var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("ILSCTX") || session.createContext("ILSCTX");
		var ctx1 = session.name("omsapijob") || session.createContext("omsapijob");
		var retry = ctx1.getVariable('retry');
		var ErrorTxt = ctx.getVariable('errormessage')
		var exitStatus = ctx.getVariable('exitStatus');
		var incomingClient = ctx.getVariable('incomingClient');
		var destination = ctx.getVariable('destintion');
		//ctx.setVariable('destination', destination);
		if (retry != 'yes') {
			var destination = ctx.getVariable('destintion');
			ctx.setVariable('exitStatus', '0');
			ctx.setVariable("destination", destination);
			if(incomingClient == session.parameters.Client){
			ctx.setVariable("outagedestination", OMSGeturl);
			var outagedestination = ctx1.getVariable('outagedestination')
				ctx.setVariable("destination", destination);
				ctx.setVariable("exitdescription", session.parameters.Restoreupdexitdescription);
			}else if (destination.includes("OMSAPIJOB.RESTORE.VERIFY.CHECK.STATUS")) {
				ctx.setVariable("exitdescription", session.parameters.Restoreupdexitdescription);
			}else if (destination.includes("OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS")){
				ctx.setVariable("exitdescription", session.parameters.verifychkexitdescription);
			}
		} else {
			ctx.setVariable('exitStatus', exitStatus);
			ctx.setVariable('exitdescription', ErrorTxt)
		}
	}
});
