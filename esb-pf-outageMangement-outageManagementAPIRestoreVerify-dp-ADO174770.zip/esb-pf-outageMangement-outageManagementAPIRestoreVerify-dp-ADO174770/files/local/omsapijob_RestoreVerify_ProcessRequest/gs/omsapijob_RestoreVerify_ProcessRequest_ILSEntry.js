var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var urlIn = sm.getVar('var://service/URL-in');
var ctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingData) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var payload = incomingData.CallBackData || incomingData.StatusCheck;
		var correlationID = payload.messageID;
		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ctx.setVariable('correlationID', '');
		} else {
			ctx.setVariable('correlationID', correlationID);
		}
		var messageType = session.parameters.messageType;
		ctx.setVariable('messageType', messageType);
		var crewAssignmentDisplayID = payload.CallID;
		if (crewAssignmentDisplayID === undefined || crewAssignmentDisplayID === null || crewAssignmentDisplayID === '') {
			ctx.setVariable('crewAssignmentDisplayID', '');
		} else {
			ctx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID);
		}
		
		if(incomingData.RestoreVerify != undefined) {
			ctx.setVariable("sourceEventTimestamp", incomingData.RestoreVerify.FieldTime);
		} else {
			var dateTime = new Date();
			var currentTime = dateTime.toISOString();
			ctx.setVariable("sourceEventTimestamp", currentTime);
		}
		if(incomingData.RestoreVerify != undefined){
			ctx.setVariable("jobID", incomingData.RestoreVerify.JobIDGUID);
		}else{
			ctx.setVariable("jobID", '');
		}
		var description = session.parameters.EntryDescription;
		ctx.setVariable("Entrydescription", description);
		ctx.setVariable("sourceUrl", urlIn);
	}
})
