var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILSCTX") || session.createContext("ILSCTX");
var ctx = session.name("omsapijob") || session.createContext("omsapijob");
var clientname = session.parameters.Client;

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		ilsctx.setVariable("exitStatus", '500')
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
		var incomingClient;
		if(!(incomingdata.CallBackData == undefined)){
			if(!(incomingdata.CallBackDatav == undefined)){
		 incomingClient = incomingdata.CallBackData.Client;
		ctx.setVariable("incomingClient", incomingClient);
				}
		}

		if (incomingdata.RestoreVerify) {
			var ExternalRefID = incomingdata.CallBackData.ExternalRefID;
			var jobId = ExternalRefID.split(':').shift();
			var Url = session.parameters.OMSGeturl;
			// /api/ServiceType/Electric/Job/{jobId}?includeFields=networkModelID,networkModelType,currentAffected,phases,energizationStatus
			var OMSGeturl = Url + '/api/ServiceType/Electric/Job/' + jobId + '?includeFields=networkModelID,networkModelType,currentAffected,phases,energizationStatus';
			ctx.setVariable("outagedestination", OMSGeturl);
			ilsctx.setVariable("destintion", OMSGeturl);
			var apiToken
			if (incomingdata.CallBackData.Client == "UrmaApp") {
				apiToken = session.parameters.apiToken_Urma;
			} else if(incomingdata.CallBackData.Client == "OutageStatusApp"){
				apiToken = session.parameters.OutageStatusApp_Token;
			} else {
				apiToken = session.parameters.osiApiToken;
			}

			headers.remove('MQMD');
			var JobGetapi = {
				target: OMSGeturl,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				headers: {
					'osiApiToken': apiToken,
				},
			};
			var info = " TargetURL :" + OMSGeturl + "; Method :" + 'GET';
			urlopen.open(JobGetapi, function(error, response) {
				if (error) {
					//retry shoud be done
					var ctx = session.name("omsapijob") || session.createContext("omsapijob");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
					var ErrorTxt = (" omsapijob_002 urlopen connect error from  omsapijob_RestoreVerify_ProcessRequest JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
					var Errorinfo = info + " urlopen connect error from JobGetapi for job id " + jobId + " is " + JSON.stringify(error);
					ilsctx.setVariable("exitStatus", '500')
					ilsctx.setVariable("errormessage", Errorinfo);
					session.output.write(incomingdata);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								ilsctx.setVariable("exitStatus", responseStatusCode)
								logger.error(" error message while reading response from omsapijob_RestoreVerify_ProcessRequest JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
								session.reject(" error message while reading response from omsapijob_RestoreVerify_ProcessRequest FSECrewGetapifor job id " + jobId + " is " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								var JobGetapiResponse = JSON.parse(responseData);
								var ctx = session.name("omsapijob") || session.createContext("omsapijob");
								ctx.setVariable("JobGetapiResponse", JobGetapiResponse);
								var networkModelType = JobGetapiResponse.networkModelType;
								var energizationStatus = JobGetapiResponse.energizationStatus;
								var OUGVerify = incomingdata.RestoreVerify.Verify;
								var OUGRestore = incomingdata.RestoreVerify.Restore;
								//								var incomingtime = incomingdata.RestoreVerify.FieldTime;
								//									var	GMTDate = new Date(incomingtime);
								//									var ESTDateVar = GMTDate.getTime();
								//									var localOffset = GMTDate.getTimezoneOffset() * 60000;
								//									var datestrng = GMTDate.toString();
								//									//var offset;
								////									if(datestrng.includes(edt)){
								////									offset = +4;
								////										} else {
								////									offset = +5;
								////									}
								//									//var utc = ESTDateVar + (3600000*offset);
								//									var utc = ESTDateVar
								//									var ctx = session.name("omsapijob")|| session.createContext("omsapijob");
								//									ctx.setVariable("utc",utc);
								//									var ESTDate = new Date(utc).toISOString();
								//									var finalutcDate = ESTDate.replace('Z', '');
								//									var	incomingepochTime = Math.floor(new Date(incomingtime+'Z') / 1000);
								var finalutcDate = incomingdata.RestoreVerify.FieldTime;
								var epochTime = Math.floor(new Date(finalutcDate) / 1000);
								epochTime = epochTime + '000';
								ctx.setVariable("epochTime", epochTime);
								//adding values to above payload start									
								var payload = {
								}
								if (JobGetapiResponse.networkModelID != undefined) {
									payload.networkModelID = JobGetapiResponse.networkModelID;
								}
								if (JobGetapiResponse.networkModelType != undefined) {
									payload.networkModelType = JobGetapiResponse.networkModelType;
								}
								if (JobGetapiResponse.phases != undefined) {
									payload.phases = JobGetapiResponse.phases;
								}
								if (JobGetapiResponse.currentAffected != undefined) {
									payload.currentAffected = JobGetapiResponse.currentAffected;
								}
								//adding value to payload end


								//stack payload start
								var StatusCheck_payload =
								{
									"StatusCheck": {

										"Client": incomingdata.CallBackData.Client,
										"ServiceName": incomingdata.CallBackData.ServiceName


									}
								}
								//	if(incomingdata.RequestVerifyRestore.Task != '' || incomingdata.RequestVerifyRestore.Task != undefined || incomingdata.RequestVerifyRestore.Task != null){
								var CallID = incomingdata.CallBackData.CallID;
								if (CallID != undefined) {
									StatusCheck_payload.StatusCheck.CallID = CallID;
								}
								var IncomingNumber = incomingdata.CallBackData.Number;
								if (IncomingNumber != undefined) {
									StatusCheck_payload.StatusCheck.Number = IncomingNumber;
								}
								var OUGLastRequestStatus = incomingdata.RestoreVerify.LastRequestStatus;
								if (OUGLastRequestStatus != undefined) {
									StatusCheck_payload.StatusCheck.LastRequestStatus = OUGLastRequestStatus;
								}
								//}
								if (JobGetapiResponse.energizationStatus != undefined) {
									StatusCheck_payload.StatusCheck.EnergizationStatus = JobGetapiResponse.energizationStatus;
								}
								StatusCheck_payload.StatusCheck.ExternalRefID = incomingdata.CallBackData.ExternalRefID;
								//New fields added in payload 
								var messageId = incomingdata.CallBackData.messageID;
								if (messageId != undefined) {
									StatusCheck_payload.StatusCheck.messageID = messageId;
								}
								var fieldtime = incomingdata.RestoreVerify.FieldTime;
								if (fieldtime != undefined) {
									StatusCheck_payload.StatusCheck.FieldTime = fieldtime;
								}
								//new fields end

								//stack payload end
								// framing failure message start
								var task_payload = {
									"CallBackData": {
										"Client": incomingdata.CallBackData.Client,
										"ServiceName": incomingdata.CallBackData.ServiceName
									},
									"UpdateEngerzationStatus": {}
								}
								//if(incomingdata.RequestVerifyRestore.Task != '' || incomingdata.RequestVerifyRestore.Task != undefined || incomingdata.RequestVerifyRestore.Task != null){
								if (incomingdata.CallBackData.CallID != undefined) {
									//	task_payload.TaskRequestedProperties.push(incomingdata.RequestVerifyRestore.Task.CallID);
									task_payload.CallBackData.CallID = incomingdata.CallBackData.CallID;
								}
								if (incomingdata.CallBackData.Number != undefined) {
									task_payload.CallBackData.Number = incomingdata.CallBackData.Number;
								}
								if (incomingdata.CallBackData.ExternalRefID != undefined) {
									task_payload.CallBackData.ExternalRefID = incomingdata.CallBackData.ExternalRefID;
								}
								if (JobGetapiResponse.energizationStatus) {
									task_payload.UpdateEngerzationStatus.EnergizationStatus = JobGetapiResponse.energizationStatus;
								}
								//}	
								//New fields added in payload 
								var messageId = incomingdata.CallBackData.messageID;
								if (messageId != undefined) {
									task_payload.CallBackData.messageID = messageId;
								}
								var fieldtime = incomingdata.RestoreVerify.FieldTime;
								if (fieldtime != undefined) {
									task_payload.CallBackData.FieldTime = fieldtime;
								}
								//new fields end
								// framing failure message end	
								if (OUGVerify == true || OUGVerify == 'true') {
									OUGVerify == true
									if (OUGVerify == true && (networkModelType == 0 || networkModelType == 1) && energizationStatus == 'PREDICTED') {

										var OUGVerify_VerifyPremises_url = Url + '/api/ServiceType/Electric/Job/' + jobId + '/VerifyPremises?time=' + epochTime
										var TokenValue = apiToken;
										var OUGVerify_VerifyPremises = {
											target: OUGVerify_VerifyPremises_url,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'POST',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										var info = " TargetURL :" + OUGVerify_VerifyPremises_url + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
										urlopen.open(OUGVerify_VerifyPremises, function(error, response) {
											if (error) {
												var ctx = session.name("omsapijob") || session.createContext("omsapijob");
												ctx.setVariable("retry", 'yes');
												logger.error(" urlopen connect error with omsapijob_RestoreVerify_ProcessRequest Verify_VerifyPremises post is " + JSON.stringify(error));
												var ErrorTxt = "omsapijob_003 urlopen connect error with Verify_VerifyPremises omsapijob_RestoreVerify_ProcessRequest post is " + JSON.stringify(error);
												var Erroinfo = " urlopen connect error with omsapijob_RestoreVerify_ProcessRequest Verify_VerifyPremises post details are " + info + "errorinfo: " + JSON.stringify(error);
												ilsctx.setVariable('errormessage', Erroinfo);
												ilsctx.setVariable("exitStatus", '500')
												ctx.setVariable("ErrorTxt", ErrorTxt);
												session.output.write(incomingdata);
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200 || responseStatusCode == 202) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															ilsctx.setVariable("exitStatus", responseStatusCode)
															logger.error(" error message while reading from omsapijob_RestoreVerify_ProcessRequest Verify_VerifyPremises post call " + JSON.stringify(error));
															session.reject("error message while reading from omsapijob_RestoreVerify_ProcessRequest Verify_VerifyPremises post call " + JSON.stringify(error));
														}
														else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response  recieved from call Verify_VerifyPremises is " + OUGVerify_VerifyPremises_ResponseData);
															var OUGVerify_VerifyPremises_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
															var ctx = session.name("omsapijob") || session.createContext("omsapijob");
															ctx.setVariable("OUGVerify_VerifyPremises_ResponseData", OUGVerify_VerifyPremises_ResponseData);
															StatusCheck_payload.StatusCheck.statusId = OUGVerify_VerifyPremises_ResponseData;
															ctx.setVariable("OUGVerify_VerifyPremises_payload", StatusCheck_payload);
															//start calling queue api
															var Queueurl = session.parameters.VerifyUpdateMQurl;
															var test = PushingToQcall(Queueurl, StatusCheck_payload);
															ilsctx.setVariable('exitStatus', "0");
															ilsctx.setVariable("destintion", Queueurl);
															//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.CHECK.STATUS");
															session.output.write(StatusCheck_payload);
															//end calling queue api 	
														}
													});
												} else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															ilsctx.setVariable("exitStatus", responseStatusCode)
															logger.error("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGVerify_VerifyPremises post call is  " + JSON.stringify(error));
															session.reject("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGVerify_VerifyPremises post call is " + JSON.stringify(error));
														} else {
															logger.debug(" response returned from OUGVerify_VerifyPremises post call is " + responseStatusCode + " " + responseData);
															var OUGVerify_VerifyPremises_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
															var ctx = session.name("omsapijob") || session.createContext("omsapijob");
															ctx.setVariable("OUGVerify_VerifyPremises_ResponseData_Failure", OUGVerify_VerifyPremises_ResponseData_Failure);
															task_payload.UpdateEngerzationStatus.LastRequestStatus = OUGVerify_VerifyPremises_ResponseData_Failure;
															ctx.setVariable("OUGVerify_VerifyPremises_Failure", task_payload);
															//start calling queue api
															var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
															var clientList = clientname.split(",").map(client => client.trim());
	                                                        if (!clientList.includes(incomingdata.CallBackData.Client)) {
																var test = PushingToQcall(Queueurl, task_payload);
															}
															ilsctx.setVariable("exitStatus", responseStatusCode)
															ilsctx.setVariable("destintion", OUGVerify_VerifyPremises_url);
															//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS");
															session.output.write(task_payload);
															//end calling queue api 
														}
													});
												}
											}
										});
										//call end
									} else if (energizationStatus == 'PREDICTED') {
										//Call  POST /api/ServiceType/Electric/Job/{jobId}/VerifyDevice?time=10
										var OUGVerify_VerifyDevice_url = Url + '/api/ServiceType/Electric/Job/' + jobId + '/VerifyDevice?time=' + epochTime
										var TokenValue = apiToken;
										var OUGVerify_VerifyDevice = {
											target: OUGVerify_VerifyDevice_url,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'POST',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										var info = " TargetURL :" + OUGVerify_VerifyDevice_url + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
										urlopen.open(OUGVerify_VerifyDevice, function(error, response) {
											if (error) {
												var ctx = session.name("omsapijob") || session.createContext("omsapijob");
												ctx.setVariable("retry", 'yes');
												logger.debug("urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGVerify_VerifyDevice post is " + JSON.stringify(error));
												var ErrorTxt = "omsapijob_003  urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGVerify_VerifyDevice post is " + JSON.stringify(error);
												ctx.setVariable("ErrorTxt", ErrorTxt);
												var Errorinfo = "urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGVerify_VerifyDevice post details are " + info + "errorinfo" + JSON.stringify(error);
												ilsctx.setVariable("exitStatus", '500')
												ilsctx.setVariable("errormessage", Errorinfo)
												session.output.write(incomingdata);
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200 || responseStatusCode == 202) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															ilsctx.setVariable("exitStatus", responseStatusCode)
															logger.error(" error message while reading from omsapijob_RestoreVerify_ProcessRequest OUGVerify_VerifyDevice post call " + JSON.stringify(error));
															session.reject("error message while reading from omsapijob_RestoreVerify_ProcessRequest OUGVerify_VerifyDevice post call " + JSON.stringify(error));
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response code recieved from call OUGVerify_VerifyDevice is " + responseStatusCode);
															var OUGVerify_VerifyDevice_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
															var ctx = session.name("omsapijob") || session.createContext("omsapijob");
															ctx.setVariable("OUGVerify_VerifyDevice_ResponseData", OUGVerify_VerifyDevice_ResponseData);
															StatusCheck_payload.StatusCheck.statusId = OUGVerify_VerifyDevice_ResponseData;
															ctx.setVariable("OUGVerify_VerifyDevice_payload", StatusCheck_payload);
															//start calling queue api
															var Queueurl = session.parameters.VerifyUpdateMQurl;
															var test = PushingToQcall(Queueurl, StatusCheck_payload);
															ilsctx.setVariable('exitStatus', "0");
															ilsctx.setVariable("destintion", Queueurl);
															//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.CHECK.STATUS")
															session.output.write(StatusCheck_payload);
															//end calling queue api 
														}
													});
												} else {

													response.readAsBuffer(function(error, responseData) {
														if (error) {
															ilsctx.setVariable("exitStatus", responseStatusCode)
															logger.error("failure in reading message from omsapijob OUGVerify_VerifyDevice post call is  " + JSON.stringify(error));
															session.reject("failure in reading message from omsapijob OUGVerify_VerifyDevice post call is " + JSON.stringify(error));
														} else {
															logger.debug(" response returned from OUGVerify_VerifyDevice post call is " + responseStatusCode + " " + responseData);
															var OUGVerify_VerifyDevice_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
															var ctx = session.name("omsapijob") || session.createContext("omsapijob");
															ctx.setVariable("OUGVerify_VerifyDevice_ResponseData_Failure", OUGVerify_VerifyDevice_ResponseData_Failure);
																var ctx = session.name("ILSCTX") || session.createContext("ILSCTX");
																ctx.setVariable("exitdescription", OUGVerify_VerifyDevice_ResponseData_Failure);
															task_payload.UpdateEngerzationStatus.LastRequestStatus = OUGVerify_VerifyDevice_ResponseData_Failure;
															ctx.setVariable("OUGVerify_VerifyDevice_Failure", task_payload);
															//start calling queue api
															var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
															var clientList = clientname.split(",").map(client => client.trim());
	                                                        if (!clientList.includes(incomingdata.CallBackData.Client)) {
																var test = PushingToQcall(Queueurl, task_payload);
															}
															ilsctx.setVariable("exitStatus", responseStatusCode)
															ilsctx.setVariable("destintion", OUGVerify_VerifyDevice_url);
															//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS");
															session.output.write(task_payload);
															//end calling queue api 
														}
													});

												}
											}
										});
										//call end
									} else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												ilsctx.setVariable("exitStatus", responseStatusCode)
												logger.error("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGVerify post call is  " + JSON.stringify(error));
												session.reject("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUVerify post call is " + JSON.stringify(error));
											} else {
												logger.debug(" response returned from OUGVerify post call is " + responseStatusCode + " " + responseData);
												//								var OUGRestore_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
												var ctx = session.name("omsapijob") || session.createContext("omsapijob");
												//  								ctx.setVariable("OUGVerify_ResponseData_Failure", OUGVerify_ResponseData_Failure);
												task_payload.UpdateEngerzationStatus.LastRequestStatus = session.parameters.RestoreBussinessFailureLastRequestStatus;
												//								 ctx.setVariable("OUGRestore_Failure", task_payload);
												//									//start calling queue api
												var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
												var clientList = clientname.split(",").map(client => client.trim());
	                                            if (!clientList.includes(incomingdata.CallBackData.Client)) {
													var test = PushingToQcall(Queueurl, task_payload);
												}
											//	ilsctx.setVariable("destintion", OUGVerify_VerifyPremises_url);
										    	ilsctx.setVariable("exitdescription", "energizationStatus is NONE");
												ilsctx.setVariable("exitStatus", responseStatusCode)
												//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS");
												session.output.write(task_payload);
												//end calling queue api	
											}
										});

									}
								}
								if (OUGRestore == true || OUGRestore == 'true') {
									OUGRestore == true
									if (energizationStatus == 'VERIFIED' || energizationStatus == 'PREDICTED') {
										if ((networkModelType == 0 || networkModelType == 1) && energizationStatus == 'VERIFIED') {
											//POST /api/ServiceType/Electric/Job/{jobId}/RestorePremises?time=10	
											var OUGRestore_networkModelType_VERIFIED_url = Url + '/api/ServiceType/Electric/Job/' + jobId + '/RestorePremises?time=' + epochTime
											var TokenValue = apiToken;
											var OUGRestore_networkModelType_VERIFIED = {
												target: OUGRestore_networkModelType_VERIFIED_url,
												sslClientProfile: 'OMS_Client_Profile',
												method: 'POST',
												contentType: 'application/json',
												headers: {
													'osiApiToken': TokenValue
												},
												data: payload
											};
											var info = " TargetURL :" + OUGRestore_networkModelType_VERIFIED_url + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
											urlopen.open(OUGRestore_networkModelType_VERIFIED, function(error, response) {
												if (error) {
													var ctx = session.name("omsapijob") || session.createContext("omsapijob");
													ctx.setVariable("retry", 'yes');
													logger.debug(" urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_networkModelType_VERIFIED post is " + JSON.stringify(error));
													var ErrorTxt = "omsapijob_003 urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_networkModelType_VERIFIED post is " + JSON.stringify(error);
													var Errorinfo = " urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_networkModelType_VERIFIED post details are " + info + "errordetails:" + JSON.stringify(error);
													ilsctx.setVariable("errormessage", Errorinfo);
													ilsctx.setVariable("exitStatus", '500')
													ctx.setVariable("ErrorTxt", ErrorTxt);
													session.output.write(incomingdata);
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200 || responseStatusCode == 202) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																ilsctx.setVariable("exitStatus", responseStatusCode)
																logger.error(" error message while reading from omsapijob_RestoreVerify_ProcessRequest OUGRestore_networkModelType_VERIFIED post call " + JSON.stringify(error));
																session.reject("error message while reading from omsapijob_RestoreVerify_ProcessRequest OUGRestore_networkModelType_VERIFIED post call " + JSON.stringify(error));
															} else {
																hm.response.statusCode = responseStatusCode;
																logger.debug("response code recieved from call OUGRestore_networkModelType_VERIFIED is " + responseStatusCode);
																var OUGRestore_networkModelType_VERIFIED_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																var ctx = session.name("omsapijob") || session.createContext("omsapijob");
																ctx.setVariable("OUGRestore_networkModelType_VERIFIED_ResponseData", OUGRestore_networkModelType_VERIFIED_ResponseData);
																StatusCheck_payload.StatusCheck.statusId = OUGRestore_networkModelType_VERIFIED_ResponseData;
																ctx.setVariable("OUGRestore_networkModelType_VERIFIED_payload", StatusCheck_payload);
																//start calling queue api
																var Queueurl = session.parameters.VerifyUpdateMQurl;
																var test = PushingToQcall(Queueurl, StatusCheck_payload);
																ilsctx.setVariable('exitStatus', "0");
																ilsctx.setVariable("destintion", Queueurl);
																//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.CHECK.STATUS")
																session.output.write(StatusCheck_payload);
																//end calling queue api 


															}
														});
													} else {

														response.readAsBuffer(function(error, responseData) {
															if (error) {
																ilsctx.setVariable("exitStatus", responseStatusCode)
																logger.error("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGRestore_networkModelType_VERIFIED post call is  " + JSON.stringify(error));
																session.reject("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGRestore_networkModelType_VERIFIED post call is " + JSON.stringify(error));
															} else {
																logger.debug(" response returned from OUGRestore_networkModelType_VERIFIED post call is " + responseStatusCode + " " + responseData);
																var OUGRestore_networkModelType_VERIFIED_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																var ctx = session.name("omsapijob") || session.createContext("omsapijob");
																ctx.setVariable("OUGRestore_networkModelType_VERIFIED_ResponseData_Failure", OUGRestore_networkModelType_VERIFIED_ResponseData_Failure);
																task_payload.UpdateEngerzationStatus.LastRequestStatus = OUGRestore_networkModelType_VERIFIED_ResponseData_Failure;
																ctx.setVariable("OUGRestore_networkModelType_VERIFIED_Failure", task_payload);
																//start calling queue api
																var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
																var clientList = clientname.split(",").map(client => client.trim());
	                                                            if (!clientList.includes(incomingdata.CallBackData.Client)) {
																	var test = PushingToQcall(Queueurl, task_payload);
																}
																ilsctx.setVariable("exitStatus", responseStatusCode)
																ilsctx.setVariable("destintion", OUGRestore_networkModelType_VERIFIED_url);
																//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS");
																session.output.write(task_payload);
																//end calling queue api 
															}
														});

													}
												}
											});

										} else if (energizationStatus == 'PREDICTED') {

											//POST /api/ServiceType/Electric/Job/{jobId}/RestorePredicted?time=10	
											var OUGRestore_PREDICTED_url = Url + '/api/ServiceType/Electric/Job/' + jobId + '/RestorePredicted?time=' + epochTime
											var TokenValue = apiToken;
											var OUGRestore_PREDICTED = {
												target: OUGRestore_PREDICTED_url,
												sslClientProfile: 'OMS_Client_Profile',
												method: 'POST',
												contentType: 'application/json',
												headers: {
													'osiApiToken': TokenValue
												},
												data: payload
											};
											var info = " TargetURL :" + OUGRestore_PREDICTED_url + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
											urlopen.open(OUGRestore_PREDICTED, function(error, response) {
												if (error) {
													var ctx = session.name("omsapijob") || session.createContext("omsapijob");
													ctx.setVariable("retry", 'yes');
													logger.debug(" urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_PREDICTED post is " + JSON.stringify(error));
													var ErrorTxt = "omsapijob_003 urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_PREDICTED post is " + JSON.stringify(error);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ilsctx.setVariable("exitStatus", '500')
													var Errorinfo = " urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_PREDICTED post details are " + info + "errorinfo:" + JSON.stringify(error);
													ilsctx.setVariable("errormessage", Errorinfo);
													session.output.write(incomingdata);
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200 || responseStatusCode == 202) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																ilsctx.setVariable("exitStatus", responseStatusCode)
																logger.error(" error message while reading from omsapijob_RestoreVerify_ProcessRequest OUGRestore_PREDICTED post call " + JSON.stringify(error));
																session.reject("error message while reading from omsapijob_RestoreVerify_ProcessRequest OUGRestore_PREDICTED post call " + JSON.stringify(error));
															} else {
																hm.response.statusCode = responseStatusCode;
																logger.debug("response code recieved from call OUGRestore_PREDICTED is " + responseStatusCode);
																var OUGRestore_PREDICTED_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																var ctx = session.name("omsapijob") || session.createContext("omsapijob");
																ctx.setVariable("OUGRestore_PREDICTED_ResponseData", OUGRestore_PREDICTED_ResponseData);
																StatusCheck_payload.StatusCheck.statusId = OUGRestore_PREDICTED_ResponseData;
																ctx.setVariable("OUGRestore_PREDICTED_payload", StatusCheck_payload);
																//start calling queue api
																var Queueurl = session.parameters.VerifyUpdateMQurl;
																var test = PushingToQcall(Queueurl, StatusCheck_payload);
																ilsctx.setVariable('exitStatus', "0"); 
																ilsctx.setVariable("destintion", Queueurl);
																//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.CHECK.STATUS")
																session.output.write(StatusCheck_payload);
																//end calling queue api 						
															}
														});
													} else {

														response.readAsBuffer(function(error, responseData) {
															if (error) {
																ilsctx.setVariable("exitStatus", responseStatusCode)
																logger.error("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGRestore_PREDICTED post call is  " + JSON.stringify(error));
																session.reject("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGRestore_PREDICTED post call is " + JSON.stringify(error));
															} else {
																logger.debug(" response returned from OUGRestore_PREDICTED post call is " + responseStatusCode + " " + responseData);
																var OUGRestore_PREDICTED_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																var ctx = session.name("omsapijob") || session.createContext("omsapijob");
																ctx.setVariable("OUGRestore_PREDICTED_ResponseData_Failure", OUGRestore_PREDICTED_ResponseData_Failure);
																task_payload.UpdateEngerzationStatus.LastRequestStatus = OUGRestore_PREDICTED_ResponseData_Failure;
																ctx.setVariable("OUGRestore_PREDICTED_Failure", task_payload);
																//start calling queue api
																var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
																var clientList = clientname.split(",").map(client => client.trim());
	                                                            if (!clientList.includes(incomingdata.CallBackData.Client)) {
																var test = PushingToQcall(Queueurl, task_payload);
																}
																ilsctx.setVariable("exitStatus",responseStatusCode)
																ilsctx.setVariable("destintion", OUGRestore_PREDICTED_url);
																//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS");
																session.output.write(task_payload);
																//end calling queue api					
															}
														});

													}
												}
											});
											//other cases
										} else if (energizationStatus == 'VERIFIED') {
											//POST /api/ServiceType/Electric/Job/{jobId}/RestoreDevice?time=10
											var OUGRestore_VERIFIED_url = Url + '/api/ServiceType/Electric/Job/' + jobId + '/RestoreDevice?time=' + epochTime
											var TokenValue = apiToken;
											var OUGRestore_VERIFIED = {
												target: OUGRestore_VERIFIED_url,
												sslClientProfile: 'OMS_Client_Profile',
												method: 'POST',
												contentType: 'application/json',
												headers: {
													'osiApiToken': TokenValue
												},
												data: payload
											};
											var info = " TargetURL :" + OUGRestore_VERIFIED_url + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
											urlopen.open(OUGRestore_VERIFIED, function(error, response) {
												if (error) {
													var ctx = session.name("omsapijob") || session.createContext("omsapijob");
													ctx.setVariable("retry", 'yes');
													logger.debug(" urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_VERIFIED post is " + JSON.stringify(error));
													var ErrorTxt = "omsapijob_003 urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_VERIFIED post is " + JSON.stringify(error);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													var Errorinfo = " urlopen connect error with omsapijob_RestoreVerify_ProcessRequest OUGRestore_VERIFIED post details are " + info + "errorinfo:" + JSON.stringify(error);
													ilsctx.setVariable("exitStatus", '500')
													ilsctx.setVariable("errormessage", Errorinfo);
													session.output.write(incomingdata);
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200 || responseStatusCode == 202) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																ilsctx.setVariable("exitStatus",responseStatusCode)
																logger.error(" error message while reading from omsapijob_RestoreVerify_ProcessRequest OUGRestore_VERIFIED post call " + JSON.stringify(error));
																session.reject("error message while reading from omsapijob_RestoreVerify_ProcessRequest OUGRestore_VERIFIED post call " + JSON.stringify(error));
															} else {
																hm.response.statusCode = responseStatusCode;
																logger.debug("response code recieved from call OUGRestore_VERIFIED is " + responseStatusCode);
																var ctx = session.name("omsapijob") || session.createContext("omsapijob");
																var OUGRestore_VERIFIED_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																ctx.setVariable("OUGRestore_VERIFIED_ResponseData", OUGRestore_VERIFIED_ResponseData);
																StatusCheck_payload.StatusCheck.statusId = OUGRestore_VERIFIED_ResponseData;
																ctx.setVariable("OUGRestore_VERIFIED_payload", StatusCheck_payload);
																//start calling queue api
																var Queueurl = session.parameters.VerifyUpdateMQurl;
																var test = PushingToQcall(Queueurl, StatusCheck_payload);
																ilsctx.setVariable('exitStatus', "0");
																ilsctx.setVariable("destintion", Queueurl);
																//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.CHECK.STATUS")
																session.output.write(StatusCheck_payload);
																//end calling queue api 						
															}
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																ilsctx.setVariable("exitStatus",responseStatusCode)
																logger.error("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGRestore_VERIFIED post call is  " + JSON.stringify(error));
																session.reject("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGRestore_VERIFIED post call is " + JSON.stringify(error));
															} else {
																logger.debug(" response returned from OUGRestore_VERIFIED post call is " + responseStatusCode + " " + responseData);
																var OUGRestore_VERIFIED_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																var ctx = session.name("omsapijob") || session.createContext("omsapijob");
																ctx.setVariable("OUGRestore_VERIFIED_ResponseData_Failure", OUGRestore_VERIFIED_ResponseData_Failure);
																task_payload.UpdateEngerzationStatus.LastRequestStatus = OUGRestore_VERIFIED_ResponseData_Failure;
																ctx.setVariable("OUGRestore_VERIFIED_Failure", task_payload);
																//start calling queue api
																var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
																var clientList = clientname.split(",").map(client => client.trim());
	                                                            if (!clientList.includes(incomingdata.CallBackData.Client)) {
																	var test = PushingToQcall(Queueurl, task_payload);
																}
																ilsctx.setVariable("exitStatus",responseStatusCode)
																ilsctx.setVariable("destintion", OUGRestore_VERIFIED_url);
																//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.CHECK.STATUS")
																session.output.write(task_payload);
																//end calling queue api
															}
														});

													}
												}
											});
										}
									} else {

										response.readAsBuffer(function(error, responseData) {
											if (error) {
												ilsctx.setVariable("exitStatus",responseStatusCode)
												logger.error("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGRestore post call is  " + JSON.stringify(error));
												session.reject("failure in reading message from omsapijob_RestoreVerify_ProcessRequest OUGRestore post call is " + JSON.stringify(error));
											} else {
												logger.debug(" response returned from OUGRestore post call is " + responseStatusCode + " " + responseData);
												//								var OUGRestore_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
												var ctx = session.name("omsapijob") || session.createContext("omsapijob");
												//  								ctx.setVariable("OUGRestore_ResponseData_Failure", OUGRestore_ResponseData_Failure);
												task_payload.UpdateEngerzationStatus.LastRequestStatus = session.parameters.RestoreBussinessFailureLastRequestStatus;
												//								 ctx.setVariable("OUGRestore_Failure", task_payload);
												//									//start calling queue api
												var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
												var clientList = clientname.split(",").map(client => client.trim());
	                                            if (!clientList.includes(incomingdata.CallBackData.Client)) {
													var test = PushingToQcall(Queueurl, task_payload);
												}
												ilsctx.setVariable("exitStatus",responseStatusCode)
												ilsctx.setVariable("exitdescription", "energizationStatus is NONE");
											//	ilsctx.setVariable("destintion", OUGRestore_networkModelType_VERIFIED_url);
												//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS");
												session.output.write(task_payload);
												//end calling queue api	
											}
										});

									}
								}// ougrestore = true end
							}
						});
					} else if (responseStatusCode == 401 || responseStatusCode == 403) {
						//retry shoud be done
							
						var ctx = session.name("omsapijob") || session.createContext("omsapijob");
						ctx.setVariable("retry", 'yes');
						logger.error(" authentication/authorization error in omsapijob_RestoreVerify_ProcessRequest JobGetapi for job id " + jobId);
						var ErrorTxt = "omsapijob_004 error message while reading response from omsapijob_RestoreVerify_ProcessRequest JobGetapi for job id " + jobId ;
						ctx.setVariable("ErrorTxt", ErrorTxt);
						var Errorinfo = " omsapijob_004:authentication/authorization error from omsapijob_RestoreVerify_ProcessRequest JobGetapi for job id " + jobId ;
						ilsctx.setVariable("errormessage", Errorinfo);
						ilsctx.setVariable("exitStatus",responseStatusCode)
						//ilsctx.setVariable("exitstatus", "401");
						session.output.write(incomingdata);

					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								ilsctx.setVariable("exitStatus",responseStatusCode)
								logger.error("Error returned while doing GET for JobGetapi  for jobid " + jobId + " is " + JSON.stringify(error));
								session.reject("Error returned while doing GET for JobGetapi  for jobId " + jobId + " is " + JSON.stringify(error));
							} else {


								// framing failure message start
								var task_payload = {
									"CallBackData": {
										"Client": incomingdata.CallBackData.Client,
										"ServiceName": incomingdata.CallBackData.ServiceName
									},
									"UpdateEngerzationStatus": {
									}
								}
								if (incomingdata.CallBackData.CallID != undefined) {
									task_payload.CallBackData.CallID = incomingdata.CallBackData.CallID;
								}
								if (incomingdata.CallBackData.Number != undefined) {
									task_payload.CallBackData.Number = incomingdata.CallBackData.Number;
								}


								if (incomingdata.CallBackData.ExternalRefID != undefined) {
									task_payload.CallBackData.ExternalRefID = incomingdata.CallBackData.ExternalRefID;
								}

								task_payload.UpdateEngerzationStatus.LastRequestStatus = response.reasonPhrase;

								//New fields added in payload 
								var messageId = incomingdata.CallBackData.messageID;
								if (messageId != undefined) {
									task_payload.CallBackData.messageID = messageId;
								}
								var fieldtime = incomingdata.RestoreVerify.FieldTime;
								if (fieldtime != undefined) {
									task_payload.CallBackData.FieldTime = fieldtime;
								}
								//new fields end

								var ctx = session.name("omsapijob") || session.createContext("omsapijob");
								ctx.setVariable("GETCALLFailurepayload", task_payload);
								//start calling queue api
								var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
								var clientList = clientname.split(",").map(client => client.trim());
	                            if (!clientList.includes(incomingdata.CallBackData.Client)) {
									var test = PushingToQcall(Queueurl, task_payload);
								}
								ilsctx.setVariable("destintion", OMSGeturl);
								//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS");
								session.output.write(task_payload);
								//end calling queue api
							}
						});
					}
				}
			});

		} else if (incomingdata.CallBackData) {
			//start calling queue api this block is for doing mq retry if unable to place failure payload to backend queue
			var Queueurl = session.parameters.RestoreVerifyCheckMQurl;
			var clientList = clientname.split(",").map(client => client.trim());
	        if (!clientList.includes(incomingdata.CallBackData.Client)) {
				var test = PushingToQcall(Queueurl, incomingdata);
			}
			ilsctx.setVariable("destintion", Queueurl);
			//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.UPDATE.STATUS");
			//end calling queue api
			session.output.write(incomingdata);
		} else if (incomingdata.StatusCheck) {
			//start calling queue api this block is for doing mq retry if unable to place failure payload to backend queue
			
			var Queueurl = session.parameters.VerifyUpdateMQurl;
			var test = PushingToQcall(Queueurl, incomingdata);
			ilsctx.setVariable("destintion", Queueurl);
			//ilsctx.setVariable("destintion", "OMSAPIJOB.RESTORE.VERIFY.CHECK.STATUS");
			//end calling queue api
			session.output.write(incomingdata);

		}

	}
});

function PushingToQcall(url, Data) {
	var ctx = session.name("omsapijob") || session.createContext("omsapijob");
	var StandaloneMQurl = url;
	var payload = Data;
	var PushingToQueue = {
		target: StandaloneMQurl,
		data: payload
	};
	
	try {
		var info = " TargetURL :" + StandaloneMQurl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
		urlopen.open(PushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var ctx = session.name("omsapijob") || session.createContext("omsapijob");
				ctx.setVariable("retry", 'yes');
				logger.debug("error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue " + StandaloneMQurl + " is " + error);
				var ErrorTxt = ("omsapijob_005 error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue " + StandaloneMQurl + " is " + error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				var Errorinfo = "error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue details are" + info + " errorinfo: " + error;
				ilsctx.setVariable("errormessage", Errorinfo);
				ilsctx.setVariable("exitStatus", '500')

			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							// session.reject(" error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue is "+error);
							var ctx = session.name("omsapijob") || session.createContext("omsapijob");
							ctx.setVariable("retry", 'yes');
							logger.debug("error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue is " + error);
							var ErrorTxt = ("omsapijob_005 error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue is " + error);
							ctx.setVariable("ErrorTxt", ErrorTxt);
							var Errorinfo = "error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue details are " + info + "errorinfo:" + error;
							ilsctx.setVariable("errormessage", Errorinfo);
							ilsctx.setVariable("exitStatus",mqrc);
						} else {
							ilsctx.setVariable('exitStatus', "0");
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var ctx = session.name("omsapijob") || session.createContext("omsapijob");
					ctx.setVariable("retry", 'yes');
					logger.debug("response code for omsapijob_RestoreVerify_ProcessRequest " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
					var ErrorTxt = ("omsapijob_005 response code for omsapijob_RestoreVerify_ProcessRequest " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
					ctx.setVariable("ErrorTxt", ErrorTxt);
					var Errorinfo = "response code for omsapijob_RestoreVerify_ProcessRequest details are" + info + " urlopen.open error [MQRC=" + mqrc + "]";
					ilsctx.setVariable("errormessage", Errorinfo);
					ilsctx.setVariable("exitStatus",mqrc)
				}
			}
		});
	} catch {
		var Errorinfo = "response code for omsapijob_RestoreVerify_ProcessRequest " + StandaloneMQurl + " urlopen.open error ";
		ctx.setVariable("retry", 'yes');
		ilsctx.setVariable("errormessage", Errorinfo);
		ilsctx.setVariable("exitStatus", '500')
	}

}
