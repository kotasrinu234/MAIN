var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("ffs_ReceiveRequest") || session.createContext("ffs_ReceiveRequest");
var ilsctx = session.name("ILSCTX") || session.createContext("ILSCTX");
var ctx1 = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
		var ffsSendResponseUrl = session.parameters.ffsSendResponseUrl;
		var ffsSendResponsecall = {
			target: ffsSendResponseUrl,
			method: 'POST',
			sslClientProfile: 'omsapijob_RestoreVerify_UpdateStatus_TLS_ClientProfile',
			contentType: 'application/json',
			data: incomingdata
		};
		var info = " TargetURL :" + ffsSendResponseUrl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(incomingdata) + ". ";
		urlopen.open(ffsSendResponsecall, function(error, response) {
			if (error) {
				logger.error("urlopen connect error with connecting to ffs_SendResponse from omsapijob_RestoreVerify_UpdateStatus is api " + JSON.stringify(error));
				var Errorinfo = "urlopen connect error with connecting to ffs_SendResponse from omsapijob_RestoreVerify_UpdateStatus details are " + info + " errorinfo:" + JSON.stringify(error);
				ilsctx.setVariable("errormessage", Errorinfo);
				session.reject("urlopen connect error with connecting to ffs_SendResponse from omsapijob_RestoreVerify_UpdateStatus is api " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("error message while reading response from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service is " + JSON.stringify(error));
							var Errorinfo = "error message while reading response from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service details are " + info + "error details:" + JSON.stringify(error);
							ilsctx.setVariable("errormessage", Errorinfo);
							session.reject(" error message while reading response from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service is " + JSON.stringify(error));
						} else {
							hm.response.statusCode = responseStatusCode;
							hm.response.statusCode = responseStatusCode;
							ctx1.setVariable('ExitStatus', '0');
						}
					});
				} else if ((responseStatusCode == 500)) {

					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "url connection error , details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable("errormessage", errorinfo);
							logger.error("Error returned while doing post for Create fse api call is  " + JSON.stringify(error));
							session.reject("Error returned while post for Create fse api call is" + JSON.stringify(error));
						} else {
							var flagvalue;
							var FSEAPIRes = (responseData.toString());
							var errorcode = session.parameters.responseErrorcodes;
							var ErrorCodeList = errorcode.split(',');
							var errormessage = session.parameters.responseErrormessage;
							if (FSEAPIRes.includes(errormessage)) {
								flagvalue = true;
							} else {
								for (var i = 0; i < ErrorCodeList.length; i++) {
									var numberval = Number(ErrorCodeList[i])
									if (FSEAPIRes.includes(String(numberval))) {
										flagvalue = true;
									}

								}
							}
							if (flagvalue) {
								ctx.setVariable("retry", 'yes');
								var errorinfo = "Error returned while updating from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service statusCode " + responseStatusCode + " " + responseData + " details are:" + info;
								ctx1.setVariable('ExitStatus', responseStatusCode);
								ctx1.setVariable("exitdescription", errorinfo);
								logger.error(errorinfo)
								var ErrorTxt = "Error returned while updating from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service statusCode " + responseStatusCode + " details are:" + info;
								ctx.setVariable("ErrorTxt", ErrorTxt);
							} else {
								var errorinfo = "Error returned while updating from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service statusCode " + responseStatusCode + " " + responseData + " details are:" + info;
								ctx1.setVariable('ExitStatus', responseStatusCode);
								ctx1.setVariable('exitdescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						}
					});

				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("Error returned while doing post  from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service is  " + JSON.stringify(error));
							var Errorinfo = "Error returned while doing post  from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service details are " + info + "error details:" + JSON.stringify(error);
							ilsctx.setVariable("errormessage", Errorinfo);
							session.reject("Error returned while post for from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service is" + JSON.stringify(error));
						} else {
							logger.error("Error returned while updating from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service statusCode " + responseStatusCode + " " + responseData);
							session.reject("Error returned while updating from ffs_SendResponse in omsapijob_RestoreVerify_UpdateStatus service " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
});
