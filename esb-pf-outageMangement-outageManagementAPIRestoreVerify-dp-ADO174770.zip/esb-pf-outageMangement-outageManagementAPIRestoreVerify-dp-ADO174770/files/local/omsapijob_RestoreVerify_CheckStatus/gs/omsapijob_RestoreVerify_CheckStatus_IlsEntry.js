var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var urlIn = sm.getVar('var://service/URL-in');
var ctx = session.name("ILS") || session.createContext("ILS");

session.input.readAsJSON(function(readAsJSONError, incomingData) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data: " + JSON.stringify(readAsJSONError));
        session.reject(readAsJSONError);
    } else {
        var payload = incomingData.StatusCheck || incomingData.CallBackData;
        
        // Ensure payload is defined
        if (payload) {
            var correlationID = payload.messageID;
            if (correlationID === undefined || correlationID === null || correlationID === '') {
                ctx.setVariable('correlationID', '');
            } else {
                ctx.setVariable('correlationID', correlationID);
            }
            
            var crewAssignmentDisplayID = payload.CallID;
            if (crewAssignmentDisplayID === undefined || crewAssignmentDisplayID === null || crewAssignmentDisplayID === '') {
                ctx.setVariable('crewAssignmentDisplayID', '');
            } else {
                ctx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID);
            }
            
            if (payload.FieldTime) {
                ctx.setVariable("sourceEventTimestamp", payload.FieldTime);
            } else {
                var dateTime = new Date();
                var currentTime = dateTime.toISOString();
                ctx.setVariable("sourceEventTimestamp", currentTime);
            }
        } else {
            logger.error("Payload is undefined");
            ctx.setVariable('correlationID', '');
            ctx.setVariable('crewAssignmentDisplayID', '');
            var dateTime = new Date();
            var currentTime = dateTime.toISOString();
            ctx.setVariable("sourceEventTimestamp", currentTime);
        }

        if (incomingData.StatusCheck !== undefined) {
            ctx.setVariable("statusId", incomingData.StatusCheck.statusId);
        } else {
            ctx.setVariable("statusId", '');
        }

        var messageType = session.parameters.messageType;
        ctx.setVariable('messageType', messageType);

        var description = session.parameters.EntryDescription;
        ctx.setVariable("Entrydescription", description);
        ctx.setVariable("sourceUrl", urlIn);
    }
});
