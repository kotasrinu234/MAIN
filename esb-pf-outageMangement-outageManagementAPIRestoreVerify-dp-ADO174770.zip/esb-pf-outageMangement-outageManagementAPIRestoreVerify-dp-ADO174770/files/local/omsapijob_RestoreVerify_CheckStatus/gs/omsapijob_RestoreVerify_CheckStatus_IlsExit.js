var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("ILSCTX") || session.createContext("ILSCTX");
		var ctx1 = session.name("omsapijob") || session.createContext("omsapijob");
		var retry = ctx1.getVariable('retry');
		if (ctx1.getVariable('GETCALLSUCCESS')) {
			var incomingpayload = ctx1.getVariable('GETCALLSUCCESS');
			var client = incomingpayload.CallBackData.Client;
			var exitDescriptionU_O = "client is " + client;
		}
		var ErrorTxt = ctx.getVariable('errormessage')
		var exitStatus = ctx.getVariable('exitStatus');
		var outage_urma = ctx1.getVariable('outage_urma');
		var Exitdestination = ctx.getVariable('Exitdestination');
		if (retry != 'yes') {

			if (outage_urma == 'yes') {

				if (exitStatus === undefined || exitStatus === null || exitStatus === '') {
					ctx.setVariable('exitStatus', '');
				} else {
					ctx.setVariable('exitStatus', exitStatus);
				} ctx.setVariable("exitdescription", exitDescriptionU_O);
			} else {
				ctx.setVariable('exitStatus', '0');
				ctx.setVariable("exitdescription", session.parameters.exitdescription);
				ctx.setVariable("Exitdestination", session.parameters.omsapijob_RestoreVerify_CheckStatusBackendMQurl);
			}
		}
		else {
			if (outage_urma == 'yes') {
				ctx.setVariable('exitStatus', '0');
				ctx.setVariable("exitdescription", exitDescriptionU_O);
			} else {
				if (exitStatus === undefined || exitStatus === null || exitStatus === '') {
					ctx.setVariable('exitStatus', '');
				} else {
					ctx.setVariable('exitStatus', exitStatus);
				}
				ctx.setVariable('exitdescription', ErrorTxt)
				//ctx.setVariable("Exitdestination", session.parameters.omsapijob_RestoreVerify_CheckStatusBackendMQurl);
			}
		}

	}
});
