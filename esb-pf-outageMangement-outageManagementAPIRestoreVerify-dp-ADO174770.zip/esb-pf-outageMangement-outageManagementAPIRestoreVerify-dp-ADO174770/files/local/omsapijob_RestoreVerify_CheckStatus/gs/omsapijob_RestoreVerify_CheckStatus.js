var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILSCTX") || session.createContext("ILSCTX");
var clientname = session.parameters.Client;
//ilsctx.setVariable("exitStatus", '500');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {

		if (incomingdata.StatusCheck) {
			var ExternalRefID = incomingdata.StatusCheck.ExternalRefID;
			var jobId = ExternalRefID.split(':').shift();
			var statusId = incomingdata.StatusCheck.statusId;
			var Url = session.parameters.OMSGeturl;
			// GET /api/ServiceType/Electric/Job/{jobId}/RequestStatus/{statusId}  
			var OMSGeturl = Url + '/api/ServiceType/Electric/Job/' + jobId + '/RequestStatus/' + statusId;
			ilsctx.setVariable("Exitdestination", OMSGeturl);
			var apiToken;
			if (incomingdata.StatusCheck.Client == "UrmaApp") {
				apiToken = session.parameters.apiToken_Urma;
			} else if(incomingdata.StatusCheck.Client == "OutageStatusApp"){
				apiToken = session.parameters.OutageApp_Token;
			} else {
				apiToken = session.parameters.osiApiToken;
			}
			headers.remove('MQMD');
			var JobGetapi = {
				target: OMSGeturl,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				headers: {
					'osiApiToken': apiToken,
				},
			};
			var info = " TargetURL :" + OMSGeturl + "; Method :" + 'GET';
			urlopen.open(JobGetapi, function(error, response) {
				if (error) {
					//retry shoud be done
					var ctx = session.name("omsapijob") || session.createContext("omsapijob");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from omsapijob_RestoreVerify_CheckStatus StatusJobGetapi for job id " + jobId + " and statusid" + statusId + " is " + JSON.stringify(error));
					var ErrorTxt = ("omsapijob_006 urlopen connect error from omsapijob_RestoreVerify_CheckStatus StatusJobGetapi for job id " + jobId + " and statusid" + statusId + " is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
					var Errorinfo = info + " urlopen connect error from omsapijob_RestoreVerify_CheckStatus StatusJobGetapi for job id " + jobId + " and statusid" + statusId + " with error as " + JSON.stringify(error);
					ilsctx.setVariable("exitStatus", '500');
					ilsctx.setVariable("errormessage", Errorinfo);
					session.output.write(incomingdata);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								ilsctx.setVariable("exitStatus", responseStatusCode)
								logger.error(" error message while reading response from JobGetapi for job id " + jobId + " and statusid" + statusId + " is " + JSON.stringify(error));
								session.reject(" error message while reading response from omsapijob_RestoreVerify_CheckStatus job id " + jobId + " and statusid" + statusId + " is " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
								var ctx = session.name("omsapijob") || session.createContext("omsapijob");
								var JobGetapiResponse = JSON.parse(responseData);
								//var JobGetapiResponse = {"result":"SUCCESS"} 
								ctx.setVariable("JobGetapiResponse", JobGetapiResponse);
								var result = JobGetapiResponse.result;
								var task_payload =
								{
									"CallBackData": {

										"Client": incomingdata.StatusCheck.Client,
										"ServiceName": incomingdata.StatusCheck.ServiceName
									},
									"UpdateEngerzationStatus": {}
								}
								if (incomingdata.StatusCheck.CallID != undefined) {
									task_payload.CallBackData.CallID = incomingdata.StatusCheck.CallID;
								}
								if (incomingdata.StatusCheck.Number != undefined) {
									task_payload.CallBackData.Number = incomingdata.StatusCheck.Number;
								}
								if (incomingdata.StatusCheck.ExternalRefID != undefined) {
									task_payload.CallBackData.ExternalRefID = incomingdata.StatusCheck.ExternalRefID;
								}
								//New fields added in payload
								if (incomingdata.StatusCheck.messageID != undefined) {
									task_payload.CallBackData.messageID = incomingdata.StatusCheck.messageID;
								}
								if (incomingdata.StatusCheck.FieldTime != undefined) {
									task_payload.CallBackData.FieldTime = incomingdata.StatusCheck.FieldTime;
								}
								//new fields end

								if (result == 'SUCCESS' || result == 'INCONCLUSIVE') {
									//
									var ExternalRefID = incomingdata.StatusCheck.ExternalRefID;
									//var jobId = ExternalRefID.substring(ExternalRefID.indexOf(':') + 1);
									var jobId = ExternalRefID.split(':').shift();
									var Url = session.parameters.OMSGeturl;
									// /api/ServiceType/Electric/Job/{jobId}?includeFields=networkModelID,networkModelType,currentAffected,phases,energizationStatus
									var OMSGeturl = Url + '/api/ServiceType/Electric/Job/' + jobId + '?includeFields=energizationStatus';
									ilsctx.setVariable("Exitdestination", OMSGeturl);
									headers.remove('MQMD');
									var JobGetapi = {
										target: OMSGeturl,
										sslClientProfile: 'OMS_Client_Profile',
										method: 'GET',
										headers: {
											'osiApiToken': apiToken,
										},
									};
									var info = " TargetURL :" + OMSGeturl + "; Method :" + 'GET';
									urlopen.open(JobGetapi, function(error, response) {
										if (error) {
											//retry shoud be done
											var ctx = session.name("omsapijob") || session.createContext("omsapijob");
											ctx.setVariable("retry", 'yes');
											logger.debug(" urlopen connect error from foa_RestoreVerify_CheckStatus JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
											var ErrorTxt = ("omsapijob_007 urlopen connect error from foa_RestoreVerify_CheckStatus JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
											ctx.setVariable("ErrorTxt", ErrorTxt);
											var Errorinfo = info + " urlopen connect error from foa_RestoreVerify_CheckStatus JobGetapi for job id " + jobId + " is " + JSON.stringify(error);
											ilsctx.setVariable("exitStatus", '500');
											ilsctx.setVariable("errormessage", Errorinfo);
											session.output.write(incomingdata);
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														ilsctx.setVariable("exitStatus", responseStatusCode)
														logger.error(" error message while reading response from JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
														session.reject(" error message while reading response from FSECrewGetapifor job id " + jobId + " is " + JSON.stringify(error));
													} else {
														hm.response.statusCode = responseStatusCode;
														hm.response.statusCode = responseStatusCode;
														var JobGetapiResponse = JSON.parse(responseData);
														var ctx = session.name("omsapijob") || session.createContext("omsapijob");
														var energizationStatus = JobGetapiResponse.energizationStatus;
														ctx.setVariable("energizationStatus", energizationStatus);
														if (result == 'SUCCESS') {
															var ctx = session.name("omsapijob") || session.createContext("omsapijob");
															task_payload.UpdateEngerzationStatus.EnergizationStatus = energizationStatus;
															task_payload.UpdateEngerzationStatus.LastRequestStatus = "Request processed successfully";
															ctx.setVariable("GETCALLSUCCESS", task_payload);
															ctx.setVariable("statussuccess", 'yes')
															ilsctx.setVariable("exitStatus", responseStatusCode)
															//start calling queue api
															var Queueurl = session.parameters.omsapijob_RestoreVerify_CheckStatusBackendMQurl;
															var test = PushingToQcall(Queueurl, task_payload);
															session.output.write(task_payload);
															//end calling queue api
														} else if (result == 'INCONCLUSIVE') {
															task_payload.UpdateEngerzationStatus.LastRequestStatus = "Request processing complete, result unknown";
															task_payload.UpdateEngerzationStatus.EnergizationStatus = energizationStatus;
															ctx.setVariable("GETCALLINCONCLUSIVE", task_payload);
															//start calling queue api
															var Queueurl = session.parameters.omsapijob_RestoreVerify_CheckStatusBackendMQurl;
															var test = PushingToQcall(Queueurl, task_payload);
															ilsctx.setVariable("exitStatus", responseStatusCode)
															session.output.write(task_payload);
															//end calling queue api


														}

													}
												});
											} else if (responseStatusCode == 401) {
												//retry shoud be done
												var ctx = session.name("omsapijob") || session.createContext("omsapijob");
												ctx.setVariable("retry", 'yes');
												logger.error("omsapijob_008 authentication/authorization error for foa_RestoreVerify_CheckStatus job id " + jobId + " is " + JSON.stringify(error));
												var ErrorTxt = ("omsapijob_008 authentication/authorization error from from foa_RestoreVerify_CheckStatus JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
												ctx.setVariable("ErrorTxt", ErrorTxt);
												var Errorinfo = info + "omsapijob_008 authentication/authorization error from JobGetapi for foa_RestoreVerify_CheckStatus job id " + jobId + " is " + JSON.stringify(error);
												ilsctx.setVariable("errormessage", Errorinfo);
												ilsctx.setVariable("exitStatus", responseStatusCode)
												//ilsctx.setVariable("exitstatus", '401');
												session.output.write(incomingdata);
											} else {
												ilsctx.setVariable("exitStatus", responseStatusCode)
												logger.error("Error returned while doing GET for foa_RestoreVerify_CheckStatus JobGetapi  for jobid " + jobId + " is " + JSON.stringify(error));
												session.reject("Error returned while doing GET for foa_RestoreVerify_CheckStatus JobGetapi  for jobId " + jobId + " is " + JSON.stringify(error));
											}
										}

									});
									//
								} else if (result == 'FAILURE') {
									task_payload.UpdateEngerzationStatus.EnergizationStatus = incomingdata.StatusCheck.EnergizationStatus;
									var failureReason = JobGetapiResponse.failureReason
									task_payload.UpdateEngerzationStatus.LastRequestStatus = failureReason;
									var ctx = session.name("omsapijob") || session.createContext("omsapijob");
									ctx.setVariable("GETCALLFAILURE", task_payload);
									//start calling queue api
									ilsctx.setVariable("exitStatus", responseStatusCode)
									var Queueurl = session.parameters.omsapijob_RestoreVerify_CheckStatusBackendMQurl;
									var test = PushingToQcall(Queueurl, task_payload);
									session.output.write(task_payload);
									//end calling queue api
								} else if (result == 'PENDING') {
									var jobId;
									if (!(incomingdata.StatusCheck == undefined)) {
										if (!(incomingdata.StatusCheck.ExternalRefID == undefined)) {
											var ExternalRefID = incomingdata.StatusCheck.ExternalRefID;
											//var jobId = ExternalRefID.substring(ExternalRefID.indexOf(':') + 1);
											jobId = ExternalRefID.split(':').shift();
										}
									}

									var ctx = session.name("omsapijob") || session.createContext("omsapijob");
									ctx.setVariable("retry", 'yes');
									ctx.setVariable("pendingValue", 'pending');
									logger.debug(" result from JobGetapi for job id " + jobId + " and statusid " + statusId + " with status as PENDING");
									var ErrorTxt = (" result from JobGetapi for job id " + jobId + " and statusid " + statusId + " with status as PENDING");
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ilsctx.setVariable("exitStatus", responseStatusCode)
									var Errorinfo = " result from JobGetapi for job id " + jobId + " and statusid " + statusId + " with status as PENDING";
									ilsctx.setVariable("errormessage", Errorinfo);
									session.output.write(incomingdata);

								}
							}
						});
					} else if (responseStatusCode == 401) {
						var ctx = session.name("omsapijob") || session.createContext("omsapijob");
						ctx.setVariable("retry", 'yes');
						logger.error("omsapijob_009: authentication/authorization error from JobGetapi for job id " + jobId + " and statusid " + statusId);
						var ErrorTxt = ("omsapijob_009 authentication/authorization error from JobGetapi for job id " + jobId + " and statusid " + statusId);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						var Errorinfo = "omsapijob_009 authentication/authorization error from JobGetapi job id " + jobId + " and statusid " + statusId;
						ilsctx.setVariable("errormessage", Errorinfo);
						ilsctx.setVariable("exitStatus", responseStatusCode)
						//ilsctx.setVariable("exitstatus", '401')
						session.output.write(incomingdata);
					} else {
						// framing failure message start
						var task_payload = {
							"CallBackData": {
								"Client": incomingdata.StatusCheck.Client,
								"ServiceName": incomingdata.StatusCheck.ServiceName
							},
							"UpdateEngerzationStatus": {

							}
						}

						if (incomingdata.StatusCheck.CallID != undefined) {
							task_payload.CallBackData.CallID = incomingdata.StatusCheck.CallID;
						}
						if (incomingdata.StatusCheck.Number != undefined) {
							task_payload.CallBackData.Number = incomingdata.StatusCheck.Number;
						}
						if (incomingdata.StatusCheck.ExternalRefID != undefined) {
							task_payload.CallBackData.ExternalRefID = incomingdata.StatusCheck.ExternalRefID;
						}
						//New fields added in payload
						if (incomingdata.StatusCheck.messageID != undefined) {
							task_payload.CallBackData.messageID = incomingdata.StatusCheck.messageID;
						}
						if (incomingdata.StatusCheck.FieldTime != undefined) {
							task_payload.CallBackData.FieldTime = incomingdata.StatusCheck.FieldTime;
						}
						//new fields end

						if (incomingdata.StatusCheck.EnergizationStatus != undefined) {
							task_payload.UpdateEngerzationStatus.EnergizationStatus = incomingdata.StatusCheck.EnergizationStatus;
						}
						task_payload.UpdateEngerzationStatus.LastRequestStatus = response.reasonPhrase;

						var ctx = session.name("omsapijob") || session.createContext("omsapijob");
						ctx.setVariable("GETCALLFailurepayload", task_payload);
						//start calling queue api
						var Queueurl = session.parameters.omsapijob_RestoreVerify_CheckStatusBackendMQurl;
						var test = PushingToQcall(Queueurl, task_payload);
						ilsctx.setVariable("exitStatus", responseStatusCode)
						session.output.write(task_payload);
						//end calling queue api
						//
					}
				}
			});

		} else if (incomingdata.CallBackData) {
			//start calling queue api
			var Queueurl = session.parameters.omsapijob_RestoreVerify_CheckStatusBackendMQurl;
			var test = PushingToQcall(Queueurl, incomingdata);

			//end calling queue api
			session.output.write(incomingdata);
		}
	}
});
function PushingToQcall(url, Data) {
	var ctx = session.name("omsapijob") || session.createContext("omsapijob");
	var clientname = session.parameters.Client;
	var StandaloneMQurl = url;
	var payload = Data;
	ctx.setVariable("outage_urma", 'yes');
	var clientList = clientname.split(",").map(client => client.trim());
	if (!clientList.includes(Data.CallBackData.Client)) {
		ctx.setVariable("outage_urma", 'no')
		//ilsctx.setVariable("exitStatus", '400');

		var PushingToQueue = {
			target: StandaloneMQurl,
			data: payload
		};
		try {
			var info = " TargetURL :" + StandaloneMQurl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
			urlopen.open(PushingToQueue, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var ctx = session.name("foa") || session.createContext("foa");
					var ctx = session.name("omsapijob") || session.createContext("omsapijob");
					ctx.setVariable("retry", 'yes');
					logger.debug(" error foa_RestoreVerify_CheckStatus while keeping message to queue " + StandaloneMQurl + " is " + error);
					var ErrorTxt = ("omsapijob_010 error foa_RestoreVerify_CheckStatus while keeping message to queue " + StandaloneMQurl + " is " + error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
					var Errorinfo = " error foa_RestoreVerify_CheckStatus while keeping message to queue details are " + info + " with error " + error;
					ilsctx.setVariable("errormessage", Errorinfo);
					ilsctx.setVariable("exitStatus", '500');
					session.output.write(payload);
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								hm.response.statusCode = 500;
								var ctx = session.name("omsapijob") || session.createContext("omsapijob");
								ctx.setVariable("retry", 'yes');
								logger.debug("response code for foa_RestoreVerify_CheckStatus " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
								var ErrorTxt = (" omsapijob_010 response code for foa_RestoreVerify_CheckStatus " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
								ctx.setVariable("ErrorTxt", ErrorTxt);
								var Errorinfo = "response code for foa_RestoreVerify_CheckStatus details are " + info + " urlopen.open error [MQRC=" + mqrc + "]";
								ilsctx.setVariable("errormessage", Errorinfo);
								ilsctx.setVariable("exitStatus", mqrc)
								session.output.write(payload);
								//session.reject("omsapijob_010 error foa_RestoreVerify_CheckStatus while keeping message to queue is "+error);
							} else {
								ilsctx.setVariable('exitStatus', "0");
								logger.debug("MQResponsecode " + mqrc);
							}
						});
					} else {
						var ctx = session.name("omsapijob") || session.createContext("omsapijob");
						//	var mqconnection = 'Forbidden';
						//	ctx.setVariable("mqconnection", mqconnection);
						//  logger.error("   response code for foa_RestoreVerify_CheckStatus "+StandaloneMQurl+" urlopen.open error [MQRC=" + mqrc + "]");
						//  session.reject (" response code for "+StandaloneMQurl+" urlopen.open error [MQRC=" + mqrc + "]");              

						var ctx = session.name("omsapijob") || session.createContext("omsapijob");
						ctx.setVariable("retry", 'yes');
						logger.debug("response code for foa_RestoreVerify_CheckStatus " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
						var ErrorTxt = (" omsapijob_010 response code for foa_RestoreVerify_CheckStatus " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
						ctx.setVariable("ErrorTxt", ErrorTxt);
						var Errorinfo = "response code for foa_RestoreVerify_CheckStatus details are " + info + " urlopen.open error [MQRC=" + mqrc + "]";
						ilsctx.setVariable("exitStatus", mqrc)
						ilsctx.setVariable("errormessage", Errorinfo);
						session.output.write(payload);
					}
				}
			});
		} catch (err) {
			var Errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + err;
			ctx.setVariable("retry", 'yes');
			ilsctx.setVariable("exitStatus", '500');
			ilsctx.setVariable("errormessage", Errorinfo);
		}
	}
}
