<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

<xsl:variable name="TransactionID">
	<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
			
</xsl:variable>


<xsl:choose>	
<xsl:when test="contains(dp:variable('var://service/error-protocol-response'),'400' ) or contains(dp:variable('var://service/error-code'),'0x00030001') or contains(dp:variable('var://context/omsapijob_RestoreVerify/Bollencheck'),'failed') or contains(dp:variable('var://context/omsapijob_RestoreVerify/schemafailed'),'yes') or contains(dp:variable('var://service/error-code'),'0x0213000e') or contains(dp:variable('var://service/error-code'),'0x00c30025') or contains(dp:variable('var://service/error-code'),'0x0213000a')">
<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Request'" />
<xsl:message dp:type="all" dp:priority="error"> <xsl:value-of select="dp:variable('var://service/error-message')"/> in service foa_Gateway with error code <xsl:value-of select="dp:variable('var://service/error-code')"/></xsl:message>
</xsl:when>

<xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
<xsl:message dp:type="all" dp:priority="error">TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>
<dp:set-variable name="'var://service/error-protocol-response'" value="'401'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'" />
</xsl:when>

<xsl:when test="contains(dp:variable('var://service/error-code'),'0x01130006') or contains(dp:variable('var://context/omsapijob_RestoreVerify/mqconnection'),'Forbidden') ">
<xsl:message dp:type="all" dp:priority="error"> TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>

<dp:set-variable name="'var://service/error-protocol-response'" value="'503'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Gateway'" />
</xsl:when>




<xsl:when test="contains(dp:variable('var://service/error-message'),'Invalid array syntax') or contains(dp:variable('var://service/error-message'),'Invalid JSON format')" >
<xsl:message dp:type="all" dp:priority="error"> TransactionID:<xsl:value-of select="$TransactionID"/> in service foa_Gateway <xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>

<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
</xsl:when>
<xsl:otherwise>

<xsl:message dp:type="all" dp:priority="error">TransactionID:<xsl:value-of select="$TransactionID"/> ErrorCode:<xsl:value-of select="dp:variable('var://service/error-headers')"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/></xsl:message>
<dp:set-variable name="'var://service/error-protocol-response'" value="'500'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Interval Server Error (General Error)'" />

</xsl:otherwise>
</xsl:choose>		
	</xsl:template>
</xsl:stylesheet>
