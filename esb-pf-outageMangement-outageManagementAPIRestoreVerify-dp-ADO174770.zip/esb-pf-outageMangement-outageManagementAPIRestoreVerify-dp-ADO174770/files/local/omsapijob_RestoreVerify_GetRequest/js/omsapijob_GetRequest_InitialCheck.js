//js is used to perform nullcheck for the input request
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var nullCheckRequired = session.parameters.RestoreVerify_NullCheck;
	if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
	var ctx = session.name("omsapijob_RestoreVerify")|| session.createContext("omsapijob_RestoreVerify");
		if(nullCheckRequired == 'REQUIRED'){
			if(incomingdata.CallBackData != '' || incomingdata.CallBackData != undefined || incomingdata.RestoreVerify != null){
			var ExternalRefID = incomingdata.CallBackData.ExternalRefID;
			if (ExternalRefID === null || ExternalRefID === '' || ExternalRefID === undefined) {
				logger.debug('ExternalRefID is not present in input  payload');
				ctx.setVariable("schemafailed", 'yes')
				var schemafailedMessage = 'ExternalRefID is not present in input  payload'
			//	ctx.setVariable("schemafailedMessage", 'ExternalRefID is not present in input  payload')
				//  var test = FSENegativeResponse(schemafailedMessage, incomingdata);
	           session.reject('ExternalRefID is not present in input  payload');
	        }		
				}
			if(incomingdata.RestoreVerify != '' || incomingdata.RestoreVerify != undefined || incomingdata.RestoreVerify != null){
				var OUGFieldTime = incomingdata.RestoreVerify.FieldTime;			
			if (OUGFieldTime === null || OUGFieldTime === '' || OUGFieldTime === undefined) {
				logger.debug('OUGFieldTime is not present in input payload');
				ctx.setVariable("schemafailed", 'yes')
				var schemafailedMessage = 'FieldTime is not present in input  payload';
				//  var test = FSENegativeResponse(schemafailedMessage, incomingdata);
				ctx.setVariable("schemafailedMessage", 'FieldTime is not present in input  payload')
				session.reject('FieldTime is not present in input payload');
	        }
			var OUGVerify = incomingdata.RestoreVerify.Verify;
			if (OUGVerify === null || OUGVerify === '' || OUGVerify === undefined) {
	           logger.debug('OUGVerify is not present in input payload');
				ctx.setVariable("schemafailed", 'yes')
				var schemafailedMessage = 'Verify is not present in input  payload';
				  // var test = FSENegativeResponse(schemafailedMessage, incomingdata);
				//ctx.setVariable("schemafailedMessage", 'Verify is not present in input  payload')
				session.reject('Verify is not present in input payload');
	        }	
			var OUGRestore = incomingdata.RestoreVerify.Restore;
			if (OUGRestore === null || OUGRestore === '' || OUGRestore === undefined) {
		           logger.debug('OUGRestore is not present in input payload');
					ctx.setVariable("schemafailed", 'yes')
				  var schemafailedMessage = 'Restore is not present in input  payload';
				// var test = FSENegativeResponse(schemafailedMessage, incomingdata);
				//	ctx.setVariable("schemafailedMessage", 'Restore is not present in input  payload')
				session.reject('Restore is not present in input payload');
		        }	
				}	
}
//if(incomingdata.RestoreVerify == undefined || incomingdata.RestoreVerify =='' || incomingdata.RestoreVerify == null){
//		logger.debug('Verify and Restore both are not present in input payload ');
//		ctx.setVariable("schemafailed", 'yes')
//		  var schemafailedMessage = 'Verify and Restore both are not present in input payload';
//		//  var test = FSENegativeResponse(schemafailedMessage, incomingdata);
//}else{	
//	
//var OUGVerify = incomingdata.RestoreVerify.Verify;
//var OUGRestore = incomingdata.RestoreVerify.Restore;
//if((OUGVerify == true && OUGRestore == true) || (OUGVerify == false && OUGRestore == false) ){
//	 logger.debug('Verify and Restore both are '+OUGVerify);
//	ctx.setVariable("schemafailed", 'yes')
//	  var schemafailedMessage = 'Verify and Restore both are  present in input payload as '+OUGRestore;
//	//	  var test = FSENegativeResponse(schemafailedMessage, incomingdata);
//	ctx.setVariable("schemafailedMessage", schemafailedMessage)
//}
//
//}
		}		
	});
//function FSENegativeResponse(schemafailedMessage,incomingdata){
//			var payload = {
//					"CallBackData": {
//										"Client": "FSE",
//										"ServiceName": "RestoreVerify"
//									},
//									"ErrorMessage": schemafailedMessage
//				}
//if(incomingdata.CallBackData.CallID != undefined){
//payload.CallBackData.CallID = incomingdata.CallBackData.CallID
//}
//if(incomingdata.CallBackData.Number != undefined ){
//payload.CallBackData.Number = incomingdata.CallBackData.Number
//}
//if(incomingdata.CallBackData.ExternalRefID != undefined ){
//payload.CallBackData.ExternalRefID = incomingdata.CallBackData.ExternalRefID
//}
//			var InitialFailure_URL = session.parameters.InitialFailure_FSEURL
//			var InitialFailure = {
//			target: InitialFailure_URL,
//		    method: 'POST',
//			contentType: 'application/json',
//				data: payload
//							};
//						urlopen.open(InitialFailure, function(error, response) {
//					if (error) {
//					var ctx = session.name("omsapijob_RestoreVerify")|| session.createContext("omsapijob_RestoreVerify");
//					ctx.setVariable("retry", 'yes');
//					logger.debug(" urlopen connect error with omsapijob_RestoreVerify_GetRequest to ffs_SendResponse post is " + JSON.stringify(error));
//					var ErrorTxt = "urlopen connect error with omsapijob_RestoreVerify_GetRequest to ffs_SendResponse post is " + JSON.stringify(error);
//					ctx.setVariable("ErrorTxt", ErrorTxt);
//				} else {
//					var responseStatusCode = response.statusCode;
//					if (responseStatusCode == 200)  {
//						response.readAsBuffer(function(error, responseData) {
//							if (error) {
//								logger.error(" error message while reading from omsapijob_RestoreVerify_GetRequest to ffs_SendResponse post call " +JSON.stringify(error));
//								session.reject("error message while reading from omsapijob_RestoreVerify_GetRequest to ffs_SendResponse post call " +JSON.stringify(error));
//							} else {
//								hm.response.statusCode = responseStatusCode;
//								logger.debug("response code recieved from call omsapijob_RestoreVerify_GetRequest to ffs_SendResponse is "+responseStatusCode);
//								}
//						});
//					}else{
//						
//						
//	response.readAsBuffer(function(error, responseData) {
//				if (error) {
//			logger.error("failure in reading message from post omsapijob_RestoreVerify_GetRequest to ffs_SendResponse " + JSON.stringify(error));
//					session.reject("failure in reading message from post omsapijob_RestoreVerify_GetRequest to ffs_SendResponse  " + JSON.stringify(error));
//		} else {
//				logger.error("Error code returned from post omsapijob_RestoreVerify_GetRequest to ffs_SendResponse statusCode " + responseStatusCode+" "+ responseData);
//			session.reject("Error code returned from post omsapijob_RestoreVerify_GetRequest to ffs_SendResponse  statusCode " + responseStatusCode+" "+ responseData);
//		}
//		});
//					}
//					}
//					});
//
//}
