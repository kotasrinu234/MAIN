//js is used to push message to standalone queue 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	var ctx = session.name("omsapijob") || session.createContext("omsapijob");
	var Ilsctx = session.name("ILS") || session.createContext("ILS");
	var omsapijob_RestoreVerifySucess_MQURL = session.parameters.RestoreVerifyMQURL;
	var StandaloneMQurl = omsapijob_RestoreVerifySucess_MQURL;

	var PusingToQueue = {
		target: StandaloneMQurl,
		data: incomingdata
	};
	var info = " TargetURL :" + StandaloneMQurl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(incomingdata) + ". ";
	try {
		urlopen.open(PusingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var ctx = session.name("omsapijob") || session.createContext("omsapijob");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(" omsapijob_001 error while keeping RestoreVerify omsapijob_RestoreVerify_GetRequest message to queue is " + error);
				var errorinfo = "error while keeping RestoreVerify omsapijob_RestoreVerify_GetRequest message to queue , details are : " + info + "; error info :" + "Error returned mq call " + error
				Ilsctx.setVariable("errormessage", errorinfo);
				session.reject(" error while keeping omsapijob_RestoreVerify_GetRequest message to queue is " + error);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							var errorinfo = "error while keeping message  RestoreVerify omsapijob_RestoreVerify_GetRequest to queue , details are : " + info + "; error info :" + "Error returned mq call " + readError
							Ilsctx.setVariable("errormessage", errorinfo);
							session.reject("omsapijob_001 error while keeping message  RestoreVerify omsapijob_RestoreVerify_GetRequest to queue is " + error);
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var ctx = session.name("omsapijob") || session.createContext("omsapijob");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(" omsapijob_001 response code RestoreVerify omsapijob_RestoreVerify_GetRequest urlopen.open error [MQRC=" + mqrc + "]");
					var errorinfo = "error while keeping message  RestoreVerify omsapijob_RestoreVerify_GetRequest to queue , details are : " + info + "; error info :" + "Error returned mq call " + mqrc
					Ilsctx.setVariable("errormessage", errorinfo);
					session.reject(" response code omsapijob_RestoreVerify_GetRequest is urlopen.open error [MQRC=" + mqrc + "]");

				}
			}
		});
	} catch (err) {
		var errorinfo = "error while keeping message  RestoreVerify omsapijob_RestoreVerify_GetRequest to queue , details are : " + info + "; error info :" + "Error returned mq call " + err;
		Ilsctx.setVariable("errormessage", errorinfo);
		session.reject('** Mqurlopen.open error [MQRC=' + err + ']');
	}
});
