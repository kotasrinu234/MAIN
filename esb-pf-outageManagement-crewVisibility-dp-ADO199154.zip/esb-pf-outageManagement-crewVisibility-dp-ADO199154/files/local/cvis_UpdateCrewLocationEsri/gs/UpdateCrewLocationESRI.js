var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name('ILS') || session.createContext('ILS');
var ctx1 = session.name("test") || session.createContext("test");
var headers = hm.current;
headers.set('Content-Type', 'application/vnd+dteenergy.com.telemetry+json; version=1.0');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data";
		logger.error("Error in reading incoming data");
		ilsctx.setVariable('exitStatus', "500");
		ilsctx.setVariable('ExitDescription', errorinfo);
		session.reject(readAsJSONError);
	}
	else {
		var ESRIUrl = session.parameters.ESRIUrl;
		ilsctx.setVariable('exitDestination', ESRIUrl);
		if ((ESRIUrl == undefined) || (ESRIUrl == '') || (ESRIUrl == null)) {
			logger.error("ESRIUrl is missing" + JSON.stringify(readAsJSONError))
			session.reject("ESRIUrl is missing")
		} else {

			//var refreshdate = responseData.RefreshDate;
			//                                          var CustomField = {
			//                                                    //For EST to UTC conversion
			//                                                    // 'Custom Field': new Date(responseData.RefreshDate).toISOString()
			//                                                    //'Custom Field': new Date(responseData.RefreshDate)   
			//                                                    
			//                                                };


			var payload = {
				"FleetTelemetry": {
					"correlationID": ctx1.getVariable("guuid"),
					"contractCompany": "FSE",
					"VehicleTelemetryEntries": [
						{
							"VehicleID": incomingdata.customFieldValuesExt.CrewID,
							"TimeStamp": incomingdata.customFieldValuesExt.RefreshDate,
							"Track": {
								"heading": JSON.parse(incomingdata.customFieldValuesExt.heading),
								"groundSpeed": JSON.parse(incomingdata.customFieldValuesExt.speed),
							},
							"GeographicCoordinate": {
								"latitude": incomingdata.location.coordinates[1],
								"longitude": incomingdata.location.coordinates[0]
							}
						}
					]
				}


			};

			logger.debug("payload sent to OMS" + JSON.stringify(payload));
			var UpdateCrewLocation = {
				target: ESRIUrl,
				//sslClientProfile: 'cvis_UpdateCrewLocation_OMSClientProfile',
				method: 'POST',
				contentType: 'application/vnd+dteenergy.com.telemetry+json; version=1.0',
				data: payload
			};
			session.output.write(payload)
			//calling OMS inorder to Update the crew location details
			var info = " TargetURL: " + UpdateCrewLocation.target + "; Method: " + UpdateCrewLocation.method + "; Data: " + JSON.stringify(UpdateCrewLocation.data) + ". ";
			urlopen.open(UpdateCrewLocation, function(error, response) {
				if (error) {
					var errorinfo = "cvis_011 urlopen connect error with 'UpdateCrewLocation' details are: " + info + "; error info: " + error;
					// an error occurred during request sending or response header parsing
					logger.error("cvis_011 urlopen connect error while connecting to ESRI to UpdateCrewLocation" + JSON.stringify(error));
					ilsctx.setVariable('exitStatus', "500");
					ilsctx.setVariable('ExitDescription', errorinfo);
					session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						logger.debug("response received from UpdateCrewLocation ESRI call:");
						ilsctx.setVariable('exitStatus', "0");
					} else if (responseStatusCode == 201) {
						logger.debug("response received from UpdateCrewLocation ESRI call:");
						ilsctx.setVariable('exitStatus', "0");
					} else {

						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message from UpdateCrewLocation ESRI call  details are: " + info + "; error info: " + error;
								//dp:reject stop the transaction and go error rule with error code and description
								logger.error("failure in reading message from UpdateCrewLocation ESRI call ");
								ilsctx.setVariable('exitStatus', "500");
								ilsctx.setVariable('ExitDescription', errorinfo);
								session.reject(errorinfo);
							} else {
								
								hm.current.statusCode = responseStatusCode;
								var errorinfo = "cvis_012 Error returned from UpdateCrewLocation ESRI call  details are: " + info + "; error info: " + responseStatusCode + responseData;
								logger.error("cvis_012 Error returned from UpdateCrewLocation ESRI call" + " : with statusCode " + responseStatusCode + " " + responseData);
								ilsctx.setVariable('exitStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
							}
						})
					}
				}
			});
		}
	}
});
