var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name('ILS') || session.createContext('ILS');
var EntryDescription = session.parameters.UpdatecrewlocEntryDescription;
var ExitDescription = session.parameters.UpdatecrewlocExitDescription;
var messageType = session.parameters.messageType;

if (messageType != undefined && messageType != null && messageType != '') {
	ilsctx.setVariable("messageType", messageType);
}
if (EntryDescription != undefined && EntryDescription != null && EntryDescription != '') {
	ilsctx.setVariable('EntryDescription', EntryDescription);
}
if (ExitDescription != undefined && ExitDescription != null && ExitDescription != '') {
	ilsctx.setVariable('ExitDescription', ExitDescription);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
			if (incomingdata.messageId != undefined && incomingdata.messageId != null && incomingdata.messageId != '') {
				ilsctx.setVariable("correlationID", incomingdata.messageId)
			}
		if (incomingdata.customFieldValuesExt.CrewID != undefined && incomingdata.customFieldValuesExt.CrewID != null && incomingdata.customFieldValuesExt.CrewID != '') {
				ilsctx.setVariable("crewDisplayID", incomingdata.customFieldValuesExt.CrewID)
			}
		ilsctx.setVariable("sourceEventTimestamp", new Date().toISOString())
	}
});
