<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:dp="http://www.datapower.com/extensions"
xmlns:date="http://exslt.org/dates-and-times"
xmlns:dyn="http://exslt.org/dynamic"
xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
xmlns:dpconfig="http://www.datapower.com/param/config"



extension-element-prefixes="dp date" exclude-result-prefixes="dp date">

				
<xsl:output method="xml" />
    <xsl:template match="/">
<xsl:variable name="uniqueID" select="dp:generate-uuid()"/>
<xsl:element name="{name()}" namespace="{namespace-uri()}">
			<xsl:value-of select="$uniqueID"/>
		</xsl:element>
		            <xsl:message dp:type="all" dp:priority="error">
               <xsl:value-of select="$uniqueID" />
            </xsl:message>
<dp:set-http-request-header name="'UUID'" value="$uniqueID"/>
<dp:set-variable name="'var://context/test/guuid'" value="$uniqueID" />
</xsl:template>
</xsl:stylesheet>