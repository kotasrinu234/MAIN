var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

/*var labelMap = new Map([
['SUB','DTEEnergyD5'],
['OH','DTEEnergyD6'],
['UG','DTEEnergyD6'],
['EFO','DTEEnergyD5']
])*/
var EFOEmpArray = [];
//var loginArray = [];
//var loginArray1 = [];
var loginUser;
var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
var omsres = ctx.getVariable('omsresponse');
//var omsres = [];
var ilsctx = session.name("ILS") || session.createContext("ILS");

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var FSEUrl = session.parameters.EFOUrl;
		var EAuth = "Basic " + session.parameters.EFSEToken;
		//Required check for FSM URL
		if ((FSEUrl == undefined) || (FSEUrl == '') || (FSEUrl == null)) {
			logger.error("cvis_011 FSEUrl is missing" + JSON.stringify(error))
			session.reject("FSEUrl is missing")
		} else {
			//var ODMConfig = session.name('GetConfig');
			//var ODMOutput = ODMConfig.getVariable('ODMOutput');
			var numEngineersToRequest = session.parameters.numEngineersToRequest;
			var EFOArray = []
			var TestArray = []

			var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
			var crewTypeArray = ctx.getVariable("array");
			var resArray = ctx.getVariable("resArray");

			for (var i = 0; i < resArray.length; i++) {
				var Type = resArray[i].type
				TestArray.push(Type)
			}


			for (var b = 0; b < resArray.length; b++) {
				for (var a = 0; a < crewTypeArray.length; a++) {
					if (resArray[b].type == crewTypeArray[a].type) {

						var newLabel = crewTypeArray[a].label;
						//var crewType = labelMap.get(newLabel);
						var employeeId = resArray[b].customFieldValuesExt.employeeid;
						if (newLabel == 'EFO') {
							if (employeeId != null || employeeId != undefined) {
								loginUser = employeeId + '@' + session.parameters.EFO_USER;
								EFOArray.push(loginUser)
								var obj1 = {
									'label': newLabel,
									'empid': resArray[b].customFieldValuesExt.employeeid,
									'externalID': resArray[b].externalID
								};

								EFOEmpArray.push(obj1);
								ctx.setVariable("EFOEmpArray", EFOEmpArray)
							}
							else {
								logger.debug("employeeId is not present for this crew");
							}
						}



					}

				}
			}
			var index = EFOArray.indexOf(null);

			if (index > -1) {
				EFOArray.splice(index, 1);
			}
			ctx.setVariable("EFOArray", EFOArray);
			//	ctx.setVariable("loginArray1", loginArray1);
			var results = [];
			var EfoArrayindex = EFOArray.length;
			ctx.setVariable("EfoArrayindex", EfoArrayindex)
			//ctx.setVariable("D6Array", D6Array)
			//Start of splitting array
			function chunkArray(eidArray, chunk_size, results) {

				while (eidArray.length) {
					results.push(eidArray.splice(0, chunk_size));
				}

				return results;
			}
			ctx.setVariable("results", results);

			var EFOChunks = []

			var EFOresult = chunkArray(EFOArray, numEngineersToRequest, EFOChunks);

			//splitting array
			function makeRequest(FSECall) {
				return new Promise(function(resolve, reject) {
					var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";
					urlopen.open(FSECall, function(error, response) {
						if (error) {
							var errorinfo = "urlopen connect error while connecting to 'FSECall', details are : " + info + "; error info :" + error
							ilsctx.setVariable('exitdescription', errorinfo);
							ilsctx.setVariable('exitStatus', '500');
							logger.error(errorinfo);
							reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "Failure in getting response of 'FSECall', details are : " + info + "; error info :" + error
										ilsctx.setVariable('exitdescription', errorinfo);
										ilsctx.setVariable('exitStatus', responseStatusCode);
										logger.error(errorinfo);
										reject(errorinfo);
									} else {
										if (responseData.IsSuccess == true) {
											ctx.setVariable("response", responseData.ErrorMessage);
											var Data = JSON.parse(responseData.ErrorMessage);
											//jsonString = jsonString.replaceAll('\"', '"');
											ctx.setVariable("testing", Data);
											for (var j = 0; j < Data.DynamicData.length; j++) {
												var userName = Data.DynamicData[j].userName;
												//ctx.setVariable("user", userName);
												var resultObject = search(userName, EFOEmpArray);
												ilsctx.setVariable('exitdescription', session.parameters.EFODescription);
												ilsctx.setVariable('exitdestination', FSEUrl);
												ilsctx.setVariable('exitStatus', '0')
												var ms = require('multistep');
												ms.callRule('cvis_UpdateCrewLocation_policy_ILS_StepExit', null, null, function(error) {
													if (error) {
														logger.error("Error in cvis_UpdateCrewLocation_policy_ILS_StepExit	");
													}
												});
												var OMSUrl = session.parameters.OMSUrl + '/api/v1/ServiceType/Electric/Crew/' + resultObject.externalID;

												//ctx.setVariable("omsurl", OMSUrl);
												var v1 = Data.DynamicData[j].longitude;
												var v2 = Data.DynamicData[j].latitude;
												var coodinates = {
													'coordinates': [v1, v2],
													"type": "POINT"
												};
												let unixTimestamp = Data.RefreshDate;
												var ms = unixTimestamp;
												var dateObj = new Date(ms);
												var finalDate = dateObj.toISOString();

												ctx.setVariable("asdf", ms);
												ctx.setVariable("test", dateObj);
												ctx.setVariable("time", finalDate);
												var payload = {
													'location': coodinates,
													'customFieldValues': {
														'speed': JSON.stringify(Data.DynamicData[j].speed),
														'heading': JSON.stringify(Data.DynamicData[j].heading),
														'accuracy': JSON.stringify(Data.DynamicData[j].accuracy),
														'altitude': JSON.stringify(Data.DynamicData[j].altitude),
														'RefreshDate': finalDate
													}
												};
												var TokenValue = session.parameters.TokenValue;
												var UpdateCrewLocation = {
													target: OMSUrl,
													sslClientProfile: 'cvis_UpdateCrewLocation_OMSClientProfile',
													method: 'PATCH',
													contentType: 'application/json',
													headers: {
														'osiApiToken': TokenValue
													},
													data: payload
												};

												var info = " TargetURL :" + UpdateCrewLocation.target + "; Method :" + UpdateCrewLocation.method + "; Data :" + JSON.stringify(UpdateCrewLocation.data) + ". ";
												
													urlopen.open(UpdateCrewLocation, function(error, response) {
														if (error) {
															// an error occurred during request sending or response header parsing
															var errorinfo = "cvis_008 urlopen connect error while connecting to OMS to UpdateCrewLocation, details are : " + info + "; error info :" + error
															ilsctx.setVariable('ExitDescription', errorinfo);
															ilsctx.setVariable('ExitStatus', '500');
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															// read response data
															// get the response status code
															var responseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																response.readAsJSON(function(error, responseData) {
																	if (error) {
																		// error while reading response or transferring data to Buffer
																		var errorinfo = "failure in getting response message from omsapi UpdateCrewLocation, details are : " + info + "; error info :" + error
																		ilsctx.setVariable('exitdescription', errorinfo);
																		ilsctx.setVariable('exitStatus', responseStatusCode);
																		logger.error(errorinfo);
																	} else {
																		ilsctx.setVariable('exitStatus', '0');
																		omsres.push(responseData);
																		ctx.setVariable("omsresponse", omsres);
																		logger.debug("response received from UpdateCrewLocation OMS call:" + JSON.stringify(responseData));
																		var targetQueue = session.parameters.Queue;
																		var messageId = ilsctx.getVariable('correlationID')
																		var payload = responseData
																		payload.messageId = messageId
																		var options = {
																			target: targetQueue,
																			data: payload
																		};
																		var options = {
																			target: targetQueue,
																			data: responseData
																		};
																		var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";

																		try {
																			urlopen.open(options, function(error, response) {
																				var hm = require('header-metadata');
																				if (error) {
																					hm.response.statusCode = 500;
																					var errorinfo = "cvis_009 Mq urlopen error, details are : " + info + "; error info :" + error
																					ilsctx.setVariable('exitdescription', errorinfo);
																					ilsctx.setVariable('exitStatus', '500');
																					logger.error(errorinfo);
																					session.reject(errorinfo);
																				} else {
																					var mqrc = response.statusCode;
																					if (mqrc == 0) {
																						response.readAsBuffer(function(readError, responseData) {
																							if (readError) {
																								hm.response.statusCode = 500
																								ilsctx.setVariable('exitStatus', mqrc);
																							} else {
																								ilsctx.setVariable('exitStatus', '0');
																								console.log("MQResponseData " + responseData);
																							}
																						});
																					} else {
																						hm.response.statusCode = 500
																						var errorinfo = "Mqurlopen.open error [MQRC=" + mqrc + "]" + info + "; error info :" + error
																						ilsctx.setVariable('exitdescription', errorinfo);
																						ilsctx.setVariable('exitStatus', mqrc);
																						logger.error(errorinfo);
																						session.reject(errorinfo);

																					}
																				}
																			})
																		} catch (error) {
																			hm.response.statusCode = 500;
																			var errorinfo = "cvis_009 Mq urlopen error, details are : " + info + "; error info :" + error
																			ilsctx.setVariable('exitdescription', errorinfo);
																			ilsctx.setVariable('exitStatus', '500');
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}

																	}
																})
															}
															else {

																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		//dp:reject stop the transaction and go error rule with error code and description
																		var errorinfo = "failure in reading message from UpdateCrewLocation OMS call, details are : " + info + "; error info :" + error
																		ilsctx.setVariable('exitdescription', errorinfo);
																		ilsctx.setVariable('exitStatus', responseStatusCode);
																		logger.error(errorinfo);
																		session.reject(errorinfo);

																	} else {

																		hm.current.statusCode = responseStatusCode;
																		var responseinfo = "cvis_010 Error returned from UpdateCrewLocation OMS call : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		logger.error(responseinfo);

																	}
																})
															}
														}
													})
											}
										}
										else if (responseData.IsSuccess == false) {
											logger.error("cvis_007 \"IsSucess\" is false coming from FSE")
											//session.reject(" \"IsSuccess\" is false coming from FSE");

										}

										resolve(responseData);
									}

								});

							} else {
								response.readAsBuffer(function(error, responseData) {

									if (error) {
										var errorinfo = "Failure in reading response of 'FSECall', details are : " + info + "; error info :" + error
										ilsctx.setVariable('exitdescription', errorinfo);
										ilsctx.setVariable('exitStatus', responseStatusCode);
										logger.error(errorinfo);
										reject(errorinfo);
									} else {
										var errorinfo = "Error returned from 'FSECall', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ilsctx.setVariable('exitdescription', errorinfo);
										ilsctx.setVariable('exitStatus', responseStatusCode);
										logger.error(errorinfo);
										reject(errorinfo);

									}

								});

							}

						}

					});

				});

			}

			async function main() {
				for (var i = 0; i < EFOresult.length; i++) {
					var Data = EFOresult[i]
					var FSECall = {
						target: FSEUrl,
						sslClientProfile: 'FSE_Client_Profile',
						method: 'post',
						contentType: 'application/json',
						headers: {
							'Authorization': EAuth,
						},
						data: {
							"loginUser": Data,
							"fromTime": 0
						}
					};
					try {
						var responseData = await makeRequest(FSECall);
						hm.response.statusCode = '200 OK';
						logger.debug("response received :" + JSON.stringify(responseData));
					} catch (error) {
						hm.current.statusCode = responseStatusCode;
						logger.error(error);
						session.reject(error);
					}
				}
			}
			main();
		}
		/*End Of Crew Location Call*/
	}
})
var ms = require('multistep');
var locationData = omsres;
function callMultiStepAtLocationIndex(index) {
	if (locationData.length === 0) {
		var noupdate = session.parameters.NoUpdate
		ilsctx.setVariable('exitStatus', '')
		ilsctx.setVariable('exitdescription', noupdate);
var payload = {}
		session.output.write(payload)
		return;
	}
	if (index < locationData.length - 1) {
		var currentLocation = locationData[index].customFieldValuesExt.CrewID;
		ilsctx.setVariable('crewid', currentLocation)
		ilsctx.setVariable('exitdescription', session.parameters.UpdateDescription);
		ilsctx.setVariable('exitdestination', session.parameters.Queue);
		ilsctx.setVariable('exitStatus', "0");
		ms.callRule('cvis_UpdateCrewLocation_policy_ILS_StepExit', null, null, function(error) {
			if (error) {
				console.error("Error processing location: ", + error);
			}
			callMultiStepAtLocationIndex(index + 1);
		});
	} else {
		var lastLocation = locationData[locationData.length - 1];
		var lastloacation = lastLocation.customFieldValuesExt.CrewID
		if (lastloacation != undefined) {
			ilsctx.setVariable('lastid', lastloacation)
			ilsctx.setVariable('exitdescription', session.parameters.ExitDescription);
		ilsctx.setVariable('exitStatus', "0");
		ilsctx.setVariable('exitdestination', session.parameters.Queue);
		payload = lastLocation
			session.output.write(payload)
		}
		
	}
}
callMultiStepAtLocationIndex(0);
function search(nameKey, myArray) {
	for (var i = 0; i < myArray.length; i++) {
		var EmpID = myArray[i].empid
		var DupEmpID = EmpID + "a"
		var DupnameKey = nameKey + "a"
		if (DupEmpID.toUpperCase() === DupnameKey.toUpperCase()) {
			return myArray[i];
		}
	}
}
