var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
    'category': 'all'
});


var loginArray = [];
var loginArray1 = [];
var loginUser;
var omsres= [];




        var FSEUrl = 'local:///cvis_UpdateCrewLocation/gs/test.json';
		var Auth = "Basic "+session.parameters.FSEToken;
        //Required check for FSM URL
        if ((FSEUrl == undefined) || (FSEUrl == '') || (FSEUrl == null)) {
            logger.error("FSEUrl is missing" + JSON.stringify(error))
            session.reject("FSEUrl is missing")
        } else {
            //var ODMConfig = session.name('GetConfig');
            //var ODMOutput = ODMConfig.getVariable('ODMOutput');
            var numEngineersToRequest = session.parameters.numEngineersToRequest;
			
			var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
			var loginArray1 = ctx.getVariable("loginArray1");
            //splitting array

                var FSECall = {
                    target: FSEUrl,
                    method: 'GET',
                    contentType: 'application/json',

                };


                urlopen.open(FSECall, function(error, response) {
                    if (error) {
						// an error occurred during request sending or response header parsing
                        logger.error("cvis_003 urlopen connect error while doing FSECall" + JSON.stringify(error));
                        session.reject("urlopen connect error while doing FSECall");
                    } else {
                        // read response data
                        // get the response status code
                        var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    // error while reading response or transferring data to Buffer
                                    logger.error("cvis_011 failure in reading message from FSECall" + JSON.stringify(error));
                                } 
								else {
									//ctx.setVariable("testing", 'testing');
									//ctx.setVariable("response", responseData);
									var DynamicData = responseData.ErrorMessage.DynamicData;
									for (var j = 0; j < DynamicData.length; j++) {
										var userName = DynamicData[j].userName;
										//ctx.setVariable("user", userName);
										var resultObject = search(userName, loginArray1);
										ctx.setVariable("resobj", resultObject);
										var OMSUrl = session.parameters.OMSUrl + '/api/v1/ServiceType/Electric/Crew/' + resultObject.externalID ;
										//var OMSUrl = session.parameters.OMSUrl + '/api/v1/ServiceType/Electric/Crew/' + userName ;
											
										//ctx.setVariable("omsurl", OMSUrl);
										var v1 = DynamicData[j].longitude;                                               
										var v2 = DynamicData[j].latitude;
										var coodinates = {
											'coordinates': [v1, v2],
											"type": "POINT"
										};
										let unixTimestamp = responseData.ErrorMessage.RefreshDate;
										var ms = unixTimestamp;
										var dateObj = new Date(ms);
										var finalDate = dateObj.toISOString();
										
										ctx.setVariable("asdf", ms);
										ctx.setVariable("test", dateObj);
										ctx.setVariable("time", finalDate);
										var payload = {
											'location': coodinates,
											'customFieldValues': {
												'speed': JSON.stringify(DynamicData[j].speed),
												'heading': JSON.stringify(DynamicData[j].heading),
												'accuracy': JSON.stringify(DynamicData[j].accuracy),
												'altitude': JSON.stringify(DynamicData[j].altitude),
												'RefreshDate': finalDate
											}
										};
										var TokenValue = session.parameters.TokenValue;
										var UpdateCrewLocation = {
											target: OMSUrl,
											sslClientProfile: 'cvis_UpdateCrewLocation_OMSClientProfile',
											method: 'PATCH',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										urlopen.open(UpdateCrewLocation, function(error, response) {
											if (error) {
												// an error occurred during request sending or response header parsing
												logger.error("cvis_005 urlopen connect error while connecting to OMS to UpdateCrewLocation" + JSON.stringify(error));
												session.reject(" urlopen connect error while connecting to OMS to UpdateCrewLocation");
											} else {
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsJSON(function(error, responseData) {
														if (error) {
															// error while reading response or transferring data to Buffer
															logger.error("cvis_015 failure in getting response message from omsapi UpdateCrewLocation " + JSON.stringify(error));
														} else {
															omsres.push(responseData);
															ctx.setVariable("omsresponse", omsres);
															logger.debug("response received from UpdateCrewLocation OMS call:" + JSON.stringify(responseData));
															var targetQueue = session.parameters.Queue;
															var options = {
																target : targetQueue,
																data : responseData
															};
															urlopen.open(options, function(error, response){
																var hm = require('header-metadata');
																if(error){
																	logger.error(' Mqurlopen.open error');
																	session.reject('** Mqurlopen.open error');
																	hm.response.statusCode = 500;
																} else {
																	var mqrc = response.statusCode;
																	if(mqrc == 0){
																		response.readAsBuffer(function(readError, responseData){
																			if(readError){
																				hm.response.statusCode = 500
																			} else {
																				console.log("MQResponseData "+ responseData);
																			}
																		});
																	} else {
																		logger.error('SOM_csyn_002 ** Mqurlopen.open error [MQRC=' + mqrc + ']');
																		session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
																		hm.response.statusCode = 500
																	}
																}
															})
															
														}
													})
												}
												else {
														
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															//dp:reject stop the transaction and go error rule with error code and description
															logger.error("failure in reading message from UpdateCrewLocation OMS call " + JSON.stringify(error));
															session.reject("failure in reading message from UpdateCrewLocation OMS call ");
														} else {
															
															  hm.current.statusCode = responseStatusCode;
															  logger.error("cvis_016 Error returned from UpdateCrewLocation OMS call" + " : with statusCode " + responseStatusCode+" "+ responseData);
														  
														}
													})
												}
											}
										})
									
	


									}
								}

                            })
						}
						
                        else {
                        	
                            logger.error("cvis_017 Error returned from FSECall" + " : with statusCode " + responseStatusCode);
                            hm.response.statusCode = responseStatusCode;
                        }
					}
                }) 
                    


            }
function search(nameKey, myArray){
    for (var i=0; i < myArray.length; i++) {
        if (myArray[i].empid === nameKey) {
            return myArray[i];
        }
    }
}
