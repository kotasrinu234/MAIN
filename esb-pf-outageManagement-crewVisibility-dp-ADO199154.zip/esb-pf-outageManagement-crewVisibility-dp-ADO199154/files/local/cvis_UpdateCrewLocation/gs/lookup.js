var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");
if (ilsctx.getVariable('omsstepexit') === "yes") {
	ilsctx.setVariable('exitStatus', '0')
	ilsctx.setVariable('exitdescription', session.parameters.GetListDescription);
	ilsctx.setVariable('exitdestination', session.parameters.OMSUrl);
	ms.callRule('cvis_UpdateCrewLocation_policy_ILS_StepExit', null, null, function(error) {
		if (error) {
			logger.error("Error in cvis_UpdateCrewLocation_policy_ILS_StepExit	");
		}
	});
}
var labelMap = new Map([
	['SUB', 'DTEEnergyD5'],
	['OH', 'DTEEnergyD6'],
	['UG', 'DTEEnergyD6'],
	['EFO', 'DTEEnergyD5']
])

var type = [];
var crewTypeArray = [];
var loginArray = [];
var resArray = [];


session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var lookupURL = session.parameters.lookupUrl;
		var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
		var typeArray = ctx.getVariable("type");
		var uniquetypeValue = [...new Set(typeArray)];
		ctx.setVariable("uniquetypeValue", uniquetypeValue);

		var resArray = ctx.getVariable("resArray");
		//resArray = [...resArray, ...resArray.data];
		//logger.debug(resArray + "ResArray");
		//session.output.write(resArray);

		var index = uniquetypeValue.indexOf(null);

		if (index > -1) {
			uniquetypeValue.splice(index, 1);
		}
		ctx.setVariable("uniquetypeValue2", uniquetypeValue);
		var obj = {};
		for (var i = 0; i < uniquetypeValue.length; i++) {
			let typeValue = uniquetypeValue[i];
			type.push(typeValue);
			ctx.setVariable("label", type);
			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "crewTypes",
							"status": uniquetypeValue[i]
						}
					]
				}
			};
			var joblookupService = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + joblookupService.target + "; Method :" + joblookupService.method + "; Data :" + JSON.stringify(joblookupService.data) + ". ";
			urlopen.open(joblookupService, function(error, response) {
				if (error) {
					logger.error("cvis_004 urlopen connect error from CrewType joblookupService" + JSON.stringify(error));
					var errorinfo = "cvis_004 urlopen connect error from CrewType joblookupService, details are:" + info + " , " + JSON.stringify(error)
					ilsctx.setVariable('exitStatus', '500')
					ilsctx.setVariable('exitdescription', errorinfo);
					session.reject("urlopen connect error from CrewType LookupServiceResponse" + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								logger.error("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
								var errorinfo = "Failure in reading the message for Crewtype LookupServiceResponse, details are:" + info + " , " + JSON.stringify(error)
								ilsctx.setVariable('exitStatus', '500')
								ilsctx.setVariable('exitdescription', errorinfo);
								session.reject("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("Response received from the LookupServiceResponse " + responseData);
								ctx.setVariable("res", responseData);

								var label = responseData.lookupRep.type[0].label;

								/*if(label == "SUB"){
									var newType = uniquetypeValue[i];
									//ctx.setVariable("subType", subType);
								}
								else if(label == "OH"){
									var newType =uniquetypeValue[i];
									//ctx.setVariable("OHType", OHType);
								}
								else if(label == "UG"){
									var newType = uniquetypeValue[i];
									//ctx.setVariable("UGType", UGType);
								}
								else if(label == "EFO"){
									var newType = uniquetypeValue[i];
									//ctx.setVariable("EFOType", EFOType);
								}
								else {
									var newType = uniquetypeValue[i];
								}
								ctx.setVariable("array", newType);*/
								if (label == "OH" || label == "UG" || label == "EFO" || label == "Substations") {
									obj = {
										"type": typeValue,
										"label": label,

									};
									crewTypeArray.push(obj);
									//logger.error("array", crewTypeArray);
									ctx.setVariable("array", crewTypeArray);

								}

							}


						})

					} else {

						logger.error("Error received in reading lookup response data " + responseStatusCode);
						var errorinfo = "Error received in reading lookup response data, details are:" + info + " responseStatusCode " + responseStatusCode + "responsedata" + responseData;
						ilsctx.setVariable('exitStatus', responseStatusCode)
						ilsctx.setVariable('exitdescription', errorinfo);
						session.reject("Error received in reading lookup response data " + responseStatusCode);
					}
				}
			})
		}


	}
})
var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");

for (var b = 0; b < resArray.length; b++) {
	for (var a = 0; a < crewTypeArray.length; a++) {
		if (resArray[b].type == crewTypeArray[a].type) {
			ctx.setVariable("testing", 'testing');
			var newLabel = crewTypeArray[a].label;
			var crewType = labelMap.get(newLabel);
			var loginUser = resArray[b].externalID + crewType;
			loginArray.push(newLabel);
		}
		else {
			logger.error("ignore thiss");
		}

	}
}
ctx.setVariable("loginArray", loginArray);
