var hm = require('header-metadata');
var sm = require('service-metadata');
//hm.current.statusCode = '500';
var obj = {};
obj.errorMessage = sm.getVar('var://service/error-message');
//obj.errorCode = sm.getVar('var://service/error-code');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
var errorCode = hm.current.statusCode;
if ((errorCode == '400') || (errorCode == '401') || (errorCode == '404') || (errorCode == '405'))
{
    obj.errorCode = errorCode;  
    hm.current.statusCode = errorCode;
}
else{
    obj.errorCode = '500';    
    hm.current.statusCode = '500';
}
session.output.write(obj);