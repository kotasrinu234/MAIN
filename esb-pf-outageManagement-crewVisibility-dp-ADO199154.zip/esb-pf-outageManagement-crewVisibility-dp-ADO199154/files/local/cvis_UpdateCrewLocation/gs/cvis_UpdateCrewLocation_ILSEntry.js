var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var urlIn = sm.getVar('var://service/URL-in');
var ctx = session.name("ILS") || session.createContext("ILS");
function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
var uuid = uuidv4();
ctx.setVariable('correlationID', uuid);
var messageType = session.parameters.messageType;
ctx.setVariable('messageType', messageType);
var dateTime = new Date();
var currentTime = dateTime.toISOString();
ctx.setVariable("sourceEventTimestamp", currentTime);
ctx.setVariable("sourceUrl", urlIn);
var description = session.parameters.EntryDescription;
ctx.setVariable("Entrydescription", description);