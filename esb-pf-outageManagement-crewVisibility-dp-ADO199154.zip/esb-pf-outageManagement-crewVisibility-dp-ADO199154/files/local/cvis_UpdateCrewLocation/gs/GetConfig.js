var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
        /*Start Of ODM Call to GetConfig*/
        var ODMUrl = session.parameters.ODMUrl;
        var ODMCredentials = session.parameters.ODMCredentials;
        //Required ODMUrl and ODMCredentials check
        if ((ODMUrl == undefined) || (ODMUrl == '') || (ODMUrl == null)) {
            logger.error("ODMUrl is missing" + JSON.stringify(error));
            session.reject("ODMUrl is missing" + JSON.stringify(error));
        } else if ((ODMCredentials == undefined) || (ODMCredentials == '') || (ODMCredentials == null)) {
            logger.error(" ODMCredentials is missing" + JSON.stringify(error));
            session.reject("ODMCredentials is missing");
        } else {
            var ODMEncodedCred = 'Basic ' + new Buffer(ODMCredentials).toString('base64');
            hm.current.remove('MQMD');
            var timeType = incomingdata.timeType;
            var timerDateTime = incomingdata.timerDateTime;
            var timerValue = timeType + timerDateTime;
            //payload need to be sent to ODM
            var ODMInputpayload = {
                '__DecisionID__': timerValue
            };
            var GetConfigVariable = session.createContext('GetConfig');

            var GetConfig = {
                target: ODMUrl,
                sslClientProfile: 'cvis_UpdateCrewLocation_ClientProfile',
                method: 'post',
                contentType: 'application/json',
                headers: {
                    'Authorization': ODMEncodedCred
                },
                data: ODMInputpayload
            };


            urlopen.open(GetConfig, function(error, response) {
                if (error) {
                    // an error occurred during request sending or response header parsing
                    logger.error("cvis_001 urlopen connect error with odm causeCodeapi " + JSON.stringify(error));
                    session.reject("urlopen connect error with odm causeCodeapi" + JSON.stringify(error));
                } else {
                    // read response data
                    // get the response status code
                    var responseStatusCode = response.statusCode;
                    if (responseStatusCode == 200) {
                        response.readAsJSON(function(error, responseData) {
                            if (error) {
                                // error while reading response or transferring data to Buffer
                                logger.error(" failure in reading message from ODM for GetConfig" + JSON.stringify(error));
                                session.reject(" failure in reading message from ODM for GetConfig" + JSON.stringify(error));
                            } else {
                                hm.response.statusCode = '200 OK';
                                logger.debug("response received from GetConfig ODM call:" + responseData);
                                GetConfigVariable.setVariable("ODMOutput", responseData);
                                session.output.write(responseData);
                            }
                        });
                    } else {
                        hm.current.statusCode = responseStatusCode;
                        logger.error("Error returned from GetConfig ODM call" + " : with statusCode " + responseStatusCode);
                        hm.response.statusCode = responseStatusCode;
                        session.reject("Error returned from GetConfig ODM call");
                    }
                }
            });
        }

    }

    /*End Of ODM Call*/

});