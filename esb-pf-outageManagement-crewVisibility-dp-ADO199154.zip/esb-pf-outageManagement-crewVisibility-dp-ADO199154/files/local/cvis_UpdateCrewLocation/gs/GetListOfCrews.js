//9cGetListOfCrew
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");
var TokenValue = session.parameters.TokenValue;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		/*Start Of OMS Call to GetListOfCrews*/
		var OMS = session.parameters.OMSUrl;
		if ((OMS == undefined) || (OMS == '') || (OMS == null)) {
			logger.error("OMSUrl is missing" + JSON.stringify(error));
			session.reject("OMSUrl is missing");
		} else {

			var eId = [];
			var resArray = [];
			var typeArray = [];
			var GetListOfCrewVariable = session.createContext('GetListOfCrew');
			var skip = 0;
			var take = 1000;
			var OMSUrl = OMS + '/api/v1/ServiceType/Electric/Crew?excludeDeprecated=true&excludeInactive=false&includeFields=id,externalID,archived,deprecated,active,type,customFieldValuesExt&skip=' + skip + '&take=' + take;

			//Recursive function call
			function getDataFn(OMSUrl) {

				fetchData(OMSUrl, function(error, responseData) {
					if (error) {
						logger.error("UrlOpen error for getData" + JSON.stringify(error))

					} else {
						var total = responseData.total;
						logger.debug("total" + total);
						resArray = [...resArray, ...responseData.data]
						logger.debug(resArray + "ResArray");
						// return responseData;
						if (total == take) {
							// call the function recursively when total == take
							skip = skip + 1000;
							OMSUrl = OMS + '/api/v1/ServiceType/Electric/Crew?excludeDeprecated=true&excludeInactive=false&includeFields=id,externalID,archived,deprecated,active,type,customFieldValuesExt&skip=' + skip + '&take=' + take;
							getDataFn(OMSUrl);
						} else {
							var result = resArray;
							for (var i = 0; i < result.length; i++) {
								if ((result[i].archived == false) && (result[i].active == true)) {
									eId.push(result[i].externalID);
									typeArray.push(result[i].type);
								}
							}
							logger.debug("eidArray", eId);
							GetListOfCrewVariable.setVariable("eidArray", eId);
							GetListOfCrewVariable.setVariable("type", typeArray);
							GetListOfCrewVariable.setVariable("resArray", resArray);
							// the resultant array of emp id needs to be sent to FSM
							session.output.write(eId);
							return resArray;
						}

					}

				});
			}
			getDataFn(OMSUrl);
			GetListOfCrewVariable.setVariable("TestLength", resArray.length)
		}
	}

	function fetchData(OMSUrl, cb) {

		var GetListOfCrews = {
			target: OMSUrl,
			sslClientProfile: 'cvis_UpdateCrewLocation_OMSClientProfile',
			method: 'get',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			}
		};
		var info = " TargetURL :" + GetListOfCrews.target + "; Method :" + GetListOfCrews.method + ". ";
		urlopen.open(GetListOfCrews, function(error, response) {
			if (error) {
				// an error occurred during request sending or response header parsing
				logger.error("cvis_002 urlopen connect error with causeCodeapi oms api get" + JSON.stringify(error));
				var errorinfo = "cvis_002 urlopen connect error with causeCodeapi oms api get, details are:" + info + " , " + JSON.stringify(error)
				ilsctx.setVariable('exitStatus', '500')
				ilsctx.setVariable('exitdescription', errorinfo);
				session.reject("urlopen connect error with causeCodeapi oms api get" + JSON.stringify(error))
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							logger.error("urlopen connect error with oms GetListOfCrewVariable " + JSON.stringify(error));
							var errorinfo = "urlopen connect error with oms GetListOfCrewVariable , details are:" + info + " , " + JSON.stringify(error)
							ilsctx.setVariable('exitStatus', '500')
							ilsctx.setVariable('exitdescription', errorinfo);
							cb(error, null);
						} else {
							hm.response.statusCode = '200 Message is received';
							logger.debug("response received from 1st GetListOfCrews OMS call:" + responseData);
							//GetListOfCrewVariable.setVariable("GetListOfCrewVariable", responseData);
							var total = responseData.total;
							ilsctx.setVariable("omsstepexit", "yes");
							GetListOfCrewVariable.setVariable("total", total);
							cb(null, responseData);
						}
					})
				}else if(responseStatusCode == 401 || responseStatusCode == 403){
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "failure in reading message from UpdateCrewLocation OMS call , details are:" + info + " , " + JSON.stringify(error)
							ilsctx.setVariable('exitStatus', '500')
							ilsctx.setVariable('exitdescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "cvis_013 Error returned from GetListOfCrews OMS call details are :" + info + " : with statusCode " + responseStatusCode + " " + responseData
							ilsctx.setVariable('exitStatus', responseStatusCode)
							ilsctx.setVariable('exitdescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
					
				}else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error("failure in reading message from UpdateCrewLocation OMS call " + JSON.stringify(error));
							var errorinfo = "failure in reading message from UpdateCrewLocation OMS call , details are:" + info + " , " + JSON.stringify(error)
							ilsctx.setVariable('exitStatus', '500')
							ilsctx.setVariable('exitdescription', errorinfo);
							session.reject("failure in reading message from UpdateCrewLocation OMS call ");
						} else {
							hm.current.statusCode = responseStatusCode;
							logger.error("cvis_003 Error returned from GetListOfCrews OMS call" + " : with statusCode " + responseStatusCode + " " + responseData);
							var errorinfo = "cvis_003 Error returned from GetListOfCrews OMS call details are :" + info + " : with statusCode " + responseStatusCode + " " + responseData
							ilsctx.setVariable('exitStatus', responseStatusCode)
							ilsctx.setVariable('exitdescription', errorinfo);
							cb("Error returned from GetListOfCrews OMS call" + " : with statusCode " + responseStatusCode, null);

						}
					});
				}
			}
		}); //URL open closed
	}
})
