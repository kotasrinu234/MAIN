var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

/*var labelMap = new Map([
['SUB','DTEEnergyD5'],
['OH','DTEEnergyD6'],
['UG','DTEEnergyD6'],
['EFO','DTEEnergyD5']
])*/
var OHArray = [];
var OHEmpArray = [];
var loginUser;
var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
var omsres = ctx.getVariable('omsresponse');
var ilsctx = session.name("ILS") || session.createContext("ILS");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {


		var FSEUrl = session.parameters.FSEUrl;
		var Auth = "Basic " + session.parameters.FSEToken;
		//Required check for FSM URL
		if ((FSEUrl == undefined) || (FSEUrl == '') || (FSEUrl == null)) {
			logger.error("cvis_011 FSEUrl is missing" + JSON.stringify(error))
			session.reject("FSEUrl is missing")
		} else {
			//var ODMConfig = session.name('GetConfig');
			//var ODMOutput = ODMConfig.getVariable('ODMOutput');
			var numEngineersToRequest = session.parameters.numEngineersToRequest;
			//var UGArray = [];
			var TestArray = []

			var crewTypeArray = ctx.getVariable("array");
			var resArray = ctx.getVariable("resArray");

			for (var i = 0; i < resArray.length; i++) {
				var Type = resArray[i].type
				TestArray.push(Type)
			}

			for (var b = 0; b < resArray.length; b++) {
				for (var a = 0; a < crewTypeArray.length; a++) {
					if (resArray[b].type == crewTypeArray[a].type) {

						var newLabel = crewTypeArray[a].label;
						//var crewType = labelMap.get(newLabel);
						var employeeId = resArray[b].customFieldValuesExt.employeeid;
						if (newLabel == 'OH') {
							loginUser = employeeId + '@' + session.parameters.OH_UG;
							OHArray.push(loginUser)
							var obj1 = {
								'label': newLabel,
								'empid': resArray[b].customFieldValuesExt.employeeid,
								'externalID': resArray[b].externalID
							};
							OHEmpArray.push(obj1);
							ctx.setVariable("OHEmpArray", OHEmpArray)

						}
					}
				}
			}
			var index = OHArray.indexOf(null);
			if (index > -1) {
				OHArray.splice(index, 1);
			}
			ctx.setVariable("OHArray", OHArray);
			//ctx.setVariable("loginArray1", loginArray1);
			var results = [];

			var OHArrayindex = OHArray.length;
			ctx.setVariable("OHArrayindex", OHArrayindex)
			//ctx.setVariable("D6Array", D6Array)
			//Start of splitting array
			function chunkArray(eidArray, chunk_size, results) {
				while (eidArray.length) {
					results.push(eidArray.splice(0, chunk_size));
				}
				return results;
			}
			ctx.setVariable("results", results);

			var OHChunks = []
			var OHresult = chunkArray(OHArray, numEngineersToRequest, OHChunks);

			//splitting array
			function makeRequest(FSECall) {
				return new Promise(function(resolve, reject) {
					var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";
					urlopen.open(FSECall, function(error, response) {
						if (error) {
							var errorinfo = "urlopen connect error while connecting to 'FSECall', details are : " + info + "; error info :" + error
							ilsctx.setVariable('exitdescription', errorinfo);
							ilsctx.setVariable('exitStatus', '500');
							logger.error(errorinfo);
							reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "Failure in getting response of 'FSECall', details are : " + info + "; error info :" + error
										ilsctx.setVariable('exitdescription', errorinfo);
										ilsctx.setVariable('exitStatus', responseStatusCode);
										logger.error(errorinfo);
										reject(errorinfo);
									} else {
										if (responseData.IsSuccess == true) {
											ctx.setVariable("response", responseData.ErrorMessage);
											var Data = JSON.parse(responseData.ErrorMessage);
											//jsonString = jsonString.replaceAll('\"', '"');
											ctx.setVariable("testing", Data);
											for (var j = 0; j < Data.DynamicData.length; j++) {
												var userName = Data.DynamicData[j].userName;
												//ctx.setVariable("user", userName);
												var resultObject = search(userName, OHEmpArray);
												ilsctx.setVariable('exitdescription', session.parameters.FSEDescription);
												ilsctx.setVariable('exitdestination', FSEUrl);
												ilsctx.setVariable('exitStatus', '0')
												var ms = require('multistep');
												ms.callRule('cvis_UpdateCrewLocation_policy_ILS_StepExit', null, null, function(error) {
													if (error) {
														logger.error("Error in cvis_UpdateCrewLocation_policy_ILS_StepExit	");
													}
												});
												var OMSUrl = session.parameters.OMSUrl + '/api/v1/ServiceType/Electric/Crew/' + resultObject.externalID;

												//ctx.setVariable("omsurl", OMSUrl);
												var v1 = Data.DynamicData[j].longitude;
												var v2 = Data.DynamicData[j].latitude;
												var coodinates = {
													'coordinates': [v1, v2],
													"type": "POINT"
												};
												let unixTimestamp = Data.RefreshDate;
												var ms = unixTimestamp;
												var dateObj = new Date(ms);
												var finalDate = dateObj.toISOString();

												ctx.setVariable("asdf", ms);
												ctx.setVariable("test", dateObj);
												ctx.setVariable("time", finalDate);
												//var messageid = ilsctx.getVariable('correlationID')
												var payload = {
													'location': coodinates,
													'customFieldValues': {
														'speed': JSON.stringify(Data.DynamicData[j].speed),
														'heading': JSON.stringify(Data.DynamicData[j].heading),
														'accuracy': JSON.stringify(Data.DynamicData[j].accuracy),
														'altitude': JSON.stringify(Data.DynamicData[j].altitude),
														'RefreshDate': finalDate
													}

												};
												var TokenValue = session.parameters.TokenValue;
												var UpdateCrewLocation = {
													target: OMSUrl,
													sslClientProfile: 'cvis_UpdateCrewLocation_OMSClientProfile',
													method: 'PATCH',
													contentType: 'application/json',
													headers: {
														'osiApiToken': TokenValue
													},
													data: payload
												};
												var info = " TargetURL :" + UpdateCrewLocation.target + "; Method :" + UpdateCrewLocation.method + "; Data :" + JSON.stringify(UpdateCrewLocation.data) + ". ";

												urlopen.open(UpdateCrewLocation, function(error, response) {
													if (error) {
														// an error occurred during request sending or response header parsing
														var errorinfo = "cvis_008 urlopen connect error while connecting to OMS to UpdateCrewLocation, details are : " + info + "; error info :" + error
														ilsctx.setVariable('exitdescription', errorinfo);
														ilsctx.setVariable('exitStatus', '500');
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														// read response data
														// get the response status code
														var responseStatusCode = response.statusCode;
														if (responseStatusCode == 200) {
															response.readAsJSON(function(error, responseData) {
																if (error) {
																	// error while reading response or transferring data to Buffer
																	var errorinfo = "failure in getting response message from omsapi UpdateCrewLocation, details are : " + info + "; error info :" + error
																	ilsctx.setVariable('exitdescription', errorinfo);
																	ilsctx.setVariable('exitStatus', responseStatusCode);
																	logger.error(errorinfo);
																} else {
																	ilsctx.setVariable('exitStatus', '0');
																	logger.debug("response received from UpdateCrewLocation OMS call:" + JSON.stringify(responseData));
																	var targetQueue = session.parameters.Queue;
																	var messageId = ilsctx.getVariable('correlationID')
																	var payload = responseData
																	payload.messageId = messageId
																	var options = {
																		target: targetQueue,
																		data: payload
																	};
																	omsres.push(responseData);
																	ctx.setVariable("omsresponse", omsres);
																	var options = {
																		target: targetQueue,
																		data: responseData
																	};

																	var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
																	try {
																		urlopen.open(options, function(error, response) {
																			var hm = require('header-metadata');
																			if (error) {
																				hm.response.statusCode = 500;
																				var errorinfo = "cvis_009 Mq urlopen error, details are : " + info + "; error info :" + error
																				ilsctx.setVariable('exitdescription', errorinfo);
																				ilsctx.setVariable('exitStatus', '500');
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var mqrc = response.statusCode;
																				if (mqrc == 0) {
																					response.readAsBuffer(function(readError, responseData) {
																						if (readError) {
																							hm.response.statusCode = 500
																							ilsctx.setVariable('exitStatus', mqrc);
																						} else {
																							ilsctx.setVariable('exitStatus', '0');
																							console.log("MQResponseData " + responseData);
																						}
																					});
																				} else {
																					hm.response.statusCode = 500
																					var errorinfo = "Mqurlopen.open error [MQRC=" + mqrc + "]" + info + "; error info :" + error
																					ilsctx.setVariable('exitdescription', errorinfo);
																					ilsctx.setVariable('exitStatus', mqrc);
																					logger.error(errorinfo);
																					session.reject(errorinfo);
																				}
																			}
																		})
																	} catch (error) {
																		hm.response.statusCode = 500;
																		var errorinfo = "cvis_009 Mq urlopen error, details are : " + info + "; error info :" + error
																		ilsctx.setVariable('exitdescription', errorinfo);
																		ilsctx.setVariable('exitStatus', '500');
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}

																}
															})
														}
														else {

															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	//dp:reject stop the transaction and go error rule with error code and description
																	var errorinfo = "failure in reading message from UpdateCrewLocation OMS call, details are : " + info + "; error info :" + error
																	ilsctx.setVariable('exitdescription', errorinfo);
																	ilsctx.setVariable('exitStatus', responseStatusCode);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {

																	hm.current.statusCode = responseStatusCode;
																	var responseinfo = "cvis_010 Error returned from UpdateCrewLocation OMS call : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	logger.error(responseinfo);
																}
															})
														}
													}
												})
											}
										}
										else if (responseData.IsSuccess == false) {
											logger.error("cvis_007 \"IsSucess\" is false coming from FSE")
											//session.reject(" \"IsSuccess\" is false coming from FSE");

										}

										resolve(responseData);
									}

								});

							} else {
								response.readAsBuffer(function(error, responseData) {

									if (error) {
										var errorinfo = "Failure in reading response of 'FSECall', details are : " + info + "; error info :" + error
										ilsctx.setVariable('exitdescription', errorinfo);
										ilsctx.setVariable('exitStatus', responseStatusCode);
										logger.error(errorinfo);
										reject(errorinfo);
									} else {
										var errorinfo = "Error returned from 'FSECall', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ilsctx.setVariable('exitdescription', errorinfo);
										ilsctx.setVariable('exitStatus', responseStatusCode);
										logger.error(errorinfo);
										reject(errorinfo);

									}

								});

							}

						}

					});

				});

			}

			async function main() {
				for (var i = 0; i < OHresult.length; i++) {
					var Data = OHresult[i]
					var FSECall = {
						target: FSEUrl,
						sslClientProfile: 'FSE_Client_Profile',
						method: 'post',
						contentType: 'application/json',
						headers: {
							'Authorization': Auth,
						},
						data: {
							"loginUser": Data,
							"fromTime": 0
						}
					};

					try {
						var responseData = await makeRequest(FSECall);
						hm.response.statusCode = '200 OK';
						logger.debug("response received :" + JSON.stringify(responseData));
					} catch (error) {
						hm.current.statusCode = responseStatusCode;
						logger.error(error);
						session.reject(error);
					}
				}
			}
			main();
		}
		/*End Of Crew Location Call*/
	}
})

function search(nameKey, myArray) {
	for (var i = 0; i < myArray.length; i++) {
		var EmpID = myArray[i].empid
		var DupEmpID = EmpID + "a"
		var DupnameKey = nameKey + "a"
		if (DupEmpID.toUpperCase() === DupnameKey.toUpperCase()) {
			return myArray[i];
		}
	}
}
