Deployment instructions:


deploy IIBMQ scripts and iibflow are uploaded in dteenergy/esb-pf-outageManagement-crewVisibility-iib/tree/feature.

MQCSP details will be given by DTE ESB team.

Password aliases will be created by DTE ESB team.

Private keys and certs need to be provided by DTE ESB team.

Backend Url's need to confirmed for FSM and oms for load and prod

Properties file as per env are in the config folder of this repository.

Jenkins file as per env are also uploaded in this repository.
