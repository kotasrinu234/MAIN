# esb-pf-OutageMangement-crewAssignmentRequestAPI-dp-
Interface 49 - FSE Resource Request
