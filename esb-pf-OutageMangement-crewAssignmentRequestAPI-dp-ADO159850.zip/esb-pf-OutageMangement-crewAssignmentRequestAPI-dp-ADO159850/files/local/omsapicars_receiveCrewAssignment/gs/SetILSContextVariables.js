var ILSctx = session.name('ILS') || session.createContext('ILS');

var dateTime = new Date();
ILSctx.setVariable("sourceEventTimestamp", dateTime.toISOString());
