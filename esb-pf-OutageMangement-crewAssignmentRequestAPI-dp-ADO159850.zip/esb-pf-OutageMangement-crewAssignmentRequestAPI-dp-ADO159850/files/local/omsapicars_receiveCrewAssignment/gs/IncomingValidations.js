//js is used to perform nullcheck for the input request
var logger = console.options({ 'category': 'all' });
var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name("ILS") || session.createContext("ILS");

session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var JobIDGUID = incomingData.CrewRequest.JobIDGUID;
		var CrewType = incomingData.CrewRequest.CrewType;
		var WorkType = incomingData.CrewRequest.WorkType;
		
		NullCheck(JobIDGUID, "JobIDGUID")
		NullCheck(WorkType, "WorkType")
		NullCheck(CrewType, "CrewType")
	}
})
function NullCheck(value, myctx) {
	if (value === null || value === '' || value === undefined) {
		var info = myctx + ' is not present in input payload'
		ILSctx.setVariable("ExitDescription", info)
		logger.error(info);
		ctx.setVariable("schemafailed", 'yes')
		session.reject(info);
	}
}