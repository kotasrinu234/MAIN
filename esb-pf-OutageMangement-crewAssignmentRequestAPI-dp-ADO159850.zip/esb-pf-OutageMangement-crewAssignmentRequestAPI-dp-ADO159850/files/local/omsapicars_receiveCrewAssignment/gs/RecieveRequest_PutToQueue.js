var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data" + JSON.stringify(error)
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo);
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {
		var StandaloneMQurl = session.parameters.MQUrl;
		var ExitDescription = session.parameters.ExitDescription;
		var pushingToQueue = {
			target: StandaloneMQurl,
			data: incomingData
		};
		var info = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";
		try{
		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var ctx = session.name("rreq") || session.createContext("rreq");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				var errorinfo = "error reading response 'OMSAPICARS.CREWASSIGNMENT.REQUEST QueueCall', details are :" + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "Error reading the response 'OMSAPICARS.CREWASSIGNMENT.REQUEST QueueCall', details are : " + info + "; error info :" + readError
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							hm.response.statusCode = 500
							logger.error(errorinfo);
							session.reject(errorinfo)
						} else {
							logger.debug("MQResponsecode " + mqrc);
							ILSctx.setVariable('ExitStatus', '0');
							ILSctx.setVariable('ExitDestination', StandaloneMQurl);
							ILSctx.setVariable('ExitDescription', ExitDescription)
						}
					});
				} else {
					var errorinfo = "Error received from the response of OMSAPICARS.CREWASSIGNMENT.REQUEST Queue, details are : " + info + "; response info :" + JSON.stringify(response) + "; ResponseStatusCode :" + response.statusCode
					var ctx = session.name("rreq") || session.createContext("rreq");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			}
		});
		} catch(err){
			
			var ctx = session.name("rreq") || session.createContext("rreq");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				var errorinfo = "error reading response 'OMSAPICARS.CREWASSIGNMENT.REQUEST QueueCall', details are :" + info + "; error info :" + err
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
		}
	}
});
