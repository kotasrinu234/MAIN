var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		var errorinfo = "Error in reading Incoming Data" + JSON.stringify(readAsJSONError)
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {
		//var Auth = "Basic "+session.parameters.FSEToken;
		var data = incomingdata;
		data.CallBackData.CallID = ctx.getVariable("displayID");
		data.CallBackData.Number = '0';
		var ExitDescription = session.parameters.ExitDescription
		var FSECall = {
			target: session.parameters.FacadeUrl,
			sslClientProfile: 'omsapicars_reportErrorCrewAssignment_TLS_ClientProfile',
			method: 'post',
			contentType: 'application/json',
			data: incomingdata
		};

        var info = " TargetURL: " + FSECall.target + "; Method: " + FSECall.method + "; Data: " + JSON.stringify(FSECall.data) + ". ";
        try{
		urlopen.open(FSECall, function(error, response) {
			if (error) {
				// an error occurred during request sending or response header parsing
				var errorinfo = "rreq_007: urlopen connect error while doing Facade Call" + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response 'FSECall ', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} 
						else {
							logger.debug("Business error sent to FSE");
							ILSctx.setVariable('ExitStatus', '0');
		                    ILSctx.setVariable('ExitDescription', ExitDescription)
							
							
						}
					})
				}
				else {

					response.readAsBuffer(function(error, responseData) {

						if (error) {
							var errorinfo = "failure in reading response 'FSECall', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);

						} else {
                            var errorinfo = "rreq_008:Error response from facade call " + ": with statusCode " + responseStatusCode + " " + responseData;
	                        hm.current.statusCode = responseStatusCode;
							ctx.setVariable("retry", 'yes');
							var ErrorTxt = " urlopen connect error with facade call" + JSON.stringify(error);
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
					        //session.reject("Error returned from NotesMessage " + ": with statusCode " + responseStatusCode + " " + responseData);
						}
					})
				}
			}
		})
		} catch(err)
		{
			var errorinfo = "rreq_007: urlopen connect error while doing Facade Call" + info + "; error info :" + err
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
		}
	}
})
