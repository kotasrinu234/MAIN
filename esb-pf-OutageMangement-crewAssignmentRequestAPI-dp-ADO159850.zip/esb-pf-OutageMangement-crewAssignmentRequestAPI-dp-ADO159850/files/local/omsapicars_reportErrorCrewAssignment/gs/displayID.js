var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ExitDestination = session.parameters.FacadeUrl; 
ILSctx.setVariable('ExitDestination', ExitDestination)

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		var errorinfo = "Error in reading Incoming Data" + JSON.stringify(readAsJSONError)
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {
		var ExternalRefID = incomingdata.CallBackData.ExternalRefID;
		var ExternalRefIDSplit = ExternalRefID.split(":");
		var crewAssignmentID = ExternalRefIDSplit[1];
		var OMSUrl = session.parameters.OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + crewAssignmentID + '?includeFields=displayID';
		var Token = session.parameters.OMSToken;
		var oms = {
			target: OMSUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
			'osiApiToken': Token
			}
		};

        var info = " TargetURL: " + oms.target + "; Method: " + oms.method  + ". ";
        try{
		urlopen.open(oms, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'getCallID BusinessError', details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					logger.error(errorinfo);
					session.reject(errorinfo);
			}
											
			else {	
				var rescode = response.statusCode;
				if(rescode == 200){
					response.readAsJSON(function(error, responseData) {
                        if (error) {
                           var errorinfo = "error reading response 'getCallID BusinessError', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
                        } else {
                            hm.response.statusCode = '200 OK';
                            logger.debug("response received from OMS Get calls by job:" + JSON.stringify(responseData));
							ctx.setVariable("omsResponse", responseData);
							ctx.setVariable("displayID", responseData.displayID);
							ILSctx.setVariable('ExitStatus', '0');
							ILSctx.setVariable('ExitDescription', session.parameters.ExitDescription)
						}
					})
				}
				else{
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading response 'getCallID BusinessError', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', rescode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							var errorinfo = "rreq_006: error response 'getCallID BusinessError', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							hm.current.statusCode = responseStatusCode;
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					})
				}
			}
		})
		} catch(err){
			var errorinfo = "url connection error 'getCallID BusinessError', details are : " + info + "; error info :" + err
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					logger.error(errorinfo);
					session.reject(errorinfo);
		}
	}
})
