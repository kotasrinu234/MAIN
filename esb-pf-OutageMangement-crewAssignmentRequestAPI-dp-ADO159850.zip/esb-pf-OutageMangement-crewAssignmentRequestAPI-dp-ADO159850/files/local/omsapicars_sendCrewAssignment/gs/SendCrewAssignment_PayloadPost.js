var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading Incoming Data" + JSON.stringify(readAsJSONError)
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {
		var OMSUrl = session.parameters.OMSUrl;
		if ((OMSUrl == undefined) || (OMSUrl == ' ') || (OMSUrl == null)) {
			var errorinfo = "Error in connection with OMSUrl"
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo)
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			ctx.setVariable("incomin", incomingdata)
			var ExitDescription = session.parameters.ExitDescription

			var Client = incomingdata.CallBackData.Client;
			var ServiceName = incomingdata.CallBackData.ServiceName;
			var ExternalRefID = incomingdata.CallBackData.ExternalRefID;
			var engineerType = incomingdata.CrewRequest.CrewType;
			var taskType = incomingdata.CrewRequest.WorkType;
			var messageID = incomingdata.CallBackData.messageID;

			var lookupForCrewtype = {
				"lookupReq": {
					"type": [
						{
							"name": "crewTypes",
							"label": engineerType

						},
						{
							"name": "workTypes",
							"label": taskType
						}
					]
				}
			};

			var url = session.parameters.lookupUrl;
			var LookupServiceResponse = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupForCrewtype

			};
			var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "; Data: " + JSON.stringify(LookupServiceResponse.data) + ". ";
			try{
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "rreq_002 : url connection error 'LookUpCall', details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'LookUpCall', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', '500');
								ILSctx.setVariable('ExitDescription', errorinfo)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "; Data: " + JSON.stringify(LookupServiceResponse.data) + ". ";
								hm.response.statusCode = responseStatusCode;
								logger.debug("Response received from the LookupServiceResponse " + responseData);
								ctx.setVariable("res", responseData);
								if (responseData.lookupRep.type[0].result == 1) {
									var invalidresp = "rreq_003: Invalid Lookup Request 'crewType Request', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', invalidresp)
									logger.error(invalidresp)
									session.reject(invalidresp)
								}
								else if (responseData.lookupRep.type[1].result == 1) {
									var invalidresp = "rreq_004: Invalid Lookup Request 'workType Request', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', invalidresp)
									logger.error(invalidresp)
									session.reject(invalidresp)
								}
								else {
									var status = responseData.lookupRep.type[0].status;
									var internalId = responseData.lookupRep.type[1].id;
									ctx.setVariable("status", status);
									ctx.setVariable("internalId", internalId);

									var JobIDGUID = incomingdata.CrewRequest.JobIDGUID;
									var Longitude = incomingdata.CrewRequest.Longitude;
									var Latitude = incomingdata.CrewRequest.Latitude;

									var OMSpayload = {
										"workTypeID": internalId,
										"status": -1,
										"requestedCrewType": status,
										"location": {
											"coordinates": [
												Longitude,
												Latitude
											],
											"type": "Point"
										}
									};

									var Token = session.parameters.OMSToken;
									var PayloadUrl = OMSUrl + '/api/v1/ServiceType/Electric/CrewAssignment?jobIDs=' + JobIDGUID;
									ILSctx.setVariable('ExitDestination', PayloadUrl)
									var CrewAssignment = {
										target: PayloadUrl,
										sslClientProfile: 'omsapi_client_profile',
										method: 'POST',
										contentType: 'application/json',
										data: OMSpayload,
										headers: {
											'osiApiToken': Token
										}
									};
									var info = " TargetURL: " + CrewAssignment.target + "; Method: " + CrewAssignment.method + "; Data: " + JSON.stringify(CrewAssignment.data) + ". ";
									try{
									urlopen.open(CrewAssignment, function(error, response) {
										if (error) {
											var errorinfo = "rreq_005: url connection error 'CrewAssignment Update to OMS', details are : " + info + "; error info :" + error
											logger.error(errorinfo);
											ctx.setVariable("retry", 'yes');
											ILSctx.setVariable('ExitStatus', '500');
											ILSctx.setVariable('ExitDescription', errorinfo)
											var ErrorTxt = errorinfo
											ctx.setVariable("ErrorTxt", ErrorTxt);
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsJSON(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'CrewAssignment Update to OMS', details are : " + info + "; error info :" + error
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('ExitDescription', errorinfo)
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														hm.response.statusCode = '200 OK';
														logger.debug("Response received from CrewAssignment :" + JSON.stringify(responseData));
														ILSctx.setVariable('ExitStatus', '0');
														ILSctx.setVariable('ExitDescription', ExitDescription)
													}
												});
											}
											else if (responseStatusCode == 400) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'CrewAssignment Update to OMS', details are : " + info + "; error info :" + error
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('ExitDescription', errorinfo)
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														hm.current.statusCode = responseStatusCode;
														var res = responseData.toString();
														var QueueMessage = {
															"CallBackData": {
																"Client": Client,
																"ServiceName": incomingdata.CallBackData.ServiceName,
																"ExternalRefID": ExternalRefID,
																"messageID": messageID
															},
															"ErrorMessage": res
														}
													};
													var targetQueue = session.parameters.Queue;
													ILSctx.setVariable('ExitDestination', targetQueue)
													var options = {
														target: targetQueue,
														data: QueueMessage
													};
													var info = " TargetURL: " + options.target + "; Data: " + JSON.stringify(options.data) + ". ";
													try{
													urlopen.open(options, function(error, response) {
														var hm = require('header-metadata');
														if (error) {
															var errorinfo = "url connection error 'OMSAPICARS.CREWASSIGNMENT.ERROR Queue', details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', '500');
															ILSctx.setVariable('ExitDescription', errorinfo)
															logger.error(errorinfo);
															session.reject(errorinfo);
															hm.response.statusCode = 500;
														} else {
															var mqrc = response.statusCode;
															if (mqrc == 0) {
																response.readAsBuffer(function(readError, responseData) {
																	if (readError) {
																		var errorinfo = "Error reading the response 'OMSAPICARS.CREWASSIGNMENT.ERROR Queue', details are : " + info + "; error info :" + readError
																		ILSctx.setVariable('ExitStatus', '500');
																		ILSctx.setVariable('ExitDescription', errorinfo)
																		hm.response.statusCode = 500
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		console.log("MQResponseData " + responseData);
																	}
																});
															} else {
																var errorinfo = "Error received from the response of 'OMSAPICARS.CREWASSIGNMENT.ERROR Queue', details are : " + info + "; response info :" + JSON.stringify(response) + "; ResponseStatusCode :" + response.statusCode
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ExitDescription', errorinfo)
																hm.response.statusCode = 500
																logger.error(errorinfo);
																session.reject(errorinfo);
															}
														}
													})
													} catch(err){
														var errorinfo = "url connection error 'OMSAPICARS.CREWASSIGNMENT.ERROR Queue', details are : " + info + "; error info :" + err
															ILSctx.setVariable('ExitStatus', '500');
															ILSctx.setVariable('ExitDescription', errorinfo)
															logger.error(errorinfo);
															session.reject(errorinfo);
															hm.response.statusCode = 500;
													}
													var info = " TargetURL: " + CrewAssignment.target + "; Method: " + CrewAssignment.method + "; Data: " + responseData + ". ";
													var errorinfo = "Bad Request Error from CrewAssignment: , details are : " + info
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ExitDescription', errorinfo)
													logger.error(errorinfo);
													session.reject(errorinfo);
												})
											}
											else {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "failure reading the error response 'CrewAssignment Update to OMS', details are : " + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('ExitDescription', errorinfo)
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														var errorinfo = "error response 'CrewAssignment Update to OMS', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														hm.current.statusCode = responseStatusCode;
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('ExitDescription', errorinfo)
														logger.error(errorinfo);
														ctx.setVariable("retry", 'yes');
														var ErrorTxt = errorinfo
														ctx.setVariable("ErrorTxt", ErrorTxt);
													}
												});
											}
										}
									});
									} catch(err){
										var errorinfo = "rreq_005: url connection error 'CrewAssignment Update to OMS', details are : " + info + "; error info :" + err
											logger.error(errorinfo);
											ctx.setVariable("retry", 'yes');
											ILSctx.setVariable('ExitStatus', '500');
											ILSctx.setVariable('ExitDescription', errorinfo)
											var ErrorTxt = errorinfo
											ctx.setVariable("ErrorTxt", ErrorTxt);
									}
								}
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading response 'LookUpCall', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "error response 'LookUpCall', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								hm.current.statusCode = responseStatusCode;
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
			} catch(err){
				var errorinfo = "rreq_002 : url connection error 'LookUpCall', details are : " + info + "; error info :" + err
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					logger.error(errorinfo);
					session.reject(errorinfo);
			}

		}

	}

});
