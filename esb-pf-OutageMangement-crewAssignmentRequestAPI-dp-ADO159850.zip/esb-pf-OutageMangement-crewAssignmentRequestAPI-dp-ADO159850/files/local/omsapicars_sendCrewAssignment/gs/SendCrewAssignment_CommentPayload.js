var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var checkretry = ctx.getVariable("retry");
if (checkretry !== 'yes') {
	session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			var errorinfo = "Error in reading Incoming Data" + JSON.stringify(readAsJSONError)
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo)
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var OMSUrl = session.parameters.OMSUrl;
			var Token = session.parameters.OMSToken;
			var ExitDescription = session.parameters.ExitDescription
			if ((OMSUrl == undefined) || (OMSUrl == ' ') || (OMSUrl == null)) {
				var errorinfo = "Error in connection with OMSUrl"
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var JobIDGUID = incomingdata.CrewRequest.JobIDGUID;
				var Comment = incomingdata.CrewRequest.Notes;
				var CommentPayload = {
					"comment": Comment
				};

				var NotesUrl = OMSUrl + '/api/ServiceType/Electric/Job/' + JobIDGUID + '/Comment';
				ILSctx.setVariable('ExitDestination', NotesUrl)
				var CommentPayloadPost = {
					target: NotesUrl,
					sslClientProfile: 'omsapi_client_profile',
					method: 'POST',
					contentType: 'application/json',
					data: CommentPayload,
					headers: {
						'osiApiToken': Token
					}
				};
				var info = " TargetURL: " + CommentPayloadPost.target + "; Method: " + CommentPayloadPost.method + "; Data: " + JSON.stringify(CommentPayloadPost.data) + ". ";
				try{
				urlopen.open(CommentPayloadPost, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'CrewAssignment Notes Update to OMS', details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						ctx.setVariable("retry", 'yes');
						var ErrorTxt = errorinfo
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						ctx.setVariable("ErrorTxt", ErrorTxt);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'CrewAssignment Notes Update to OMS', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = '200 OK';
									logger.debug("response received from NotesMessage :" + JSON.stringify(responseData));
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDescription', ExitDescription)
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'CrewAssignment Notes Update to OMS', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error response 'CrewAssignment Notes Update to OMS', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									hm.current.statusCode = responseStatusCode;
									logger.error(errorinfo);
									ctx.setVariable("retry", 'yes');
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo)
									var ErrorTxt = errorinfo
									ctx.setVariable("ErrorTxt", ErrorTxt);
								}
							})
						}
					}
				});
				} catch(err){
					var errorinfo = "url connection error 'CrewAssignment Notes Update to OMS', details are : " + info + "; error info :" + err
						logger.error(errorinfo);
						ctx.setVariable("retry", 'yes');
						var ErrorTxt = errorinfo
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						ctx.setVariable("ErrorTxt", ErrorTxt);
				}
			}

		}

	})
}
