var ctx = session.name("csyn_SOM") || session.createContext("csyn_SOM");
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var logger = console.options({ 'category': 'all' });

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {

		if (!(incomingdata.data[0].name == null || incomingdata.data[0].name == '' || incomingdata.data[0].name == undefined)) {
			ctx.setVariable("name", incomingdata.data[0].name);
		} else {
			logger.error('SOM_csyn_000 : Request input-- Name is null or undefined');
			session.reject("Request input : Name is null or undefined");
			return;
		}

		if (!(incomingdata.data[0].externalID == null || incomingdata.data[0].externalID == '' || incomingdata.data[0].externalID == undefined)) {
			ctx.setVariable("externalID", incomingdata.data[0].externalID);
		} else {
			logger.error('SOM_csyn_000 : Request input-- externalID is null or undefined');
			session.reject('Request input : externalID is null or undefined');
			return;
		}

		if (!(incomingdata.data[0].aorIDs == null || incomingdata.data[0].aorIDs == '' || incomingdata.data[0].aorIDs == undefined)) {
			ctx.setVariable("aorIDs", incomingdata.data[0].aorIDs);
		} else {
			logger.error('SOM_csyn_000 : Request input-- aorIDs is null or undefined');
			session.reject('Request input : aorIDs is null or undefined');
			return;
		}

		if (!(incomingdata.data[0].type == null || incomingdata.data[0].type == '' || incomingdata.data[0].type == undefined)) {
			ctx.setVariable("crewType", incomingdata.data[0].type);
		} else {
			logger.error('SOM_csyn_000 : Request input-- type is null or undefined');
			session.reject('Request input : type is null or undefined');
			return;
		}
        incomingdata.data[0].messageID = ilsCtx.getVariable('correlationID');
		var targetQueue = session.parameters.Queue;
		var options = {
			target: targetQueue,
			data: incomingdata
		};
        var exitTimestamp = new Date().toISOString();
		if (exitTimestamp !== undefined) {
			ilsCtx.setVariable('exitTimestamp', exitTimestamp);
		}
		var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
		try {
			urlopen.open(options, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var errorinfo = "MQurl open error Could not place message in Queue, details are : " + info + "; error info :" + error
					hm.response.statusCode = 500;
					logger.error("SOM_csyn_001 : " + errorinfo);
					exitTimestamp = new Date().toISOString();
					if (exitTimestamp !== undefined) {
						ilsCtx.setVariable('exitTimestamp', exitTimestamp);
					}
					session.reject("SOM_csyn_001 : " + errorinfo);
					
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								var errorinfo = "Error reading the response , details are : " + info + "; error info :" + readError
								hm.response.statusCode = 500
								logger.error(errorinfo);
								exitTimestamp = new Date().toISOString();
								if (exitTimestamp !== undefined) {
									ilsCtx.setVariable('exitTimestamp', exitTimestamp);
								}
								session.reject(errorinfo);
							} else {
								console.log("MQResponseData " + responseData);
							}
						});
					} else {
						var errorinfo = "Error Could not place message in Queue, details are : " + info + "; response info :" + response + "; ResponseStatusCode :" + response.statusCode
						hm.response.statusCode = 500
						logger.error("SOM_csyn_002 : " + errorinfo);
						exitTimestamp = new Date().toISOString();
						if (exitTimestamp !== undefined) {
							ilsCtx.setVariable('exitTimestamp', exitTimestamp);
						}
						session.reject("SOM_csyn_002 : " + errorinfo);
					}
				}
			});
			exitTimestamp = new Date().toISOString();
			if (exitTimestamp !== undefined) {
				ilsCtx.setVariable('exitTimestamp', exitTimestamp);
			}
		} catch (err) {
			var errorinfo = "MQurl open error Could not place message in Queue, details are : " + info + "; error info :" + err
			hm.response.statusCode = 500;
			logger.error("SOM_csyn_001 : " + errorinfo);
			exitTimestamp = new Date().toISOString();
					if (exitTimestamp !== undefined) {
						ilsCtx.setVariable('exitTimestamp', exitTimestamp);
					}
			session.reject("SOM_csyn_001 : " + errorinfo);
		}
	}
});
