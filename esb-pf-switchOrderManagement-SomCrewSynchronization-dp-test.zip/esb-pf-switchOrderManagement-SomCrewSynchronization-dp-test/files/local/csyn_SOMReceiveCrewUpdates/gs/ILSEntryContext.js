var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var crewTypeDisplayID = '';
function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data for ILS");
	} else {
		var lookupURL = session.parameters.lookupUrl;
		var crewID = '';
		if (!(incomingdata.data[0].externalID == null || incomingdata.data[0].externalID == '' || incomingdata.data[0].externalID == undefined)) {
			ilsCtx.setVariable('crewID', incomingdata.data[0].externalID);
		}
		var crewTypeID = '';
		if (!(incomingdata.data[0].type == null || incomingdata.data[0].type == '' || incomingdata.data[0].type == undefined)) {
			crewTypeID = incomingdata.data[0].type;
		}

		if (!(incomingdata.data[0].messageID == null || incomingdata.data[0].messageID == '' || incomingdata.data[0].messageID == undefined)) {
			ilsCtx.setVariable('correlationID', incomingdata.data[0].messageID);
		}

		

		var lookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "crewTypes",
						"status": crewTypeID
					},

				]
			}
		};
		var crewlookupService = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		var info = " TargetURL :" + crewlookupService.target + "; Method :" + crewlookupService.method + "; Data :" + JSON.stringify(crewlookupService.data) + ". ";
		try {
			urlopen.open(crewlookupService, function(error, response) {
				if (error) {
					var errorinfo = "url connection error 'crewlookupService', details are : " + info + "; error info :" + error
					logger.error(errorinfo);
					//session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response crewlookupService, details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								
								if (responseData.lookupRep.type[0].result == 0) {
									
									if ((responseData.lookupRep.type[0].label != undefined) && (responseData.lookupRep.type[0].label != null) && (responseData.lookupRep.type[0].label != '')) {
										
										 crewTypeDisplayID = responseData.lookupRep.type[0].label;
										 ilsCtx.setVariable('crewTypeDisplayID', crewTypeDisplayID);
										 
									}
								}
							}
						})
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response from  crewlookupService, details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								hm.current.statusCode = responseStatusCode;
								logger.error("Error returned from lookup call" + " : with statusCode " + responseStatusCode + " " + responseData);
							}
						});
					}
					
				}
		
			});

		}
		
		catch (err) {
			var errorinfo = "url connection error catch 'crewlookupService', details are : " + info + "; error info :" + err
			logger.error(errorinfo);
			//session.reject(errorinfo);
		}
	
		
      
		var sourceUrl = sm.getVar('var://service/URL-in');
	    var correlationID = uuidv4();
		var sourceEventTimestamp = new Date().toISOString();
		var messageType = session.parameters.messageType;
		var interfaceName = session.parameters.interfaceName;
		var EntryDescription = session.parameters.EntryDescription;
		var ExitDescription = session.parameters.ExitDescription;
		
		if (correlationID !== undefined) {
			ilsCtx.setVariable('correlationID',correlationID);
		}
		if (sourceUrl !== undefined) {
			ilsCtx.setVariable('sourceUrl', sourceUrl);
		}
		if (sourceEventTimestamp !== undefined) {
			ilsCtx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
                        ilsCtx.setVariable('exitTimestamp', sourceEventTimestamp);
		}
		if (messageType !== undefined) {
			ilsCtx.setVariable('messageType', messageType);
		}
		if (interfaceName !== undefined) {
			ilsCtx.setVariable('interfaceName', interfaceName);
		}
		
		if (crewTypeID !== undefined) {
			ilsCtx.setVariable('crewTypeID', crewTypeID);
		}
		if (EntryDescription !== undefined) {
			ilsCtx.setVariable('EntryDescription', EntryDescription);
		}
		if (ExitDescription !== undefined) {
			ilsCtx.setVariable('ExitDescription', ExitDescription);
		}
	}
});
