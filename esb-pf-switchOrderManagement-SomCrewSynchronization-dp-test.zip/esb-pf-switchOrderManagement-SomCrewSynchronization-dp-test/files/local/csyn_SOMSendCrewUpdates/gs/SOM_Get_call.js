var ctx = session.name('SOM') || session.createContext('SOM');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var somToken = session.parameters.somToken;
var ctx = session.name('SOM') || session.createContext('SOM');

session.input.readAsJSON(function(error, json) {
	if (error) {
		logger.error("Error in reading Json");
		session.reject("Error in reading Json");
	}
	else {
		var externalID = json.data[0].externalID;
		var somURL = session.parameters.somURL + "/api/Crew/External/" + externalID;


		var somCall = {
			target: somURL,
			sslClientProfile: 'OMS_SOM_Client_Profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': somToken
			}
		}
		var info = " TargetURL :" + somCall.target + "; Method :" + somCall.method + ". ";
		try {
			urlopen.open(somCall, function(error, response) {
				if (error) {
					var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to GET SOM api call,details are : " + info + "; error info :" + error;
					logger.error("SOM_csyn_006:" + ErrorTxt);
					ctx.setVariable("retry", 'yes');
					//session.reject("SOM_csyn_006 : " + ErrorTxt);
					
				}
				else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'somCall', details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.current.statusCode = responseStatusCode;
								ctx.setVariable("responseCode", responseStatusCode);
								var internalid = responseData.id;
								ctx.setVariable("internalid", internalid);
							}
						});
					} else {
						
						var errorinfo = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to GET SOM api call,details are : " + info + "; ResponseStatusCode :" + response.statusCode + "-" + response.reasonPhrase
						logger.error("SOM_csyn_023 : " + errorinfo);
						ctx.setVariable("retry", 'yes');
						ctx.setVariable("responseCode", responseStatusCode);
						//session.reject("SOM_csyn_023 : " + errorinfo);
						
						
					}
				}
			});
		} catch (err) {
			var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to GET SOM api call,details are : " + info + "; error info :" + err;
			logger.error("SOM_csyn_006:" + ErrorTxt);
			ctx.setVariable("retry", 'yes');
		}
	}
});
