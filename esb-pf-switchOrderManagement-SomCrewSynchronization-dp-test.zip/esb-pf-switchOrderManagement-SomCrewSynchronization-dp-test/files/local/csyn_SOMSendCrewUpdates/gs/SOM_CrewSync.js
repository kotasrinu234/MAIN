var ctx = session.name('SOM') || session.createContext('SOM');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var lookupUrl = session.parameters.lookupUrl;
var somlookupUrl = session.parameters.somlookupUrl;
var somToken = session.parameters.somToken;

var somURL;
var createURL;
var updateURL;
var externalID;

session.input.readAsJSON(function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		session.reject("Error in reading Json");
	} else {

		//Request body for SOM crewSync - Create & Update
		externalID = json.data[0].externalID;
		var createobj = {};
		createobj.name = json.data[0].name;
		createobj.externalID = json.data[0].externalID;
		createobj.phoneNumber = json.data[0].phoneNumber;
		createobj.email = json.data[0].email;
		//createobj.crewTypeID = ctx.getVar('crewTypeSOMid');
		createobj.aorIDs = ctx.getVar("aorsSOMLabelArray");
		createobj.customFieldValuesExt = {
			"Crew_ID": json.data[0].customFieldValuesExt.CrewID,
			"Employee_ID": json.data[0].customFieldValuesExt.employeeid,
			"Crew_Compliment": json.data[0].customFieldValuesExt.Crew_Compliment
		};

		ctx.setVariable("createobjresult", createobj);

		//Final SOM CALL for Crew Create & Update
		somURL = session.parameters.somURL + "/api/Crew/External/" + externalID;
		createURL = session.parameters.somURL + "/api/v1/Crew";

		var somCall = {
			target: somURL,
			sslClientProfile: 'OMS_SOM_Client_Profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': somToken
			}
		};
		var info = " TargetURL :" + somCall.target + "; Method :" + somCall.method + ". ";
		try {
			urlopen.open(somCall, function(error, response) {
				if (error) {
					var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to GET SOM api call,details are : " + info + "; error info :" + error
					logger.debug(ErrorTxt);
					logger.error("SOM_csyn_006: " + ErrorTxt);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						logger.error("Trace 1" + JSON.stringify(response));
						response.readAsJSON(function(error, responseData) {
							logger.error("Trace 2");
							if (error) {
								var errorinfo = "url connection error 'somCall', details are : " + info + "; error info :" + error
								logger.error("Trace 3");
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								logger.error("Trace 4");
								ctx.setVariable("responseData", responseData);
								logger.debug("Update Crew");
								var updateid = ctx.getVar('crewTypeSOMid');
								createobj.secondaryCrewTypeIDs = [updateid];
								var internalid = responseData.id;
								updateURL = session.parameters.somURL + "/api/v1/Crew/" + internalid;
								var updateCrew = {
									target: updateURL,
									sslClientProfile: 'OMS_SOM_Client_Profile',
									method: 'PATCH',
									contentType: 'application/json',
									data: createobj,
									headers: {
										'osiApiToken': somToken
									}
								};

								var info = " TargetURL :" + updateCrew.target + "; Method :" + updateCrew.method + "; Data :" + JSON.stringify(updateCrew.data) + ". ";
								try {
									urlopen.open(updateCrew, function(error, response) {
										if (error) {
											var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to PATCH SOM updateCrew call,details are : " + info + "; error info :" + error
											logger.debug(ErrorTxt);
											logger.error("SOM_csyn_007: " + ErrorTxt);
											ctx.setVariable("retry", 'yes');
											ctx.setVariable("ErrorTxt", ErrorTxt);
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsJSON(function(error, jsonresponse) {
													if (error) {
														// error while reading response or transferring data to Buffer
														var errorinfo = "error reading response with connecting to PATCH SOM updateCrew call,details are : " + info + "; error info :" + error
														logger.error(errorinfo);
													} else {
														logger.debug("crew updated successfully");
														ctx.setVariable("updated crew for" + externalID, jsonresponse);
													}
												})
											} else {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "Failure in reading meassage for PATCH SOM updateCrew call,details are : " + info + "; error info :" + error
														logger.error("SOM_csyn_008:" + errorinfo);
													} else {
														hm.current.statusCode = responseStatusCode;
														logger.error("Error returned from PATCH SOM api Crew Update Call" + " : with statusCode " + responseStatusCode + " " + responseData);
													}
												});
											}
										}
									})
								} catch (err) {
									var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to PATCH SOM updateCrew call,details are : " + info + "; error info :" + err
									logger.debug(ErrorTxt);
									logger.error("SOM_csyn_007: " + ErrorTxt);
									ctx.setVariable("retry", 'yes');
									ctx.setVariable("ErrorTxt", ErrorTxt);
								}
							}
						})

					}
					if (responseStatusCode == 404) {  // CrewSync Create Request
						logger.debug("Create Crew");
						createobj.crewTypeID = ctx.getVar('crewTypeSOMid');
						var createCrew = {
							target: createURL,
							sslClientProfile: 'OMS_SOM_Client_Profile',
							method: 'POST',
							contentType: 'application/json',
							data: createobj,
							headers: {
								'osiApiToken': somToken
							}
						};


						var info = " TargetURL :" + createCrew.target + "; Method :" + createCrew.method + "; Data :" + JSON.stringify(createCrew.data) + ". ";
						try {
							urlopen.open(createCrew, function(error, response) {
								if (error) {
									var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to POST SOM api Crew Create Call,details are : " + info + "; error info :" + error
									logger.debug(ErrorTxt);
									logger.error("SOM_csyn_009: " + ErrorTxt);
									ctx.setVariable("retry", 'yes');
									ctx.setVariable("ErrorTxt", ErrorTxt);
								}
								else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												// error while reading response or transferring data to Buffer
												var errorinfo = "error reading response with connecting to POST call for 'SOM createCrew',details are : " + info + "; error info :" + error
												logger.error(errorinfo);
											} else {
												logger.debug("crew created successfully");
												ctx.setVariable("crew created for" + externalID, responseData);
											}
										})
									}
									else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "Failure in reading mesaage of POST call for 'SOM createCrew',details are : " + info + "; error info :" + error
												logger.error(errorinfo);
											} else {
												hm.current.statusCode = responseStatusCode;
												logger.error("Error returned from POST SOM api Crew Create Call" + " : with statusCode " + responseStatusCode + " " + responseData);
											}
										});
									}
								}
							})
						} catch (err) {
							var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to POST SOM api Crew Create Call,details are : " + info + "; error info :" + err
							logger.debug(ErrorTxt);
							logger.error("SOM_csyn_009: " + ErrorTxt);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", ErrorTxt);
						}
					} else if (responseStatusCode == 401) {
						logger.error("SOM_csyn_011: SOM request is not authorized");
						session.reject("SOM Request : 401 Unauthorized")
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message from GET SOM api Crew  Call, details are : " + info + "; error info :" + error
								logger.error("SOM_csyn_020: " + errorinfo);
								session.reject("SOM_csyn_020: " + errorinfo);
							} else {
								hm.current.statusCode = responseStatusCode;
								logger.error("SOM_csyn_020:urlopen connect error failure in reading message from GET SOM api Crew  Call " + JSON.stringify(error));
								session.reject("SOM_csyn_020:urlopen connect error failure in reading message from GET SOM api Crew  Call " + JSON.stringify(error));
							}
						});
					}
				}
			})
		} catch (err) {
			var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to GET SOM api call,details are : " + info + "; error info :" + err
			logger.debug(ErrorTxt);
			logger.error("SOM_csyn_006: " + ErrorTxt);
			ctx.setVariable("retry", 'yes');
			ctx.setVariable("ErrorTxt", ErrorTxt);
		}
	}
});
