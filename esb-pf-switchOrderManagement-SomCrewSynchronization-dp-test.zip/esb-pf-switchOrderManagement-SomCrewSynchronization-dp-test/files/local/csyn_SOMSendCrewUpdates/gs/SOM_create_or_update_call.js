var ctx = session.name('SOM') || session.createContext('SOM');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var somToken = session.parameters.somToken;


session.input.readAsJSON(function(error, json) {
	if (error) {
		
		logger.error("Error in reading Json");
		session.reject("Error in reading Json");
	} else {
		logger.error("Trace 1"+JSON.stringify(json));
		var externalID = json.data[0].externalID;
		var createobj = {};
		createobj.name = json.data[0].name;
		createobj.externalID = json.data[0].externalID;
		createobj.phoneNumber = json.data[0].phoneNumber;
		createobj.email = json.data[0].email;
		//createobj.crewTypeID = ctx.getVar('crewTypeSOMid');
		createobj.aorIDs = ctx.getVar("aorsSOMLabelArray");
		createobj.customFieldValuesExt = {
			"Crew_ID": json.data[0].customFieldValuesExt.CrewID,
			"Employee_ID": json.data[0].customFieldValuesExt.employeeid,
			"Crew_Compliment": json.data[0].customFieldValuesExt.Crew_Compliment
		};
		var exitTimestamp = new Date().toISOString();
		if (exitTimestamp !== undefined) {
			ilsCtx.setVariable('exitTimestamp', exitTimestamp);
		}
		var statusCode = ctx.getVar("responseCode");
		logger.error("statusCode :"+statusCode);
		if (statusCode == 200) {

			//SOM CREW UPDATE call

			var internalid = ctx.getVar("internalid");
			var updateURL = session.parameters.somURL + "/api/v1/Crew/" + internalid;
			var somINID = ctx.getVar('crewTypeSOMid');
			createobj.secondaryCrewTypeIDs = [somINID];
			var updateCrew = {
				target: updateURL,
				sslClientProfile: 'OMS_SOM_Client_Profile',
				method: 'PATCH',
				contentType: 'application/json',
				data: createobj,
				headers: {
					'osiApiToken': somToken
				}
			};
			session.output.write(createobj);
			var info = " TargetURL :" + updateCrew.target + "; Method :" + updateCrew.method + "; Data :" + JSON.stringify(updateCrew.data) + ". ";
			try {
				urlopen.open(updateCrew, function(error, response) {
					if (error) {
						var errorinfo = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to PATCH SOM update apicall, details are : " + info + "; error info :" + error
						logger.error("SOM_csyn_007: " + errorinfo);
						ctx.setVariable("retry", 'yes');
						//var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to PATCH SOM update apicall" + JSON.stringify(error);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, jsonresponse) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "error reading response 'PATCH SOM update apicall', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.debug("crew updated successfully");
									ctx.setVariable("updated crew for" + externalID, jsonresponse);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "urlopen connect error failure in reading message from PATCH SOM api Crew Update Call, details are : " + info + "; error info :" + error
									logger.error("SOM_csyn_008: " + errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("Error returned from PATCH SOM api Crew Update Call" + " : with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}

					}

					if (exitTimestamp !== undefined) {
						ilsCtx.setVariable('exitTimestamp', exitTimestamp);
					}
				});

			} catch (err) {
				var errorinfo = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to PATCH SOM update apicall, details are : " + info + "; error info :" + err
				logger.error("SOM_csyn_007: " + errorinfo);
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to PATCH SOM update apicall" + JSON.stringify(error);
			}
		} else if (statusCode == 404) {

			//SOM CREW CREATE CALL 

			var createURL = session.parameters.somURL + "/api/v1/Crew";
			createobj.crewTypeID = ctx.getVar('crewTypeSOMid');
			var createCrew = {
				target: createURL,
				sslClientProfile: 'OMS_SOM_Client_Profile',
				method: 'POST',
				contentType: 'application/json',
				data: createobj,
				headers: {
					'osiApiToken': somToken
				}
			};
			session.output.write(createobj);
			var info = " TargetURL :" + createCrew.target + "; Method :" + createCrew.method + "; Data :" + JSON.stringify(createCrew.data) + ". ";
			try {
				urlopen.open(createCrew, function(error, response) {
					if (error) {
						var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to POST SOM api Crew Create Call, details are: " + info + "; error info :" + error
						logger.debug(ErrorTxt);
						logger.error("SOM_csyn_009:" + ErrorTxt);
						ctx.setVariable("retry", 'yes');
						ctx.setVariable("ErrorTxt", ErrorTxt);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "error reading response 'POST SOM api Crew Create Call', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.debug("crew created successfully");
									ctx.setVariable("crew created for" + externalID, responseData);

								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "urlopen connect error failure in reading message from POST SOM api Crew Create Call, details are : " + info + "; error info :" + error
									logger.error("SOM_csyn_010:" + errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("Error returned from POST SOM api Crew Create Call" + " : with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}
					}
				});
			} catch (err) {
				var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to POST SOM api Crew Create Call, details are: " + info + "; error info :" + err
				logger.debug(ErrorTxt);
				logger.error("SOM_csyn_009:" + ErrorTxt);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", ErrorTxt);
			}
			if (exitTimestamp !== undefined) {
				ilsCtx.setVariable('exitTimestamp', exitTimestamp);
			}
		}
		else {
			var ErrorTxt = "csyn_SOMSendCrewUpdate service is urlopen connect error with connecting to POST SOM api Crew Create Call,details are : " + info + "; error info :" + error;
			logger.error("Error in reading Json");
			logger.error("SOM_csyn_009: " + ErrorTxt);
			ctx.setVariable("ErrorTxt", ErrorTxt);
			//session.reject("Error in reading Json");

		}

	}


});
