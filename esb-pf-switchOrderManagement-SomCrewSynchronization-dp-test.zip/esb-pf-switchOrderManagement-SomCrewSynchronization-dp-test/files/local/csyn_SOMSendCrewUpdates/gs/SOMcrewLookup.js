var ctx = session.name('SOM') || session.createContext('SOM');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var lookupUrl = session.parameters.lookupUrl;
var somlookupUrl = session.parameters.somlookupUrl;
var somToken = session.parameters.somToken;

var somURL;
var createURL;
var updateURL;
var externalID;
var incommingCrewType;
var aorIDs;
var customFieldValuesExt;

var labelMap = new Map([
	['Substations', 'OPER'],
	['OH', 'OHL'],
	['UG', 'UGL'],
	['PSR', 'PSR']
])

session.input.readAsJSON(function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		session.reject("Error in reading Json");
	} else {
		var createobj = {};
		var aorsOMSLabelArray = [];
		var aorsSOMLabelArray = [];

		ctx.setVariable("MQResponse", json);
		externalID = json.data[0].externalID;
		ctx.setVariable("externalID", json.data[0].externalID);
		aorIDs = json.data[0].aorIDs;
		ctx.setVariable("aorIDs", json.data[0].aorIDs);
		incommingCrewType = json.data[0].type;
		ctx.setVariable("type", json.data[0].type);
		customFieldValuesExt = json.data[0].customFieldValuesExt;

		// Start OMS aorsIds Lookup 
		for (var i = 0; i < aorIDs.length; i++) {
			var aorsOMSLabel;
			var aorsSOMLabelid;
			var aorsSOMdefaultid;

			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "aors",
						"id": aorIDs[i]
					}]
				}
			}
			var aorsOMSlookup = {
				target: lookupUrl,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + aorsOMSlookup.target + "; Method :" + aorsOMSlookup.method + "; Data :" + JSON.stringify(aorsOMSlookup.data) + ". ";
			try {
				urlopen.open(aorsOMSlookup, function(error, response) {
					if (error) {
						var errorinfo = "OMSurlopen connect error with aorsOMSlookup, details are : " + info + "; error info :" + error
						logger.error("SOM_csyn_003 : " + errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							logger.info("aorsOMSlookup response status code 200");
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'aorsOMSlookup', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var lookupResponse = responseData;
									if (lookupResponse.lookupRep.type[0].result == 0) {
										if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
											aorsOMSLabel = lookupResponse.lookupRep.type[0].label;
											ctx.setVariable("aorsOMSLabel_" + [i] + "_", aorsOMSLabel);
											aorsOMSLabelArray.push(aorsOMSLabel);
											ctx.setVariable("aorsOMSLabelArray", aorsOMSLabelArray);
										} else {
											aorsOMSLabel = "";
										}
									} else {
										aorsOMSLabel = "";
									}

									//  Start SOM aorIds lookup
									var lookupMessage = {
										"lookupReq": {
											"type": [
												{
													"name": "aorsId",
													"label": aorsOMSLabel
												}]
										}
									}
									var aorsSOMlookup = {
										target: somlookupUrl,
										method: 'POST',
										contentType: 'application/json',
										data: lookupMessage
									};

									var info = " TargetURL :" + aorsSOMlookup.target + "; Method :" + aorsSOMlookup.method + "; Data :" + JSON.stringify(aorsSOMlookup.data) + ". ";
									try {
										var somlookupstring = "SOMLookup";
										lookup(somlookupstring, aorsSOMlookup, function(error, responseData) {
											if (error) {
												var errorinfo = "url connection error 'aorsSOMlookup', details are : " + info + "; error info :" + error
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var lookupResponse = responseData;
												if (lookupResponse.lookupRep.type[0].result == 0) {
													if ((lookupResponse.lookupRep.type[0].id != undefined) && (lookupResponse.lookupRep.type[0].id != null) && (lookupResponse.lookupRep.type[0].id != '')) {
														aorsSOMLabelid = lookupResponse.lookupRep.type[0].id;
														ctx.setVariable("aorsSOMLabelid_" + [i] + "_", aorsSOMLabelid);
														aorsSOMLabelArray.push(aorsSOMLabelid);
														ctx.setVariable("aorsSOMLabelArray", aorsSOMLabelArray);
													} else {
														aorsSOMLabelid = "";
													}
												} else {
													aorsSOMLabelid = "";
												}

												if (aorsSOMLabelid === undefined || aorsSOMLabelid === null) {
													var aor_somlookupMessage = {
														"lookupReq": {
															"type": [
																{
																	"name": "aorsId",
																	"label": 'DTE'
																}]
														}
													}
													var aor_somlookupService = {
														target: somlookupUrl,
														method: 'POST',
														contentType: 'application/json',
														data: aor_somlookupMessage
													};

													var info = " TargetURL :" + aor_somlookupService.target + "; Method :" + aor_somlookupService.method + "; Data :" + JSON.stringify(aor_somlookupService.data) + ". ";
													try {
														lookup(somlookupstring, aor_somlookupService, function(error, responseData) {
															if (error) {
																var errorinfo = "url connection error 'aor_somlookupService', details are : " + info + "; error info :" + error
																logger.error(errorinfo);
															} else {
																var lookupResponse = responseData;
																if (lookupResponse.lookupRep.type[0].result == 0) {
																	if ((lookupResponse.lookupRep.type[0].id != undefined) && (lookupResponse.lookupRep.type[0].id != null) && (lookupResponse.lookupRep.type[0].id != '')) {
																		aorsSOMdefaultid = lookupResponse.lookupRep.type[0].id;
																		ctx.setVariable("aorsSOMdefaultid", aorsSOMdefaultid);
																		aorsSOMLabelArray.push(aorsSOMdefaultid);
																		ctx.setVariable("aorsSOMLabelArray", aorsSOMLabelArray);
																	} else {
																		aorsSOMdefaultid = "";
																	}
																} else {
																	aorsSOMdefaultid = "";
																	session.reject("Lookup data is not matched with OMS_aorsId & SOM_aorsId");
																}
															}
														})
													} catch (err) {
														var errorinfo = "url connection error aor_somlookupService, details are : " + info + "; error info :" + err
														logger.error(errorinfo);
													}
												} else {
													var uniqueChars = [...new Set(aorsSOMLabelArray)];
													ctx.setVariable("aorsSOMLabelArray", uniqueChars);
												}
											}
										})
									} catch (err) {
										var errorinfo = "url connection error aorsSOMlookup, details are : " + info + "; error info :" + err
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
									// End SOM aorIds lookup
								}
							});
						}
					}
				});
			} catch (err) {
				var errorinfo = "url connection error aorsOMSlookup, details are : " + info + "; error info :" + err
				logger.error("SOM_csyn_003 : " + errorinfo);
				session.reject(errorinfo);
			}
		} // End OMS aorIds lookup

		//CrewType OMS  Lookup
		var crewTypeOMSLabel;
		var crewTypeSOMid;
		var Omsstring = "OMSLookup";
		var lookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "crewTypes",
						"status": incommingCrewType
					}]
			}
		}
		var crewTypelookupService = {
			target: lookupUrl,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		var info = " TargetURL :" + crewTypelookupService.target + "; Method :" + crewTypelookupService.method + "; Data :" + JSON.stringify(crewTypelookupService.data) + ". ";
		try {
			lookup(Omsstring, crewTypelookupService, function(error, responseData) {
				if (error) {
					var errorinfo = "url connection error 'crewTypelookupService', details are : " + info + "; error info :" + error
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var lookupResponse = responseData;
					if (lookupResponse.lookupRep.type[0].result == 0) {
						if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
							crewTypeOMSLabel = lookupResponse.lookupRep.type[0].label;
							ctx.setVariable("crewTypeOMSLabel", crewTypeOMSLabel);
						} else {
							crewTypeOMSLabel = "";
						}
					} else {
						crewTypeOMSLabel = "";
					}
					//CrewType SOM  Lookup
					if ((crewTypeOMSLabel == "Substations" || crewTypeOMSLabel == "OH" || crewTypeOMSLabel == "UG" || crewTypeOMSLabel == "PSR")) {
						var crewType = labelMap.get(crewTypeOMSLabel);
						var somlookupMessage = {
							"lookupReq": {
								"type": [{
									"name": "crewTypes",
									"label": crewType
								}]
							}
						}
						var somlookupService = {
							target: somlookupUrl,
							method: 'POST',
							contentType: 'application/json',
							data: somlookupMessage
						};
						var info = " TargetURL :" + somlookupService.target + "; Method :" + somlookupService.method + "; Data :" + JSON.stringify(somlookupService.data) + ". ";
						try {
							var SomLookupstring = "SOMLookupCrewType"
							lookup(SomLookupstring, somlookupService, function(error, responseData) {
								if (error) {
									var errorinfo = "url connection error 'somlookupService', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
								} else {
									var lookupResponse = responseData;
									if (lookupResponse.lookupRep.type[0].result == 0) {
										if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
											crewTypeSOMid = lookupResponse.lookupRep.type[0].id;
											ctx.setVariable("crewTypeSOMid", crewTypeSOMid);
										} else {
											crewTypeSOMid = "";
										}
									} else {
										crewTypeSOMid = "";
									}
								}
							})
						} catch (err) {
							var errorinfo = "url connection error somlookupService, details are : " + info + "; error info :" + err
							logger.error(errorinfo);
						}
					} else {
						session.reject("Failure in matching the OMS crewType with SOM crewType");
					}  //END CrewType SOM Lookup
				}
			})
		} catch (err) {
			var errorinfo = "url connection error crewTypelookupService, details are : " + info + "; error info :" + err
			logger.error(errorinfo);
			session.reject(errorinfo);
		}// End CrewType OMS lookup
	}
});

function lookup(string, url, data) {
	try {
		urlopen.open(url, function(error, response) {
			if (error) {
				// an error occurred during request sending or response header parsing
				if (string == "SOMLookup") {
					logger.error("SOM_csyn_004 : SOMurlopen connect error with aorsSOMlookup" + JSON.stringify(error));
					session.reject("urlopen connect error with aorsSOMlookup" + JSON.stringify(error));
				} else if (string == "OMSLookup") {
					logger.error("SOM_csyn_005 : OMSurlopen connect error with CrewTypeOMSlookup" + JSON.stringify(error));
					session.reject("urlopen connect error with CrewTypeOMSlookup" + JSON.stringify(error));
				} else if (string == "SOMLookupCrewType") {
					logger.error("SOM_csyn_006 : SOMurlopen connect error with CrewTypeSOMlookup" + JSON.stringify(error));
					session.reject("urlopen connect error with CrewTypeSOMlookup" + JSON.stringify(error));
				}
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							logger.error("failure in reading message from  lookup call" + JSON.stringify(error));
							data(error, null);
						} else {
							hm.response.statusCode = '200 Message is received';
							logger.debug("response received from Lookup api:" + responseData);
							data(null, responseData);
						}
					})
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error("SOM_csyn_007 : Lookup urlopen connect error failure in reading message from lookup call " + JSON.stringify(error));
							session.reject("failure in reading message from  lookup call ");
						} else {
							hm.current.statusCode = responseStatusCode;
							logger.error("Error returned from lookup call" + " : with statusCode " + responseStatusCode + " " + responseData);
							data("Error returned from lookup call" + " : with statusCode " + responseStatusCode, null);

						}
					});
				}
			}
		});
	} catch (err) {
		if (string == "SOMLookup") {
			logger.error("SOM_csyn_004 : SOMurlopen connect error with aorsSOMlookup" + JSON.stringify(error));
			session.reject("urlopen connect error with aorsSOMlookup" + JSON.stringify(error));
		} else if (string == "OMSLookup") {
			logger.error("SOM_csyn_005 : OMSurlopen connect error with CrewTypeOMSlookup" + JSON.stringify(error));
			session.reject("urlopen connect error with CrewTypeOMSlookup" + JSON.stringify(error));
		} else if (string == "SOMLookupCrewType") {
			logger.error("SOM_csyn_006 : SOMurlopen connect error with CrewTypeSOMlookup" + JSON.stringify(error));
			session.reject("urlopen connect error with CrewTypeSOMlookup" + JSON.stringify(error));
		}
	}
}
