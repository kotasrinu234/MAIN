<?xml version="1.0" encoding="utf-8"?>
<!-- This XLST is used to fetch the MQMD headers and place them in the context 
	variables in order to access them in the error rule Date: 1st October 
	2019 Author: Sushma Yarlagadda -->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date msxsl dyn">
	<xsl:output method="text" encoding="utf-8"/>
	<xsl:template match="/">
		<dp:set-variable name="'var://context/store/msgId'"
			value="'1'" />

		<!-- Fetching the MQMD headers -->
		<xsl:variable name="entriesMQMD" select="dp:request-header('MQMD')" />
		<xsl:variable name="entriesMQRFH2" select="dp:request-header('MQRFH2')" />

		<!-- Parsing the string MQMD headers to XML format -->
		<xsl:if test="normalize-space($entriesMQMD)!=''">
		<xsl:variable name="mqmd-headers" select="dp:parse($entriesMQMD)" />
		<dp:set-variable name="'var://context/MQMD/MQMDRequestHeaders'"
			value="$mqmd-headers" />
		</xsl:if>
        <xsl:if test="normalize-space($entriesMQRFH2)!=''">
		<xsl:variable name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)" />
		<!-- Placing the MQMD headers in the context variables -->		
		<dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value="$mqrfh2-headers" />
		</xsl:if>

	</xsl:template>
</xsl:stylesheet>
