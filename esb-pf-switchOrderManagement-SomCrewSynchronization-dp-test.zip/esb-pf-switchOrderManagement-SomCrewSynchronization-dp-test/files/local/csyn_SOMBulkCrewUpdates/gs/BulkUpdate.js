var urlopen = require('urlopen');
var fs = require('fs');
var util = require('util');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data" + incomingdata);
	}
	else {
		var somToken = session.parameters.somToken
		var Updatebulk = ctx.getVariable("finalupdateArray");
		var result = [];
		function chunkArray(array, chunk_size, result) {
			while (array.length) {
				result.push(array.splice(0, chunk_size));
			}
			return result;
		};
		var UpdateChunks = [];
		var count = session.parameters.count;
		var BulkUpdateChunks;
		if(Updatebulk !== undefined && Updatebulk !== null && Updatebulk !== ''){
		BulkUpdateChunks = chunkArray(Updatebulk, count, UpdateChunks);
		}

		function makeRequest(update, finalupdateobj) {
			return new Promise(function(resolve, reject) {
				var info = " TargetURL :" + update.target + "; Method :" + update.method + "; Data :" + JSON.stringify(update.data) + ". ";
				urlopen.open(update, function(error, response) {
					if (error) {
						var ErrorTxt = "csyn_SOMBulkCrewUpdates service is urlopen connect error with connecting to  PATCH SOM Bulk Update api call,details are : " + info + "; error info :" + error
						ctx.setVariable("retry", 'yes');
						logger.debug(ErrorTxt);
						logger.error("SOM_csyn_020 :" + ErrorTxt);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						reject(ErrorTxt);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'PATCH SOM Bulk Update api call', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									reject(errorinfo);
								} else {
									resolve(responseData);
								}
							});
						}
						else if (responseStatusCode == 404) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'PATCH SOM Bulk Update api call', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
								} else {
									function makeRequest1(update1) {
										return new Promise(function(resolve, reject) {
											var info = " TargetURL :" + update1.target + "; Method :" + update1.method + "; Data :" + JSON.stringify(update1.data) + ". ";
											urlopen.open(update1, function(error, response) {
												if (error) {
													var ErrorTxt = "csyn_SOMBulkCrewUpdates service urlopen connect error with connecting to  PATCH SOM Single Update api call, details are : " + info + "; error info :" + error
													ctx.setVariable("retry", 'yes');
													logger.debug(ErrorTxt);
													logger.error("SOM_csyn_021 :" + ErrorTxt);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													reject(ErrorTxt);
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response 'PATCH SOM Single Update api call', details are : " + info + "; error info :" + error
																logger.error(errorinfo);
																reject(errorinfo);
															} else {
																resolve(responseData);
															}
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response 'PATCH SOM Single Update api call', details are : " + info + "; error info :" + error
																logger.error(errorinfo);
															} else {
																logger.error("Error returned " + ": with statusCode " + responseStatusCode + " " + responseData);
															}
														});
													}
												}
											});
										});
									}
									async function main1() {
										var finalupdateobjkeys = Object.keys(finalupdateobj);
										for (var s = 0; s < finalupdateobjkeys.length; s++) {
											var singledata = finalupdateobj[finalupdateobjkeys[s]];
											var singleEID1 = finalupdateobjkeys[s];

											var singleEID = singleEID1.replace(/\s/g, "%20");

											var updateURL = session.parameters.somURL + "/api/v1/Crew/External/" + singleEID;
											var update1 = {
												target: updateURL,
												sslClientProfile: 'OMS_SOM_Client_Profile',
												method: 'PATCH',
												contentType: 'application/json',
												data: singledata,
												headers: {
													'osiApiToken': somToken
												}
											};
											try {
												var responseData = await makeRequest1(update1);
												hm.response.statusCode = '200 OK';
												logger.debug("response received :" + JSON.stringify(responseData));
											} catch (error) {
												hm.current.statusCode = responseStatusCode;
												logger.error(error);
												session.reject(error);
											}
											if (s == count - 1) {
												resolve(responseData);
											}
										}
									}
									main1();
								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'PATCH SOM Bulk Update api call', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
								} else {
									logger.error("Error returned " + ": with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}
					}
				});
			});
		}
		async function main() {
			if(BulkUpdateChunks !== undefined && BulkUpdateChunks !== null && BulkUpdateChunks !== ''){
			
			  for (var i = 0; i < BulkUpdateChunks.length; i++) {
				var finalupdateobj = {};
				var bulkupdatearray = BulkUpdateChunks[i];
				for (var k = 0; k < bulkupdatearray.length; k++) {
					var objkeys = Object.keys(bulkupdatearray[k]);
					var objvalues = bulkupdatearray[k][objkeys];
					finalupdateobj[objkeys] = objvalues;
				}
				var updateURL = session.parameters.somURL + "/api/v1/crew/bulk";
				var update = {
					target: updateURL,
					sslClientProfile: 'OMS_SOM_Client_Profile',
					method: 'PATCH',
					contentType: 'application/json',
					data: finalupdateobj,
					headers: {
						'osiApiToken': somToken
					},
				};
				try {
					var responseData = await makeRequest(update, finalupdateobj);
					hm.response.statusCode = '200 OK';
					logger.debug("response received :" + JSON.stringify(responseData));
				} catch (error) {
					hm.current.statusCode = responseStatusCode;
					logger.error(error + "error in upadte call" + responseStatusCode);
					session.reject(error);
				}



			}
		  }
		}
		main();
	}
}); 
