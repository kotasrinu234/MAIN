var urlopen = require('urlopen');
var fs = require('fs');
var util = require('util');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
    'category': 'all'
});
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
 var exitTimestamp = new Date().toISOString();
		if (exitTimestamp !== undefined) {
			ilsCtx.setVariable('exitTimestamp', exitTimestamp);
		}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata){
	if (readAsJSONError){
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data" + incomingdata);
	}else {
		var somToken = session.parameters.somToken;
		var Createbulk = ctx.getVariable("finalcreateArray");
		var result = [];
		function chunkArray (array, chunk_size, result){
			while (array.length){
				result.push(array.splice(0, chunk_size));
			}
			return result;
		}
		var CreateChunks = [];
		var count = session.parameters.count;
		
		var BulkCreateChunks;
		if(Createbulk !== undefined && Createbulk !== null && Createbulk !== ''){
		  BulkCreateChunks = chunkArray(Createbulk, count, CreateChunks);
		}
		function makeRequest(create) {
			return new Promise(function(resolve, reject) {
				var info = " TargetURL :" + create.target + "; Method :" + create.method + "; Data :" + JSON.stringify(create.data) + ". "; 
				urlopen.open(create, function(error, response) {
					if (error) {
						var ErrorTxt = "csyn_SOMBulkCrewUpdates service is urlopen connect error with connecting to backend SOM bulk create  api,details are : " + info + "; error info :" + error
						ctx.setVariable("retry", 'yes');
						logger.debug(ErrorTxt);
						logger.error("SOM_csyn_022 :" + ErrorTxt);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						reject(ErrorTxt);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response to backend 'SOM bulk create  api', details are : " + info + "; error info :" + error
									reject(errorinfo);
								} else {
									resolve(responseData);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response to backend 'SOM bulk create  api', details are : " + info + "; error info :" + error
									reject(errorinfo);
								} else {
									reject("Error returned " + ": with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}
					}
				});
			});
		}
		async function main() {
			var finalcreateobj = {};
			if(BulkCreateChunks !== undefined && BulkCreateChunks !== null && BulkCreateChunks !== ''){
			for (var i = 0; i < BulkCreateChunks.length; i++){
				var arr = [];
				var insidechunks = BulkCreateChunks[i];
				for (var l = 0; l < insidechunks.length; l++){
					arr.push(insidechunks[l]);
				}
				finalcreateobj.crews = arr;
				var createURL = session.parameters.somURL + "/api/v1/crew/bulk";
				var create = {
					target: createURL,
					sslClientProfile: 'OMS_SOM_Client_Profile',
					method: 'POST',
					contentType: 'application/json',
					data: finalcreateobj,
					headers: {
					'osiApiToken': somToken
					}
				};
				try {
					var responseData = await makeRequest(create);
					hm.response.statusCode = '200 OK';
					logger.debug("response received :" + JSON.stringify(responseData));
				} catch (error) {
					var errorinfo = "urlopen connect error with connecting to Bulk create call SOM api call, details are : " + info + "; error info :" + error
					hm.current.statusCode = responseStatusCode;
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			}
		}
		}
		main();
		if (exitTimestamp !== undefined) {
			ilsCtx.setVariable('exitTimestamp', exitTimestamp);
		}
	}
});
