var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var labelArray = [];
var somlabelArray = [];

var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
var checkretry = ctx.getVariable("retry");
if (checkretry != 'yes') {
	var lookupURL = session.parameters.lookupUrl;
	var somlookupURL = session.parameters.somlookupUrl;
	var aors = ctx.getVariable("aors");
	var uniquetypeValue = [...new Set(aors)];
	ctx.setVariable("uniquetypeValue", uniquetypeValue);

	session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

		if (readAsJSONError) {
			logger.error("Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {
			var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
			var resArray = ctx.getVariable("GetListOfCrewVariable");

			for (var a = 0; a < uniquetypeValue.length; a++) {
				let aorValue = uniquetypeValue[a];
				var lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "aors",
								"id": uniquetypeValue[a]

							}

						]
					}
				};
				var joblookupService = {
					target: lookupURL,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};

				var info = " TargetURL :" + joblookupService.target + "; Method :" + joblookupService.method + "; Data :" + JSON.stringify(joblookupService.data) + ". ";
				try {
					urlopen.open(joblookupService, function(error, response) {
						if (error) {
							var errorinfo = "url connection error of lookup call for 'joblookupService', details are : " + info + "; error info :" + error
							logger.error(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "Failure in reading the message for Crewtype LookupServiceResponse, details are : " + info + "; error info :" + error
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										ctx.setVariable("lookupres", responseData);
										if (responseData.lookupRep.type[0].result == 0) {
											if ((responseData.lookupRep.type[0].label != undefined) && (responseData.lookupRep.type[0].label != null) && (responseData.lookupRep.type[0].label != '')) {
												//var label = responseData.lookupRep.type[0].label;
												var label = responseData.lookupRep.type[0].label;
												var obj = {
													'aor': aorValue,
													'label': label
												};
												//labelArray.push(obj);

												//ctx.setVariable("aors1", labelArray);
												var somlookupMessage = {
													"lookupReq": {
														"type": [

															{
																"name": "aorsId",
																"label": label
															}

														]
													}
												};

												var somlookupService = {
													target: somlookupURL,
													method: 'POST',
													contentType: 'application/json',
													data: somlookupMessage
												};
												var info = " TargetURL :" + somlookupService.target + "; Method :" + somlookupService.method + "; Data :" + JSON.stringify(somlookupService.data) + ". ";
												try {
													urlopen.open(somlookupService, function(error, responseData) {
														if (error) {
															var errorinfo = "Failure in reading the message for somlookupService, details are : " + info + "; error info :" + error
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															//var id;
															var responseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {

																response.readAsJSON(function(error, responseData) {
																	if (error) {
																		var errorinfo = "Failure in reading the message for 'somlookupService', details are : " + info + "; error info :" + error
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		ctx.setVariable("somres", responseData);
																		if (responseData.lookupRep.type[0].result == 0) {
																			if ((responseData.lookupRep.type[0].id != undefined) && (responseData.lookupRep.type[0].id != null) && (responseData.lookupRep.type[0].id != '')) {
																				var aor_id = responseData.lookupRep.type[0].id;
																				somlabelArray.push(aor_id);
																				ctx.setVariable("somaor", somlabelArray);
																			}
																			else {

																				var aor_id = "";
																			}
																		}
																		else {
																			var aor_id = "";
																		}
																	}
																})
															}
															else {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		//dp:reject stop the transaction and go error rule with error code and description
																		var errorinfo = "Failure in reading the message for somlookupService, details are : " + info + "; error info :" + error
																		logger.error(errorinfo);
																		session.reject(errorinfo);																		//session.reject("failure in reading message from lookup call ");
																	} else {
																		hm.current.statusCode = responseStatusCode;
																		logger.error("Error returned from lookup call" + " : with statusCode " + responseStatusCode + " " + responseData);
																		data("Error returned from lookup call" + " : with statusCode " + responseStatusCode, null);

																	}
																})
															}


														}
													})
												} catch (err) {
													var errorinfo = "Failure in reading the message for somlookupService, details are : " + info + "; error info :" + err
													logger.error(errorinfo);
													session.reject(errorinfo);
												}
											}
											else {
												var aorlabel = "";
											}

										}
										else {
											var aorlabel = "";

										}
									}
								})
							}
							else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										var errorinfo = "Failure in reading the message from lookup call, details are : " + info + "; error info :" + error
										logger.error(errorinfo);
										session.reject(errorinfo);
										//session.reject("failure in reading message from lookup call ");
									} else {
										hm.current.statusCode = responseStatusCode;
										logger.error("Error returned from lookup call" + " : with statusCode " + responseStatusCode + " " + responseData);
										data("Error returned from lookup call" + " : with statusCode " + responseStatusCode, null);

									}
								})
							}
						}
					})
				} catch (err) {
					var errorinfo = "Failure in reading the message from lookup call, details are : " + info + "; error info :" + err
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			}
		}
	})
}
