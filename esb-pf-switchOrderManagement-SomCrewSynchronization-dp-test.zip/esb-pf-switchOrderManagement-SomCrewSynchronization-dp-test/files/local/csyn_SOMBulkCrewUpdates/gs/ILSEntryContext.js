var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ilsCtx = session.name('ILS') || session.createContext('ILS');

function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data for ILS");
		
	} else {
		   

		   var sourceUrl = sm.getVar('var://service/URL-in');
		   var correlationID = uuidv4();
		   var sourceEventTimestamp= new Date().toISOString();
		   var messageType = session.parameters.messageType;
		   var interfaceName = session.parameters.interfaceName;
		   var EntryDescription = session.parameters.EntryDescription;
		   var ExitDescription = session.parameters.ExitDescription;
		   var ExitDestination = session.parameters.somURL;
		   
		   if (sourceUrl !== undefined) {
		    ilsCtx.setVariable('sourceUrl',sourceUrl);
		   }
		   if (correlationID !== undefined) {
			ilsCtx.setVariable('correlationID',correlationID);
		   }
		   if (sourceEventTimestamp !== undefined) {
			ilsCtx.setVariable('sourceEventTimestamp',sourceEventTimestamp);
			ilsCtx.setVariable('exitTimestamp',sourceEventTimestamp);
		   }
		   if (messageType !== undefined) {
			ilsCtx.setVariable('messageType',messageType);
		   }
		    if (interfaceName !== undefined) {
			ilsCtx.setVariable('interfaceName',interfaceName);
			}
			
			if (EntryDescription !== undefined) {
			ilsCtx.setVariable('EntryDescription',EntryDescription);
			}
			if (ExitDescription !== undefined) {
			ilsCtx.setVariable('ExitDescription',ExitDescription);
			}
			if (ExitDestination !== undefined) {
			ilsCtx.setVariable('ExitDestination',ExitDestination);
			}
		   
	}
});
