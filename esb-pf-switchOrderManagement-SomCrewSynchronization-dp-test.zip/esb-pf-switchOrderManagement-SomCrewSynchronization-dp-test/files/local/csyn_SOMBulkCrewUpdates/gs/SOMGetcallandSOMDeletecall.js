var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
var checkretry = ctx.getVariable("retry");
if (checkretry != 'yes') {
	var somcrewlist = [];
	var delexternalID = [];
	var somcrewEID = [];
	var Exid = [];
	var omscrewEID = [];
	var Createobj = {};
	var finalupdateArray = [];
	var finalcreateArray = [];
	session.input.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			logger.error("Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {
			var somURL = session.parameters.somURL + "/api/v1/Crew" + '?includeFields=externalID,id,deprecated';
			var somToken = session.parameters.somToken;
			if ((somURL == undefined) || (somURL == '') || (somURL == null)) {
				logger.error("somURL is missing" + JSON.stringify(error));
				session.reject("somURL is missing");
			} else {
				var som = {
					target: somURL,
					sslClientProfile: 'OMS_SOM_Client_Profile',
					method: 'GET',
					contentType: 'application/json',
					headers: {
						'osiApiToken': somToken
					}
				};
				var info = " TargetURL :" + som.target + "; Method :" + som.method + ". ";
				try {
					urlopen.open(som, function(error, response) {
						if (error) {
							var ErrorTxt = "service csyn_SOMBulkCrewUpdates urlopen connect error with SOMapi GET Call for get crew list,details are : " + info + "; error info :" + error
							logger.error("SOM_csyn_018 : " + ErrorTxt);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", ErrorTxt);
							//session.reject("error in som urlopen GET call, " +"Errorcode:" +rescode);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "som url connection error GET Call, details are : " + info + "; error info :" + error
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										somcrewlist = responseData.data;
										var result = somcrewlist;
										for (var i = 0; i < result.length; i++) {
											somcrewEID.push(result[i].externalID);
										}
										//ctx.setVariable("somcrewEID", somcrewEID);
										//ctx.setVariable("somcrewlist", somcrewlist);
										var omscrewlist = ctx.getVariable("GetListOfCrewVariable");
										var result = omscrewlist;
										for (var b = 0; b < result.length; b++) {
											omscrewEID.push(result[b].externalID);
										}
										var typeArray = ctx.getVariable("array");
										for (var a = 0; a < omscrewEID.length; a++) {
											if (somcrewEID.includes(omscrewEID[a])) {
												var id1 = omscrewEID[a];
												var pos = somcrewlist.map(function(e) { return e.externalID; }).indexOf(id1);
												if ((omscrewlist[a].deprecated == true) && (somcrewlist[pos].deprecated == false) && ((omscrewlist[a].type == 13) || (omscrewlist[a].type == 21) || (omscrewlist[a].type == 20) || (omscrewlist[a].type == 24))) {

													delexternalID.push(omscrewlist[a].externalID);

												} else if ((omscrewlist[a].deprecated == false) && ((omscrewlist[a].type == 13) || (omscrewlist[a].type == 21) || (omscrewlist[a].type == 20) || (omscrewlist[a].type == 24))) {
													//Set the payload for Bulk SOM update call

													if (omscrewlist[a].type == 13) {
														var a1 = typeArray.map(function(f) { return f.type; }).indexOf(13);
														var intid = typeArray[a1].id;
														var aorid = typeArray[a1].aorid;
													}
													else if (omscrewlist[a].type == 21) {
														var a2 = typeArray.map(function(g) { return g.type; }).indexOf(21);
														var intid = typeArray[a2].id;
														var aorid = typeArray[a2].aorid;
													}
													else if (omscrewlist[a].type == 20) {
														var a3 = typeArray.map(function(h) { return h.type; }).indexOf(20);
														var intid = typeArray[a3].id;
														var aorid = typeArray[a3].aorid;
													}
													else if (omscrewlist[a].type == 24) {
														var a4 = typeArray.map(function(x) { return x.type; }).indexOf(24);
														var intid = typeArray[a4].id;
														var aorid = typeArray[a4].aorid;
													}

													Exid = omscrewlist[a].externalID;
													var customobj = {};
													customobj.Crew_ID = omscrewlist[a].customFieldValuesExt.CrewID;
													customobj.Employee_ID = omscrewlist[a].customFieldValuesExt.employeeid;
													customobj.Crew_Compliment = omscrewlist[a].customFieldValuesExt.Crew_Compliment;

													var extobj = {};
													extobj.name = omscrewlist[a].name;
													extobj.aorIDs = [aorid];
													extobj.email = omscrewlist[a].email;
													extobj.phoneNumber = omscrewlist[a].phoneNumber;
													extobj.externalID = omscrewlist[a].externalID;
													extobj.secondaryCrewTypeIDs = [intid];
													extobj.customFieldValuesExt = customobj;
													var Updateobj = {};
													Updateobj[Exid] = extobj;
													finalupdateArray.push(Updateobj);
												}
											} else {
												// Set the payload for bulk SOM create call
												if (((omscrewlist[a].deprecated == false)) && ((omscrewlist[a].type == 13) || (omscrewlist[a].type == 21) || (omscrewlist[a].type == 20) || (omscrewlist[a].type == 24))) {

													if (omscrewlist[a].type == 13) {
														var a1 = typeArray.map(function(f) { return f.type; }).indexOf(13);
														var intid = typeArray[a1].id;
														var aorid = typeArray[a1].aorid;
													}
													else if (omscrewlist[a].type == 21) {
														var a2 = typeArray.map(function(g) { return g.type; }).indexOf(21);
														var intid = typeArray[a2].id;
														var aorid = typeArray[a2].aorid;
													}
													else if (omscrewlist[a].type == 20) {
														var a3 = typeArray.map(function(h) { return h.type; }).indexOf(20);
														var intid = typeArray[a3].id;
														var aorid = typeArray[a3].aorid;
													}
													else if (omscrewlist[a].type == 24) {
														var a4 = typeArray.map(function(x) { return x.type; }).indexOf(24);
														var intid = typeArray[a4].id;
														var aorid = typeArray[a4].aorid;
													}

													var customobj = {};
													customobj.Crew_ID = omscrewlist[a].customFieldValuesExt.CrewID;
													customobj.Employee_ID = omscrewlist[a].customFieldValuesExt.employeeid;
													customobj.Crew_Compliment = omscrewlist[a].customFieldValuesExt.Crew_Compliment;

													var extobj = {};
													extobj.name = omscrewlist[a].name;
													extobj.externalID = omscrewlist[a].externalID;
													extobj.crewTypeID = intid;
													extobj.aorIDs = [aorid];
													extobj.email = omscrewlist[a].email;
													extobj.phoneNumber = omscrewlist[a].phoneNumber;
													extobj.customFieldValuesExt = customobj;
													finalcreateArray.push(extobj);
												}
											}
										}

										ctx.setVariable("finalupdateArray", finalupdateArray);
										ctx.setVariable("finalcreateArray", finalcreateArray);
										//delete

										//ctx.setVariable("SOM delete call array  ", delexternalID);

										function makeRequest(somdel) {
											return new Promise(function(resolve, reject) {
												var info = " TargetURL :" + somdel.target + "; Method :" + somdel.method + ". ";
												urlopen.open(somdel, function(error, response) {
													if (error) {
														var ErrorTxt = "service csyn_SOMBulkCrewUpdates urlopen connect error with delete call for  SOMapi,details are : " + info + "; error info :" + error
														logger.error("SOM_csyn_019 : " + ErrorTxt);
														ctx.setVariable("retry", 'yes');
														//logger.debug("urlopen connect error with SOM API for delete crew call" + JSON.stringify(error));
														ctx.setVariable("ErrorTxt", ErrorTxt);
														reject(ErrorTxt);
													} else {
														var responseStatusCode = response.statusCode;
														if (responseStatusCode == 200) {
															response.readAsJSON(function(error, responseData) {
																if (error) {
																	var errorinfo = "Failure in getting response for SOMapi delete call, details are : " + info + "; error info :" + error
																	logger.error(errorinfo);
																	reject(errorinfo);
																} else {
																	resolve(responseData);
																}
															});
														}
														else if (responseStatusCode == 400) {

															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "Failure in getting response for SOMapi delete call, details are : " + info + "; error info :" + error
																	logger.error(errorinfo);
																	reject(errorinfo);
																} else {
																	resolve(responseData);
																}
															});

														}
														else {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "Failure in getting response for SOMapi delete call, details are : " + info + "; error info :" + error
																	logger.error(errorinfo);
																	reject(errorinfo);
																} else {
																	reject("Error returned " + ": with statusCode " + responseStatusCode + " " + responseData);
																}
															});
														}
													}
												});
											});
										}
										async function main(delexternalID) {
											for (var n = 0; n < delexternalID.length; n++) {

												var somdelurl = session.parameters.somURL + "/api/v1/Crew/External/" + delexternalID[n];
												var somdel = {
													target: somdelurl,
													sslClientProfile: 'OMS_SOM_Client_Profile',
													method: 'DELETE',
													headers: {
														'osiApiToken': somToken
													}
												};
												try {
													var responseData = await makeRequest(somdel);
													hm.response.statusCode = '200 OK';
													logger.debug("response received :" + JSON.stringify(responseData));
												} catch (error) {
													hm.current.statusCode = responseStatusCode;
													logger.error(error);
													session.reject(error);
												}
											}
										}
										main(delexternalID);
									}
								});
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure in reading response from SOMapi Get call, details are : " + info + "; error info :" + error
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										logger.error("Error code returned from SOMapi Get call" + responseStatusCode + " " + responseData);
										session.reject("Error code returned from SOMapi Get call" + responseStatusCode + " " + responseData);
									}
								});
							}


						}
					});
				} catch (err) {
					var ErrorTxt = "service csyn_SOMBulkCrewUpdates urlopen connect error with SOMapi GET Call for get crew list,details are : " + info + "; error info :" + err
					logger.error("SOM_csyn_018 : " + ErrorTxt);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("ErrorTxt", ErrorTxt);
				}
			}
		}

	});
}
