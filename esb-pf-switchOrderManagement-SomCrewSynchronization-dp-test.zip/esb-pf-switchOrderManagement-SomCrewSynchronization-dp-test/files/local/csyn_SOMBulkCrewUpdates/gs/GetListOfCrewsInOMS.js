var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var TokenValue = session.parameters.osiApiToken;
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + readAsJSONError);
		session.reject("Error in reading incoming data" + readAsJSONError);
	} else {
		/*Start Of OMS Call to GetListOfCrews*/
		var OMS = session.parameters.OMSUrl;
		if ((OMS == undefined) || (OMS == '') || (OMS == null)) {
			logger.error("OMSUrl is missing" + JSON.stringify(error));
			session.reject("OMSUrl is missing");
		} else {
			var ctx = session.createContext('GetListOfCrew');
			var skip = 0;
			var take = 1000;
			var OMSUrl = OMS + '/api/ServiceType/Electric/Crew' + '?excludeDeprecated=false&excludeInactive=false&includeFields=externalID,name,aorIDs,phoneNumber,email,type,customFieldValuesExt,deprecated&skip=' + skip + '&take=' + take;
			var omsEID = [];
			var omscrewlistArray = [];
			var omstypeArray = [];
			//Recursive function call
			function getDataFn(OMSUrl) {
				fetchData(OMSUrl, function(error, responseData) {
					if (error) {
						logger.error("Error returned from OMSurl function call" + JSON.stringify(error));
					} else {
						var total = responseData.total;
						logger.debug("total" + total);

						for (var j = 0; j < total; j++) {
							if ((responseData.data[j].type == 13) || (responseData.data[j].type == 20) || (responseData.data[j].type == 21) || (responseData.data[j].type == 24)) {
								omscrewlistArray.push(responseData.data[j]);
							}
						}
						var total = responseData.total;
						// return responseData;
						if (total == take) {
							// call the function recursively when total == take
							skip = skip + 1000;
							OMSUrl = OMS + '/api/ServiceType/Electric/Crew' + '?excludeDeprecated=false&excludeInactive=false&includeFields=externalID,name,aorIDs,phoneNumber,email,type,customFieldValuesExt,deprecated&skip=' + skip + '&take=' + take;
							getDataFn(OMSUrl);
						} else {
							ctx.setVariable("GetListOfCrewVariable", omscrewlistArray);
							return omscrewlistArray;
						}
					}
				});
			}
			getDataFn(OMSUrl);
		}
	}
	function fetchData(OMSUrl, cb) {
		var GetListOfCrews = {
			target: OMSUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'get',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			}
		};

		var info = " TargetURL :" + GetListOfCrews.target + "; Method :" + GetListOfCrews.method + ". ";
		try {
			urlopen.open(GetListOfCrews, function(error, response) {
				if (error) {
					// an error occurred during request sending or response header parsing
					var ErrorTxt = "service csyn_SOMBulkCrewUpdates urlopen connect error with OMSapi for GET crew list,details are : " + info + "; error info :" + error
					logger.error("SOM_csyn_014 : " + ErrorTxt);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("ErrorTxt", ErrorTxt);
					//session.reject("urlopen connect error with OMSapi for GET crew list " + JSON.stringify(error))
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "error reading response with oms 'GetListOfCrewVariable call', details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								cb(error, null);
							} else {
								hm.response.statusCode = '200 Message is received';
								logger.debug("response received from 1st GetListOfCrews OMS call:" + responseData);
								cb(null, responseData);
							}
						})
					}
					else if (responseStatusCode == 401) {
						logger.error("OMS request in not authorized");
						session.reject("OMS Request : 401 Unauthorized");
					}
					else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from GET OMS call', details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								//session.reject("failure in reading message from GET OMS call" + JSON.stringify(error));
							} else {
								hm.current.statusCode = responseStatusCode;
								logger.error("SOM_csyn_015 :  Error returned from GetListOfCrews OMS GET call" + " : with statusCode " + responseStatusCode + " " + responseData);
								ctx.setVariable("retry", 'yes');
								var ErrorTxt = "service csyn_SOMBulkCrewUpdates urlopen connect error with get call for  OMScrewlist " + JSON.stringify(error);
								ctx.setVariable("ErrorTxt", ErrorTxt);
								cb("Error returned from GetListOfCrews OMS call" + " : with statusCode " + responseStatusCode, null);
							}
						});
					}
				}
			});
		} catch (err) {
			var ErrorTxt = "service csyn_SOMBulkCrewUpdates urlopen connect error with OMSapi for GET crew list,details are : " + info + "; error info :" + error
			logger.error("SOM_csyn_014 : " + ErrorTxt);
			ctx.setVariable("retry", 'yes');
			ctx.setVariable("ErrorTxt", ErrorTxt);
		} //URL open closed
	}
})
