var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
var checkretry = ctx.getVar("retry");
if (checkretry != 'yes') {
	var lookupURL = session.parameters.lookupUrl;
	var somlookupURL = session.parameters.somlookupUrl;
	var somToken = session.parameters.somToken;
	var omscrewlistArray = [];
	var crewTypeArray = [];
	var labelMap = new Map([
		['Substations', 'OPER'],
		['OH', 'OHL'],
		['UG', 'UGL'],
		['PSR', 'PSR']
	]);
	var omstypeArray = [];
	session.input.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			logger.error("Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {
			var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
			var omscrewlistArray = ctx.getVariable("GetListOfCrewVariable");

			var result = omscrewlistArray;
			for (var i = 0; i < result.length; i++) {
				omstypeArray.push(result[i].type);
			}
			var uniquetypeValue = [...new Set(omstypeArray)];
			var index = uniquetypeValue.indexOf(null);

			if (index > -1) {
				uniquetypeValue.splice(index, 1);
			}

			var ctx = session.name("GetListOfCrew") || session.createContext("GetListOfCrew");
			for (var i = 0; i < uniquetypeValue.length; i++) {
				var obj = {};
				let type = uniquetypeValue[i];
				var aorObject = search(type, omscrewlistArray);
				//logger.error("test", aorObject);
				//for(var j=0;j<aorObject.length;j++){
				var lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "crewTypes",
								"status": type
							},
							{
								"name": "aors",
								"id": aorObject[i]

							}

						]
					}
				};
				var joblookupService = {
					target: lookupURL,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				var info = " TargetURL :" + joblookupService.target + "; Method :" + joblookupService.method + "; Data :" + JSON.stringify(joblookupService.data) + ". ";
				try {
					function getDataFn(OMSUrl) {
						var lookupstring = "OMSLookup";
						lookup(lookupstring, joblookupService, function(error, responseData) {
							if (error) {
								var errorinfo = "url connection error 'joblookupService', details are : " + info + "; error info :" + error
								logger.error(errorinfo);
							} else {
								if (responseData.lookupRep.type[0].result == 0) {
									if ((responseData.lookupRep.type[0].label != undefined) && (responseData.lookupRep.type[0].label != null) && (responseData.lookupRep.type[0].label != '')) {
										var label = responseData.lookupRep.type[0].label;
										var aorlabel = responseData.lookupRep.type[1].label;
									}
									else {
										var label = "";
										var aorlabel = "";
									}
								}
								else {
									var label = "";
									var aorlabel = "";
								}
								if ((label == "Substations" || label == "OH" || label == "UG" || label == "PSR")) {
									var crewType = labelMap.get(label);

									var somlookupMessage = {
										"lookupReq": {
											"type": [
												{
													"name": "crewTypes",
													"label": crewType
												},
												{
													"name": "aorsId",
													"label": aorlabel
												}

											]
										}
									};

									var somlookupService = {
										target: somlookupURL,
										method: 'POST',
										contentType: 'application/json',
										data: somlookupMessage
									};

									var info = " TargetURL :" + somlookupService.target + "; Method :" + somlookupService.method + "; Data :" + JSON.stringify(somlookupService.data) + ". ";
									try {
										var lookupstring = "SOMlookup";
										lookup(lookupstring, somlookupService, function(error, responseData) {
											if (error) {
												var errorinfo = "url connection error 'somlookupService', details are : " + info + "; error info :" + error
												logger.error(errorinfo);
											} else {
												if (responseData.lookupRep.type[0].result == 0) {
													if ((responseData.lookupRep.type[0].id != undefined) && (responseData.lookupRep.type[0].id != null) && (responseData.lookupRep.type[0].id != '')) {
														var id = responseData.lookupRep.type[0].id;
														var aor_id = responseData.lookupRep.type[1].id;
													}
													else {
														var id = "";
														var aor_id = "";
													}
												}
												else {
													var id = "";
													var aor_id = "";
												}

												if (aor_id === undefined || aor_id === null) {
													var aor_somlookupMessage = {
														"lookupReq": {
															"type": [

																{
																	"name": "aorsId",
																	"label": 'DTE'
																}

															]
														}
													};
													var aor_somlookupService = {
														target: somlookupURL,
														method: 'POST',
														contentType: 'application/json',
														data: aor_somlookupMessage
													};

													var info = " TargetURL :" + aor_somlookupService.target + "; Method :" + aor_somlookupService.method + "; Data :" + JSON.stringify(aor_somlookupService.data) + ". ";
													try {
														lookup(lookupstring, somlookupService, function(error, responseData) {
															if (error) {
																var errorinfo = "url connection error 'aor_somlookupService', details are : " + info + "; error info :" + error
																logger.error(errorinfo);
															} else {
																if (responseData.lookupRep.type[0].result == 0) {
																	if ((responseData.lookupRep.type[0].id != undefined) && (responseData.lookupRep.type[0].id != null) && (responseData.lookupRep.type[0].id != '')) {
																		var aor_id = responseData.lookupRep.type[0].id;
																	}
																	else {
																		var aor_id = "";
																	}
																}
																else {
																	var aor_id = "";
																}
															}
														})
													} catch (err) {
														var errorinfo = "url connection error 'aor_somlookupService', details are : " + info + "; error info :" + error
														logger.error(errorinfo);
													}
												}
												obj = {
													"type": type,
													"label": label,
													"label": label,
													"id": id,
													"aorid": aor_id
												};

												crewTypeArray.push(obj);
												ctx.setVariable("array", crewTypeArray);
											}
										})
									} catch (err) {
										var errorinfo = "url connection error 'somlookupService', details are : " + info + "; error info :" + error
										logger.error(errorinfo);
									}
								}
							}
						})
					}
					getDataFn(joblookupService);
				} catch (err) {
					var errorinfo = "url connection error 'joblookupService', details are : " + info + "; error info :" + error
					logger.error(errorinfo);
				}

				//}
			}



			function search(nameKey, myArray) {
				for (var i = 0; i < myArray.length; i++) {
					if (myArray[i].type === nameKey) {
						return myArray[i].aorIDs;
					}
				}
			}

			function lookup(lookupstring, url, data) {
				urlopen.open(url, function(error, response) {
					if (error) {
						// an error occurred during request sending or response header parsing
						if (lookupstring == "OMSLookup") {
							var errorinfo = "OMSLookup urlopen connect error', details are : " + info + "; error info :" + error
							logger.error("SOM_csyn_016 : " + errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "SOMLookup urlopen connect error, details are : " + info + "; error info :" + error
							logger.error("SOM_csyn_017 :" + errorinfo);
							session.reject(errorinfo);
						}
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "url connection error 'lookup url', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									data(error, null);
								} else {
									hm.response.statusCode = '200 Message is received';
									//logger.debug("response received from 1st GetListOfCrews OMS call:" + responseData);

									data(null, responseData);
								}
							})
						} else {

							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "failure in reading message from  lookup call, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									//session.reject("failure in reading message from lookup call ");
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("Error returned from lookup call" + " : with statusCode " + responseStatusCode + " " + responseData);
									data("Error returned from lookup call" + " : with statusCode " + responseStatusCode, null);

								}
							});
						}
					}
				});
			}
		}
	});
}
