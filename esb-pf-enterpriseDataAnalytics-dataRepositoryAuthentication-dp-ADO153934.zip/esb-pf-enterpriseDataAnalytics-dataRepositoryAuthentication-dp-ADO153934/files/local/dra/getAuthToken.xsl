<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:regexp="http://exslt.org/regular-expressions" xmlns:dt="http://exslt.org/dates-and-times" version="1.0" extension-element-prefixes="dp regexp dt" exclude-result-prefixes="dp regexp dt">

	<xsl:output method="text"/>
	
	<xsl:variable name="clientInformation">
		<xsl:copy-of select="document('local:///dra/ClientInformation.xml')"/>
	</xsl:variable>
	
	<xsl:variable name="CRLF" select="'&#13;&#10;'"/>
	<xsl:variable name="DDASH" select="'--'"/>
	<xsl:variable name="QUOT" select="'&quot;'"/>
	<xsl:variable name="boundary" select="dp:generate-uuid()"/>
	
	<xsl:template match="/">
		<xsl:variable name="URL-in" select="dp:variable('var://service/URL-in')"/>
		<xsl:variable name="resource" select="regexp:match($URL-in, '(?&lt;=\/)\w+(?=$)','')"/>
		<xsl:message dp:priority="debug">### resource : <xsl:value-of select="$resource"/>
		</xsl:message>
		
		<xsl:variable name="tenant">
			<xsl:value-of select="$clientInformation/ClientInformation/TenantID"/>
		</xsl:variable>
		<xsl:message dp:priority="debug">### tenant : <xsl:value-of select="$tenant"/>
		</xsl:message>
		
		<xsl:variable name="clientID">
			<xsl:value-of select="$clientInformation/ClientInformation/Client[URI=$resource]/ClientID"/>
		</xsl:variable>
		<xsl:message dp:priority="debug">### clientID : <xsl:value-of select="$clientID"/>
		</xsl:message>
		
		<xsl:variable name="clientSecret">
			<xsl:value-of select="$clientInformation/ClientInformation/Client[URI=$resource]/ClientSecret"/>
		</xsl:variable>
		<xsl:message dp:priority="debug">### clientSecret : <xsl:value-of select="$clientSecret"/>
		</xsl:message>
		
		<xsl:variable name="contentType">
			<xsl:value-of disable-output-escaping="no" select="concat('multipart/form-data; boundary=',$QUOT,$boundary,$QUOT)"/>
		</xsl:variable>
	
		<xsl:variable name="tokenURL" select="concat('https://login.microsoftonline.com/', $tenant, '/oauth2/v2.0/token')"/>
		<xsl:message dp:priority="debug">### tokenURL : <xsl:value-of select="$tokenURL"/>
		</xsl:message>
		
		<dp:set-variable name="'var://service/routing-url'" value="$tokenURL"/>
		<dp:set-http-request-header name="'Content-Type'" value="$contentType"/>

		<xsl:variable name="payload">
		<xsl:call-template name="buildMIMEpart">
			<xsl:with-param name="pname" select="'client_id'"/>
			<xsl:with-param name="pval" select="$clientID"/>
		</xsl:call-template>
		<xsl:call-template name="buildMIMEpart">
			<xsl:with-param name="pname" select="'scope'"/>
			<xsl:with-param name="pval" select="'https://eventhubs.azure.net/.default'"/>
		</xsl:call-template>
		<xsl:call-template name="buildMIMEpart">
			<xsl:with-param name="pname" select="'client_secret'"/>
			<xsl:with-param name="pval" select="$clientSecret"/>
		</xsl:call-template>
		<xsl:call-template name="buildMIMEpart">
			<xsl:with-param name="pname" select="'grant_type'"/>
			<xsl:with-param name="pval" select="'client_credentials'"/>
		</xsl:call-template>
		<xsl:value-of disable-output-escaping="yes" select="concat($CRLF,$DDASH,$boundary)"/>
		</xsl:variable>
		
		<xsl:value-of select="$payload"/>
		
	</xsl:template>
	
	<xsl:template name="buildMIMEpart">
		<xsl:param name="pname" select="''" />
		<xsl:param name="pval" select="''" />
      
		<xsl:value-of disable-output-escaping="yes"
			select="concat($CRLF,$DDASH,$boundary,$CRLF)"/> 
		  <xsl:value-of disable-output-escaping="yes"
			select="concat('Content-Disposition: form-data; name=')"/>
		<xsl:value-of disable-output-escaping="yes"
			select="concat($QUOT,$pname,$QUOT,$CRLF,$CRLF)"/>
		<xsl:value-of disable-output-escaping="yes"
			select="$pval"/>
    </xsl:template>

</xsl:stylesheet>