var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ilsCtx = session.name('ILS') || session.createContext('ILS');

function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}

//var ctxHeader = session.name('omsfoaSeq') || session.createContext('omsfoaSeq');

var json_mqrfh2 = headers.get({
	type: 'mq'
}, 'MQRFH2');

if (
	json_mqrfh2 &&
	json_mqrfh2.MQRFH2 &&
	json_mqrfh2.MQRFH2.NameValueData &&
	json_mqrfh2.MQRFH2.NameValueData.NameValue &&
	json_mqrfh2.MQRFH2.NameValueData.NameValue.usr &&
	json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.retryCount
) {

}
else {
	headers.remove('MQRFH2')

}

var reqType = '';
var root = '';

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		if (incomingdata.OMS_EFO_StatusChange) {
			root = incomingdata.OMS_EFO_StatusChange;
			reqType = 'update';

		} else if (incomingdata.EFO_Completion_OMSCompletion) {
			root = incomingdata.EFO_Completion_OMSCompletion;
			reqType = 'completion';

		} else if (incomingdata.OMS_TaskUpdate) {
			root = incomingdata.OMS_TaskUpdate;
			reqType = 'crewLeader';

		} else if (incomingdata.EFO_StatusChange_Dispatched) {
			root = incomingdata.EFO_StatusChange_Dispatched;
			reqType = 'Dispatched';

		}

		var externalRefID = root.Task.ExternalRefID;
		if (externalRefID === undefined || externalRefID === null || externalRefID === " ") {
		} else {
			var g = externalRefID.split('_');
		}

		var myuuid = uuidv4();
		var correlationID = myuuid;
		var messageType = reqType + "Event";
		var interfaceName = session.parameters.interfaceName;
		//	var retryCount = "-1";
		var messageID = root.MessageID;
		var crewAssignmentID = g[1];
		var crewAssignmentDisplayID;
		var jobDisplayID;

		if (messageType === "crewLeaderEvent" || messageType === "completionEvent") {
			var callId = root.Task.CallID;
			if (root.Task.CallID === undefined || root.Task.CallID === null || root.Task.CallID === " ") {
			} else {
				var c = callId.split('_');
				crewAssignmentDisplayID = c[3];
				jobDisplayID = c[2];
			}

		} else {
			//var o;
			var ilsJobId = root.Task.omsJobId;
			//if (root.Task.omsJobId !== undefined || root.Task.omsJobId !== null || root.Task.omsJobId !== "") {
			if (ilsJobId === undefined || ilsJobId === null || ilsJobId === " ") {
			} else {
				var o = ilsJobId.split('_');
				crewAssignmentDisplayID = o[1];
				jobDisplayID = o[0];
			}

		}
		var jobID = g[2];
		var crewDisplayID;
		var assignmentStatus;
		if (messageType === "crewLeaderEvent") {
			if (root.Task.AssignedEngineer !== undefined || root.Task.AssignedEngineer !== null || root.Task.AssignedEngineer !== " ") {
				crewDisplayID = root.Task.AssignedEngineer.PSCrewID;
			}

		}
		if (messageType === "updateEvent") {
			if (root.Assignment !== undefined && root.Assignment.Engineers !== undefined) {
				crewDisplayID = root.Assignment.Engineers.crewID;
			}
			assignmentStatus = root.Task.Status.Name;
		}
		if (messageType === "completionEvent") {
			if (root.Assignment !== undefined && root.Assignment.Engineers !== undefined) {
				crewDisplayID = root.Assignment.Engineers[0].PSCrewID;
			}
			assignmentStatus = root.Task.Status.Name;
		}
		var sourceEventTimestamp;
		if (root.OMSsequenceTimeStamp) {
			sourceEventTimestamp = root.OMSsequenceTimeStamp;
		} else if (root.Task.Stamp && root.Task.Stamp.TimeModified) {
			sourceEventTimestamp = root.Task.Stamp.TimeModified;
		} else if (root.Task.Stamp && root.Task.Stamp.TimeCreated) {
			sourceEventTimestamp = root.Task.Stamp.TimeCreated;
		} else {
			sourceEventTimestamp = "TIME STAMP NOT IN PAYLOAD";
		}
		var sourceUrl = sm.getVar('var://service/URL-in');
		var entryDescription = session.parameters.SeqEntryDescription;
		var exitDescription = session.parameters.SeqExitDescription;

		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ilsCtx.setVariable('correlationID', " ");
		} else {
			ilsCtx.setVariable('correlationID', correlationID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ilsCtx.setVariable('messageType', " ");
		} else {
			ilsCtx.setVariable('messageType', messageType);
		}
		if (messageID === undefined || messageID === null || messageID === '') {
			ilsCtx.setVariable('messageID', " ");
		} else {
			ilsCtx.setVariable('messageID', messageID);
		}
		if (crewAssignmentID === undefined || crewAssignmentID === null || crewAssignmentID === '') {
			ilsCtx.setVariable('crewAssignmentID', " ");
		} else {
			ilsCtx.setVariable('crewAssignmentID', crewAssignmentID);
		}
		if (crewAssignmentDisplayID === undefined || crewAssignmentDisplayID === null || crewAssignmentDisplayID === '') {
			ilsCtx.setVariable('crewAssignmentDisplayID', " ");
		} else {
			ilsCtx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID);
		}
		if (jobDisplayID === undefined || jobDisplayID === null || jobDisplayID === '') {
			ilsCtx.setVariable('jobDisplayID', " ");
		} else {
			ilsCtx.setVariable('jobDisplayID', jobDisplayID);
		}
		if (jobID === undefined || jobID === null || jobID === '') {
			ilsCtx.setVariable('jobID', " ");
		} else {
			ilsCtx.setVariable('jobID', jobID);
		}
		if (crewDisplayID === undefined || crewDisplayID === null || crewDisplayID === '') {
			ilsCtx.setVariable('crewDisplayID', " ");
		} else {
			ilsCtx.setVariable('crewDisplayID', crewDisplayID);
		}
		if (assignmentStatus === undefined || assignmentStatus === null || assignmentStatus === '') {
			ilsCtx.setVariable('assignmentStatus', " ");
		} else {
			ilsCtx.setVariable('assignmentStatus', assignmentStatus);
		}
		if (sourceEventTimestamp === undefined || sourceEventTimestamp === null || sourceEventTimestamp === '') {
			ilsCtx.setVariable('sourceEventTimestamp', " ");
		} else {
			ilsCtx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
		}
		if (sourceUrl === undefined || sourceUrl === null || sourceUrl === '') {
			ilsCtx.setVariable('sourceUrl', " ");
		} else {
			ilsCtx.setVariable('sourceUrl', sourceUrl);
		}
		if (entryDescription === undefined || entryDescription === null || entryDescription === '') {
			ilsCtx.setVariable('EntryDescription', " ");
		} else {
			ilsCtx.setVariable('EntryDescription', entryDescription);
		}
		if (exitDescription === undefined || exitDescription === null || exitDescription === '') {
			ilsCtx.setVariable('ExitDescription', " ");
		} else {
			ilsCtx.setVariable('ExitDescription', exitDescription);
		}
	}
});
