var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("omsfoaSeq") || session.createContext("omsfoaSeq");

function callMQURL(url, reqType, myctx, payload) {
	var mqmd = {
		MQMD: {
			StrucId: {
				$: 'MD '
			},
			Format: {
				$: 'MQHRF2 '
			},
			MsgType: {
				$: '8'
			},
			Persistence: {
				$: '1'
			}
		}
	};
	var mqrfh2 = {
		MQRFH2: {
			Version: {
				$: '2'
			},
			Format: {
				$: 'MQSTR'
			},
			NameValueData: {
				NameValue: [{
					usr: {
						triggerValue: {
							$: reqType
						},
					}
				}]
			}
		}
	};
	var urlopenHeaders = {
		MQMD: mqmd,
		MQRFH2: mqrfh2
	};
	var options = {
		target: url,
		headers: urlopenHeaders,
		data: payload
	};
	var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "Unable to connect MQ details details are : " + info + "; error info :" + error
				var ctx = session.name("omsfoaSeq") || session.createContext("omsfoaSeq");
				logger.error(errorinfo);
				ctx.setVariable("customErrorCode", error.errorCode);
				ctx.setVariable("customErrorMessage", 'urlopen.open error MQ [MQRC=' + error.errorMessage + ']');
				ctx.setVariable("customReasonMessage", 'urlopen.open error MQ [MQRC=' + error.errorMessage + ']');
				session.reject(errorinfo);
			} else {

				var mqrc = response.statusCode;
				var reasonPhrase = response.reasonPhrase;
				if (mqrc == 0) {

					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "error reading response from MQ, details are : " + info + "; error info :" + readError
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var ctx = session.name("omsfoaSeq") || session.createContext("omsfoaSeq");
							ctx.setVariable(myctx + "_response", response);
							logger.info("MQResponseData" + responseData);
						}
					});
				} else {
					var errorinfo = "Error Could not place message in Queue, details are : " + info + "; response info :" + response + "; ResponseStatusCode :" + response.statusCode
					var ctx = session.name("omsfoaSeq") || session.createContext("omsfoaSeq");
					logger.error(errorinfo);
					ctx.setVariable("customErrorCode", mqrc);
					ctx.setVariable("customErrorMessage", 'urlopen.open error MQ [MQRC=' + mqrc + ']');
					ctx.setVariable("customReasonMessage", 'urlopen.open error MQ [MQRC=' + mqrc + ']');
					session.reject(errorinfo);
				}
			}
		});
	}
	catch (err) {
		var errorinfo = "URL Open Connection Error, details are : " + info + "; error info :" + err
		session.reject(errorinfo);
		logger.error(errorinfo);
	}
}
module.exports = callMQURL;
