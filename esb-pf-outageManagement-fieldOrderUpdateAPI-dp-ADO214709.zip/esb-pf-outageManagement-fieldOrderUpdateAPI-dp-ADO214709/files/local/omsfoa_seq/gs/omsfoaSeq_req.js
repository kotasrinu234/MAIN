var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var callMQURL = require('./callMQURL.js');
var expiry = session.parameters.expiry;
var waitTime = session.parameters.waitTime;
var sec = session.parameters.sec;
var eventHubQM = session.parameters.eventHubQM;
var eventHubReqQ = session.parameters.eventHubReqQ;
var ctx = session.name('omsfoaSeq') || session.createContext('omsfoaSeq');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
ilsCtx.setVariable("exitDestination", eventHubReqQ);
/*function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}*/
var outReq = {};
var reqType = '';
var root = '';
var eventTimeStamp = '';
var crewAssignmentID = '';
var crewAssignmentDisplayID = '';
var jobDisplayID = '';
var messageType = '';
var label;
var assignmentStatus;
var taskStatus;
var rootTask;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up15|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//const arry = [];
		if (incomingdata.OMS_EFO_StatusChange) {
			root = incomingdata.OMS_EFO_StatusChange;
			reqType = 'update';
			messageType = 'updateEvent';

		} else if (incomingdata.EFO_Completion_OMSCompletion) {
			root = incomingdata.EFO_Completion_OMSCompletion;
			reqType = 'completion';
			messageType = 'completionEvent'


		} else if (incomingdata.OMS_TaskUpdate) {
			root = incomingdata.OMS_TaskUpdate;
			reqType = 'crewLeader';
			messageType = 'crewLeaderEvent';

		}
		ctx.setVariable("root", root);
		ctx.setVariable("reqType", reqType);

		//var status=root.Task.Status.Name

		rootTask = root.Task;

		//taskStatus  = rootTask.Status;

		if (root.Task.Status !== undefined && root.Task.Status !== null && root.Task.Status !== '') {
			assignmentStatus = root.Task.Status.Name;

		}

		if (root.OMSsequenceTimeStamp) {
			eventTimeStamp = root.OMSsequenceTimeStamp;
		}
		else if (root.Task.Stamp.TimeModified) {
			eventTimeStamp = root.Task.Stamp.TimeModified;
		}
		else if (root.Task.Stamp.TimeCreated) {
			eventTimeStamp = root.Task.Stamp.TimeCreated;
		}

		if (!(eventTimeStamp.includes('Z'))) {
			eventTimeStamp = eventTimeStamp + 'Z';
		}

		ctx.setVariable('eventTimeStamp', eventTimeStamp);
		if (incomingdata.EFO_Completion_OMSCompletion) {
			var dt = new Date(eventTimeStamp);
			sec = Number(sec);
			var eventTimeStamp = (addSeconds(dt, sec).toISOString());
			console.log(addSeconds(dt, sec));
			ctx.setVariable('eventTimeStamp_fc', eventTimeStamp);
		}

		var date = new Date();
		var externalRefID = root.Task.ExternalRefID;
		if (externalRefID !== undefined && externalRefID !== null && externalRefID !== '') {
			var g = externalRefID.split('_');
			var omsjobid = g[2];
			crewAssignmentID = g[1]
		}

		var buff = new Buffer(JSON.stringify(incomingdata));
		var base64EncodedString = buff.toString('base64');

		//var myuuid =uuidv4();	
		var myuuid = ilsCtx.getVariable('correlationID');
		if (messageType === 'completionEvent' || messageType === 'crewLeaderEvent') {
			var callId = root.Task.CallID;
			if (callId !== undefined && callId !== null && callId !== '') {
				var s = callId.split('_');
				jobDisplayID = s[2];
				crewAssignmentDisplayID = s[3];
			}
		}
		else {
			var crewomsJobId = root.Task.omsJobId;
			if (crewomsJobId !== undefined && crewomsJobId !== null && crewomsJobId !== '') {
				var r = crewomsJobId.split('_');
				crewAssignmentDisplayID = r[1];
				jobDisplayID = r[0];
			}
		}

		/* 	if (assignmentStatus !== undefined && assignmentStatus !== null && assignmentStatus !== ''){
		 assignmentStatus = root.Task.Status.Name;
			} */
		//var outReq = {};
		outReq.messageId = myuuid;
		outReq.serviceName = 'workOrderEFOUpdate';
		outReq.expiry = expiry;
		outReq.eventType = reqType;
		if (assignmentStatus !== undefined && assignmentStatus !== null && assignmentStatus !== '' && assignmentStatus !== 'Start-Task' && assignmentStatus !== 'Ready to Assign' && reqType !== 'completion' && reqType !== 'crewLeader') {
			outReq.workFlowRequirementEvent = 'N';
		}
		//outReq.workFlowRequirementEvent = 'N';

		if (omsjobid) {
			outReq.eventContext = omsjobid;
			outReq.jobID = omsjobid;
		}
		outReq.payload = base64EncodedString;
		outReq.EventTimeStamp = eventTimeStamp;
		outReq.sendTimeStamp = date.toISOString();
		if (assignmentStatus == 'Ready to Assign' && reqType !== 'completion') {
			outReq.waitTime = '1';
			//ctx.setVariable("waitTimeRa",'1');
		} else if (reqType == 'completion') {
			outReq.waitTime = '10';
			//ctx.setVariable("waitTimeComp",'10');

		} else if (reqType == 'crewLeader') {
			outReq.waitTime = '1';
		} else {
			outReq.waitTime = waitTime;
			//ctx.setVariable("waitTimeOthers",waitTime);
		}
		if (assignmentStatus !== undefined && assignmentStatus !== null && assignmentStatus !== '' && assignmentStatus !== 'Start-Task' && assignmentStatus !== 'Ready to Assign' && reqType !== 'completion' && reqType !== 'crewLeader') {
			outReq.eventKey = crewAssignmentDisplayID;
		}
		outReq.assignmentStatus = assignmentStatus;
		if (assignmentStatus !== undefined && assignmentStatus !== null && assignmentStatus !== '') {
			outReq.assignmentStatus = assignmentStatus;
		}
		if (crewAssignmentID !== undefined && crewAssignmentID !== null && crewAssignmentID !== '') {
			outReq.crewAssignmentID = crewAssignmentID;
		}
		if (crewAssignmentDisplayID !== undefined && crewAssignmentDisplayID !== null && crewAssignmentDisplayID !== '') {
			outReq.crewAssignmentDisplayID = crewAssignmentDisplayID
		}
		if (jobDisplayID !== undefined && jobDisplayID !== null && jobDisplayID !== '') {
			outReq.jobDisplayID = jobDisplayID
		}
		if (messageType !== undefined && messageType !== null && messageType !== '') {
			outReq.messageType = messageType;
		}
		outReq.destQueueName = 'OMSFSA.EFO.STATUS.UPDATE.SEQ';
		ctx.setVariable('outReq', outReq);
		var OMSURL = session.parameters.OMSURL
		var TokenValue = session.parameters.TokenValue;
		var GetWorkFlowTypeIDURL = OMSURL + '/api/ServiceType/Electric/CrewAssignment/' + crewAssignmentID + '?includeFields=workTypeID'
		var GetWorkFlowTypeID = {
			target: GetWorkFlowTypeIDURL,
			sslClientProfile: 'mosfoa_ClientProfile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			}
		};
		var info = " TargetURL :" + GetWorkFlowTypeID.target + "; Method :" + GetWorkFlowTypeID.method + ". ";
		urlopen.open(GetWorkFlowTypeID, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'GetWorkFlowTypeID', details are : " + info + "; error info :" + error
				ilsCtx.setVariable('ExitStatus', '500');
				ilsCtx.setVariable('ExitDescription', errorinfo);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'GetWorkFlowTypeID', details are : " + info + "; error info :" + error
							ilsCtx.setVariable('ExitStatus', '500');
							ilsCtx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = '200 OK';
							var workTypeID = responseData.workTypeID;
							var LabelLookUp = {
								"lookupReq": {
									"type": [
										{
											"name": "workTypes",
											"id": workTypeID,
											"status": 'none'
										}
									]
								}
							};
							var LabelLookUpCall = {
								target: session.parameters.lookupUrl,
								method: 'POST',
								contentType: 'application/json',
								data: LabelLookUp
							};
							var info = " TargetURL :" + LabelLookUpCall.target + "; Method :" + LabelLookUpCall.method + "; Data :" + JSON.stringify(LabelLookUpCall.data) + ". ";
							urlopen.open(LabelLookUpCall, function(error, response) {
								if (error) {
									var errorinfo = "url connection error 'Label LookUp', details are : " + info + "; error info :" + error
									ilsCtx.setVariable('ExitStatus', '500');
									ilsCtx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'Label LookUp', details are : " + info + "; error info :" + error
												ilsCtx.setVariable('ExitStatus', '500');
												ilsCtx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												hm.response.statusCode = '200 OK';
												logger.debug("response received from LookUp of Status :" + responseData);
												if (responseData.lookupRep.type[0].result == 1) {
													var invalidresp = "Invalid Lookup Request 'Label LookUp', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ilsCtx.setVariable('ExitStatus', '1');
													ilsCtx.setVariable('ExitDescription', invalidresp);
													logger.error(invalidresp);
													session.reject(invalidresp)
												} else {
													label = responseData.lookupRep.type[0].label;
													if (root.Task.Status !== undefined && root.Task.Status !== null && root.Task.Status !== '') {
														assignmentStatus = root.Task.Status.Name;

													}
													if (assignmentStatus !== undefined && assignmentStatus !== null && assignmentStatus !== '' && assignmentStatus !== 'Start-Task' && assignmentStatus !== 'Ready to Assign' && reqType !== 'completion' && reqType !== 'crewLeader') {
														outReq.workFlowType = label;
													}
													ctx.setVariable('outReq0', outReq);
													var urlopenurl = 'dpmq://' + eventHubQM + '/?RequestQueue=' + eventHubReqQ;
													callMQURL(urlopenurl, reqType, 'Seq_MQ', outReq);
													session.output.write(outReq);
													ctx.setVariable('responseData', responseData);
												}
											}
										})
									} else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'Label LookUp', details are : " + info + "; error info :" + error
												ilsCtx.setVariable('ExitStatus', '500');
												ilsCtx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "error response 'Label LookUp', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												ilsCtx.setVariable('ExitStatus', '500');
												ilsCtx.setVariable('ExitDescription', errorinfo);
												hm.current.statusCode = responseStatusCode;
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});
									}
								}
							});
						}
					})
				} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
					response.readAsBuffer(function(error, BusinessResponseData) {
						if (error) {
							var errorinfo = "error reading response 'GetWorkTypeID', details are : " + info + "; error info :" + error
							ilsCtx.setVariable('ExitStatus', responseStatusCode);
							ilsCtx.setVariable('ExitDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							//business error change 2
							var BusinessResponseData = BusinessResponseData;
							var buff = Buffer.from(BusinessResponseData);
							var ResponseString = buff.toString();
							ctx.setVariable("respo", ResponseString)
							if ((ResponseString === "File Not Found") || (ResponseString === "No updates") || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
								var errorinfo = "error response 'GetWorkTypeID', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
								ilsCtx.setVariable('ExitStatus', responseStatusCode);
								ilsCtx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								ilsCtx.setVar("exitStatus", responseStatusCode);
								session.output.write(incomingdata);
							}
						}
					});
				} else if (responseStatusCode == 401 || responseStatusCode == 403) {
					// Handle business error responses (HTTP 401 or 403)
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "id=fior_up001: error reading response 'GetWorkTypeID' call, details are : " + info + "; error info :" + error;
							ilsCtx.setVariable('ExitStatus', responseStatusCode);
							ilsCtx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "id=fior_up001:" + responseData +" error reading response 'GetWorkTypeID' call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							ilsCtx.setVariable('ExitStatus', responseStatusCode);
							ilsCtx.setVariable('ExitDescription', errorinfo);
							
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				} else if (responseStatusCode == 502) {
					// Handle business error responses (HTTP 401 or 403)
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "id=fior_up001: error reading response 'GetWorkTypeID' call, details are : " + info + "; error info :" + error;
							ilsCtx.setVariable('ExitStatus', responseStatusCode);
							ilsCtx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "id=fior_up001:" + responseData +" error reading response 'GetWorkTypeID' call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							ilsCtx.setVariable('ExitStatus', responseStatusCode);
							ilsCtx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
				
				
				
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'GetWorkTypeID', details are : " + info + "; error info :" + error
							ilsCtx.setVariable('ExitStatus', responseStatusCode);
							ilsCtx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "error response 'GetWorkTypeID', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ilsCtx.setVariable('ExitStatus', responseStatusCode);
							ilsCtx.setVariable('ExitDescription', errorinfo);
							hm.current.statusCode = responseStatusCode;
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
							logger.error(errorinfo);
						}
					});
				}
			}
		});
	} //end of else
}); //end of function

function addSeconds(date, seconds) {
	var result = new Date(date);
	result.setSeconds(result.getSeconds() + seconds);
	return result;
};
