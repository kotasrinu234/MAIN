var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var CauseCodeName = '';
var CauseCodeLabel = session.parameters.causeCodeLabel;
ctx.setVariable("CauseCodeLabel",CauseCodeLabel);
var PSOMSCompletion = '';
var IsCGI = '';

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("id=fior_up75|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

   var PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
		if (PSOMSCompletion.IsCGI !== undefined && PSOMSCompletion.IsCGI === true){
			//CauseCodeName = 'NO WORK DONE';
			
			IsCGI=PSOMSCompletion.IsCGI
			
			//causeCodeLookupReq
			
			var typeobj = {
				name: "jobCustomFields.workflows",
				label: CauseCodeLabel
			}
			var typeArr = new Array();
			typeArr.push(typeobj);
			var lookupReqobj = {
				type: typeArr
			}
			var lookupReq = {
				lookupReq: lookupReqobj
			}
			var lookupuri = session.parameters.lookupurl;

			var lookupcallIsCGI = {
				target: lookupuri,
				method: 'POST',
				contentType: 'application/json',
				data: lookupReq
			};
			
						var info = " TargetURL :" + lookupcallIsCGI.target + "; Method :" + lookupcallIsCGI.method + "; Data :" + JSON.stringify(lookupcallIsCGI.data) + ". ";
			try {
				urlopen.open(lookupcallIsCGI, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'lookupcallIsCGI', details are : " + info + "; error info :" + error
						ctx.setVar('IsCGIlookup_Error', errorinfo)
						logger.error("id=fior_up96 : " + errorinfo);
						session.reject("id=fior_up96 : " + errorinfo);
					} else {
						ctx.setVar('IsCGIlookup_Resp', response)
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'lookupcallIsCGI', details are : " + info + "; error info :" + error
									ctx.setVar('IsCGI_RespError', errorinfo);
									logger.error("id=fior_up297 : " + errorinfo);
									session.reject("id=fior_up297 : " + errorinfo);
								} else {
									ctx.setVar('IsCGI_RespData', responseData);
									var CauseCodeName = responseData.lookupRep.type[0].status;
									logger.debug("status is " + CauseCodeName);
									ctx.setVariable("CauseCodeName", CauseCodeName);


								}
							})
						} 
					} //end of else
				}); //end of urlopen

			} catch (err) {
				var errorinfo = "url connection error 'lookupcallIsCGI', details are : " + info + "; error info :" + err
				ctx.setVar('lookupcallIsCGI_Error', errorinfo)
				logger.error("id=fior_up96 : " + errorinfo);
				session.reject("id=fior_up96 : " + errorinfo);
			}
			
			
			}
			
	}
});