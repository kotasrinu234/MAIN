var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var closeJob = omsfoa_UPdate_jobType.getVariable("closeJob");
var TokenValue = session.parameters.TokenValue;

var Engineers = "";
var crewID = "";
var empID = "";
var empName = "";
var PSOMSCompletion = "";
var taskRemarks = "";
var IsCGI = "";


	session.input.readAsJSON(function(readAsJSONError, incomingdata) {
			var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
		if (incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion != undefined) {
			PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
		}
		
		if (PSOMSCompletion.IsCGI != undefined) {
				
				IsCGI=PSOMSCompletion.IsCGI;
			}
		if (PSOMSCompletion.CompletionRemarks != undefined) {
			taskRemarks = PSOMSCompletion.CompletionRemarks;
		}
		
		
		if (closeJob === true || IsCGI === true) {
		
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
		if ((incomingdata.EFO_Completion_OMSCompletion.Assignment != undefined) && (incomingdata.EFO_Completion_OMSCompletion.Assignment.Engineers[0] != undefined)) {
			Engineers = incomingdata.EFO_Completion_OMSCompletion.Assignment.Engineers[0];
			crewID = Engineers.PSCrewID;
			ctx.setVariable('PScrewID', crewID);
			empID = Engineers.ID;
			empName = Engineers.Name;
		}

		var now = new Date();
		var year = now.getFullYear();
		var month = now.getMonth() + 1;
		var month1 = month.toString();
		var strmonthlength = month1.length;
		var todaymonth;
		if (strmonthlength == 1) {
			todaymonth = '0' + month;
		} else {
			todaymonth = month;
		}

		var day = now.getDate();
		var day1 = day.toString();
		var strdaylength = day1.length;
		var todaydate;
		if (strdaylength == 1) {
			todaydate = '0' + day;
		} else {
			todaydate = day;
		}

		var hour = now.getHours();
		var todayhour = hour.toString();
		var strhourlength = todayhour.length;
		var todayhour;
		if (strhourlength == 1) {
			todayhour = '0' + hour;
		} else {
			todayhour = hour;
		}

		var minute = now.getMinutes();
		var todayminute = minute.toString();
		var strminutelength = todayminute.length;
		var todayminute;
		if (strminutelength == 1) {
			todayminute = '0' + minute;
		} else {
			todayminute = minute;
		}

		var second = now.getSeconds();
		var todaysecond = second.toString();
		var strsecondlength = todaysecond.length;
		var todaysecond;
		if (strsecondlength == 1) {
			todaysecond = '0' + todaysecond;
		} else {
			todaysecond = todaysecond;
		}

		var nowdate = year + '-' + todaymonth + '-' + todaydate;
		var nowtime = todayhour + ':' + todayminute + ':' + todaysecond;

		var g = ExternalRefID.split('_');
		var AssigmentId = g[1];
		var CrewJobId = g[2];


		if (taskRemarks != undefined) {
			var customComment = 'REMARKS AMENDMENT BY ' + crewID + ' ' + empName + ' (' + empID + ')' + ' ' + 'ON' + ' ' + nowdate + ' AT ' + nowtime + ' - ' + taskRemarks;
		}

		var patchRemarksApiUri = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + CrewJobId;

		var patchRemarksApi = {
			target: patchRemarksApiUri,
			sslClientProfile: 'mosfoa_ClientProfile',
			method: 'PATCH',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},
			data: {
				"customFieldValues": { "Remarks": customComment }
			}
		};

		if ((PSOMSCompletion.CompletionRemarks != undefined) && (PSOMSCompletion.CompletionRemarks != null) && (PSOMSCompletion.CompletionRemarks != '')) {
			var info = " TargetURL :" + patchRemarksApi.target + "; Method :" + patchRemarksApi.method + "; Data :" + JSON.stringify(patchRemarksApi.data) + ". ";

			try {
				urlopen.open(patchRemarksApi, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'patchRemarksApi', details are : " + info + "; error info :" + error
						ctx.setVar('patchRemarksApi_error', errorinfo);
						logger.error("id=fior_up171 : " + errorinfo);
						session.reject("id=fior_up171 : " + errorinfo);
						//throw errorinfo;
					} else {
						ctx.setVar('patchRemarksApi_response', response);
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'patchRemarksApi', details are : " + info + "; error info :" + error
									ctx.setVar('patchRemarksApi_error', errorinfo);
									logger.error("id=fior_up72 : " + errorinfo);
									session.reject("id=fior_up172 : " + errorinfo);
								} else {
									ctx.setVar('patchRemarksApi_response', responseData);
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									ilsCtx.setVariable('ExitStatus', '0');
									logger.debug("response received from patchRemarksApi for CrewJobId:" + CrewJobId + " " + responseStatusCode);
									session.output.write(responseData);
								}
							});
						} else if (responseStatusCode == 400 || responseStatusCode == 404) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'patchRemarksApi', details are : " + info + "; error info :" + error
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
									else {
									var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
										if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
											var errorinfo = "error reading response 'patchRemarksApi', details are:" + info + "; response info :" + responseData
											logger.error(errorinfo);
											session.output.write(incomingdata);
										}else {
										var errorinfo = "error reading response 'patchRemarksApi', details are: " + info + "; response info : " + responseData
										ilsCtx.setVariable('ExitStatus', responseStatusCode);
										ilsCtx.setVariable('ExitDescription', errorinfo);
										var ctx = session.name('omsfoa') || session.createContext('omsfoa');
										ctx.setVariable('AvoidBackOut', 'yes');
									}
									}
								});
							}else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "id=fior_up010: error reading response 'patchRemarksApi' , details are : " + info + "; error info :" + error;
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "id=fior_up010: " + responseData + " error reading response 'patchRemarksApi' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'patchRemarksApi', details are : " + info + "; error info :" + error
									logger.error("id=fior_up73A : " + errorinfo);
									session.reject("id=fior_up73A : " + errorinfo);
								} else {
									var errorinfo = "error response 'patchRemarksApi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up73B : " + errorinfo);
									session.reject("id=fior_up73B : " + errorinfo);
								}
							});
						}
					}
				});
			} catch (err) {
				var errorinfo = "url connection error 'patchRemarksApi' , details are : " + info + "; error info :" + err
				ctx.setVar('patchRemarksApi_error', errorinfo);
				logger.error("id=fior_up171 : " + errorinfo);
				session.reject("id=fior_up171 : " + errorinfo);
				//throw errorinfo;
			}
			//patch call ends

		}//patchRemarksApi	
	}
	}
	});
