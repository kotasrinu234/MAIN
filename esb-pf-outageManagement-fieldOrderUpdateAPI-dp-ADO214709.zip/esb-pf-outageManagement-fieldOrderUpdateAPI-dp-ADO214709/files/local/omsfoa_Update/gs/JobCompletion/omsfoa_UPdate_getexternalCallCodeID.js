var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("id=fior_up84|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
			var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
			var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
			var ExternalRefIDArray = ExternalRefID.split('_');
			var Callid = ExternalRefIDArray[3];

			var omsuriwithcallid = session.parameters.OMS + '/api/ServiceType/Electric/Call/' + Callid;
			var TokenValue = session.parameters.TokenValue;

			var omsapi = {
				target: omsuriwithcallid,
				sslClientProfile: 'mosfoa_ClientProfile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
				data: incomingdata
			};

			var info = " TargetURL :" + omsapi.target + "; Method :" + omsapi.method + ". ";
			try {
				urlopen.open(omsapi, function(error, response) {
					if (error) {
						var errorinfo = "url connection error  with 'omsapi', details are : " + info + "; error info :" + error
						ctx.setVar('getCallid', errorinfo);
						logger.error("id=fior_up85 : " + errorinfo);
						session.reject("id=fior_up85 : " + errorinfo);
					} else {
						ctx.setVar('getCallid', response);
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in putting message to omsapi, details are : " + info + "; error info :" + error
									ctx.setVar('getCallid', errorinfo);
									logger.error("id=fior_up86 : " + errorinfo);
									session.reject("id=fior_up86 : " + errorinfo);
								} else {
									ctx.setVar('getCallid', responseData);
									ilsCtx.setVariable('ExitStatus', '0');
									omsfoa_UPdate_jobType.setVariable("responseData", responseData);
									logger.debug("id=fior_up87|response received from omsuri call:" + responseData);
									var externalCallCodeID = responseData.externalCallCodeID;
									omsfoa_UPdate_jobType.setVariable("externalCallCodeID", externalCallCodeID);
								}
							});
						} else if (responseStatusCode == 400 || responseStatusCode == 404) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Error returned from omsapi, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								else {
									var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
									if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
										var errorinfo = "Error returned from omsapi, details are:" + info + "; response info :" + responseData
										logger.error(errorinfo);
										session.output.write(incomingdata);
									} else {
										var errorinfo = "Error returned from omsapi, details are:" + info + "; response info :" + responseData
										ilsCtx.setVariable('ExitStatus', responseStatusCode);
										ilsCtx.setVariable('ExitDescription', errorinfo);
										var ctx = session.name('omsfoa') || session.createContext('omsfoa');
										ctx.setVariable('AvoidBackOut', 'yes');
									}
								}
							});
						} else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "id=fior_up013: Error returned from omsapi, details are : " + info + "; error info :" + error;
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "id=fior_up013: " + responseData + " Error returned from omsapi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Error returned from omsapi, details are : " + info + "; error info :" + error
									logger.error("id=fior_up88 : " + errorinfo);
									session.reject("id=fior_up88 : " + errorinfo);
								} else {
									var errorinfo = "Error returned from omsapi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up88 : " + errorinfo);
									session.reject("id=fior_up88 : " + errorinfo);
								}
							});
						}
					}
				});
			} catch (err) {
				var errorinfo = "url connection error with omsapi, details are : " + info + "; error info :" + err
				ctx.setVar('getCallid', error);
				logger.error("id=fior_up85 : " + errorinfo);
				session.reject("id=fior_up85 : " + errorinfo);
			}
		}
	}
	/*End Of jobType Call*/
});
