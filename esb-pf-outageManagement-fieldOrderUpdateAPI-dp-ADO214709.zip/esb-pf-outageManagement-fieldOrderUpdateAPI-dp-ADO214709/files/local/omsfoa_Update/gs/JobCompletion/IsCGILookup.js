var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var url = session.parameters.lookupurl;
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var TokenValue = session.parameters.TokenValue;


var PSOMSCompletion = "";
var IsCGI = "";

	session.input.readAsJSON(function(readAsJSONError, incomingdata) {
			var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
		if (incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion != undefined) {
			PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
			IsCGI=PSOMSCompletion.IsCGI;
		}
		
		if (IsCGI === true) {
			
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
		var g = ExternalRefID.split('_');
		var CrewAssignmentId = g[1];
		
		var lookupMessage = {
															"lookupReq": {
																"type": [{
																	"name": "crewAssignmentCustomFields",
																	"externalLabel": "Disposition",
																	"label":"CANT GET IN"
																}
																
																]
															}
														}
														
			var lookupcallwithDisposition_IsCGI = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};

			var info = " TargetURL :" + lookupcallwithDisposition_IsCGI.target + "; Method :" + lookupcallwithDisposition_IsCGI.method + "; Data :" + JSON.stringify(lookupcallwithDisposition_IsCGI.data) + ". ";
			try {
				urlopen.open(lookupcallwithDisposition_IsCGI, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'lookupcallwithDisposition_IsCGI', details are : " + info + "; error info :" + error
						ctx.setVar('dispositionLookup_Error', errorinfo)
						logger.error("id=fior_up496 : " + errorinfo);
						session.reject("id=fior_up496 : " + errorinfo);
					} else {
						ctx.setVar('dispositionLookup_Resp', response)
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'lookupcallwithDisposition_IsCGI', details are : " + info + "; error info :" + error
									ctx.setVar('dispositionLookup_RespError', errorinfo);
									logger.error("id=fior_up497 : " + errorinfo);
									session.reject("id=fior_up497 : " + errorinfo);
								} else {
									ctx.setVar('dispositionLookup_RespData', responseData);
									var DispositionIdArr_IsCGI = responseData.lookupRep.type[0].status;
									logger.debug("id is " + DispositionIdArr_IsCGI);
									ctx.setVariable("dispositionID_IsCGI", DispositionIdArr_IsCGI);

								
								}
							})
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response  from 'lookupcallwithDisposition_IsCGI', details are : " + info + "; error info :" + error
									logger.error("id=fior_up497 : " + errorinfo);
									session.reject("id=fior_up497 : " + errorinfo);
								} else {
									var errorinfo = "error response from 'lookupcallwithDisposition_IsCGI', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up497 : " + errorinfo);
									session.reject("id=fior_up497 : " + errorinfo);
								}
							});
						}
					} //end of else
				}); //end of urlopen

			} catch (err) {
				var errorinfo = "url connection error 'lookupcallwithDisposition_IsCGI', details are : " + info + "; error info :" + err
				ctx.setVar('dispositionLookup_Error', errorinfo)
				logger.error("id=fior_up498 : " + errorinfo);
				session.reject("id=fior_up498 : " + errorinfo);
			}
			
			
	
		}
}
	});
