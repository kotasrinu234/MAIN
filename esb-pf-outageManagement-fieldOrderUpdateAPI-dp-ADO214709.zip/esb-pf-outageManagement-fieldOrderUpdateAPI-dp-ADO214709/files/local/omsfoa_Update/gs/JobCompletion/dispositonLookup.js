var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var url = session.parameters.lookupurl;
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var closeJob = omsfoa_UPdate_jobType.getVariable("closeJob");
var okOnArrival = omsfoa_UPdate_jobType.getVariable("okOnArrival");
var TokenValue = session.parameters.TokenValue;


var PSOMSCompletion = "";
			var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {

if (closeJob === true  && okOnArrival === true) {

	session.input.readAsJSON(function(readAsJSONError, incomingdata) {

		if (incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion != undefined) {
			PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
		}
		
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
		var g = ExternalRefID.split('_');
		var CrewAssignmentId = g[1];
		
		var lookupMessage = {
															"lookupReq": {
																"type": [{
																	"name": "crewAssignmentCustomFields",
																	"externalLabel": "Disposition",
																	"label":"OK ON ARRIVAL"
																}
																
																]
															}
														}
														
			var lookupcallwithDisposition = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};

			var info = " TargetURL :" + lookupcallwithDisposition.target + "; Method :" + lookupcallwithDisposition.method + "; Data :" + JSON.stringify(lookupcallwithDisposition.data) + ". ";
			try {
				urlopen.open(lookupcallwithDisposition, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'lookupcallwithDisposition', details are : " + info + "; error info :" + error
						ctx.setVar('dispositionLookup_Error', errorinfo)
						logger.error("id=fior_up96 : " + errorinfo);
						session.reject("id=fior_up96 : " + errorinfo);
					} else {
						ctx.setVar('dispositionLookup_Resp', response)
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'lookupcallwithDisposition', details are : " + info + "; error info :" + error
									ctx.setVar('dispositionLookup_RespError', errorinfo);
									logger.error("id=fior_up297 : " + errorinfo);
									session.reject("id=fior_up297 : " + errorinfo);
								} else {
									ctx.setVar('dispositionLookup_RespData', responseData);
									var DispositionIdArr = responseData.lookupRep.type[0].status;
									logger.debug("id is " + DispositionIdArr);
									ctx.setVariable("dispositionID", DispositionIdArr);

								
								}
							})
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response  from 'lookupcallwithDisposition', details are : " + info + "; error info :" + error
									logger.error("id=fior_up97 : " + errorinfo);
									session.reject("id=fior_up97 : " + errorinfo);
								} else {
									var errorinfo = "error response from 'lookupcallwithDisposition', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up97 : " + errorinfo);
									session.reject("id=fior_up97 : " + errorinfo);
								}
							});
						}
					} //end of else
				}); //end of urlopen

			} catch (err) {
				var errorinfo = "url connection error 'lookupcallwithDisposition', details are : " + info + "; error info :" + err
				ctx.setVar('dispositionLookup_Error', errorinfo)
				logger.error("id=fior_up96 : " + errorinfo);
				session.reject("id=fior_up96 : " + errorinfo);
			}
			
			
	


	});
	}
}
