var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var url = session.parameters.lookupurl;
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var DispositionIdArr_IsCGI = ctx.getVariable("dispositionID_IsCGI");
var TokenValue = session.parameters.TokenValue;


var PSOMSCompletion = "";
var IsCGI = "";


	session.input.readAsJSON(function(readAsJSONError, incomingdata) {
			var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
		if (incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion != undefined) {
			PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
			IsCGI = PSOMSCompletion.IsCGI;
		}
		
		if (IsCGI === true) {
		
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
		var g = ExternalRefID.split('_');
		var CrewAssignmentId = g[1];
		

		var IsCGIPatchUri = session.parameters.OMS + '/api/v1/ServiceType/Electric/CrewAssignment/' + CrewAssignmentId;

		var IsCGIPatch = {
			target: IsCGIPatchUri,
			sslClientProfile: 'mosfoa_ClientProfile',
			method: 'PATCH',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},
			data: {
				"customFieldValues": { "Disposition": [DispositionIdArr_IsCGI] }
			}
		};

		if ((PSOMSCompletion.CompletionRemarks != undefined) && (PSOMSCompletion.CompletionRemarks != null) && (PSOMSCompletion.CompletionRemarks != '')) {
			var info = " TargetURL :" + IsCGIPatch.target + "; Method :" + IsCGIPatch.method + "; Data :" + JSON.stringify(IsCGIPatch.data) + ". ";

			try {
				urlopen.open(IsCGIPatch, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'IsCGIPatch', details are : " + info + "; error info :" + error
						ctx.setVar('IsCGIPatch_error', errorinfo);
						logger.error("id=fior_up471 : " + errorinfo);
						session.reject("id=fior_up471 : " + errorinfo);
						//throw errorinfo;
					} else {
						ctx.setVar('IsCGIPatch_response', response);
						response.readAsBuffer(function(error, responseData) {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							
								if (error) {
									var errorinfo = "error reading response 'IsCGIPatch', details are : " + info + "; error info :" + error
									ctx.setVar('IsCGIPatch_error', errorinfo);
									logger.error("id=fior_up472 : " + errorinfo);
									session.reject("id=fior_up472 : " + errorinfo);
								} else {
									ctx.setVar('IsCGIPatchUri_response', responseData);
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									ilsCtx.setVariable('ExitStatus', '0');
									logger.debug("response received from IsCGIPatch" +" " + responseStatusCode);
									session.output.write(responseData);
								}
							//});
						} else if (responseStatusCode == 400 || responseStatusCode == 404) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'IsCGIPatch', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								else {
									var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
									if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
										var errorinfo = "error reading response 'IsCGIPatch', details are:" + info + "; response info :" + responseData
									//	ilsCtx.setVariable('ExitStatus', responseStatusCode);
									//	ilsCtx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.output.write(incomingdata);
									}else {
										var errorinfo = "error reading response 'IsCGIPatch', details are: " + info + "; response info : " + responseData
										ilsCtx.setVariable('ExitStatus', responseStatusCode);
										ilsCtx.setVariable('ExitDescription', errorinfo);
										var ctx = session.name('omsfoa') || session.createContext('omsfoa');
										ctx.setVariable('AvoidBackOut', 'yes');
									}
								}
							});
						}else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "id=fior_up0473: error reading response 'IsCGIPatch' , details are : " + info + "; error info :" + error;
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "id=fior_up0473: " + responseData + " error reading response 'IsCGIPatch' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'IsCGIPatch', details are : " + info + "; error info :" + error
									logger.error("id=fior_up473A : " + errorinfo);
									session.reject("id=fior_up473A : " + errorinfo);
								} else {
									var errorinfo = "error response 'IsCGIPatch', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up473B : " + errorinfo);
									session.reject("id=fior_up473B : " + errorinfo);
								}
							});
						}
						});
					}
				});
			} catch (err) {
				var errorinfo = "url connection error 'IsCGIPatch' , details are : " + info + "; error info :" + err
				ctx.setVar('IsCGIPatch_error', errorinfo);
				logger.error("id=fior_up471 : " + errorinfo);
				session.reject("id=fior_up471 : " + errorinfo);
				//throw errorinfo;
			}
			//patch call ends

		}//IsCGIPatch	
	}
	}
	});
