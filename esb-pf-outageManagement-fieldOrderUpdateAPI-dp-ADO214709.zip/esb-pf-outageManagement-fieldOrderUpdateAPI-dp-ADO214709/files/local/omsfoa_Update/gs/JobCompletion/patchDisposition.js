var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var url = session.parameters.lookupurl;
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var closeJob = omsfoa_UPdate_jobType.getVariable("closeJob");
var okOnArrival = omsfoa_UPdate_jobType.getVariable("okOnArrival");
var DispositionIdArr = ctx.getVariable("dispositionID");
var TokenValue = session.parameters.TokenValue;


var PSOMSCompletion = "";
			var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
if (closeJob === true  && okOnArrival === true) {

	session.input.readAsJSON(function(readAsJSONError, incomingdata) {

		if (incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion != undefined) {
			PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
		}
		
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
		var g = ExternalRefID.split('_');
		var CrewAssignmentId = g[1];
		

		var okOnArrivalPatchUri = session.parameters.OMS + '/api/v1/ServiceType/Electric/CrewAssignment/' + CrewAssignmentId;

		var okOnArrivalPatch = {
			target: okOnArrivalPatchUri,
			sslClientProfile: 'mosfoa_ClientProfile',
			method: 'PATCH',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},
			data: {
				"customFieldValues": { "Disposition": [DispositionIdArr] }
			}
		};

		if ((PSOMSCompletion.CompletionRemarks != undefined) && (PSOMSCompletion.CompletionRemarks != null) && (PSOMSCompletion.CompletionRemarks != '')) {
			var info = " TargetURL :" + okOnArrivalPatch.target + "; Method :" + okOnArrivalPatch.method + "; Data :" + JSON.stringify(okOnArrivalPatch.data) + ". ";

			try {
				urlopen.open(okOnArrivalPatch, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'okOnArrivalPatch', details are : " + info + "; error info :" + error
						ctx.setVar('okOnArrivalPatch_error', errorinfo);
						logger.error("id=fior_up271 : " + errorinfo);
						session.reject("id=fior_up271 : " + errorinfo);
						//throw errorinfo;
					} else {
						ctx.setVar('okOnArrivalPatch_response', response);
						response.readAsBuffer(function(error, responseData) {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							
								if (error) {
									var errorinfo = "error reading response 'okOnArrivalPatch', details are : " + info + "; error info :" + error
									ctx.setVar('okOnArrivalPatch_error', errorinfo);
									logger.error("id=fior_up72 : " + errorinfo);
									session.reject("id=fior_up172 : " + errorinfo);
								} else {
									ctx.setVar('okOnArrivalPatchUri_response', responseData);
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									ilsCtx.setVariable('ExitStatus', '0');
									logger.debug("response received from okOnArrivalPatch" +" " + responseStatusCode);
									session.output.write(responseData);
								}
							//});
						} else if (responseStatusCode == 400 || responseStatusCode == 404 ) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'okOnArrivalPatch', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								else {
									var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
									if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
										var errorinfo = "error reading response 'okOnArrivalPatch', details are:" + info + "; response info :" + responseData
									//	ilsCtx.setVariable('ExitStatus', responseStatusCode);
									//	ilsCtx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.output.write(incomingdata);
									}else {
										var errorinfo = "error reading response 'okOnArrivalPatch', details are: " + info + "; response info : " + responseData
										ilsCtx.setVariable('ExitStatus', responseStatusCode);
										ilsCtx.setVariable('ExitDescription', errorinfo);
										var ctx = session.name('omsfoa') || session.createContext('omsfoa');
										ctx.setVariable('AvoidBackOut', 'yes');
									}
								}
							});
						}else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "id=fior_up010: error reading response 'okOnArrivalPatch' , details are : " + info + "; error info :" + error;
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "id=fior_up010: " + responseData + " error reading response 'okOnArrivalPatch' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'okOnArrivalPatch', details are : " + info + "; error info :" + error
									logger.error("id=fior_up73A : " + errorinfo);
									session.reject("id=fior_up73A : " + errorinfo);
								} else {
									var errorinfo = "error response 'okOnArrivalPatch', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up273B : " + errorinfo);
									session.reject("id=fior_up273B : " + errorinfo);
								}
							});
						}
						});
					}
				});
			} catch (err) {
				var errorinfo = "url connection error 'okOnArrivalPatch' , details are : " + info + "; error info :" + err
				ctx.setVar('okOnArrivalPatch_error', errorinfo);
				logger.error("id=fior_up171 : " + errorinfo);
				session.reject("id=fior_up171 : " + errorinfo);
				//throw errorinfo;
			}
			//patch call ends

		}//okOnArrivalPatch	

	});
	}
}
