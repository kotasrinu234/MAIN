var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});

var Engineers = "";
var crewID = "";
var empID = "";
var empName = "";
var PSOMSCompletion = "";
var taskRemarks = "";
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
			var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
	var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;

	if (incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion != undefined) {
		PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
	}
	if (PSOMSCompletion.CompletionRemarks != undefined) {
		taskRemarks = PSOMSCompletion.CompletionRemarks;
	}
	var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
	if ((incomingdata.EFO_Completion_OMSCompletion.Assignment != undefined) && (incomingdata.EFO_Completion_OMSCompletion.Assignment.Engineers[0] != undefined)) {
		Engineers = incomingdata.EFO_Completion_OMSCompletion.Assignment.Engineers[0];
		crewID = Engineers.PSCrewID;
		ctx.setVariable('PScrewID', crewID);
		empID = Engineers.ID;
		empName = Engineers.Name;
	}
	/* var today = new Date();
	var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
	var dt = new Date(); //Date constructor 
	var hh = pad(dt.getHours());
	var mm = pad(dt.getMinutes());
	var ss = pad(dt.getSeconds()); */

	var now = new Date();
	var year = now.getFullYear();
	var month = now.getMonth() + 1;
	var month1 = month.toString();
	var strmonthlength = month1.length;
	var todaymonth;
	if (strmonthlength == 1) {
		todaymonth = '0' + month;
	} else {
		todaymonth = month;
	}

	var day = now.getDate();
	var day1 = day.toString();
	var strdaylength = day1.length;
	var todaydate;
	if (strdaylength == 1) {
		todaydate = '0' + day;
	} else {
		todaydate = day;
	}

	var hour = now.getHours();
	var todayhour = hour.toString();
	var strhourlength = todayhour.length;
	var todayhour;
	if (strhourlength == 1) {
		todayhour = '0' + hour;
	} else {
		todayhour = hour;
	}

	var minute = now.getMinutes();
	var todayminute = minute.toString();
	var strminutelength = todayminute.length;
	var todayminute;
	if (strminutelength == 1) {
		todayminute = '0' + minute;
	} else {
		todayminute = minute;
	}

	var second = now.getSeconds();
	var todaysecond = second.toString();
	var strsecondlength = todaysecond.length;
	var todaysecond;
	if (strsecondlength == 1) {
		todaysecond = '0' + todaysecond;
	} else {
		todaysecond = todaysecond;
	}

	var nowdate = year + '-' + todaymonth + '-' + todaydate;
	var nowtime = todayhour + ':' + todayminute + ':' + todaysecond;

	var g = ExternalRefID.split('_');
	var AssigmentId = g[1];
	var CrewJobId = g[2];
	if (AssigmentId !== undefined) {
		if (readAsJSONError) {
			logger.error("Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {
			var payload = {
				"customFieldValues": {
				}
			}
			//bTrouble
			if (PSOMSCompletion.Trouble != undefined) {
				if (PSOMSCompletion.Trouble == "true") {
					//var bTrouble = 'TRUE';
					//payload.customFieldValues.Trouble ='TRUE';
					payload.customFieldValues.bTrouble = "true";
				} else {
					//var bTrouble = 'FALSE';		
					//payload.customFieldValues.Trouble ='FALSE';
					payload.customFieldValues.bTrouble = "false";
				}
			}
			//bWireDown				
			if (PSOMSCompletion.WireDown != undefined) {

				if (PSOMSCompletion.WireDown == "true") {
					//payload.customFieldValues.WireDown = 'TRUE';
					payload.customFieldValues.bWireDown = "true";
				} else {
					//payload.customFieldValues.WireDown = 'FALSE';
					payload.customFieldValues.bWireDown = "false";
				}
			}
			//bServiceRestoration
			if (PSOMSCompletion.bServiceRestoration != undefined) {

				if (PSOMSCompletion.bServiceRestoration == "true") {
					//payload.customFieldValues.ServiceRestoration = 'TRUE';
					payload.customFieldValues.bServiceRestoration = "true";
				} else {
					//payload.customFieldValues.ServiceRestoration = 'FALSE';				
					payload.customFieldValues.bServiceRestoration = "false";
				}
			}

			//StdMtrNo
			if (PSOMSCompletion.StdMtrNo != undefined) {
				payload.customFieldValues.StdMtrNo = PSOMSCompletion.StdMtrNo;
			}
			//MeterRead1
			if (PSOMSCompletion.MeterRead1 != undefined && PSOMSCompletion.MeterRead1 != null) {
				payload.customFieldValues.MeterRead1 = PSOMSCompletion.MeterRead1;
			}
			//MeterRead2
			if (PSOMSCompletion.MeterRead2 != undefined) {
				payload.customFieldValues.MeterRead2 = PSOMSCompletion.MeterRead2;
			}
			//MeterRead3
			if (PSOMSCompletion.MeterRead3 != undefined) {
				payload.customFieldValues.MeterRead3 = PSOMSCompletion.MeterRead3;
			}
			//MeterRead4
			if (PSOMSCompletion.MeterRead4 != undefined) {
				payload.customFieldValues.MeterRead4 = PSOMSCompletion.MeterRead4;
			}
			//VoltageRead.Name
			if (PSOMSCompletion.VoltageRead != undefined) {
				payload.customFieldValues.VoltageRead = PSOMSCompletion.VoltageRead.Name;
			}
			//LoadDevice.Name
			if (PSOMSCompletion.LoadDevice != undefined) {
				payload.customFieldValues.LoadDevice = PSOMSCompletion.LoadDevice.Name;
			}

			//NoLoadVoltage.Name
			if (PSOMSCompletion.NoLoadVoltage != undefined) {
				payload.customFieldValues.NoLoadVoltage = PSOMSCompletion.NoLoadVoltage.Name;
			}
			//NoLoadV1
			if (PSOMSCompletion.NoLoadV1 != undefined) {
				payload.customFieldValues.NoLoadV1 = PSOMSCompletion.NoLoadV1;
			}
			//NoLoadV2
			if (PSOMSCompletion.NoLoadV2 != undefined) {
				payload.customFieldValues.NoLoadV2 = PSOMSCompletion.NoLoadV2;
			}
			//NoLoadV3
			if (PSOMSCompletion.NoLoadV3 != undefined) {
				payload.customFieldValues.NoLoadV3 = PSOMSCompletion.NoLoadV3;
			}
			//NoLoadV4
			if (PSOMSCompletion.NoLoadV4 != undefined) {
				payload.customFieldValues.NoLoadV4 = PSOMSCompletion.NoLoadV4;
			}
			//NoLoadV5
			if (PSOMSCompletion.NoLoadV5 != undefined) {
				payload.customFieldValues.NoLoadV5 = PSOMSCompletion.NoLoadV5;
			}
			//NoLoadV6
			if (PSOMSCompletion.NoLoadV6 != undefined) {
				payload.customFieldValues.NoLoadV6 = PSOMSCompletion.NoLoadV6;
			}
			//LoadVoltage.Name
			if (PSOMSCompletion.LoadVoltage != undefined) {
				payload.customFieldValues.LoadVoltage = PSOMSCompletion.LoadVoltage.Name;
			}
			//LoadV1
			if (PSOMSCompletion.LoadV1 != undefined) {
				payload.customFieldValues.LoadV1 = PSOMSCompletion.LoadV1;
			}
			//LoadV2
			if (PSOMSCompletion.LoadV2 != undefined) {
				payload.customFieldValues.LoadV2 = PSOMSCompletion.LoadV2;
			}
			//LoadV3
			if (PSOMSCompletion.LoadV3 != undefined) {
				payload.customFieldValues.LoadV3 = PSOMSCompletion.LoadV3;
			}
			//LoadV4
			if (PSOMSCompletion.LoadV4 != undefined) {
				payload.customFieldValues.LoadV4 = PSOMSCompletion.LoadV4;
			}
			//LoadV5
			if (PSOMSCompletion.LoadV5 != undefined) {
				payload.customFieldValues.LoadV5 = PSOMSCompletion.LoadV5;
			}
			//LoadV6
			if (PSOMSCompletion.LoadV6 != undefined) {
				payload.customFieldValues.LoadV6 = PSOMSCompletion.LoadV6;
			}
			//DteEquipDamage.Name
			if (PSOMSCompletion.DteEquipDamage != undefined) {
				payload.customFieldValues.DteEquipDamage = PSOMSCompletion.DteEquipDamage.Name;
			}
			//Task.PSOMSCompletion.DTEDamageTypes.DTEDamageTypes.@DisplayString
			//test this mapping result
			if (PSOMSCompletion.DTEDamageTypes != undefined) {

				var DTEDamageTypes = PSOMSCompletion.DTEDamageTypes;
				var DTEDamageTypesArray = [];

				var DTEDamageTypesString = "";
				DTEDamageTypes.forEach(function(o) {

					DTEDamageTypesString = o.DTEDamageTypes["@DisplayString"]

					if (DTEDamageTypesString) {

						DTEDamageTypesArray.push(DTEDamageTypesString);
					}
				})
				var DTEDamageTypesmsg = "";
				var i;
				for (i = 0; i < DTEDamageTypesArray.length; i++) {
					DTEDamageTypesmsg += DTEDamageTypesArray[i] + '\n';
				}
				//	  session.output.write(DTEDamageTypesmsg);	
				payload.customFieldValues.DTEDamageTypes = DTEDamageTypesmsg;
			}
			//CustEquipDamage.Name
			if (PSOMSCompletion.CustEquipDamage != undefined) {
				payload.customFieldValues.CustEquipDamage = PSOMSCompletion.CustEquipDamage.Name;
			}
			//Task.PSOMSCompletion.CustDamageTypes.CustDamageTypes.@DisplayString
			if (PSOMSCompletion.CustDamageTypes != undefined) {
				var CustDamageTypes = PSOMSCompletion.CustDamageTypes;
				var CustDamageTypesArray = [];
				var CustDamageTypesString = "";
				CustDamageTypes.forEach(function(o) {
					CustDamageTypesString = o.CustDamageTypes["@DisplayString"]
					if (CustDamageTypesString) {
						CustDamageTypesArray.push(CustDamageTypesString);
					}
				})
				var CustDamageTypesmsg = "";
				var i;
				for (i = 0; i < CustDamageTypesArray.length; i++) {
					CustDamageTypesmsg += CustDamageTypesArray[i] + '\n';
				}
				// session.output.write(CustDamageTypesmsg);	
				payload.customFieldValues.CustDamageTypes = CustDamageTypesmsg;
			}
			//CustLoadCenter.Name
			if (PSOMSCompletion.CustLoadCenter != undefined) {
				payload.customFieldValues.CustLoadCenter = PSOMSCompletion.CustLoadCenter.Name;
			}
			//PrimaryWireDwn.Name
			if (PSOMSCompletion.PrimaryWireDwn != undefined) {
				payload.customFieldValues.PrimaryWireDwn = PSOMSCompletion.PrimaryWireDwn.Name;
			}
			//PrimaryWireDwn.Name
			if (PSOMSCompletion.PrimaryArcing != undefined) {
				payload.customFieldValues.PrimaryArcing = PSOMSCompletion.PrimaryArcing.Name;
			}
			//TapeOff.Name
			if (PSOMSCompletion.TapeOff != undefined) {
				payload.customFieldValues.TapeOff = PSOMSCompletion.TapeOff.Name;
			}
			//NumPrimaryWires
			if (PSOMSCompletion.NumPrimaryWires != undefined) {
				payload.customFieldValues.NumPrimaryWires = PSOMSCompletion.NumPrimaryWires;
			}
			//NumPrimarySections
			if (PSOMSCompletion.NumPrimarySections != undefined) {
				payload.customFieldValues.NumPrimarySections = PSOMSCompletion.NumPrimarySections;
			}
			//SecondaryWireDwn.Name
			if (PSOMSCompletion.SecondaryWireDwn != undefined) {
				payload.customFieldValues.SecondaryWireDwn = PSOMSCompletion.SecondaryWireDwn.Name;
			}
			//SecondaryArcing.Name
			if (PSOMSCompletion.SecondaryArcing != undefined) {
				payload.customFieldValues.SecondaryArcing = PSOMSCompletion.SecondaryArcing.Name;
			}
			//SecondaryWireDwn.Name row 49
			/*if(PSOMSCompletion.SecondaryWireDwn != undefined){
				 payload.customFieldValues.SecondaryWireDwn = PSOMSCompletion.SecondaryWireDwn.Name;
			}*/

			//NumSecondaryWires

			if (PSOMSCompletion.SecondaryWireDwn != undefined) {
				payload.customFieldValues.NumSecondaryWires = PSOMSCompletion.SecondaryWireDwn.Name;
			}
			//NumSecondarySections
			if (PSOMSCompletion.NumSecondarySections != undefined) {
				payload.customFieldValues.NumSecondarySections = PSOMSCompletion.NumSecondarySections;
			}
			//ServiceDownWire.Name
			if (PSOMSCompletion.ServiceDownWire != undefined) {
				payload.customFieldValues.ServiceDownWire = PSOMSCompletion.ServiceDownWire.Name;
			}
			//ServiceArcingWire.Name
			if (PSOMSCompletion.ServiceArcingWire != undefined) {
				payload.customFieldValues.ServiceArcingWire = PSOMSCompletion.ServiceArcingWire.Name;
			}
			//ServicePoleWire.Name
			if (PSOMSCompletion.ServicePoleWire != undefined) {
				payload.customFieldValues.ServicePoleWire = PSOMSCompletion.ServicePoleWire.Name;
			}
			//ServiceStructureWire.Name
			if (PSOMSCompletion.ServiceStructureWire != undefined) {
				payload.customFieldValues.ServiceStructureWire = PSOMSCompletion.ServiceStructureWire.Name;
			}
			//ForeignDown.Name
			if (PSOMSCompletion.ForeignDown != undefined) {
				payload.customFieldValues.ForeignDown = PSOMSCompletion.ForeignDown.Name;
			}
			//NumForeignWires
			if (PSOMSCompletion.NumForeignWires != undefined) {
				payload.customFieldValues.NumForeignWires = PSOMSCompletion.NumForeignWires;
			}
			//NumForeignSections
			if (PSOMSCompletion.NumForeignSections != undefined) {
				payload.customFieldValues.NumForeignSections = PSOMSCompletion.NumForeignSections;
			}
			//PldDown.Name
			if (PSOMSCompletion.PldDown != undefined) {
				payload.customFieldValues.PldDown = PSOMSCompletion.PldDown.Name;
			}
			//PldWires
			if (PSOMSCompletion.PldWires != undefined) {
				payload.customFieldValues.PldWires = PSOMSCompletion.PldWires;
			}
			//PldSections
			if (PSOMSCompletion.PldSections != undefined) {
				payload.customFieldValues.PldSections = PSOMSCompletion.PldSections;
			}
			//PlaDown.Name
			if (PSOMSCompletion.PlaDown != undefined) {
				payload.customFieldValues.PlaDown = PSOMSCompletion.PlaDown.Name;
			}
			//PlaWires
			if (PSOMSCompletion.PlaWires != undefined) {
				payload.customFieldValues.PlaWires = PSOMSCompletion.PlaWires;
			}

			//PlaSections
			if (PSOMSCompletion.PlaSections != undefined) {
				payload.customFieldValues.PlaSections = PSOMSCompletion.PlaSections;
			}

			//GuyBroken.Name
			if (PSOMSCompletion.GuyBroken != undefined) {
				payload.customFieldValues.GuyBroken = PSOMSCompletion.GuyBroken.Name;
			}

			//GuyType.Name
			if (PSOMSCompletion.GuyType != undefined) {
				payload.customFieldValues.GuyType = PSOMSCompletion.GuyType.Name;
			}

			//				GuyTypeOther
			if (PSOMSCompletion.GuyTypeOther != undefined) {
				payload.customFieldValues.GuyTypeOther = PSOMSCompletion.GuyTypeOther;
			}

			//Task.PSOMSCompletion.WirePremises.WirePremises."@DisplayString"
			if (PSOMSCompletion.WirePremises != undefined) {

				var WirePremises = PSOMSCompletion.WirePremises;
				var WirePremisesArray = [];
				var WirePremisesString = "";
				WirePremises.forEach(function(o) {
					WirePremisesString = o.WirePremises["@DisplayString"]
					if (WirePremisesString) {
						WirePremisesArray.push(WirePremisesString);
					}
				})
				var WirePremisesmsg = "";
				var i;
				for (i = 0; i < WirePremisesArray.length; i++) {
					WirePremisesmsg += WirePremisesArray[i] + '\n';
				}
				//session.output.write(WirePremisesmsg);	
				payload.customFieldValues.WirePremises = WirePremisesmsg;
			}
			//end
			//WirePremiseOther
			if (PSOMSCompletion.WirePremiseOther != undefined) {
				payload.customFieldValues.WirePremiseOther = PSOMSCompletion.WirePremiseOther;
			}

			//WireLocation.Name
			if (PSOMSCompletion.WireLocation != undefined) {
				payload.customFieldValues.WireLocation = PSOMSCompletion.WireLocation.Name;
			}

			//WireLocationOther
			if (PSOMSCompletion.WireLocationOther != undefined) {
				payload.customFieldValues.WireLocationOther = PSOMSCompletion.WireLocationOther;
			}

			//Task.PSOMSCompletion.DamageTypeWires.DamageTypeWires.@DisplayString
			if (PSOMSCompletion.DamageTypeWires != undefined) {

				var DamageTypeWires = PSOMSCompletion.DamageTypeWires;
				var DamageTypeWiresArray = [];

				var DamageTypeWiresString = "";
				DamageTypeWires.forEach(function(o) {

					DamageTypeWiresString = o.DamageTypeWires["@DisplayString"]

					if (DamageTypeWiresString) {

						DamageTypeWiresArray.push(DamageTypeWiresString);
					}
				})
				var DamageTypeWiresmsg = "";
				var i;
				for (i = 0; i < DamageTypeWiresArray.length; i++) {
					DamageTypeWiresmsg += DamageTypeWiresArray[i] + '\n';
				}
				// session.output.write(DamageTypeWiresmsg);	


				payload.customFieldValues.DamageTypeWires = DamageTypeWiresmsg;
			}
			//end		
			//DamageTypeWireOther
			if (PSOMSCompletion.DamageTypeWireOther != undefined) {
				payload.customFieldValues.DamageTypeWireOther = PSOMSCompletion.DamageTypeWireOther;
			}

			//ServiceDownRestore.Name
			if (PSOMSCompletion.ServiceDownRestore != undefined) {
				payload.customFieldValues.ServiceDownRestore = PSOMSCompletion.ServiceDownRestore.Name;
			}

			//ServiceArcingRestore.Name
			if (PSOMSCompletion.ServiceArcingRestore != undefined) {
				payload.customFieldValues.ServiceArcingRestore = PSOMSCompletion.ServiceArcingRestore.Name;
			}

			//ServicePoleRestore.Name
			if (PSOMSCompletion.ServicePoleRestore != undefined) {
				payload.customFieldValues.ServicePoleRestore = PSOMSCompletion.ServicePoleRestore.Name;
			}

			//ServiceStructureRestore.Name
			if (PSOMSCompletion.ServiceStructureRestore != undefined) {
				payload.customFieldValues.ServiceStructureRestore = PSOMSCompletion.ServiceStructureRestore.Name;
			}

			//ReattachedStructure.Name
			if (PSOMSCompletion.ReattachedStructure != undefined) {
				payload.customFieldValues.ReattachedStructure = PSOMSCompletion.ReattachedStructure.Name;
			}

			//ReattachedPole.Name
			if (PSOMSCompletion.ReattachedPole != undefined) {
				payload.customFieldValues.ReattachedPole = PSOMSCompletion.ReattachedPole.Name;
			}

			//LateralInstalled.Name
			if (PSOMSCompletion.LateralInstalled != undefined) {
				payload.customFieldValues.LateralInstalled = PSOMSCompletion.LateralInstalled.Name;
			}

			//DamageEquipRestore.Name
			if (PSOMSCompletion.DamageEquipRestore != undefined) {
				payload.customFieldValues.DamageEquipRestore = PSOMSCompletion.DamageEquipRestore.Name;
			}

			//PS15DayCompleted.Name
			if (PSOMSCompletion.PS15DayCompleted != undefined) {
				payload.customFieldValues.PS15DayCompleted = PSOMSCompletion.PS15DayCompleted.Name;
			}

			//CompletionRemarks
			if (PSOMSCompletion.CompletionRemarks != undefined) {
				payload.customFieldValues.CompletionRemarks = PSOMSCompletion.CompletionRemarks;
			}

			// session.output.write(payload);
			// /api/ServiceType/{sid}/CrewAssignment/{id}
			var crewAssigmenturi = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + AssigmentId;
			var TokenValue = session.parameters.TokenValue;

			var POSTcrewAssigmenturi = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + AssigmentId + '/Comment';

			//PAtch call starts
			var crewAssigmentapi = {
				target: crewAssigmenturi,
				sslClientProfile: 'mosfoa_ClientProfile',
				method: 'PATCH',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
				data: payload
			};
			var info = " TargetURL :" + crewAssigmentapi.target + "; Method :" + crewAssigmentapi.method + "; Data :" + JSON.stringify(crewAssigmentapi.data) + ". ";
			try {
				urlopen.open(crewAssigmentapi, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'crewAssigmentapi', details are : " + info + "; error info :" + error
						ctx.setVar('patchCrewassignmentfsmToOms', errorinfo);
						logger.error("id=fior_up68 : " + errorinfo);
						ctx.setVar("urlopen connect error with crewAssigmentapi", errorinfo);
						session.reject("id=fior_up68 : " + errorinfo);
						//throw errorinfo;
					} else {
						ctx.setVar('patchCrewassignmentfsmToOms', response);
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'crewAssigmentapi', details are : " + info + "; error info :" + error
								ctx.setVar('patchCrewassignmentfsmToOms', errorinfo);
								logger.error("id=fior_up69 : " + errorinfo);
								session.reject("id=fior_up69 : " + errorinfo);
							} else {
								if (responseStatusCode == 200) {
									ctx.setVar('patchCrewassignmentfsmToOms', responseData);
									hm.response.statusCode = responseStatusCode;
									ilsCtx.setVariable('ExitStatus', '0');
									var responseinfo = "response received from crewAssigmentapi for AssigmentId:" + AssigmentId + " " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.debug("id=fior_up69 : " + responseinfo);
									session.output.write(responseData);
								} else if (responseStatusCode == 400 || responseStatusCode == 404) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error response 'crewAssigmentapi', details are : " + info + "; error info :" + error
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
										else {
									var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
											
											if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
												var errorinfo = "error response 'crewAssigmentapi', details are: " + info + "; response info : " + responseData
											//	ilsCtx.setVariable('ExitStatus', responseStatusCode);
												// ilsCtx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.output.write(incomingdata);
											}else {
										var errorinfo = "error response 'crewAssigmentapi', details are: " + info + "; response info : " + responseData
										ilsCtx.setVariable('ExitStatus', responseStatusCode);
										ilsCtx.setVariable('ExitDescription', errorinfo);
										var ctx = session.name('omsfoa') || session.createContext('omsfoa');
										ctx.setVariable('AvoidBackOut', 'yes');
									}
										}
									});
								} else if (responseStatusCode == 401 || responseStatusCode == 403) {
									// Handle business error responses (HTTP 401 or 403)
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											// Handle error in reading response data
											var errorinfo = "id=fior_up008: error response 'crewAssigmentapi' , details are : " + info + "; error info :" + error;
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "id=fior_up008:" + responseData + " error response 'crewAssigmentapi' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});
								} else {
									var errorinfo = "error response 'crewAssigmentapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up70 : " + errorinfo);
									session.reject("id=fior_up70 : " + errorinfo);
								}
							}
						});
					}
				});
			} catch (err) {
				var errorinfo = "url connection error 'crewAssigmentapi', details are : " + info + "; error info :" + err
				ctx.setVar('patchCrewassignmentfsmToOms', errorinfo);
				logger.error("id=fior_up68 : " + errorinfo);
				ctx.setVar("urlopen connect error with crewAssigmentapi", errorinfo);
				session.reject("id=fior_up68 : " + errorinfo);
				//throw errorinfo;
			}
			//PATCH call ends

			//POST CAll starts
			//commenting and changing the call to CrewJobIduri instead of CrewJobIduriapi as per mapping sheet
			//var customComment = crewID + ' ' + empName + ' (' + empID + ')' + ' ' + 'Completed ON' + ' ' + date + ' AT ' + hh + ':' + mm + ':' + ss;
			// adding comments in this format: REMARKS AMENDMENT BY <Crew ID> <EMP NAME>  ( <EMP ID>  ) ON <date YYYY-MM-DD> AT <time HH24:MM:SS> - <COMMENTS>
			if (CrewJobId !== undefined) {
				if (taskRemarks != undefined) {
					var customComment = 'REMARKS AMENDMENT BY ' + crewID + ' ' + empName + ' (' + empID + ')' + ' ' + 'ON' + ' ' + nowdate + ' AT ' + nowtime + ' - ' + taskRemarks;
				}
				else {
					var customComment = 'REMARKS AMENDMENT BY ' + crewID + ' ' + empName + ' (' + empID + ')' + ' ' + 'ON' + ' ' + nowdate + ' AT ' + nowtime;
				}
				var CrewJobIduri = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + CrewJobId + '/Comment';
				var CrewJobIduriapi = {
					target: CrewJobIduri,
					sslClientProfile: 'mosfoa_ClientProfile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: {
						"comment": customComment
					}
				};

				if ((PSOMSCompletion.CompletionRemarks != undefined) && (PSOMSCompletion.CompletionRemarks != null) && (PSOMSCompletion.CompletionRemarks != '')) {
					var info = " TargetURL :" + CrewJobIduriapi.target + "; Method :" + CrewJobIduriapi.method + "; Data :" + JSON.stringify(CrewJobIduriapi.data) + ". ";
					try {
						urlopen.open(CrewJobIduriapi, function(error, response) {
							if (error) {
								var errorinfo = "url connection error 'CrewJobIduriapi', details are : " + info + "; error info :" + error
								ctx.setVar('patchCrewassignment_comment', errorinfo);
								logger.error("id=fior_up71 : " + errorinfo);
								ctx.setVar("urlopen connect error with CrewJobIduriapi", errorinfo);
								session.reject("id=fior_up71 : " + errorinfo);
								//throw errorinfo;
							} else {
								ctx.setVar('patchCrewassignment_comment', response);
								// read response data
								// get the response status code
								var responseStatusCode = response.statusCode;
								var responseReasonPhrase = response.reasonPhrase;
								if (responseStatusCode == 200) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'CrewJobIduriapi', details are : " + info + "; error info :" + error
											ctx.setVar('patchCrewassignment_comment', errorinfo);
											logger.error("id=fior_up72 : " + errorinfo);
											session.reject("id=fior_up72 : " + errorinfo);
										} else {
											ctx.setVar('patchCrewassignment_comment', responseData);
											hm.response.statusCode = responseStatusCode;
											hm.response.statusCode = responseStatusCode;
											ilsCtx.setVariable('ExitStatus', '0');
											logger.debug("response received from CrewJobIduriapi for CrewJobId:" + CrewJobId + " " + responseStatusCode);
											session.output.write(responseData);
										}
									});
								} else if (responseStatusCode == 400 || responseStatusCode == 404) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'CrewJobIduriapi', details are : " + info + "; error info :" + error
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
										else {
											var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
											if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
												var errorinfo = "error reading response 'CrewJobIduriapi', details are:" + info + "; response info : " + responseData
												//ilsCtx.setVariable('ExitStatus', responseStatusCode);
											//	ilsCtx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.output.write(incomingdata);
											} else {
										var errorinfo = "error reading response 'CrewJobIduriapi', details are:" + info + "; response info : " + responseData
										ilsCtx.setVariable('ExitStatus', responseStatusCode);
										ilsCtx.setVariable('ExitDescription', errorinfo);
										var ctx = session.name('omsfoa') || session.createContext('omsfoa');
										ctx.setVariable('AvoidBackOut', 'yes');
									}
										}
									});
								} else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'CrewJobIduriapi', details are : " + info + "; error info :" + error
											logger.error("id=fior_up73A: " + CrewJobId + " responsecode:" + responseStatusCode + " " + JSON.stringify(errorinfo));
											session.reject("id=fior_up73A :" + CrewJobId + " responsecode:" + responseStatusCode + " " + errorinfo);
										} else {
											var errorinfo = "error response 'CrewJobIduriapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											logger.error("id=fior_up73B :" + errorinfo);
											session.reject("id=fior_up73B : " + errorinfo);
										}
									});
								}
							}
						});
					} catch (err) {
						var errorinfo = "url connection error 'CrewJobIduriapi', details are : " + info + "; error info :" + err
						ctx.setVar('patchCrewassignment_comment', errorinfo);
						logger.error("id=fior_up71 : " + errorinfo);
						ctx.setVar("urlopen connect error with CrewJobIduriapi" + JSON.stringify(errorinfo));
						session.reject("id=fior_up71 : " + errorinfo);
						//throw errorinfo;
					}
					//post call ends
				}
				///
			}
		}
	} else {
		logger.error("id=fior_up74|ExternalRefID doesn't have CrewAssignmentId in incoming message");
	}
	}
});

function pad(n) {
	return (n < 10) ? ("0" + n) : n;
}
