var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var Engineers = "";
var crewID = "";
var empID = "";
var empName = "";
var incomingdata = ctx.getVariable('decodedRequest');
/* session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("id=fior_up117|omsjobid is not passed in incoming dataError in reading incoming data");
		session.reject(readAsJSONError);
	} else { */
			var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {	
if (incomingdata.EFO_Completion_OMSCompletion.Task.TaskTypeCategory.Name == 'OMS') {
	if (incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID !== undefined) {
		if (incomingdata.EFO_Completion_OMSCompletion.Task.Attachments !== undefined) {
			var attachments = incomingdata.EFO_Completion_OMSCompletion.Task.Attachments;
			if (attachments.length > 0) {

				var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
				var g = ExternalRefID.split('_');

				var CrewAssignmentId = g[1];

				if (incomingdata.EFO_Completion_OMSCompletion.Assignment != undefined && incomingdata.EFO_Completion_OMSCompletion.Assignment.Engineers[0] != undefined) {
					Engineers = incomingdata.EFO_Completion_OMSCompletion.Assignment.Engineers[0];
					crewID = Engineers.PSCrewID;
					empID = Engineers.ID;
					empName = Engineers.Name;
				}
				var statusname = 'Completed';
				fs.readAsXML('local:///omsfoa_Update/xml/mosfoa_EnvSpecificConfig.xml', function(error, envdetails) {
					if (error) {
						logger.error("id=fior_up117|error while reading the mosfoa_EnvSpecificConfig.xml file");
						throw error; // throw and stop processing
					} else {
						///api/ServiceType/{sid}/CrewAssignment/{id}
						var crewAssignmentIduri = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentId;
						var TokenValue = session.parameters.TokenValue;
						var status = incomingdata.EFO_Completion_OMSCompletion.Task.Status.Name;

						var crewAssignmentWorkTypeapi = {
							target: crewAssignmentIduri,
							sslClientProfile: 'mosfoa_ClientProfile',
							method: 'GET',
							contentType: 'application/json',
							headers: {
								'osiApiToken': TokenValue
							}
						};
						var info = " TargetURL :" + crewAssignmentWorkTypeapi.target + "; Method :" + crewAssignmentWorkTypeapi.method + ". ";
						try {
							urlopen.open(crewAssignmentWorkTypeapi, function(error, response) {
								if (error) {
									var errorinfo = "url connection error 'crewAssignmentWorkTypeapi', details are : " + info + "; error info :" + error
									ctx.setVar('getCrewAssignmentID', errorinfo);
									// an error occurred during request sending or response header parsing
									logger.error("id=fior_up118 : " + errorinfo);
									ctx.setVar("url connection error 'crewAssignmentWorkTypeapi'", errorinfo);
									session.reject("id=fior_up118 : " + errorinfo);
									//throw errorinfo;
								} else {
									ctx.setVar('getCrewAssignmentID', response);
									// read response data
									// get the response status code
									//var ctx = session.name('myContext') || session.createContext('myContext');
									var responseStatusCode = response.statusCode;
									var responseReasonPhrase = response.reasonPhrase;
									if (responseStatusCode == 200 || responseStatusCode == 404) {

										if (responseStatusCode == 200) {
											//if block for 200 response code
											response.readAsJSON(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'crewAssignmentWorkTypeapi', details are : " + info + "; error info :" + error
													ctx.setVar('getCrewAssignmentID', errorinfo);
													// error while reading response or transferring data to Buffer
													logger.error("id=fior_up119 : " + errorinfo);
													session.reject("id=fior_up119 : " + errorinfo);
												} else {
													ctx.setVar('getCrewAssignmentID_worktypeId', responseData.workTypeID);
													ctx.setVar('getCrewAssignmentID_currentStatus', responseData.status);
													//ctx.setVariable('lookupresponse',responseData);
													hm.response.statusCode = responseStatusCode;
													ilsCtx.setVariable('ExitStatus', '0');
													//hm.response.statusCode = responseStatusCode;
													logger.debug("id=fior_up120|response received from crewAssignmentWorkTypeapi for crewAssignmentId:" + CrewAssignmentId + " " + responseStatusCode);
													//var response = responseData;
													//var CrewassignmentGETResponse = JSON.parse(response).workTypeID;
													ctx.setVar('getCrewAssignmentID_RESPONSE_DATA', responseData);

													var workTypeID = responseData.workTypeID;
													var currentStatus = responseData.status;
													var crewExternalId = '';

													//var LookupStatus = status; 
													//	logger.error("LookupStatus+++", +pars(LookupStatus));

													//	logger.error("LookupStatus+++", (LookupStatus).toString());

													//	session.output.write(LookupStatus);
													// Calling lookup service start

													if (workTypeID != null) {
														var lookupMessage = {
															"lookupReq": {
																"type": [{
																	"name": "workType.workflows",
																	"id": workTypeID,
																	"label": statusname
																},
																{
																	"name": "workType.workflows",
																	"id": workTypeID,
																	"status": currentStatus
																}
																]
															}
														}
														var TokenValue = session.parameters.TokenValue;
														var url = session.parameters.lookupurl;
														//invoking lookup service and storing response in a var
														//var url="http://10.0.10.228:1214";
														ctx.setVar('LookupMessage', lookupMessage);
														var LookupServiceResponse = {
															target: url,
															method: 'POST',
															contentType: 'application/json',
															data: lookupMessage
														};

														logger.info("response" + LookupServiceResponse);

														//calling lookup service end
														var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
														try {
															urlopen.open(LookupServiceResponse, function(error, response) {
																if (error) {
																	var errorinfo = "url connection error 'LookupServiceResponse', details are : " + info + "; error info :" + error
																	ctx.setVar('postLookup', errorinfo);
																	// an error occurred during request sending or response header parsing
																	logger.error("id=fior_up121 : " + errorinfo);
																	session.reject("id=fior_up121 : " + errorinfo);
																	//throw errorinfo;
																} else {
																	ctx.setVar('postLookup', response);
																	// read response data
																	// get the response status code
																	var responseStatusCode = response.statusCode;
																	var responseReasonPhrase = response.reasonPhrase;
																	if (responseStatusCode == 200) {
																		response.readAsJSON(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'LookupServiceResponse', details are : " + info + "; error info :" + error
																				ctx.setVar('postLookup', errorinfo);
																				// error while reading response or transferring data to Buffer
																				logger.error("id=fior_up122 : " + errorinfo);
																				session.reject("id=fior_up122 : " + errorinfo);
																			} else {
																				ctx.setVar('postLookup', responseData);
																				hm.response.statusCode = responseStatusCode;
																				ilsCtx.setVariable('ExitStatus', '0');
																				logger.debug("response received from LookupServiceResponse " + responseData);
																				console.info("LOOKUP RESPONSE ::::::" + JSON.stringify(responseData));
																				//session.output.write(JSON.parse(responseData));
																				// lookupresponse is stored in lookupresponse var now

																				//starting for post for comments and status
																				//if(responseData.lookupRep.type[0].result==0)	
																				{
																					//POST /api/v1/ServiceType/{sid}/CrewAssignment/{id}/WorkFlow
																					var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
																					var g = ExternalRefID.split('_');

																					var CrewAssignmentId = g[1];
																					//	var CrewAssignmentid = incomingdata.EFO_Completion_OMSCompletion.Task.crewAssignmentId;

																					var CrewAssigmenturi = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentId + '/WorkFlow';
																					var TokenValue = session.parameters.TokenValue;
																					var LookupLabel = responseData.lookupRep.type[0].label;
																					var LookupStatus = responseData.lookupRep.type[0].status;
																					var currentLookupLabel = responseData.lookupRep.type[1].label;

																					//var crewID = crewID;
																					//var empid = empid;
																					/* today = new Date();
																					var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
																					var dt = new Date(); //Date constructor 
																					var hh = pad(dt.getHours());
																					var mm = pad(dt.getMinutes());
																					var ss = pad(dt.getSeconds()); */

																					var now = new Date();
																					var year = now.getFullYear();
																					var month = now.getMonth() + 1;
																					var month1 = month.toString();
																					var strmonthlength = month1.length;
																					var todaymonth;
																					if (strmonthlength == 1) {
																						todaymonth = '0' + month;
																					} else {
																						todaymonth = month;
																					}

																					var day = now.getDate();
																					var day1 = day.toString();
																					var strdaylength = day1.length;
																					var todaydate;
																					if (strdaylength == 1) {
																						todaydate = '0' + day;
																					} else {
																						todaydate = day;
																					}

																					var hour = now.getHours();
																					var todayhour = hour.toString();
																					var strhourlength = todayhour.length;
																					var todayhour;
																					if (strhourlength == 1) {
																						todayhour = '0' + hour;
																					} else {
																						todayhour = hour;
																					}

																					var minute = now.getMinutes();
																					var todayminute = minute.toString();
																					var strminutelength = todayminute.length;
																					var todayminute;
																					if (strminutelength == 1) {
																						todayminute = '0' + minute;
																					} else {
																						todayminute = minute;
																					}

																					var second = now.getSeconds();
																					var todaysecond = second.toString();
																					var strsecondlength = todaysecond.length;
																					var todaysecond;
																					if (strsecondlength == 1) {
																						todaysecond = '0' + todaysecond;
																					} else {
																						todaysecond = todaysecond;
																					}

																					var nowdate = year + '-' + todaymonth + '-' + todaydate;
																					var nowtime = todayhour + ':' + todayminute + ':' + todaysecond;
																					var engineerid = incomingdata.EFO_Completion_OMSCompletion.Assignment.Engineers[0].ID;
																					var customcomment = '';
																					//var taskStatusName = incomingdata.EFO_Completion_OMSCompletion.Task.Status.Name;
																					//if(incomingdata.EFO_Completion_OMSCompletion.Task.Status.Name !== 'Ready to Assign'){

																					/* customcomment = 'CREW ' + crewExternalId + ' REASSIGNED TO '+ empid;		 */
																					//}else{
																					// adding comments in this format: REMARKS AMENDMENT BY <Crew ID> <EMP NAME>  ( <EMP ID>  ) ON <date YYYY-MM-DD> AT <time HH24:MM:SS> - <COMMENTS>	
																					// customcomment = crewID + ' ' + empname + '(' + empid + ')' + statusname + ' ON ' + date + ' AT ' + hh + ':' + mm + ':' + ss;

																					//var taskRemarks = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion.CompletionRemarks;
																					/* if (taskRemarks != undefined){
																					customcomment = 'REMARKS AMENDMENT BY ' + crewID + ' ' + empName + ' (' + empID + ')' + ' ' + 'ON' + ' ' + date + ' AT ' + hh + ':' + mm + ':' + ss + ' - ' + taskRemarks;
																					}
																					else{ */
																					customcomment = crewID + ' ' + empName + ' (' + empID + ')' + ' ' + 'Completed ON' + ' ' + nowdate + ' AT ' + nowtime;
																					//}
																					//}
																					//var customcomment='';
																					//var taskStatus =incomingdata.EFO_Completion_OMSCompletion.Task.Status.Name;
																					/*if(LookupLabel=='none'){
																			//POST /api/ServiceType/{sid}/Job/{id}/Comments
 customcomment = 'The label doesnt match - '+taskStatus;
																		}else{
																			 customcomment = 'The crew status has changed to - '+taskStatus;
																		}*/
																					ctx.setVar('customcomment', customcomment);
																					//omsfoa_UPdate_jobType.setVariable("customComment", customcomment);
																					var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
																					var g = ExternalRefID.split('_');
																					var CrewJobId = g[2];
																					//var CrewJobId = incomingdata.EFO_Completion_OMSCompletion.Task.omsJobId;
																					var CrewJobIduri = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + CrewJobId + '/Comment';
																					var TokenValue = session.parameters.TokenValue;
																					var status = incomingdata.EFO_Completion_OMSCompletion.Task.Status.Name;
																					var comment = ""
																					var payload = {
																						comment: customcomment
																					}
																					var CrewJobIduriStatusPost = {
																						target: CrewJobIduri,
																						sslClientProfile: 'mosfoa_ClientProfile',
																						method: 'POST',
																						contentType: 'application/json',
																						headers: {
																							'osiApiToken': TokenValue
																						},
																						data: payload
																					};

																					//if(incomingdata.EFO_Completion_OMSCompletion.Task.Status.Name !== 'Ready to Assign'){
																					//if ((taskRemarks != undefined)&& (taskRemarks != null) && (taskRemarks != '')){
																					var info = " TargetURL :" + CrewJobIduriStatusPost.target + "; Method :" + CrewJobIduriStatusPost.method + "; Data :" + JSON.stringify(CrewJobIduriStatusPost.data) + ". ";
																					try {
																						urlopen.open(CrewJobIduriStatusPost, function(error, response) {
																							if (error) {
																								var errorinfo = "url connection error 'CrewJobIduriStatusPost', details are : " + info + "; error info :" + error
																								ctx.setVar('postJobId_comments2', errorinfo);
																								// an error occurred during request sending or response header parsing
																								logger.error("id=fior_up123 : " + errorinfo);
																								session.reject("id=fior_up123 : " + errorinfo);
																								//throw errorinfo;
																							} else {
																								ctx.setVar('postJobId_comments2', response);
																								// read response data
																								// get the response status code
																								var responseStatusCode = response.statusCode;
																								var responseReasonPhrase = response.reasonPhrase;
																								if (responseStatusCode == 200 || responseStatusCode == 404) {
																									response.readAsJSON(function(error, responseData) {
																										if (error) {
																											var errorinfo = "error reading response 'CrewJobIduriStatusPost', details are : " + info + "; error info :" + error
																											ctx.setVar('postJobId_comments2', errorinfo);
																											// error while reading response or transferring data to Buffer
																											logger.error("id=fior_up124 : " + errorinfo);
																											session.reject("id=fior_up124 : " + errorinfo);
																										} else {
																											ctx.setVar('postJobId_comments2', responseData);
																											hm.response.statusCode = responseStatusCode;
																											ilsCtx.setVariable('ExitStatus', '0');
																											var responseinfo = "response received from CrewJobIduriStatusPost for CrewJobId:" + CrewJobId + " " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																											logger.debug("id=fior_up124 : " + responseinfo);
																											session.output.write(responseData);
																										}
																									});
																								} else if (responseStatusCode == 400 || responseStatusCode == 404) {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											var errorinfo = "error response received from 'CrewJobIduriStatusPost' call, details are : " + info + "; error info :" + error
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										}
																										else {
																											var BusinessResponseData = responseData;
																											var buff = Buffer.from(BusinessResponseData);
																											var ResponseString = buff.toString();
																											if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																												var errorinfo = "error response received from 'CrewJobIduriStatusPost' call, details are: " + info + "; response info :" + responseData
																											//	ilsCtx.setVariable('ExitStatus', responseStatusCode);
																											//	ilsCtx.setVariable('ExitDescription', errorinfo);
																												logger.error(errorinfo);
																												session.output.write(incomingdata);
																											} else {
																												var errorinfo = "error response received from 'CrewJobIduriStatusPost' call, details are: " + info + "; response info : " + responseData
																												ilsCtx.setVariable('ExitStatus', responseStatusCode);
																												ilsCtx.setVariable('ExitDescription', errorinfo);
																												var ctx = session.name('omsfoa') || session.createContext('omsfoa');
																												ctx.setVariable('AvoidBackOut', 'yes');
																											}
																										}
																									});
																								} else if (responseStatusCode == 401 || responseStatusCode == 403) {
																									// Handle business error responses (HTTP 401 or 403)
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											// Handle error in reading response data
																											var errorinfo = "id=fior_up005: error response received from 'CrewJobIduriStatusPost' call , details are : " + info + "; error info :" + error;
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										} else {
																											var errorinfo = "id=fior_up005: " + responseData + " error response received from 'CrewJobIduriStatusPost' call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										}
																									});
																								} else {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											var errorinfo = "error reading response 'CrewJobIduriStatusPost for CrewJobId: ' " + CrewJobId + ", details are : " + info + "; error info :" + error
																											logger.error("id=fior_up124 : " + errorinfo);
																											session.reject("id=fior_up124 : " + errorinfo);
																										} else {
																											var errorinfo = "error response 'CrewJobIduriStatusPost for CrewJobId: ' " + CrewJobId + ", details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																											logger.error("id=fior_up124 : " + errorinfo);
																											session.reject("id=fior_up124 : " + errorinfo);
																										}
																									});
																								}
																							}
																						});
																					} catch (err) {
																						var errorinfo = "url connection error 'CrewJobIduriStatusPost', details are : " + info + "; error info :" + err
																						ctx.setVar('postJobId_comments2', errorinfo);
																						// an error occurred during request sending or response header parsing
																						logger.error("id=fior_up123 : " + errorinfo);
																						session.reject("id=fior_up123 : " + errorinfo);
																						//throw errorinfo;
																					}
																					//}
																					//}// end of ready to assign condition for comments

																					var payload2 = {
																						status: LookupStatus
																					};
																					/*var payload = {
																							
																							status : 2
																					};*/
																					var crewAssignmentapiStatusPost = {
																						target: CrewAssigmenturi,
																						sslClientProfile: 'mosfoa_ClientProfile',
																						method: 'POST',
																						contentType: 'application/json',
																						headers: {
																							'osiApiToken': TokenValue
																						},
																						data: payload2
																					};

																					if (LookupLabel !== 'none' && currentLookupLabel !== 'Completed') {
																						var info = " TargetURL :" + crewAssignmentapiStatusPost.target + "; Method :" + crewAssignmentapiStatusPost.method + "; Data :" + JSON.stringify(crewAssignmentapiStatusPost.data) + ". ";
																						try {
																							urlopen.open(crewAssignmentapiStatusPost, function(error, response) {
																								if (error) {
																									var errorinfo = "url connection error 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + error
																									ctx.setVar('postCrewAssignmentID_workflow', errorinfo);
																									// an error occurred during request sending or response header parsing
																									logger.error("id=fior_up126 : " + errorinfo);
																									session.reject("id=fior_up126 : " + errorinfo);
																									//throw errorinfo;
																								} else {
																									ctx.setVar('postCrewAssignmentID_workflow', response);
																									// read response data
																									// get the response status code
																									var responseStatusCode = response.statusCode;
																									var responseReasonPhrase = response.reasonPhrase;
																									if (responseStatusCode == 200 || responseStatusCode == 404) {
																										response.readAsJSON(function(error, responseData) {
																											if (error) {
																												var errorinfo = "error reading response 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + error
																												ctx.setVar('postCrewAssignmentID_workflow', errorinfo);
																												// error while reading response or transferring data to Buffer
																												logger.error("id=fior_up127 : " + errorinfo);
																												session.reject("id=fior_up127 : " + errorinfo);
																											} else {
																												ctx.setVar('postCrewAssignmentID_workflow', responseData);
																												hm.response.statusCode = responseStatusCode;
																												ilsCtx.setVariable('ExitStatus', '0');
																												logger.debug("id=fior_up128|response received from crewAssignmentapiStatusPost for CrewAssignmentId:" + CrewAssignmentId + " " + responseStatusCode);
																												session.output.write(responseData);
																											}
																										});
																									} else if (responseStatusCode == 400 || responseStatusCode == 404) {
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												var errorinfo = "error response reecived from 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + error
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											}
																											else {
																												var BusinessResponseData = responseData;
																												var buff = Buffer.from(BusinessResponseData);
																												var ResponseString = buff.toString();
																												if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																													var errorinfo = "error response reecived from 'crewAssignmentapiStatusPost', details are:" + info + "; response info :" + responseData
																												//	ilsCtx.setVariable('ExitStatus', responseStatusCode);
																												//	ilsCtx.setVariable('ExitDescription', errorinfo);
																													logger.error(errorinfo);
																													session.output.write(incomingdata);
																												} else {
																													var errorinfo = "error response reecived from 'crewAssignmentapiStatusPost', details are:" + info + "; response info : " + responseData
																													ilsCtx.setVariable('ExitStatus', responseStatusCode);
																													ilsCtx.setVariable('ExitDescription', errorinfo);
																													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
																													ctx.setVariable('AvoidBackOut', 'yes');
																												}
																											}
																										});
																									} else if (responseStatusCode == 401 || responseStatusCode == 403) {
																										// Handle business error responses (HTTP 401 or 403)
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												// Handle error in reading response data
																												var errorinfo = "id=fior_up006:  error response reecived from 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + error;
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											} else {
																												var errorinfo = "id=fior_up006:" + responseData + " error response reecived from 'crewAssignmentapiStatusPost', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											}
																										});
																									} else {
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												var errorinfo = "error reading response 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + error
																												logger.error("id=fior_up129 : " + CrewAssignmentId + " responsecode:" + responseStatusCode + " " + errorinfo);
																												session.reject("id=fior_up129 : " + CrewAssignmentId + " responsecode:" + responseStatusCode + " " + errorinfo);
																											} else {
																												var errorinfo = "error response 'crewAssignmentapiStatusPost', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																												logger.error("id=fior_up129 : " + CrewAssignmentId + errorinfo);
																												session.reject("id=fior_up129 : " + CrewAssignmentId + errorinfo);
																											}
																										});
																									}
																								}
																							});
																						} catch (err) {
																							var errorinfo = "url connection error 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + err
																							ctx.setVar('postCrewAssignmentID_workflow', errorinfo);
																							// an error occurred during request sending or response header parsing
																							logger.error("id=fior_up126 : " + errorinfo);
																							session.reject("id=fior_up126 : " + errorinfo);
																							//	throw errorinfo;
																						}
																					}
																				}

																			}
																		});
																	} else {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'LookupServiceResponse', details are : " + info + "; error info :" + error
																				logger.error("id=fior_up131 : " + responseStatusCode + " " + JSON.stringify(errorinfo));
																				session.reject("id=fior_up131 : " + responseStatusCode + " " + errorinfo);
																			} else {
																				var errorinfo = "error response 'LookupServiceResponse', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																				logger.error("id=fior_up131 : " + errorinfo);
																				session.reject("id=fior_up131 : " + errorinfo);
																			}
																		});
																	}
																}
															});
														} catch (err) {
															var errorinfo = "url connection error 'LookupServiceResponse', details are : " + info + "; error info :" + err
															ctx.setVar('postLookup', errorinfo);
															logger.error("id=fior_up121 : " + errorinfo);
															session.reject("id=fior_up121 : " + errorinfo);
															//throw errorinfo;
														}

														//closing worktypeid
													}
												}
											});
											//if block close for status code 200
										} else if (responseStatusCode == 400 ||responseStatusCode == 404) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "error response received from CrewAssignment, details are : " + info + "; error info :" + error
													logger.error(errorinfo);
													session.reject(errorinfo);
												}
												else {
													var BusinessResponseData = responseData;
													var buff = Buffer.from(BusinessResponseData);
													var ResponseString = buff.toString();
													if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
														var errorinfo = "error response received from CrewAssignment, details are:" + info + "; response info :" + responseData
														//ilsCtx.setVariable('ExitStatus', responseStatusCode);
														//ilsCtx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.output.write(incomingdata);
													} else {
														var errorinfo = "error response received from CrewAssignment, details are:" + info + "; response info : " + responseData
														ilsCtx.setVariable('ExitStatus', responseStatusCode);
														ilsCtx.setVariable('ExitDescription', errorinfo);
														var ctx = session.name('omsfoa') || session.createContext('omsfoa');
														ctx.setVariable('AvoidBackOut', 'yes');
													}
												}
											});
										} else if (responseStatusCode == 401 || responseStatusCode == 403) {
											// Handle business error responses (HTTP 401 or 403)
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													// Handle error in reading response data
													var errorinfo = "id=fior_up004: error response received from CrewAssignment, details are : " + info + "; error info :" + error;
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "id=fior_up004:" + responseData + " error response received from CrewAssignment, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
													logger.error(errorinfo);
													session.reject(errorinfo);
												}
											});
										}
										//if block for 200 and 400 code stops
									} else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'crewAssignmentWorkTypeapi', details are : " + info + "; error info :" + errorinfo
												logger.error("id=fior_up133 : " + CrewAssignmentId + " responsecode:" + responseStatusCode + " " + JSON.stringify(errorinfo));
												session.reject("id=fior_up133 : " + CrewAssignmentId + " responsecode:" + responseStatusCode + " " + errorinfo);
											} else {
												var errorinfo = "error response 'crewAssignmentWorkTypeapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												logger.error("id=fior_up133 : " + CrewAssignmentId + errorinfo);
												session.reject("id=fior_up133 : " + CrewAssignmentId + errorinfo);
											}
										});
									}
								}
							});
						} catch (err) {
							var errorinfo = "url connection error 'crewAssignmentWorkTypeapi', details are : " + info + "; error info :" + err
							ctx.setVar('getCrewAssignmentID', errorinfo);
							logger.error("id=fior_up118A : " + errorinfo);
							ctx.setVar("urlopen connect error with crewAssignmentWorkTypeapi", errorinfo);
							session.reject("id=fior_up118A : " + errorinfo);
							//throw errorinfo;
						}
					}
				});
			}
		}
	} else {
		logger.error("id=fior_up135|ExternalRefID is not passed in incoming data");
	}
}
//}
//});
}
function pad(n) {
	return (n < 10) ? ("0" + n) : n;
}
