var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var lookupuri = session.parameters.lookupurl;
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("id=fior_up89|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
	    var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
		var PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
		var ExternalRefIDArray = ExternalRefID.split('_');
		var Crewid = ExternalRefIDArray[1];
		var Jobid = ExternalRefIDArray[2];
		var IsCGI = '';
		var getjoburi = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + Jobid;
		var TokenValue = session.parameters.TokenValue;
		if (incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion != undefined) {
			var PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
	        if (PSOMSCompletion.IsCGI != undefined) {
				IsCGI = PSOMSCompletion.IsCGI;
			}
		}

		var getjobapiIsCGI = {
			target: getjoburi,
			sslClientProfile: 'mosfoa_ClientProfile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			}
		};

		var info = " TargetURL :" + getjobapiIsCGI.target + "; Method :" + getjobapiIsCGI.method + ". ";
		if (IsCGI === true) {
			try {
				urlopen.open(getjobapiIsCGI, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'getjobapiIsCGI', details are : " + info + "; error info :" + error
						ctx.setVar('getJobId', errorinfo);
						logger.error("id=fior_up91 : " + errorinfo);
						session.reject("id=fior_up91 : " + errorinfo);
					} else {
						ctx.setVar('getJobId', response);
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'getjobapiIsCGI', details are : " + info + "; error info :" + error
									ctx.setVar('getJobId', errorinfo);
									logger.error("id=fior_up92 : " + errorinfo);
									session.reject("id=fior_up92 : " + errorinfo);
								} else {
									ctx.setVar('getJobId', responseData);
									hm.response.statusCode = '200 Message is received';
									ilsCtx.setVariable('ExitStatus', '0');
									console.info("ResponseData" + responseData);

									var jobTypeIDValue = responseData.jobTypeID;
									var leadCallId = responseData.leadCallID;

									omsfoa_UPdate_jobType.setVariable("jobTypeIDValue", jobTypeIDValue);
									omsfoa_UPdate_jobType.setVariable("leadCallId", leadCallId);
									logger.debug("response received from getjoburi call:" + responseData);
									logger.debug("jobTypeIDValue received from getjoburi call:" + jobTypeIDValue);

									/* start of lookup call based on jobTypeID */

									var outageReq = {
										name: "jobOutageTypes",
										id: jobTypeIDValue
									}

									var typedata = {
										name: "jobTypes",
										id: jobTypeIDValue
									}

									var typevalue = [

										typedata,
										outageReq
									]

									var lookupReq = {
										type: typevalue
									}

									var lookupRequest = {
										lookupReq: lookupReq
									}

									var lookupcallwithJobTypeId = {
										target: lookupuri,
										method: 'POST',
										contentType: 'application/json',
										data: lookupRequest
									};

									var info = " TargetURL :" + lookupcallwithJobTypeId.target + "; Method :" + lookupcallwithJobTypeId.method + "; Data :" + JSON.stringify(lookupcallwithJobTypeId.data) + ". ";
									try {
										urlopen.open(lookupcallwithJobTypeId, function(error, response) {
											if (error) {
												var errorinfo = "url connection error 'lookupcallwithJobTypeId', details are : " + info + "; error info :" + error
												ctx.setVar('postJobTypeId', errorinfo);
												logger.error("id=fior_up93 : " + errorinfo);
												session.reject("id=fior_up93 : " + errorinfo);
											} else {
												ctx.setVar('postJobTypeId', response);
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												var responseReasonPhrase = response.reasonPhrase;
												if (responseStatusCode == 200) {
													response.readAsJSON(function(error, responseData) {
														if (error) {
															var errorinfo = "error reading response 'lookupcallwithJobTypeId', details are : " + info + "; error info :" + error
															ctx.setVar('postJobTypeId', error);
															logger.error("id=fior_up94 : " + errorinfo);
															session.reject("id=fior_up94 : " + errorinfo);
														} else {
															ctx.setVar('postJobTypeId', responseData);
															ilsCtx.setVariable('ExitStatus', '0');
															console.info("ResponseData lookupcall" + responseData);
															var wfId = responseData.lookupRep.type[0].id;
															logger.debug("work flow id  is " + wfId);
															omsfoa_UPdate_jobType.setVariable("wfId", wfId);
															var jobOutageLabel = responseData.lookupRep.type[1].label;
															var isOutage = 'false';
															if (jobOutageLabel === 'UNPLANNED_OUTAGE') {
																isOutage = 'true';
															} else {
																isOutage = 'false';
															}
															omsfoa_UPdate_jobType.setVariable("isOutage", isOutage);
														}
													});
												} else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "Error returned from lookupcallwithJobTypeId, details are : " + info + "; error info :" + error
															logger.error("id=fior_up94 : " + errorinfo);
															session.reject("id=fior_up94 : " + errorinfo);
														}
														else {
															var errorinfo = "error response 'lookupcallwithJobTypeId', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
															logger.error("id=fior_up94 : " + errorinfo);
															session.reject("id=fior_up94 : " + errorinfo);
														}
													});
												}
											}
										});
									} catch (err) {
										var errorinfo = "url connection error 'lookupcallwithJobTypeId', details are : " + info + "; error info :" + err
										ctx.setVar('postJobTypeId', errorinfo);
										logger.error("id=fior_up93 : " + errorinfo);
										session.reject("id=fior_up93 : " + errorinfo);
									}

									/* End of lookup call based on jobTypeID */

								}
							});
						} else if (responseStatusCode == 400 || responseStatusCode == 404) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Error returned from getjobapiIsCGI, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								else {
									var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
									if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
										var errorinfo = "Error returned from getjobapiIsCGI, details are:" + info + "; response info :" + responseData
										logger.error(errorinfo);
										session.output.write(incomingdata);
									}else {
										var errorinfo = "Error returned from getjobapiIsCGI, details are:" + info + "; response info : " + responseData
										ilsCtx.setVariable('ExitStatus', responseStatusCode);
										ilsCtx.setVariable('ExitDescription', errorinfo);
										var ctx = session.name('omsfoa') || session.createContext('omsfoa');
										ctx.setVariable('AvoidBackOut', 'yes');
									}
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Error returned from getjobapiIsCGI, details are : " + info + "; error info :" + error
									logger.error("id=fior_up94 : " + errorinfo);
									session.reject("id=fior_up94 : " + errorinfo);
								}
								else {
									var errorinfo = "Error returned from getjobapiIsCGI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up94 : " + errorinfo);
									session.reject("id=fior_up94 : " + errorinfo);
								}
							});
						}
					}
				});
			} catch (err) {
				var errorinfo = "url connection error getjobapiIsCGI, details are : " + info + "; error info :" + err
				ctx.setVar('getJobId', errorinfo);
				logger.error("id=fior_up91 : " + errorinfo);
				session.reject("id=fior_up91 : " + errorinfo);
			}

		}
	}
	}
});
