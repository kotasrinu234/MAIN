var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(async function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up58|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {		
			if (incomingdata.EFO_Completion_OMSCompletion.Task.Attachments != undefined) {
				var attachments = incomingdata.EFO_Completion_OMSCompletion.Task.Attachments;
				var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
				var ExternalRefIDArray = ExternalRefID.split('_');
				var Jobid = ExternalRefIDArray[2];
				var downloadTypeValue = session.parameters.EFONEW;
				var downloadType;
				var userId;
				
				if (downloadTypeValue == 'Y') {
					downloadType = 4;
					userId = session.parameters.DowntypeuserId;
				} else {
					downloadType = 1;
					userId = session.parameters.userId;
				}
				
				// Process attachments sequentially
				for (var i = 0; i < attachments.length; i++) {
					if ((attachments[i].ExternalURL_SO != '') && (attachments[i].ExternalURL_SO != null)) {
						var AttachmentUrl = session.parameters.AttachmentUrl;
						var Attachmentpayload = {};
						Attachmentpayload.downloadType = downloadType;
						Attachmentpayload.id = Jobid;
						Attachmentpayload.url = attachments[i].ExternalURL_SO;
						Attachmentpayload.userId = userId;
						
						if (downloadTypeValue == 'Y') {
							Attachmentpayload.fileName = attachments[i].FileName;
							Attachmentpayload.checkForDup = true;
							Attachmentpayload.asyncReplyFlag = true;
						} else {
							Attachmentpayload.fileName = 'FSM_' + attachments[i].FileName;
							Attachmentpayload.checkForDup = true;
							Attachmentpayload.asyncReplyFlag = true;
						}	
						
						try {
							// Wait for each upload to complete before proceeding
							await ImageUpload(AttachmentUrl, Attachmentpayload);
						} catch (error) {
							logger.error("id=fior_up60|Upload failed for attachment " + i + ": " + error);
							session.reject(error);
							return;
						}
					}
				}
				
				// All uploads completed successfully
				hm.response.statusCode = '200 OK';
				session.output.write(JSON.stringify({ status: 'success' }));
			}
		}
	}
});

// Wrap urlopen.open in a Promise
function ImageUpload(AttachmentUrl, Attachmentpayload) {
	return new Promise((resolve, reject) => {
		var AttachmentApi = {
			target: AttachmentUrl,
			sslClientProfile: 'omsfoa_Update_IIB_ClientProfile',
			method: 'POST',
			contentType: 'application/json',
			data: Attachmentpayload
		};

		var info = " TargetURL :" + AttachmentApi.target + "; Method :" + AttachmentApi.method + "; Data :" + JSON.stringify(AttachmentApi.data) + ". ";
		
		try {
			urlopen.open(AttachmentApi, function(error, response) {
				if (error) {
					var errorinfo = "url connection error 'AttachmentApi', details are : " + info + "; error info :" + error;
					ctx.setVariable('ImageUpload', 'ImageUpload');
					logger.error("id=fior_up59 : " + errorinfo);
					resolve({  });
				//	reject(new Error(errorinfo));
				} else {
					var responseStatusCode = response.statusCode;
					var responseReasonPhrase = response.reasonPhrase;
					
					if (responseStatusCode == 200) {
						logger.debug("id=fior_up61|response received from AttachmentApi call:");
						resolve({ statusCode: 200 });
					} else {
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								var errorinfo = "error reading response 'AttachmentApi', details are : " + info + "; error info :" + readError;
								ctx.setVariable('ImageUpload', 'ImageUpload');
								logger.error("id=fior_up61 : " + responseStatusCode + " " + errorinfo);
								resolve({  });
								//reject(new Error(errorinfo));
							} else {
								var errorinfo = "error response 'AttachmentApi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
								ctx.setVariable('ImageUpload', 'ImageUpload');
								logger.error("id=fior_up61A : " + errorinfo);
								resolve({  });
								//reject(new Error(errorinfo));
							}
						});
					}
				}
			});
		} catch (err) {
			var errorinfo = "url connection error 'AttachmentApi', details are : " + info + "; error info :" + err;
			ctx.setVariable('ImageUpload', 'ImageUpload');
			logger.error("id=fior_up59 : " + errorinfo);
			resolve({  });
		//reject(new Error(errorinfo));
		}
	});
}
