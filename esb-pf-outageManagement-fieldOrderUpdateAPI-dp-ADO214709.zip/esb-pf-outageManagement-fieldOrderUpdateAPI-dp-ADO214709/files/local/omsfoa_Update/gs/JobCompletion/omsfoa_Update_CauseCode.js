var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var CauseCodeName = '';
var CauseCodeLabel = '';
var SubtypeName = '';
var PSOMSCompletion = '';
var IsCGI = '';

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("id=fior_up75|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
		ctx.setVariable("ExternalRefID", ExternalRefID);
		var Allids = ExternalRefID.split('_');
		var Jobid = Allids[2];
		var PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
		if (PSOMSCompletion.IsCGI !== undefined && PSOMSCompletion.IsCGI === true) {
			//CauseCodeName = 'NO WORK DONE';
			CauseCodeName = ctx.getVariable("CauseCodeName");

			IsCGI = PSOMSCompletion.IsCGI

			//causeCodeLookupReq


		}
		else if (PSOMSCompletion !== undefined && PSOMSCompletion.CauseCode !== undefined && PSOMSCompletion.CauseCode.Name !== undefined && PSOMSCompletion.IsCGI !== true || PSOMSCompletion !== undefined && PSOMSCompletion.CauseCode !== undefined && PSOMSCompletion.CauseCode.Name !== undefined && PSOMSCompletion.IsCGI == undefined) {
			CauseCodeName = (PSOMSCompletion.CauseCode.Name).trim();
		}

		if (PSOMSCompletion != undefined && PSOMSCompletion.Subtype != undefined && PSOMSCompletion.Subtype.Name != undefined) {
			SubtypeName = PSOMSCompletion.Subtype.Name;
		}
		var Joburi = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + Jobid;
		var TokenValue = session.parameters.TokenValue;

		var customFields = {
			"customFieldValues": {
				"cause": CauseCodeName
			}
		}

		var JobapiwithcustomFieldValues = {
			target: Joburi,
			sslClientProfile: 'mosfoa_ClientProfile',
			method: 'PATCH',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},
			data: customFields
		};

		if (PSOMSCompletion != undefined && PSOMSCompletion.CauseCode != undefined && PSOMSCompletion.CauseCode.Name != undefined && PSOMSCompletion.CauseCode.Name != null && PSOMSCompletion.CauseCode.Name != '' || IsCGI === true) {
			var info = " TargetURL :" + JobapiwithcustomFieldValues.target + "; Method :" + JobapiwithcustomFieldValues.method + "; Data :" + JSON.stringify(JobapiwithcustomFieldValues.data) + ". ";
			try {
				urlopen.open(JobapiwithcustomFieldValues, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'JobapiwithcustomFieldValues', details are : " + info + "; error info :" + error
						ctx.setVariable('patchJobid', errorinfo);
						logger.error("id=fior_up79 : " + errorinfo);
						session.reject("id=fior_up79 : " + errorinfo);
					} else {
						ctx.setVariable('patchJobid', response);
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'JobapiwithcustomFieldValues', details are : " + info + "; error info :" + error
								ctx.setVar('patchJobid', errorinfo);
								logger.error("id=fior_up80 : " + errorinfo);
								session.reject("id=fior_up80 : " + errorinfo);
							} else {
								if (responseStatusCode == 200) {
									var responseinfo = "error reading response 'JobapiwithcustomFieldValues', details are : " + info + "; error info :" + error
									ctx.setVar('patchJobid', responseinfo);
									hm.response.statusCode = responseStatusCode;
									ilsCtx.setVariable('ExitStatus', '0');
									logger.debug("id=fior_up80 : " + responseinfo);
									session.output.write(responseData);
								} else if (responseStatusCode == 400 || responseStatusCode == 404) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error response 'JobapiwithcustomField', details are : " + info + "; error info :" + error
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
										else {
													var BusinessResponseData = responseData;
													var buff = Buffer.from(BusinessResponseData);
													var ResponseString = buff.toString();

											if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION") ) {
												var errorinfo = "error response 'JobapiwithcustomField', details are:" + info + "; response info :" + responseData
												logger.error(errorinfo);
												session.output.write(incomingdata);
											}else{
															var errorinfo = "error response 'JobapiwithcustomField', details are:" + info + "; response info :" + responseData
															ilsCtx.setVariable('ExitStatus', responseStatusCode);
															ilsCtx.setVariable('ExitDescription', errorinfo);
															var ctx = session.name('omsfoa') || session.createContext('omsfoa');
															ctx.setVariable('AvoidBackOut', 'yes');
															//throw Error("id=fior_up39 : " + errorinfo);
														}
										}
									});
								} else if (responseStatusCode == 401 || responseStatusCode == 403) {
									// Handle business error responses (HTTP 401 or 403)
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											// Handle error in reading response data
											var errorinfo = "id=fior_up011: error response 'JobapiwithcustomField' , details are : " + info + "; error info :" + error;
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "id=fior_up011:" + responseData + " error response 'JobapiwithcustomField' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});
								} else {
									var errorinfo = "error response 'JobapiwithcustomField', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up82 : " + errorinfo);
									session.reject("id=fior_up82 : " + errorinfo);
								}
							}
						});
					}
				});
			} catch (err) {
				var errorinfo = "url connection error 'JobapiwithcustomFieldValues', details are : " + info + "; error info :" + err
				ctx.setVariable('patchJobid', errorinfo);
				logger.error("id=fior_up79 : " + errorinfo);
				session.reject("id=fior_up79 : " + errorinfo);
			}
		}
		//subType API starts

		if (incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion != undefined && incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion.Subtype != undefined && incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion.Subtype.Name != undefined && incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion.Subtype.Name != null && incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion.Subtype.Name != '') {

			var typeobj = {
				name: "outageSubtypes",
				label: SubtypeName
			}
			var typeArr = new Array();
			typeArr.push(typeobj);
			var lookupReqobj = {
				type: typeArr
			}
			var lookupReq = {
				lookupReq: lookupReqobj
			}
			var lookupuri = session.parameters.lookupurl;

			var lookupcallwithSubTypeId = {
				target: lookupuri,
				method: 'POST',
				contentType: 'application/json',
				data: lookupReq
			};

			var info = " TargetURL :" + lookupcallwithSubTypeId.target + "; Method :" + lookupcallwithSubTypeId.method + "; Data :" + JSON.stringify(lookupcallwithSubTypeId.data) + ". ";
			try {
				urlopen.open(lookupcallwithSubTypeId, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'lookupcallwithSubTypeId', details are : " + info + "; error info :" + error
						ctx.setVar('subTypeIDlookup_Error', errorinfo)
						logger.error("id=fior_up96 : " + errorinfo);
						session.reject("id=fior_up96 : " + errorinfo);
					} else {
						ctx.setVar('subTypeIDlookup_Resp', response)
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responseReasonPhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'lookupcallwithSubTypeId', details are : " + info + "; error info :" + error
									ctx.setVar('subTypeID_RespError', errorinfo);
									logger.error("id=fior_up297 : " + errorinfo);
									session.reject("id=fior_up297 : " + errorinfo);
								} else {
									ctx.setVar('subTypeID_RespData', responseData);
									var outageSubtypeID = responseData.lookupRep.type[0].id;
									logger.debug("id is " + outageSubtypeID);
									ctx.setVariable("outageSubtypeID", outageSubtypeID);

									var subTypeuri = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + Jobid;

									var outageSubTypereq = {
										"outageSubtypeID": outageSubtypeID
									}

									var subTypeapi = {
										target: subTypeuri,
										sslClientProfile: 'mosfoa_ClientProfile',
										method: 'PATCH',
										contentType: 'application/json',
										headers: {
											'osiApiToken': TokenValue
										},
										data: outageSubTypereq
									};
									var info = " TargetURL :" + subTypeapi.target + "; Method :" + subTypeapi.method + "; Data :" + JSON.stringify(subTypeapi.data) + ". ";
									try {
										urlopen.open(subTypeapi, function(error, response) {
											if (error) {
												var errorinfo = "url connection error with 'subTypeapi call to oms', details are : " + info + "; error info :" + error
												ctx.setVar('patchoutageSubTypeError', errorinfo);
												logger.error("id=fior_up98 : " + errorinfo);
												session.reject("id=fior_up98 : " + errorinfo);
											} else {
												ctx.setVar('patchoutageSubTypeResp', response);
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												var responseReasonPhrase = response.reasonPhrase;
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'subTypeapi', details are : " + info + "; error info :" + error
														ctx.setVar('patchoutageSubTypeError', errorinfo);
														logger.error("id=fior_up199 : " + errorinfo);
														session.reject("id=fior_up199 : " + errorinfo);
													} else {
														if (responseStatusCode == 200) {
															var responseinfo = "response received from subTypeapi call : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
															ctx.setVar('patchoutageSubTypeResp', responseinfo);
															hm.response.statusCode = responseStatusCode;
															ilsCtx.setVariable('ExitStatus', '0');
															logger.debug("id=fior_up80 : " + responseinfo);
															session.output.write(responseData);
														} else if (responseStatusCode == 400 || responseStatusCode == 404 ) {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "Error returned from subTypeapi call to oms, details are : " + info + "; error info :" + error
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
																else {
																	var BusinessResponseData = responseData;
													var buff = Buffer.from(BusinessResponseData);
													var ResponseString = buff.toString();
													if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																		var errorinfo = "Error returned from subTypeapi call to oms, details are:" + info + "; response info :" + responseData
																		logger.error(errorinfo);
																		session.output.write(incomingdata);
																	}else{
															var errorinfo = "Error returned from subTypeapi call to oms, details are:" + info + "; response info :" + responseData
															ilsCtx.setVariable('ExitStatus', responseStatusCode);
															ilsCtx.setVariable('ExitDescription', errorinfo);
															var ctx = session.name('omsfoa') || session.createContext('omsfoa');
															ctx.setVariable('AvoidBackOut', 'yes');
															//throw Error("id=fior_up39 : " + errorinfo);
														}
																}
															});
														} else if (responseStatusCode == 401 || responseStatusCode == 403) {
															// Handle business error responses (HTTP 401 or 403)
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	// Handle error in reading response data
																	var errorinfo = "id=fior_up012: Error returned from subTypeapi call to oms , details are : " + info + "; error info :" + error;
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "id=fior_up012:" + responseData + " Error returned from subTypeapi call to oms , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
															});
														} else {
															var errorinfo = "Error returned from subTypeapi call to oms, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
															logger.error("id=fior_up200 : " + errorinfo);
															session.reject("id=fior_up200 : " + errorinfo);
														}
													}
												});
											}
										});
									} catch (err) {
										var errorinfo = "url connection error subTypeapi call to oms, details are : " + info + "; error info :" + err
										ctx.setVar('patchoutageSubTypeError', errorinfo);
										logger.error("id=fior_up98 : " + errorinfo);
										session.reject("id=fior_up98 : " + errorinfo);
									}
								}
							})
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response  from 'lookupcallwithSubTypeId', details are : " + info + "; error info :" + error
									logger.error("id=fior_up97 : " + errorinfo);
									session.reject("id=fior_up97 : " + errorinfo);
								} else {
									var errorinfo = "error response from 'lookupcallwithSubTypeId', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error("id=fior_up97 : " + errorinfo);
									session.reject("id=fior_up97 : " + errorinfo);
								}
							});
						}
					} //end of else
				}); //end of urlopen

			} catch (err) {
				var errorinfo = "url connection error 'lookupcallwithSubTypeId', details are : " + info + "; error info :" + err
				ctx.setVar('subTypeIDlookup_Error', errorinfo)
				logger.error("id=fior_up96 : " + errorinfo);
				session.reject("id=fior_up96 : " + errorinfo);
			}
		}
		//subtypeAPI ends
	}
});
