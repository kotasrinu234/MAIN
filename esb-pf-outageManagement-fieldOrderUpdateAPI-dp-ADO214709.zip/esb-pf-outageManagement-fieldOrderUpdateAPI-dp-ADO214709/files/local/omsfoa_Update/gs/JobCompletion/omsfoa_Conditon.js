var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var PSOMSCompletion = '';
var ilsCtx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name('omsfoa') || session.createContext('omsfoa');
	var avoidcall = ctx.getVariable("AvoidBackOut");

	if (avoidcall != 'yes') {
		PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;

		var g = ExternalRefID.split('_');
		var AssigmentId = g[1];
		if (AssigmentId !== undefined) {
			if (readAsJSONError) {
				logger.error("id=fior_up63|Error in reading incoming data");
				session.reject(readAsJSONError);
			} else {
				//condtionFound process start
				var ConditionsFoundArray = [];
				for (var key in PSOMSCompletion) {
					if (key.match(/CondFndCd/)) {
						ConditionsFoundArray.push(PSOMSCompletion[key].Name)
					}
				}

				var ConditionFoundmsg = "";
				var i;
				for (i = 0; i < ConditionsFoundArray.length; i++) {
					if ((!(ConditionsFoundArray[i] === undefined || ConditionsFoundArray[i] === null || ConditionsFoundArray[i] === "")) && (i == 0)) {
						ConditionFoundmsg += ConditionsFoundArray[i];
					}
					else if ((!(i == ConditionsFoundArray.length - 1)) && (!(ConditionsFoundArray[i] === undefined || ConditionsFoundArray[i] === null || ConditionsFoundArray[i] === ""))) {
						if (ConditionFoundmsg === "") {
							ConditionFoundmsg += ConditionsFoundArray[i];
						}
						else {
							ConditionFoundmsg += '\n' + ConditionsFoundArray[i];
						}
					}
					else if ((i == ConditionsFoundArray.length - 1) && (!(ConditionsFoundArray[i] === undefined || ConditionsFoundArray[i] === null || ConditionsFoundArray[i] === ""))) {
						ConditionFoundmsg += '\n' + ConditionsFoundArray[i];
					}

				}

				//condition left start
				var ConditionsLeftArray = [];

				for (var key in PSOMSCompletion) {
					if (key.match(/CondLftCd/)) {
						ConditionsLeftArray.push(PSOMSCompletion[key].Name)
					}
				}

				var Conditionleftmsg = "";
				var i;
				for (i = 0; i < ConditionsLeftArray.length; i++) {
					if ((!(ConditionsLeftArray[i] === undefined || ConditionsLeftArray[i] === null || ConditionsLeftArray[i] === "")) && (i == 0)) {
						Conditionleftmsg += ConditionsLeftArray[i];
					}
					else if ((!(i == ConditionsLeftArray.length - 1)) && (!(ConditionsLeftArray[i] === undefined || ConditionsLeftArray[i] === null || ConditionsLeftArray[i] === ""))) {
						if (Conditionleftmsg === "") {
							Conditionleftmsg += ConditionsLeftArray[i];
						}
						else {
							Conditionleftmsg += '\n' + ConditionsLeftArray[i];
						}
					}
					else if ((i == ConditionsLeftArray.length - 1) && (!(ConditionsLeftArray[i] === undefined || ConditionsLeftArray[i] === null || ConditionsLeftArray[i] === ""))) {
						Conditionleftmsg += '\n' + ConditionsLeftArray[i];
					}

				}

				var customFieldValues = {
					"ConditionsLeft": Conditionleftmsg,
					"ConditionsFound": ConditionFoundmsg
				}
				var payload = {
					"customFieldValues": customFieldValues
				}
				session.output.write(payload);

				var TokenValue = session.parameters.TokenValue;
				var CrewAssignmentId = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + AssigmentId;
				logger.info("payload+++" + payload);

				var CrewAssignmentapi = {
					target: CrewAssignmentId,
					sslClientProfile: 'mosfoa_ClientProfile',
					method: 'PATCH',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: payload
				};
				var info = " TargetURL :" + CrewAssignmentapi.target + "; Method :" + CrewAssignmentapi.method + "; Data :" + JSON.stringify(CrewAssignmentapi.data) + ". ";
				try {
					urlopen.open(CrewAssignmentapi, function(error, response) {
						if (error) {
							var errorinfo = "url connection error 'CrewAssignmentapi', details are : " + info + "; error info :" + error
							logger.error("id=fior_up64 : " + errorinfo);
							var ctx = session.name('myContext') || session.createContext('myContext');
							ctx.setVar("urlopen connect error with CrewAssignmentapi" + JSON.stringify(errorinfo));
							session.reject("id=fior_up64 : " + errorinfo);
							//throw errorinfo;
						} else {
							// read response data
							// get the response status code
							var responseStatusCode = response.statusCode;
							var responseReasonPhrase = response.reasonPhrase;
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'CrewAssignmentapi', details are : " + info + "; error info :" + error
									ctx.setVar('patchCrewAssignmentCOnditionError', errorinfo);
									logger.error("id=fior_up65 : " + errorinfo);
									session.reject("id=fior_up65 : " + errorinfo);
								} else {
									if (responseStatusCode == 200) {
										hm.response.statusCode = responseStatusCode;
										ilsCtx.setVariable('ExitStatus', '0');
										var responseinfo = "response received from CrewAssignmentapi for CrewAssignmentId:" + CrewAssignmentId + " " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										logger.debug("id=fior_up66 : " + responseinfo);
										session.output.write(responseData);
									} else if (responseStatusCode == 400 || responseStatusCode == 404) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error response 'CrewAssignmentapi', details are : " + info + "; error info :" + error
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
											else {
												var BusinessResponseData = responseData;
												var buff = Buffer.from(BusinessResponseData);
												var ResponseString = buff.toString();
												if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
													var errorinfo = "error response 'CrewAssignmentapi', details are:" + info + "; response info :" + responseData
													logger.error(errorinfo);
													session.output.write(incomingdata);
												} else {
													var errorinfo = "error response 'CrewAssignmentapi', details are:" + info + "; response info :" + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}
											}
										});
									} else if (responseStatusCode == 401 || responseStatusCode == 403) {
										// Handle business error responses (HTTP 401 or 403)
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												// Handle error in reading response data
												var errorinfo = "id=fior_up007:  error response 'CrewAssignmentapi' , details are : " + info + "; error info :" + error;
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "id=fior_up007:" + responseData + " error response 'CrewAssignmentapi' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});
									} else {
										var errorinfo = "error response 'CrewAssignmentapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
								}
							});
						}
					});
				} catch (err) {
					var errorinfo = "url connection error 'CrewAssignmentapi', details are : " + info + "; error info :" + err
					logger.error("id=fior_up64 : " + errorinfo);
					var ctx = session.name('myContext') || session.createContext('myContext');
					ctx.setVar("urlopen connect error with CrewAssignmentapi", errorinfo);
					session.reject("id=fior_up64 : " + errorinfo);
				}
			}
		} else {
			logger.error("id=fior_up67|ExternalRefID doesn't have CrewAssignmentId in incoming message");
		}

	}
}); 
