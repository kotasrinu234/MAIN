var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var callMQURL = require('./callMQURL.js');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var outageServiceName = session.parameters.outageServiceName;
var outageUserId = session.parameters.outageUserId;
var outageQueue = session.parameters.outageQueue;
var outageQM = session.parameters.outageQM;
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var wfId = omsfoa_UPdate_jobType.getVariable("wfId");
var isOutage = omsfoa_UPdate_jobType.getVariable("isOutage");
var closeJob = omsfoa_UPdate_jobType.getVariable("closeJob");
var TokenValue = session.parameters.TokenValue;
//Step4:- Lookup for WFID_Status

var Engineers = "";
var crewID = "";
var empID = "";
var empName = "";
var PSOMSCompletion = "";
var taskRemarks = "";
var CauseCodeName = "";
var IsCGI = "";


// if (closeJob === true) {

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var avoidcall = ctx.getVariable("AvoidBackOut");
	if (avoidcall != 'yes') {
		var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
		var ExternalRefIDArray = ExternalRefID.split('_');
		var Jobid = ExternalRefIDArray[2];

		PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;


		PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
		if (PSOMSCompletion.IsCGI !== undefined && PSOMSCompletion.IsCGI === true) {
			CauseCodeName = session.parameters.causeCodeLabel;
			IsCGI = PSOMSCompletion.IsCGI
		}
		else if (PSOMSCompletion !== undefined && PSOMSCompletion.CauseCode !== undefined && PSOMSCompletion.CauseCode.Name !== undefined) {
			CauseCodeName = PSOMSCompletion.CauseCode.Name;
		}

		if (closeJob === true || IsCGI === true) {
			if (isOutage == 'false') {
				if (readAsJSONError) {
					logger.error("id=fior_up89|Error in reading incoming data");
					session.reject(readAsJSONError);
				} else {
					var typeobj = {
						name: "jobTypes.workflows",
						id: wfId,
						label: "Completed"
					}
					//var type = [
					var typeArr = new Array();
					typeArr.push(typeobj);
					/*  typeobj
				 ] */
					var lookupReqobj = {
						type: typeArr
					}
					//constructing the payload for lookup call
					var lookupReq = {
						lookupReq: lookupReqobj
					}
					var lookupuri = session.parameters.lookupurl;
					var lookupcallwithJobTypeId = {
						target: lookupuri,
						method: 'POST',
						contentType: 'application/json',
						data: lookupReq
					};

					var info = " TargetURL :" + lookupcallwithJobTypeId.target + "; Method :" + lookupcallwithJobTypeId.method + "; Data :" + JSON.stringify(lookupcallwithJobTypeId.data) + ". ";
					try {
						urlopen.open(lookupcallwithJobTypeId, function(error, response) {
							if (error) {
								var errorinfo = "url connection error 'lookupcallwithJobTypeId', details are : " + info + "; error info :" + error
								ctx.setVar('WFID_Status_Error', errorinfo)
								logger.error("id=fior_up96 : " + errorinfo);
								session.reject("id=fior_up96 : " + errorinfo);
							} else {
								ctx.setVar('WFID_Status_Resp', response)
								// read response data
								// get the response status code
								var responseStatusCode = response.statusCode;
								var responseReasonPhrase = response.reasonPhrase;
								if (responseStatusCode == 200) {
									response.readAsJSON(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'lookupcallwithJobTypeId', details are : " + info + "; error info :" + error
											ctx.setVar('WFID_Status_RespError', errorinfo);
											logger.error("id=fior_up97 : " + errorinfo);
											session.reject("id=fior_up97 : " + errorinfo);
										} else {
											ctx.setVar('WFID_Status_RespData', responseData);
											ilsCtx.setVariable('ExitStatus', '0');
											var status = responseData.lookupRep.type[0].status;
											logger.debug("status is " + status);
											omsfoa_UPdate_jobType.setVariable("status", status);
											//var Jobid = "5e593e8debeb0f6aa93da037";
											var omsuri = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + Jobid + '/WorkFlow';
											/* Start of 4. Call POST /api/ServiceType/Electric/Job/{id}/WorkFlow and set the status*/

											var setworkstatusapi = {
												target: omsuri,
												sslClientProfile: 'mosfoa_ClientProfile',
												method: 'POST',
												contentType: 'text',
												headers: {
													'osiApiToken': TokenValue
												},
												data: status
											};

											var info = " TargetURL :" + setworkstatusapi.target + "; Method :" + setworkstatusapi.method + "; Data :" + JSON.stringify(setworkstatusapi.data) + ". ";
											try {
												urlopen.open(setworkstatusapi, function(error, response) {
													if (error) {
														var errorinfo = "url connection error with setworkstatusapi call to oms, details are : " + info + "; error info :" + error
														ctx.setVar('WFID_Status_workflow', errorinfo);
														logger.error("id=fior_up98 : " + errorinfo);
														session.reject("id=fior_up98 : " + errorinfo);
													} else {
														ctx.setVar('WFID_Status_workflow', response);
														// read response data
														// get the response status code
														var responseStatusCode = response.statusCode;
														var responseReasonPhrase = response.reasonPhrase;
														if (responseStatusCode == 200) {
															response.readAsJSON(function(error, responseData) {
																if (error) {
																	var errorinfo = "error reading response with setworkstatusapi call to oms, details are : " + info + "; error info :" + error
																	ctx.setVar('WFID_Status_workflow', errorinfo);
																	logger.error("id=fior_up99 : " + errorinfo);
																	session.reject("id=fior_up99 : " + errorinfo);
																} else {
																	ctx.setVar('WFID_Status_workflow', responseData);
																	hm.response.statusCode = '200 Message is received';
																	ilsCtx.setVariable('ExitStatus', '0');
																	logger.debug("response received from setworkstatusapi call to oms:" + responseData);
																}
															});
														} else if (responseStatusCode == 400 || responseStatusCode == 404) {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "Error returned from setworkstatusapi call to oms, details are : " + info + "; error info :" + error
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
																else {
																	var BusinessResponseData = responseData;
																	var buff = Buffer.from(BusinessResponseData);
																	var ResponseString = buff.toString();
																	if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																		var errorinfo = "Error returned from setworkstatusapi call to oms, details are:" + info + "; response info :" + responseData
																		ilsCtx.setVariable('ExitStatus', responseStatusCode);
																		ilsCtx.setVariable('ExitDescription', errorinfo);

																		logger.error(errorinfo);
																		session.output.write(incomingdata);
																	} else {

																		var ctx = session.name('omsfoa') || session.createContext('omsfoa');
																		ctx.setVariable('AvoidBackOut', 'yes');
																		ilsCtx.setVariable('ExitStatus', responseStatusCode);
																		var errorinfo = "Error returned from setworkstatusapi call to oms, details are:" + info + "; response info :" + responseData
																		ilsCtx.setVariable('ExitDescription', errorinfo);


																	}
																}
															});
														} else if (responseStatusCode == 401 || responseStatusCode == 403) {
															// Handle business error responses (HTTP 401 or 403)
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	// Handle error in reading response data
																	var errorinfo = "id=fior_up015: Error returned from setworkstatusapi call to oms , details are : " + info + "; error info :" + error;
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "id=fior_up015:" + responseData + " Error returned from setworkstatusapi call to oms , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
															});
														} else {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "Error returned from setworkstatusapi call to oms, details are : " + info + "; error info :" + error
																	logger.error("id=fior_up100 : " + errorinfo);
																	session.reject("id=fior_up100 : " + errorinfo);
																} else {
																	var errorinfo = "Error returned from setworkstatusapi call to oms, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	logger.error("id=fior_up100 : " + errorinfo);
																	session.reject("id=fior_up100 : " + errorinfo);
																}
															});
														}
													}
												});
											} catch (err) {
												var errorinfo = "url connection error with setworkstatusapi call to oms, details are : " + info + "; error info :" + err
												ctx.setVar('WFID_Status_workflow', errorinfo);
												logger.error("id=fior_up98 : " + errorinfo);
												session.reject("id=fior_up98 : " + errorinfo);
											}
										}
									});
								} else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'lookupcallwithJobTypeId', details are : " + info + "; error info :" + error
											logger.error("id=fior_up97 : " + errorinfo);
											session.reject("id=fior_up97 : " + errorinfo);
										} else {
											var errorinfo = "Error returned from lookupcallwithJobTypeId, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											logger.error("id=fior_up97 : " + errorinfo);
											session.reject("id=fior_up97 : " + errorinfo);
										}
									});
								}
							} //end of else
						});
					} catch (err) {
						var errorinfo = "url connection error with lookupcallwithJobTypeId, details are : " + info + "; error info :" + err
						ctx.setVar('WFID_Status_Error', errorinfo)
						logger.error("id=fior_up96 : " + errorinfo);
						session.reject("id=fior_up96 : " + errorinfo);
					} //end of urlopen
				}
			} else {
				/* var leadCallId = omsfoa_UPdate_jobType.getVariable("leadCallId");
				var postCalluri = session.parameters.OMS + '/api/v1/ServiceType/Electric/Call/' + leadCallId + '/Status';
	
				var postcallapi = {
					target: postCalluri,
					sslClientProfile: 'mosfoa_ClientProfile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: 2
				};
	
				var info = " TargetURL :" + postcallapi.target + "; Method :" + postcallapi.method + "; Data :" + JSON.stringify(postcallapi.data) + ". ";
				try {
					urlopen.open(postcallapi, function(error, response) {
						if (error) {
							var errorinfo = "url connection error 'postcallapi', details are : " + info + "; error info :" + error
							ctx.setVar('postCallId_StatusError', errorinfo);
							logger.error("id=fior_up111 : " + errorinfo);
						} else {
							ctx.setVar('postCallId_StatusResponse', response);
							// read response data
							// get the response status code
							var responseStatusCode = response.statusCode;
							var responseReasonPhrase = response.reasonPhrase;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'postcallapi', details are : " + info + "; error info :" + error
										ctx.setVar('postCallId_StatusError', errorinfo);
										logger.error("id=fior_up112 : " + errorinfo);
										session.reject("id=fior_up112 : " + errorinfo);
									} else {
										ctx.setVar('postCallId_StatusResponseJson', responseData);
									}
								})
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'postcallapi', details are : " + info + "; error info :" + error
										logger.error("id=fior_up112 : " + errorinfo);
										session.reject("id=fior_up112 : " + errorinfo);
										//throw Error("id=fior_up112 : " + errorinfo);
									} else {
										var errorinfo = "error response 'postcallapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										logger.error("id=fior_up112 : " + errorinfo);
										session.reject("id=fior_up112 : " + errorinfo);
										//throw Error("id=fior_up112 : " + errorinfo);
									}
								});
							}
						}
	
					});
				} catch (err) {
					var errorinfo = "url connection error with postcallapi, details are : " + info + "; error info :" + err
					ctx.setVar('postCallId_StatusError', errorinfo);
					logger.error("id=fior_up111 : " + errorinfo);
					session.reject("id=fior_up111 : " + errorinfo);
				}  */

				//new change 105246

				var now = new Date();
				var year = now.getFullYear();
				var month = now.getMonth() + 1;
				var month1 = month.toString();
				var strmonthlength = month1.length;
				var todaymonth;
				if (strmonthlength == 1) {
					todaymonth = '0' + month;
				} else {
					todaymonth = month;
				}

				var day = now.getDate();
				var day1 = day.toString();
				var strdaylength = day1.length;
				var todaydate;
				if (strdaylength == 1) {
					todaydate = '0' + day;
				} else {
					todaydate = day;
				}

				var hour = now.getHours();
				var todayhour = hour.toString();
				var strhourlength = todayhour.length;
				var todayhour;
				if (strhourlength == 1) {
					todayhour = '0' + hour;
				} else {
					todayhour = hour;
				}

				var minute = now.getMinutes();
				var todayminute = minute.toString();
				var strminutelength = todayminute.length;
				var todayminute;
				if (strminutelength == 1) {
					todayminute = '0' + minute;
				} else {
					todayminute = minute;
				}

				var second = now.getSeconds();
				var todaysecond = second.toString();
				var strsecondlength = todaysecond.length;
				var todaysecond;
				if (strsecondlength == 1) {
					todaysecond = '0' + todaysecond;
				} else {
					todaysecond = todaysecond;
				}

				var nowdate = year + '-' + todaymonth + '-' + todaydate;
				var nowtime = todayhour + ':' + todayminute + ':' + todaysecond;


				var customComment = 'EFO CLOSED JOB ON ' + nowdate + ' AT ' + nowtime + ' AND UPDATED CAUSE CODE to ' + CauseCodeName;

				var correlid = ilsCtx.getVariable('correlationID');
				var outReq = {};
				outReq.msgId = correlid;
				outReq.serviceName = outageServiceName;
				outReq.jobId = Jobid;
				outReq.timesStamp = now.toISOString();
				outReq.userId = outageUserId;
				outReq.comment = customComment;


				var urlopenurl = 'dpmq://' + outageQM + '/?RequestQueue=' + outageQueue;
				ctx.setVariable("urlopenurl", urlopenurl);
				callMQURL(urlopenurl, 'Outage_MQ', outReq);
				session.output.write(outReq);

				//new change 105246 ends
			}//else end
		}
	}
});
