//Step5:- Posting a comment
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var omsfoa_UPdate_jobType = session.name('omsfoa_UPdate_jobType') || session.createContext('omsfoa_UPdate_jobType');
var CauseCodeLabel = session.parameters.causeCodeLabel;
var isOutage = omsfoa_UPdate_jobType.getVariable("isOutage");
var closeJob = omsfoa_UPdate_jobType.getVariable("closeJob");

var PSOMSCompletion = "";
//if (closeJob == true) {
	var ctx = session.name('omsfoa') || session.createContext('omsfoa');
				var avoidcall = ctx.getVariable("AvoidBackOut");
				
		if(avoidcall != 'yes'){
if (isOutage !== 'true') {

	session.input.readAsJSON(function(readAsJSONError, incomingdata) {

		if (readAsJSONError) {
			logger.error("id=fior_up89|Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {
			var ExternalRefID = incomingdata.EFO_Completion_OMSCompletion.Task.ExternalRefID;
			var ExternalRefIDArray = ExternalRefID.split('_');
			var Jobid = ExternalRefIDArray[2];

			var POSTJobIduri = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + Jobid + '/Comment';

			var now = new Date();
			var year = now.getFullYear();
			var month = now.getMonth() + 1;
			var month1 = month.toString();
			var strmonthlength = month1.length;
			var todaymonth;
			if (strmonthlength == 1) {
				todaymonth = '0' + month;
			} else {
				todaymonth = month;
			}

			var day = now.getDate();
			var day1 = day.toString();
			var strdaylength = day1.length;
			var todaydate;
			if (strdaylength == 1) {
				todaydate = '0' + day;
			} else {
				todaydate = day;
			}

			var hour = now.getHours();
			var todayhour = hour.toString();
			var strhourlength = todayhour.length;
			var todayhour;
			if (strhourlength == 1) {
				todayhour = '0' + hour;
			} else {
				todayhour = hour;
			}

			var minute = now.getMinutes();
			var todayminute = minute.toString();
			var strminutelength = todayminute.length;
			var todayminute;
			if (strminutelength == 1) {
				todayminute = '0' + minute;
			} else {
				todayminute = minute;
			}

			var second = now.getSeconds();
			var todaysecond = second.toString();
			var strsecondlength = todaysecond.length;
			var todaysecond;
			if (strsecondlength == 1) {
				todaysecond = '0' + todaysecond;
			} else {
				todaysecond = todaysecond;
			}

			var nowdate = year + '-' + todaymonth + '-' + todaydate;
			var nowtime = todayhour + ':' + todayminute + ':' + todaysecond;


			var CauseCodeName = "";
			var CrewID = "";
			var EmpID = "";
			var EmpName = "";
			var IsCGI = "";


			PSOMSCompletion = incomingdata.EFO_Completion_OMSCompletion.Task.PSOMSCompletion;
			if (PSOMSCompletion.IsCGI !== undefined && PSOMSCompletion.IsCGI === true) {
				CauseCodeName = CauseCodeLabel;

				//CauseCodeName = 'NO ISSUES FOUND';
				IsCGI = PSOMSCompletion.IsCGI
			}
			else if (PSOMSCompletion !== undefined && PSOMSCompletion.CauseCode !== undefined && PSOMSCompletion.CauseCode.Name !== undefined) {
				CauseCodeName = PSOMSCompletion.CauseCode.Name;
			}

			if (closeJob === true || IsCGI === true) {


				var customComment = 'EFO CLOSED JOB ON ' + nowdate + ' AT ' + nowtime + ' AND UPDATED CAUSE CODE to ' + CauseCodeName;

				var TokenValue = session.parameters.TokenValue;

				var PostJobIdapi = {
					target: POSTJobIduri,
					sslClientProfile: 'mosfoa_ClientProfile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: {
						"comment": customComment
					}
				};
				var info = " TargetURL :" + PostJobIdapi.target + "; Method :" + PostJobIdapi.method + "; Data :" + JSON.stringify(PostJobIdapi.data) + ". ";
				try {
					urlopen.open(PostJobIdapi, function(error, response) {
						if (error) {
							var errorinfo = "url connection error 'PostJobIdapi', details are : " + info + "; error info :" + error
							ctx.setVar('PostJobIdapi_comment', errorinfo);
							logger.error("id=fior_up113 : " + errorinfo);
							ctx.setVar("urlopen connect error with PostJobIdapi", errorinfo);
							session.reject("id=fior_up113 : " + errorinfo);
							//throw errorinfo;
						} else {
							ctx.setVar('PostJobIdapi_comment', response);
							// read response data
							// get the response status code
							var responseStatusCode = response.statusCode;
							var responseReasonPhrase = response.reasonPhrase;
							if (responseStatusCode == 200) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'PostJobIdapi', details are : " + info + "; error info :" + error
										ctx.setVar('PostJobIdapi_comment', errorinfo);
										logger.error("id=fior_up114 : " + errorinfo);
										session.reject("id=fior_up114 : " + errorinfo);
									} else {
										ctx.setVar('PostJobIdapi_comment', responseData);
										hm.response.statusCode = responseStatusCode;
										hm.response.statusCode = responseStatusCode;
										ilsCtx.setVariable('ExitStatus', '0');
										logger.debug("id=fior_up115|response received from PostJobIdapi for Jobid:" + Jobid + " " + responseStatusCode);
										session.output.write(responseData);
									}
								});
							} else if (responseStatusCode == 400 || responseStatusCode == 404) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'PostJobIdapi', details are : " + info + "; error info :" + error
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
									else {
										var parsedResponse = JSON.parse(responseData.toString());
										if ((responseData == 'No updates') || parsedResponse.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
											var errorinfo = "error reading response 'PostJobIdapi', details are:" + info + "; response info :" + responseData
											//ilsCtx.setVariable('ExitStatus', responseStatusCode);
											//ilsCtx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.output.write(incomingdata);
										}
									}
								});
							} else if (responseStatusCode == 401 || responseStatusCode == 403) {
								// Handle business error responses (HTTP 401 or 403)
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										// Handle error in reading response data
										var errorinfo = "id=fior_up009: error reading response 'PostJobIdapi' , details are : " + info + "; error info :" + error;
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var errorinfo = "id=fior_up009: " + responseData + " error reading response 'PostJobIdapi' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
								});
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'PostJobIdapi', details are : " + info + "; error info :" + error
										logger.error("id=fior_up116A : " + errorinfo);
										session.reject("id=fior_up116A : " + errorinfo);
									} else {
										var errorinfo = "error response 'PostJobIdapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										logger.error("id=fior_up116B : " + errorinfo);
										session.reject("id=fior_up116B : " + errorinfo);
									}
								});
							}
						}
					});
				} catch (err) {
					var errorinfo = "url connection error 'PostJobIdapi', details are : " + info + "; error info :" + err
					ctx.setVar('PostJobIdapi_comment', errorinfo);
					logger.error("id=fior_up113 : " + errorinfo);
					ctx.setVar("urlopen connect error with PostJobIdapi", errorinfo)
					session.reject("id=fior_up113 : " + errorinfo);
					//throw errorinfo;
				}


			}
		}
	});
}
}
