var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var getURLResponse1 = require('./geturlopenUtil.js');
var getURLResponse = require('./urlopenUtil.js');

var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});

var noId= ctx.getVariable("noId");

if(noId !=='noId'){
/* var intCrewId= ctx.getVariable('getIntCrewId').id;
ctx.setVariable("intCrewId",intCrewId); */
var crewNF= ctx.getVariable('crewNF');
var PSEngineersID= ctx.getVariable('PSEngineersID');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up15|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ExternalRefID = incomingdata.OMS_TaskUpdate.Task.ExternalRefID;
							var g = ExternalRefID.split('_');
							var crewAssignmentId = g[1];
							var omsjobid = g[2];
		
		
		if(ctx.getVariable("crewNF")){
			var commentsUri = session.parameters.OMS + '/api/ServiceType/Electric/Job/'+omsjobid +'/Comment';
			  var customcomment = 'REASSIGNED failed as CREW '+ PSEngineersID +' does not exits.';

                var jobComments = {
                    comment: customcomment
                };
			
			
			getURLResponse(commentsUri,'POST','failComments',jobComments);
			/* throw Error('REASSIGNED failed as CREW '+ PSEngineersID +' does not exits.'); */
			
		}else {
			var crewAssignmentUri = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' +crewAssignmentId+'?includeFields=crew.id%2Ccrew.externalID&join=true';
			getURLResponse1(crewAssignmentUri,'caGetintCrewIdResp');
		}
		
	}
	});
}