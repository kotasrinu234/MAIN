var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var getURLResponse = require('./urlopenUtil.js');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ctx1 = session.name('nonefo') || session.createContext('nonefo');
var logger = console.options({
	'category': 'all'
});
var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
var noId= ctx.getVariable("noId");
if(noId !=='noId'){
 var PSEngineersID= ctx.getVariable('PSEngineersID');
 var internalId_StatusCode= ctx1.getVariable('internalId_StatusCode');
var caGetextCrewId = ctx.getVariable("caGetextCrewId"); 
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up15|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ExternalRefID = incomingdata.OMS_TaskUpdate.Task.ExternalRefID;
							var g = ExternalRefID.split('_');
							var crewAssignmentId = g[1];
							var omsjobid = g[2];
			var internalId = ctx.getVariable('internalId');
			if (internalId_StatusCode == 200){
				var commentsUri = session.parameters.OMS + '/api/ServiceType/Electric/Job/'+omsjobid +'/Comment';
			  var customcomment = caGetextCrewId +' REASSIGNED TO '+ PSEngineersID ;
                var jobComments = {
                    comment: customcomment
                };
			getURLResponse(commentsUri,'POST','successComments',jobComments);
			}
		}			
});
}
}
