var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var getURLResponse = require('./urlopenUtil.js');

var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});
var noId = ctx.getVariable("noId");
if (noId !== 'noId') {

	var PSEngineersID = ctx.getVariable('PSEngineersID');
	var failComments = ctx.getVariable('failComments');
	if (failComments) {
		throw Error('REASSIGNED failed as CREW ' + PSEngineersID + ' does not exits.');
	}

	var getIntCrewId = ctx.getVariable('getIntCrewId')
	var intCrewId = getIntCrewId.id;
	if (intCrewId === undefined || intCrewId === null || intCrewId === '') {
	}
	else {
		ctx.setVariable("intCrewId", intCrewId);
	}

	var caGetintCrewIdResp = ctx.getVariable('caGetintCrewIdResp')
	//ctx.setVariable("caGetintCrewId", '');
	if (!(caGetintCrewIdResp.crew === undefined || caGetintCrewIdResp.crew === null || caGetintCrewIdResp.crew === '')) {
		if (!(caGetintCrewIdResp.crew.id === undefined || caGetintCrewIdResp.crew.id === null || caGetintCrewIdResp.crew.id === '')) {
			ctx.setVariable("caGetintCrewId", caGetintCrewIdResp.crew.id);
		}
	}

	var caGetextCrewIdResp = ctx.getVariable('caGetintCrewIdResp')
	//ctx.setVariable("caGetextCrewId", '');
	if (!(caGetextCrewIdResp.crew === undefined || caGetextCrewIdResp.crew === null || caGetextCrewIdResp.crew === '')) {
		if (!(caGetextCrewIdResp.crew.externalID === undefined || caGetextCrewIdResp.crew.externalID === null || caGetextCrewIdResp.crew.externalID === '')) {
			ctx.setVariable("caGetextCrewId", caGetextCrewIdResp.crew.externalID);
		}
	}

	session.input.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			logger.error("id=fior_up15|Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {
			var ExternalRefID = incomingdata.OMS_TaskUpdate.Task.ExternalRefID;
			var g = ExternalRefID.split('_');
			var crewAssignmentId = g[1];
			var omsjobid = g[2];

			if (!(caGetintCrewIdResp.crew === undefined || caGetintCrewIdResp.crew === null || caGetintCrewIdResp.crew === '')) {
				if (!(caGetintCrewIdResp.crew.id === undefined || caGetintCrewIdResp.crew.id === null || caGetintCrewIdResp.crew.id === '')) {
					if (intCrewId !== caGetintCrewIdResp) {
						var crewAssignmentUri = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + crewAssignmentId;
						var payload = {
							"crewID": intCrewId
						}
						getURLResponse(crewAssignmentUri, 'PATCH', 'internalId', payload);
						/* var internalId_StatusCode = ctx.getVariable('internalId_StatusCode');
						if (internalId_StatusCode === 200){
							
							var commentsUri = session.parameters.OMS + '/api/ServiceType/Electric/Job/'+omsjobid +'/Comments';
							ctx.setVariable("commentsUri",commentsUri);
						  var customcomment = caGetextCrewId +'REASSIGNED TO '+ PSEngineersID ;
			
							var jobComments = {
								comment: customcomment
							};
						
						
						getURLResponse(commentsUri,'POST','successComments',jobComments);
						} */
					}
					else {
						logger.error("Error in patch call")
					}
				}
			}
		}
	});
}
