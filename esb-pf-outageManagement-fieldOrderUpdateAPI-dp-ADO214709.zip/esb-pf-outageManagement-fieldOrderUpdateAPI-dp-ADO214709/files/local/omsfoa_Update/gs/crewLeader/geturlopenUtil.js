var ctx = session.name("omsfoa") || session.createContext("omsfoa");
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var apiToken = session.parameters.TokenValue;
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
function getURLResponse1(url, myctx) {
	var options = {
		target: url,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "mosfoa_ClientProfile"

	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
	try {
		urlopen.open(options, function(error, response) {
			var ctx = session.name('omsfoa') || session.createContext('omsfoa');
			if (error) {
				var errorinfo = "url connection error 'getURLResponse1', details are : " + info + "; error info :" + error
				ctx.setVariable("customErrorCode", '500');
				ctx.setVariable("customErrorMessage", 'Internal Server Error');
				ctx.setVariable("customReasonMessage", 'Internal Server Error');
				session.output.write(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response 'getURLResponse1', details are : " + info + "; error info :" + error
							logEvent("readAsJSON error: " + JSON.stringify(errorinfo), "");
							session.output.write("readAsJSON error: " + JSON.stringify(errorinfo));
						} else {
							var ctx = session.name('omsfoa') || session.createContext('omsfoa');
							ilsCtx.setVariable('ExitStatus', '0');
							ctx.setVariable(myctx, responseData);
						}
					})
				}
				else if (responseStatusCode == 404) {
					ctx.setVariable('crewNF', 'crewNF');
				} else if (responseStatusCode == 401 || responseStatusCode == 403) {
					// Handle business error responses (HTTP 401 or 403)
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "id=fior_up002: error reading response , details are : " + info + "; error info :" + error;
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "id=fior_up002: " + responseData + " error reading response " + myctx + " , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'getURLResponse1', details are : " + info + "; error info :" + error
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							if (responseStatusCode == 400) {
								
								var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
								if ((ResponseString === "No updates") || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
									var errorinfo = "error response received , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ilsCtx.setVariable('ExitStatus', responseStatusCode);
									ilsCtx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.output.write(incomingdata);
								}else {
													var errorinfo = "error response received, details are:" + info + "; response info : " + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}
							}
							else {
								logger.error("response received " + responseStatusCode + " " + responseData);
								session.reject("response received" + " " + responseStatusCode + " " + responseData);
							}
						}
					});
				}
			}
		})
	} catch (err) {
		var errorinfo = "url connection error getURLResponse1, details are : " + info + "; error info :" + err
		ctx.setVariable("customErrorCode", '500');
		ctx.setVariable("customErrorMessage", 'Internal Server Error');
		ctx.setVariable("customReasonMessage", 'Internal Server Error');

		session.output.write(errorinfo);
		session.reject(errorinfo);
	}
}

module.exports = getURLResponse1;
