var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var getURLResponse1 = require('./geturlopenUtil.js');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});

var EngineersID ='';
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up15|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		
			if (incomingdata.OMS_TaskUpdate.Task.AssignedEngineer !== undefined) {
				if (incomingdata.OMS_TaskUpdate.Task.AssignedEngineer.PSCrewID !== undefined && incomingdata.OMS_TaskUpdate.Task.AssignedEngineer.PSCrewID !== null && incomingdata.OMS_TaskUpdate.Task.AssignedEngineer.PSCrewID !== ''){
				 EngineersID = incomingdata.OMS_TaskUpdate.Task.AssignedEngineer.PSCrewID;
				 ctx.setVariable("PSEngineersID",EngineersID);
				 var CrewId = EngineersID;
var crewuri = session.parameters.OMS + '/api/ServiceType/Electric/Crew/' + EngineersID+'?includeFields=id';
				getURLResponse1(crewuri, 'getIntCrewId');	
						
				/* var getIntCrewIdresp= ctx.getVariable('getIntCrewId');
				var intCrewId= getIntCrewIdresp.id;
				ctx.setVariable("intCrewId",intCrewId); */
				 
				}else {
					//session.reject('');
					ctx.setVariable("noId","noId");
				}
				 
				}
}});