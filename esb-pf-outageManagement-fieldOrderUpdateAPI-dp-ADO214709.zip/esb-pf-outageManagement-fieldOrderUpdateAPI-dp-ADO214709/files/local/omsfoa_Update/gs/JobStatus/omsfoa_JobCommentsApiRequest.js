var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var Engineers = '';
var crewID = '';
var empID = '';
var empName = '';

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("id=fior_up35|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
		if (incomingdata.OMS_EFO_StatusChange.Task.TaskTypeCategory.Name == 'OMS') {
			if (incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID != undefined) {

				var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
				if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name !== "Ready to Assign") {

					if (incomingdata.OMS_EFO_StatusChange.Assignment !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers !== undefined) {
						Engineers = incomingdata.OMS_EFO_StatusChange.Assignment.Engineers;
						crewID = Engineers.crewID;
						empID = Engineers.ID;
						empName = Engineers.Name;
					}

					var g = ExternalRefID.split('_');
					var omsjobid = g[2];

					if (incomingdata.OMS_EFO_StatusChange.comments !== undefined) {
						var inputcomments = incomingdata.OMS_EFO_StatusChange.comments;
					} else {
						var inputcomments = '';
					}
					//var crewID = crewID;
					//var empid = empid;
					/*   var today = new Date();
					  var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
					  var dt = new Date(); //Date constructor 
					  var hh = pad(dt.getHours());
					  var mm = pad(dt.getMinutes());
					  var ss = pad(dt.getSeconds()); */
					// var engineerid = incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.ID;

					var now = new Date();
					var year = now.getFullYear();
					var month = now.getMonth() + 1;
					var month1 = month.toString();
					var strmonthlength = month1.length;
					var todaymonth;
					if (strmonthlength == 1) {
						todaymonth = '0' + month;
					} else {
						todaymonth = month;
					}

					var day = now.getDate();
					var day1 = day.toString();
					var strdaylength = day1.length;
					var todaydate;
					if (strdaylength == 1) {
						todaydate = '0' + day;
					} else {
						todaydate = day;
					}

					var hour = now.getHours();
					var todayhour = hour.toString();
					var strhourlength = todayhour.length;
					var todayhour;
					if (strhourlength == 1) {
						todayhour = '0' + hour;
					} else {
						todayhour = hour;
					}

					var minute = now.getMinutes();
					var todayminute = minute.toString();
					var strminutelength = todayminute.length;
					var todayminute;
					if (strminutelength == 1) {
						todayminute = '0' + minute;
					} else {
						todayminute = minute;
					}

					var second = now.getSeconds();
					var todaysecond = second.toString();
					var strsecondlength = todaysecond.length;
					var todaysecond;
					if (strsecondlength == 1) {
						todaysecond = '0' + todaysecond;
					} else {
						todaysecond = todaysecond;
					}

					var nowdate = year + '-' + todaymonth + '-' + todaydate;
					var nowtime = todayhour + ':' + todayminute + ':' + todaysecond;

					var customcomment = 'REMARKS AMENDMENT BY ' + crewID + ' ' + empName + '( ' + empID + '  ) ON ' + nowdate + ' AT ' + nowtime + ' - ' + inputcomments + '';

					var jobComments = {
						comment: customcomment
					};

					fs.readAsXML('local:///omsfoa_Update/xml/mosfoa_EnvSpecificConfig.xml', function(error, envdetails) {
						if (error) {
							logger.error("id=fior_up36|error while reading the mosfoa_EnvSpecificConfig.xml file");
							throw error; // throw and stop processing
						} else {
							//POST /api/ServiceType/{sid}/Job/{id}/Comments
							var omsjoburi = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + omsjobid + '/Comment';
							//var TokenValue = envdetails.item(0).firstChild.nextSibling.nextSibling.nextSibling.textContent;

							var TokenValue = session.parameters.TokenValue;

							var omsJobapi = {
								target: omsjoburi,
								sslClientProfile: 'mosfoa_ClientProfile',
								method: 'POST',
								contentType: 'application/json',
								headers: {
									'osiApiToken': TokenValue
								},
								data: jobComments
							};


							if ((incomingdata.OMS_EFO_StatusChange.comments !== undefined) && (incomingdata.OMS_EFO_StatusChange.comments !== '') && (incomingdata.OMS_EFO_StatusChange.comments !== null)) {
								var info = " TargetURL :" + omsJobapi.target + "; Method :" + omsJobapi.method + "; Data :" + JSON.stringify(omsJobapi.data) + ". ";
								try {
									urlopen.open(omsJobapi, function(error, response) {
										if (error) {
											var errorinfo = "url connection error with omsJobapi, details are : " + info + "; error info :" + error
											ctx.setVar('postJobId_comments', errorinfo);
											logger.error("id=fior_up37 : " + errorinfo);
											session.reject("id=fior_up37 : " + errorinfo);
											//throw errorinfo;
										} else {
											ctx.setVar('postJobId_comments', response);
											// read response data
											// get the response status code
											var responseStatusCode = response.statusCode;
											var responseReasonPhrase = response.reasonPhrase;
											if (responseStatusCode == 200) {
												response.readAsJSON(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'omsJobapi', details are : " + info + "; error info :" + error
														ctx.setVar('postJobId_comments', errorinfo);
														logger.error("id=fior_up38 : " + errorinfo);
														session.reject("id=fior_up90 : " + errorinfo);
													} else {
														ctx.setVar('postJobId_comments', responseData);
														hm.response.statusCode = responseStatusCode;
														hm.response.statusCode = responseStatusCode;
														ilsCtx.setVariable('ExitStatus', '0');
														logger.debug("response received from omsJobapi for omsjobid:" + omsjobid + " " + responseStatusCode);
														session.output.write(responseData);
													}
												});
											} else if (responseStatusCode == 400 || responseStatusCode == 404) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "Error from omsJobapi call, details are : " + info + "; error info :" + error
														logger.error(errorinfo);
														session.reject(errorinfo);
													}
													else {
														var BusinessResponseData = responseData;
														var buff = Buffer.from(BusinessResponseData);
														var ResponseString = buff.toString();
														if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
															var errorinfo = "Error from omsJobapi call, details are:" + info + "; response info :" + responseData
															ilsCtx.setVariable('ExitStatus', responseStatusCode);
															ilsCtx.setVariable('ExitDescription', errorinfo);
															logger.error(errorinfo);
															session.output.write(incomingdata);
														} else {
															var errorinfo = "error reading response 'omsJobapi call', details are:" + info + responseData
															ilsCtx.setVariable('ExitStatus', responseStatusCode);
															ilsCtx.setVariable('ExitDescription', errorinfo);
															var ctx = session.name('omsfoa') || session.createContext('omsfoa');
															ctx.setVariable('AvoidBackOut', 'yes');
															//throw Error("id=fior_up39 : " + errorinfo);
														}
													}
												});
											} else if (responseStatusCode == 401 || responseStatusCode == 403) {
												// Handle business error responses (HTTP 401 or 403)
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														// Handle error in reading response data
														var errorinfo = "id=fior_up024:Error from omsJobapi call , details are : " + info + "; error info :" + error;
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														var errorinfo = "id=fior_up024:" + responseData + " Error from omsJobapi call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
														logger.error(errorinfo);
														session.reject(errorinfo);
													}
												});
											} else {

												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "Error from omsJobapi for omsjobid:" + omsjobid + info + "; error info :" + error
														logger.error("id=fior_up39A: " + errorinfo);
														session.reject("id=fior_up39A : " + errorinfo);
														//throw Error("id=fior_up39 : " + errorinfo);
													} else {
														var errorinfo = "error response from omsJobapi for omsjobid details are :" + omsjobid + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														logger.error("id=fior_up39B : " + errorinfo);
														session.reject("id=fior_up39B : " + errorinfo);
														//throw Error("id=fior_up39 : " + errorinfo);
													}
												});
											}

										}
									});
								} catch (err) {
									var errorinfo = "url connection error with omsJobapi, details are : " + info + "; error info :" + err
									ctx.setVar('postJobId_comments', errorinfo);
									logger.error("id=fior_up37 : " + errorinfo);
									session.reject("id=fior_up37 : " + errorinfo);
									//throw errorinfo;
								}
							}

						}
					});
				}
			} else {
				logger.error("id=fior_up40|omsjobid is not passed in incoming data");
			}
		}
	}
	}
});

function pad(n) {
	return (n < 10) ? ("0" + n) : n;
}
