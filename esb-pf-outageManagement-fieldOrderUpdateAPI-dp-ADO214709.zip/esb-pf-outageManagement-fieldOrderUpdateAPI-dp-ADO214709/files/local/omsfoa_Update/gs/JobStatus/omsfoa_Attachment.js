var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(async function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up11|Error in reading incoming data");
		session.reject(readAsJSONError);
		return;
	}

	var ctx = session.name('omsfoa') || session.createContext('omsfoa');
	var avoidcall = ctx.getVariable("AvoidBackOut");

	if (avoidcall != 'yes') {
		if (incomingdata.OMS_EFO_StatusChange.Task.Attachments != undefined) {
			ctx.setVariable('action', 'attachments');
			var attachments = incomingdata.OMS_EFO_StatusChange.Task.Attachments;
			var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
			var ExternalRefIDArray = ExternalRefID.split('_');
			var Jobid = ExternalRefIDArray[2];
			var downloadTypeValue = session.parameters.EFONEW;
			var downloadType;
			var userId;

			if (downloadTypeValue == 'Y') {
				downloadType = 4;
				userId = session.parameters.DowntypeuserId;
			} else {
				downloadType = 1;
				userId = session.parameters.userId;
			}

			// Process attachments sequentially - WAIT for each one
			for (var i = 0; i < attachments.length; i++) {
				if ((attachments[i].ExternalURL_SO != '') && (attachments[i].ExternalURL_SO != null)) {
					var AttachmentUrl = session.parameters.AttachmentUrl;
					var Attachmentpayload = {};

					Attachmentpayload.downloadType = downloadType;
					Attachmentpayload.id = Jobid;
					Attachmentpayload.url = attachments[i].ExternalURL_SO;
					Attachmentpayload.userId = userId;

					if (downloadTypeValue == 'Y') {
						Attachmentpayload.fileName = attachments[i].FileName;
						Attachmentpayload.checkForDup = true;
						Attachmentpayload.asyncReplyFlag = true;
					} else {
						Attachmentpayload.fileName = 'FSM_' + attachments[i].FileName;
						Attachmentpayload.checkForDup = true;
						Attachmentpayload.asyncReplyFlag = true;
					}

					try {
						// WAIT for response before processing next attachment
						var result = await ImageUpload(AttachmentUrl, Attachmentpayload);
						logger.debug("id=fior_up15|Attachment " + i + " uploaded successfully");
					} catch (error) {
						logger.error("id=fior_up16|Attachment " + i + " upload failed: " + error);
						session.reject(error);
						return;
					}
				}
			}

			// All attachments processed successfully
			hm.response.statusCode = '200 OK';
			logger.debug("id=fior_up17|All attachments processed successfully");
		}
	}
});

// Convert callback-based urlopen to Promise
function ImageUpload(AttachmentUrl, Attachmentpayload) {
	return new Promise((resolve, reject) => {
		var AttachmentApi = {
			target: AttachmentUrl,
			sslClientProfile: 'omsfoa_Update_IIB_ClientProfile',
			method: 'POST',
			contentType: 'application/json',
			data: Attachmentpayload
		};

		var info = " TargetURL :" + AttachmentApi.target + "; Method :" + AttachmentApi.method + "; Data :" + JSON.stringify(AttachmentApi.data) + ". ";

		try {
			urlopen.open(AttachmentApi, function(error, response) {
				if (error) {
					var errorinfo = "url connection error 'AttachmentApi', details are : " + info + "; error info :" + error;
					ctx.setVariable('ImageUpload', 'ImageUpload');
					logger.error("id=fior_up12 : " + errorinfo);
					resolve({});
					//reject(new Error("id=fior_up12 : " + errorinfo));
				} else {
					var responseStatusCode = response.statusCode;
					var responseReasonPhrase = response.reasonPhrase;

					if (responseStatusCode == 200) {
						hm.response.statusCode = '200 OK';
						logger.debug("id=fior_up13|response received from AttachmentApi call:");
						resolve({
							statusCode: 200,
							reasonPhrase: responseReasonPhrase
						});
					} else {
						// Read response data for non-200 status
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								var errorinfo = "failure in reading response from AttachmentApi, details are : " + info + "; error info :" + readError;
								ctx.setVariable('ImageUpload', 'ImageUpload');
								logger.error("id=fior_up14 : " + errorinfo);
								resolve({});
								//reject(new Error("id=fior_up14 : " + errorinfo));
							} else {
								var errorinfo = "Error returned from AttachmentApi call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
								ctx.setVariable('ImageUpload', 'ImageUpload');
								logger.error("id=fior_up14 : " + errorinfo);
									resolve({});
								// Reject even for non-200 responses
								//reject(new Error("id=fior_up14 : " + errorinfo));
							}
						});
					}
				}
			});
		} catch (err) {
			var errorinfo = "url connection error 'AttachmentApi', details are : " + info + "; error info :" + err;
			ctx.setVariable('ImageUpload', 'ImageUpload');
			logger.error("id=fior_up12 : " + errorinfo);
					resolve({});
			//reject(new Error("id=fior_up12 : " + errorinfo));
		}
	});
}
