var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});

var Engineers = "";
var crewID = "";
var empID = "";
var empName = "";
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("id=fior_up41|omsjobid is not passed in incoming dataError in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
			if (incomingdata.OMS_EFO_StatusChange.Task.TaskTypeCategory.Name == 'OMS') {
				if (incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID !== undefined) {

					var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
					var g = ExternalRefID.split('_');

					var CrewAssignmentId = g[1];
					if (incomingdata.OMS_EFO_StatusChange.Assignment !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers !== undefined) {
						Engineers = incomingdata.OMS_EFO_StatusChange.Assignment.Engineers;
						crewID = Engineers.crewID;
						empID = Engineers.ID;
						empName = Engineers.Name;
					}

					var statusname = '';
					if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name !== undefined) {
						if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name == 'Ready to Assign') {
							statusname = 'Request Successful';
						}
						if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name !== 'Ready to Assign') {
							if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name === 'Dispatched') {
								statusname = 'Dispatch Successful'
							} else if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name === 'Stand By') {
								statusname = 'Stand By'
							} else if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name === 'Canceled') {
								statusname = 'Canceled'
							} else {
								statusname = incomingdata.OMS_EFO_StatusChange.Task.Status.Name;
							}
						}
						logger.info("statusname" + statusname);

					} else {

						statusname = ' ';
					}

					var crewAssignmentIduri = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentId;
					var TokenValue = session.parameters.TokenValue;
					var status = incomingdata.OMS_EFO_StatusChange.Task.Status.Name;
					var crewAssignmentWorkTypeapi = {
						target: crewAssignmentIduri,
						sslClientProfile: 'mosfoa_ClientProfile',
						method: 'GET',
						contentType: 'application/json',
						headers: {
							'osiApiToken': TokenValue
						}
					};
					var info = " TargetURL :" + crewAssignmentWorkTypeapi.target + "; Method :" + crewAssignmentWorkTypeapi.method + ". ";
					try {
						urlopen.open(crewAssignmentWorkTypeapi, function(error, response) {
							if (error) {
								var errorinfo = "url connection error 'crewAssignmentWorkTypeapi', details are : " + info + "; error info :" + error
								ctx.setVar('getCrewAssignmentID', errorinfo);
								logger.error("id=fior_up42 : " + errorinfo);
								ctx.setVar("urlopen connect error with crewAssignmentWorkTypeapi", errorinfo);
								session.reject("id=fior_up42 : " + errorinfo);
								//throw errorinfo;
							} else {
								ctx.setVar('getCrewAssignmentID', response);
								var responseStatusCode = response.statusCode;
								var responseReasonPhrase = response.reasonPhrase;
								if (responseStatusCode == 200 || responseStatusCode == 404) {

									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "failure in putting message to crewAssignmentWorkTypeapi, details are : " + info + "; error info :" + error
												ctx.setVar('getCrewAssignmentID', errorinfo);
												logger.error("id=fior_up43 : " + errorinfo);
												session.reject("id=fior_up43 : " + errorinfo);
											} else {
												ctx.setVar('getCrewAssignmentID_worktypeId', responseData.workTypeID);
												hm.response.statusCode = responseStatusCode;
												ilsCtx.setVariable('ExitStatus', '0');
												logger.debug("id=fior_up44|response received from crewAssignmentWorkTypeapi for crewAssignmentId:" + CrewAssignmentId + " " + responseStatusCode);
												ctx.setVar('getCrewAssignmentID_RESPONSE_DATA', responseData);

												var workTypeID = responseData.workTypeID;
												var getStatus = responseData.status;
												var crewExternalId = '';

												var LookupStatus = status;

												session.output.write(LookupStatus);
												if (workTypeID != null) {
													var lookupMessage = {
														"lookupReq": {
															"type": [{
																"name": "workType.workflows",
																"id": workTypeID,
																"label": statusname
															},
															{
																"name": "workType.workflows",
																"id": workTypeID,
																"status": getStatus
															}

															]
														}
													}
													var TokenValue = session.parameters.TokenValue;
													var url = session.parameters.lookupurl;
													ctx.setVar('LookupMessage', lookupMessage);
													logger.info("url++++" + url);

													logger.info("lookupMessage" + lookupMessage);
													var LookupServiceResponse = {
														target: url,
														method: 'POST',
														contentType: 'application/json',
														data: lookupMessage
													};

													logger.info("response" + LookupServiceResponse);

													var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
													try {
														urlopen.open(LookupServiceResponse, function(error, response) {
															if (error) {
																var errorinfo = "url connection error 'LookupServiceResponse', details are : " + info + "; error info :" + error
																ctx.setVar('postLookup', errorinfo);
																logger.error("id=fior_up45 : " + errorinfo);
																session.reject("id=fior_up45 : " + errorinfo);
																//throw errorinfo;
															} else {
																ctx.setVar('postLookup', response);
																var responseStatusCode = response.statusCode;
																var responseReasonPhrase = response.reasonPhrase;
																if (responseStatusCode == 200) {
																	response.readAsJSON(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'LookupServiceResponse', details are : " + info + "; error info :" + error
																			ctx.setVar('postLookup', errorinfo);
																			logger.error("id=fior_up46 : " + errorinfo);
																			session.reject("id=fior_up46 : " + errorinfo);
																		} else {
																			ctx.setVar('postLookup', responseData);
																			hm.response.statusCode = responseStatusCode;
																			ilsCtx.setVariable('ExitStatus', '0');
																			logger.debug("response received from LookupServiceResponse " + responseData);
																			console.info("LOOKUP RESPONSE ::::::" + JSON.stringify(responseData));
																			{
																				var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
																				var g = ExternalRefID.split('_');

																				var CrewAssignmentId = g[1];

																				var CrewAssigmenturi = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentId + '/WorkFlow';
																				var TokenValue = session.parameters.TokenValue;
																				var LookupLabel = responseData.lookupRep.type[0].label;
																				var LookupgetLabel = responseData.lookupRep.type[1].label;
																				var LookupStatus = responseData.lookupRep.type[0].status;

																				/* var today = new Date();
																				var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
																				var dt = new Date(); //Date constructor 
																				var hh = pad(dt.getHours());
																				var mm = pad(dt.getMinutes());
																				var ss = pad(dt.getSeconds());
																				 */
																				var now = new Date();
																				var year = now.getFullYear();
																				var month = now.getMonth() + 1;
																				var month1 = month.toString();
																				var strmonthlength = month1.length;
																				var todaymonth;
																				if (strmonthlength == 1) {
																					todaymonth = '0' + month;
																				} else {
																					todaymonth = month;
																				}

																				var day = now.getDate();
																				var day1 = day.toString();
																				var strdaylength = day1.length;
																				var todaydate;
																				if (strdaylength == 1) {
																					todaydate = '0' + day;
																				} else {
																					todaydate = day;
																				}

																				var hour = now.getHours();
																				var todayhour = hour.toString();
																				var strhourlength = todayhour.length;
																				var todayhour;
																				if (strhourlength == 1) {
																					todayhour = '0' + hour;
																				} else {
																					todayhour = hour;
																				}

																				var minute = now.getMinutes();
																				var todayminute = minute.toString();
																				var strminutelength = todayminute.length;
																				var todayminute;
																				if (strminutelength == 1) {
																					todayminute = '0' + minute;
																				} else {
																					todayminute = minute;
																				}

																				var second = now.getSeconds();
																				var todaysecond = second.toString();
																				var strsecondlength = todaysecond.length;
																				var todaysecond;
																				if (strsecondlength == 1) {
																					todaysecond = '0' + todaysecond;
																				} else {
																					todaysecond = todaysecond;
																				}

																				var nowdate = year + '-' + todaymonth + '-' + todaydate;
																				var nowtime = todayhour + ':' + todayminute + ':' + todaysecond;
																				var customcomment = '';
																				var taskStatusName = incomingdata.OMS_EFO_StatusChange.Task.Status.Name;
																				if (statusname === 'Canceled') {
																					customcomment = 'DELETED FROM MWM ON ' + nowdate + ' AT ' + nowtime;
																				} else {

																					customcomment = crewID + ' ' + empName + '(' + empID + ')' + statusname + ' ON ' + nowdate + ' AT ' + nowtime;
																				}
																				ctx.setVar('customComment', customcomment);
																				var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
																				var g = ExternalRefID.split('_');

																				var CrewJobId = g[2];

																				var CrewJobIduri = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + CrewJobId + '/Comment';

																				var TokenValue = session.parameters.TokenValue;
																				var status = incomingdata.OMS_EFO_StatusChange.Task.Status.Name;
																				var comment = ""
																				var payload = {
																					comment: customcomment
																				}
																				var CrewJobIduriStatusPost = {
																					target: CrewJobIduri,
																					sslClientProfile: 'mosfoa_ClientProfile',
																					method: 'POST',
																					contentType: 'application/json',
																					headers: {
																						'osiApiToken': TokenValue
																					},
																					data: payload
																				};

																				if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name !== 'Ready to Assign' || (incomingdata.OMS_EFO_StatusChange.Task.Status.Name === 'Ready to Assign' && incomingdata.OMS_EFO_StatusChange.Assignment !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.ID !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.ID !== null)) {

																					var info = " TargetURL :" + CrewJobIduriStatusPost.target + "; Method :" + CrewJobIduriStatusPost.method + "; Data :" + JSON.stringify(CrewJobIduriStatusPost.data) + ". ";
																					try {
																						urlopen.open(CrewJobIduriStatusPost, function(error, response) {
																							if (error) {
																								var errorinfo = "url connection error 'CrewJobIduriStatusPost', details are : " + info + "; error info :" + error
																								ctx.setVar('postJobId_comments2', errorinfo);
																								logger.error("id=fior_up47 : " + errorinfo);
																								session.reject("id=fior_up47 : " + errorinfo);
																								//throw errorinfo;
																							} else {
																								ctx.setVar('postJobId_comments2', response);

																								var responseStatusCode = response.statusCode;
																								var responseReasonPhrase = response.reasonPhrase;
																								if (responseStatusCode == 200 || responseStatusCode == 404) {
																									response.readAsJSON(function(error, responseData) {
																										if (error) {
																											var errorinfo = "error reading response 'CrewJobIduriStatusPost', details are : " + info + "; error info :" + error
																											ctx.setVar('postJobId_comments2', errorinfo);
																											logger.error("id=fior_up48 : " + errorinfo);
																											session.reject("id=fior_up48 : " + errorinfo);
																										} else {
																											var responseinfo = "response received from CrewJobIduriStatusPost for CrewJobId:" + CrewJobId + " " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																											ctx.setVar('postJobId_comments2', responseinfo);
																											hm.response.statusCode = responseStatusCode;
																											ilsCtx.setVariable('ExitStatus', '0');
																											logger.debug("id=fior_up49 : " + responseinfo);
																											session.output.write(response);
																										}
																									});
																								}
																								else if (responseStatusCode == 400 || responseStatusCode == 404) {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											var errorinfo = "error reading response 'CrewJobIduriStatusPost', details are : " + info + "; error info :" + error
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										}
																										else {
																											var BusinessResponseData = responseData;
																											var buff = Buffer.from(BusinessResponseData);
																											var ResponseString = buff.toString();
																											if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																												var errorinfo = "error reading response 'CrewJobIduriStatusPost', details are:" + info + responseData
																												ilsCtx.setVariable('ExitStatus', responseStatusCode);
																												ilsCtx.setVariable('ExitDescription', errorinfo);
																												logger.error(errorinfo);
																												session.output.write(incomingdata);
																											} else {
																												var errorinfo = "error reading response 'CrewJobIduriStatusPost', details are:" + info + "; response info : " + responseData
																												ilsCtx.setVariable('ExitStatus', responseStatusCode);
																												ilsCtx.setVariable('ExitDescription', errorinfo);
																												var ctx = session.name('omsfoa') || session.createContext('omsfoa');
																												ctx.setVariable('AvoidBackOut', 'yes');
																											}
																										}
																									});
																								}
																								else if (responseStatusCode == 401 || responseStatusCode == 403) {
																									// Handle business error responses (HTTP 401 or 403)
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											// Handle error in reading response data
																											var errorinfo = "id=fior_up026: Error from CrewJobIduriStatusPost , details are : " + info + "; error info :" + error;
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										} else {
																											var errorinfo = "id=fior_up026: " + responseData + " Error from CrewJobIduriStatusPost , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										}
																									});
																								} else {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											var errorinfo = "Error from CrewJobIduriStatusPost for CrewJobId, details are :" + CrewJobId + info + "; error info :" + error
																											logger.error("id=fior_up49 : " + errorinfo);
																											session.reject("id=fior_up49 : " + errorinfo);
																										} else {
																											var errorinfo = "Error from CrewJobIduriStatusPost for CrewJobId, details are:" + CrewJobId + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																											logger.error("id=fior_up49 : " + errorinfo);
																											session.reject("id=fior_up49 : " + errorinfo);
																										}
																									});
																								}
																							}
																						});
																					} catch (err) {
																						var errorinfo = "url connection error 'CrewJobIduriStatusPost', details are : " + info + "; error info :" + err
																						ctx.setVar('postJobId_comments2', CrewJobIduriStatusPost);
																						logger.error("id=fior_up47 : " + errorinfo);
																						session.reject("id=fior_up47 : " + errorinfo);
																						//throw errorinfo;
																					}

																				} // end of ready to assign condition for comments

																				var payload2 = {

																					status: LookupStatus
																				};

																				var crewAssignmentapiStatusPost = {
																					target: CrewAssigmenturi,
																					sslClientProfile: 'mosfoa_ClientProfile',
																					method: 'POST',
																					contentType: 'application/json',
																					headers: {
																						'osiApiToken': TokenValue
																					},
																					data: payload2
																				};

																				ctx.setVar('LookupgetLabel', LookupgetLabel);
																				ctx.setVar('statusname', statusname);
																				if (LookupLabel !== 'none') {
																					if (!(LookupgetLabel === 'Stand By' && statusname === 'Stand By')) {

																						var info = " TargetURL :" + crewAssignmentapiStatusPost.target + "; Method :" + crewAssignmentapiStatusPost.method + "; Data :" + JSON.stringify(crewAssignmentapiStatusPost.data) + ". ";
																						try {
																							urlopen.open(crewAssignmentapiStatusPost, function(error, response) {
																								if (error) {
																									var errorinfo = "url connection error 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + error
																									ctx.setVar('postCrewAssignmentID_workflow', errorinfo);
																									logger.error("id=fior_up51 : " + errorinfo);
																									session.reject("id=fior_up51 : " + errorinfo);
																									//throw errorinfo;
																								} else {
																									ctx.setVar('postCrewAssignmentID_workflow', response);

																									var responseStatusCode = response.statusCode;
																									var responseReasonPhrase = response.reasonPhrase;
																									if (responseStatusCode == 200 || responseStatusCode == 404) {
																										response.readAsJSON(function(error, responseData) {
																											if (error) {
																												var errorinfo = "error reading response 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + error
																												ctx.setVar('postCrewAssignmentID_workflow', errorinfo);
																												logger.error("id=fior_up52 : " + errorinfo);
																												session.reject("id=fior_up52 : " + errorinfo);
																											} else {
																												ctx.setVar('postCrewAssignmentID_workflow', responseData);
																												hm.response.statusCode = responseStatusCode;
																												ilsCtx.setVariable('ExitStatus', '0');
																												logger.debug("id=fior_up53|response received from crewAssignmentapiStatusPost for CrewAssignmentId:" + CrewAssignmentId + " " + responseStatusCode);
																												session.output.write(responseData);
																											}
																										});
																									}
																									else if (responseStatusCode == 400 || responseStatusCode == 404) {
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												var errorinfo = "error reading response 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + error
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											}
																											else {
																												var BusinessResponseData = responseData;
																												var buff = Buffer.from(BusinessResponseData);
																												var ResponseString = buff.toString();
																												if ((ResponseString == 'No updates') || (ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION"))) {
																													var errorinfo = "error reading response 'crewAssignmentapiStatusPost', details are:" + info + responseData
																													ilsCtx.setVariable('ExitStatus', responseStatusCode);
																													ilsCtx.setVariable('ExitDescription', errorinfo);
																													logger.error(errorinfo);
																													session.output.write(incomingdata);
																												} else {
																													var errorinfo = "error reading response 'crewAssignmentapiStatusPost', details are:" + info + responseData
																													ilsCtx.setVariable('ExitStatus', responseStatusCode);
																													ilsCtx.setVariable('ExitDescription', errorinfo);
																													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
																													ctx.setVariable('AvoidBackOut', 'yes');
																												}
																											}
																										});
																									}
																									else if (responseStatusCode == 401 || responseStatusCode == 403) {
																										// Handle business error responses (HTTP 401 or 403)
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												// Handle error in reading response data
																												var errorinfo = "id=fior_up027: Error from crewAssignmentapiStatusPost , details are : " + info + "; error info :" + error;
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											} else {
																												var errorinfo = "id=fior_up027: " + responseData + " Error from crewAssignmentapiStatusPost , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											}
																										});
																									} else {
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												var errorinfo = "Error from crewAssignmentapiStatusPost for CrewAssignmentId, details are : " + CrewAssignmentId + info + "; error info :" + error
																												logger.error("id=fior_up54 : " + errorinfo);
																												session.reject("id=fior_up54 : " + errorinfo);
																											} else {
																												var errorinfo = "Error from crewAssignmentapiStatusPost for CrewAssignmentId, details are: " + CrewAssignmentId + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																												logger.error("id=fior_up54 : " + errorinfo);
																												session.reject("id=fior_up54 : " + errorinfo);
																											}
																										});
																									}
																								}
																							});
																						}
																						catch (err) {
																							var errorinfo = "url connection error 'crewAssignmentapiStatusPost', details are : " + info + "; error info :" + err
																							ctx.setVar('postCrewAssignmentID_workflow', errorinfo);
																							logger.error("id=fior_up51 : " + errorinfo);
																							session.reject("id=fior_up51 : " + errorinfo);
																							//throw errorinfo;
																						}
																					}
																				}
																			}
																		}
																	});
																} else {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "Error from LookupServiceResponse responsecode, details are : " + info + "; error info :" + error
																			logger.error("id=fior_up55 : " + errorinfo);
																			session.reject("id=fior_up55 : " + errorinfo);
																		} else {
																			var errorinfo = "Error from LookupServiceResponse responsecode, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			logger.error("id=fior_up55 : " + errorinfo);
																			session.reject("id=fior_up55 : " + errorinfo);
																		}
																	});
																}
															}
														});
													} catch (err) {
														var errorinfo = "url connection error 'LookupServiceResponse', details are : " + info + "; error info :" + err
														ctx.setVar('postLookup', errorinfo);
														logger.error("id=fior_up45 : " + errorinfo);
														session.reject("id=fior_up45 : " + errorinfo);
														//throw errorinfo;
													}
													//closing worktypeid
												}
											}
										});
										//if block close for status code 200
									}
									//if block for 200 and 400 code stops
								}
								else if (responseStatusCode == 400 || responseStatusCode == 404) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "Error from crewAssignmentWorkTypeapi for crewAssignmentId, details are : " + info + "; error info :" + error
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
										else {
											var BusinessResponseData = responseData;
											var buff = Buffer.from(BusinessResponseData);
											var ResponseString = buff.toString();
											//JSON.parse(responseData.toString());
											if ((ResponseString == 'No updates') || (ResponseString.contains(String("OMS_CIRCULAR_WORKFLOW_TRANSITION")))) {
												var errorinfo = "Error from crewAssignmentWorkTypeapi for crewAssignmentId, details are:" + info + responseData
												ilsCtx.setVariable('ExitStatus', responseStatusCode);
												ilsCtx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.output.write(incomingdata);
											 } else {
												var errorinfo = "Error from crewAssignmentWorkTypeapi for crewAssignmentId, details are:" + info + "; response info : " + responseData
												ilsCtx.setVariable('ExitStatus', responseStatusCode);
												ilsCtx.setVariable('ExitDescription', errorinfo);
												var ctx = session.name('omsfoa') || session.createContext('omsfoa');
												ctx.setVariable('AvoidBackOut', 'yes');
											}
										}
									});
								}
								else if (responseStatusCode == 401 || responseStatusCode == 403) {
									// Handle business error responses (HTTP 401 or 403)
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											// Handle error in reading response data
											var errorinfo = "id=fior_up025: Error from crewAssignmentWorkTypeapi, details are : " + info + "; error info :" + error;
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "id=fior_up025: " + responseData + " Error from crewAssignmentWorkTypeapi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});
								} else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "Error from crewAssignmentWorkTypeapi for crewAssignmentId, details are:" + CrewAssignmentId + info + "; error info :" + error
											logger.error("id=fior_up56 : " + errorinfo);
											session.reject("id=fior_up56 : " + errorinfo);
										} else {
											var errorinfo = "Error from crewAssignmentWorkTypeapi for crewAssignmentId, details are:" + CrewAssignmentId + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											logger.error("id=fior_up56 : " + errorinfo);
											session.reject("id=fior_up56 : " + errorinfo);
										}
									});
								}
							}
						});
					} catch (err) {
						var errorinfo = "url connection error crewAssignmentWorkTypeapi, details are : " + info + "; error info :" + err
						ctx.setVar('getCrewAssignmentID', errorinfo);
						logger.error("id=fior_up42 : " + errorinfo);
						ctx.setVar("urlopen connect error with crewAssignmentWorkTypeapi", errorinfo);
						session.reject("id=fior_up42 : " + errorinfo);
						//throw errorinfo;
					}
				} else {
					logger.error("id=fior_up57|ExternalRefID is not passed in incoming data");
				}
			}
		}
	}
});

function pad(n) {
	return (n < 10) ? ("0" + n) : n;
}
