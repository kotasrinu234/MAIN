var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up15|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//validation starts
		ctx.setVariable('incdata', incomingdata);
		if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name === undefined || incomingdata.OMS_EFO_StatusChange.Task.Status.Name === '' || incomingdata.OMS_EFO_StatusChange.Task.Status.Name === null) {
			logger.error("id=fior_up134|StatusName is not passed in incoming data");
			throw Error("id=fior_up134|StatusName is not passed in incoming data");
		}

		var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
		var g = ExternalRefID.split('_');
		var crewAssignmentId = g[1];
		var jobId = g[2];
		var callId = g[3];
		//if (g.length != 4 || (g[1]==='' || g[2]==='' || g[3]===''))  {
		/* if (g[1]==='' || g[2]==='')  {
		logger.error("id=fior_up135|crewAssignmentId or JobId  is not passed in incoming data");
		throw Error("id=fior_up135|crewAssignmentId or JobId  is not passed in incoming data");
	} */

		/*  if (incomingdata.OMS_EFO_StatusChange.Assignment !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Start === undefined || incomingdata.OMS_EFO_StatusChange.Assignment.Start === '' || incomingdata.OMS_EFO_StatusChange.Assignment.Start === null) {
			 logger.info("id=fior_up136|AssignmentStart is not passed in incoming data");
			 //throw Error("id=fior_up136|AssignmentStart is not passed in incoming data");
		 }
		 if (incomingdata.OMS_EFO_StatusChange.Assignment !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Finish === undefined || incomingdata.OMS_EFO_StatusChange.Assignment.Finish === '' || incomingdata.OMS_EFO_StatusChange.Assignment.Finish === null)  {
			 logger.info("id=fior_up137|AssignmentFinish is not passed in incoming data");
			 //throw Error("id=fior_up137|AssignmentFinish is not passed in incoming data");
		 }
		 if (incomingdata.OMS_EFO_StatusChange.Assignment !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.ID === undefined || incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.ID === '' || incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.ID === null)  {
			 logger.info("id=fior_up138|EngineersID is not passed in incoming data");
			 //throw Error("id=fior_up138|EngineersID is not passed in incoming data");
		 }
		 if (incomingdata.OMS_EFO_StatusChange.Assignment !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.Name === undefined || incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.Name === '' || incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.Name === null) {
			 logger.info("id=fior_up139|EngineersName is not passed in incoming data");
			 //throw Error("id=fior_up139|EngineersName is not passed in incoming data");
		 }
  */

		/*  if (incomingdata.OMS_EFO_StatusChange.estimatedRestorationTime === undefined || incomingdata.OMS_EFO_StatusChange.estimatedRestorationTime === null || incomingdata.OMS_EFO_StatusChange.estimatedRestorationTime === "") {
			 logger.info("id=fior_up140|estimatedRestorationTime is required");
			 //throw Error('id=fior_up140|estimatedRestorationTime is required');
		 }

		 if (incomingdata.OMS_EFO_StatusChange.estimatedResolutionTime === undefined || incomingdata.OMS_EFO_StatusChange.estimatedResolutionTime === null || incomingdata.OMS_EFO_StatusChange.estimatedResolutionTime === "") {
			 logger.info("id=fior_up146|estimatedResolutionTime is required");
			// throw Error('id=fior_up146|estimatedResolutionTime is required');
		 }
		 if (incomingdata.OMS_EFO_StatusChange.estimatedArrivalTime === undefined || incomingdata.OMS_EFO_StatusChange.estimatedArrivalTime === null || incomingdata.OMS_EFO_StatusChange.estimatedArrivalTime === "") {
			 logger.info("id=fior_up142|estimatedArrivalTime is required");
			// throw Error('id=fior_up142|estimatedArrivalTime is required');
		 }

		 if (incomingdata.OMS_EFO_StatusChange.estimatedCompletionTime === undefined || incomingdata.OMS_EFO_StatusChange.estimatedCompletionTime === null || incomingdata.OMS_EFO_StatusChange.estimatedCompletionTime === "") {
			 logger.info("id=fior_up143|estimatedCompletionTime is required");
			// throw Error('id=fior_up143|estimatedCompletionTime is required');
		 } */

		//validation ends

		if (incomingdata.OMS_EFO_StatusChange.Task.TaskTypeCategory.Name == 'OMS') {
			if (incomingdata.OMS_EFO_StatusChange.Assignment !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers !== undefined && incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.crewID !== undefined) {

				if (incomingdata.OMS_EFO_StatusChange.CrewLocation !== undefined) {
					if (incomingdata.OMS_EFO_StatusChange.CrewLocation.latitude !== undefined) {
						var latitude = incomingdata.OMS_EFO_StatusChange.CrewLocation.latitude;
					}
					else {
						logger.info("id=fior_up144|latitude is not passed in incoming data");
						// throw Error("id=fior_up144|latitude is not passed in incoming data");
					}
					if (incomingdata.OMS_EFO_StatusChange.CrewLocation.longitude !== undefined) {
						var longitude = incomingdata.OMS_EFO_StatusChange.CrewLocation.longitude;
					} else {
						logger.info("id=fior_up145|longitude is not passed in incoming data");
						//  throw Error("id=fior_up145|longitude is not passed in incoming data");
					}

					var Crewid = incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.crewID;
					var coordinatesobject = [longitude, latitude];
					var coordinates = {
						coordinates: coordinatesobject,
						type: "POINT"
					};

					var crewlocationpayload = {
						location: coordinates
					};

					/* fs.readAsXML('local:///omsfoa_Update/xml/mosfoa_EnvSpecificConfig.xml', function(error, envdetails) {
						if (error) {
							logger.error("id=fior_up16|error while reading the mosfoa_EnvSpecificConfig.xml file");
							throw error; // throw and stop processing
						} else { */

					var crewlocationuri = session.parameters.OMS + '/api/ServiceType/Electric/Crew/' + Crewid;
					//var crewlocationuri = 'https://10.0.96.10:8443/oms/external/api/ServiceType/Electric/Crew/' + Crewid;

					//var TokenValue = envdetails.item(0).firstChild.nextSibling.nextSibling.nextSibling.textContent;
					var TokenValue = session.parameters.TokenValue;
					
					var crewlocationapi = {
						target: crewlocationuri,
						sslClientProfile: 'mosfoa_ClientProfile',
						method: 'PATCH',
						contentType: 'application/json',
						headers: {
							'osiApiToken': TokenValue
						},
						data: crewlocationpayload
					};
					var info = " TargetURL :" + crewlocationapi.target + "; Method :" + crewlocationapi.method + "; Data :" + JSON.stringify(crewlocationapi.data) + ". ";
					try {
						urlopen.open(crewlocationapi, function(error, response) {
							if (error) {
								var errorinfo = "url connection error 'crewlocationapi', details are : " + info + "; error info :" + error
								ctx.setVar('patchCrewId', errorinfo);
								logger.error("id=fior_up17 : " + errorinfo);
								session.reject("id=fior_up17 : " + errorinfo);
								//throw Error("id=fior_up17 : " + errorinfo);
							} else {
								// read response data
								// get the response status code
								ctx.setVar('patchCrewId', response);
								var responseStatusCode = response.statusCode;
								var responseReasonPhrase = response.reasonPhrase;
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure in putting message to crewlocationapi, details are : " + info + "; error info :" + error
										ctx.setVar('patchCrewId', errorinfo);
										logger.error("id=fior_up18 : " + errorinfo);
										session.reject("id=fior_up18 : " + errorinfo);
									} else {
										if (responseStatusCode == 200) {
											var responseinfo = "response received from crewlocationapi for crewid:" + Crewid + " " + + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ctx.setVar('patchCrewId', responseinfo);
											hm.response.statusCode = responseStatusCode;
											logger.debug(responseinfo);
											ilsCtx.setVariable('ExitStatus', '0');
											session.output.write(responseData);
										} else if (responseStatusCode == 400 || responseStatusCode == 404) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "Error from crewlocationapi call, details are : " + info + "; error info :" + error
													logger.error(errorinfo);
													session.reject(errorinfo);
												}
												else {
													var BusinessResponseData = responseData;
													var buff = Buffer.from(BusinessResponseData);
													var ResponseString = buff.toString();
													if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
														var errorinfo = "Error from crewlocationapi call, details are:" + info + responseData
													//	ilsCtx.setVariable('ExitStatus', responseStatusCode);
													//	ilsCtx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.output.write(incomingdata);
													} else {
														var errorinfo = "Error from crewlocationapi call, details are:" + info + "; response info : " + responseData
														ilsCtx.setVariable('ExitStatus', responseStatusCode);
														ilsCtx.setVariable('ExitDescription', errorinfo);
														var ctx = session.name('omsfoa') || session.createContext('omsfoa');
														ctx.setVariable('AvoidBackOut', 'yes');
													}
												}
											});
										}
										else if (responseStatusCode == 401 || responseStatusCode == 403) {
											// Handle business error responses (HTTP 401 or 403)
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													// Handle error in reading response data
													var errorinfo = "id=fior_up016: Error from crewlocationapi call, details are : " + info + "; error info :" + error;
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "id=fior_up016: " + responseData + " Error from crewlocationapi call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
													logger.error(errorinfo);
													session.reject(errorinfo);
												}
											});
										} else {
											var errorinfo = "Error from crewlocationapi for crewid, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											logger.error("id=fior_up18 : " + errorinfo);
											session.reject("id=fior_up18 : " + errorinfo);
										}
									}
								});

							}
						});
					} catch (err) {
						var errorinfo = "url connection error 'crewlocationapi', details are : " + info + "; error info :" + err
						ctx.setVar('patchCrewId', errorinfo);
						logger.error("id=fior_up17 : " + errorinfo);
						session.reject("id=fior_up17 : " + errorinfo);
						//	throw Error("id=fior_up17 : " + errorinfo);
					}
				} else {
					logger.info("id=fior_up20|Crew Location is not passed in incoming data");
				}
			} else {
				logger.info("id=fior_up141|Crew id is not passed in incoming data");
				//throw Error("id=fior_up141|Crew id is not passed in incoming data");
			}
		}
	}

});
