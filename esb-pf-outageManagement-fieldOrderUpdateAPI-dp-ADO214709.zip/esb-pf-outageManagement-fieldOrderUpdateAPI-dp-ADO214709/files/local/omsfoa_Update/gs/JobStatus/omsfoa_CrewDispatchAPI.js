var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up22|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
		if (incomingdata.OMS_EFO_StatusChange.Task.TaskTypeCategory.Name == 'OMS') {
			if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name == "Dispatched") {
				logger.info("inside dispatch");
				fs.readAsXML('local:///omsfoa_Update/xml/mosfoa_EnvSpecificConfig.xml', function(error, envdetails) {
					if (error) {
						logger.error("id=fior_up23|error while reading the mosfoa_EnvSpecificConfig.xml file");
						throw error; // throw and stop processing
					} else {
						var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
						var g = ExternalRefID.split('_');
						var crewAssignmentId = g[1];
						///api/v1/ServiceType/{sid}/Crew/{id}
						var CrewId = incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.ID;
						var crewuri = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + crewAssignmentId;
						//	var TokenValue = envdetails.item(0).firstChild.nextSibling.nextSibling.nextSibling.textContent;

						var TokenValue = session.parameters.TokenValue;
						//crewapi call 

						var originalInternalId = ctx.getVariable('CrewInternalid');
						var crewAssignmentInternalID = ctx.getVariable('internalCrewId');
						if (originalInternalId !== crewAssignmentInternalID) {
							var crewInternaDispatchpayload = {
								crewID: originalInternalId
							};

							var crewAssignmentDispatchapi = {
								target: crewuri,
								sslClientProfile: 'mosfoa_ClientProfile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': TokenValue
								},
								data: crewInternaDispatchpayload
							};

							var info = " TargetURL :" + crewAssignmentDispatchapi.target + "; Method :" + crewAssignmentDispatchapi.method + "; Data :" + JSON.stringify(crewAssignmentDispatchapi.data) + ". ";
							try {
								urlopen.open(crewAssignmentDispatchapi, function(error, response) {
									if (error) {
										var errorinfo = "url connection error 'crewAssignmentDispatchapi', details are : " + info + "; error info :" + error
										ctx.setVariable('patchCrewDispatch_Error', errorinfo);
										logger.error("id=fior_up29 : " + errorinfo);
										session.reject("id=fior_up29 : " + errorinfo);
										//throw errorinfo;
									} else {
										ctx.setVariable('patchCrewDispatch_Response', response);
										var responseStatusCode = response.statusCode;
										var responseReasonPhrase = response.reasonPhrase;
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'crewAssignmentDispatchapi', details are : " + info + "; error info :" + error
												ctx.setVar('patchCrewDispatch_Error', errorinfo);
												logger.error("id=fior_up29 : " + errorinfo);
												session.reject("id=fior_up29 : " + errorinfo);
											} else {
												if (responseStatusCode == 200) {
													var responseinfo = "response received from crewAssignmentDispatchapi call : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ctx.setVar('patchCrewDispatch_ResponseData', responseinfo);
													hm.response.statusCode = responseStatusCode;
													ilsCtx.setVariable('ExitStatus', '0');
													logger.debug("id=fior_up30 : " + responseinfo);
													session.output.write(responseData);
												} else if (responseStatusCode == 400 || responseStatusCode == 404) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error from crewAssignmentDispatchapi call, details are : " + info + "; error info :" + error
															logger.error(errorinfo);
															session.reject(errorinfo);
														}
														else {
															var BusinessResponseData = responseData;
															var buff = Buffer.from(BusinessResponseData);
															var ResponseString = buff.toString();
															if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																var errorinfo = "error from crewAssignmentDispatchapi call, details are:" + info + "; response info :" + responseData
															//	ilsCtx.setVariable('ExitStatus', responseStatusCode);
															//	ilsCtx.setVariable('ExitDescription', errorinfo);
																logger.error(errorinfo);
																session.output.write(incomingdata);
															} else {
																var errorinfo = "error from crewAssignmentDispatchapi call, details are:" + info + "; response info : " + responseData
																ilsCtx.setVariable('ExitStatus', responseStatusCode);
																ilsCtx.setVariable('ExitDescription', errorinfo);
																var ctx = session.name('omsfoa') || session.createContext('omsfoa');
																ctx.setVariable('AvoidBackOut', 'yes');
															}
														}
													});
												} else if (responseStatusCode == 401 || responseStatusCode == 403) {
													// Handle business error responses (HTTP 401 or 403)
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															// Handle error in reading response data
															var errorinfo = "id=fior_up023: error from crewAssignmentDispatchapi call , details are : " + info + "; error info :" + error;
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															var errorinfo = "id=fior_up023: " + responseData + " error from crewAssignmentDispatchapi call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
															logger.error(errorinfo);
															session.reject(errorinfo);
														}
													});
												} else {
													var errorinfo = "failure in putting message to crewAssignmentDispatchapi with statusCode : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													logger.error("id=fior_up30 : " + errorinfo);
													session.reject("id=fior_up30 : " + errorinfo);
												}
											}
										});
									}
								});
							} catch (err) {
								var errorinfo = "url connection error with crewAssignmentDispatchapi, details are : " + info + "; error info :" + err
								ctx.setVariable('patchCrewDispatch_Error', errorinfo);
								logger.error("id=fior_up29 : " + errorinfo);
								session.reject("id=fior_up29 : " + errorinfo);
								//throw errorinfo;
							}
						} // end of if original and crewassignmentid
					}
				}); //end of reading xml file
			} // end of dispatched 
		} // end of oms
		}
	} //end of else
}); // end of session.input
