var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("id=fior_up31|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
		var estimatedRestorationTime = '';
		var estimatedResolutionTime = '';
		var estimatedCompletionTime = '';
		var estimatedArrivalTime = '';
		var customfields = {};
		var crewAssignmentpayload = {};
		if (incomingdata.OMS_EFO_StatusChange.Task.TaskTypeCategory.Name == 'OMS') {
			if (incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID !== undefined) {

				if (incomingdata.OMS_EFO_StatusChange.estimatedRestorationTime !== undefined && incomingdata.OMS_EFO_StatusChange.estimatedRestorationTime !== null) {
					estimatedRestorationTime = incomingdata.OMS_EFO_StatusChange.estimatedRestorationTime;
					customfields.Estimated_Restoration_Time = estimatedRestorationTime;
				}
				if (incomingdata.OMS_EFO_StatusChange.estimatedResolutionTime !== undefined && incomingdata.OMS_EFO_StatusChange.estimatedResolutionTime !== null) {
					estimatedResolutionTime = incomingdata.OMS_EFO_StatusChange.estimatedResolutionTime;
					customfields.Estimated_Resolution_Time = estimatedResolutionTime;
				}
				if (incomingdata.OMS_EFO_StatusChange.estimatedArrivalTime !== undefined && incomingdata.OMS_EFO_StatusChange.estimatedArrivalTime !== null) {
					estimatedArrivalTime = incomingdata.OMS_EFO_StatusChange.estimatedArrivalTime;
					crewAssignmentpayload.eta = estimatedArrivalTime;

				}
				if (incomingdata.OMS_EFO_StatusChange.estimatedCompletionTime !== undefined && incomingdata.OMS_EFO_StatusChange.estimatedCompletionTime !== null) {
					estimatedCompletionTime = incomingdata.OMS_EFO_StatusChange.estimatedCompletionTime;
					customfields.Estimated_Completion_Time = estimatedCompletionTime;
				}

				var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
				var g = ExternalRefID.split('_');
				var crewAssignmentId = g[1];
				//	var crewAssignmentId = incomingdata.OMS_EFO_StatusChange.Task.crewAssignmentId;
				/* var customfields = {
					"Estimated_Restoration_Time": estimatedRestorationTime,
					"Estimated_Resolution_Time": estimatedResolutionTime,
					"Estimated_Completion_Time": estimatedCompletionTime
				} */
				//var ctx = session.name('myContext') || session.createContext('myContext');
				ctx.setVariable('ETA', estimatedArrivalTime);
				ctx.setVariable('ECT', estimatedCompletionTime);
				ctx.setVariable('ERT', estimatedResolutionTime);
				ctx.setVariable('ERest', estimatedRestorationTime);

				var customFieldKeysLength = (Object.keys(customfields)).length;

				if (customFieldKeysLength > 0) {
					crewAssignmentpayload.customFieldValues = customfields;
				}
				/* var crewAssignmentpayload = {
					"eta": estimatedArrivalTime,
					"customFieldValues": customfields
				}; */

				/*  var req = {
					 "eta": "2011-08-11T19:43:37+0100",
					 "customFieldValuesExt": {
						 "estimatedRestorationTime": "2011-08-11T19:43:37+0100",
						 "estimatedResolutionTime": "2011-08-11T19:43:37+0100",
						 "estimatedCompletionTime": "2011-08-11T19:43:37+0100"
					 }
				 } */
				fs.readAsXML('local:///omsfoa_Update/xml/mosfoa_EnvSpecificConfig.xml', function(error, envdetails) {
					if (error) {
						logger.error("error while reading the mosfoa_EnvSpecificConfig.xml file");
						//var ctx = session.name('myContext') || session.createContext('myContext');
						ctx.setVariable("id=fior_up31|error while reading the mosfoa_EnvSpecificConfig.xml file");
						throw error; // throw and stop processing
					} else {

						//	console.error("CrewAssignmentId"+crewAssignmentId);
						// /api/ServiceType/{sid}/CrewAssignment/{id}
						var crewAssignmenturi = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + crewAssignmentId;
						//var TokenValue = envdetails.item(0).firstChild.nextSibling.nextSibling.nextSibling.textContent;
						//	var TokenValue = '5e18cd19ebeb0f0d4cc88ed5:fafb8842b44594cc0a75b698eb225139e140e4c561afbe5649da4e7f5ae7494a';
						var TokenValue = session.parameters.TokenValue;
						if ((Object.keys(crewAssignmentpayload)).length > 0) {
							var crewAssignmentapi = {
								target: crewAssignmenturi,
								sslClientProfile: 'mosfoa_ClientProfile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': TokenValue
								},
								data: crewAssignmentpayload
							};

							var info = " TargetURL :" + crewAssignmentapi.target + "; Method :" + crewAssignmentapi.method + "; Data :" + JSON.stringify(crewAssignmentapi.data) + ". ";
							try {
								urlopen.open(crewAssignmentapi, function(error, response) {
									if (error) {
										var errorinfo = "url connection error 'crewAssignmentapi', details are : " + info + "; error info :" + error
										ctx.setVar('patchCrewAssignmentID', errorinfo);
										logger.error("id=fior_up32 : " + errorinfo);
										session.reject("id=fior_up32 : " + errorinfo);
										//throw errorinfo;
									} else {
										ctx.setVar('patchCrewAssignmentID', response);
										// read response data
										// get the response status code
										var responseStatusCode = response.statusCode;
										var responseReasonPhrase = response.reasonPhrase;
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'crewAssignmentapi', details are : " + info + "; error info :" + error
												ctx.setVar('patchCrewAssignmentID', errorinfo);
												logger.error("id=fior_up33 : " + errorinfo);
												session.reject("id=fior_up33 : " + errorinfo);
											} else {
												if (responseStatusCode == 200) {
													var responseinfo = "response received from patchCrewAssignmentTimeapi for crewAssignmentId :  " + crewAssignmentId + "" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ctx.setVar('patchCrewAssignmentID', responseinfo);
													hm.response.statusCode = responseStatusCode;
													logger.debug(responseinfo);
													ilsCtx.setVariable('ExitStatus', '0');
													session.output.write(responseData);
												} else if (responseStatusCode == 400 || responseStatusCode == 404) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "Error response received from patchCrewAssignmentTimeapi for crewAssignmentId, details are : " + info + "; error info :" + error
															logger.error(errorinfo);
															session.reject(errorinfo);
														}
														else {
															var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
															if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																var errorinfo = "error response received from patchCrewAssignmentTimeapi for crewAssignmentId, details are:" + info + "; response info :" + responseData
															//ilsCtx.setVariable('ExitStatus', responseStatusCode);
															//	ilsCtx.setVariable('ExitDescription', errorinfo);
																logger.error(errorinfo);
																session.output.write(incomingdata);
															}else {
													var errorinfo = "error response received from patchCrewAssignmentTimeapi for crewAssignmentId, details are:" + info + "; response info : " + responseData
												ilsCtx.setVariable('ExitStatus', responseStatusCode);
												ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}
														}
													});
												}
												else if (responseStatusCode == 401 || responseStatusCode == 403) {
													// Handle business error responses (HTTP 401 or 403)
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															// Handle error in reading response data
															var errorinfo = "id=fior_up022: error response from 'patchCrewAssignmentTimeapi' , details are : " + info + "; error info :" + error;
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															var errorinfo = "id=fior_up022:" + responseData + " error response from 'patchCrewAssignmentTimeapi' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
															logger.error(errorinfo);
															session.reject(errorinfo);
														}
													});
												} else {
													var errorinfo = "error response from 'patchCrewAssignmentTimeapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													logger.error("id=fior_up34 : " + errorinfo);
													session.reject("id=fior_up34 : " + errorinfo);
												}
											}
										});
									}
								});
							} catch (err) {
								var errorinfo = "url connection error with patchCrewAssignmentTimeapi, details are : " + info + "; error info :" + err
								ctx.setVar('patchCrewAssignmentID', errorinfo);
								logger.error("id=fior_up32 : " + errorinfo);
								session.reject("id=fior_up32 : " + errorinfo);
								//throw errorinfo;
							}
						}
					}
				});
			} else {
				// storing in custom logging dp
				logger.error("crewAssignmentapi is not passed in incoming data");
			}
		}
		}
	}
});
