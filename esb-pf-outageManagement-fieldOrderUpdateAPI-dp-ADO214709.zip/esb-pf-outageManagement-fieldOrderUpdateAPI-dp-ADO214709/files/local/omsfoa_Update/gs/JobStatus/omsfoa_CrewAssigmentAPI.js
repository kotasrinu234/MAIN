var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});

var EngineersID = '';
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up15|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
var avoidcall = ctx.getVariable("AvoidBackOut");
		if (avoidcall != 'yes') {
		if (incomingdata.OMS_EFO_StatusChange.Task.TaskTypeCategory.Name == 'OMS') {
			if (incomingdata.OMS_EFO_StatusChange.Assignment !== undefined) {
				if (incomingdata.OMS_EFO_StatusChange.Assignment.Engineers !== undefined) {
					if (incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.crewID !== undefined) {
						EngineersID = incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.crewID;
						ctx.setVariable("CAEngineersID", EngineersID);
					}

				}
			}
			if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name == "Ready to Assign") {

				var crewpayload = {
					crewID: ""
				}

				fs.readAsXML('local:///omsfoa_Update/xml/mosfoa_EnvSpecificConfig.xml', function(error, envdetails) {
					if (error) {
						logger.error("error while reading the mosfoa_EnvSpecificConfig.xml file");
						throw error; // throw and stop processing
					} else {

						var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
						var g = ExternalRefID.split('_');
						var crewAssignmentId = g[1];
						var omsjobid = g[2];
						//var crewAssignmentId = incomingdata.OMS_EFO_StatusChange.Task.crewAssignmentId;
						var crewAssignmenturi = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + crewAssignmentId;
						//var TokenValue = envdetails.item(0).firstChild.nextSibling.nextSibling.nextSibling.textContent;
						var TokenValue = session.parameters.TokenValue;

						//new changes for crew unassigned
						var getcrewAssignmentIdDetails = {
							target: crewAssignmenturi,
							sslClientProfile: 'mosfoa_ClientProfile',
							method: 'GET',
							contentType: 'application/json',
							headers: {
								'osiApiToken': TokenValue
							}
						};
						var info = " TargetURL :" + getcrewAssignmentIdDetails.target + "; Method :" + getcrewAssignmentIdDetails.method + ". ";
						try {
							urlopen.open(getcrewAssignmentIdDetails, function(error, response) {
								if (error) {
									var errorinfo = "url connection error 'getcrewAssignmentIdDetails', details are : " + info + "; error info :" + error
									ctx.setVar('getCrewAssignmentId_ExternalId', errorinfo);
									logger.error("id=fior_up27 : " + errorinfo);
									session.reject("id=fior_up27 : " + errorinfo);
									//	throw errorinfo;
								} else {
									ctx.setVar('getCrewAssignmentId_ExternalId', response);
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'getcrewAssignmentIdDetails', details are : " + info + "; error info :" + error
												ctx.setVar('getCrewAssignmentId_ExternalId', errorinfo);
												logger.error("id=fior_up128 : " + errorinfo);
												session.reject("id=fior_up128 : " + errorinfo);
											} else {
												ctx.setVar('getCrewAssignmentId_ExternalId', responseData);
												hm.response.statusCode = responseStatusCode;
												var externalCrewId = '';
												if (responseData.crew !== undefined && responseData.crew.externalID !== undefined) {
													externalCrewId = responseData.crew.externalID;
												}
												ctx.setVar('externalCrewId', externalCrewId);
												ilsCtx.setVariable('ExitStatus', '0');
												logger.debug("id=fior_up129|response received from getcrewAssignmentapi call:" + responseData);
												session.output.write(responseData);
											} //else of responsedata
										});
									}
									else if (responseStatusCode == 400 || responseStatusCode == 404) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error from getcrewAssignmentIdDetails call, details are : " + info + "; error info :" + error
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
											else {
												var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
												if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
													var errorinfo = "error from getcrewAssignmentIdDetails call, details are:" + info + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													session.output.write(incomingdata);
												}else {
													var errorinfo = "error from getcrewAssignmentIdDetails call, details are:" + info + "; response info : " + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}
											}
										});
									}
									else {
										if (responseStatusCode == 401 || responseStatusCode == 403) {
											// Handle business error responses (HTTP 401 or 403)
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													// Handle error in reading response data
													var errorinfo = "id=fior_up017: error from getcrewAssignmentIdDetails call , details are : " + info + "; error info :" + error;
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "id=fior_up017: " + responseData + " error from getcrewAssignmentIdDetails call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
													logger.error(errorinfo);
													session.reject(errorinfo);
												}
											});
										}
									}
								} //end of else urlopen														

							});
						} catch (err) {
							var errorinfo = "url connection error 'getcrewAssignmentIdDetails', details are : " + info + "; error info :" + err
							ctx.setVar('getCrewAssignmentId_ExternalId', errorinfo);
							logger.error("id=fior_up27 : " + errorinfo);
							session.reject("id=fior_up27 : " + errorinfo);
							//throw errorinfo;
						}
						//new changes end for crew unassigned

						var crewlocationapi = {
							target: crewAssignmenturi,
							sslClientProfile: 'mosfoa_ClientProfile',
							method: 'PATCH',
							contentType: 'application/json',
							headers: {
								'osiApiToken': TokenValue
							},
							data: crewpayload
						};

						var info = " TargetURL :" + crewlocationapi.target + "; Method :" + crewlocationapi.method + "; Data :" + JSON.stringify(crewlocationapi.data) + ". ";
						try {
							urlopen.open(crewlocationapi, function(error, response) {
								if (error) {
									var errorinfo = "url connection error 'crewlocationapi', details are : " + info + "; error info :" + error
									ctx.setVar('patchCrewAssignmentID_location', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
									//throw errorinfo;
								} else {
									ctx.setVar('patchCrewAssignmentID_location', response);
									// checking for url open response code for CrewAssignment api call, 200 and 404 accpeted ,rest rejected 								
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'crewlocationapi', details are : " + info + "; error info :" + error
												ctx.setVar('patchCrewAssignmentID_location', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												ctx.setVar('patchCrewAssignmentID_location', responseData);
												// response code 200 or 400 here
												hm.response.statusCode = responseStatusCode;
												hm.response.statusCode = responseStatusCode;
												ilsCtx.setVariable('ExitStatus', '0');
												logger.debug("response received from crewAssignment" + crewAssignmentId + " response:" + responseData);
												session.output.write(responseData);

												//adding comments call

												var externalCrewId = ctx.getVariable('externalCrewId');
												var customcomment = "CREW " + externalCrewId + " UNASSIGNED";
												var crewComments = {
													comment: customcomment
												};

												var omsjoburi = session.parameters.OMS + '/api/ServiceType/Electric/Job/' + omsjobid + '/Comment';

												var TokenValue = session.parameters.TokenValue;

												var omsJobapi = {
													target: omsjoburi,
													sslClientProfile: 'mosfoa_ClientProfile',
													method: 'POST',
													contentType: 'application/json',
													headers: {
														'osiApiToken': TokenValue
													},
													data: crewComments
												};

												if (externalCrewId != '') {
													var info = " TargetURL :" + omsJobapi.target + "; Method :" + omsJobapi.method + "; Data :" + JSON.stringify(omsJobapi.data) + ". ";
													try {
														urlopen.open(omsJobapi, function(error, response) {
															if (error) {
																var errorinfo = "url connection error 'omsJobapi', details are : " + info + "; error info :" + error
																ctx.setVar('crew_comments', errorinfo);
																logger.error("id=fior_up37 : " + errorinfo);
																session.reject("id=fior_up37 : " + errorinfo);
																//throw errorinfo;
															} else {
																ctx.setVar('crew_comments', response);
																// read response data
																// get the response status code
																var responseStatusCode = response.statusCode;
																if (responseStatusCode == 200) {
																	response.readAsJSON(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'omsJobapi', details are : " + info + "; error info :" + error
																			ctx.setVar('crew_comments', errorinfo);
																			logger.error("id=fior_up38 : " + errorinfo);
																			session.reject("id=fior_up38 : " + errorinfo);
																		} else {
																			ctx.setVar('crew_comments', responseData);
																			hm.response.statusCode = responseStatusCode;
																			hm.response.statusCode = responseStatusCode;
																			ilsCtx.setVariable('ExitStatus', '0');
																			logger.debug("response received from omsJobapi for omsjobid:" + omsjobid + " " + responseStatusCode);
																			session.output.write(responseData);
																		}
																	});
																} else if (responseStatusCode == 400 || responseStatusCode == 404) {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'omsJobapi', details are : " + info + "; error info :" + error
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}
																		else {
																			var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
																			if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																				var errorinfo = "error reading response 'omsJobapi', details are:" + info + responseData
																				ilsCtx.setVariable('ExitStatus', responseStatusCode);
																				ilsCtx.setVariable('ExitDescription', errorinfo);
																				logger.error(errorinfo);
																				session.output.write(incomingdata);
																			}else {
													var errorinfo = "error reading response 'omsJobapi', details are:" + info + "; response info : " + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}
																		}
																	});
																}
																else if (responseStatusCode == 401 || responseStatusCode == 403) {
																	// Handle business error responses (HTTP 401 or 403)
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			// Handle error in reading response data
																			var errorinfo = "id=fior_up019: error response 'omsJobapi for omsjobid' , details are : " + info + "; error info :" + error;
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var errorinfo = "id=fior_up019:" + responseData + " error response 'omsJobapi for omsjobid' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}
																	});
																} else {
																	var errorinfo = "error response 'omsJobapi for omsjobid', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	logger.error("id=fior_up139 : " + errorinfo);
																	session.reject("id=fior_up139 : " + errorinfo);
																	//throw Error("id=fior_up139 : " + errorinfo);
																}
															}
														});
													} catch (err) {
														var errorinfo = "url connection error 'omsJobapi', details are : " + info + "; error info :" + err
														ctx.setVar('crew_comments', errorinfo);
														logger.error("id=fior_up37 : " + errorinfo);
														session.reject("id=fior_up37 : " + errorinfo);
														//throw errorinfo;
													}
												}
												//end-adding comments call

											}
										});
									}
									else if (responseStatusCode == 400 || responseStatusCode == 404) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "Error from crewAssignmentapi, details are : " + info + "; error info :" + error
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
											else {
												var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
												if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
													var errorinfo = "Error from crewAssignmentapi, details are:" + info + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													session.output.write(incomingdata);
												}else {
													var errorinfo = "Error from crewAssignmentapi, details are:" + info + "; response info : " + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}
											}
										});
									}
									else if (responseStatusCode == 401 || responseStatusCode == 403) {
										// Handle business error responses (HTTP 401 or 403)
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												// Handle error in reading response data
												var errorinfo = "id=fior_up018: Error from crewAssignmentapi , details are : " + info + "; error info :" + error;
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "id=fior_up018: " + responseData + " Error from crewAssignmentapi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});
									} else {
										response.readAsBuffer(function(error, responseData) {
											/*// crewassignment api reponse other than 200 and 404 
												logger.error("Error from crewAssignmentapi for Name: Ready To Assign  for crewassigmentid: "+crewAssignmentId+" with statusCode" + responseStatusCode);
												//throw Error("Error returned from crewAssignmentapi with statusCode " + responseStatusCode);							
												session.reject("Error returned from crewAssignmentapi with statusCode "+crewAssignmentId+" with statusCode" + responseStatusCode);*/
											if (error) {
												var errorinfo = "Error from crewAssignmentapi for Name: Ready To Assign  for crewassigmentid, details are : " + info + "; error info :" + error
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "Error from crewAssignmentapi for Name: Ready To Assign  for crewassigmentid, details are : " + crewAssignmentId + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});

									}
								}
							});
						} catch (err) {
							var errorinfo = "url connection error 'crewlocationapi', details are : " + info + "; error info :" + err
							ctx.setVar('patchCrewAssignmentID_location', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
							//throw errorinfo;
						}
					}
				});

			} // end of Read to assign api part
			else if (incomingdata.OMS_EFO_StatusChange.Task.Status.Name == "Dispatched") {
				logger.info("inside dispatch");
				fs.readAsXML('local:///omsfoa_Update/xml/mosfoa_EnvSpecificConfig.xml', function(error, envdetails) {
					if (error) {
						logger.error("id=fior_up23|error while reading the mosfoa_EnvSpecificConfig.xml file");
						throw error; // throw and stop processing
					} else {
						var ExternalRefID = incomingdata.OMS_EFO_StatusChange.Task.ExternalRefID;
						var g = ExternalRefID.split('_');
						var crewAssignmentId = g[1];
						///api/v1/ServiceType/{sid}/Crew/{id}
						var CrewId = EngineersID;
						var crewuri = session.parameters.OMS + '/api/ServiceType/Electric/Crew/' + EngineersID;
						//var TokenValue = envdetails.item(0).firstChild.nextSibling.nextSibling.nextSibling.textContent;
						var TokenValue = session.parameters.TokenValue;
						//crewapi call 
						var crewlocationapi = {
							target: crewuri,
							sslClientProfile: 'mosfoa_ClientProfile',
							method: 'GET',
							contentType: 'application/json',
							headers: {
								'osiApiToken': TokenValue
							}
						};

						var info = " TargetURL :" + crewlocationapi.target + "; Method :" + crewlocationapi.method + ". ";
						try {
							urlopen.open(crewlocationapi, function(error, response) {
								if (error) {
									var errorinfo = "url connection error 'getcrewlocationapi', details are : " + info + "; error info :" + error
									ctx.setVar('getCrewID', error);
									logger.error("id=fior_up24 : " + errorinfo);
									session.reject("id=fior_up24 : " + errorinfo);
									//throw errorinfo;
								} else {
									ctx.setVariable('getCrewID', response);
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										logger.debug("id=fior_up25|response received from crewapi for crewid:" + CrewId + "is " + responseStatusCode);
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'getcrewlocationapi', details are : " + info + "; error info :" + error
												ctx.setVariable('getCrewID', errorinfo);
												logger.error("id=fior_up26 : " + errorinfo);
												session.reject("id=fior_up26 : " + errorinfo);
											} else {
												ctx.setVariable('getCrewID', responseData.id);
												hm.response.statusCode = responseStatusCode;
												ilsCtx.setVariable('ExitStatus', '0');
												//var CrewCallReponse= responseData;

												//session.output.write(responseData);

												//calling patch operation CrewAssignment API
												//ctx.setVar('CrewCallReponse',CrewCallReponse.id);
												var CrewInternalid = responseData.id;
												ctx.setVariable('CrewInternalid', responseData.id);

												logger.debug("id++" + CrewInternalid);
												//var crewuri = envdetails.item(0).firstChild.nextSibling.textContent + '/api/ServiceType/Electric/CrewAssignment/' +crewAssignmentId;


												var crewuri = session.parameters.OMS + '/api/ServiceType/Electric/CrewAssignment/' + crewAssignmentId;
												//var externalid = incomingdata.OMS_EFO_StatusChange.Assignment.Engineers.ID;
												/* var crewInternaDispatchpayload = {
													crewID: CrewInternalid
												}; */

												//new changes
												var crewAssignmentIdDetails = {
													target: crewuri,
													sslClientProfile: 'mosfoa_ClientProfile',
													method: 'GET',
													contentType: 'application/json',
													headers: {
														'osiApiToken': TokenValue
													}
												};
												var info = " TargetURL :" + crewAssignmentIdDetails.target + "; Method :" + crewAssignmentIdDetails.method + ". ";

												try {
													urlopen.open(crewAssignmentIdDetails, function(error, response) {
														if (error) {
															var errorinfo = "url connection error 'crewAssignmentDispatchapi', details are : " + info + "; error info :" + error
															ctx.setVar('getCrewAssignmentId_InternalId', errorinfo);
															logger.error("id=fior_up27 : " + errorinfo);
															session.reject("id=fior_up27 : " + errorinfo);
															//throw errorinfo;
														} else {
															ctx.setVar('getCrewAssignmentId_InternalId', response);
															var responseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																response.readAsJSON(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'crewAssignmentapi', details are : " + info + "; error info :" + error
																		ctx.setVar('getCrewAssignmentId_InternalId', errorinfo);
																		logger.error("id=fior_up28: " + errorinfo);
																		session.reject("id=fior_up28 : " + errorinfo);
																	} else {
																		ctx.setVar('getCrewAssignmentId_InternalId', responseData);
																		hm.response.statusCode = responseStatusCode;
																		var internalCrewId = '';
																		if (responseData.crew !== undefined) {
																			internalCrewId = responseData.crew.id;
																		}
																		ctx.setVar('internalCrewId', internalCrewId);
																		logger.debug("id=fior_up29|response received from crewAssignmentapi call:" + responseData);
																		ilsCtx.setVariable('ExitStatus', '0');
																		session.output.write(responseData);
																	} //else of responsedata
																});
															} else if (responseStatusCode == 400 || responseStatusCode == 404) {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'getCrewAssignmentId_InternalIdApi', details are : " + info + "; error info :" + error
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																	else {
																		var BusinessResponseData = responseData;
																		var buff = Buffer.from(BusinessResponseData);
																		var ResponseString = buff.toString();
																		if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
																			var errorinfo = "error reading response 'getCrewAssignmentId_InternalIdApi', details are:" + info + responseData
																			ilsCtx.setVariable('ExitStatus', responseStatusCode);
																			ilsCtx.setVariable('ExitDescription', errorinfo);
																			logger.error(errorinfo);
																			session.output.write(incomingdata);
																		}else {
													var errorinfo = "error reading response 'getCrewAssignmentId_InternalIdApi', details are:" + info + "; response info : " + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}
																	}
																});
															}
															else if (responseStatusCode == 401 || responseStatusCode == 403) {
																// Handle business error responses (HTTP 401 or 403)
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		// Handle error in reading response data
																		var errorinfo = "id=fior_up021: error reading response 'getCrewAssignmentId_InternalIdApi', details are : " + info + "; error info :" + error;
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = "id=fior_up021: " + responseData + " error reading response 'getCrewAssignmentId_InternalIdApi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																});
															} else {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'getCrewAssignmentId_InternalIdApi', details are : " + info + "; error info :" + error
																		logger.error("id=fior_up29 : " + errorinfo);
																		session.reject("id=fior_up29 : " + errorinfo);
																	} else {
																		var errorinfo = "error response 'getCrewAssignmentId_InternalIdApi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		logger.error("id=fior_up29 : " + errorinfo);
																		session.reject("id=fior_up29 : " + errorinfo);
																	}
																});
															}
														} //end of else urlopen														

													});
												} catch (err) {
													var errorinfo = "error reading response 'crewAssignmentDispatchapi', details are : " + info + "; error info :" + error
													ctx.setVar('getCrewAssignmentId_InternalId', errorinfo);
													logger.error("id=fior_up27 : " + errorinfo);
													session.reject("id=fior_up27 : " + errorinfo);
													//throw errorinfo;
												}

												// end of if original and crewassignmentid
											} //end of else
										}); //end of read as json
									}
									else if (responseStatusCode == 400 || responseStatusCode == 404) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'getcrewapi', details are : " + info + "; error info :" + error
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
											else {
												var BusinessResponseData = responseData;
												var buff = Buffer.from(BusinessResponseData);
												var ResponseString = buff.toString();
												if ((ResponseString == 'No updates') || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
													var errorinfo = "error reading response 'getcrewapi', details are:" + info + responseData
												//	ilsCtx.setVariable('ExitStatus', responseStatusCode);
												//	ilsCtx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													session.output.write(incomingdata);
												} else {
													var errorinfo = "error reading response 'getcrewapi', details are:" + info + "; response info : " + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}
											}
										});
									}
									else if (responseStatusCode == 401 || responseStatusCode == 403) {
										// Handle business error responses (HTTP 401 or 403)
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												// Handle error in reading response data
												var errorinfo = "id=fior_up020:error reading response 'getcrewapi', details are : " + info + "; error info :" + error;
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "id=fior_up020: " + responseData + " error reading response 'getcrewapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});
									} else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'getcrewapi', details are : " + info + "; error info :" + error
												logger.error("id=fior_up30 : " + errorinfo);
												session.reject("id=fior_up30 : " + errorinfo);
											} else {
												var errorinfo = "error response 'getcrewapi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												logger.error("id=fior_up30 : " + errorinfo);
												session.reject("id=fior_up30 : " + errorinfo);
											}
										});
									}

								} //end of else

							});
						} catch (err) {
							var errorinfo = "url connection error getcrewapi, details are : " + info + "; error info :" + err
							ctx.setVar(errorinfo);
							// an error occurred during request sending or response header parsing
							logger.error("id=fior_up24 : " + errorinfo);
							session.reject("id=fior_up24 : " + errorinfo);
							//throw errorinfo;
						}//end of url open
					} //end of else dispatched
				});
			} // end of dispatched
		} //end of oms
		}
	} //end of else
}); //end of function
