var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var callMQURL = require('./callMQURL.js');
var eventHubQM = session.parameters.eventHubQM;
var eventHubReqQ = session.parameters.eventHubReqQ;
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});

/*function uuidv4() {return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
return v.toString(16);});}*/

var reqType = ctx.getVariable('reqType');
if (reqType === 'update' || reqType === 'completion' || reqType === 'crewLeader') {

	session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			logger.error("id=fior_up15|Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {

			var ehreq = ctx.getVariable("eventHubReqmsg");

			var date = new Date();
			//var myuuid =uuidv4();	

			var outReq = {};
			outReq.messageId = ehreq.messageId;
			outReq.eventType = ehreq.eventType;
			outReq.eventContext = ehreq.eventContext;
			outReq.serviceName = 'workOrderEFOUpdate';
			outReq.EventTimeStamp = ehreq.EventTimeStamp;
			outReq.sendTimeStamp = date.toISOString();
			outReq.confirmation = 'Y';
			//outReq.workFlowType = ehreq.workFlowType;
			//outReq.workFlowRequirementEvent = ehreq.workFlowRequirementEvent;
			//outReq.eventKey = ehreq.eventKey;

			if (ehreq.workFlowType !== undefined && ehreq.workFlowType !== null && ehreq.workFlowType !== '') {
				outReq.workFlowType = ehreq.workFlowType;
			}
			if (ehreq.workFlowRequirementEvent !== undefined && ehreq.workFlowRequirementEvent !== null && ehreq.workFlowRequirementEvent !== '') {
				outReq.workFlowRequirementEvent = ehreq.workFlowRequirementEvent;
			}
			if (ehreq.eventKey !== undefined && ehreq.eventKey !== null && ehreq.eventKey !== '') {
				outReq.eventKey = ehreq.eventKey;
			}



			if (ehreq.crewAssignmentID !== undefined && ehreq.crewAssignmentID !== null && ehreq.crewAssignmentID !== '') {
				outReq.crewAssignmentID = ehreq.crewAssignmentID;
			}
			if (ehreq.crewAssignmentDisplayID !== undefined && ehreq.crewAssignmentDisplayID !== null && ehreq.crewAssignmentDisplayID !== '') {
				outReq.crewAssignmentDisplayID = ehreq.crewAssignmentDisplayID;
			}
			if (ehreq.jobID !== undefined && ehreq.jobID !== null && ehreq.jobID !== '') {
				outReq.jobID = ehreq.jobID;
			}
			if (ehreq.jobDisplayID !== undefined && ehreq.jobDisplayID !== null && ehreq.jobDisplayID !== '') {
				outReq.jobDisplayID = ehreq.jobDisplayID;
			}
			if (ehreq.messageType !== undefined && ehreq.messageType !== null && ehreq.messageType !== '') {
				outReq.messageType = ehreq.messageType;
			}

			ctx.setVariable('outReq', outReq);
			ctx.setVariable('SeqConfirm', 'SeqConfirm');
			var urlopenurl = 'dpmq://' + eventHubQM + '/?RequestQueue=' + eventHubReqQ;
			callMQURL(urlopenurl, reqType, 'Seq_ConfMQ', outReq);

		} //end of else

	}); //end of function
}
