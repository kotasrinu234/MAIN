var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');

function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
var reqType = '';
var root = '';


session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		incomingdata = ctx.getVariable('decodedRequest');
		//logger.error("incomingdata",JSON.stringify(incomingdata));
		if (incomingdata.OMS_EFO_StatusChange) {
			root = incomingdata.OMS_EFO_StatusChange;
			reqType = 'update';

		} else if (incomingdata.EFO_Completion_OMSCompletion) {
			root = incomingdata.EFO_Completion_OMSCompletion;
			reqType = 'completion';

		} else if (incomingdata.OMS_TaskUpdate) {
			root = incomingdata.OMS_TaskUpdate;
			reqType = 'crewLeader';

		}
		//logger.error("root.Task",JSON.stringify(root.Task));
		var externalRefID = root.Task.ExternalRefID;
		var g = externalRefID.split('_');
		//var myuuid =uuidv4();	


		var correlationID = ctx.getVariable('messageId');

		var messageType = reqType + "Event";
		//var interfaceName = session.parameters.interfaceName;

		var messageID = root.MessageID;
		var crewAssignmentID = g[1];
		var crewAssignmentDisplayID;
		var jobDisplayID;

		if (messageType === "crewLeaderEvent" || messageType === "completionEvent") {
			var callId = '';
			if (root.Task.CallID !== undefined) {
				callId = root.Task.CallID;
				var c = callId.split('_');
				crewAssignmentDisplayID = c[3];
				jobDisplayID = c[2];
			}
		} else {
			var o;
			var ilsJobId = '';
			if (root.Task.omsJobId !== undefined) {
				ilsJobId = root.Task.omsJobId;
				o = ilsJobId.split('_');
				crewAssignmentDisplayID = o[1];
				jobDisplayID = o[0];
			}
		}
		var jobID = g[2];
		var crewDisplayID = '';
		var assignmentStatus = '';
		if (messageType === "crewLeaderEvent") {
			if (root.Task.AssignedEngineer !== undefined) {
				crewDisplayID = root.Task.AssignedEngineer.PSCrewID;
			}
		}
		if (messageType === "updateEvent") {
			if (root.Assignment !== undefined && root.Assignment.Engineers !== undefined) {
				crewDisplayID = root.Assignment.Engineers.crewID;
			}
			assignmentStatus = root.Task.Status.Name;
		}
		if (messageType === "completionEvent") {

			if (root.Assignment !== undefined && root.Assignment.Engineers !== undefined) {
				crewDisplayID = root.Assignment.Engineers[0].PSCrewID;
			}
			assignmentStatus = root.Task.Status.Name;
		}
		var sourceEventTimestamp;
		if (root.OMSsequenceTimeStamp) {
			sourceEventTimestamp = root.OMSsequenceTimeStamp;
		} else if (root.Task.Stamp && root.Task.Stamp.TimeModified) {
			sourceEventTimestamp = root.Task.Stamp.TimeModified;
		} else if (root.Task.Stamp && root.Task.Stamp.TimeCreated) {
			sourceEventTimestamp = root.Task.Stamp.TimeCreated;
		} else {
			sourceEventTimestamp = "TIME STAMP NOT IN PAYLOAD";
		}
		var sourceUrl = sm.getVar('var://service/URL-in');
		var entryDescription = session.parameters.UpdateEntryDescription;
		var exitDescription = session.parameters.UpdateExitDescription;
		var exitDestination = session.parameters.OMS;

		if (correlationID !== undefined) {
			ilsCtx.setVariable('correlationID', correlationID);
		}
		if (messageType !== undefined) {
			ilsCtx.setVariable('messageType', messageType);
		}
		if (messageID !== undefined) {
			ilsCtx.setVariable('messageID', messageID);
		}
		if (crewAssignmentID !== undefined) {
			ilsCtx.setVariable('crewAssignmentID', crewAssignmentID);
		}
		if (crewAssignmentDisplayID !== undefined) {
			ilsCtx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID);
		}
		if (jobDisplayID !== undefined) {
			ilsCtx.setVariable('jobDisplayID', jobDisplayID);
		}
		if (jobID !== undefined) {
			ilsCtx.setVariable('jobID', jobID);
		}
		if (crewDisplayID !== undefined) {
			ilsCtx.setVariable('crewDisplayID', crewDisplayID);
		}
		if (assignmentStatus !== undefined) {
			ilsCtx.setVariable('assignmentStatus', assignmentStatus);
		}
		if (sourceEventTimestamp !== undefined) {
			ilsCtx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
		}
		if (sourceUrl !== undefined) {
			ilsCtx.setVariable('sourceUrl', sourceUrl);
		}
		if (entryDescription !== undefined) {
			ilsCtx.setVariable('EntryDescription', entryDescription);
		}
		if (exitDescription !== undefined) {
			ilsCtx.setVariable('ExitDescription', exitDescription);
		}
		if (exitDestination !== undefined) {
			ilsCtx.setVariable('ExitDestination', exitDestination);
		}
	}
});
