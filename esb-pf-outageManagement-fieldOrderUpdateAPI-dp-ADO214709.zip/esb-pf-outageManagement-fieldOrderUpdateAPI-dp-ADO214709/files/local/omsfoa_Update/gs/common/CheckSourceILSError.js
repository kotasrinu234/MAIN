var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsCtx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var reqType = '';
var root = '';
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var seqCheck = ctx.getVariable('SeqConfirm');
		var imgCheck = ctx.getVariable('ImageUpload');

		if (seqCheck) {
			ilsCtx.setVariable('messageType', 'seqConfirmationEvent');
		} else if (imgCheck) {
			ilsCtx.setVariable('messageType', 'ImageUploadEvent');
		}
	}
});
