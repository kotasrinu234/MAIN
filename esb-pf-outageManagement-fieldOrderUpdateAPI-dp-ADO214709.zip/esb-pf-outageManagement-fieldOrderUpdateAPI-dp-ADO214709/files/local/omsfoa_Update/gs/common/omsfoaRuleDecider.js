var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;

var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});
var ruleType ='';
var reqType=ctx.getVariable('reqType');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up15|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		

 if (reqType ==='update'){
	 ruleType ='omsfoa_UPdate_Processing_Policy_Request_rule';
	 
 }else if (reqType === 'completion'){
	  ruleType ='omsfoa_UPdate_Form_Processing_Policy_Request_Rule';
 }else if(reqType === 'crewLeader'){
	  ruleType ='omsfoa_UPdate_crewLeader_Request_Rule';
 }else{
	  ruleType ='omsfoa_UPdate_Processing_NonEFO_CrewUpdate_Request_Rule';
 }
 
ctx.setVariable('ruleType',ruleType);

	} //end of else

}); //end of function


