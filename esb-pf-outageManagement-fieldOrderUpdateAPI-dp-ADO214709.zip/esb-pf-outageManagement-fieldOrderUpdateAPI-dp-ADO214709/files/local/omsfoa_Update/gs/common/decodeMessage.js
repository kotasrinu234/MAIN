var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;

var ctx = session.name('omsfoa') || session.createContext('omsfoa');
var logger = console.options({
	'category': 'all'
});

var reqType='';

/* var json_mqrfh2 = headers.get({type: 'mq'},'MQRFH2');

if(json_mqrfh2 !== undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue !=undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr !=undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.triggerValue !=undefined){
 reqType= json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.triggerValue.$;
}
ctx.setVariable("reqType",reqType);

if (reqType === 'update' || reqType === 'completion'  ){ */

var base64EncodedString ='';

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("id=fior_up15|Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var base64EncodedString = incomingdata.payload;
		
		if ((incomingdata.eventType !==undefined) && (incomingdata.eventType !==null)){
			reqType = incomingdata.eventType;
		ctx.setVariable("eventHubReqmsg", incomingdata);
		ctx.setVariable("messageId", incomingdata.messageId);

		
		 


var decodedRequest = JSON.parse(new Buffer.from(base64EncodedString, 'base64').toString());
ctx.setVariable('decodedRequest',decodedRequest);
session.output.write(decodedRequest);
}else {reqType = '';
		
       session.output.write(incomingdata);
} ctx.setVariable("reqType", reqType);
			
	} //end of else

}); //end of function
//}

