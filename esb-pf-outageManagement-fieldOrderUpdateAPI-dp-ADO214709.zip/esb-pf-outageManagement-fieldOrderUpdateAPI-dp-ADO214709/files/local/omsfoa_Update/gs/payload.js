session.input.readAsBuffer(function (error, buffer) {
    if (error) {
        session.reject("Unexpected error in readAsJSON(): " + error);
        return;
    }

    var ctx = session.name('myContext') || session.createContext('myContext');
    ctx.setVar("inputData", buffer.toString());

console.log('buffer json', buffer.toString());
});