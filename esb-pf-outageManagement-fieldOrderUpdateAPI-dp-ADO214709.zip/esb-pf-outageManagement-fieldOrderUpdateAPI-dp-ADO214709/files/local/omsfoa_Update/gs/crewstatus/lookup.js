var urlopen = require('urlopen');
var ctx = session.name('nonefo') || session.createContext('nonefo');
var logger = console.options({
	'category': 'all'
});

//reading input request json
var json = ctx.getVariable('inputRequest');
var ctx = session.name('nonefo') || session.createContext('nonefo');
var lookupURL = session.parameters.lookupurl;
var crewType = session.parameters.crewType;

//creating request for lookup service
var request = {};
request.type = new Array();

//creating request for aors
var obj = {};
obj.name = "aors";
obj.label = "DTE";
request.type.push(obj);

//creating request for crewTypes
obj = {};
obj.name = "crewTypes";
obj.label = crewType;
request.type.push(obj);

// urlopen parameters 
var options = {
	target: lookupURL,
	method: 'POST',
	contentType: 'application/json',
	data: {
		"lookupReq": request
	}
};

// open connection to target
var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
try {
	urlopen.open(options, function(error, response) {
		var ctx = session.name('nonefo') || session.createContext('nonefo');
		if (error) {
			// an error occurred during reading the file
			var errorinfo = "url connection error 'lookupURL', details are : " + info + "; error info :" + error
			logger.error("id=fior_up04 : " + errorinfo);
			session.reject("id=fior_up04 : " + errorinfo);
			//throw errorinfo;
		} else {
			var responseStatusCode = response.statusCode;
			var responseReasonPhrase = response.reasonPhrase;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					var ctx = session.name('nonefo') || session.createContext('nonefo');
					ctx.setVariable('lookupResponseData', responseData);
					if (error) {
						var errorinfo = "error reading response 'lookupURL', details are : " + info + "; error info :" + error
						logger.error("id=fior_up05 : " + errorinfo);
						session.reject("id=fior_up05 : " + errorinfo);
						//throw errorinfo;
					} else {
						logger.info("success lookup response received");
						var aorIDs = new Array();
						aorIDs.push(responseData.lookupRep.type[0].id);
						ctx.setVariable('aorIDs', aorIDs);
						var crewTypeLookupStatus = responseData.lookupRep.type[1].status;
						ctx.setVariable('crewTypeLookupStatus', crewTypeLookupStatus);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response 'lookupURL', details are : " + info + "; error info :" + error
						logger.error("id=fior_up06 :  " + responseStatusCode + " " + errorinfo);
						session.reject("id=fior_up06 :  " + responseStatusCode + " " + errorinfo);
					} else {
						var errorinfo = "error response 'lookupURL', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						logger.error("id=fior_up06 :  " + errorinfo);
						session.reject("id=fior_up06 :  " + errorinfo);
					}
				});
			}
		}
	});
} catch (err) {
	var errorinfo = "url connection error 'lookupURL', details are : " + info + "; error info :" + err
	logger.error("id=fior_up07 : " + errorinfo);
	session.reject("id=fior_up07 : " + errorinfo);
	//throw errorinfo;
}
// end of urlopen.open()
