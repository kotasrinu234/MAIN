var ctx = session.name("nonefo") || session.createContext("nonefo");
var apiToken = session.parameters.TokenValue;
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("nonefo") || session.createContext("nonefo");

function callURL(url, method, myctx, payload) {
	logger.info("id=fior_up08|Inside callURL :: url" + url + ', ' + method + ', ' + myctx);

	var options = {
		target: url,
		method: method,
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "mosfoa_ClientProfile"
	};
	if (method == "POST" || method == "PATCH") {
		options.data = payload;
	}

	ctx.setVariable('method', method);
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "url connection error, details are : " + info + "; error info :" + error
				// an error occurred during reading the file
				logger.error("id=fior_up09 : " + errorinfo);
				// throw error;
			} else {
				var responseStatusCode = response.statusCode;
				var ctx = session.name('nonefo') || session.createContext('nonefo');
				ctx.setVariable(myctx + '_StatusCode', responseStatusCode);
				if (responseStatusCode == 200) {

					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "Error in reading the response data : " + info + "; error info :" + error
							logger.error("id=fior_up10 : " + errorinfo);
							//	throw error;
						} else {
							ilsCtx.setVariable('ExitStatus', "0");
							logger.info("success url response received");
							var ctx = session.name('nonefo') || session.createContext('nonefo');
							ctx.setVariable(myctx, responseData);
						}
					});
				} else if (responseStatusCode == 401 || responseStatusCode == 403) {
					// Handle business error responses (HTTP 401 or 403)
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "id=fior_up003: Error in reading the response data , details are : " + info + "; error info :" + error;
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "id=fior_up003:" + responseData + " Error in reading the response data " + myctx + ", details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				} else {

					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "Error in reading the response data details are : " + info + "; error info :" + error
							logger.error("id=fior_up10 : " + errorinfo);
							//throw error;
						} else {
							if (responseStatusCode == 400 || responseStatusCode == 404) {
								var BusinessResponseData = responseData;
									var buff = Buffer.from(BusinessResponseData);
									var ResponseString = buff.toString();
								if ((ResponseString === "No updates") || ResponseString.includes("OMS_CIRCULAR_WORKFLOW_TRANSITION")) {
									var errorinfo = "error response received , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									//ilsCtx.setVariable('ExitStatus', responseStatusCode);
									//ilsCtx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.output.write(incomingdata);
								}else {			   var errorinfo = "error response received , details are :" + info + "; response info : " + responseData
													ilsCtx.setVariable('ExitStatus', responseStatusCode);
													ilsCtx.setVariable('ExitDescription', errorinfo);
													var ctx = session.name('omsfoa') || session.createContext('omsfoa');
													ctx.setVariable('AvoidBackOut', 'yes');
												}                         
							} else {
								var ctx = session.name('nonefo') || session.createContext('nonefo');
								//ctx.setVariable('test', 'two'); 
								var method = ctx.getVariable('method');
								if (method == "POST" || method == "PATCH") {
									logger.error("id=fior_up10|Error from urlopen" + " : with statusCode " + responseStatusCode + " " + responseData);
									//throw Error("id=fior_up10|Error from urlopen" + " : with statusCode " + responseStatusCode + " " + responseData);
								}

								logger.error("id=fior_up10|Error from urlopen" + " : with statusCode " + responseStatusCode + " " + responseData);
							}
						}
					});
				}
			}
		});
	} catch (err) {
		if (error) {
			var errorinfo = "url connection error, details are : " + info + "; error info :" + error
			// an error occurred during reading the file
			logger.error("id=fior_up09 : " + errorinfo);
		}
	}
}
module.exports = callURL;
