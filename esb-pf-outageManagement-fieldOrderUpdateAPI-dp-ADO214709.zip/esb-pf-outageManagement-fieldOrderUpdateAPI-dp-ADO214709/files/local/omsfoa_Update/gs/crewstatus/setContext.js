var getURLResponse = require('./urlopenUtil.js');
var ctx = session.name("nonefo") || session.createContext("nonefo");
var errctx = session.name('error') || session.createContext('error');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(error, input) {
    if (error) {
        logger.error("id=fior_up07|Connection Error" );
        throw error;
    }
    var json = input[Object.keys(input)[0]];
	ctx.setVariable("inputRequest", json);
	
	  if (json.Assignment.Engineers[0].PSCrewID !==undefined && json.Assignment.Engineers[0].PSCrewID !== null && json.Assignment.Engineers[0].PSCrewID !== '') {
           var crewId = json.Assignment.Engineers[0].PSCrewID;
        } else {
			var crewId = json.Assignment.Engineers[0].ID;
		}
	ctx.setVariable("crewId", crewId);
    //var crewId = json.Assignment.Engineers[0].ID;
    var crewUri = session.parameters.OMS + '/api/ServiceType/Electric/Crew/' + crewId;
	logger.info("invoking url for GetCrewResponse" ); 
	 getURLResponse(crewUri, 'GET', 'GetCrewResponse', '');
});