var getURLResponse = require('./urlopenUtil.js');
var ctx = session.name('nonefo') || session.createContext('nonefo');
var errctx = session.name('error') || session.createContext('error');
var logger = console.options({
    'category': 'all'
});

//json = input[Object.keys(input)[0]];
var json = ctx.getVariable('inputRequest');
var crewId = ctx.getVariable('crewId');
var crewPostUrl = session.parameters.OMS + '/api/ServiceType/Electric/Crew';
var crewPatchUrl = session.parameters.OMS + '/api/ServiceType/Electric/Crew/' + crewId;
var crewResponse = ctx.getVariable('GetCrewResponse');
var crewResponseStatusCode = ctx.getVariable('GetCrewResponse_StatusCode');
console.info('Inside crewupdate ' + crewResponseStatusCode + ',  crewresp' + crewResponse);

if (crewResponseStatusCode === 404 || (crewResponseStatusCode === 200 && crewResponse.deprecated === true)) {
    var crewTypeLookupStatus = ctx.getVariable('crewTypeLookupStatus');
    if (crewTypeLookupStatus === undefined || crewTypeLookupStatus === null || crewTypeLookupStatus === '') {
        logger.error('id=fior_up108|Crew Type is not found');
        throw Error('id=fior_up108|Crew Type is not found');
    }
    var postRequest = {};
    postRequest.customFieldValues = {};
    postRequest.name = json.Assignment.Engineers[0].Name;
	
	if((json.Assignment.Engineers[0].PSCrewID === undefined || json.Assignment.Engineers[0].PSCrewID === '' || json.Assignment.Engineers[0].PSCrewID === null)&& (json.Assignment.Engineers[0].ID === undefined || json.Assignment.Engineers[0].ID === '' || json.Assignment.Engineers[0].ID === null)){
		logger.error('id=fior_up208|PSCrewID and Engineers.ID are not found');
            throw Error('id=fior_up208|PSCrewID and Engineers.ID are not found');	
	}
	
   	  if (json.Assignment.Engineers[0].PSCrewID !==undefined && json.Assignment.Engineers[0].PSCrewID !== null && json.Assignment.Engineers[0].PSCrewID !== '') {
            postRequest.externalID = json.Assignment.Engineers[0].PSCrewID;
        } else {
			postRequest.externalID = json.Assignment.Engineers[0].ID;
		}
		
    postRequest.active = true;
    postRequest.aorIDs = ctx.getVariable('aorIDs');
    postRequest.type = crewTypeLookupStatus;
    postRequest.customFieldValues.employeeid = json.Assignment.Engineers[0].ID;
    postRequest.customFieldValues.CrewID = json.Assignment.Engineers[0].PSCrewID;
    postRequest.customFieldValues.Crew_Status_non_OMS = json.Task.Status.Name;
    postRequest.customFieldValues.Crew_AssignmentStart_non_OMS = json.Assignment.Start;
    postRequest.customFieldValues.Crew_AssignmentEnd_non_OMS = json.Assignment.Finish;
    postRequest.customFieldValues.Crew_Callid_non_OMS = json.Task.CallID;
    postRequest.customFieldValues.Crew_TaskType_non_OMS = json.Task.TaskTypeCategory.Name;
    if (json.Task.PSStandByReason !== undefined && json.Task.PSStandByReason.Name !== undefined && json.Task.PSStandByReason.Name !== '') {
        postRequest.customFieldValues.Crew_StatusReason_non_OMS = json.Task.PSStandByReason.Name;
    }
    if (json.Task.PSOnHoldReason !== undefined && json.Task.PSOnHoldReason.Name !== undefined && json.Task.PSOnHoldReason.Name !== '') {
        postRequest.customFieldValues.Crew_StatusReason_non_OMS = json.Task.PSOnHoldReason.Name;
    }
    if (json.Task.PSInterruptReason !== undefined && json.Task.PSInterruptReason.Name !== undefined && json.Task.PSInterruptReason.Name !== '') {
        postRequest.customFieldValues.Crew_StatusReason_non_OMS = json.Task.PSInterruptReason.Name;
    }
    if (json.Task.PSCancellationReason !== undefined && json.Task.PSCancellationReason.Name !== undefined && json.Task.PSCancellationReason.Name !== '') {
        postRequest.customFieldValues.Crew_StatusReason_non_OMS = json.Task.PSCancellationReason.Name;
    }

    if (json.Task.PSStandByNotes !== undefined && json.Task.PSStandByNotes !== '') {
        postRequest.customFieldValues.Crew_StatusNotes_non_OMS = json.Task.PSStandByNotes;
    }
    if (json.Task.PSOnHoldNotes !== undefined && json.Task.PSOnHoldNotes !== '') {
        postRequest.customFieldValues.Crew_StatusNotes_non_OMS = json.Task.PSOnHoldNotes;
    }
    if (json.Task.PSInterruptNotes !== undefined && json.Task.PSInterruptNotes !== '') {
        postRequest.customFieldValues.Crew_StatusNotes_non_OMS = json.Task.PSInterruptNotes;
    }
    if (json.Task.PSCancellationNotes !== undefined && json.Task.PSCancellationNotes !== '') {
        postRequest.customFieldValues.Crew_StatusNotes_non_OMS = json.Task.PSCancellationNotes;
    }
    postRequest.customFieldValues.Crew_StatusChangeDate_non_OMS = json.Task.StatusChangeDate;
    logger.info("Sending the PostRequest");
    getURLResponse(crewPostUrl, 'POST', 'PostCrewResponse', postRequest);


} else if (crewResponseStatusCode === 200 && crewResponse.deprecated === false) {
    console.info('In patch block');
    var patchRequest = {};
    patchRequest.customFieldValues = {};
    patchRequest.customFieldValues.Crew_Status_non_OMS = json.Task.Status.Name;
    patchRequest.customFieldValues.Crew_AssignmentStart_non_OMS = json.Assignment.Start;
    patchRequest.customFieldValues.Crew_AssignmentFinish_non_OMS = json.Assignment.Finish;
    patchRequest.customFieldValues.Crew_Callid_non_OMS = json.Task.CallID;
    patchRequest.customFieldValues.Crew_TaskType_non_OMS = json.Task.TaskTypeCategory.Name;
    if (json.Task.PSStandByReason !== undefined && json.Task.PSStandByReason.Name !== undefined && json.Task.PSStandByReason.Name !== '') {
        patchRequest.customFieldValues.Crew_StatusReason_non_OMS = json.Task.PSStandByReason.Name;
    }
    if (json.Task.PSOnHoldReason !== undefined && json.Task.PSOnHoldReason.Name !== undefined && json.Task.PSOnHoldReason.Name !== '') {
        patchRequest.customFieldValues.Crew_StatusReason_non_OMS = json.Task.PSOnHoldReason.Name;
    }
    if (json.Task.PSInterruptReason !== undefined && json.Task.PSInterruptReason.Name !== undefined && json.Task.PSInterruptReason.Name !== '') {
        patchRequest.customFieldValues.Crew_StatusReason_non_OMS = json.Task.PSInterruptReason.Name;
    }
    if (json.Task.PSCancellationReason !== undefined && json.Task.PSCancellationReason.Name !== undefined && json.Task.PSCancellationReason.Name !== '') {
        patchRequest.customFieldValues.Crew_StatusReason_non_OMS = json.Task.PSCancellationReason.Name;
    }
    if (json.Task.PSStandByNotes !== undefined && json.Task.PSStandByNotes !== '') {
        patchRequest.customFieldValues.Crew_StatusNotes_non_OMS = json.Task.PSStandByNotes;
    }
    if (json.Task.PSOnHoldNotes !== undefined && json.Task.PSOnHoldNotes !== '') {
        patchRequest.customFieldValues.Crew_StatusNotes_non_OMS = json.Task.PSOnHoldNotes;
    }
    if (json.Task.PSInterruptNotes !== undefined && json.Task.PSInterruptNotes !== '') {
        patchRequest.customFieldValues.Crew_StatusNotes_non_OMS = json.Task.PSInterruptNotes;
    }
    if (json.Task.PSCancellationNotes !== undefined && json.Task.PSCancellationNotes !== '') {
        patchRequest.customFieldValues.Crew_StatusNotes_non_OMS = json.Task.PSCancellationNotes;
    }
    patchRequest.customFieldValues.Crew_StatusChangeDate_non_OMS = json.Task.StatusChangeDate;
    logger.info("Sending the PatchRequest");
    getURLResponse(crewPatchUrl, 'PATCH', 'PatchCrewResponse', patchRequest);
} else if (crewResponseStatusCode === 400) {
    logger.error("id=fior_up109" + crewResponseStatusCode);
    throw Error("id=fior_up109" + crewResponseStatusCode);
}