var getURLResponse = require('./urlopenUtil.js');
var ctx = session.name('nonefo') || session.createContext('nonefo');
var logger = console.options({
    'category': 'all'
});

var PostCrewResponse = ctx.getVariable('PostCrewResponse');
if (PostCrewResponse !== undefined) {
    ctx.setVariable('PostCrewResponseId', PostCrewResponse.id);
    ctx.setVariable('PostCrewResponseOnshift', PostCrewResponse.onShift);
    var crewPostUrlOffshift = session.parameters.OMS + '/api/ServiceType/Electric/Crew/' + PostCrewResponse.id + '/OffShift';
    ctx.setVariable('crewPostUrlOffshift', crewPostUrlOffshift);
    var now = new Date();
    var year = now.getFullYear();

    var month = now.getMonth() + 1;
    var month1 = month.toString();
    var strmonthlength = month1.length;
    var todaymonth;
    if (strmonthlength == 1) {
        todaymonth = '0' + month;
    } else {
        todaymonth = month;
    }

    var day = now.getDate();
    var day1 = day.toString();
    var strdaylength = day1.length;
    var todaydate;
    if (strdaylength == 1) {
        todaydate = '0' + day;
    } else {
        todaydate = day;
    }

    var hour = now.getHours();
    var todayhour = hour.toString();
    var strhourlength = todayhour.length;
    var todayhour;
    if (strhourlength == 1) {
        todayhour = '0' + hour;
    } else {
        todayhour = hour;
    }

    var minute = now.getMinutes();
    var todayminute = minute.toString();
    var strminutelength = todayminute.length;
    var todayminute;
    if (strminutelength == 1) {
        todayminute = '0' + minute;
    } else {
        todayminute = minute;
    }

    var second = now.getSeconds();
    var todaysecond = second.toString();
    var strsecondlength = todaysecond.length;
    var todaysecond;
    if (strsecondlength == 1) {
        todaysecond = '0' + todaysecond;
    } else {
        todaysecond = todaysecond;
    }

    var nowdate = year + '-' + todaymonth + '-' + todaydate
    var nowtime = todayhour + ':' + todayminute + ':' + todaysecond
    ctx.setVariable('shiftofftime', nowdate + 'T' + nowtime + 'Z');
    var shiftofftime = ctx.getVariable('shiftofftime');
    if (PostCrewResponse.onShift === true) {
        var patchRequest = {};
        patchRequest.shiftOffTime = shiftofftime;
        logger.info("Sending the PostRequest_offshift");
        getURLResponse(crewPostUrlOffshift, 'PATCH', 'PostCrewResponse_Offshift', patchRequest);
    }

}