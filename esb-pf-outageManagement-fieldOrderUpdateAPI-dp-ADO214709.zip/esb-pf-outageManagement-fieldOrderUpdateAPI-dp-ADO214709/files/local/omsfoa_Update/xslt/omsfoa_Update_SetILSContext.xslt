<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp"
	xmlns:date="http://exslt.org/dates-and-times"
	version="1.0">
	<xsl:variable name="Delimiter" select="'_'" />
	<xsl:template match="/">


<xsl:variable name="TransactoinID">
	<xsl:copy-of
					select="dp:variable('var://service/global-transaction-id')" />
	</xsl:variable>
	
	<xsl:variable name="ExternalRefID">
<xsl:value-of select="/*[local-name()='object']/*[local-name()='object'][@name='EFO_Completion_OMSCompletion']/*[local-name()='object'][@name='Task']/*[local-name()='string'][@name='ExternalRefID']/text()"/>
</xsl:variable>
<!-- OMS_CrewAssignmentID>_<JobId>_<JobId> -->

<xsl:variable name="substring1">
<xsl:value-of select="substring-after($ExternalRefID, 'OMS_')"/>
</xsl:variable>		

<!-- /<CrewAssignmentID>_<Callid>_<JobId> -->

<xsl:variable name="CrewAssignmentID">
<xsl:value-of select="substring-before($substring1, '_')"/>
</xsl:variable>

<!-- <JobId>_<Callid -->
<xsl:variable name="substring2">
<xsl:value-of select="substring-after($substring1, '_')"/>
</xsl:variable>

<xsl:variable name="Jobid">
<xsl:value-of select="substring-before($substring2, '_')"/>
</xsl:variable>
<xsl:variable name="Callid">
<xsl:value-of select="substring-after($substring2, '_')"/>
</xsl:variable>

			<xsl:variable name="JobID">
			<xsl:value-of
				select="$Jobid" />
		</xsl:variable>

		<xsl:variable name="crewAssignmentId">
			<xsl:value-of
				select="$CrewAssignmentID" />
		</xsl:variable>
	<xsl:variable name="CallID">		
			<xsl:value-of
				select="$Callid" />	
				</xsl:variable>	
				<!-- /*[local-name()='object']/*[local-name()='object'][@name='OMS_EFO_StatusChange']/*[local-name()='object'][@name='Assignment']/*[local-name()='array']/*[local-name()='object']/*[local-name()='object'][@name='Engineers']/*[local-name()='string'][@name='ID']/text() -->
	<xsl:variable name="ID">
	<!-- <xsl:value-of select="/*[local-name()='object']/*[local-name()='object'][@name='EFO_Completion_OMSCompletion']/*[local-name()='object'][@name='Assignment']/*[local-name()='array'][@name='Engineers']/*[local-name()='object'][1]/*[local-name()='string'][@name='ID']/text()"/> -->
	
	<xsl:value-of select="/*[local-name()='object']/*[local-name()='object'][@name='EFO_Completion_OMSCompletion']/*[local-name()='object'][@name='Assignment']/*[local-name()='object'][@name='Engineers']/*[local-name()='string'][@name='ID']/text()"/>
						  
	</xsl:variable>			
		<xsl:variable name="TimeStamp">
			<xsl:value-of select="date:date-time()"/>
		</xsl:variable>

<!-- customer logging to log temp -->
	<xsl:message dp:type="all" dp:priority="debug">FSM REQUEST: <xsl:value-of select="concat('TransactoinID:',$TransactoinID,' JobID:',$JobID ,' crewAssignmentId:',$crewAssignmentId,' CallID:',$CallID,' CrewID:',$ID,' TimeStamp:',$TimeStamp )" />
							</xsl:message>
							
							
		<xsl:call-template name="set_ILS_Context">
			
			<xsl:with-param name="JobID" select="$JobID" />
			<xsl:with-param name="crewAssignmentId" select="$crewAssignmentId" />
			<xsl:with-param name="CallID" select="$CallID" />
			<xsl:with-param name="ID" select="$ID"/>
			<xsl:with-param name="TimeStamp" select="$TimeStamp" />
			</xsl:call-template>
	</xsl:template>

	<xsl:template name="set_ILS_Context">
		<xsl:param name="JobID" />
		<xsl:param name="crewAssignmentId" />
        <xsl:param name="CallID" />
        <xsl:param name="ID"/>
		<xsl:param name="TimeStamp" />

		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()"/>
		<dp:set-variable name="'var://context/TimeStamp'" value="$TimeStamp" />
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'RECEIVED'"/>
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'FSM'"/>
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')"/>
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))"/>
	
		
		
		<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="'FORM COMPLETION'"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="string($JobID)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement3'" value="string($crewAssignmentId)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement4'" value="string($CallID)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement5'" value="string($ID)"/>
			
	</xsl:template>
</xsl:stylesheet>
