<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	extension-element-prefixes="dp" exclude-result-prefixes="dp">
	<xsl:variable name="smallcase" select="'abcdefghijklmnopqrstuvwxyz '" /> 
    <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ '" /> 
	
	<xsl:template match="/">
		<xsl:variable name="statusName" select="string(/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='object' and @*[local-name()='name' and normalize-space(.) = 'Status']]/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'Name']])" />
		
		<dp:set-variable name="'var://context/omsfoa1/statusName'" value="$statusName" />
		
		<xsl:choose>
			<xsl:when test="translate($statusName,$smallcase,$uppercase)='PARTIAL UPDATE'">
				<dp:set-variable name="'var://context/omsfoa1/ruleName'" value="'omsfoa_UPdate_Attachment_Processing_Policy_rule'" />
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/omsfoa1/ruleName'" value="'omsfoa_UPdate_Processing_Policy_Request_rule'" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>

