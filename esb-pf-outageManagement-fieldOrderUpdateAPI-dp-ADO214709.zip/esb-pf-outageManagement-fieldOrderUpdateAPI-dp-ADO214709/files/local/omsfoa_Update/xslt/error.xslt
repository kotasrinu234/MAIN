<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

<xsl:variable name="TransactionID">
	<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
			
</xsl:variable>
<xsl:message dp:type="all" dp:priority="debug">TransactionID:<xsl:value-of select="$TransactionID"/> ErrorCode:<xsl:value-of select="dp:variable('var://service/error-headers')"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>



</xsl:message>
	
	
<dp:set-variable name="'var://service/error-protocol-response'" value="dp:variable('var://service/error-headers')" />
<xsl:choose>
<xsl:when test="string-length(normalize-space(dp:variable('var://context/myContext/ErrorMesage')))&gt; 0">
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="concat('TransactionID:',$TransactionID,dp:variable('var://context/myContext/ErrorMesage'))" />
</xsl:when>
<xsl:otherwise>
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="concat('TransactionID:',$TransactionID,dp:variable('var://service/error-message'))" />
</xsl:otherwise>
</xsl:choose>

				
	</xsl:template>
</xsl:stylesheet>
