Interface 8: GIT Repo: esb-pf-outageManagement-fieldOrderUpdateAPI-dp

Jenkins Pipelines:

esb-pf-outageManagement-fieldOrderUpdateAPI-dp-st esb-pf-outageManagement-fieldOrderUpdateAPI-dp-acc esb-pf-outageManagement-fieldOrderUpdateAPI-dp-dev esb-pf-outageManagement-fieldOrderUpdateAPI-dp-int esb-pf-outageManagement-fieldOrderUpdateAPI-dp-load esb-pf-outageManagement-fieldOrderUpdateAPI-dp-prod

Domain: OutageManagement01



Tokens to be updated after Prod Deployment: 1.omsfoa_seq --TokenValue (stylesheet parameter name) 2.omsfoa_update -- -TokenValue (stylesheet parameter name)

NOTE: Please validate if all objects are up. Password alias for MQ, ssl certs should be added.

objects list:

MPG Services:

1.omsfoa_seq 2. omsfoa_update

Queaue Managers: 

omsfoa_seq_Eventhub_QM	 	
omsfoa_seq_QM		 	 	
omsfoa_seq_QM_ALT			 	 		
omsfoa_Update_EFO_MQ_QM		 	 	
omsfoa_Update_EFO_MQ_QM_alt			 	 	
omsfoa_Update_OTH_MQ_QM		 
omsfoa_Update_OTH_MQ_QM_alt

Client profiles:

omsfoa_Update_IIB_ClientProfile 
mosfoa_ClientProfile
ODM_Client_Profile"

MQ FSH:
omsfoa_seq_MQFSH	
omsfoa_seq_MQFSH_ALT	
omsfoa_Update_EFO_MQ_FSH	
omsfoa_Update_EFO_MQ_FSH_alt	
omsfoa_Update_OTH_MQ_FSH	
omsfoa_Update_OTH_MQ_FSH_alt
