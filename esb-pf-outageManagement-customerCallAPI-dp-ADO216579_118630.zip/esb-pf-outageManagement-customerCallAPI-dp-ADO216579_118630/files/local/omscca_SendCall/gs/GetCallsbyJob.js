// Import required modules
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

// Initialize variables
var headers = hm.current;
var callsArray = [];
var lookupArray = [];
var obsArray = [];

// Create contexts for session handling
var ctx = session.name("gcc") || session.createContext("gcc");
var ILSctx = session.name('ILS') || session.createContext('ILS');

// Read incoming data as JSON
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		// Handle error in reading incoming data
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		ILSctx.setVariable('ILSPayload', incomingdata);
		var internalid = incomingdata.GetCallsByJobRequest.JobIDGUID;
		ctx.setVariable("id", internalid);

		// Construct OMS URL and prepare headers
		var OMSUrl = session.parameters.OMSUrl + '/api/v1/ServiceType/Electric/Job/' + internalid + '/Call' + '?includeFields=callCodeID,address,name,phoneNumber,meterID,createdAt';
		var Token = session.parameters.OMSToken;
		var oms = {
			target: OMSUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': Token
			}
		};
		var info = " TargetURL: " + oms.target + "; Method: " + oms.method + ". ";

		// Make a GET request to OMS
		urlopen.open(oms, function(error, response) {
			if (error) {
				// Handle URL connection error
				var errorinfo = "gcc_003: url connection error 'GetCustomerCalls from OMS', details are : " + info + "; error info :" + error;
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", errorinfo);
			} else {
				var rescode = response.statusCode;
				if (rescode == 200) {
					// Handle successful response (HTTP 200)
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "error reading response 'GetCustomerCalls from OMS', details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							ctx.setVariable('GetCallResponse', responseData);
							if (responseData.length == null || responseData.length === 0) {
								// Handle business error when response data is empty
								var errorinfo = "error response 'GetCustomerCalls NoCalls for the Job', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + rescode;
								logger.error(errorinfo)

								ctx.setVariable("businessError", 'yes');
								var payload = {
									"CallBackData": {
										"messageID": incomingdata.CallBackData.messageID,
										"CallID": incomingdata.CallBackData.CallID,
										"Number": incomingdata.CallBackData.Number,
										"Client": incomingdata.CallBackData.Client,
										"ServiceName": incomingdata.CallBackData.ServiceName,
										"ExternalRefID": incomingdata.CallBackData.ExternalRefID
									},
									"GetCallsByJobResponse": [{
										"CallCode": "404"
									}]
								};
								ILSctx.setVariable('ExitDescription', session.parameters.NoCallsExitDescription);
								ILSctx.setVariable("ILSPayload", payload);
								fseCall(payload);
							} else {
								// Set response status and log successful response
								hm.response.statusCode = '200 OK';
								logger.debug("response received from 'GetCustomerCalls from OMS':" + JSON.stringify(responseData));
								ctx.setVariable("omsResponse", responseData);
							}
						}
					});
				} else if (rescode == 401 || rescode == 403) {
					// Handle business error responses (HTTP 401 or 403)
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "gcc_004: error reading response 'GetCustomerCalls OMS/Authentication Error', details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', rescode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "gcc_004: error response 'GetCustomerCalls OMS/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + rescode;
							ILSctx.setVariable('ExitStatus', rescode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				} else if (rescode == 400 || rescode == 404) {
					// Handle business error responses (HTTP 400 or 404)
					ctx.setVariable("businessError", 'yes');
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "error reading response 'GetCustomerCalls from OMS BusinessError', details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', rescode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "gcc_005: error response 'GetCustomerCalls from OMS BusinessError', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + rescode;
							ILSctx.setVariable('ExitStatus', rescode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo)
							ctx.setVariable("errordata", responseData.toString());
							var payload = {
								"CallBackData": {
									"messageID": incomingdata.CallBackData.messageID,
									"CallID": incomingdata.CallBackData.CallID,
									"Number": incomingdata.CallBackData.Number,
									"Client": incomingdata.CallBackData.Client,
									"ServiceName": incomingdata.CallBackData.ServiceName,
									"ExternalRefID": incomingdata.CallBackData.ExternalRefID
								},
								"ErrorMessage": responseData.toString()
							};
							ILSctx.setVariable("ILSPayload", payload);
							fseCall(payload);
						}
					});
				} else {
					// Handle other error responses
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "error reading response 'GetCustomerCalls from OMS', details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', rescode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "gcc_006: error response 'GetCustomerCalls from OMS', details are : " + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + rescode;
							ILSctx.setVariable('ExitStatus', rescode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							hm.current.statusCode = responseStatusCode;
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
						}
					});
				}
			}
		});
	}
});

// Function to make a call to another service (FSE)
function fseCall(payload) {
	var FSECall = {
		target: session.parameters.FacadeUrl,
		sslClientProfile: 'omsapijob_RestoreVerify_UpdateStatus_TLS_ClientProfile',
		method: 'post',
		contentType: 'application/json',
		data: payload
	};
	var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";

	// Make a POST request to the FSE service
	urlopen.open(FSECall, function(error, response) {
		if (error) {
			// Handle URL connection error to FSE
			ILSctx.setVariable('ILSPayload', FSECall.data)
			var errorinfo = "gcc_007: url connection error 'Request to FSE NoCall/BusinessError', details are : " + info + "; error info :" + error;
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo);
			logger.error(errorinfo);
			ctx.setVariable("retry", 'yes');
			ctx.setVariable("ErrorTxt", errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				// Handle successful response from FSE (HTTP 200)
				response.readAsJSON(function(error, responseData) {
					if (error) {
						// Handle error in reading response data
						var errorinfo = "error reading response 'Request to FSE NoCall/BusinessError', details are : " + info + "; error info :" + error;
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						logger.debug("request sent to FSE");
						ILSctx.setVariable('ExitStatus', '0');
						ILSctx.setVariable('ExitDestination', FSECall.target);
					}
				});
			} else if ((responseStatusCode == 500)) {

				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "url connection error , details are : " + info + "; error info :" + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						logger.error("Error returned while doing post for Create fse api call is  " + JSON.stringify(error));
						session.reject("Error returned while post for Create fse api call is" + JSON.stringify(error));
					} else {
						var flagvalue;
						var FSEAPIRes = (responseData.toString());
						var errorcode = session.parameters.responseErrorcodes;
						var ErrorCodeList = errorcode.split(',');
						var errormessage = session.parameters.responseErrormessage;
						if (FSEAPIRes.includes(errormessage)) {
							flagvalue = true;
						} else {
							for (var i = 0; i < ErrorCodeList.length; i++) {
								var numberval = Number(ErrorCodeList[i])
								if (FSEAPIRes.includes(String(numberval))) {
									flagvalue = true;
								}

							}
						}
						if (flagvalue) {
							ctx.setVariable("retry", 'yes');
							var errorinfo = "gcc_014: error response 'Request to FSE NoCall/BusinessError', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							ILSctx.setVariable('ExitDestination', FSECall.target);
							logger.error(errorinfo)
							var ErrorTxt = "Error returned while doing post for Create fse api call , details are: " + info + "error info:" + JSON.stringify(FSEAPIRes.ExceptionMessage);
							ctx.setVariable("ErrorTxt", ErrorTxt);
						} else {
							var errorinfo = "gcc_014: error response 'Request to FSE NoCall/BusinessError', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							ILSctx.setVariable('ExitDestination', FSECall.target);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					}
				});

			} else if (responseStatusCode == 504) {
				// Handle timeout error (HTTP 504)
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						// Handle error in reading response data
						var errorinfo = "error reading response 'Request to FSE NoCall/BusinessError', details are : " + info + "; error info :" + error;
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "error response 'Request to FSE NoCall/BusinessError', details are : " + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode;
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ExitDescription', errorinfo);
						hm.current.statusCode = responseStatusCode;
						logger.error(errorinfo);
						ctx.setVariable("retry", 'yes');
						ctx.setVariable("ErrorTxt", errorinfo);
					}
				});
			} else {
				// Handle other error responses from FSE
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						// Handle error in reading response data
						var errorinfo = "error reading response 'Request to FSE NoCall/BusinessError', details are : " + info + "; error info :" + error;
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "gcc_008: error response 'Request to FSE NoCall/BusinessError', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ExitDescription', errorinfo);
						hm.current.statusCode = responseStatusCode;
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		}
	});
}
