// Import required libraries/modules
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });

// Create or retrieve session contexts
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("gcc") || session.createContext("gcc");

// Retrieve variables from the context
var retry = ctx.getVariable("retry");
var businessError = ctx.getVariable("businessError");
var ILSPayload = ILSctx.getVariable("ILSPayload");
session.output.write(ILSPayload)
// Check if retry and businessError flags are not set
if (retry !== 'yes' && businessError !== 'yes') {
	// Read incoming data as JSON
	session.input.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			// Handle error in reading incoming data
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
			logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
			session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
		} else {
			var callArray = [];
			let payload = {
				"CallBackData": {
					"messageID": incomingdata.CallBackData.messageID,
					"CallID": incomingdata.CallBackData.CallID,
					"Number": incomingdata.CallBackData.Number,
					"Client": incomingdata.CallBackData.Client,
					"ServiceName": incomingdata.CallBackData.ServiceName,
					"ExternalRefID": incomingdata.CallBackData.ExternalRefID
				}
			};
			var omsres = ctx.getVariable("omsResponse");

			// Loop through omsres array
			for (let a = 0; a < omsres.length; a++) {
				var codeArray = ctx.getVariable("codeArray");

				// Loop through codeArray to find a match
				for (var c = 0; c < codeArray.length; c++) {
					if (codeArray[c].callCodeID === omsres[a].callCodeID) {
						var type = codeArray[c].type;
					}
				}

				// Create a call object and add it to the callArray
				let call = {
					"CallCode": type,
					"CustomerAddress": omsres[a].address,
					"CustomerName": omsres[a].name,
					"CustomerPhone": omsres[a].phoneNumber,
					"MeterID": omsres[a].meterID,
					"Timestamp": omsres[a].createdAt
				};
				callArray.push(call);
			}

			// Update payload with the callArray
			payload.GetCallsByJobResponse = callArray;
			ctx.setVariable("payload", payload);
			session.output.write(payload)
			// Create a service configuration for the FSE call
			var FSECall = {
				target: session.parameters.FacadeUrl,
				sslClientProfile: 'omsapijob_RestoreVerify_UpdateStatus_TLS_ClientProfile',
				method: 'post',
				contentType: 'application/json',
				data: payload
			};

			// Create an info string for logging
			var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";

			// Perform an HTTP request to perform the FSE call
			urlopen.open(FSECall, function(error, response) {
				if (error) {
					// Handle URL connection error
					session.output.write(FSECall.data);
					var errorinfo = "gcc_012: url connection error 'Request to FSE with Customer calls', details are : " + info + "; error info :" + error;
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo);
					logger.error(errorinfo);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("ErrorTxt", errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						// Read and handle a successful response
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// Handle error reading response
								var errorinfo = "error reading response 'Request to FSE with Customer calls', details are : " + info + "; error info :" + error;
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								logger.debug("request sent to FSE");
								ILSctx.setVariable('ExitStatus', '0');
								ILSctx.setVariable('ExitDestination', FSECall.target);
								ILSctx.setVariable('ExitDescription', session.parameters.WithCallsExitDescription);
							}
						});
					} else if (responseStatusCode == 504) {
						// Handle a specific HTTP response code
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								// Handle error reading response
								var errorinfo = "error reading response 'Request to FSE with Customer calls', details are : " + info + "; error info :" + error;
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "error response 'Request to FSE with Customer calls', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								hm.current.statusCode = responseStatusCode;
								logger.error(errorinfo);
								ctx.setVariable("retry", 'yes');
								ctx.setVariable("ErrorTxt", errorinfo);
							}
						});
					} else if ((responseStatusCode == 500)) {

						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "url connection error , details are : " + info + "; error info :" + JSON.stringify(error)
								ctx.setVariable("errormessage", errorinfo);
								logger.error("Error returned while doing post for Create fse api call is  " + JSON.stringify(error));
								session.reject("Error returned while post for Create fse api call is" + JSON.stringify(error));
							} else {
								var flagvalue;
								var FSEAPIRes = (responseData.toString());
								var errorcode = session.parameters.responseErrorcodes;
								var ErrorCodeList = errorcode.split(',');
								var errormessage = session.parameters.responseErrormessage;
								if (FSEAPIRes.includes(errormessage)) {
									flagvalue = true;
								} else {
									for (var i = 0; i < ErrorCodeList.length; i++) {
										var numberval = Number(ErrorCodeList[i])
										if (FSEAPIRes.includes(String(numberval))) {
											flagvalue = true;
										}

									}
								}
								if (flagvalue) {
									ctx.setVariable("retry", 'yes');
									var errorinfo = "gcc_014: error response 'Request to FSE with Customer calls details', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitDestination', FSECall.target);
									logger.error(errorinfo)
									var ErrorTxt = "Error returned while doing post for Create fse api call , details are: " + info + "error info:" + JSON.stringify(FSEAPIRes.ExceptionMessage);
									ctx.setVariable("ErrorTxt", ErrorTxt);
								} else {
									var errorinfo = "gcc_014: error response 'Request to FSE with Customer calls details', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitDestination', FSECall.target);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							}
						});

					} else {
						// Handle other HTTP response codes
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								// Handle error reading response
								var errorinfo = "error reading response 'Request to FSE with Customer calls', details are : " + info + "; error info :" + error;
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "gcc_013: error response 'Request to FSE with Customer calls details', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								hm.current.statusCode = responseStatusCode;
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
		}
	});
}
