var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});// Create or retrieve the ILS context for session handling
var ILSctx = session.name('ILS') || session.createContext('ILS');

// Get the current date and time and set it as a variable in the ILS context
var dateTime = new Date();
ILSctx.setVariable("sourceEventTimestamp", dateTime.toISOString());
session.input.readAsJSON(function(readAsJSONError, json) {
	if (readAsJSONError) {
		// Handle error in reading incoming data
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else { 
		if(!(json.CallBackData.messageID === undefined || json.CallBackData.messageID === null ||json.CallBackData.messageID === '')){
			ILSctx.setVariable('messageID', json.CallBackData.messageID)
		} else {
			ILSctx.setVariable('messageID', " ")
		}
		if(!(json.CallBackData.CallID === undefined || json.CallBackData.CallID === null ||json.CallBackData.CallID === '')){
			ILSctx.setVariable('CallID', json.CallBackData.CallID)
		} else {
			ILSctx.setVariable('CallID', " ")
		}
		if(!(json.GetCallsByJobRequest.JobIDGUID === undefined || json.GetCallsByJobRequest.JobIDGUID === null ||json.GetCallsByJobRequest.JobIDGUID === '')){
			ILSctx.setVariable('JobIDGUID', json.GetCallsByJobRequest.JobIDGUID)
		} else {
			ILSctx.setVariable('JobIDGUID', " ")
		}	
		if(!(json.GetCallsByJobRequest.JobID === undefined || json.GetCallsByJobRequest.JobID === null ||json.GetCallsByJobRequest.JobID === '')){
			ILSctx.setVariable('JobID', json.GetCallsByJobRequest.JobID)
		} else {
			ILSctx.setVariable('JobID', " ")
		}
	}
})
