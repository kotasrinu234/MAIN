// Import required libraries/modules
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });

// Initialize an array to store data
let codeArray = [];

// Create or retrieve session contexts
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("gcc") || session.createContext("gcc");
// Retrieve variables from the context
var retry = ctx.getVariable("retry");
var businessError = ctx.getVariable("businessError");

// Check if retry and businessError flags are not set
if (retry !== 'yes' && businessError !== 'yes') {
	// Retrieve a variable from the context
	var omsres = ctx.getVariable("omsResponse");

	// Loop through omsres array
	for (let a = 0; a < omsres.length; a++) {
		// Create a message for call code lookup
		var callCodeLookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "callCodeLabel",
						"id": omsres[a].callCodeID
					}
				]
			}
		};

		// Construct the lookup URL
		var lookupURL = session.parameters.lookupURL + "/callCodeLabel/" + omsres[a].callCodeID;

		// Create a service configuration for the lookup request
		var joblookupService = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: callCodeLookupMessage
		};
		ctx.setVariable("ILSPayload", JSON.stringify(joblookupService.data))
		// Create an info string for logging
		var info = " TargetURL :" + joblookupService.target + "; Method :" + joblookupService.method + "; Data :" + JSON.stringify(joblookupService.data) + ". ";

		// Perform an HTTP request to perform callCodeID lookup
		urlopen.open(joblookupService, function(error, response) {
			if (error) {
				// Handle URL connection error
				var errorinfo = "gcc_009: url connection error 'callCodeID Lookup', details are : " + info + "; error info :" + error;
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					// Read and handle a successful response
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// Handle error reading response
							var errorinfo = "error reading response 'callCodeID Lookup', details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							// Handle the successful lookup response
							ctx.setVariable("callcodelookupres", responseData);
							if (responseData.lookupRep.type[0].result == 0) {
								if ((responseData.lookupRep.type[0].label != undefined) && (responseData.lookupRep.type[0].label != null) && (responseData.lookupRep.type[0].label != '')) {
									// Update variables based on the response
									ctx.setVariable("type", responseData.lookupRep.type[0].label);
									let type = responseData.lookupRep.type[0].label;
									var callObj = {
										"callCodeID": omsres[a].callCodeID,
										"type": type
									};
									codeArray.push(callObj);
									ctx.setVariable("codeArray", codeArray);
								} else {
									// Handle invalid lookup response
									var invalidresp = "gcc_010: Invalid Lookup Request 'callCodeID Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode;
									ILSctx.setVariable('ExitStatus', '1');
									ILSctx.setVariable('ExitDescription', invalidresp);
									logger.error(invalidresp);
									session.reject(invalidresp);
								}
							} else {
								// Handle invalid lookup result
								var invalidresp = "gcc_010: Invalid Lookup Request 'callCodeID Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode;
								ILSctx.setVariable('ExitStatus', '1');
								ILSctx.setVariable('ExitDescription', invalidresp);
								logger.error(invalidresp);
								session.reject(invalidresp);
							}
						}
					});
				} else {
					// Handle non-200 HTTP response
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// Handle error reading response
							var errorinfo = "error reading response 'callCodeID Lookup', details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							// Handle error response
							var errorinfo = "gcc_011: error response 'callCodeID Lookup', details are : " + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							hm.current.statusCode = responseStatusCode;
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		});
	}
}
