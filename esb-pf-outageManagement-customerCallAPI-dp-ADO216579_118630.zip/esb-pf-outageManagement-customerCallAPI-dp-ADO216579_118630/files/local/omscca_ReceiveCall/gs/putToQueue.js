// Import required modules
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var RCExitDescription = session.parameters.RCExitDescription;

// Create or retrieve the context for session handling
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("gcc") || session.createContext("gcc");

// Read incoming data as JSON
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		// Handle error in reading incoming data
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		// Extract StandaloneMQurl and payload from incoming data
		var StandaloneMQurl = session.parameters.MQUrl;
		var payload = incomingdata;

		// Configure the message for pushing to the queue
		var pushingToQueue = {
			target: StandaloneMQurl,
			data: payload
		};

		var info = " TargetURL: " + pushingToQueue.target + "; Data: " + JSON.stringify(pushingToQueue.data) + ". ";
		try {
			// Open a connection and push the message to the queue
			urlopen.open(pushingToQueue, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					// Handle URL connection error
					var errorinfo = "gcc_001: URL connection error 'OMSCCA.RECEIVE.CALL queue', details are : " + info + "; error info :" + error;
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo);
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						// Handle successful response from the queue
						var replyMQMD = response.get({ type: 'mq' }, 'MQMD');
						var replyMQRFH2 = response.get({ type: 'mq' }, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								// Handle error in reading the response data
								var errorinfo = "Error reading the response 'OMSCCA.RECEIVE.CALL queue', details are : " + info + "; error info :" + readError;
								ILSctx.setVariable('ExitStatus', '500');
								ILSctx.setVariable('ExitDescription', errorinfo);
								hm.response.statusCode = 500;
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								logger.debug("MQResponsecode " + mqrc);
								ILSctx.setVariable('ExitDestination', StandaloneMQurl);
								ILSctx.setVariable('ExitDescription', RCExitDescription);
								ILSctx.setVariable('ExitStatus', '0');
							}
						});
					} else {
						// Handle error responses from the queue
						var errorinfo = "gcc_002:  Error received from the response of Queue 'OMSCCA.RECEIVE.CALL queue', details are : " + info + "; response info :" + JSON.stringify(response) + "; ResponseStatusCode :" + response.statusCode;
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				}
			});
		} catch (err) {
			// Handle URL connection error
			var errorinfo = "gcc_001: URL connection error 'OMSCCA.RECEIVE.CALL queue', details are : " + info + "; error info :" + err;
			var mqconnection = 'Forbidden';
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo);
			ctx.setVariable("mqconnection", mqconnection);
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	}
});
