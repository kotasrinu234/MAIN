// Create or retrieve the ILS context for session handling
var ILSctx = session.name('ILS') || session.createContext('ILS');

// Get the current date and time and set it as a variable in the ILS context
var dateTime = new Date();
ILSctx.setVariable("sourceEventTimestamp", dateTime.toISOString());
