// Import required modules
var logger = console.options({ 'category': 'all' });

// Create or retrieve the context for session handling
var ctx = session.name("gcc") || session.createContext("gcc");
var ILSctx = session.name("ILS") || session.createContext("ILS");

// Read incoming data as JSON
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		// Handle error in reading incoming data
		logger.error("Error in reading Incoming Data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		// Extract values from incoming data and perform null checks
		var ExternalRefID = incomingdata.CallBackData.ExternalRefID;
		NullCheck(ExternalRefID, "ExternalRefID");
		var JobID = incomingdata.GetCallsByJobRequest.JobIDGUID;
		NullCheck(JobID, "JobID");
	}
});

// Function to perform a null check on a value
function NullCheck(value, myctx) {
	if (value === null || value === '' || value === undefined) {
		var info = myctx + ' is not present in input payload';
		ILSctx.setVariable("ExitStatus", '500');
		ILSctx.setVariable("ExitDescription", info);
		logger.error(info);
		ctx.setVariable("schemafailed", 'yes');
		session.reject(info);
	}
}
