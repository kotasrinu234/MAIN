# esb-pf-outageManagement-customerCallAPI-dp
Interface 52- FSE Get Customer Calls

# Package from INT Environment.
# Instructions for Packaging.

#1. HTTPS Handler :
omscca_ReceiveCall_HTTPS_FSH

#2. MQ Handlers :
omscca_SendCall_MQ_FSH ,
omscca_SendCall_MQ_FSH_ALT ,
omscca_SendCall_MQ_Retry_FSH

#3. Queue Managers :
omscca_ReceiveCall_QMgr ,
omscca_SendCall_QMgr ,
omscca_SendCall_QMgr_ALT ,
omscca_SendCall_QMgr_Retry

#4. MultiProtocal Gateways :
omscca_ReceiveCall ,
omscca_SendCall

#5. TLS Client Profiles :
omscca_SendCall_TLS_ClientProfile ,
omsapi_client_profile ,
omsapijob_RestoreVerify_UpdateStatus_TLS_ClientProfile

#6. TLS Server Profile :
omscca_ReceiveCall_HTTPS_Server_Profile
