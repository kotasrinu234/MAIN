# esb-pf-enterpriseAssetManagement-serviceRequestService-dp
This repo consists the DP export, Jenkinsfile that are used in domain EnterpriseAssetManagement

Prerequisties: 
1) We have to plave Jenkinsfile for each environment under reponame.The Jenkins files are self explanatory.
2) Zip file with all objects that has to be promoted.
3) files should be placed under files/local folder.
4) Properties file for each environment should be placed under conf folder.
5) Base deployment policy must be placed in the repo with name: baseAPPNameDeploymentPolicy.


Execution: 
The corresponding pipelines are created in Jenkins with below names under DataPower view: 
1) For INT--> esb-pf-enterpriseAssetManagement-serviceRequestService-dp-int 
2) For ST--> esb-pf-enterpriseAssetManagement-serviceRequestService-dp-st 
3) For ACC--> esb-pf-enterpriseAssetManagement-serviceRequestService-dp-acc 
4) For LOAD--> esb-pf-enterpriseAssetManagement-serviceRequestService-dp-load 
5) For PROD--> esb-pf-enterpriseAssetManagement-serviceRequestService-dp-prod
