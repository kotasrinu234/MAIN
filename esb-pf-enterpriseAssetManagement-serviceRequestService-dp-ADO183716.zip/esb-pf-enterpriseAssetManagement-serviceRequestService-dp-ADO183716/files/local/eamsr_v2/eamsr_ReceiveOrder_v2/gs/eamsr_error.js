var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var hm = require('header-metadata');
var ictx = session.name("ILS") || session.createContext("ILS");
var sm = require('service-metadata');
var responseStatusCode = ctx.getVariable("responseStatusCode");
var errorCode = sm.getVar('var://service/error-code');
var errorMessage = sm.getVar('var://service/error-message')
var logger = console.options({
	'category': 'all'
});
var WSM = session.name('WSM') || session.createContext('WSM');
var value = WSM.getVar('identity/username');
logger.error("credentials" + value)
if(errorMessage === "Rejected by policy.") {
var errorinfo = `eamsr_35: AAA failure for OMS with, Username: ${value}, Errorstring: ${errorCode}, errorMessage: ${errorMessage}`;
   ictx.setVariable("ExitStatus", '401')
    logger.error(errorinfo);
}

if((errorCode == '0x00d30003')&& (responseStatusCode =='400')){
hm.current.statusCode = '400';
}
else if((errorCode == '0x00d30003')&& (responseStatusCode =='404')){
hm.current.statusCode = '404';
}
else{
hm.current.statusCode = '500';
}
var obj = {};
obj.errorMessage 		  = sm.getVar('var://service/error-message');
obj.errorCode 			  = sm.getVar('var://service/error-code');
obj.formattedErrorMessage 	  = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders		  = sm.getVar('var://service/error-headers');
session.output.write(obj);
