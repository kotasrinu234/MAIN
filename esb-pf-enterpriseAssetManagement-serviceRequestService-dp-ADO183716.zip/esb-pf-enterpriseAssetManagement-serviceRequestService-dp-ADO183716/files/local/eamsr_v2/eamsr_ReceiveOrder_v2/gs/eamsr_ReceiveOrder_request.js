var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ilsctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		var targetQueue = session.parameters.Queue + '&Transactional=true';
		/*    
		   var links = incomingdata.data[0].links;
		   console.log("links" + links);
		   if (links == null || links == '' || links == undefined) {
			   logger.error("eamsr_001 Links is not present in trigger payload");
			   session.reject('Links is not present in trigger payload');
   
		   } else {
			   var linkedDisplayID = incomingdata.data[0].links[0].linkedDisplayID;
			   if (linkedDisplayID == null || linkedDisplayID == '' || linkedDisplayID == undefined) {
				   logger.error("eamsr_002 linkedDisplayID is not present in trigger payload");
				   session.reject('linkedDisplayID is not present in trigger payload');
			   } else {
				   ctx.setVariable("linkedDisplayID", linkedDisplayID);
			   }
		   }
		//Removed the null check as per the updated Document
		*/
		var messageid = ilsctx.getVariable('correlationID')
		var payload = incomingdata;
		payload.messageID = messageid
		var options = {
			target: targetQueue,
			data: payload,
		};
		session.output.write(payload);
		ctx.setVar("payload", payload);
		var info = " TargetURL :" + options.target + "; Method :" + "POST" + "; Data :" + JSON.stringify(options.data) + ". ";
		try {
			urlopen.open(options, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var errorinfo = "eamsr_003 ** Mqurlopen.open error', details are : " + info + "; error info :" + error
					ilsctx.setVariable('ExitDescription', errorinfo);
					ilsctx.setVariable('ExitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
					hm.response.statusCode = 500
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								hm.response.statusCode = 500
							} else {
								console.log("MQResponseData" + responseData);
								ilsctx.setVariable('ExitDescription', session.parameters.ExitDescription);
								ilsctx.setVariable('ExitStatus', '0');
								ilsctx.setVariable('ExitDestination', targetQueue);

								if (incomingdata.data && incomingdata.data.length > 0 && incomingdata.data[0].links && incomingdata.data[0].links.length > 0) {
									var options = {
										target: session.parameters.rQueue + '&Transactional=true',
										data: payload,
									};
									session.output.write(payload)
									var info = " TargetURL :" + options.target + "; Method :" + "POST" + "; Data :" + JSON.stringify(options.data) + ". ";
									try {
										urlopen.open(options, function(error, response) {
											var hm = require('header-metadata');
											if (error) {
												var errorinfo = "eamsr_003 ** Mqurlopen.open error', details are : " + info + "; error info :" + error
												ilsctx.setVariable('ExitDescription', errorinfo);
												ilsctx.setVariable('ExitStatus', '500');
												logger.error(errorinfo);
												session.reject(errorinfo);
												hm.response.statusCode = 500
											} else {
												var mqrc = response.statusCode;
												if (mqrc == 0) {
													response.readAsBuffer(function(readError, responseData) {
														if (readError) {
															hm.response.statusCode = 500
														} else {
															console.log("MQResponseData" + responseData);
															ilsctx.setVariable('ExitDescription', session.parameters.ExitDescription);
															ilsctx.setVariable('ExitStatus', '0');
															ilsctx.setVariable('stepExitDestination', session.parameters.rQueue);
															ms.callRule('eamsr_ReceiveOrder_V2_policy_step_exit_rule', null, null, function(error) {
																if (error) {
																	logger.error("Error eamsr_ReceiveOrder_V2_policy_step_exit_rule");
																}
															});
														}
													});
												} else {
													var errorinfo = 'eamsr_003 ** Mqurlopen.open error,[MQRC=' + mqrc + ']' + "details are : " + info;
													ilsctx.setVariable('ExitDescription', errorinfo);
													ilsctx.setVariable('ExitStatus', mqrc);
													logger.error(errorinfo);
													session.reject(errorinfo);
													hm.response.statusCode = 500
												}
											}
										});
									} catch (err) {
										var errorinfo = "URL Open Connection Error, details are : " + info + "; error info :" + err
										ilsctx.setVariable('ExitDescription', errorinfo);
										ilsctx.setVariable('ExitStatus', '500');
										logger.error(errorinfo);
										session.reject(errorinfo);

									}
								}


							}
						});
					} else {
						var errorinfo = 'eamsr_003 ** Mqurlopen.open error,[MQRC=' + mqrc + ']' + "details are : " + info;
						ilsctx.setVariable('ExitDescription', errorinfo);
						ilsctx.setVariable('ExitStatus', mqrc);
						logger.error(errorinfo);
						session.reject(errorinfo);
						hm.response.statusCode = 500
					}
				}
			});
		} catch (err) {
			var errorinfo = "URL Open Connection Error, details are : " + info + "; error info :" + err
			ilsctx.setVariable('ExitDescription', errorinfo);
			ilsctx.setVariable('ExitStatus', '500');
			logger.error(errorinfo);
			session.reject(errorinfo);

		}

	}
});
