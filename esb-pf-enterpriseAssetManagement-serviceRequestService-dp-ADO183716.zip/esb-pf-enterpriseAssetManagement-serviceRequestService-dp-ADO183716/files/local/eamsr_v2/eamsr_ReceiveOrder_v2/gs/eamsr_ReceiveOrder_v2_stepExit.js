var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var payload = ctx.getVar("payload");
session.output.write(payload);
