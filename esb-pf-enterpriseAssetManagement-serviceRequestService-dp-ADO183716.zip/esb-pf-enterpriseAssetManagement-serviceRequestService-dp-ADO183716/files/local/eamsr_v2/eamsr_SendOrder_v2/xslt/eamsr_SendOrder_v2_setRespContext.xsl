<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/json" 
	extension-element-prefixes="dp" exclude-result-prefixes="dp da com max sr soapenv">
	<xsl:output method="xml" omit-xml-declaration="yes" />
	<xsl:template match="/">
	<xsl:variable name="retry">
			<xsl:value-of select="dp:variable('var://context/followUpOrder/Retry')"/>
	</xsl:variable>
	<xsl:if test="not(contains($retry,'yes'))">
		<xsl:variable name="input_old">
			<xsl:copy-of select="dp:variable('var://context/followUpOrder/MaximoResponse')"/>
		</xsl:variable>
		<xsl:variable name="input">  
			<dp:parse select="$input_old"/>
		</xsl:variable>
	<!-- 	<xsl:message>message::::<xsl:copy-of select="$input"/></xsl:message> -->
		<dp:set-variable
			name="'var://context/followUpOrder/input'" value="$input"/>
		<xsl:choose>
			<xsl:when test="$input/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']">
				<xsl:variable name="faultcode">
					<xsl:value-of select="$input/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/*[local-name()='faultcode']" />
				</xsl:variable>
				<xsl:variable name="faultstring">
					<xsl:value-of select="$input/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/*[local-name()='faultstring']" />
				</xsl:variable>
				<dp:set-variable
			name="'var://context/followUpOrder/faultcode'" value="string($faultcode)"/>
				<dp:set-variable
			name="'var://context/followUpOrder/faultstring'" value="string($faultstring)"/>
			</xsl:when>
			<xsl:when test="$input/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='CreateDTESROBJINResponse']">
				<xsl:variable name="ticketId">
					<xsl:value-of select="$input/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='CreateDTESROBJINResponse']/*[local-name()='SRMboKeySet']/*[local-name()='SR']/*[local-name()='TICKETID']" />
				</xsl:variable>
			<xsl:variable name="CLASS">
				<xsl:value-of select="$input/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='CreateDTESROBJINResponse']/*[local-name()='SRMboKeySet']/*[local-name()='SR']/*[local-name()='CLASS']" />
			</xsl:variable>
			<xsl:choose>
				<xsl:when test="$ticketId!=''">
					<dp:set-variable
			name="'var://context/followUpOrder/ticketId'" value="string($ticketId)"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:message dp:type="all" dp:priority="error">eamsr_19 ticketId not found</xsl:message>
					<dp:reject>ticketId not found</dp:reject>
				</xsl:otherwise>
			</xsl:choose>
			<dp:set-variable
			name="'var://context/followUpOrder/CLASS'" value="string($CLASS)"/>
			</xsl:when>
			<xsl:otherwise>
				<!-- <xsl:message>Inside otherwise</xsl:message>  -->
		</xsl:otherwise>			
	</xsl:choose>
	</xsl:if>		
</xsl:template>
</xsl:stylesheet>
