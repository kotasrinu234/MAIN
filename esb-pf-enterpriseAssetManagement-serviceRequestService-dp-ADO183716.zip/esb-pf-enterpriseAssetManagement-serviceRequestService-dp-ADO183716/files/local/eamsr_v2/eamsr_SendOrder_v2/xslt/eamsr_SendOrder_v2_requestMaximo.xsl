<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:da="http://da.esm.dteenergy.com/"
	xmlns:com="http://esm.dteco.com/common/v1"
	xmlns:max="http://www.ibm.com/maximo"
	xmlns:sr="http://servicerequest.esm.dteenergy.com"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope"
	xmlns:dpfunc="http://www.datapower.com/extensions/functions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	extension-element-prefixes="dp"
	exclude-result-prefixes="dp da com max sr soapenv">
	<xsl:include href="store:///utilities.xsl" />
	<xsl:output method="xml" />
	<xsl:param name="dpconfig:MaximoURL" />
	<xsl:variable name="exitpayload" select="''" />
	<xsl:template match="/">
		<dp:set-http-request-header
			name="'MaximoReq'" value="'MaximoReq'" />
		<dp:set-variable
			name="'var://context/followUpOrder/InputMessage'" value="." />
		<xsl:variable name="MaximoURL">
			<xsl:value-of select="$dpconfig:MaximoURL" />
		</xsl:variable>
		<xsl:variable name="MaximoReq">
			<soapenv:Envelope
				xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
				xmlns:max="http://www.ibm.com/maximo">
				<soapenv:Header />
				<soapenv:Body>
					<xsl:variable name="InputRequest">
						<xsl:copy-of select="." />
					</xsl:variable>
					<xsl:variable name="disconnectMeterURL">
						<xsl:value-of select="$dpconfig:disconnectMeterURL" />
					</xsl:variable>
					<xsl:variable name="commentUrl">
						<xsl:value-of
							select="dp:variable('var://context/followUpOrder/commentUrl')" />
					</xsl:variable>
					<xsl:variable name="comment">
						<xsl:value-of
							select="dp:variable('var://context/followUpOrder/totalComments')" />
					</xsl:variable>
					<xsl:variable name="InternalID">
						<xsl:value-of
							select="dp:variable('var://context/followUpOrder/InternalID')" />
					</xsl:variable>
					<xsl:variable name="lowercase"
						select="'abcdefghijklmnopqrstuvwxyz'" />
					<xsl:variable name="uppercase"
						select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
					<xsl:variable name="rightNow"
						select="date:seconds(date:date-time())" />
					<xsl:variable name="convertTime"
						select="dpfunc:zulu-time($rightNow, 'on')" />
					<xsl:variable name="Result">
						<xsl:value-of
							select="concat(substring-before($convertTime,'.'),'Z')" />
					</xsl:variable>
					<max:CreateDTESROBJIN
						xmlns="http://www.ibm.com/maximo"
						xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
						<max:DTESROBJINSet>
							<SR>
								<DTE_EXTERNALID>
									<xsl:value-of select="$InternalID" />
								</DTE_EXTERNALID>
								<DTE_REQTYPE>
									<xsl:value-of select="'SR'" />
								</DTE_REQTYPE>
								<CLASS>
									<xsl:value-of select="'SR'" />
								</CLASS>
								<xsl:variable name="Predirectional">
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Pre_Direction']" />
								</xsl:variable>
								<xsl:choose>
									<xsl:when
										test="$Predirectional = 'E' or $Predirectional = 'N' or $Predirectional = 'NE' or $Predirectional = 'NW' or $Predirectional = 'S' or $Predirectional = 'SE' or $Predirectional = 'SW' or $Predirectional = 'W' or $Predirectional = ''">
										<DTE_ADDSTRTPREDIR>
											<xsl:value-of select="$Predirectional" />
										</DTE_ADDSTRTPREDIR>
									</xsl:when>
									<xsl:otherwise>
										<xsl:message dp:type="all" dp:priority="error">
											eamsr_016 Not a valid Predirection
										</xsl:message>
										<dp:set-variable
							name="'var://context/ILS/errorStatus'" value="'500'" />
										<dp:reject>eamsr_016 Not a valid Predirection</dp:reject>
									</xsl:otherwise>
								</xsl:choose>
								<xsl:variable name="Postdirectional">
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Post_Direction']" />
								</xsl:variable>
								<xsl:choose>
									<xsl:when
										test="$Postdirectional = 'E' or $Postdirectional = 'N' or $Postdirectional = 'NE' or $Postdirectional = 'NW' or $Postdirectional = 'S' or $Postdirectional = 'SE' or $Postdirectional = 'SW' or $Postdirectional = 'W' or $Postdirectional = ''">
										<DTE_ADDSTRTPOSTDIR>
											<xsl:value-of select="$Postdirectional" />
										</DTE_ADDSTRTPOSTDIR>
									</xsl:when>
									<xsl:otherwise>
										<xsl:message dp:type="all" dp:priority="error">
											eamsr_017 Not a valid Postdirectional
										</xsl:message>
										<dp:set-variable
							name="'var://context/ILS/errorStatus'" value="'500'" />
										<dp:reject>eamsr_017 Not a valid Postdirectional</dp:reject>
									</xsl:otherwise>
								</xsl:choose>
								<DTE_ADDSTRTNUM>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Number']" />
								</DTE_ADDSTRTNUM>
								<DTE_ADDSTREET>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Name']" />
								</DTE_ADDSTREET>
								<DTE_ADDSTRTSUFFIX>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Suffix']" />
								</DTE_ADDSTRTSUFFIX>
								<DTE_ADDCITY>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_City']" />
								</DTE_ADDCITY>
								<DTE_ADDSTATE>
									<xsl:value-of
										select="translate($InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_State'],$lowercase,$uppercase)" />
								</DTE_ADDSTATE>
								<DTE_ADDZIP>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Zip_Code']" />
								</DTE_ADDZIP>
								<DTE_ADDSERVICECITY>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Township']" />
								</DTE_ADDSERVICECITY>
								<DTE_ADDCOUNTY>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_County']" />
								</DTE_ADDCOUNTY>
								<DTE_ADDEXTERNALID>
									<xsl:value-of
										select="$InputRequest//*[local-name()='string'][@name='externalID']" />
								</DTE_ADDEXTERNALID>
								<DTE_ADDLAT>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='location']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][2]" />
								</DTE_ADDLAT>
								<DTE_ADDLON>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='location']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][1]" />
								</DTE_ADDLON>
								<DTE_ADDMUNICIPAL>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Municipality']" />
								</DTE_ADDMUNICIPAL>
								<DTE_ADDTOWNSHIP>
									<xsl:value-of
										select="$InputRequest//*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Municipality']" />
								</DTE_ADDTOWNSHIP>
								<DESCRIPTION>
									<xsl:value-of
										select="dp:variable('var://context/followUpOrder/truncate_Description')" />
								</DESCRIPTION>
								<DTE_UNIT_CENTER>
									<xsl:value-of
										select="dp:variable('var://context/followUpOrder/aorIDlabel')" />
								</DTE_UNIT_CENTER>
								<REPORTDATE>
									<xsl:value-of select="$Result" />
								</REPORTDATE>
								<DTE_CUSTEXTERNALID>
									<xsl:value-of
										select="dp:variable('var://context/followUpOrder/Business_Partner_Number')" />
								</DTE_CUSTEXTERNALID>
								<DTE_FIRSTSTREET>
									<xsl:value-of
										select="dp:variable('var://context/followUpOrder/CrossStreet1')" />
								</DTE_FIRSTSTREET>
								<DTE_SECNDSTREET>
									<xsl:value-of
										select="dp:variable('var://context/followUpOrder/CrossStreet2')" />
								</DTE_SECNDSTREET>
								<DTE_TICKET>
									<DTE_SUB_CIR>
										<xsl:value-of
											select="dp:variable('var://context/followUpOrder/externalID')" />
									</DTE_SUB_CIR>
									<DTE_DGROUP>
										<xsl:value-of
											select="dp:variable('var://context/followUpOrder/aorIDlabel')" />
									</DTE_DGROUP>
									<DTE_SUBTYPE>
										<xsl:value-of
											select="dp:variable('var://context/followUpOrder/outageSubtypelabel')" />
									</DTE_SUBTYPE>
									<DTE_WORKTYPE>
										<xsl:value-of
											select="dp:variable('var://context/followUpOrder/externalCallCodeID')" />
									</DTE_WORKTYPE>
									<DTE_JOBTYPE>
										<xsl:value-of
											select="dp:variable('var://context/followUpOrder/externalCallCodeID')" />
									</DTE_JOBTYPE>
									<DTE_ORIGEXTERNALID>
										<xsl:value-of
											select="dp:variable('var://context/followUpOrder/id')" />
									</DTE_ORIGEXTERNALID>
								</DTE_TICKET>
								<WORKLOG>
									<CREATEDATE>
										<xsl:value-of select="$Result" />
									</CREATEDATE>
									<DESCRIPTION>
										<xsl:value-of select="'User Remarks'" />
									</DESCRIPTION>
									<DESCRIPTION_LONGDESCRIPTION>
										<xsl:value-of
											select="dp:variable('var://context/followUpOrder/totalComments')" />
									</DESCRIPTION_LONGDESCRIPTION>
									<DESCRIPTION>
										<xsl:value-of select="'Address'" />
									</DESCRIPTION>
									<DESCRIPTION_LONGDESCRIPTION>
										<xsl:value-of
											select="dp:variable('var://context/followUpOrder/Linkaddress')" />
									</DESCRIPTION_LONGDESCRIPTION>
									<LOGTYPE>
										<xsl:value-of select="'CLIENTNOTE'" />
									</LOGTYPE>
								</WORKLOG>
							</SR>
						</max:DTESROBJINSet>
					</max:CreateDTESROBJIN>
				</soapenv:Body>
			</soapenv:Envelope>
		</xsl:variable>
		<dp:set-variable
			name="'var://context/followUpOrder/MaximoReq'" value="$MaximoReq" />
		<xsl:variable name="MaximoResult">
			<dp:url-open target="{$MaximoURL}"
				response="responsecode-binary" http-method="post"
				content-type="text/xml">
				<xsl:copy-of select="$MaximoReq" />
			</dp:url-open>
		</xsl:variable>
<xsl:variable name="exitpayload" select="$MaximoReq" />	
<dp:set-variable
			name="'var://context/followUpOrder/MaximoResult'"
			value="$exitpayload" />
<xsl:variable name="responseCode">
			<xsl:value-of select="$MaximoResult/result/responsecode" />
		</xsl:variable>
		<xsl:variable name="MaximoResponse">
			<xsl:copy-of
				select="(dp:decode(dp:binary-encode($MaximoResult/result/binary/node()),'base-64'))"
				disable-output-escaping="yes" />
		</xsl:variable>
		<dp:set-variable
			name="'var://context/followUpOrder/MaximoResponseCode'"
			value="string($responseCode)" />
		<dp:set-variable
			name="'var://context/followUpOrder/MaximoResponse'"
			value="string($MaximoResponse)" />
		<xsl:variable name="Response_new">
			<dp:parse select="$MaximoResponse" />
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="$responseCode='200'">
				<xsl:variable name="MaximoResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($MaximoResult/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
					<dp:set-variable
						name="'var://context/followUpOrder/Retry'" value="'No'" />
				</xsl:variable>
			</xsl:when>
			<xsl:when test="$responseCode='500'">
				<dp:set-variable
					name="'var://context/followUpOrder/Retry'" value="'No'" />
				<xsl:choose>
					<xsl:when
						test="$Response_new/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']">
						<dp:set-variable
							name="'var://context/followUpOrder/Retry'" value="'No'" />
						<xsl:message dp:type="all" dp:priority="error">
							eamsr_071 Fault message from Maximo
						</xsl:message>
                  <dp:set-variable
            name="'var://context/ILS/ExitDescription'"
            value="concat('eamsr_071 Fault message from Maximo URL: ', $MaximoURL, '. Request Data: ', $MaximoReq)" />
			<dp:set-variable
							name="'var://context/ILS/exitStatus'" value="'500'" />
					</xsl:when>
					<xsl:otherwise>
						<xsl:message dp:type="all" dp:priority="error">
							eamsr_018 Unable to connect to Maximo
						</xsl:message>
						 <dp:set-variable
            name="'var://context/ILS/ExitDescription'"
            value="concat('eamsr_018 Unable to connect to Maximo URL: ', $MaximoURL, '. Request Data: ', $MaximoReq)" />
			<dp:set-variable
							name="'var://context/ILS/exitStatus'" value="'500'" />
						<dp:set-variable
							name="'var://context/followUpOrder/Retry'" value="'yes'" />
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">
					eamsr_070 Unable to connect to Maximo
				</xsl:message>
				 <dp:set-variable
    name="'var://context/ILS/ExitDescription'"
    value="concat('eamsr_070 Unable to connect to Maximo URL: ', $MaximoURL, '. Request Data: ', $MaximoReq)" />
	<dp:set-variable
							name="'var://context/ILS/exitStatus'" value="'500'" />

				<dp:set-variable
					name="'var://context/followUpOrder/Retry'" value="'yes'" />
			</xsl:otherwise>
		</xsl:choose>
		<xsl:copy-of select="$exitpayload"/>	
	</xsl:template>
</xsl:stylesheet>
