var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var urlopen = require('urlopen');
var apiToken = ctx.getVariable("apiToken");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var lookupURL = ctx.getVariable("lookupURL");
var InternalID = ctx.getVariable("id");
var ticketId = ctx.getVariable("ticketId");
var faultcode = ctx.getVariable("faultcode");
var faultstring = ctx.getVariable("faultstring");
var displayID = ctx.getVariable("displayID");
var Retry = ctx.getVariable("Retry");
var exitpayload = ctx.getVariable("MaximoResult");
var MaximoPayload = XML.stringify(exitpayload);
var ExitDescription = session.parameters.ExitDescription
var exitpayload = {}
if (Retry == 'No') {

	if (faultcode == '' || faultcode == undefined || faultcode == null) {
		var updateComment = {
			"comment": 'Maximo Request Successful. SR#: ' + ticketId
		}
		var label = "Maximo Successful";
	} else {
		var updateComment = {
			"comment": 'Maximo Request Failed. Code:' + faultcode + '. Reason: ' + faultstring
		}
		var label = "Maximo Failed";
	}
	var commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + InternalID + '/Comment';
	var options = {
		target: commentURL,
		method: "post",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "oms_Client_Profile",
		data: updateComment
	};
	var exitpayload = options.data;
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	urlopen.open(options, function(error, response) {
		if (error) {
			// an error occurred during reading the file
			var errorinfo = "eamsr_020 comment urlopen error details are : " + info + "error info :" + JSON.stringify(error)
			ilsctx.setVariable('errorStatus', "500");
			ilsctx.setVariable('ExitDescription', errorinfo);
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode != 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from comment details are : " + info + "error info :" + JSON.stringify(error)
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "eamsr_021 comment response is  " + responseStatusCode + " " + responseData + "details are :" + info
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});

			} else if ((responseStatusCode == 401)) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "eamsr_19 : Unauthorized error message while reading response from post call commentAPI, details are : " + info + "; error info :" + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error("eamsr_19 : error message while reading response from post call commentAPI , details are : " + info + "; error info :" + JSON.stringify(error));
						session.reject("eamsr_19 : error message while reading response from post call commentAPI , details are : " + info + "; error info :" + JSON.stringify(error));
					} else {
						var errorinfo = "eamsr_19 : Unauthorized error message while reading response from post call commentAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable("errormessage", errorinfo);
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error("eamsr_19 : Unauthorized Error returned from post call commentAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
						session.reject("eamsr_19 : Unauthorized Error returned from post call commentAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					}
				});
			} else if ((responseStatusCode == 403)) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "eamsr_20 :Forbidden error message while reading response from post call commentAPI , details are : " + info + "; error info :" + JSON.stringify(error)
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						ctx.setVariable("errormessage", errorinfo);
						logger.error("eamsr_20 :Forbidden error message while reading response from post call commentAPI, details are : " + info + "; error info :" + JSON.stringify(error));
						session.reject("eamsr_20 :Forbidden error message while reading response from post call commentAPI, details are : " + info + "; error info :" + JSON.stringify(error));
					} else {
						var errorinfo = "eamsr_20 :Forbidden error message while reading response from post call commentAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable("errormessage", errorinfo);
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error("eamsr_20 :Forbidden error returned from post call commentAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
						session.reject("eamsr_20 :Forbidden error returned from post call commentAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					}
				});
			} else {
				ilsctx.setVariable('exitStatus', "0");
				ilsctx.setVariable('ExitDescription', ExitDescription);
				console.log("response code of commentApi call :" + responseStatusCode);
			}
		}
	});
	var URL = omsExternalURL + '/api/ServiceType/Electric/Job/' + InternalID;
	var options = {
		target: URL,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "oms_Client_Profile"
	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
	urlopen.open(options, function(error, response) {
		if (error) {
			// an error occurred during reading the file
			var errorinfo = "eamsr_024  getJobAPI urlopen error details are : " + info + "error info :" + JSON.stringify(error)
			ilsctx.setVariable('errorStatus', "500");
			ilsctx.setVariable('ExitDescription', errorinfo);
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						// error while reading response or transferring data to Buffer
						var errorinfo = "eamsr_025 readAsJSON error details are : " + info + "error info :" + JSON.stringify(error)
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						ilsctx.setVariable('exitStatus', "0");
						ilsctx.setVariable('ExitDescription', ExitDescription);
						var id = responseData.id;
						if (id === null || id === '' || id === undefined) {
							//need to confirm this
							logger.error("eamsr_026 id not found");
							session.reject("id not found")
						} else {
							ctx.setVariable("id", id);
						}
						var jobTypeID = responseData.jobTypeID;
						if (jobTypeID === null || jobTypeID === '' || jobTypeID === undefined) {
							//need to confirm this
							logger.error("eamsr_027 jobTypeID not found");
							session.reject("jobTypeID not found")
						} else {
							ctx.setVariable("jobTypeID", jobTypeID);
						}
						var Status = responseData.status;
						if (Status === null || Status === '' || Status === undefined) {
							logger.error("Status not found");
							session.reject("Status not found")
						} else {
							ctx.setVariable("Job_Status", Status);
						}
						var jobWorkFlowIDlookupMessage = {
							"lookupReq": {
								"type": [{
									"name": "jobTypes.workflows",
									"id": jobTypeID,
									"label": label
								}]
							}
						}
						var LookupServiceResponse = {
							target: lookupURL,
							method: 'POST',
							contentType: 'application/json',
							data: jobWorkFlowIDlookupMessage
						};
						//var exitpayload = LookupServiceResponse.data
						var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
						urlopen.open(LookupServiceResponse, function(error, response) {
							if (error) {
								var errorinfo = "eamsr_028 lookup urlopen error details are : " + info + "error info :" + JSON.stringify(error)
								ilsctx.setVariable('errorStatus', "500");
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsJSON(function(error, responseData) {
										if (error) {
											// error while reading response or transferring data to Buffer
											var errorinfo = "eamsr_029 failure in putting message to LookupServiceResponse details are : " + info + "error info :" + JSON.stringify(error)
											ilsctx.setVariable('errorStatus', responseStatusCode);
											ilsctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											ilsctx.setVariable('exitStatus', "0");
											ilsctx.setVariable('ExitDescription', ExitDescription);
											hm.response.statusCode = responseStatusCode;
											logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
											if (responseData.lookupRep.type[0].result == 0) {
												var lookUpstatus = responseData.lookupRep.type[0].status;
												logger.debug("lookUpstatus:" + lookUpstatus);
												ctx.setVariable("lookUpstatus", lookUpstatus);
												if (Status == lookUpstatus) {
													logger.debug('Jobstatus is already ' + lookUpstatus);
												} else {
													var statusURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + InternalID + '/WorkFlow';
													var options = {
														target: statusURL,
														method: "post",
														headers: {
															"osiApiToken": apiToken
														},
														contentType: "application/json",
														sslClientProfile: "oms_Client_Profile",
														data: lookUpstatus
													};
													var exitpayload = options.data;
													var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
													urlopen.open(options, function(error, response) {
														if (error) {
															// an error occurred during reading the file
															var errorinfo = "eamsr_030 workflowAPI urlopen error details are : " + info + "error info :" + JSON.stringify(error)
															ilsctx.setVariable('errorStatus', "500");
															ilsctx.setVariable('ExitDescription', errorinfo);
															logger.error(errorinfo);
															session.output.write("workflowAPI urlopen error: " + JSON.stringify(error));
														} else {
															var responseStatusCode = response.statusCode;
															if (responseStatusCode != 200) {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		//dp:reject stop the transaction and go error rule with error code and description
																		var errorinfo = "failure in reading message from workflowAPI details are : " + info + "error info :" + JSON.stringify(error)
																		ilsctx.setVariable('errorStatus', responseStatusCode);
																		ilsctx.setVariable('ExitDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = "eamsr_031 workflowAPI  response is  " + responseStatusCode + " " + responseData + "details are :" + info;
																		ilsctx.setVariable('errorStatus', responseStatusCode);
																		ilsctx.setVariable('ExitDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																});
															} else if ((responseStatusCode == 401)) {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "eamsr_21 : Unauthorized error message while reading response from workflowAPI post call , details are : " + info + "; error info :" + JSON.stringify(error)
																		ilsctx.setVariable('errorStatus', responseStatusCode);
																		ilsctx.setVariable('ExitDescription', errorinfo);
																		ctx.setVariable("errormessage", errorinfo);
																		logger.error("eamsr_21 : error message while reading response from workflowAPI post call, details are : " + info + "; error info :" + JSON.stringify(error));
																		session.reject("eamsr_21 : error message while reading response from workflowAPI post call, details are : " + info + "; error info :" + JSON.stringify(error));
																	} else {
																		var errorinfo = "eamsr_21 : Unauthorized error message while reading response from workflowAPI post call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		ctx.setVariable("errormessage", errorinfo);
																		ilsctx.setVariable('errorStatus', responseStatusCode);
																		ilsctx.setVariable('ExitDescription', errorinfo);
																		logger.error("eamsr_21 : Unauthorized Error returned from workflowAPI post call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																		session.reject("eamsr_21 : Unauthorized Error returned from workflowAPI post call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																	}
																});
															} else if ((responseStatusCode == 403)) {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "eamsr_22 :Forbidden error message while reading response from workflowAPI post call, details are : " + info + "; error info :" + JSON.stringify(error)
																		ctx.setVariable("errormessage", errorinfo);
																		ilsctx.setVariable('errorStatus', responseStatusCode);
																		ilsctx.setVariable('ExitDescription', errorinfo);
																		logger.error("eamsr_22 :Forbidden error message while reading response from workflowAPI post call, details are : " + info + "; error info :" + JSON.stringify(error));
																		session.reject("eamsr_22 :Forbidden error message while reading response from workflowAPI post call, details are : " + info + "; error info :" + JSON.stringify(error));
																	} else {
																		var errorinfo = "eamsr_22 :Forbidden error message while reading response from workflowAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		ctx.setVariable("errormessage", errorinfo);
																		ilsctx.setVariable('errorStatus', responseStatusCode);
																		ilsctx.setVariable('ExitDescription', errorinfo);
																		logger.error("eamsr_22 :Forbidden error returned from workflowAPI post call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																		session.reject("eamsr_22 :Forbidden error returned from workflowAPI post call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																	}
																});
															} else {
																ilsctx.setVariable('exitStatus', "0");
																ilsctx.setVariable('ExitDescription', ExitDescription);
																if (faultcode == '' || faultcode == undefined || faultcode == null) {
																	var URL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + InternalID;
																	var data = {
																		"customFieldValues": {
																			//  "Maximo_Workorder": ticketId,
																			"Maximo_SR": ticketId
																		}
																	}
																	var options = {
																		target: URL,
																		method: "patch",
																		headers: {
																			"osiApiToken": apiToken
																		},
																		contentType: "application/json",
																		sslClientProfile: "oms_Client_Profile",
																		data: data
																	};
																	var exitpayload = options.data;
																	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
																	urlopen.open(options, function(error, response) {
																		if (error) {
																			// an error occurred during reading the file
																			var errorinfo = "eamsr_022 patchjobApi urlopen error details are : " + info + "error info :" + JSON.stringify(error)
																			ilsctx.setVariable('errorStatus', "500");
																			ilsctx.setVariable('ExitDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode != 200) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						//dp:reject stop the transaction and go error rule with error code and description
																						var errorinfo = "failure in reading message from patchjobApi details are : " + info + "error info :" + JSON.stringify(error)
																						ilsctx.setVariable('errorStatus', responseStatusCode);
																						ilsctx.setVariable('ExitDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "eamsr_023 patchjobApi  response is  " + responseStatusCode + " " + responseData + "details are :" + info
																						ilsctx.setVariable('errorStatus', responseStatusCode);
																						ilsctx.setVariable('ExitDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					}
																				});
																			} else if ((responseStatusCode == 401)) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "eamsr_23 : Unauthorized error message while reading response from patchjobApi, details are : " + info + "; error info :" + JSON.stringify(error)
																						ctx.setVariable("errormessage", errorinfo);
																						ilsctx.setVariable('errorStatus', responseStatusCode);
																						ilsctx.setVariable('ExitDescription', errorinfo);
																						logger.error("eamsr_23 : error message while reading response from patchjobApi , details are : " + info + "; error info :" + JSON.stringify(error));
																						session.reject("eamsr_23 : error message while reading response from patchjobApi , details are : " + info + "; error info :" + JSON.stringify(error));
																					} else {
																						var errorinfo = "eamsr_23 : Unauthorized error message while reading response from patchjobApi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																						ilsctx.setVariable('errorStatus', responseStatusCode);
																						ilsctx.setVariable('ExitDescription', errorinfo);
																						ctx.setVariable("errormessage", errorinfo);
																						logger.error("eamsr_23 : Unauthorized Error returned from patchjobApi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																						session.reject("eamsr_23 : Unauthorized Error returned from patchjobApi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																					}
																				});
																			} else if ((responseStatusCode == 403)) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "eamsr_24 :Forbidden error message while reading response from patchjobApi , details are : " + info + "; error info :" + JSON.stringify(error)
																						ilsctx.setVariable('errorStatus', responseStatusCode);
																						ilsctx.setVariable('ExitDescription', errorinfo);
																						ctx.setVariable("errormessage", errorinfo);
																						logger.error("eamsr_24 :Forbidden error message while reading response from patchjobApi, details are : " + info + "; error info :" + JSON.stringify(error));
																						session.reject("eamsr_24 :Forbidden error message while reading response from patchjobApi, details are : " + info + "; error info :" + JSON.stringify(error));
																					} else {
																						var errorinfo = "eamsr_24 :Forbidden error message while reading response from patchjobApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																						ctx.setVariable("errormessage", errorinfo);
																						ilsctx.setVariable('errorStatus', responseStatusCode);
																						ilsctx.setVariable('ExitDescription', errorinfo);
																						logger.error("eamsr_24 :Forbidden error returned from patchjobApi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																						session.reject("eamsr_24 :Forbidden error returned from patchjobApi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																					}
																				});
																			} else {
																				ilsctx.setVariable('exitStatus', "0");
																				ilsctx.setVariable('ExitDescription', ExitDescription);
																				console.log("response code of patchjobApi call :" + responseStatusCode);
																			}
																		}
																	});
																}
															}
														}
													});
												}
											}
										}

									});
								} else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											//dp:reject stop the transaction and go error rule with error code and description
											var errorinfo = "failure in reading message from jobWorkFlowID lookup details are :  " + info + " error info :" + JSON.stringify(error)
											ilsctx.setVariable('errorStatus', responseStatusCode);
											ilsctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "eamsr_032 jobWorkFlowID lookup response is  " + responseStatusCode + " " + responseData + "details are :" + info
											ilsctx.setVariable('errorStatus', responseStatusCode);
											ilsctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});
								}
							}
						});
					}
				});
			} else if ((responseStatusCode == 401)) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "eamsr_25 : Unauthorized error message while reading response from getJobAPI, details are : " + info + "; error info :" + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error("eamsr_25 : error message while reading response from getJobAPI , details are : " + info + "; error info :" + JSON.stringify(error));
						session.reject("eamsr_25 : error message while reading response from getJobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
					} else {
						var errorinfo = "eamsr_25 : Unauthorized error message while reading response from getJobAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable("errormessage", errorinfo);
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error("eamsr_25 : Unauthorized Error returned from getJobAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						session.reject("eamsr_25 : Unauthorized Error returned from getJobAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					}
				});
			} else if ((responseStatusCode == 403)) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "eamsr_26 :Forbidden error message while reading response from getJobAPI, details are : " + info + "; error info :" + JSON.stringify(error)
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						ctx.setVariable("errormessage", errorinfo);
						logger.error("eamsr_26 :Forbidden error message while reading response from getJobAPI , details are : " + info + "; error info :" + JSON.stringify(error));
						session.reject("eamsr_26 :Forbidden error message while reading response from getJobAPI , details are : " + info + "; error info :" + JSON.stringify(error));
					} else {
						var errorinfo = "eamsr_26 :Forbidden error message while reading response from getJobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable("errormessage", errorinfo);
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error("eamsr_26 :Forbidden error returned from getJobAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						session.reject("eamsr_26 :Forbidden error returned from getJobAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from getJobAPI details are :  " + info + " error info :" + JSON.stringify(error)
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "eamsr_033 getJobAPI response is  " + responseStatusCode + " " + responseData + "details are :" + info
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		}
	});
}
if (MaximoPayload) {
	var Maximo = {

		MaximoExitPayload: MaximoPayload

	};
	session.output.write(Maximo)

}
else {
	session.output.write(exitpayload)
}
