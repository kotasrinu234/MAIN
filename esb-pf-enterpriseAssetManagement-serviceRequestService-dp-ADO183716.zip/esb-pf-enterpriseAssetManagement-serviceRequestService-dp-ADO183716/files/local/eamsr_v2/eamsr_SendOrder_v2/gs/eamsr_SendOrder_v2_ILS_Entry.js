var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("ILS") || session.createContext("ILS");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if(incomingdata.messageID != undefined){
		ctx.setVariable('correlationID', incomingdata.messageID);
		}
		if(incomingdata.data[0].id != undefined){
		ctx.setVariable('JobId', incomingdata.data[0].id);
		}if(incomingdata.data[0].displayID != undefined){
		ctx.setVariable("displayid", incomingdata.data[0].displayID)
		}if(incomingdata.data[0].updatedAt !=undefined){
		ctx.setVariable("timestamp", incomingdata.data[0].updatedAt)
		}
	}
});
var messageType = session.parameters.messageType;
ctx.setVariable('messageType', messageType);
var description = session.parameters.EntryDescription;
ctx.setVariable("Entrydescription", description);
ctx.setVariable("ExitDestination", session.parameters.MaximoURL)
