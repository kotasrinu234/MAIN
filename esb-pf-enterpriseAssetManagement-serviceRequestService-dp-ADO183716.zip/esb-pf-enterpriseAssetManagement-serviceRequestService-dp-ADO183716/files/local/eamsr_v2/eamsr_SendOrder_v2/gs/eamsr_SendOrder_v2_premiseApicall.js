var ctx = session.name('followUpOrder') || session.createContext('followUpOrder');
var ilsctx = session.name("ILS") || session.createContext("ILS");
var getURLResponse = require('./urlopenUtil.js');
var leadCallIdURLResp = ctx.getVariable("leadCallIdURLResp");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var commentURLResp = ctx.getVariable("commentURLResp");
var apiToken = ctx.getVariable("apiToken");
var displayID = ctx.getVariable("displayID");
//var id = ctx.getVariable("id"); //ID for Change #4
var ComID = ctx.getVariable("ComID");
var address = ctx.getVariable("address");
var outageSubtypelabel = ctx.getVariable("outageSubtypelabel");
var commentUrl = session.parameters.commentUrl;
var urlopen = require('urlopen');
var comments = "";
var logger = console.options({
	'category': 'all'
});
var ExitDescription = session.parameters.ExitDescription
if (commentURLResp === null || commentURLResp === '' || commentURLResp === undefined) {
	ctx.setVariable("comments", '');
}
else {
	commentURLResp.forEach(function(obj) {
		comments = comments + obj.comment + "\n";
	})
}

var url_comments = commentUrl + ComID + "\t" + comments;

ctx.setVariable("totalComments", url_comments);

var Description = ComID + "\t" + address + "\t" + outageSubtypelabel;


var truncate_Description = Description.substring(0, 100);
ctx.setVariable("Description", Description);
ctx.setVariable("truncate_Description", truncate_Description);

if (leadCallIdURLResp === null || leadCallIdURLResp === '' || leadCallIdURLResp === undefined) {
	//ctx.setVariable("externalCallCodeID", '');
	ctx.setVariable("premiseID", '');
} else {

	if (leadCallIdURLResp.customFieldValuesExt === null || leadCallIdURLResp.customFieldValuesExt === undefined || leadCallIdURLResp.customFieldValuesExt === '') {
		ctx.setVariable("CrossStreet1", '');
		ctx.setVariable("CrossStreet2", '');
	} else {
		if (leadCallIdURLResp.customFieldValuesExt.CrossStreet1 === null || leadCallIdURLResp.customFieldValuesExt.CrossStreet1 === '' || leadCallIdURLResp.customFieldValuesExt.CrossStreet1 === undefined) {
			ctx.setVariable("CrossStreet1", '');
		} else {
			var CrossStreet1 = leadCallIdURLResp.customFieldValuesExt.CrossStreet1;
			ctx.setVariable("CrossStreet1", CrossStreet1);
		}
		if (leadCallIdURLResp.customFieldValuesExt.CrossStreet2 === null || leadCallIdURLResp.customFieldValuesExt.CrossStreet2 === '' || leadCallIdURLResp.customFieldValuesExt.CrossStreet2 === undefined) {
			ctx.setVariable("CrossStreet2", '');
		} else {
			var CrossStreet2 = leadCallIdURLResp.customFieldValuesExt.CrossStreet2;
			ctx.setVariable("CrossStreet2", CrossStreet2);
		}
	}

	var externalCallCodeID = leadCallIdURLResp.externalCallCodeID;
	if (externalCallCodeID === null || externalCallCodeID === '' || externalCallCodeID === undefined) {
		ctx.setVariable("externalCallCodeID", '');
	} else {
		ctx.setVariable("externalCallCodeID", externalCallCodeID);
	}
	var premiseID = leadCallIdURLResp.premiseID;
	if (premiseID === null || premiseID === '' || premiseID === undefined) {
		ctx.setVariable("premiseID", '');
	} else {
		ctx.setVariable("premiseID", premiseID);
	}

	if (premiseID === undefined || premiseID === null || premiseID === '') {
	} else {
		var PremiseURL = omsExternalURL + '/api/v1/ServiceType/Electric/Premise/' + premiseID;
		var PremiseAPI = {
			target: PremiseURL,
			method: "get",
			headers: {
				"osiApiToken": apiToken
			},
			contentType: "application/json",
			sslClientProfile: "oms_Client_Profile"

		};
		var info = " TargetURL :" + PremiseAPI.target + "; Method :" + PremiseAPI.method + ". ";
		urlopen.open(PremiseAPI, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				var errorinfo = "eamsr_014 PremiseAPI urlopen error details are: " + info + "error info :" + JSON.stringify(error)
				ilsctx.setVariable('errorStatus', "500");
				ilsctx.setVariable('ExitDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "readAsJSON error details are: " + info + "error info :" + JSON.stringify(error)
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							session.output.write(errorinfo);
						} else {
							ilsctx.setVariable('exitStatus', "0");
							ilsctx.setVariable('ExitDescription', ExitDescription);
							ctx.setVariable("PremiseData", responseData);
							if (responseData.customer === null || responseData.customer === undefined || responseData.customer === "") {
								ctx.setVariable('Business_Partner_Number', '');
							} else {
								if (responseData.customer.customFieldValuesExt === null || responseData.customer.customFieldValuesExt === undefined || responseData.customer.customFieldValuesExt === "") {
									ctx.setVariable('Business_Partner_Number', '');
								} else {
									if (responseData.customer.customFieldValuesExt.Business_Partner_Number === null || responseData.customer.customFieldValuesExt.Business_Partner_Number === undefined || responseData.customer.customFieldValuesExt.Business_Partner_Number === "") {
										ctx.setVariable('Business_Partner_Number', '');
									} else {
										var Business_Partner_Number = responseData.customer.customFieldValuesExt.Business_Partner_Number;
										ctx.setVariable('Business_Partner_Number', Business_Partner_Number)
									}
								}
							}
						}
					})
				} else if ((responseStatusCode == 401)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "eamsr_27 : Unauthorized error message while reading response from PremiseAPI, details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable("errormessage", errorinfo);
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							logger.error("eamsr_27 : error message while reading response from PremiseAPI, details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("eamsr_27 : error message while reading response from PremiseAPI, details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "eamsr_27 : Unauthorized error message while reading response from PremiseAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable("errormessage", errorinfo);
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							logger.error("eamsr_27 : Unauthorized Error returned from PremiseAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							session.reject("eamsr_27 : Unauthorized Error returned from PremiseAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				} else if ((responseStatusCode == 403)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "eamsr_28 :Forbidden error message while reading response from PremiseAPI, details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable("errormessage", errorinfo);
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							logger.error("eamsr_28 :Forbidden error message while reading response from PremiseAPI, details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("eamsr_28 :Forbidden error message while reading response from PremiseAPI, details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "eamsr_28 :Forbidden error message while reading response from PremiseAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							ctx.setVariable("errormessage", errorinfo);
							logger.error("eamsr_28 :Forbidden error returned from PremiseAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							session.reject("eamsr_28 :Forbidden error returned from PremiseAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				}
				else {
					ctx.setVariable('Business_Partner_Number', '');
					logger.debug("PremiseAPI response code is " + responseStatusCode + " ");
				}
			}
		})
		var premiseCallApiURL = omsExternalURL + '/api/v1/Premise/' + premiseID;
		var options = {
			target: premiseCallApiURL,
			method: "get",
			headers: {
				"osiApiToken": apiToken
			},
			contentType: "application/json",
			sslClientProfile: "oms_Client_Profile"

		};
		var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
		urlopen.open(options, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				var errorinfo = "eamsr_015 premiseCallApiURL urlopen error details are: " + info + "error info :" + JSON.stringify(error)
				ilsctx.setVariable('errorStatus', "500");
				ilsctx.setVariable('ExitDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							session.output.write("readAsJSON error: " + JSON.stringify(error));
						} else {
							ilsctx.setVariable('exitStatus', "0");
							ilsctx.setVariable('ExitDescription', ExitDescription);
							ctx.setVariable('premiseCallApiURLResp', responseData);
							session.output.write(responseData);
						}
					})

				} else if ((responseStatusCode == 401)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "eamsr_29 : Unauthorized error message while reading response from premiseCallApiURL, details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable("errormessage", errorinfo);
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							logger.error("eamsr_29 : error message while reading response from premiseCallApiURL, details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("eamsr_29 : error message while reading response from premiseCallApiURL, details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "eamsr_29 : Unauthorized error message while reading response from premiseCallApiURL, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable("errormessage", errorinfo);
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							logger.error("eamsr_29 : Unauthorized Error returned from premiseCallApiURL, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							session.reject("eamsr_29 : Unauthorized Error returned from premiseCallApiURL, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				} else if ((responseStatusCode == 403)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "eamsr_30 :Forbidden error message while reading response from premiseCallApiURL, details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable("errormessage", errorinfo);
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							logger.error("eamsr_30 :Forbidden error message while reading response from premiseCallApiURL, details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("eamsr_30 :Forbidden error message while reading response from premiseCallApiURL, details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "eamsr_30 :Forbidden error message while reading response from premiseCallApiURL, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable("errormessage", errorinfo);
							ilsctx.setVariable('errorStatus', responseStatusCode);
							ilsctx.setVariable('ExitDescription', errorinfo);
							logger.error("eamsr_30 :Forbidden error returned from premiseCallApiURL, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							session.reject("eamsr_30 :Forbidden error returned from premiseCallApiURL, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				}
				else {
					var errorinfo = "premiseCallApiURL response code is " + responseStatusCode + " details are :" + info
					ilsctx.setVariable('errorStatus', responseStatusCode);
					ilsctx.setVariable('ExitDescription', errorinfo);
					logger.error(errorinfo);
					var obj = {};
					session.output.write(obj);
				}
			}
		})
	}
}
