var ctx = session.name('followUpOrder') || session.createContext('followUpOrder');
var ilsctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var getURLResponse = require('./urlopenUtil.js');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var apiToken = ctx.getVariable("apiToken");
var logger = console.options({
	'category': 'all'
});
var ExitDescription = session.parameters.ExitDescription

session.input.readAsJSON(function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		session.reject("Error in reading Json");
	} else {
		var links = json.data[0].links;

		if (json.data[0].displayID === null || json.data[0].displayID === undefined || json.data[0].displayID === '') {
			var ComID = ''
			ctx.setVariable("ComID", ComID)
		} else {
			var ComID = json.data[0].displayID
			ctx.setVariable("ComID", ComID)
		}

		if (links === undefined || links === null || links === '' || links.length === 0) {
			var DispID = json.data[0].displayID;
			var id = json.data[0].id
			ctx.setVariable('id', id);
			ctx.setVariable("InternalID", DispID)

		} else {
			var linksLength = json.data[0].links.length;
			for (var i = 0; i < linksLength; i++) {
				var DispID = json.data[0].displayID;
				var id = json.data[0].id
				ctx.setVariable('id', id);
				ctx.setVariable("InternalID", DispID)

				var archived = json.data[0].links[i].archived;
				var deprecated = json.data[0].links[i].deprecated;
				var linkedDisplayID = json.data[0].links[i].linkedDisplayID;

				if ((archived != 'True') && (deprecated != 'True')) {
					var linkedID = json.data[0].links[i].linkedID;

					if (linkedID === null || linkedID === '' || linkedID === undefined) {
						logger.error("eamsr_008 linkedID is not present");
						session.reject("linkedID is not present");
					}
					else {
						ctx.setVariable('linkedID', linkedID);
					}
					console.log("linkedDisplayID" + linkedDisplayID);

					var LinkJobURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + linkedDisplayID;
					var LinkJobURI = {
						target: LinkJobURL,
						sslClientProfile: 'oms_Client_Profile',
						method: 'GET',
						contentType: 'application/json',
						headers: {
							'osiApiToken': apiToken
						},
					};
					var info = " TargetURL :" + LinkJobURI.target + "; Method :" + LinkJobURI.method + ". ";
					urlopen.open(LinkJobURI, function(error, response) {
						if (error) {
							// an error occurred during reading the file
							var errorinfo = "eamsr_004 LinkJob urlopen error details are " + info + "error info" + JSON.stringify(error)
							ilsctx.setVariable('errorStatus', "500");
							ilsctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										var errorinfo = "readAsJSON error details are  " + info + "error info" + JSON.stringify(error)
										ilsctx.setVariable('errorStatus', responseStatusCode);
										ilsctx.setVariable('ExitDescription', errorinfo);
										session.output.write(errorinfo);
									} else {
										ilsctx.setVariable('exitStatus', "0");
										ilsctx.setVariable('ExitDescription', ExitDescription);
										ctx.setVariable('LinkJobURLResponse', responseData);
									}
								})

							} else if ((responseStatusCode == 401)) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "eamsr_17 : Unauthorized error message while reading response from LinkJobUri, details are : " + info + "; error info :" + JSON.stringify(error)
										ctx.setVariable("errormessage", errorinfo);
										ilsctx.setVariable('errorStatus', responseStatusCode);
										ilsctx.setVariable('ExitDescription', errorinfo);
										logger.error("eamsr_17 : error message while reading response from LinkJobUri, details are : " + info + "; error info :" + JSON.stringify(error))
										session.reject("eamsr_17 : error message while reading response from LinkJobUri, details are : " + info + "; error info :" + JSON.stringify(error))
									} else {
										var errorinfo = "eamsr_17 : Unauthorized error message while reading response from LinkJobUri , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ilsctx.setVariable('errorStatus', responseStatusCode);
										ilsctx.setVariable('ExitDescription', errorinfo);
										ctx.setVariable("errormessage", errorinfo);
										logger.error("eamsr_17 : Unauthorized Error returned from LinkJobUri, details are: " + info + " response info: " + responseData + "; ResponseStatusCode: " + responseStatusCode);
										session.reject("eamsr_17 : Unauthorized Error returned from LinkJobUri, details are: " + info + " response info: " + responseData + "; ResponseStatusCode: " + responseStatusCode);

									}
								});
							} else if ((responseStatusCode == 403)) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "eamsr_18 :Forbidden error message while reading response from LinkJobUri , details are : " + info + "; error info :" + JSON.stringify(error)
										ctx.setVariable("errormessage", errorinfo);
										ilsctx.setVariable('errorStatus', responseStatusCode);
										ilsctx.setVariable('ExitDescription', errorinfo);
										logger.error("eamsr_18 :Forbidden error message while reading response from LinkJobUriI , details are : " + info + "; error info :" + JSON.stringify(error));
										session.reject("eamsr_18 :Forbidden error message while reading response from LinkJobUri , details are : " + info + "; error info :" + JSON.stringify(error));
									} else {
										var errorinfo = "eamsr_18 :Forbidden error message while reading response from LinkJobUri, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ctx.setVariable("errormessage", errorinfo);
										ilsctx.setVariable('errorStatus', responseStatusCode);
										ilsctx.setVariable('ExitDescription', errorinfo);
										logger.error("eamsr_18 :Forbidden error returned from LinkJobUri , details are: " + info + " response info: " + responseData + "; ResponseStatusCode: " + responseStatusCode);
										session.reject("eamsr_18 :Forbidden error returned from LinkJobUri , details are: " + info + " response info: " + responseData + "; ResponseStatusCode: " + responseStatusCode);
									}
								});
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										var errorinfo = "failure in reading message from LinkJobUri details are  " + info + "error info" + JSON.stringify(error)
										ilsctx.setVariable('errorStatus', responseStatusCode);
										ilsctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var errorinfo = "eamsr_005 LinkJobUri response is  " + responseStatusCode + " " + responseData + "details are" + info;
										ilsctx.setVariable('errorStatus', responseStatusCode);
										ilsctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
										hm.current.statusCode = '404';
									}
								});
							}

						}
					})
					break;
				}

			}
		}
	}
});
