var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var eamsr = ctx.getVariable("eamsr");
var logger = console.options({
	'category': 'all'
});

function getURLResponse(url, myctx) {
	var options = {
		target: url,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "oms_Client_Profile"

	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
	urlopen.open(options, function(error, response) {
		if (error) {
			// an error occurred during reading the file
			var errorinfo = eamsr + " urlopen error details are :" + info + "error info:" + JSON.stringify(error)
			ilsctx.setVariable('errorStatus', "500");
			ilsctx.setVariable('ExitDescription', errorinfo);
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						// error while reading response or transferring data to Buffer
						var errorinfo = "readAsJSON error details are " + info + "error info" + JSON.stringify(error)
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						session.output.write("readAsJSON error: " + JSON.stringify(error));
					} else {
						ctx.setVariable(myctx, responseData);
					}
				})

			} else if ((responseStatusCode == 401)) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "eamsr_33 : Unauthorized error message while reading response from " + url + "details are : " + info + "; error info :" + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error("eamsr_33 : error message while reading response details are : " + info + "; error info :" + JSON.stringify(error));
						session.reject("eamsr_33 : error message while reading response details are : " + info + "; error info :" + JSON.stringify(error));
					} else {
						var errorinfo = "eamsr_33 : Unauthorized error message while reading response from " + url + "details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						ctx.setVariable("errormessage", errorinfo);
						logger.error("eamsr_33 : Unauthorized Error details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						session.reject("eamsr_33 : Unauthorized Error details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					}
				});
			} else if ((responseStatusCode == 403)) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "eamsr_34 :Forbidden error message while reading response from from " + url + "details are : " + info + "; error info :" + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error("eamsr_34 :Forbidden error message while reading response details are : " + info + "; error info :" + JSON.stringify(error));
						session.reject("eamsr_34 :Forbidden error message while reading response details are : " + info + "; error info :" + JSON.stringify(error));
					} else {
						var errorinfo = "eamsr_34 :Forbidden error message while reading response from from " + url + "details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						ctx.setVariable("errormessage", errorinfo);
						logger.error("eamsr_34 :Forbidden error details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						session.reject("eamsr_34 :Forbidden error details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from " + url + "details are " + info + "error info:" + JSON.stringify(error)
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else
						var ctx = session.name("followUpOrder") || session.createContext("followUpOrder"); {
						var eamsr = ctx.getVariable("eamsr");
						var errorinfo = eamsr + ' ' + 'Error code returned from Api ' + url + ' ' + responseStatusCode + ' ' + responseData + "details are :" + info
						ilsctx.setVariable('errorStatus', responseStatusCode);
						ilsctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		}
	})
}

module.exports = getURLResponse;
