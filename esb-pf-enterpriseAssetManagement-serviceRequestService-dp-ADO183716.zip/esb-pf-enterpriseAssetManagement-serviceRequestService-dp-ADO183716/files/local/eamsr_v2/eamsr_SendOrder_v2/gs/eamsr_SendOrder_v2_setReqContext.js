var getURLResponse = require('./urlopenUtil.js');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var errctx = session.name('error') || session.createContext('error');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var apiToken = ctx.getVariable("apiToken");
var linkedID = ctx.getVariable("linkedID");
var LinkJobURLResponse = ctx.getVariable("LinkJobURLResponse");
var lookupURL = ctx.getVariable("lookupURL");
var logger = console.options({
	'category': 'all'
});
var ExitDescription = session.parameters.ExitDescription

session.input.readAsJSON(function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		session.output.write(error);
	} else {


		if (LinkJobURLResponse == null || LinkJobURLResponse == '' || LinkJobURLResponse == undefined) {
			var leadCallID = json.data[0].leadCallID
			if (leadCallID === null || leadCallID === '' || leadCallID === undefined) {
				var jobTypeID = json.data[0].jobTypeID
				if (jobTypeID === null || jobTypeID === undefined || jobTypeID === '') {
					ctx.setVariable("externalCallCodeID", '')
					//logger.error("JobTypeID is not present in the trigger Payload")
				} else {
					var Payload = {
						"lookupReq": {
							"type": [
								{
									"name": "jobTypes",
									"id": jobTypeID

								}
							]
						}
					};
					LookUpCall(lookupURL, Payload)
				}

			} else {
				var leadCallIdURL = omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + leadCallID;
				ctx.setVariable("eamsr", 'eamsr_006');
				getURLResponse(leadCallIdURL, 'leadCallIdURLResp');
			}
		} else {
			var leadCallID = LinkJobURLResponse.leadCallID;
			console.log("leadCallID" + leadCallID);
			if (leadCallID == null || leadCallID == '' || leadCallID == undefined) {
				//logger.error("eamsr_007 leadCallID is not present");
				var jobTypeID = json.data[0].jobTypeID
				if (jobTypeID === null || jobTypeID === undefined || jobTypeID === '') {
					ctx.setVariable("externalCallCodeID", '')
					//logger.error("JobTypeID is not present in the trigger Payload")
				} else {
					var Payload = {
						"lookupReq": {
							"type": [
								{
									"name": "jobTypes",
									"id": jobTypeID

								}
							]
						}
					};
					LookUpCall(lookupURL, Payload)
				}

			}
			else {
				ctx.setVariable("leadCallID", leadCallID);
				var leadCallIdURL = omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + leadCallID;
				ctx.setVariable("eamsr", 'eamsr_006');
				getURLResponse(leadCallIdURL, 'leadCallIdURLResp');
			}
		}

		var displayID = json.data[0].displayID;
		if (displayID === null || displayID === '' || displayID === undefined) {
			ctx.setVariable("displayID", '');
		}
		else {
			ctx.setVariable("displayID", displayID);
		}

		if (LinkJobURLResponse === null || LinkJobURLResponse === '' || LinkJobURLResponse === undefined) {
			if (json.data[0].nominalFeederID === null || json.data[0].nominalFeederID === undefined || json.data[0].nominalFeederID === '') {
				var ExternalID = session.parameters.ExternalID
				ctx.setVariable("externalID", ExternalID);
				ctx.setVariable("nominalFeederID", '');
			} else {
				var flag = 'True';
				var nominalFeederID = json.data[0].nominalFeederID;
				ctx.setVariable("nominalFeederID", json.data[0].nominalFeederID);
			}
		}
		else {
			if (LinkJobURLResponse.nominalFeederID === null || LinkJobURLResponse.nominalFeederID === undefined || LinkJobURLResponse.nominalFeederID === '') {
				if (json.data[0].nominalFeederID === null || json.data[0].nominalFeederID === undefined || json.data[0].nominalFeederID === '') {
					var ExternalID = session.parameters.ExternalID
					ctx.setVariable("externalID", ExternalID);
					ctx.setVariable("nominalFeederID", '');
				} else {
					var flag = 'True';
					var nominalFeederID = json.data[0].nominalFeederID;
					ctx.setVariable("nominalFeederID", json.data[0].nominalFeederID);
				}
				/*var nominalFeederID = ''
				ctx.setVariable("nominalFeederID", nominalFeederID);*/
			} else {
				var flag = 'True';
				ctx.setVariable("nominalFeederID", LinkJobURLResponse.nominalFeederID);
				var nominalFeederID = LinkJobURLResponse.nominalFeederID;
			}
		}

		var address;

		if (json.data[0].leadLocation === null || json.data[0].leadLocation === undefined || json.data[0].leadLocation === ' ' || json.data[0].leadLocation === '') {
		} else {
			if (json.data[0].leadLocation.label === null || json.data[0].leadLocation.label === undefined || json.data[0].leadLocation.label === ' ' || json.data[0].leadLocation.label === '') {
			} else {
				address = json.data[0].leadLocation.label;
			}
		}

		//ctx.setVariable("Linkaddress", Linkaddress);
		if (address === null || address === '' || address === undefined) {
			if (LinkJobURLResponse === null || LinkJobURLResponse === undefined || LinkJobURLResponse === ' ' || LinkJobURLResponse === '') {
				ctx.setVariable("Linkaddress", '')
				if (json.data[0].address === undefined || json.data[0].address === null || json.data[0].address === ' ' || json.data[0].address === '') {
					ctx.setVariable("address", '');
				} else {
					ctx.setVariable("address", json.data[0].address);
				}
			} else {
				if (LinkJobURLResponse.leadLocation === null || LinkJobURLResponse.leadLocation === undefined || LinkJobURLResponse.leadLocation === ' ' || LinkJobURLResponse.leadLocation === '') {
					if (LinkJobURLResponse.address === null || LinkJobURLResponse.address === undefined || LinkJobURLResponse.address === ' ' || LinkJobURLResponse.address === '') {
						if (json.data[0].address === undefined || json.data[0].address === null || json.data[0].address === ' ' || json.data[0].address === '') {
							ctx.setVariable("address", '');
						} else {
							ctx.setVariable("address", json.data[0].address);
						}
					} else {
						ctx.setVariable("address", LinkJobURLResponse.address);
					}
					ctx.setVariable("Linkaddress", '')
				} else {
					if (LinkJobURLResponse.leadLocation.label === null || LinkJobURLResponse.leadLocation.label === undefined || LinkJobURLResponse.leadLocation.label === ' ' || LinkJobURLResponse.leadLocation.label === '') {
						ctx.setVariable("Linkaddress", '')
						if (LinkJobURLResponse.address === null || LinkJobURLResponse.address === undefined || LinkJobURLResponse.address === ' ' || LinkJobURLResponse.address === '') {
							if (json.data[0].address === undefined || json.data[0].address === null || json.data[0].address === ' ' || json.data[0].address === '') {
								ctx.setVariable("address", '');
							} else {
								ctx.setVariable("address", json.data[0].address);
							}
						} else {
							ctx.setVariable("address", LinkJobURLResponse.address);
						}
					} else {
						var LinkLabel = LinkJobURLResponse.leadLocation.label;
						ctx.setVariable("Linkaddress", LinkLabel)
						ctx.setVariable("address", LinkLabel);
					}
				}
			}
		}
		else {
			ctx.setVariable("address", address);
			ctx.setVariable("Linkaddress", address);
		}

		var links = json.data[0].links;
		if (links === undefined || links === null || links === '' || links.length === 0) {
			var CommentID = json.data[0].id
		} else {
			var CommentID = linkedID
		}

		var commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + CommentID + '/Comment';
		ctx.setVariable("eamsr", 'eamsr_009');
		getURLResponse(commentURL, 'commentURLResp');

		if (LinkJobURLResponse === null || LinkJobURLResponse === undefined || LinkJobURLResponse === '') {
			if (json.data[0].aorID === null || json.data[0].aorID === undefined || json.data[0].aorID === '') {
				ctx.setVariable("aorID", '');
				errctx.setVariable("customErrorMessage", "The aorID value is not present");
				//logger.error("eamsr_010 The aorID value is not present.");
				//throw new ReferenceError("The aorID value is not present.");
			} else {
				aorID = json.data[0].aorID
				ctx.setVariable("aorID", aorID);
			}
		} else {
			if (LinkJobURLResponse.aorID === null || LinkJobURLResponse.aorID === undefined || LinkJobURLResponse.aorID === '') {
				ctx.setVariable("aorID", '');
			} else {
				var aorID = LinkJobURLResponse.aorID
				console.log(aorID);
				ctx.setVariable("aorID", aorID);
			}

		}

		if (LinkJobURLResponse === null || LinkJobURLResponse === undefined || LinkJobURLResponse === '') {
			if (json.data[0].outageSubtypeID === null || json.data[0].outageSubtypeID === undefined || json.data[0].outageSubtypeID === '') {
				var outageSubtypeID = ''
				ctx.setVariable("outageSubtypeID", outageSubtypeID);
			} else {
				var outageSubtypeID = json.data[0].outageSubtypeID
				ctx.setVariable("outageSubtypeID", outageSubtypeID);
			}
		} else {
			var outageSubtypeID = LinkJobURLResponse.outageSubtypeID;
			if (outageSubtypeID === null || outageSubtypeID === undefined || outageSubtypeID === '') {
				if (json.data[0].outageSubtypeID === null || json.data[0].outageSubtypeID === undefined || json.data[0].outageSubtypeID === '') {
					var outageSubtypeID = ''
					ctx.setVariable("outageSubtypeID", outageSubtypeID);
				} else {
					var outageSubtypeID = json.data[0].outageSubtypeID
					ctx.setVariable("outageSubtypeID", outageSubtypeID);
				}
			} else {
				console.log(outageSubtypeID);
				ctx.setVariable("outageSubtypeID", outageSubtypeID);
			}
		}

		/*	if (LinkJobURLResponse != null) {
				if (LinkJobURLResponse.outageSubtypeID === null || LinkJobURLResponse.outageSubtypeID === undefined || LinkJobURLResponse.outageSubtypeID === '') {
					var outageSubtypeID
				} else {
					var outageSubtypeID = LinkJobURLResponse.outageSubtypeID;
					console.log(outageSubtypeID);
					ctx.setVariable("outageSubtypeID", outageSubtypeID);
				}
			}
			else if (json.data[0].outageSubtypeID != null || json.data[0].outageSubtypeID != undefined || json.data[0].outageSubtypeID != '') {
				var outageSubtypeID = json.data[0].outageSubtypeID
				//ctx.setVariable("outageSubtypelabel", '');
			}*/

		var request = {};
		request.type = new Array();

		var obj
		if (aorID == null || aorID == undefined || aorID == '') {
			var aorIDlabel = '';
			ctx.setVariable("aorIDlabel", aorIDlabel)
		} else {
			obj = {};
			obj.name = "aors";
			obj.id = aorID;
			obj.status = "none";
			request.type.push(obj);
		}

		if (outageSubtypeID == null || outageSubtypeID == undefined || outageSubtypeID == '') {
			var outageSubtypelabel = '';
			ctx.setVariable("outageSubtypelabel", outageSubtypelabel)
		} else {
			obj = {};
			obj.name = "outageSubtypes";
			obj.id = outageSubtypeID;
			request.type.push(obj);
		}
		if (request.type.length == 0) {
			//logger.error("OutageSubtypeID and aorID are not Present")
			ctx.setVariable("aorIDlabel", '');
			ctx.setVariable("outageSubtypelabel", '');
		} else {
			var options1 = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: {
					"lookupReq": request
				}
			};
			var optionsinfo = " TargetURL :" + lookupURL + "; Method :" + "POST" + "; Data :" + JSON.stringify(options1.data) + ". ";
			//logger.error("line287"+ optionsinfo)
			// open connection to target
			try {
				urlopen.open(options1, function(error, response) {
					if (error) {
						// an error occurred during reading the file
						var optionserrorinfo = "eamsr_011 Lookup urlopen error details are: " + optionsinfo + "error details :" + JSON.stringify(error)
						ilsctx.setVariable('errorStatus', "500");
						ilsctx.setVariable('ExitDescription', optionserrorinfo);
						logger.error(optionserrorinfo);
						session.reject(optionserrorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "eamsr_012 readAsJson error details are: " + optionsinfo + "error details :" + JSON.stringify(error)
									ilsctx.setVariable('errorStatus', responseStatusCode);
									ilsctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.output.write("readAsJson error: " + JSON.stringify(error));
								} else {
									ilsctx.setVariable('exitStatus', "0");
									ilsctx.setVariable('ExitDescription', ExitDescription);
									ctx.setVariable('lookupResponseData', responseData);
									var aorIDlabel = '';
									var outageSubtypelabel = '';
									for (var i = 0; i < responseData.lookupRep.type.length; i++) {
										if (responseData.lookupRep.type[i].name == 'aors') {
											var result = responseData.lookupRep.type[i].result
											if (result == 0) {
												aorIDlabel = responseData.lookupRep.type[i].label;
												ctx.setVariable("aorIDlabel", aorIDlabel);
											} else {
												var errorinfo = "Invalid LookUp Request for aorID Label details are: " + info;
												ilsctx.setVariable('exitStatus', "500");
												ilsctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo)
												ctx.setVariable("aorIDlabel", aorIDlabel);
											}
										} else if (responseData.lookupRep.type[i].name == 'outageSubtypes') {
											var result = responseData.lookupRep.type[i].result
											if (result == 0) {
												outageSubtypelabel = responseData.lookupRep.type[i].label;
												ctx.setVariable("outageSubtypelabel", outageSubtypelabel);
											} else {
												var errorinfo = "Invalid LookUp Request for outageSubType Label details are: " + info;
												ilsctx.setVariable('exitStatus', "500");
												ilsctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo)
												ctx.setVariable("outageSubtypelabel", outageSubtypelabel);
											}
										}
									}
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "failure in reading message from lookup details are: " + optionsinfo + "error details:" + JSON.stringify(error)
									ilsctx.setVariable('errorStatus', responseStatusCode);
									ilsctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "eamsr_013 lookup urlopen target return statusCode:" + responseStatusCode + " " + responseData + "details" + info
									ilsctx.setVariable('errorStatus', responseStatusCode);
									ilsctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "eamsr_011 Lookup urlopen error details are: " + optionsinfo + "error details :" + JSON.stringify(error)
				ilsctx.setVariable('errorStatus', "500");
				ilsctx.setVariable('ExitDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);

			} // end of urlopen.open()
		}

		//End of changes for Missing aorID and OutageSubtype


		if (flag == 'True') {
			var FeederUri = omsExternalURL + '/api/ServiceType/Electric/Feeder/' + nominalFeederID;
			var feederGetApi = {
				target: FeederUri,
				sslClientProfile: 'oms_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': apiToken
				},
			};
			var info = " TargetURL :" + feederGetApi.target + "; Method :" + feederGetApi.method + ". ";
			urlopen.open(feederGetApi, function(error, response) {

				if (error) {
					// an error occurred during reading the file
					var errorinfo = "urlopen error details are : " + info + "error info :" + JSON.stringify(error)
					ilsctx.setVariable('errorStatus', "500");
					ilsctx.setVariable('ExitDescription', errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					ctx.setVariable("responseStatusCode", responseStatusCode);
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "readAsJSON error details are " + info + "error info" + JSON.stringify(error)
								ilsctx.setVariable('ExitDescription', errorinfo);
								ilsctx.setVariable('errorStatus', responseStatusCode);
								session.reject("readAsJSON error: " + JSON.stringify(error));
							} else {
								ilsctx.setVariable('exitStatus', "0");
								ilsctx.setVariable('ExitDescription', ExitDescription);

								if (responseData.externalID === null || responseData.externalID === undefined || responseData.externalID === "") {
									var ExternalID = session.parameters.ExternalID
									ctx.setVariable("externalID", ExternalID);
								} else {
									var externalID = responseData.externalID;
									ctx.setVariable("externalID", externalID);
								}
							}
						})

					} else if ((responseStatusCode == 401)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "eamsr_31 : Unauthorized error message while reading response from feederGetApi, details are : " + info + "; error info :" + JSON.stringify(error)
								ctx.setVariable("errormessage", errorinfo);
								ilsctx.setVariable('errorStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error("eamsr_31 : error message while reading response from feederGetApi, details are : " + info + "; error info :" + JSON.stringify(error));
								session.reject("eamsr_31 : error message while reading response from feederGetApi, details are : " + info + "; error info :" + JSON.stringify(error));
							} else {
								var errorinfo = "eamsr_31 : Unauthorized error message while reading response from feederGetApi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ctx.setVariable("errormessage", errorinfo);
								ilsctx.setVariable('errorStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error("eamsr_31 : Unauthorized Error returned from feederGetApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
								session.reject("eamsr_31 : Unauthorized Error returned from feederGetApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							}
						});
					} else if ((responseStatusCode == 403)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "eamsr_32 :Forbidden error message while reading response from feederGetApi , details are : " + info + "; error info :" + JSON.stringify(error)
								ctx.setVariable("errormessage", errorinfo);
								ilsctx.setVariable('errorStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error("eamsr_32 :Forbidden error message while reading response from feederGetApi, details are : " + info + "; error info :" + JSON.stringify(error));
								session.reject("eamsr_32 :Forbidden error message while reading response from feederGetApi, details are : " + info + "; error info :" + JSON.stringify(error));
							} else {
								var errorinfo = "eamsr_32 :Forbidden error message while reading response from feederGetApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ctx.setVariable("errormessage", errorinfo);
								ilsctx.setVariable('errorStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error("eamsr_32 :Forbidden error returned from feederGetApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
								session.reject("eamsr_32 :Forbidden error returned from feederGetApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from feederGetApi details are : " + info + "error info" + JSON.stringify(error)
								ilsctx.setVariable('errorStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "feederGetApi urlopen  statusCode:" + responseStatusCode + " " + responseData + "details are :" + info;
								ilsctx.setVariable('errorStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
		}

		function LookUpCall(lookupURL, Payload) {
			var options = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: Payload
			}
			var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
			urlopen.open(options, function(error, response) {
				if (error) {
					var errorinfo = "urlopen connect error details are " + info + "error details :" + JSON.stringify(error);
					ilsctx.setVariable('errorStatus', "500");
					ilsctx.setVariable('ExitDescription', errorinfo);
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in getting response details are " + info + "error details :" + JSON.stringify(error);
								ilsctx.setVariable('errorStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								//ilsctx.setVariable('exitStatus', "0");
								//ilsctx.setVariable('ExitDescription', ExitDescription);
								hm.response.statusCode = '200 OK';
								logger.debug("response received :" + JSON.stringify(responseData));
								ctx.setVariable("LookUpResponse", responseData)
								if (responseData.lookupRep.type[0].result == 1) {
									var errorinfo = "Invalid LookUp Request and JobTypeID is : " + jobTypeID + "details are :" + info
									ilsctx.setVariable('exitStatus', "500");
									ilsctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo)
									ctx.setVariable("externalCallCodeID", '')
								} else {
									var externalCallCodeID = responseData.lookupRep.type[0].label
									ctx.setVariable("externalCallCodeID", externalCallCodeID)
								}

							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading response details are " + info + "error details :" + JSON.stringify(error);
								ilsctx.setVariable('errorStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.current.statusCode = responseStatusCode;
								var errorinfo = "Error returned  " + ": with statusCode " + responseStatusCode + " " + responseData + "details are :" + info;
								ilsctx.setVariable('exitStatus', responseStatusCode);
								ilsctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
							}
						});
					}
				}
			});
		}

	}
});
