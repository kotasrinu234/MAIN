<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/json"
extension-element-prefixes="dp" exclude-result-prefixes="dp">
	<xsl:output method="xml" />
	<xsl:template match="/">
		<dp:set-variable name="'var://context/followUpOrder/Input'" value="." />
		<xsl:variable name="action" select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/@action)"/>
		<xsl:variable name="Description" select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[local-name()='DESCRIPTION']/text())"/>
		<xsl:variable name="externalID" select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[ local-name()='DTE_EXTERNALID']/text())"/>
		<xsl:variable name="dtetasktype" select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[ local-name()='DTE_TASKTYPE']/text())"/>
		<xsl:variable name="lead" select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[ local-name()='LEAD']/text())"/>
		<xsl:variable name="status" select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[ local-name()='STATUS']/text())"/>
		<xsl:variable name="TargCompDate" select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[ local-name()='TARGCOMPDATE']/text())"/>
		<xsl:variable name="WONum" select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[ local-name()='WONUM']/text())"/>
		<xsl:choose>
			<xsl:when test ="string-length($externalID) &gt; 0">
				<xsl:value-of select="$externalID" />
				<dp:set-variable name="'var://context/followUpOrder/externalID'" value="$externalID" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">eamsr_050 externalID Id not found</xsl:message>
				<dp:reject>externalID Id not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($Description) &gt; 0">
				<dp:set-variable name="'var://context/followUpOrder/Description'" value="$Description" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">eamsr_051 Description not found</xsl:message>
				<dp:reject> Description not found </dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($action) &gt; 0">
				<dp:set-variable
			name="'var://context/followUpOrder/action'" value="$action" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">eamsr_052 action not found</xsl:message>
				<dp:reject> action not found </dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($dtetasktype) &gt; 0">
				<dp:set-variable
			name="'var://context/followUpOrder/dtetasktype'" value="$dtetasktype" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">eamsr_053 dtetasktype not found</xsl:message>
				<dp:reject>dtetasktype not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
				<dp:set-variable
			name="'var://context/followUpOrder/lead'" value="$lead" />
			<dp:set-variable
			name="'var://context/followUpOrder/status'" value="$status" />
			<dp:set-variable
			name="'var://context/followUpOrder/TargCompDate'" value="$TargCompDate" />
			<dp:set-variable
			name="'var://context/followUpOrder/WONum'" value="$WONum" />
	</xsl:template>
</xsl:stylesheet>
