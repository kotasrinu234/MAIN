<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:msg="http://esm.dteco.com/common/v1" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig">
<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>

	<xsl:param name="dpconfig:ExitDescription" select="''" />
	<xsl:param name="dpconfig:StepExitDescription" select="''" />
	<xsl:param name="dpconfig:EntryDescription" select="''" />
	<xsl:param name="dpconfig:messageType" select="''" />
		<xsl:template match="/">
		<xsl:variable name="description">
			<xsl:value-of select="$dpconfig:EntryDescription" />
		</xsl:variable>
		<xsl:variable name="exitdescription">
			<xsl:value-of select="$dpconfig:ExitDescription" />
		</xsl:variable>
		<xsl:variable name="stepexitdescription">
			<xsl:value-of select="$dpconfig:StepExitDescription" />
		</xsl:variable>
		<xsl:variable name="messageType">
			<xsl:value-of select="$dpconfig:messageType" />
		</xsl:variable>
		<xsl:variable name="correlationID">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='PublishDTEOMSWORKORDER']/@messageID">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTEOMSWORKORDER']/@messageID)" />
				</xsl:when>
				<xsl:when
					test="/*[local-name()='PublishDTESRFOLLOWUP']/@messageID">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTESRFOLLOWUP']/@messageID)" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of
						select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='CreateDTESROBJINResponse']/@messageID)" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="jobID">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[ local-name()='DTE_EXTERNALID']">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[ local-name()='DTE_EXTERNALID']/text())" />
				</xsl:when>
				<xsl:when
					test="/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/*[ local-name()='DTE_EXTERNALID']">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/*[ local-name()='DTE_EXTERNALID']/text())" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of
						select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/*[ local-name()='faultstring']/text())" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="maximoID">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[local-name()='SR']/*[local-name()='TICKETID']">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[local-name()='SR']/*[local-name()='TICKETID'])" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of
						select="string(/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/*[local-name()='TICKETID'])" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="status">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/@action">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/@action)" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of
						select="string(/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/@action)" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="workOrderNumber">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM']">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTEOMSWORKORDER']/*[local-name()='DTEOMSWORKORDERSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM'])" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="''" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="sourceEventTimestamp">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='PublishDTEOMSWORKORDER']/@creationDateTime">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTEOMSWORKORDER']/@creationDateTime)" />
				</xsl:when>
				<xsl:when
					test="/*[local-name()='PublishDTESRFOLLOWUP']/@creationDateTime">
					<xsl:value-of
						select="string(/*[local-name()='PublishDTESRFOLLOWUP']/@creationDateTime)" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of
						select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='CreateDTESROBJINResponse']/@creationDateTime)" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<dp:set-variable
			name="'var://context/ILS/correlationID'" value="$correlationID" />
		<dp:set-variable
			name="'var://context/ILS/entryDescription'" value="$description" />
		<dp:set-variable
			name="'var://context/ILS/stepexitdescription'"
			value="$stepexitdescription" />
		<dp:set-variable
			name="'var://context/ILS/exitDescription'" value="$exitdescription" />
		<dp:set-variable name="'var://context/ILS/jobID'"
			value="$jobID" />
		<dp:set-variable name="'var://context/ILS/status'"
			value="$status" />
		<dp:set-variable name="'var://context/ILS/maximoID'"
			value="$maximoID" />
		<dp:set-variable
			name="'var://context/ILS/workOrderNumber'" value="$workOrderNumber" />
		<dp:set-variable
			name="'var://context/ILS/sourceEventTimestamp'"
			value="$sourceEventTimestamp" />
			<dp:set-variable
			name="'var://context/ILS/messageType'"
			value="$messageType" />
 
	</xsl:template>
</xsl:stylesheet>
