<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" extension-element-prefixes="dp" exclude-result-prefixes="dp">
    <xsl:template match="/">
        <xsl:variable name="TransactionID">
            <xsl:copy-of select="dp:variable('var://service/global-transaction-id')"/>
        </xsl:variable>
        <xsl:choose>
            <xsl:when test="contains(dp:variable('var://service/error-code'),'0x00230001' ) or contains(dp:variable('var://service/error-code'),'0x00030001') or contains(dp:variable('var://context/csyn/schemafailed'),'yes') or contains(dp:variable('var://service/error-code'),'0x0213000e') or contains(dp:variable('var://service/error-code'),'0x00c30025') or contains(dp:variable('var://service/error-code'),'0x0213000a')">
                <dp:set-variable name="'var://service/error-protocol-response'" value="'400'"/>
                <dp:set-variable name="'var://context/ILS/exitstatus'" value="'400'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')"/>
                <xsl:message dp:type="all" dp:priority="error">
                    <xsl:value-of select="dp:variable('var://service/error-message')"/>eamsr_36 in service eamsr_UpdateOrderStatus_v2 with error code
                    <xsl:value-of select="dp:variable('var://service/error-code')"/></xsl:message>
            </xsl:when>
           <!--   <xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
                <xsl:message dp:type="all" dp:priority="error">
                    eamsr_36: AAA failure for Maximo Unauthorized error for username:
                    <xsl:value-of select="dp:variable('var://context/WSM/identity/username')"/>
                    ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>TransactionID:<xsl:value-of select="$TransactionID"/>
                </xsl:message>
                <dp:set-variable name="'var://context/ILS/exitstatus'" value="'401'"/>
                <dp:set-variable name="'var://service/error-protocol-response'" value="'401'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'"/>
            </xsl:when> -->
            <xsl:when test="contains(dp:variable('var://service/error-code'),'0x01130006')">
                <xsl:message dp:type="all" dp:priority="error">
                    TransactionID:<xsl:value-of select="$TransactionID"/>
                    ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
                </xsl:message>
                <dp:set-variable name="'var://context/ILS/exitstatus'" value="'502'"/>
                <dp:set-variable name="'var://service/error-protocol-response'" value="'502'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Gateway'"/>
            </xsl:when>
        </xsl:choose>
    </xsl:template>
</xsl:stylesheet>
