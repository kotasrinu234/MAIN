<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/json"
extension-element-prefixes="dp" exclude-result-prefixes="dp">
	<xsl:output method="xml" />
	<xsl:template match="/">
		<dp:set-variable name="'var://context/followUpOrder/Input'" value="." />
		<xsl:variable name="maxvalue" select="string(/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/*[local-name()='STATUS']/@maxvalue)"/>
		<xsl:variable name="status" select="string(/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/*[local-name()='STATUS']/text())"/>
		<xsl:variable name="externalID" select="string(/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/*[ local-name()='DTE_EXTERNALID']/text())"/>
		<xsl:variable name="workType" select="string(/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/*[ local-name()='DTE_TICKET']/*[ local-name()='DTE_WORKTYPE']/text())"/>
		<xsl:variable name="dteSubType" select="string(/*[local-name()='PublishDTESRFOLLOWUP']/*[local-name()='DTESRFOLLOWUPSet']/*[local-name()='SR']/*[ local-name()='DTE_TICKET']/*[ local-name()='DTE_SUBTYPE']/text())"/>
		<xsl:choose>
			<xsl:when test ="string-length($externalID) &gt; 0">
				<xsl:value-of select="$externalID" />
				<dp:set-variable name="'var://context/followUpOrder/externalID'" value="$externalID" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">eamsr_034 externalID Id not found</xsl:message>
				<dp:reject>externalID Id not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<dp:set-variable name="'var://context/followUpOrder/maxvalue'" value="$maxvalue" />
		<dp:set-variable name="'var://context/followUpOrder/status'" value="$status" />
		<dp:set-variable name="'var://context/followUpOrder/workType'" value="$workType" />
		<dp:set-variable name="'var://context/followUpOrder/dteSubType'" value="$dteSubType" />

	</xsl:template>
</xsl:stylesheet>
