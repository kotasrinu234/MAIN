var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var ictx = session.name("ILS") || session.createContext("ILS");
var urlopen = require('urlopen');
var ErrorQueue = require('./urlopenutil.js');
var apiToken = ctx.getVariable("apiToken");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var externalID = ctx.getVariable("externalID");
var Description = ctx.getVariable("Description");
var action = ctx.getVariable("action");
var dtetasktype = ctx.getVariable("dtetasktype");
var lead = ctx.getVariable("lead");
var status = ctx.getVariable("status");
var Input = ctx.getVariable("Input");
var TargCompDate = ctx.getVariable("TargCompDate");
var logger = console.options({
	'category': 'all'
});
var exitpayload = {}
ictx.setVariable('exitpayload', exitpayload);
if (action == 'Replace' || action == 'Add') {
	var URL = omsExternalURL + '/api/ServiceType/Electric/Job/' + externalID;
	var Joboptions = {
		target: URL,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "oms_Client_Profile"
	};

	var info = " TargetURL :" + Joboptions.target + "; Method :" + Joboptions.method + ". ";

	urlopen.open(Joboptions, function(error, response) {
		if (error) {
			// an error occurred during reading the file
			var errorinfo = "eamsr_058 urlopen error, details are : " + info + "; error info :" + JSON.stringify(error)
			ictx.setVariable("exitDescription", errorinfo);
			ictx.setVariable("exitDestination", URL)
			ictx.setVariable("exitstatus", "500")
			logger.error(errorinfo);
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			ctx.setVariable("responseStatusCode", responseStatusCode);
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					var id = responseData.id;
					if (id === null || id === '' || id === undefined) {
						//need to confirm this
						logger.error("eamsr_060 id not found");
						session.reject("id not found")
					} else {
						ctx.setVariable("id", id);
					}
					var jobTypeID = responseData.jobTypeID;
					if (jobTypeID === null || jobTypeID === '' || jobTypeID === undefined) {
						//need to confirm this
						logger.error("eamsr_061 jobTypeID not found");
						session.reject("jobTypeID not found")
					} else {
						ctx.setVariable("jobTypeID", jobTypeID);
					}
					var Status = responseData.status;
					if (Status === null || Status === '' || Status === undefined) {
						logger.error("Status not found");
						session.reject("Status not found")
					} else {
						ctx.setVariable("Job_Status", Status);
					}
					var commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/Comment';
					var Payload = {
						"comment": Description
					}
					var options = {
						target: commentURL,
						method: "post",
						headers: {
							"osiApiToken": apiToken
						},
						contentType: "application/json",
						sslClientProfile: "oms_Client_Profile",
						data: Payload
					};
					ictx.setVariable("exitpayload", JSON.stringify(options.data))
					var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";

					urlopen.open(options, function(error, response) {
						if (error) {
							// an error occurred during reading the file
							var errorinfo = "eamsr_054 comment urlopen error, details are : " + info + "; error info :" + JSON.stringify(error)
							ictx.setVariable("exitDescription", errorinfo);
							ictx.setVariable("exitDestination", commentURL)
							ictx.setVariable("exitstatus", "500")
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							ctx.setVariable("responseStatusCode", responseStatusCode);
							if (responseStatusCode != 200) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										var errorinfo = "failure in reading message from commentapi, details are : " + info + "; error info :" + JSON.stringify(error)
										ictx.setVariable("exitDescription", errorinfo);
										ictx.setVariable("exitDestination", commentURL)
										ictx.setVariable("exitstatus", responseStatusCode)
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										ctx.setVariable("Break", 'Yes');
										var errorinfo = "eamsr_055 comment response is  " + responseStatusCode + responseData + "  " + 'MaximoReq :' + XML.stringify(Input) + "details are:" + info
										ictx.setVariable("exitDescription", errorinfo);
										ictx.setVariable("exitDestination", commentURL)
										ictx.setVariable("exitstatus", responseStatusCode)
										logger.error(errorinfo);
										//session.reject("comment  response is " + responseStatusCode + " " + responseData);
										ErrorQueue(Input);
									}
								});
							} else if ((responseStatusCode == 401)) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "eamsr_13 : Unauthorized error message while reading response from post call commentapi , details are : " + info + "; error info :" + JSON.stringify(error)
										ctx.setVariable("errormessage", errorinfo);
										ictx.setVariable("exitstatus", responseStatusCode)
										ictx.setVariable("exitDescription", errorinfo);
										logger.error("eamsr_13 : error message while reading response from post call commentapi, details are : " + info + "; error info :" + JSON.stringify(error));
										session.reject("eamsr_13 : error message while reading response from post call commentapi, details are : " + info + "; error info :" + JSON.stringify(error));
									} else {
										var errorinfo = "eamsr_13 : Unauthorized error message while reading response from post call commentapi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ctx.setVariable("errormessage", errorinfo);
										ictx.setVariable("exitstatus", responseStatusCode)
										ictx.setVariable("exitDescription", errorinfo);
										logger.error("eamsr_13 : Unauthorized Error returned from post call commentapi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
										session.reject("eamsr_13 : Unauthorized Error returned from post call commentapi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
									}
								});
							} else if ((responseStatusCode == 403)) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "eamsr_14 :Forbidden error message while reading response from post call commentapi , details are : " + info + "; error info :" + JSON.stringify(error)
										ctx.setVariable("errormessage", errorinfo);
										ictx.setVariable("exitstatus", responseStatusCode)
										ictx.setVariable("exitDescription", errorinfo);
										logger.error("eamsr_14 :Forbidden error message while reading response from post call commentapi, details are : " + info + "; error info :" + JSON.stringify(error));
										session.reject("eamsr_14 :Forbidden error message while reading response from post call commentapi, details are : " + info + "; error info :" + JSON.stringify(error));
									} else {
										var errorinfo = "eamsr_14 :Forbidden error message while reading response from post call commentapi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ctx.setVariable("errormessage", errorinfo);
										ictx.setVariable("exitstatus", responseStatusCode)
										ictx.setVariable("exitDescription", errorinfo);
										logger.error("eamsr_14 :Forbidden error returned from post call commentapi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
										session.reject("eamsr_14 :Forbidden error returned from post call commentapi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
									}
								});
							} else {
								console.log("response code of commentApi call :" + responseStatusCode);

							}
						}
					});
				});
			} else if ((responseStatusCode == 401)) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "eamsr_15 : Unauthorized error message while reading response from externalID JobAPI , details are : " + info + "; error info :" + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						ictx.setVariable("exitstatus", responseStatusCode)
						ictx.setVariable("exitDescription", errorinfo);
						logger.error("eamsr_15 : error message while reading response from externalID JobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
						session.reject("eamsr_15 : error message while reading response from externalID JobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
					} else {
						var errorinfo = "eamsr_15 : Unauthorized error message while reading response from externalID JobAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable("errormessage", errorinfo);
						ictx.setVariable("exitstatus", responseStatusCode)
						ictx.setVariable("exitDescription", errorinfo);
						logger.error("eamsr_15 : Unauthorized Error returned from externalID JobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						session.reject("eamsr_15 : Unauthorized Error returned from externalID JobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					}
				});
			} else if ((responseStatusCode == 403)) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "eamsr_16 :Forbidden error message while reading response from externalID JobAPI , details are : " + info + "; error info :" + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						ictx.setVariable("exitstatus", responseStatusCode)
						ictx.setVariable("exitDescription", errorinfo);
						logger.error("eamsr_16 :Forbidden error message while reading response from externalID JobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
						session.reject("eamsr_16 :Forbidden error message while reading response from externalID JobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
					} else {
						var errorinfo = "eamsr_16 :Forbidden error message while reading response from externalID JobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable("errormessage", errorinfo);
						ictx.setVariable("exitstatus", responseStatusCode)
						ictx.setVariable("exitDescription", errorinfo);
						logger.error("eamsr_16 :Forbidden error returned from externalID JobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						session.reject("eamsr_16 :Forbidden error returned from externalID JobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from JobAPI, details are : " + info + "; error info :" + JSON.stringify(error)
						ictx.setVariable("exitDescription", errorinfo);
						ictx.setVariable("exitDestination", URL)
						ictx.setVariable("exitstatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);

					} else {
						ctx.setVariable("Break", 'Yes');
						var errorinfo = "eamsr_067 JobAPI response is  " + responseStatusCode + info + " " + responseData + "  " + 'MaximoReq :' + XML.stringify(Input)
						ictx.setVariable("exitDescription", errorinfo);
						ictx.setVariable("exitDestination", URL)
						ictx.setVariable("exitstatus", responseStatusCode)
						logger.error("eamsr_067 JobAPI response is  " + responseStatusCode + info + " " + responseData + "  " + 'MaximoReq :' + XML.stringify(Input));
						//session.reject("JobAPI  response is " + responseStatusCode + " " + responseData);
						ErrorQueue(Input);
					}
				});
			}
		}

	});
} else {
	var errorinfo = "eamsr_069 action is not Replace/Add, details are : " + info
	ictx.setVariable("exitDescription", errorinfo);
	ictx.setVariable("exitDestination", URL)
	ictx.setVariable("exitstatus", "500")
	logger.error(errorinfo);
	session.reject(errorinfo);
}
