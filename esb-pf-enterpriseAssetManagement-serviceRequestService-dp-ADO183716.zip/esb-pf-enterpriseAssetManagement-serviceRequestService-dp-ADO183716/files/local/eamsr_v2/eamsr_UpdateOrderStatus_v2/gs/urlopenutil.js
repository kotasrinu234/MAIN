var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var hm = require('header-metadata');
var sm = require('service-metadata');
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var Id = ctx.getVariable("Id");
var callType = ctx.getVariable("callType");
var premiseid = ctx.getVariable("premiseid");
var queueName = session.parameters.queueName;
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});

function ErrorQueue(input) {
	var options = {
		target: queueName,
		data: input,
	};
	var info = "TargetUrl" + options.target + "method" + "post" + "data" + XML.stringify(input)
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = 'Mqurlopen.open error details are :' + info
				ilsctx.setVariable('exitdescription', errorinfo);
				ilsctx.setVariable('exitstatus', '500')
				logger.error(errorinfo);
				session.reject(errorinfo);
				hm.response.statusCode = 500
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
						} else {
							console.log("MQResponseData" + responseData);
							ilsctx.setVariable('exitdescription', session.parameters.StepExitDescription);
							ilsctx.setVariable('exitdestination', queueName);
							ilsctx.setVariable('exitStatus', '0')
							ms.callRule('eamsr_UpdateOrderStatus_V2_Policy_StepExit_rule', null, null, function(error) {
								if (error) {
									logger.error("eamsr_UpdateOrderStatus_V2_Policy_StepExit_rule");
								}
							});
						}
					});
				} else {
					var errorinfo = 'Mqurlopen.open error details are :' + info
					ilsctx.setVariable('exitdescription', errorinfo);
					ilsctx.setVariable('exitstatus', mqrc)
					logger.error(errorinfo);
					session.reject(errorinfo);
					hm.response.statusCode = 500
				}
			}
		});
	} catch (err) {

		ilsctx.setVariable('exitstatus', "500")
		session.reject('Mqurlopen.open error details are :' + info);
	}
}

module.exports = ErrorQueue;
