var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var ictx = session.name("ILS") || session.createContext("ILS");
var ErrorQueue = require('./urlopenutil.js');
var hm = require('header-metadata');
var apiToken = ctx.getVariable("apiToken");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var lookupURL = ctx.getVariable("lookupURL");
var maxvalue = ctx.getVariable("maxvalue");
var status = ctx.getVariable("status");
var Job_Status = ctx.getVariable("Job_Status");
var jobTypeID = ctx.getVariable("jobTypeID");
var lookUpstatus = ctx.getVariable("lookUpstatus");
var externalID = ctx.getVariable("externalID");
var id = ctx.getVariable("id");
var Break = ctx.getVariable("Break");
var Input = ctx.getVariable("Input");
var urlopen = require('urlopen');
var flag;
var logger = console.options({
	'category': 'all'
});
var exitpayload = ictx.getVariable("exitpayload")
console.log("maxvalue :" + maxvalue);
console.log("status :" + status);
if (Break != 'Yes') {
	if ((maxvalue.trim() == 'CLOSED') || ((maxvalue.trim() == 'RESOLVED') && (status.trim() == 'RESOLVED'))) {
		var flag = 'closed';
	} else if ((maxvalue.trim() == 'RESOLVED') && (status.trim() == 'CLEAR')) {
		var flag = 'resolved';
	}
	if (flag === 'closed' || flag === 'resolved') {
		//logger.error("inside flag");
		if (flag === 'resolved') {
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "jobTypes.workflows",
						"id": jobTypeID,
						"label": "Canceled"
					}]
				}
			}
		} else {
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "jobTypes.workflows",
						"id": jobTypeID,
						"label": "Completed"
					}]
				}
			}
		}
		var LookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		//exitpayload = LookupServiceResponse.data
		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
		urlopen.open(LookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "eamsr_043 lookup urlopen error, details are : " + info + "; error info :" + JSON.stringify(error)
				ictx.setVariable("exitDescription", errorinfo);
				//ictx.setVariable("exitDestination",lookupURL)
				ictx.setVariable("exitstatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "eamsr_044 failure in putting message to LookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error)
							ictx.setVariable("exitDescription", errorinfo);
							//ictx.setVariable("exitDestination",lookupURL)
							ictx.setVariable("exitstatus", "0")
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = responseStatusCode;
							console.log("response received from LookupServiceResponse " + JSON.stringify(responseData));
							if (responseData.lookupRep.type[0].result == 0) {
								var lookUpstatus = responseData.lookupRep.type[0].status;
								console.log("lookUpstatus:" + lookUpstatus);
								if (Job_Status == lookUpstatus) {
									logger.debug('Job status is already ' + lookUpstatus);
								} else {
									var statusURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/WorkFlow';
									var workflowoptions = {
										target: statusURL,
										method: "post",
										headers: {
											"osiApiToken": apiToken
										},
										contentType: "application/json",
										sslClientProfile: "oms_Client_Profile",
										data: lookUpstatus
									};
									exitpayload = lookUpstatus
									var info = " TargetURL :" + workflowoptions.target + "; Method :" + workflowoptions.method + "; Data :" + JSON.stringify(workflowoptions.data) + ". ";

									urlopen.open(workflowoptions, function(error, response) {
										if (error) {
											// an error occurred during reading the file
											var errorinfo = "eamsr_045 workflow urlopen error, details are : " + info + "; error info :" + JSON.stringify(error)
											ictx.setVariable("exitDescription", errorinfo);
											ictx.setVariable("exitDestination", statusURL)
											ictx.setVariable("exitstatus", "500")
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var responseStatusCode = response.statusCode;
											ctx.setVariable("responseStatusCode", responseStatusCode);
											console.log("responseStatusCode" + responseStatusCode);
											//hm.response.statusCode = responseStatusCode;
											if (responseStatusCode != 200) {
												hm.response.statusCode = responseStatusCode;
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														//dp:reject stop the transaction and go error rule with error code and description
														var errorinfo = "failure in reading message from workflowApi, details are : " + info + "; error info :" + JSON.stringify(error)
														ictx.setVariable("exitDescription", errorinfo);
														ictx.setVariable("exitDestination", statusURL)
														ictx.setVariable("exitstatus", responseStatusCode)
														logger.error(errorinfo);
														session.reject(errorinfo);

													} else {
														var errorinfo = "eamsr_046 workflowApi :" + info + ";response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode + 'MaximoReq :' + XML.stringify(Input) + "details are:" + info
														logger.error(errorinfo);
														ictx.setVariable("exitDescription", errorinfo);
														ictx.setVariable("exitDestination", statusURL)
														ictx.setVariable("exitstatus", responseStatusCode)
														//session.reject("workflowApi  response is " + responseStatusCode + " " + responseData);
														ErrorQueue(Input);
													}
												});
											}
											else if ((responseStatusCode == 401)) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "eamsr_07 : Unauthorized error message while reading response from workflowApi , details are : " + info + "; error info :" + JSON.stringify(error)
														ctx.setVariable("errormessage", errorinfo);
														ictx.setVariable("exitstatus", responseStatusCode)
																ictx.setVariable("exitDescription", errorinfo);
														logger.error("eamsr_07 : error message while reading response from workflowApi, details are : " + info + "; error info :" + JSON.stringify(error));
														session.reject("eamsr_07 : error message while reading response from workflowApi, details are : " + info + "; error info :" + JSON.stringify(error));
													} else {
														var errorinfo = "eamsr_07 : Unauthorized error message while reading response from workflowApi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														ctx.setVariable("errormessage", errorinfo);
														ictx.setVariable("exitstatus", responseStatusCode)
																ictx.setVariable("exitDescription", errorinfo);
														logger.error("eamsr_07 : Unauthorized Error returned from workflowApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
														session.reject("eamsr_07 : Unauthorized Error returned from workflowApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
													}
												});
											} else if ((responseStatusCode == 403)) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "eamsr_08 :Forbidden error message while reading response from workflowApi , details are : " + info + "; error info :" + JSON.stringify(error)
														ctx.setVariable("errormessage", errorinfo);
														ictx.setVariable("exitstatus", responseStatusCode)
																ictx.setVariable("exitDescription", errorinfo);
														logger.error("eamsr_08 :Forbidden error message while reading response from workflowApi, details are : " + info + "; error info :" + JSON.stringify(error));
														session.reject("eamsr_08 :Forbidden error message while reading response from workflowApi, details are : " + info + "; error info :" + JSON.stringify(error));
													} else {
														var errorinfo = "eamsr_08 :Forbidden error message while reading response from workflowApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														ctx.setVariable("errormessage", errorinfo);
														ictx.setVariable("exitstatus", responseStatusCode)
																ictx.setVariable("exitDescription", errorinfo);
														logger.error("eamsr_08 :Forbidden error returned from workflowApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
														session.reject("eamsr_08 :Forbidden error returned from workflowApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
													}
												});
											}
										}
									});
								}
							} else {
								var errorinfo = "eamsr_047 result is not 0 for lookup response for status  " + info + 'MaximoReq :' + XML.stringify(Input) + "details are:" + info;
								logger.error(errorinfo);
								ictx.setVariable("exitDescription", errorinfo);
								ictx.setVariable("exitDestination", statusURL)
								ictx.setVariable("exitstatus", responseStatusCode)
								//session.reject("result is not 0 for lookup response for status");
								ErrorQueue(Input);
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from lookup call, details are : " + info + "; error info :" + JSON.stringify(error)
							ictx.setVariable("exitDescription", errorinfo);
							ictx.setVariable("exitstatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							//hm.response.statusCode = responseStatusCode;
							var errorinfo = "eamsr_048 lookup urlopen, details are:" + info + "statusCode:" + responseStatusCode + " " + responseData + "  " + 'MaximoReq :' + XML.stringify(Input) + "details are :" + info
							logger.error(errorinfo);
							ictx.setVariable("exitDescription", errorinfo);
							ictx.setVariable("exitstatus", responseStatusCode)
							//session.reject("lookup urlopen statusCode: " + responseStatusCode + " " + responseData);
							ErrorQueue(Input);
						}
					});
				}
			}
		});
	}
}
session.output.write(exitpayload)
