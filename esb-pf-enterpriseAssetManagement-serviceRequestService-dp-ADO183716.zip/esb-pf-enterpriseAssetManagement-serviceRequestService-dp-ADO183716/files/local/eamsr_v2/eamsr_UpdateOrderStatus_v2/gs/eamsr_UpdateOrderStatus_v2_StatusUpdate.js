var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var ictx = session.name("ILS") || session.createContext("ILS");
var ErrorQueue = require('./urlopenutil.js');
var hm = require('header-metadata');
var apiToken = ctx.getVariable("apiToken");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var lookupURL = ctx.getVariable("lookupURL");
var maxvalue = ctx.getVariable("maxvalue");
var status = ctx.getVariable("status");
var lookUpstatus = ctx.getVariable("lookUpstatus");
var externalID = ctx.getVariable("externalID");
var dteSubType = ctx.getVariable("dteSubType");
var workType = ctx.getVariable("workType");
var Input = ctx.getVariable("Input");
var urlopen = require('urlopen');
var URL = '';
var flag;
console.log("maxvalue :" + maxvalue);
console.log("status :" + status);
var logger = console.options({
	'category': 'all'
});

if ((maxvalue.trim() == 'CLOSED') || ((maxvalue.trim() == 'RESOLVED') && (status.trim() == 'RESOLVED'))) {
	var flag = 'closed';
	var updateComment = {
		"comment": "Job Closed as SR is Closed in Maximo"
	}
	URL = omsExternalURL + '/api/ServiceType/Electric/Job/' + externalID;
} else if ((maxvalue.trim() == 'RESOLVED') && (status.trim() == 'CLEAR')) {
	var flag = 'resolved';
	var updateComment = {
		"comment": "Job Cancelled as SR is cancelled in Maximo"
	}
	URL = omsExternalURL + '/api/ServiceType/Electric/Job/' + externalID;
} else {
	// logger.error("else part");
	var check = 'Update'
	var updateComment = {
		"comment": 'Jobtype/SubType Updated in Maximo to ' + workType + '/' + dteSubType
	}
	URL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + externalID;
}
var exitpayload = {}
ictx.setVariable('exitpayload', exitpayload);
console.log("flag :" + flag);
var options = {
	target: URL,
	method: "get",
	headers: {
		"osiApiToken": apiToken
	},
	contentType: "application/json",
	sslClientProfile: "oms_Client_Profile"
};

var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
urlopen.open(options, function(error, response) {
	if (error) {
		// an error occurred during reading the file
		var errorinfo = "eamsr_038 JobAPI urlopen error of 'omsExternalURL', details are : " + info + "; error info :" + JSON.stringify(error);
		ictx.setVariable("exitDescription", errorinfo);
		ictx.setVariable("exitDestination", URL)
		ictx.setVariable("exitstatus", "500")
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {
		var responseStatusCode = response.statusCode;
		ctx.setVariable("responseStatusCode", responseStatusCode);
		if (responseStatusCode == 200) {
			response.readAsJSON(function(error, responseData) {
				if (error) {
					var errorinfo = "readAsJSONError details are :" + info
					ictx.setVariable("exitDescription", errorinfo);
					ictx.setVariable("exitDestination", URL)
					ictx.setVariable("exitstatus", responseStatusCode)
					// error while reading response or transferring data to Buffer
					session.output.write(readAsJSONError);
				} else {
					var id = responseData.id;
					if (id === null || id === '' || id === undefined) {
						logger.error("eamsr_039 id not found");
						session.reject("id not found")
					} else {
						ctx.setVariable("id", id);
					}
					var jobTypeID = responseData.jobTypeID;
					if (jobTypeID === null || jobTypeID === '' || jobTypeID === undefined) {
						logger.error("eamsr_040 jobTypeID not found");
						session.reject("jobTypeID not found")
					} else {
						ctx.setVariable("jobTypeID", jobTypeID);
					}
					var Status = responseData.status;
					if (Status === null || Status === '' || Status === undefined) {
						logger.error("Status not found");
						session.reject("Status not found")
					} else {
						ctx.setVariable("Job_Status", Status);
					}
					ictx.setVariable("exitDescription", session.parameters.ExitDescription);
					ictx.setVariable("exitDestination", URL)
					ictx.setVariable("exitstatus", "0")
					var commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/Comment';
					var options = {
						target: commentURL,
						method: "post",
						headers: {
							"osiApiToken": apiToken
						},
						contentType: "application/json",
						sslClientProfile: "oms_Client_Profile",
						data: updateComment
					};
					ictx.setVariable('exitpayload', JSON.stringify(options.data));
					var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
					urlopen.open(options, function(error, response) {
						if (error) {
							// an error occurred during reading the file
							var errorinfo = "eamsr_041 comment urlopen error, details are : " + info + "; error info :" + JSON.stringify(error)
							ictx.setVariable("exitDescription", errorinfo);
							ictx.setVariable("exitDestination", URL)
							ictx.setVariable("exitstatus", "500")
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							ctx.setVariable("responseStatusCode", responseStatusCode);
							if (responseStatusCode == 200) {
								var success = success;
								console.log("commentApi call responseCode : " + responseStatusCode);
								if (check == 'Update') {
									var URL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id;
									var payload = {
										"customFieldValues": {
											"Maximo_Jobtype": workType,
											"Maximo_Subtype": dteSubType
										}
									}
									var Patchoptions = {
										target: URL,
										method: "PATCH",
										headers: {
											"osiApiToken": apiToken
										},
										contentType: "application/json",
										sslClientProfile: "oms_Client_Profile",
										data: payload
									};
									ictx.setVariable('exitpayload', JSON.stringify(Patchoptions.data));
									var info = " TargetURL :" + Patchoptions.target + "; Method :" + Patchoptions.method + "; Data :" + JSON.stringify(Patchoptions.data) + ". ";

									urlopen.open(Patchoptions, function(error, response) {
										if (error) {
											// an error occurred during reading the file
											var errorinfo = "urlopen error, details are : " + info + "; error info :" + JSON.stringify(error)
											ictx.setVariable("exitDescription", errorinfo);
											ictx.setVariable("exitDestination", URL)
											ictx.setVariable("exitstatus", "500")
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var responseStatusCode = response.statusCode;
											ctx.setVariable("responseStatusCode", responseStatusCode);
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													//dp:reject stop the transaction and go error rule with error code and description
													var errorinfo = "failure in reading message from PatchJobAPI, details are : " + info + "; error info :" + JSON.stringify(error)
													ictx.setVariable("exitDescription", errorinfo);
													ictx.setVariable("exitDestination", URL)
													ictx.setVariable("exitstatus", responseStatusCode)
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													if ((responseStatusCode == 200) || (responseStatusCode == 400 && responseData == 'No updates')) {
														//hm.response.statusCode = responseStatusCode;
														logger.info("response received from patch call api " + JSON.stringify(responseData));
													} else if ((responseStatusCode == 401)) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "eamsr_01 : Unauthorized error message while reading response from PatchJobAPI call, details are : " + info + "; error info :" + JSON.stringify(error)
																ctx.setVariable("errormessage", errorinfo);
																ictx.setVariable("exitstatus", responseStatusCode)
																ictx.setVariable("exitDescription", errorinfo);
																logger.error("eamsr_01 : error message while reading response from PatchJobAPI call, details are : " + info + "; error info :" + JSON.stringify(error));
																session.reject("eamsr_01 : error message while reading response from PatchJobAPI call, details are : " + info + "; error info :" + JSON.stringify(error));
															} else {
																var errorinfo = "eamsr_01 : Unauthorized error message while reading response from PatchJobAPI call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																ctx.setVariable("errormessage", errorinfo);
																ictx.setVariable("exitstatus", responseStatusCode)
																ictx.setVariable("exitDescription", errorinfo);
																logger.error("eamsr_01 : Unauthorized Error returned while doing PatchJobAPI call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																session.reject("eamsr_01 : Unauthorized Error returned while doing PatchJobAPI call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
															}
														});
													} else if ((responseStatusCode == 403)) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "eamsr_02 :Forbidden error message while reading response from PatchJobAPI , details are : " + info + "; error info :" + JSON.stringify(error)
																ctx.setVariable("errormessage", errorinfo);
																ictx.setVariable("exitstatus", responseStatusCode)
																ictx.setVariable("exitDescription", errorinfo);
																logger.error("eamsr_02 :Forbidden error message while reading response from PatchJobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
																session.reject("eamsr_02 : error message while reading response from PatchJobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
															} else {
																var errorinfo = "eamsr_02 :Forbidden error message while reading response from PatchJobAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																ictx.setVariable("exitstatus", responseStatusCode)
																ictx.setVariable("exitDescription", errorinfo);
																ctx.setVariable("errormessage", errorinfo);
																logger.error("eamsr_02 :Forbidden error returned while doing PatchJobAPI call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
																session.reject("eamsr_02 :Forbidden error returned while doing PatchJobAPI call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
															}
														});
													} else {
														response.readAsBuffer(function(error, ErrorresponseData) {
															if (error) {
																// error while reading response or transferring data to Buffer
																var errorinfo = "failure reading response from patch call api, details are : " + info + "; error info :" + JSON.stringify(error)
																ictx.setVariable("exitDescription", errorinfo);
																ictx.setVariable("exitDestination", URL)
																ictx.setVariable("exitstatus", responseStatusCode)
																logger.error(errorinfo);
																session.output.write("failure reading response from patch call api");
															} else {
																//hm.response.statusCode = response.statusCode;
																ctx.setVariable("Break", 'Yes');
																var errorinfo = "error response from patch call api CHG" + info + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData + 'MaximoReq' + XML.stringify(Input) + "details are:" + info;
																logger.error(errorinfo);
																//session.reject("error response from patch call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData); 
																ictx.setVariable("exitDescription",errorinfo);
																ictx.setVariable("exitDestination", URL)
																ictx.setVariable("exitstatus", responseStatusCode)
																ErrorQueue(Input);
															}
														});

													}
												}
											});

										}
									});
								}
							} else if ((responseStatusCode == 401)) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "eamsr_03 : Unauthorized error message while reading response from comment post call , details are : " + info + "; error info :" + JSON.stringify(error)
										ctx.setVariable("errormessage", errorinfo);
										ictx.setVariable("exitstatus", responseStatusCode)
										ictx.setVariable("exitDescription", errorinfo);
										logger.error("eamsr_03 : error message while reading response from comment post call, details are : " + info + "; error info :" + JSON.stringify(error));
										session.reject("eamsr_03 : error message while reading response from comment post call, details are : " + info + "; error info :" + JSON.stringify(error));
									} else {
										var errorinfo = "eamsr_03 : Unauthorized error message while reading response from comment post call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ctx.setVariable("errormessage", errorinfo);
										ictx.setVariable("exitstatus", responseStatusCode)
										ictx.setVariable("exitDescription", errorinfo);
										logger.error("eamsr_03 : Unauthorized Error returned while doing post for comment call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
										session.reject("eamsr_03 : Unauthorized Error returned while doing post for comment call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
									}
								});
							} else if ((responseStatusCode == 403)) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "eamsr_04 : Forbidden error message while reading response from comment post call , details are : " + info + "; error info :" + JSON.stringify(error)
										ctx.setVariable("errormessage", errorinfo);
										ictx.setVariable("exitstatus", responseStatusCode)
										ictx.setVariable("exitDescription", errorinfo);
										logger.error("eamsr_04 : error message while reading response from comment post call, details are : " + info + "; error info :" + JSON.stringify(error));
										session.reject("eamsr_04 : error message while reading response from comment post call, details are : " + info + "; error info :" + JSON.stringify(error));
									} else {
										var errorinfo = "eamsr_04 : Forbidden error message while reading response from comment post call , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ctx.setVariable("errormessage", errorinfo);
										ictx.setVariable("exitstatus", responseStatusCode)
										ictx.setVariable("exitDescription", errorinfo);
										logger.error("eamsr_04 : Forbidden error returned while doing post for comment call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
										session.reject("eamsr_04 :Forbidden error returned while doing post for comment call, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
									}
								});
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										var errorinfo = "failure in reading message from comment call, details are : " + info + "; error info :" + JSON.stringify(error)
										ictx.setVariable("exitDescription", errorinfo);
										ictx.setVariable("exitDestination", URL)
										ictx.setVariable("exitstatus", responseStatusCode)
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										//hm.response.statusCode = responseStatusCode;
										ctx.setVariable("Break", 'Yes');
										var errorinfo = "eamsr_042 comment urlopen details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode + 'MaximoReq' + XML.stringify(Input) + "details are:" + info;
										logger.error(errorinfo);
										ictx.setVariable("exitDescription",errorinfo);
										ictx.setVariable("exitDestination", URL)
										ictx.setVariable("exitstatus", responseStatusCode)
										//session.reject("comment urlopen statusCode: " + responseStatusCode + " " + responseData); 
											ErrorQueue(Input);
									}
								});
							}
						}
					});
				}
			});
		} else if ((responseStatusCode == 401)) {
			response.readAsBuffer(function(error, responseData) {
				if (error) {
					var errorinfo = "eamsr_05 : Unauthorized error message while reading response from jobApi , details are : " + info + "; error info :" + JSON.stringify(error)
					ctx.setVariable("errormessage", errorinfo);
					ictx.setVariable("exitstatus", responseStatusCode)
					ictx.setVariable("exitDescription", errorinfo);
					logger.error("eamsr_05 : error message while reading response from jobApi, details are : " + info + "; error info :" + JSON.stringify(error));
					session.reject("eamsr_05 : error message while reading response from jobApi, details are : " + info + "; error info :" + JSON.stringify(error));
				} else {
					var errorinfo = "eamsr_05 : Unauthorized error message while reading response from jobApi , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
					ictx.setVariable("exitstatus", responseStatusCode)
					ictx.setVariable("exitDescription", errorinfo);
					ctx.setVariable("errormessage", errorinfo);
					logger.error("eamsr_05 : Unauthorized Error returned from jobApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					session.reject("eamsr_05 : Unauthorized Error returned from jobApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
				}
			});
		} else if ((responseStatusCode == 403)) {
			response.readAsBuffer(function(error, responseData) {
				if (error) {
					var errorinfo = "eamsr_06 :Forbidden error message while reading response from jobApi , details are : " + info + "; error info :" + JSON.stringify(error)
					ctx.setVariable("errormessage", errorinfo);
					ictx.setVariable("exitstatus", responseStatusCode)
					ictx.setVariable("exitDescription", errorinfo);
					logger.error("eamsr_06 :Forbidden error message while reading response from jobApi, details are : " + info + "; error info :" + JSON.stringify(error));
					session.reject("eamsr_06 :Forbidden error message while reading response from jobApi, details are : " + info + "; error info :" + JSON.stringify(error));
				} else {
					var errorinfo = "eamsr_06 :Forbidden error message while reading response from jobApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
					ctx.setVariable("errormessage", errorinfo);
					ictx.setVariable("exitstatus", responseStatusCode)
					ictx.setVariable("exitDescription", errorinfo);
					logger.error("eamsr_06 :Forbidden error returned from jobApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
					session.reject("eamsr_06 :Forbidden error returned from jobApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
				}
			});
		} else {
			response.readAsBuffer(function(error, responseData) {
				if (error) {
					//dp:reject stop the transaction and go error rule with error code and description
					var errorinfo = "failure in reading message from jobApi, details are : " + info + "; error info :" + JSON.stringify(error)
					ictx.setVariable("exitDescription", errorinfo);
					ictx.setVariable("exitDestination", URL)
					ictx.setVariable("exitstatus", responseStatusCode)
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					//hm.response.statusCode = responseStatusCode;
					ctx.setVariable("Break", 'Yes');
					var errorinfo = "eamsr_049 jobApi urlopendetails are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode + "  " + 'MaximoReq :' + XML.stringify(Input) + "details are:" + info;
					logger.error(errorinfo);
					ictx.setVariable("exitDescription",errorinfo);
					ictx.setVariable("exitDestination", URL)
					ictx.setVariable("exitstatus", responseStatusCode)
					//session.reject("jobApi urlopen statusCode: " + responseStatusCode + " " + responseData); 
					ErrorQueue(Input);
				}
			});
		}
	}
});
