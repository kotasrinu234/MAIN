var ctx = session.name("followUpOrder")|| session.createContext("followUpOrder");
//set stylesheet parameters to variable

var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookupURL;


//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("lookupURL", lookupURL);
