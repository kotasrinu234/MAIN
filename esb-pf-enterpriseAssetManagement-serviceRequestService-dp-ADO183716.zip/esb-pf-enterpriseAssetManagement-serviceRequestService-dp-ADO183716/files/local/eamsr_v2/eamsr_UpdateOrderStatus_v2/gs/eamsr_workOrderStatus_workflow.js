var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var urlopen = require('urlopen');
var ErrorQueue = require('./urlopenutil.js');
var apiToken = ctx.getVariable("apiToken");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var externalID = ctx.getVariable("externalID");
var ictx = session.name("ILS") || session.createContext("ILS");
var Description = ctx.getVariable("Description");
var action = ctx.getVariable("action");
var id = ctx.getVariable("id");
var lookupURL = ctx.getVariable("lookupURL");
var dtetasktype = ctx.getVariable("dtetasktype");
var lead = ctx.getVariable("lead");
var status_inp = ctx.getVariable("status");
var Job_Status = ctx.getVariable("Job_Status");
var TargCompDate = ctx.getVariable("TargCompDate");
var WONum = ctx.getVariable("WONum");
var Input = ctx.getVariable("Input");
var Break = ctx.getVariable("Break");
var jobTypeID = ctx.getVariable("jobTypeID");
var logger = console.options({
	'category': 'all'
});
var exitpayload = ictx.getVariable("exitpayload")
ictx.setVariable("exitDestination", omsExternalURL)
if (Break != 'Yes') {
	if (status_inp == 'WAPPR' || status_inp == 'APPR' || status_inp == 'FDCOMP') {
		if (status_inp == 'WAPPR') {
			var status_out = 'Waiting on Approval';
		} else if (status_inp == 'APPR') {
			var status_out = 'Approved';
		} else {
			var status_out = 'Field Completed';
		}
		var jobWorkFlowIDlookupMessage = {
			"lookupReq": {
				"type": [{
					"name": "jobTypes.workflows",
					"id": jobTypeID,
					"label": status_out
				}]
			}
		}
		var LookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: jobWorkFlowIDlookupMessage
		};

		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

		urlopen.open(LookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "eamsr_062 readAsJSON error, details are : " + info + "; error info :" + JSON.stringify(error)
				ictx.setVariable("exitDescription", errorinfo);
				//ictx.setVariable("exitDestination",lookupURL)
				ictx.setVariable("exitstatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "eamsr_063 failure in putting message to LookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error)
							ictx.setVariable("exitDescription", errorinfo);
							//ictx.setVariable("exitDestination",lookupURL)
							ictx.setVariable("exitstatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);

						} else {
							logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
							if (responseData.lookupRep.type[0].result == 0) {
								var lookUpstatus = responseData.lookupRep.type[0].status;

								//ictx.setVariable("exitDestination",lookupURL)
								ictx.setVariable("exitstatus", "0")
								logger.debug("lookUpstatus:" + lookUpstatus);
								ctx.setVariable("lookUpstatus", lookUpstatus);
								if (Job_Status == lookUpstatus) {
									logger.debug('Job status is already ' + lookUpstatus);
								} else {
									var statusURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/WorkFlow';
									var options = {
										target: statusURL,
										method: "post",
										headers: {
											"osiApiToken": apiToken
										},
										contentType: "application/json",
										sslClientProfile: "oms_Client_Profile",
										data: lookUpstatus
									};
									var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";

									urlopen.open(options, function(error, response) {
										if (error) {
											// an error occurred during reading the file
											var errorinfo = "eamsr_064 failure in putting message to LookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error)
											ictx.setVariable("exitDescription", errorinfo);
											ictx.setVariable("exitDestination", statusURL)
											ictx.setVariable("exitstatus", "500")
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var responseStatusCode = response.statusCode;
											ctx.setVariable("responseStatusCode", responseStatusCode);
											if (responseStatusCode != 200) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														//dp:reject stop the transaction and go error rule with error code and description
														var errorinfo = "failure in reading message from statusURL, details are : " + info + "; error info :" + JSON.stringify(error)
														ictx.setVariable("exitDescription", errorinfo);
														ictx.setVariable("exitDestination", statusURL)
														ictx.setVariable("exitstatus", responseStatusCode)
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														var errorinfo = "eamsr_065 statusURL  response is  " + responseStatusCode + info + " " + responseData + "  " + 'MaximoReq :' + XML.stringify(Input)
														logger.error(errorinfo);
														ictx.setVariable("exitDescription", errorinfo);
														ictx.setVariable("exitDestination", statusURL)
														ictx.setVariable("exitstatus", responseStatusCode)
														//session.reject("statusURL  response is " + responseStatusCode + " " + responseData);
														ErrorQueue(Input);
													}
												});
											} else if ((responseStatusCode == 401)) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "eamsr_09 : Unauthorized error message while reading response from WorkFlow post call API, details are : " + info + "; error info :" + JSON.stringify(error)
														ictx.setVariable("exitDescription", errorinfo);
														ictx.setVariable("exitstatus", responseStatusCode)
														ctx.setVariable("errormessage", errorinfo);
														logger.error("eamsr_09 : error message while reading response from WorkFlow post call API, details are : " + info + "; error info :" + JSON.stringify(error));
														session.reject("eamsr_09 : error message while reading response from WorkFlow post call API, details are : " + info + "; error info :" + JSON.stringify(error));
													} else {
														var errorinfo = "eamsr_09 : Unauthorized error message while reading response from WorkFlow post call API , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														ictx.setVariable("exitDescription", errorinfo);
														ictx.setVariable("exitstatus", responseStatusCode)
														ctx.setVariable("errormessage", errorinfo);
														logger.error("eamsr_09 : Unauthorized Error returned from WorkFlow post call API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
														session.reject("eamsr_09 : Unauthorized Error returned from WorkFlow post call API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
													}
												});
											} else if ((responseStatusCode == 403)) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "eamsr_10 :Forbidden error message while reading response from WorkFlow post call API , details are : " + info + "; error info :" + JSON.stringify(error)
														ctx.setVariable("errormessage", errorinfo);
														ictx.setVariable("exitDescription", errorinfo);
														ictx.setVariable("exitstatus", responseStatusCode)
														logger.error("eamsr_10 :Forbidden error message while reading response from WorkFlow post call API, details are : " + info + "; error info :" + JSON.stringify(error));
														session.reject("eamsr_10 :Forbidden error message while reading response from WorkFlow post call API, details are : " + info + "; error info :" + JSON.stringify(error));
													} else {
														var errorinfo = "eamsr_10 :Forbidden error message while reading response from jobApi, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														ctx.setVariable("errormessage", errorinfo);
														ictx.setVariable("exitDescription", errorinfo);
														ictx.setVariable("exitstatus", responseStatusCode)
														logger.error("eamsr_10 :Forbidden error returned from WorkFlow post call API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
														session.reject("eamsr_10 :Forbidden error returned from WorkFlow post call API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
													}
												});
											} else {

											}
										}
									});
								}
								var URL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id;
								var payload = {
									"customFieldValues": {
										"Maximo_Tasktype": dtetasktype,
										"Maximo_Lead": lead,
										"Maximo_TARGCOMPDATE": TargCompDate
									}
								}

								if (WONum === null || WONum === undefined || WONum === "") {
								} else {
									payload.customFieldValues.Maximo_Workorder = WONum
								}


								var Patchoptions = {
									target: URL,
									method: "PATCH",
									headers: {
										"osiApiToken": apiToken
									},
									contentType: "application/json",
									sslClientProfile: "oms_Client_Profile",
									data: payload
								};
								exitpayload = JSON.stringify(Patchoptions.data)
								session.output.write(exitpayload)
								var info = " TargetURL :" + Patchoptions.target + "; Method :" + Patchoptions.method + "; Data :" + JSON.stringify(Patchoptions.data) + ". ";

								urlopen.open(Patchoptions, function(error, response) {
									if (error) {
										// an error occurred during reading the file
										var errorinfo = "eamsr_056 urlopen error, details are : " + info + "; error info :" + JSON.stringify(error)
										ictx.setVariable("exitDescription", errorinfo);
										ictx.setVariable("exitDestination", URL)
										ictx.setVariable("exitstatus", "500")
										logger.error(errorinfo);
										session.reject(errorinfo);

									} else {
										var responseStatusCode = response.statusCode;
										ctx.setVariable("responseStatusCode", responseStatusCode);
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												var errorinfo = "failure in reading message from PatchJobAPI, details are : " + info + "; error info :" + JSON.stringify(error)
												ictx.setVariable("exitDescription", errorinfo);
												ictx.setVariable("exitDestination", URL)
												ictx.setVariable("exitstatus", responseStatusCode)
												logger.error(errorinfo);
												session.reject(errorinfo);

											} else {
												if ((responseStatusCode == 200) || (responseStatusCode == 400 && responseData == 'No updates')) {
													logger.info("response received from patch call api " + JSON.stringify(responseData));
												} else if ((responseStatusCode == 401)) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "eamsr_11 : Unauthorized error message while reading response from PatchJobAPI , details are : " + info + "; error info :" + JSON.stringify(error)
															ctx.setVariable("errormessage", errorinfo);
															ictx.setVariable("exitDescription", errorinfo);
															ictx.setVariable("exitstatus", responseStatusCode)
															logger.error("eamsr_11 : error message while reading response from PatchJobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
															session.reject("eamsr_11 : error message while reading response from PatchJobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
														} else {
															var errorinfo = "eamsr_11 : Unauthorized error message while reading response from PatchJobAPI , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
															ctx.setVariable("errormessage", errorinfo);
															ictx.setVariable("exitDescription", errorinfo);
															ictx.setVariable("exitstatus", responseStatusCode)
															logger.error("eamsr_11 : Unauthorized Error returned from PatchJobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
															session.reject("eamsr_11 : Unauthorized Error returned from PatchJobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
														}
													});
												} else if ((responseStatusCode == 403)) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "eamsr_12 :Forbidden error message while reading response from PatchJobAPI , details are : " + info + "; error info :" + JSON.stringify(error)
															ctx.setVariable("errormessage", errorinfo);
															ictx.setVariable("exitDescription", errorinfo);
															ictx.setVariable("exitstatus", responseStatusCode)
															logger.error("eamsr_12 :Forbidden error message while reading response from PatchJobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
															session.reject("eamsr_12 :Forbidden error message while reading response from PatchJobAPI, details are : " + info + "; error info :" + JSON.stringify(error));
														} else {
															var errorinfo = "eamsr_12 :Forbidden error message while reading response from PatchJobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
															ictx.setVariable("exitDescription", errorinfo);
															ictx.setVariable("exitstatus", responseStatusCode)
															ctx.setVariable("errormessage", errorinfo);
															logger.error("eamsr_12 :Forbidden error returned from PatchJobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
															session.reject("eamsr_12 :Forbidden error returned from PatchJobAPI, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
														}
													});
												} else {
													response.readAsBuffer(function(error, ErrorresponseData) {
														if (error) {
															// error while reading response or transferring data to Buffer
															var errorinfo = "failure reading response from patch call api, details are : " + info + "; error info :" + JSON.stringify(error)
															ictx.setVariable("exitDescription", errorinfo);
															ictx.setVariable("exitDestination", URL)
															ictx.setVariable("exitstatus", responseStatusCode)
															logger.error(errorinfo);
															session.reject(errorinfo);

														} else {
															var errorinfo = "eamsr_057 PatchJobAPI  response is  " + responseStatusCode + info + " " + ErrorresponseData + "  " + 'MaximoReq :' + XML.stringify(Input)
															logger.error(errorinfo);
															ictx.setVariable("exitDescription", errorinfo);
															ictx.setVariable("exitDestination", URL)
															ictx.setVariable("exitstatus", responseStatusCode)
															//session.reject("PatchJobAPI  response is " + responseStatusCode + " " + ErrorresponseData);
																ErrorQueue(Input);
														}
													});

												}
											}
										});
									}
								});
							} else {
								logger.error("eamsr_066 jobWorkFlowID lookup response result is not 0");
								//session.reject("jobWorkFlowID lookup response result is not 0");
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from jobWorkFlowID, details are : " + info + "; error info :" + JSON.stringify(error)
							ictx.setVariable("exitDescription", errorinfo);
							//ictx.setVariable("exitDestination", lookupURL)
							ictx.setVariable("exitstatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);

						} else {
							var errorinfo = " jobWorkFlowID  response is  " + responseStatusCode + info + " " + responseData + "  " + 'MaximoReq :' + XML.stringify(Input);
							ictx.setVariable("exitDescription", errorinfo);
							//ictx.setVariable("exitDestination", lookupURL)
							ictx.setVariable("exitstatus", responseStatusCode)
							logger.error(errorinfo);
							//session.reject("jobWorkFlowID  response is " + responseStatusCode + " " + responseData);
							ErrorQueue(Input);
						}
					});
				}
			}
		});
	} else {
		var errorinfo = "eamsr_068 Status is not WAPPR/APPR/FDCOMP, details are : " + info
		ictx.setVariable("exitDescription", errorinfo);
		//ictx.setVariable("exitDestination", lookupURL)
		ictx.setVariable("exitstatus", "500")
		logger.error(errorinfo);
		session.reject(errorinfo);
	}
}
session.output.write(exitpayload)
