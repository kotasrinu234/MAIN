<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:dp="http://www.datapower.com/extensions"
    xmlns:dpconfig="http://www.datapower.com/param/config"
    xmlns:func="http://exslt.org/functions" 
    xmlns:com="http://comesb.pro.com"
    xmlns:regexp="http://exslt.org/regular-expressions"
    xmlns:str="http://exslt.org/strings"
    extension-element-prefixes="dp"
    exclude-result-prefixes="dp dpconfig str"
>

<func:function name="com:printLogMessage">
   <xsl:param name="type"/>
   <xsl:param name="message"/>
   <xsl:message dp:priority="$type" dp:type="all">
       <xsl:copy-of select="$message"/>      
   </xsl:message>

</func:function>
<!--+
    |Utility function to get the requestors IP address
    +-->
<func:function name="com:getRequestorIP">
        <xsl:variable name="immediateHost" select="dp:variable('var://service/transaction-client')"/>
        <xsl:variable name="x-forwarded-for" select="dp:http-request-header('X-Forwarded-For')"/> 
        <xsl:variable name="requestorIP">
           <xsl:choose>
              <xsl:when test="string-length($x-forwarded-for) > 0">
                 <xsl:value-of select="$x-forwarded-for"/>
              </xsl:when>
              <xsl:otherwise>
                 <xsl:value-of select="$immediateHost"/>
              </xsl:otherwise>
           </xsl:choose>
        </xsl:variable>
        <func:result select="$requestorIP"/>
</func:function>

<!--+
    |Utility function to get the request out time
    +-->
<func:function name="com:getRequestOutTime">
        <xsl:variable name="timeElapsed"><xsl:value-of select="dp:variable('var://service/time-elapsed')"/></xsl:variable>
        <xsl:variable name="timeForwarded"><xsl:value-of select="dp:variable('var://service/time-forwarded')"/></xsl:variable>
        <xsl:variable name="requestOutTime"><xsl:value-of select="dp:time-value() - $timeElapsed + $timeForwarded"/></xsl:variable>
        <func:result select="$requestOutTime"/>
</func:function>

<!--+
    |Utility function to get the request In time
    +-->
<func:function name="com:getRequestInTime">
         <xsl:variable name="timeElapsed"><xsl:value-of select="dp:variable('var://service/time-elapsed')"/></xsl:variable>
         <xsl:variable name="requestInTime"><xsl:value-of select="dp:time-value() - $timeElapsed"/></xsl:variable>
         <func:result select="$requestInTime"/>
</func:function>



<!--+
    |Utility function to convert to upper-case
    +-->
<func:function name="com:to-upper">
         <xsl:param name="inputStr"/>
         <xsl:variable name="lowercase" select="'abcdefghijklmnopqrstuvwxyz'" />
         <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
         <xsl:variable name="outputStr" select="translate($inputStr,$lowercase,$uppercase)"/>
         <func:result select="$outputStr"/>
</func:function>



<!--+
    |Utility function to convert to upper-case
    +-->
<func:function name="com:getRequestDetails">
 
    <xsl:variable name="datapowerInfo"><xsl:copy-of select="dp:variable('var://service/system/ident')"/></xsl:variable>
    <xsl:variable name="dpHost"><xsl:value-of select="$datapowerInfo/identification/device-name"/></xsl:variable>
    <xsl:variable name="dpDomain"><xsl:value-of select="dp:variable('var://service/domain-name')"/></xsl:variable>

    <!-- Get the service method from SOAPAction header -->
    <xsl:variable name="SOAPAction" select="dp:http-request-header('SOAPAction')"/>
    <xsl:variable name="regexNoQuote">([^"]*\w)</xsl:variable>
    <xsl:variable name="noQuoteSOAPAction" select="regexp:match($SOAPAction,$regexNoQuote)"/>
    <xsl:variable name="svcMethod" select="regexp:match($noQuoteSOAPAction,'\w*$')"/>

    <!-- Get the client request URL -->
    <xsl:variable name="inURL" select="dp:variable('var://service/URL-in')"/>
   
    <xsl:variable name="payLoadSize"><xsl:value-of select="dp:variable('var://service/mpgw/request-size')"/></xsl:variable> 
    
	
	<!-- NotIncluded -->
     <xsl:variable name="endpointUrl"><xsl:value-of select="dp:variable('var://context/esb/destURL')"/></xsl:variable>
     <xsl:variable name="detailedEndPoint">
        <xsl:choose>
            <xsl:when test="contains($endpointUrl,'http:')">
                DHttpURL=<xsl:value-of select="$endpointUrl"/>
            </xsl:when> 
            <xsl:when test="contains($endpointUrl,'dpmq:')">
                <xsl:variable name="qmgr" select="substring-before(substring-after($endpointUrl,'//'),'/?')"/>
                <xsl:variable name="reqQ" select="substring-after($endpointUrl,'RequestQueue=')"/>
                <xsl:variable name="resQ" select="substring-after($endpointUrl,'ReplyQueue=')"/>
                <xsl:choose>
                     <xsl:when test="string-length($resQ) > 0">
                QMgr=<xsl:value-of select="$qmgr"/>,RequestQ=<xsl:value-of select="substring-before($reqQ,';')"/>,ReplyToQ=<xsl:value-of select="$resQ"/>
                     </xsl:when>
                     <xsl:otherwise>
                           QMgr=<xsl:value-of select="$qmgr"/>,RequestQ=<xsl:value-of select="$reqQ"/>
                     </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$endpointUrl"/>
            </xsl:otherwise>
        </xsl:choose>
     </xsl:variable>

     <xsl:variable name="requestInEventDetails">
<xsl:value-of select="$payLoadSize"/>|<xsl:value-of select="$dpHost"/>|<xsl:value-of select="$dpDomain"/>|destURL=<xsl:value-of select="$endpointUrl"/>|DetailedEP(<xsl:value-of select="normalize-space($detailedEndPoint)"/>)
     </xsl:variable>
<func:result select="normalize-space($requestInEventDetails)"/>
</func:function>

<!--+
    |Utility function to get the generate event
    +-->
<func:function name="com:genComEvent">
        <xsl:param name="comMessage"/>
		  <xsl:param name="disableLog"/>
		  <xsl:if test="$disableLog != '1'">
           <xsl:message dp:type="all" dp:priority="information"> ***** log enabled *****</xsl:message>
             <xsl:variable name="dpDomain"><xsl:value-of select="dp:variable('var://service/domain-name')"/></xsl:variable>
             <xsl:variable name="eventType" select="concat('com-',$dpDomain)"/>
             <xsl:message dp:type="all" dp:priority="information"> ***** <xsl:value-of select="normalize-space($comMessage)"/> *****</xsl:message>
        </xsl:if>
</func:function>

</xsl:stylesheet>
