var ctx = session.name("BulkCrewUpdate") || session.createContext("BulkCrewUpdate");
var logger = console.options({ 'category': 'all' });
var lookupResp = ctx.getVar("lookUpArr") || []; // Initialize with empty array if null
var getCallResp = ctx.getVar("respArr") || []; // Initialize with empty array if null
var lookupErrorArr = ctx.getVar("lookupErrorArr") || []; // Initialize with empty array if null
var failedCrewList = ctx.getVar("failedCrewList") || []; // Initialize with empty array if null
// Check if any entry in lookupResp has result: 1 and add crewId to failedCrewList
lookupResp.forEach(function(entry) {
	if (entry.data.some(function(item) { return item.result === 1 })) {
		if (!failedCrewList.includes(entry.crewId)) {
			failedCrewList.push(entry.crewId);
			ctx.setVar("failedCrewList", failedCrewList);
		}
	}
});
ctx.setVar("failedCrewList", failedCrewList);
function findAorIDs(externalID) {
	var result = getCallResp.find(function(item) {
		return item.externalID === externalID;
	});
	return result ? result.aorIDs : [];
}
function findId(label) {
	for (var i = 0; i < lookupResp.length; i++) {
		var entry = lookupResp[i];
		var item = entry.data[0];
		if (item.label === label && item.result !== 1 && item.id !== "undefined") {
			return item.id;
		}
	}
	return null; // Return null if label is not found or result is 1
}
var combinedList = [];
if (ctx.getVar("uniqueCrewList")) {
	var uniqueCrewList = ctx.getVar("uniqueCrewList");
	if (uniqueCrewList.length > 0 || uniqueCrewList !== undefined) {
		uniqueCrewList.forEach(function(crew) {
			var crewID = crew.crewID;
			var aroLabels = crew.aors;
			var aorsAction = crew.aorsAction;
			if (failedCrewList.includes(crewID)) {
				return; // Skip this crewID if it's in failedCrewList
			}
			var crewData = {
				crewID: crewID,
				IDs: new Set() // Use a Set to store unique IDs
			};
			if (aorsAction === "APPEND") {
				// Combine id and aorIDs into a single list
				aroLabels.forEach(function(label) {
					var id = findId(label);
					if (id !== null) {
						crewData.IDs.add(id); // Add id to the Set
					}
				});
				// Add aorIDs for the crewID
				var aorIDs = findAorIDs(crewID);
				aorIDs.forEach(function(aorID) {
					crewData.IDs.add(aorID); // Add aorID to the Set
				});
			} else if (aorsAction === "REPLACE") {
				// Only add id to the list
				aroLabels.forEach(function(label) {
					var id = findId(label);
					if (id !== null) {
						crewData.IDs.add(id); // Add id to the Set
					}
				});
			}
			// Convert Set back to Array (if needed)
			crewData.IDs = Array.from(crewData.IDs);
			combinedList.push(crewData);
		});
	}
}
ctx.setVar('CombinedList', combinedList);
