var ctx = session.name("BulkCrewUpdate") || session.createContext("BulkCrewUpdate");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var doLookup = require('./bcu_crewUpdateBulk_lookup.js');
var respArr = ctx.getVariable("respArr");
if (ctx.getVariable("uniqueCrewList")) {
	var uniqueCrewList = ctx.getVariable("uniqueCrewList");
	if (uniqueCrewList.length > 0 || uniqueCrewList !== undefined) {
		for (var i = 0; i < uniqueCrewList.length; i++) {
			var crewId = uniqueCrewList[i].crewID;
			var aors = uniqueCrewList[i].aors;
			for (var j = 0; j < respArr.length; j++) {
				var externalID = respArr[j].externalID;
				if (externalID === crewId) {
					var uniquetypeValue = [...new Set(aors)];
					var reqObj = {};
					for (var k = 0; k < uniquetypeValue.length; k++) {
						var reqArr = new Array();
						var crewId_aors = crewId + "_" + aors[k]
						reqObj.name = "aors";
						reqObj.label = aors[k];
						reqArr.push(reqObj);
						doLookup(reqArr, crewId_aors, aors[k], crewId);
					}
				}
			}
		}
	}
}
