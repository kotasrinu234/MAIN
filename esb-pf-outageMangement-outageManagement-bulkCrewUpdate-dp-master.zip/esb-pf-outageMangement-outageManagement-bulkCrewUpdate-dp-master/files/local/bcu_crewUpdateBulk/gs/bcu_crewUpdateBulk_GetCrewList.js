var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('BulkCrewUpdate') || session.createContext("BulkCrewUpdate");
var ilsctx = session.name('ILS') || session.createContext("ILS");
var TokenValue = session.parameters.osiApiToken;
var respArr = [];
var successArr = [];
var errorArr = [];
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data" + readAsJSONError;
		ilsctx.setVar("errorDescription", errorinfo);
		ilsctx.setVar("errorStatus", "500");
		logger.error("Error in reading incoming data" + readAsJSONError);
		session.reject("Error in reading incoming data" + readAsJSONError);
	} else {
		var crewarray = incomingdata.crewList;
		var crewCount = {};
		for (var i = 0; i < crewarray.length; i++) {
			var crewID = crewarray[i].crewID;
			if (crewCount[crewID]) {
				crewCount[crewID]++;
			} else {
				crewCount[crewID] = 1;
			}
		}
		var duplicateCrewList = [];
		var uniqueCrewList = [];
		for (var i = 0; i < crewarray.length; i++) {    //Separate payloads into duplicates and uniques
			var crewListID = crewarray[i].crewID;
			if (!crewID) {

			}
			else {
				if (crewCount[crewListID] > 1) {
					duplicateCrewList.push(crewarray[i]);
					ctx.setVariable("duplicateCrewList", duplicateCrewList);
				} else {
					uniqueCrewList.push(crewarray[i]);
					ctx.setVariable("uniqueCrewList", uniqueCrewList);
				}
			}
		}
		// Function to make the crew API call
		var failedCrewList = [];
		function makeCrewApiCall(index) {
			if (index >= uniqueCrewList.length) {
				// All API calls are done, set the context variables
				ctx.setVariable("respArr", respArr);
				ctx.setVariable("errorArr", errorArr);
				return;
			}
			var crewID = uniqueCrewList[index].crewID;
			var Crewidapiuri = session.parameters.omsExternalURL + '/api/ServiceType/Electric/Crew/' + crewID + '?includeFields=externalID,aorIDs,deprecated';
			var crewapi = {
				target: Crewidapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
			};
			var getCallInfo = " TargetURL :" + crewapi.target + "; Method :" + crewapi.method;
			try {
				urlopen.open(crewapi, function(error, response) {
					if (error) {
						var errorinfo = "bcu_001:urlopen connect error with GET bulkcrewupdateapi , details are : " + getCallInfo + "; error getCallInfo :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", "500");
						logger.error("bcu_001:urlopen connect error with GET bulkcrewupdateapi" + JSON.stringify(error));
						session.reject("bcu_001:urlopen connect error with GET bulkcrewupdateapi" + JSON.stringify(error));
					} else {
						var responseStatusCode = response.statusCode;
						var reasonphrase = response.reasonphrase
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "error message from bulkcrewupdateapi , details are : " + getCallInfo + "; error getCallInfo :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", "500");
									logger.error(" error message from bulkcrewupdateapi" + JSON.stringify(error));
									session.reject("error message from bulkcrewupdateapi" + JSON.stringify(error));
								} else {
									if (responseData.deprecated == false) {
										respArr.push(responseData);
										successArr.push({
											crewID: crewID,
											statusCode: responseStatusCode,
											data: responseData
										});
										ctx.setVariable("respArr", respArr);
										ctx.setVariable("successArr", successArr);
									}
									else {
										failedCrewList.push(crewID);
										errorArr.push({
											crewID: crewID,
											statusCode: responseStatusCode,
											failuresReason: "Deprecated crewID : " + crewID
										});
									}
									hm.response.statusCode = responseStatusCode;
								}
								makeCrewApiCall(index + 1); // Continue with the next call
							});
						} else if (responseStatusCode == 404) {
							failedCrewList.push(crewID);
							ctx.setVar("failedCrewList", failedCrewList);
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "bcu_002:failure in reading message from bulkcrewupdateapi , details are : " + getCallInfo + "; error getCallInfo :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", responseStatusCode);
									logger.error("bcu_002:failure in reading message from bulkcrewupdateapi is  " + JSON.stringify(error));
									session.reject("bcu_002:failure in reading message from bulkcrewupdateapi is " + JSON.stringify(error));
								} else {
									var errorinfo = "bcu_003:Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " , details are : " + getCallInfo + "; errorresponse :" + responseData;
									ilsctx.setVariable("exitDescription", errorinfo);
									ilsctx.setVariable("exitStatus", responseStatusCode);
									logger.error(" bcu_003:Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " " + responseData);
									errorArr.push({
										crewID: crewID,
										statusCode: responseStatusCode,
										failuresReason: "Crew " + responseData + " not found "
									});
									ctx.setVariable("errorArr", errorArr);
								}
								makeCrewApiCall(index + 1); // Continue with the next call
							});
						}
						else if (responseStatusCode == 401) {
							failedCrewList.push(crewID);
							ctx.setVar("failedCrewList", failedCrewList);
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "bcu_002:failure in reading message from bulkcrewupdateapi , details are : " + getCallInfo + "; error getCallInfo :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", "401");
									logger.error("bcu_002:failure in reading message from bulkcrewupdateapi is  " + JSON.stringify(error));
									session.reject("bcu_002:failure in reading message from bulkcrewupdateapi is " + JSON.stringify(error));
								} else {
									var errorinfo = "bcu_003:Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " , details are : " + getCallInfo + "; errorresponse :" + responseData;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", responseStatusCode);
									logger.error(" bcu_003:Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " " + responseData);
									session.reject("bcu_003:Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}
						else {
							failedCrewList.push(crewID);
							ctx.setVar("failedCrewList", failedCrewList);
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "bcu_002:failure in reading message from bulkcrewupdateapi , details are : " + getCallInfo + "; error getCallInfo :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", responseStatusCode);
									logger.error("bcu_002:failure in reading message from bulkcrewupdateapi is  " + JSON.stringify(error));
									session.reject("bcu_002:failure in reading message from bulkcrewupdateapi is " + JSON.stringify(error));
								} else {
									var errorinfo = "bcu_003:Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " , details are : " + getCallInfo + "; errorresponse :" + responseData;
									ilsctx.setVariable("exitDescription", errorinfo);
									ilsctx.setVariable("exitStatus", responseStatusCode);
									logger.error(" bcu_003:Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " " + responseData);
									var data = responseData + " " + reasonphrase + " " + responseStatusCode;
									errorArr.push({
										crewID: crewID,
										statusCode: responseStatusCode,
										failuresReason: data
									});
									ctx.setVariable("errorArr", errorArr);
								}
								makeCrewApiCall(index + 1); // Continue with the next call
							});
						}
					}
				});
			}
			catch (error) {
				var errorinfo = "bcu_001:urlopen connect error with GET bulkcrewupdateapi , details are : " + getCallInfo + "; error getCallInfo :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatus", "500");
				logger.error(" bcu_001:urlopen connect error with GET bulkcrewupdateapi" + JSON.stringify(error));
				session.reject("bcu_001:urlopen connect error with GET bulkcrewupdateapi" + JSON.stringify(error));
			}
		}
		makeCrewApiCall(0);
	}
})
