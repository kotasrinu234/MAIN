var ctx = session.name('BulkCrewUpdate') || session.createContext("BulkCrewUpdate");
var ilsctx = session.name('ILS') || session.createContext("ILS");
var reqPayload = ctx.getVar("json");
var crewList = reqPayload.crewList || [];
var getSuccessArr = ctx.getVar("successArr") || [];
var getErrorArr = ctx.getVar("errorArr") || [];
var lookupSuccessArr = ctx.getVar("lookupSuccessArr") || [];
var lookupErrorArr = ctx.getVar("lookupErrorArr") || [];
var patchSuccessArr = ctx.getVar("patchSuccessArr") || [];
var patchErrorArr = ctx.getVar("patchErrorArr") || [];
var duplicateCrewList = ctx.getVar("duplicateCrewList") || [];
var finalBulkResponsePayload = {
	"msgId": reqPayload.msgId,
	"timesStamp": reqPayload.timesStamp,
	"crewList": []
};
var logger = console.options({
	'category': 'all'
});
function findCrewDetails(crewID, crewList) {
	return crewList.find(crew => crew.crewID === crewID) || null;
}
function removeUsedElements(arr, usedArr) {
	return arr.filter(item => !usedArr.includes(item));
}
if (crewList.length === 0) {
	// Handle case where crewList is empty
	finalBulkResponsePayload.crewList.push({
		"failureReasons": "CrewList is empty"
	});
}
else {
	crewList.forEach(crew => {
		var crewID = crew.crewID;
		var aors = crew.aors;
		var aorsAction = crew.aorsAction;
		var status = "SUCCESS"; // Assume success unless proven otherwise
		var failureReasons = null;

		// Validate crewID
		if (!crewID || crewID.trim() === '' || crewID === null || crewID === undefined) {
			status = "FAILURE";
			failureReasons = "crewID value missing or invalid in input";
		}

		// Validate aors
		if (!aors || !Array.isArray(aors) || aors.length === 0 ||aors.some(aor => typeof aor !== 'string' || aor.trim() === '')) {
			status = "FAILURE";
			failureReasons = "aors value missing or invalid in input";
		}

		// Validate aorsAction
		if (!aorsAction || typeof aorsAction !== 'string' || aorsAction.trim() === '') {
			status = "FAILURE";
			failureReasons = "aorsAction value missing or invalid in input";
		} else if (!(aorsAction === 'APPEND' || aorsAction === 'REPLACE')) {
			status = "FAILURE";
			failureReasons = "aorsAction value missing or invalid in input";
		}

		// Check for crewID in error arrays and add corresponding failure reasons
		var errorArrs = [getErrorArr, lookupErrorArr, patchErrorArr];
		for (var i = 0; i < errorArrs.length; i++) {
			var errorArr = errorArrs[i];
			var errorItems = errorArr.filter(item => item.crewID === crewID);
			if (errorItems.length > 0) {
				// Add the first error reason found, for example:
				failureReasons = errorItems[0].failuresReason;
				status = "FAILURE";
				break; // Exit loop if errors are found
			}
		}

		// Check for duplicate crewID
		var isDuplicate = duplicateCrewList.some(item => item.crewID === crewID);
		if (isDuplicate) {
			status = "FAILURE";
			failureReasons = "Duplicate crew ID " + crewID;
		}

		// If any failure reasons, add to finalBulkResponsePayload as FAILURE
		if (status === "FAILURE") {
			finalBulkResponsePayload.crewList.push({
				"crewID": crewID,
				"aors": aors,
				"aorsAction": aorsAction,
				"status": status,
				"failureReasons": failureReasons
			});
		} else {
			// Otherwise, it's a success
			finalBulkResponsePayload.crewList.push({
				"crewID": crewID,
				"aors": aors,
				"aorsAction": aorsAction,
				"status": status
			});
		}
	});
}

ctx.setVar("finalBulkResponsePayload", finalBulkResponsePayload);
session.output.write(finalBulkResponsePayload);
