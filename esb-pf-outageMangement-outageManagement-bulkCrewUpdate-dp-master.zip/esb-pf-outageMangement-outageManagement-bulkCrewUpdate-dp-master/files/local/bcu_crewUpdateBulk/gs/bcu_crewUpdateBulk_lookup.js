var ctx = session.name("BulkCrewUpdate") || session.createContext("BulkCrewUpdate");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var url = session.parameters.lookupUrl;
var aorArr = []
var lookUpArr = [];
var lookupSuccessArr = [];
var lookupErrorArr = [];
var failedCrewList = ctx.getVar("failedCrewList") || [];
function doLookup(arrObj, lookupCtx, aor, crewId) {
	aorArr.push(aor);
	ctx.setVar("aorArr", aorArr);
	var request = {};
	request.type = arrObj;
	var lookupUrl = url + "/" + aor;
	var options = {
		target: lookupUrl,
		method: 'post',
		contentType: 'application/json',
		data: { "lookupReq": request }
	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		// open connection to target
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "bcu_004:urlopen.open error MQ, details are : " + info + "; error info :" + error;
				ilsctx.setVar("errorDescription", errorinfo);
				ilsctx.setVar("errorStatus", "500");
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						ctx.setVariable('lookupResponseData', responseData);
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response 'lookUpURL', details are : " + info + "; error info :" + error;
							ilsctx.setVar("errorDescription", errorinfo);
							ilsctx.setVar("errorStatus", "500");
							logger.error(errorinfo);
							session.output.write(errorinfo);
							session.reject(errorinfo);
						} else {
							if (responseData.lookupRep.type[0].result == 0) {
								var lookupResponse = {
									data: responseData.lookupRep.type,
									crewId: crewId
								}
								ctx.setVariable(lookupCtx + "_lookup", lookupResponse);
								lookUpArr.push(lookupResponse);
								lookupSuccessArr.push({
									crewID: crewId,
									statusCode: responseStatusCode,
									incomingdata: arrObj,
									data: responseData
								});
								ctx.setVariable("lookupSuccessArr", lookupSuccessArr);
								ctx.setVar("lookUpArr", lookUpArr);
							}
							else {
								if (responseData.lookupRep.type[0].result === 1) {
									if (!failedCrewList.includes(crewId)) {
										failedCrewList.push(crewId);
										ctx.setVar("failedCrewList", failedCrewList);
									}
									var lookupResponse = {
										data: responseData.lookupRep.type,
										crewId: crewId
									}
									ctx.setVariable(lookupCtx + "_lookup", lookupResponse);
									lookUpArr.push(lookupResponse);
									lookupErrorArr.push({
										crewID: crewId,
										statusCode: responseStatusCode,
										incomingdata: options.data,
										failuresReason: "Aor label lookup failed",
										data: responseData
									});
									ctx.setVariable("lookupErrorArr", lookupErrorArr);
									ctx.setVar("lookUpArr", lookUpArr);
									var errorinfo = "Invalid " + lookupCtx + "Lookup Response :" + " " + JSON.stringify(error);
									ilsctx.setVar("exitDescription", errorinfo);
									ilsctx.setVar("exitStatus", "500");
									logger.error("Invalid " + lookupCtx + "Lookup Response :" + " " + JSON.stringify(error));
									//session.reject("Invalid " + lookupCtx + "Lookup Response :" + " " + JSON.stringify(error));
								}
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading response of 'lookUpURL', details are : " + info + "; error info :" + error;
							ilsctx.setVar("errorDescription", errorinfo);
							ilsctx.setVar("errorStatus", "500");
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "response received lookUpURL details are  :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							ilsctx.setVar("exitDescription", errorinfo);
							ilsctx.setVar("exitStatus", responseStatusCode);
							if (!failedCrewList.includes(crewId)) {
								failedCrewList.push(crewId);
								ctx.setVar("failedCrewList", failedCrewList);
							}
							lookupErrorArr.push({
								crewID: crewId,
								statusCode: responseStatusCode,
								incomingdata: arrObj,
								failuresReason: "received negative acknowledgement while doing lookup call for aors " + responseData + " " + responseStatusCode,
								data: responseData
							});
							ctx.setVariable("lookupErrorArr", lookupErrorArr);
							logger.error(errorinfo);
							session.output.write(errorinfo);
						}
					});
				}
			}
		});
	} catch (error) {
		var errorinfo = "bcu_004:urlopen.open error MQ, details are : " + info + "; error info :" + error;
		ilsctx.setVar("errorDescription", errorinfo);
		ilsctx.setVar("errorStatus", "500");
		logger.error(errorinfo);
		session.output.write(errorinfo);
		session.reject(errorinfo);
	}
}//end of function
module.exports = doLookup;
