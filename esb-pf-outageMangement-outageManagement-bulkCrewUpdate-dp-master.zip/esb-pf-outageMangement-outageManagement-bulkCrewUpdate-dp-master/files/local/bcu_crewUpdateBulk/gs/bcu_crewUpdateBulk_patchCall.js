var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var ctx = session.name("BulkCrewUpdate") || session.createContext("BulkCrewUpdate");
var ilsctx = session.name("ILS") || session.createContext("ILS");
// Assuming CombinedList is fetched and available
var CombinedList = ctx.getVar("CombinedList"); // Assuming this is fetched correctly
var TokenValue = session.parameters.osiApiToken; // Assuming this is fetched correctly
var json = ctx.getVar("json");
var patchSuccessArr = [];
var patchErrorArr = [];
var failedCrewList = ctx.getVar("failedCrewList");
// Iterate through each crew entry in CombinedList
if (CombinedList && json.crewList.length > 0) {
	CombinedList.forEach(function(crewEntry) {
		var crewID = crewEntry.crewID;
		var IDs = crewEntry.IDs; // IDs for this crewID
		var foundInJson = false;

		// Check if the crewID is found in json and aorsAction is APPEND or REPLACE
		json.crewList.forEach(function(jsonCrew) {
			if (jsonCrew.crewID === crewID && (jsonCrew.aorsAction === "APPEND" || jsonCrew.aorsAction === "REPLACE")) {
				foundInJson = true;
			}
		});
		// Proceed with PATCH only if conditions are met
		if (IDs && IDs.length > 0 && foundInJson && (!failedCrewList || failedCrewList.length === 0 || !failedCrewList.includes(crewID))) {
			// Check if aors array in json is valid
			var isValidAors = json.crewList.some(function(jsonCrew) {
				return jsonCrew.crewID === crewID && jsonCrew.aors.length > 0 && jsonCrew.aors.every(function(aor) {
					return typeof aor === 'string' && aor.trim() !== '';
				});
			});
			if (isValidAors) {
				// Construct the API URL for this crewID
				var Crewidapiuri = session.parameters.omsExternalURL + '/api/ServiceType/Electric/Crew/' + crewID;
				var payload = {
					"aorIDs": IDs
				};
				// Configure the HTTP request
				var bulkcrewupdateapi = {
					target: Crewidapiuri,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'PATCH',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: payload // Assign the JSON string to data
				};
				var patchcallinfo = " TargetURL :" + bulkcrewupdateapi.target + "; Method :" + bulkcrewupdateapi.method + "; Data :" + JSON.stringify(bulkcrewupdateapi.data) + ". ";
				try {
					// Make the HTTP request for this crewID
					urlopen.open(bulkcrewupdateapi, function(error, response) {
						// Handle response based on status code
						if (error) {
							// Handle error
							var errorinfo = "bcu_005:urlopen connect error with PATCH bulkcrewupdateapi , details are : " + patchcallinfo + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", "500");
							logger.error("bcu_005:urlopen connect error with PATCH bulkcrewupdateapi " + JSON.stringify(error));
							session.reject("bcu_005:urlopen connect error with PATCH bulkcrewupdateapi " + JSON.stringify(error));
						} else {
							var responseStatusCode = response.statusCode;
							var reasonphrase = response.reasonphrase;

							// Handle different status codes
							if (responseStatusCode === 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "Error reading response data from bulkcrewupdateapi , details are : " + patchcallinfo + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "500");
										logger.error("Error reading response data from bulkcrewupdateapi " + JSON.stringify(error));
										session.reject("Error reading response data from bulkcrewupdateapi " + JSON.stringify(error));
									} else {
										logger.info("Success response from bulkcrewupdateapi: " + JSON.stringify(responseData));
										patchSuccessArr.push({
											crewID: crewID,
											statusCode: responseStatusCode,
											data: responseData
										});
										ctx.setVariable("patchSuccessArr", patchSuccessArr);
										// Process your successful response here
									}
								});
							} else if (responseStatusCode === 404) {
								// Handle 404 error response
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "Failure in reading message from bulkcrewupdateapi , details are : " + patchcallinfo + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "500");
										logger.error("Failure in reading message from bulkcrewupdateapi: " + JSON.stringify(error));
										session.reject("Failure in reading message from bulkcrewupdateapi: " + JSON.stringify(error));
									} else {
										var errorinfo = "Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " , details are : " + patchcallinfo + "; errorresponseinfo :" + responseData;
										ilsctx.setVariable("exitDescription", errorinfo);
										ilsctx.setVariable("exitStatus", responseStatusCode);
										logger.error("Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " " + responseData);
										patchErrorArr.push({
											crewID: crewID,
											statusCode: responseStatusCode,
											failuresReason: responseData + " not found"
										});
										ctx.setVariable("patchErrorArr", patchErrorArr);
									}
								});
							} else {
								// Handle other error responses
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure in reading message from CrewGetApi , details are : " + patchcallinfo + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "500");
										logger.error("Failure in reading message from bulkcrewupdateapi: " + JSON.stringify(error));
										session.reject("Failure in reading message from bulkcrewupdateapi: " + JSON.stringify(error));
									} else {
										var errorinfo = "Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " , details are : " + patchcallinfo + "; errorresponseinfo :" + responseData;
										ilsctx.setVariable("exitDescription", errorinfo);
										ilsctx.setVariable("exitStatus", responseStatusCode);
										logger.error("Error returned from bulkcrewupdateapi with statusCode " + responseStatusCode + " " + responseData);
										var data = responseData + " " + reasonphrase + " " + responseStatusCode;
										patchErrorArr.push({
											crewID: crewID,
											statusCode: responseStatusCode,
											failuresReason: data
										});
										ctx.setVariable("patchErrorArr", patchErrorArr);
									}
								});
							}
						}
					});
				} catch (error) {
					var errorinfo = "bcu_005:urlopen connect error with PATCH bulkcrewupdateapi , details are : " + patchcallinfo + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatus", "500");
					logger.error("bcu_005:urlopen connect error with PATCH bulkcrewupdateapi " + JSON.stringify(error));
					session.reject("bcu_005:urlopen connect error with PATCH bulkcrewupdateapi " + JSON.stringify(error));
				}
			}
		}
	});
}
