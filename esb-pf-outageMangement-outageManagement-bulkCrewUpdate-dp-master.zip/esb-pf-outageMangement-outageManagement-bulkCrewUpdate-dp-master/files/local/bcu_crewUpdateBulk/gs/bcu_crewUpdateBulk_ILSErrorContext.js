var ctx = session.name("ILS") || session.createContext("ILS");
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var ilserrorCode = ctx.getVar("errorStatus");
var errDetail = ctx.getVar("errorDescription");
var errorSubcode = sm.getVar('var://service/error-subcode');
var errorCode = sm.getVar('var://service/error-code')
var errormessage = sm.getVar('var://service/error-message');

var obj = {};
obj.errorDescription = errormessage;
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
obj.errorCode = errorCode;
session.output.write(obj);
var errCode = '';
if (ilserrorCode == null || ilserrorCode == '' || ilserrorCode == undefined) {
	errCode = errorCode;
}
else {
	hm.current.statusCode = ilserrorCode;
	errCode = ilserrorCode;
}
ctx.setVar("errorCode", errCode);
if(errDetail){
	if(errDetail !== null || errDetail !== '' || errDetail !== undefined){
		ctx.setVar("errorDescription", errDetail);
	}
}
else if (errormessage == 'Invalid JSON format' || errorCode == '0x00c30025' || errormessage == 'Invalid string syntax' || errormessage == 'Invalid object syntax' || errormessage == 'Invalid JSON property value') {
	ctx.setVar("errorDescription", "Invali Json");

	}
else{
	ctx.setVar("errorDescription", obj.formattedErrorMessage);
}
if (errormessage == 'Invalid JSON format' || errorCode == '0x00c30025' || errormessage == 'Invalid string syntax' || errormessage == 'Invalid object syntax' || errormessage == 'Invalid JSON property value') {
		logger.error("bcu_001 Input Schema Validation Error");

	}
