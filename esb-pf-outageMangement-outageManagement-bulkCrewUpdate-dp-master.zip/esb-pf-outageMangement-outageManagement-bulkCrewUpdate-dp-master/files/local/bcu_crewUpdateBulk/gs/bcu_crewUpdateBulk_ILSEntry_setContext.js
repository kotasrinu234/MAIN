var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("BulkCrewUpdate") || session.createContext("BulkCrewUpdate");
var ilsctx = session.name('ILS') || session.createContext('ILS');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data, details are:"; "error info :" + readAsJSONError
		ilsctx.setVariable("errorStatus", '500');
		ilsctx.setVariable("errorDescription", errorinfo)
		logger.error(errorinfo);
	} else {
		ctx.setVar("json", incomingdata);
		var correlationID = incomingdata.msgId;
		var messageType = session.parameters.messageType;
		var EntryDescription = session.parameters.EntryDescription;
		var ExitDescription = session.parameters.ExitDescription;
		var sourceUrl = sm.getVar('var://service/URL-in');
		var sourceEventTimestamp = incomingdata.timesStamp;
		var userID = incomingdata.userId;
		//var crewList = incomingdata.crewList;
		
		/*for (var i = 0; i < crewList.length; i++) {
			
			if (incomingdata.crewList[i].crewID === undefined || incomingdata.crewList[i].crewID === null || incomingdata.crewList[i].crewID === '') {
				ilsctx.setVariable('crewDisplayID', ' ');
			} else {
				ilsctx.setVariable('crewDisplayID', incomingdata.crewList[i].crewID);
			}
			if (incomingdata.crewList[i].aors === undefined || incomingdata.crewList[i].aors === null || incomingdata.crewList[i].aors === '') {
				ilsctx.setVariable('aors', ' ');
			} else {
				ilsctx.setVariable('aors', incomingdata.crewList[i].aors);
			}
			if (incomingdata.crewList[i].aorsAction === undefined || incomingdata.crewList[i].aorsAction === null || incomingdata.crewList[i].aorsAction === '') {
				ilsctx.setVariable('action', ' ');
			} else {
				ilsctx.setVariable('action', incomingdata.crewList[i].aorsAction);
			}
			ms.callRule('bcu_crewUpdateBulk_Processping_Policy_ILSEntry_Rule', null, null, function(error) {
			if (error) {
				throw error;
			}
		});
		}*/
		if (sourceEventTimestamp === undefined || sourceEventTimestamp === null || sourceEventTimestamp === '') {
		} else {
			ilsctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ilsctx.setVariable('correlationID', ' ');
		} else {
			ilsctx.setVariable('correlationID', correlationID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ilsctx.setVariable('messageType', ' ');
		} else {
			ilsctx.setVariable('messageType', messageType);
		}
		if (EntryDescription === undefined || EntryDescription === null || EntryDescription === '') {
			ilsctx.setVariable('EntryDescription', ' ');
		} else {
			ilsctx.setVariable('EntryDescription', EntryDescription);
		}
		if (ExitDescription === undefined || ExitDescription === null || ExitDescription === '') {
			ilsctx.setVariable('ExitDescription', '');
		} else {
			ilsctx.setVariable('ExitDescription', ExitDescription);
		}
		if (sourceUrl === undefined || sourceUrl === null || sourceUrl === '') {
			ilsctx.setVariable('sourceUrl', ' ');
		} else {
			ilsctx.setVariable('sourceUrl', sourceUrl);
		}
		if (userID === undefined || userID === null || userID === '') {
			ilsctx.setVariable('userID', ' ');
		} else {
			ilsctx.setVariable('userID', userID);
		}
	}
});
