var urlopen = require('urlopen');
var sm = require('service-metadata')
var logger = console.options({ 'category': 'all' });
var ctx = session.name("WTP") || session.createContext("WTP");
var ILSctx = session.name("ILS") || session.createContext("ILS");
sm.setVar("var://service/mpgw/skip-backside", true)

session.INPUT.readAsJSON(function(readAsJSONError, json) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data as JSON : " + readAsJSONError;
		ILSctx.setVariable("exitDescription", errorinfo)
		ILSctx.setVariable("exitStatus", "500")
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {

		var getTokenUrl = session.parameters.getTokenUrl
		var Options = {
			target: getTokenUrl,
			method: 'GET',
			contentType: 'application/json',
		};

		var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
		urlopen.open(Options, function(error, response) {
			if (error) {
				var errorinfo = "WTP_004: url connection error 'Token Call in wtp_sendRequest Service', details are :" + info + "; error info :" + error;
				ILSctx.setVariable("exitDescription", errorinfo);
				ILSctx.setVariable("exitStatus", "500");
				ILSctx.setVariable("exitDestination", getTokenUrl);
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode === 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'Token Call in wtp_sendRequest Service', details are : " + info + "; error info :" + error
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", "500");
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							
							var AccessToken = responseData.access_token;
							if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
								var errorinfo = "WTP_005: Invalid token revieved in wtp_sendRequest Service, details are : " + info
								ILSctx.setVariable("exitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								ILSctx.setVariable("exitDestination", getTokenUrl);
								logger.error(errorinfo);
								ctx.setVariable("retry", 'yes');
								ctx.setVariable("ErrorTxt", errorinfo);
							} else {
								var tokenRecieved = "<tokenRecieved>true</tokenRecieved>"
							ILSctx.setVariable("tokensExitDestination", getTokenUrl);
							ILSctx.setVariable("tokensExitDescription", session.parameters.tokensExitDescription);
							session.output.write(XML.parse(tokenRecieved))
								//ILSctx.setVariable("exitDestination", getTokenUrl);
								var eventHubURL = session.parameters.eventHubURL;
								var TokenType = responseData.token_type;
								var Token = TokenType + ' ' + AccessToken;
								var Options = {
									target: eventHubURL,
									sslClientProfile: 'wtp_sendRequest_Client_profile',
									method: 'POST',
									headers: {
										'Authorization': Token,
									},
									contentType: 'application/x-www-form-urlencoded',
									data: json
								}

								var info = " TargetURL :" + Options.target + "; Method :" + Options.method + "; Data :" + JSON.stringify(Options.data) + ". ";
								//var errorDescription = session.parameters.errorDescription
								urlopen.open(Options, function(error, response) {
									if (error) {
										var errorinfo = "WTP_005: url connection error 'EventHub Call in wtp_sendRequest Service', details are :" + info + "; error info :" + error;
										ILSctx.setVariable("exitDescription", errorinfo);
										ILSctx.setVariable("exitStatus", "500");
										ILSctx.setVariable("exitDestination", eventHubURL);
										logger.error(errorinfo);
										ctx.setVariable("retry", 'yes');
										ctx.setVariable("ErrorTxt", errorinfo);
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode === 200 || responseStatusCode === 201) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'EventHub Call in wtp_sendRequest Service' , details are : " + eventHubCallInfo + "; error info :" + error;
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", "500");
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													logger.debug("response received :" + responseData);
													ILSctx.setVariable("exitDescription", session.parameters.exitDescription);
													ILSctx.setVariable("exitDestination", eventHubURL);
													ILSctx.setVariable("exitStatus", "0");
												}
											});
										} else {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'EventHub Call in wtp_sendRequest Service', details are : " + info + "; error info :" + error
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", "500");
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "WTP_006: " + errorDescription + " : error response 'EventHub Call in wtp_sendRequest Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", responseStatusCode);
													ILSctx.setVariable("exitDestination", eventHubURL);
													logger.error(errorinfo);
													ctx.setVariable("retry", 'yes');
													ctx.setVariable("ErrorTxt", errorinfo);
												}
											});
										}
									}
								});
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'Token Call', details are : " + info + "; error info :" + error
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "WTP_007: error response 'Token Call in wtp_sendRequest Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							ILSctx.setVariable("exitDestination", getTokenUrl);
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
						}
					});
				}
			}
		});
	}
});
