// Import required modules
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });

// Create or retrieve the context for session handling
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("WTP") || session.createContext("WTP");

// Read incoming data as JSON
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		// Handle error in reading incoming data
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {

		if (incomingdata.destQueueName === null || incomingdata.destQueueName === undefined || incomingdata.destQueueName === '') {
			var errorinfo = "WTP_002 : Destination Queue is empty in the payload or undefined :" + incomingdata
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo);
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var MQurl = session.parameters.MQConnectionString + incomingdata.destQueueName
			var pushingToQueue = {
				target: MQurl,
				data: incomingdata
			};

			var info = " TargetURL: " + pushingToQueue.target + "; Data: " + JSON.stringify(pushingToQueue.data) + ". ";
			try {
				// Open a connection and push the message to the queue
				urlopen.open(pushingToQueue, function(error, response) {
					var hm = require('header-metadata');
					if (error) {
						// Handle URL connection error
						var errorinfo = "WTP_003 : URL connection error '"+ incomingdata.destQueueName +" Queue', details are : " + info + "; error info :" + error;
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var mqrc = response.statusCode;
						if (mqrc == 0) {
							// Handle successful response from the queue
							var replyMQMD = response.get({ type: 'mq' }, 'MQMD');
							var replyMQRFH2 = response.get({ type: 'mq' }, 'MQRFH2');
							response.readAsBuffer(function(readError, responseData) {
								if (readError) {
									// Handle error in reading the response data
									var errorinfo = "Error reading the response '"+ incomingdata.destQueueName +" Queue', details are : " + info + "; error info :" + readError;
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									hm.response.statusCode = 500;
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									logger.debug("MQResponsecode " + mqrc);
									ILSctx.setVariable('ExitDestination', MQurl);
									ILSctx.setVariable('ExitStatus', '0');
								}
							});
						} else {
							// Handle error responses from the queue
							var errorinfo = "WTP_003 : Error received from the response of Queue '"+ incomingdata.destQueueName +"', details are : " + info + "; response info :" + JSON.stringify(response) + "; ResponseStatusCode :" + response.statusCode;
							var mqconnection = 'Forbidden';
							ctx.setVariable("mqconnection", mqconnection);
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					}
				});
			} catch (err) {
				// Handle URL connection error
				var errorinfo = "WTP_003 : URL connection error '"+ incomingdata.destQueueName +" Queue', details are : " + info + "; error info :" + err;
				var mqconnection = 'Forbidden';
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	}
});
