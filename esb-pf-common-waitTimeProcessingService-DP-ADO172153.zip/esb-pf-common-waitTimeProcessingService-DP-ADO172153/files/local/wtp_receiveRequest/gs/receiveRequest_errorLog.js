var hm = require('header-metadata');
var sm = require('service-metadata');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var errorCode = sm.getVar('var://service/error-code');
var errorMessage = sm.getVar('var://service/error-message')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('WSM') || session.createContext('WSM');
var value = ctx.getVar('identity/username');
if (errorMessage === "Rejected by policy.") {
	var errorinfo = `WTP_001: AAA failure for WaitTimeService with, Username: ${value}, Errorstring: ${errorCode}, errorMessage: ${errorMessage}`;
	logger.error(errorinfo);
	ILSctx.setVariable("ExitDescription", errorinfo);
	ILSctx.setVariable("ExitStatus", '401')
	logger.error(errorinfo);
}
