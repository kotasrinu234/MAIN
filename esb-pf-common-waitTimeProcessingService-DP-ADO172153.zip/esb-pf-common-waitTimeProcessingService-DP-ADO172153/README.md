# INTERFACE 63 - waitTimeProcessing

📌 **PACKAGING INSTRUCTIONS**

✅ *Objects need to be selected while taking the export:*

**1. MULTIPROTOCOL GATEWAY:** wtp_receiveRequest, wtp_sendRequest

*1. Properties file:*
wtp_receiveRequest_AAA_Policy.aaa.auth.LDAP.BindDN=CN=esb-pnfcep-wtp-dev,OU=ESB,OU=Service,OU=Restricted Accounts,DC=dtenet,DC=com
wtp_receiveRequest_AAA_Policy.aaa.auth.LDAP.GroupDN=CN=wtp-users-dev,OU=cust_svcs,OU=ESB,OU=DCA,OU=DTE Groups,DC=dtenet,DC=com

*2. BaseDeploymentPolicy:*
<ModifiedConfig>
    <Match>*/*/xml/aaapolicy?Name=wtp_receiveRequest_AAA_Policy&amp;Property=Authorize/AZLDAPGroup&amp;Value=.*</Match>
    <Type>change</Type>
    <Property/>
    <Value>@wtp_receiveRequest_AAA_Policy.aaa.auth.LDAP.GroupDN@</Value>
</ModifiedConfig>
<ModifiedConfig>
    <Match>*/*/xml/aaapolicy?Name=wtp_receiveRequest_AAA_Policy&amp;Property=Authorize/AZLDAPBindDN&amp;Value=.*</Match>
    <Type>change</Type>
    <Property/>
    <Value>@wtp_receiveRequest_AAA_Policy.aaa.auth.LDAP.BindDN@</Value>
</ModifiedConfig>
IMP Note:  validation is made off  manually in prod after deployment.
