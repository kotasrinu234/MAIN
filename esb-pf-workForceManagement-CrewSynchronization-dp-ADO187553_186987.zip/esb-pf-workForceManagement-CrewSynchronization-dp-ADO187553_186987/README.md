# esb-pf-workForceManagement-CrewSynchronization-dp
interface 53 below ADO's are merged to master branch.
User Story 187553: Interface Crew Sync OHUG- Add new sectigo certs
User Story 186987: Crew Create/Update-OH/UG FSE_Client_Profile renewTLS certificate and redeployed to master branch.
