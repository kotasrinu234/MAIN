var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("csyn") || session.createContext("csyn");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("csyn") || session.createContext("csyn");
	if (readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
		ctx.setVariable('exitStatus', '500');
		var deprecated = incomingdata.data[0].deprecated;
		var retry = ctx.getVar("retry");
		if (deprecated !== true && retry !== 'yes') {
			var Region = ctx.getVar("aordlabelRegion");
			var District = ctx.getVar("aordlabelDistrict");
			var EngineerType = ctx.getVar("EngineerTypeLabel");
			var Calendar = session.parameters.Calendar;
			var onShift;
			if (incomingdata.data[0].active == true || incomingdata.data[0].active == 'true') {
				onShift = "True";
			} else {
				onShift = "False";
			}
			var Createpayload = {
				"Operations": [{
					"Action": "CreateOrUpdate",
					"Object": {
						"@objectType": "Engineer",
						"@createOrUpdate": true,
						"Key": -1,
						"Area": "OUG",
						"EngineerType": EngineerType,
						"Region": Region,
						"District": District,
						"Calendar": Calendar,
						"Active": onShift,
						"Internal": "True",
						"CrewForExternalUse": "False",
						"MobileWebClientSettings":
						{
						}
					}
				}],
				"OneTransaction": true,
				"ContinueOnError": true,
				"ErrorOnNonExistingDictionaries": true
			}

			var LoginName = session.parameters.LoginName;
			if (incomingdata.data[0].customFieldValuesExt !== undefined) {
				if (incomingdata.data[0].customFieldValuesExt.employeeid !== undefined) {
					Createpayload.Operations[0].Object.LoginName = incomingdata.data[0].customFieldValuesExt.employeeid + '@' + LoginName;
				}
				if (incomingdata.data[0].customFieldValuesExt.CrewID !== undefined) {
					Createpayload.Operations[0].Object.OUGCrewID = incomingdata.data[0].customFieldValuesExt.CrewID;
				}
				if (incomingdata.data[0].customFieldValuesExt.crewStatusCustom !== undefined) {
					Createpayload.Operations[0].Object.OUGCrewStatus = incomingdata.data[0].customFieldValuesExt.crewStatusCustom;
				}

				if (incomingdata.data[0].customFieldValuesExt.employeeid !== undefined) {
					Createpayload.Operations[0].Object.ID = incomingdata.data[0].customFieldValuesExt.employeeid;
				}

			}
			var MobileWebClientSettings = session.parameters.MobileWebClientSettings;
			Createpayload.Operations[0].Object.MobileWebClientSettings.Key = MobileWebClientSettings;
			Createpayload.Operations[0].Object.Name = incomingdata.data[0].name;
			if (incomingdata.data[0].phoneNumber !== undefined) {
				Createpayload.Operations[0].Object.MobilePhone = incomingdata.data[0].phoneNumber;
			}
			session.output.write(Createpayload);
			ctx.setVariable('FSECreatepayload', Createpayload);
			var Auth = "Basic " + session.parameters.FSETOKEN;
			var FSEapicall = {
				target: session.parameters.FseUrlCreateUpdate,
				sslClientProfile: 'FSE_Client_Profile',
				method: 'POST',
				contentType: 'application/json',
				headers: {
					'Authorization': Auth
				},
				data: Createpayload
			};
			var info = " TargetURL :" + session.parameters.FseUrlCreateUpdate + "; Method :" + 'POST' + "; Data :" + JSON.stringify(Createpayload) + ". ";
			urlopen.open(FSEapicall, function(error, response) {
				if (error) {
					var ctx = session.name("csyn") || session.createContext("csyn");
					ctx.setVariable("retry", 'yes');
					var errorinfo = "url connection error , details are : " + info + "; error info :" + JSON.stringify(error)
					ctx.setVariable("errormessage", errorinfo);
					logger.debug("urlopen connect error with connecting to  FSEapi create call  is " + JSON.stringify(error));
					var ErrorTxt = "csyn_FSE_002 in service foa_csyn_SendCrewUpdates urlopen connect error with connecting to  FSEapi create call  is  " + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					var responseStatusCode = response.statusCode;
					var ctx = session.name("csyn") || session.createContext("csyn");
					ctx.setVariable('exitStatus', responseStatusCode);
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("error message while reading response from FSE Create api call is " + JSON.stringify(error));
								session.reject("error message while reading response from FSE Create api call is " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
							}
						});
					} else if ((responseStatusCode == 401)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "csyn_FSE_004 : Unauthorized error message while reading response from FSE Create Api , details are : " + info + "; error info :" + JSON.stringify(error)
								ctx.setVariable("errormessage", errorinfo);
								logger.error("csyn_FSE_004 : error message while reading response from FSE Create Api " + JSON.stringify(error));
								session.reject("csyn_FSE_004 : error message while reading response from FSE Create Api  " + JSON.stringify(error));
							} else {
								var errorinfo = "csyn_FSE_004 : Unauthorized error message while reading response from FSE Create Api , details are : " + info + "; error info :" + "Error returned while doing post for Create fse api call is  statusCode " + responseStatusCode + " Unauthorized"
								ctx.setVariable("errormessage", errorinfo);
								logger.error("csyn_FSE_004 : Unauthorized Error returned while doing post for Create fse api call is  statusCode " + responseStatusCode + " response info :" + responseData);
								session.reject("csyn_FSE_004 : Unauthorized Error returned while doing post for Create fse api call is  statusCode " + responseStatusCode + " response info :" + responseData);
							}
						});
					} else if ((responseStatusCode == 403)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "csyn_FSE_005 : error message while reading response from FSE Create Api , details are : " + info + "; error info :" + JSON.stringify(error)
								ctx.setVariable("errormessage", errorinfo);
								logger.error("csyn_FSE_005 : error message while reading response from FSE Create Api " + JSON.stringify(error));
								session.reject("csyn_FSE_005 : error message while reading response from FSE Create Api  " + JSON.stringify(error));
							} else {
								var errorinfo = "csyn_FSE_005 : error message while reading response from FSE Create Api , details are : " + info + "; error info :" + "Error returned while doing post for Create fse api call is  statusCode " + responseStatusCode + " Unauthorized"
								ctx.setVariable("errormessage", errorinfo);
								logger.error("csyn_FSE_005 : Error returned while doing post for Create fse api call is  statusCode " + responseStatusCode + " response info :" + responseData);
								session.reject("csyn_FSE_005 : Error returned while doing post for Create fse api call is  statusCode " + responseStatusCode + " response info :" + responseData);
							}
						});
					} else if ((responseStatusCode == 500)) {

						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "url connection error , details are : " + info + "; error info :" + JSON.stringify(error)
								ctx.setVariable("errormessage", errorinfo);
								logger.error("Error returned while doing post for Create fse api call is  " + JSON.stringify(error));
								session.reject("Error returned while post for Create fse api call is" + JSON.stringify(error));
							} else {
								var flagvalue;
								var FSEAPIRes = JSON.parse(responseData);
								var errorcode = session.parameters.responseErrorcodes;
								var ErrorCodeList = errorcode.split(',');
								if (!(FSEAPIRes.ExceptionMessage == undefined || FSEAPIRes.ExceptionMessage == '')) {
									var errormessage = session.parameters.responseErrormessage;
									var message = FSEAPIRes.ExceptionMessage;
									if (message.includes(errormessage)) {
										flagvalue = true;
									} else {
										for (var i = 0; i < ErrorCodeList.length; i++) {
											var numberval = Number(ErrorCodeList[i])
											if (message.includes(String(numberval))) {
												flagvalue = true;
											}
										}
									}
								} else {
									var exception = FSEAPIRes.ErrorNumber
									for (var i = 0; i < ErrorCodeList.length; i++) {
										var numberval = Number(ErrorCodeList[i])
										if (exception.includes(String(numberval))) {
											flagvalue = true;
										}

									}
								}
								if (flagvalue) {
									var ctx = session.name("csyn") || session.createContext("csyn");
									ctx.setVariable("retry", 'yes');
									var errorinfo = "FSEAPIRes.ExceptionMessage errorCode : " + JSON.stringify(FSEAPIRes.ExceptionMessage);
									ctx.setVariable("errormessage", errorinfo);
									var ErrorTxt = "Error returned while doing post for Create fse api call , details are: " + info + "error info:" + JSON.stringify(FSEAPIRes.ExceptionMessage);
									ctx.setVariable("ErrorTxt", ErrorTxt);
								}
								else {
									var ctx = session.name("csyn") || session.createContext("csyn");
									var errorinfo = "url connection error , details are : " + info + "; error info :" + "Error returned while Create fse api call  statusCode " + responseStatusCode + " " + responseData
									ctx.setVariable("errormessage", errorinfo);
									logger.error("Error returned while Create fse api call  statusCode " + responseStatusCode + " " + responseData);
									session.reject("Error returned while Create fse api call " + responseStatusCode + " " + responseData);
								}
							}
						});

					}

					else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "url connection error , details are : " + info + "; error info :" + JSON.stringify(error)
								ctx.setVariable("errormessage", errorinfo);
								logger.error("Error returned while doing post for Create fse api call is  " + JSON.stringify(error));
								session.reject("Error returned while post for Create fse api call is" + JSON.stringify(error));
							} else {
								var errorinfo = "url connection error , details are : " + info + "; error info :" + "Error returned while Create fse api call  statusCode " + responseStatusCode + " " + responseData
								ctx.setVariable("errormessage", errorinfo);
								logger.error("Error returned while Create fse api call  statusCode " + responseStatusCode + " " + responseData);
								session.reject("Error returned while Create fse api call " + responseStatusCode + " " + responseData);
							}
						});
					}
				}
			});




		}
	}
});
