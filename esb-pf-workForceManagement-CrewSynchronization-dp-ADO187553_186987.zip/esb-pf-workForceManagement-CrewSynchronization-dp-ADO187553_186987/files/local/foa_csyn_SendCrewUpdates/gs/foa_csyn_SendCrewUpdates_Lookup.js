var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("csyn") || session.createContext("csyn");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	// getting styleheet params
	var ctx = session.name("csyn") || session.createContext("csyn");
	if (readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
		ctx.setVariable('exitStatus', '500');
		var deprecated = incomingdata.data[0].deprecated;
		var retry = ctx.getVar("retry");
		//	operation = 'UPDATE';
		if (deprecated !== true && retry !== 'yes') {
			var id = incomingdata.data[0].aorIDs[0];
			var lookupURL = session.parameters.lookupURL;
			var lookupMessage;
			if (incomingdata.data[0].type == undefined || incomingdata.data[0].type == "") {
				lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "aors",
								"id": id
							}
						]
					}
				}
			} else {
				lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "aors",
								"id": id
							}, {
								"name": "crewTypes",
								"status": incomingdata.data[0].type
							}
						]
					}
				}


			}
			var url = lookupURL;
			var LookupServiceResponse = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + url + "; Method :" + 'POST' + "; Data :" + JSON.stringify(lookupMessage) + ". ";
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "urlopen connect error with aors LookupServiceResponse , details are : " + info + "; error info :" + JSON.stringify(error)
					ctx.setVariable("errormessage", errorinfo);
					logger.error("urlopen connect error with aors LookupServiceResponse is " + JSON.stringify(error));
					session.reject(" urlopen connect error with aors LookupServiceResponse is " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in getting message for aorids LookupServiceResponse for aorid" + id +  "details are : " + info + "error info :" + JSON.stringify(error)
								ctx.setVariable("errormessage", errorinfo);
								logger.error(" failure in getting message for aorids LookupServiceResponse for aorid" + id + " " + JSON.stringify(error));
								session.reject("failure in getting message for aorids LookupServiceResponse for aorid" + id + " " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								var lookupResponse = JSON.parse(responseData)
								var ctx = session.name("csyn") || session.createContext("csyn");
								var lookuplabel;
								if (lookupResponse.lookupRep.type[0].result == 0) {
									lookuplabel = lookupResponse.lookupRep.type[0].label;
									ctx.setVariable("lookuplabelAORID", lookuplabel);
									var labelValue = lookuplabel.substring(0, 3);
									ctx.setVariable("labelValue", labelValue);
									if (labelValue != 'DTE') {
										var MaximoLookupMap = new Map([
											['NAE', 'NE'],
											['MTC', 'NE'],
											['MAR', 'NE'],
											['LAP', 'NE'],
											['SBY', 'NW'],
											['PON', 'NW'],
											['HWL', 'NW'],
											['RFD', 'SE'],
											['CAN', 'SE'],
											['TBY', 'SE'],
											['ANN', 'SW'],
											['WWS', 'SW'],
											['NPT', 'SW']
										]);
										var aordlabelRegion;
										if (MaximoLookupMap.has(labelValue)) {
											aordlabelRegion = MaximoLookupMap.get(labelValue);
											ctx.setVariable('aordlabelRegion', MaximoLookupMap.get(labelValue));
											//distic map
											var DistrictLookupMap = new Map([
												['NAE', 'North Area Energy Ctr'],
												['MTC', 'Mt. Clemens'],
												['MAR', 'Marysville'],
												['LAP', 'Lapeer'],
												['SBY', 'Shelby'],
												['PON', 'Pontiac'],
												['HWL', 'Howell'],
												['RFD', 'Redford'],
												['CAN', 'Caniff'],
												['TBY', 'Trombly'],
												['ANN', 'Ann Arbor'],
												['WWS', 'Western Wayne'],
												['NPT', 'Newport']
											]);

											var aordlabelDistrict;
											if (MaximoLookupMap.has(labelValue)) {
												aordlabelDistrict = DistrictLookupMap.get(labelValue);
												ctx.setVariable('aordlabelDistrict', DistrictLookupMap.get(labelValue));
											} else {
												ctx.setVariable('aordlabelDistrict', '');
											}

											//distic map


										} else {
											logger.error("No match found for aorIDs label" + labelValue + "in region table");
											//session.reject("No match found for aorIDs label"+labelValue+"in region table");
										}

									} else {
										if (incomingdata.data[0].aorIDs[1] != undefined) {
											var id = incomingdata.data[0].aorIDs[1];
											var lookupURL = session.parameters.lookupURL;
											var lookupMessage;

											lookupMessage = {
												"lookupReq": {
													"type": [
														{
															"name": "aors",
															"id": id
														}
													]
												}
											}




											var url = lookupURL;
											var LookupServiceResponse = {
												target: url,
												method: 'POST',
												contentType: 'application/json',
												data: lookupMessage
											};
											var info = " TargetURL :" + url + "; Method :" + 'POST' + "; Data :" + JSON.stringify(lookupMessage) + ". ";
											urlopen.open(LookupServiceResponse, function(error, response) {
												if (error) {
													var errorinfo = "lookup url connection error , details are : " + info + "; error info :" + JSON.stringify(error)
													ctx.setVariable("errormessage", errorinfo);
													logger.error("urlopen connect error with aors LookupServiceResponse is " + JSON.stringify(error));
													session.reject(" urlopen connect error with aors LookupServiceResponse is " + JSON.stringify(error));
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "lookup url connection error , details are : " + info + "; error info :" + JSON.stringify(error)
																ctx.setVariable("errormessage", errorinfo);
																logger.error(" failure in getting message for aorids LookupServiceResponse for aorid" + id + " " + JSON.stringify(error));
																session.reject("failure in getting message for aorids LookupServiceResponse for aorid" + id + " " + JSON.stringify(error));
															} else {
																hm.response.statusCode = responseStatusCode;
																var lookupResponse = JSON.parse(responseData)
																var ctx = session.name("csyn") || session.createContext("csyn");
																var lookuplabel;
																if (lookupResponse.lookupRep.type[0].result == 0) {
																	lookuplabel = lookupResponse.lookupRep.type[0].label;
																	ctx.setVariable("lookuplabelAORID", lookuplabel);

																	var labelValue = lookuplabel.substring(0, 3);

																	ctx.setVariable("labelValue", labelValue);
																	var MaximoLookupMap = new Map([
																		['NAE', 'NE'],
																		['MTC', 'NE'],
																		['MAR', 'NE'],
																		['LAP', 'NE'],
																		['SBY', 'NW'],
																		['PON', 'NW'],
																		['HWL', 'NW'],
																		['RFD', 'SE'],
																		['CAN', 'SE'],
																		['TBY', 'SE'],
																		['ANN', 'SW'],
																		['WWS', 'SW'],
																		['NPT', 'SW']
																	]);
																	var aordlabelRegion;
																	if (MaximoLookupMap.has(labelValue)) {
																		aordlabelRegion = MaximoLookupMap.get(labelValue);
																		ctx.setVariable('aordlabelRegion', MaximoLookupMap.get(labelValue));
																		//distic map
																		var DistrictLookupMap = new Map([
																			['NAE', 'North Area Energy Ctr'],
																			['MTC', 'Mt. Clemens'],
																			['MAR', 'Marysville'],
																			['LAP', 'Lapeer'],
																			['SBY', 'Shelby'],
																			['PON', 'Pontiac'],
																			['HWL', 'Howell'],
																			['RFD', 'Redford'],
																			['CAN', 'Caniff'],
																			['TBY', 'Trombly'],
																			['ANN', 'Ann Arbor'],
																			['WWS', 'Western Wayne'],
																			['NPT', 'Newport']
																		]);

																		var aordlabelDistrict;
																		if (MaximoLookupMap.has(labelValue)) {
																			aordlabelDistrict = DistrictLookupMap.get(labelValue);
																			ctx.setVariable('aordlabelDistrict', DistrictLookupMap.get(labelValue));
																		} else {
																			ctx.setVariable('aordlabelDistrict', '');
																		}

																		//distic map


																	} else {
																		logger.error("No match found for aorIDs label" + labelValue + "in region table");
																		//session.reject("No match found for aorIDs label"+labelValue+"in region table");
																	}
																}
																else {
																	logger.error("lookup service result code for aorIDs" + id + " LookupServiceResponse  is " + lookupResponse.lookupRep.type[0].result);
																	//session.reject ("lookup service result code for aorIDs"+ id+" LookupServiceResponse  is"+lookupResponse.lookupRep.type[0].result);
																}// lookup end;

															}
														});
													} else {
														var errorinfo = "lookup url connection error , details are : " + info + "; error info : response code" + responseStatusCode;
														ctx.setVariable("errormessage", errorinfo);
														logger.error("lookup service result code for aorIDs" + id + " LookupServiceResponse  is  responsecode is " + responseStatusCode);
														session.reject("lookup service result code for aorIDs" + id + " LookupServiceResponse  is  responsecode is " + responseStatusCode);
													}
												}
											});
											//			
										}

									}



								}
								else {
									logger.error("lookup service result code for aorIDs" + id + " LookupServiceResponse  is " + lookupResponse.lookupRep.type[0].result);
									//session.reject ("lookup service result code for aorIDs"+ id+" LookupServiceResponse  is"+lookupResponse.lookupRep.type[0].result);
								}// lookup end;
								if (lookupResponse.lookupRep.type[1] != undefined) {
									if (lookupResponse.lookupRep.type[1].result == 0) {
										var EngineerTypelabel = lookupResponse.lookupRep.type[1].label;
										ctx.setVariable("EngineerTypeLabel", EngineerTypelabel);
									}
								}
							}
						});
					} else {
						var errorinfo = "lookup service result code for aorIDs" + id + " LookupServiceResponse  is  responsecode is " + responseStatusCode + "details are:" + info;
						ctx.setVariable("errormessage", errorinfo);
						logger.error("lookup service result code for aorIDs" + id + " LookupServiceResponse  is  responsecode is " + responseStatusCode);
						session.reject("lookup service result code for aorIDs" + id + " LookupServiceResponse  is  responsecode is " + responseStatusCode);
					}
				}
			});
			//			
		}
	}
});
