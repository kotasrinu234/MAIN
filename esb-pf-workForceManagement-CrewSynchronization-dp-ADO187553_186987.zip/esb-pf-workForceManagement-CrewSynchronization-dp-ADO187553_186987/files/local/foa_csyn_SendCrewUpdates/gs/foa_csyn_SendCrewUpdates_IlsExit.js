var ctx = session.name("csyn") || session.createContext("csyn");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
	var retry = ctx.getVariable('retry');
	var ExitStatusCode = ctx.getVariable('exitStatus');
	var ErrorTxt = ctx.getVariable('ErrorTxt')
	var Region = ctx.getVar("aordlabelRegion");
	var District = ctx.getVar("aordlabelDistrict");
	if (Region != undefined) {
			ctx.setVariable('region', Region);
		}
		if (District != undefined) {
			ctx.setVariable('district', District);
		}
	if(retry != 'yes'){
	ctx.setVariable('exitStatus','0');
	ctx.setVariable('exitDestination',session.parameters.FseUrlCreateUpdate );
	ctx.setVariable('Exitdescription',session.parameters.EXITdescription )
	}else{
		ctx.setVariable('exitDestination',session.parameters.FseUrlCreateUpdate );	
	ctx.setVariable('exitStatus',ExitStatusCode);
	ctx.setVariable('Exitdescription',ErrorTxt)
	}
	}
	});
