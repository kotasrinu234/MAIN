var ctx = session.name("csyn")|| session.createContext("csyn");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({'category': 'all'});
var urlIn = sm.getVar('var://service/URL-in');
var CancelQueue = session.parameters.CancelQueue;
var CreateUpdateQueue = session.parameters.CreateUpdateQueue;
session.input.readAsJSON(function(readAsJSONError, incommingdata){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
	} else {
				ctx.setVariable('correlationID',incommingdata.messageID);
				//ctx.setVariable('interfaceName',session.parameters.interfaceName);
				ctx.setVariable('messageType',session.parameters.messageType);
				if(incommingdata.data[0].updatedAt !=undefined){
					ctx.setVariable('sourceEventTimestamp',incommingdata.data[0].updatedAt);}
				var urlIn = sm.getVar('var://service/URL-in');
				ctx.setVariable('sourceUrl',urlIn)
				if(incommingdata.data[0].customFieldValuesExt !=undefined){
					if(incommingdata.data[0].customFieldValuesExt.employeeid !=undefined){
					ctx.setVariable('employeeDisplayID',incommingdata.data[0].customFieldValuesExt.employeeid);
					}
					if(incommingdata.data[0].customFieldValuesExt.CrewID !=undefined){
					ctx.setVariable('crewDisplayID',incommingdata.data[0].customFieldValuesExt.CrewID);
					}
					if(incommingdata.data[0].customFieldValuesExt.crewStatusCustom !== undefined){
						ctx.setVariable('OUGCrewStatus',incommingdata.data[0].customFieldValuesExt.crewStatusCustom);
		}
					}
				if(incommingdata.data[0].active !=undefined){
					ctx.setVariable('active',incommingdata.data[0].active);}
					if(incommingdata.data[0].active !=undefined){
					ctx.setVariable('active',incommingdata.data[0].active);}	
				if(incommingdata.data[0].active !=undefined){
					ctx.setVariable('active',incommingdata.data[0].active);}	
				ctx.setVariable('ENTRYdescription',session.parameters.ENTRYdescription)
				
				
				
	}
});
