//js is used to perform nullcheck for the input request
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var nullCheckRequired = session.parameters.nullCheckRequired;
	
	if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
	var ctx = session.name("csyn")|| session.createContext("csyn");
		if(nullCheckRequired == 'yes'){
			var name = incomingdata.data[0].name;
			if (name === null || name === '' || name === undefined) {
				logger.error('name is not present in input  payload');
				ctx.setVariable("schemafailed", 'yes')
	            session.reject('name is not present in input  payload');

	        }	
			var aorIDs = incomingdata.data[0].aorIDs;
			
			if (aorIDs === null || aorIDs === '' || aorIDs === undefined) {
				logger.error('aorIDs is not present in input payload');
				ctx.setVariable("schemafailed", 'yes')
				session.reject('aorIDs is not present in input payload');
	        }else if(aorIDs.length==0){
		logger.error('aorIDs is not present in input payload');
		ctx.setVariable("schemafailed", 'yes')
				session.reject('aorIDs is not present in input payload');
	}	
								
			var onShift = incomingdata.data[0].onShift;
			if (onShift === null || onShift === '' || onShift === undefined) {
	           logger.error('onShift is not present in input payload');
ctx.setVariable("schemafailed", 'yes')
				session.reject('onShift is not present in input payload');
	        }	
				
			var type = incomingdata.data[0].type;
			if (type === null || type === '' || type === undefined) {
	           logger.error(' type is not present in input payload');
ctx.setVariable("schemafailed", 'yes')
				session.reject('type is not present in input payload');
	        }	
			var CrewID = incomingdata.data[0].customFieldValuesExt.CrewID;
			if (CrewID === null || CrewID === '' || CrewID === undefined) {
		           logger.error('CrewID is not present in input payload');
ctx.setVariable("schemafailed", 'yes')
					session.reject('CrewID is not present in input payload');
		        }
			
		}
		}
	
		
	});