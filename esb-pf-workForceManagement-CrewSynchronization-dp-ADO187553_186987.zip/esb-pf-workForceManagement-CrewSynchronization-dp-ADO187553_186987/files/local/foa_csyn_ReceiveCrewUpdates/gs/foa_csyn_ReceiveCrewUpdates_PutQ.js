var ctx = session.name("csyn") || session.createContext("csyn");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		ctx.setVariable('exitStatus','500')
		
		var incommingdata = JSON.parse(jsonData);
		var correlationID = ctx.getVar("correlationID");
																
		incommingdata.messageID =correlationID
		var StandaloneMQurl = session.parameters.BackendMQurl;
		var publishuri = {
			target: StandaloneMQurl,
			data: incommingdata
		};
		
	var info = " TargetURL :" + session.parameters.BackendMQurl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(incommingdata) + ". ";	

try {
		urlopen.open(publishuri, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error , details are : " + info + "; error info :" + error
								  ctx.setVariable("errormessage",errorinfo);
				logger.error(" : Mqurlopen.open error while keeping message to queue is " + error);
				session.reject(": Mqurlopen.open error while keeping message to queue is " + error);
			} else {
				var mqrc = response.statusCode;
		ctx.setVariable('exitStatus',mqrc)
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							session.reject(": Mqurlopen.open error while keeping message to queue is " + readError);
						} else {
									ctx.setVariable('exitStatus',0)
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var errorinfo = " Mqurlopen.open connection error , details are : " + info + "; error info :" + mqrc
					 ctx.setVariable("errormessage",errorinfo);
					logger.error(errorinfo);
					session.reject(errorinfo);

				}
			}
		});
		}catch(err) {
				var errorinfo = "url connection error , details are : " + info + "; error info :" + err
				ctx.setVariable('exitStatus', '500');
				  ctx.setVariable("errormessage",errorinfo);
				ctx.setVariable("Exitdescription", errorinfo);
				session.reject(errorinfo);
			}
		//pushing to queue end

	}
});
