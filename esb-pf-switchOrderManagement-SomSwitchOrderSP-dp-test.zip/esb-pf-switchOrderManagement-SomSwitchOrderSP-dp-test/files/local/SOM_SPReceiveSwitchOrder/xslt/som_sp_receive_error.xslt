<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" version="1.0" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
    <xsl:variable name="somErrorCode" select="dp:variable('var://context/som/customErrorCode')"/>
    <xsl:variable name="somErrorMessage" select="dp:variable('var://context/som/customErrorMessage')"/>
    <xsl:variable name="somReasonMessage" select="dp:variable('var://context/som/customReasonMessage')"/>
    <xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
    <xsl:variable name="systemErrorMessage" select="dp:variable('var://service/error-message')"/>
    <xsl:template match="/">
        <xsl:variable name="msgId" select="*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'msgId']]"/>
        <xsl:variable name="customErrorCode">
            <xsl:if test="$somErrorCode">
                <xsl:value-of select="$somErrorCode"/>
            </xsl:if>
        </xsl:variable>
        <xsl:variable name="customErrorMessage">
            <xsl:if test="$somErrorMessage">
                <xsl:value-of select="$somErrorMessage"/>
            </xsl:if>
        </xsl:variable>
        <xsl:variable name="customReasonMessage">
            <xsl:if test="$somReasonMessage">
                <xsl:value-of select="$somReasonMessage"/>
            </xsl:if>
        </xsl:variable>
        <json:object xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">
            <xsl:choose>
                <xsl:when test="string($customErrorCode) !=''">
                    <xsl:variable name="code" select="$customErrorCode"/>
                    <xsl:variable name="text" select="concat(' ', $customReasonMessage)"/>
                    <dp:set-variable name="'var://service/error-protocol-response'" value="$code"/>
                    <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$customReasonMessage"/>
                    <xsl:if test="$msgId">
                        <json:string name="msgId">
                            <xsl:value-of select="$msgId"/>
                        </json:string>
                    </xsl:if>
                    <json:string name="errorCode">
                        <xsl:value-of select="$customErrorCode"/>
                    </json:string>
                    <json:string name="errorDescription">
                        <xsl:value-of select="$customErrorMessage"/>
                    </json:string>
                    <xsl:message dp:type="all" dp:priority="error">id=somSp_re_01|errorString:<xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage)"/>
                    </xsl:message>
                </xsl:when>
                <xsl:when test="string($customErrorCode) =''">
                    <xsl:if test="$msgId">
                        <json:string name="msgId">
                            <xsl:value-of select="$msgId"/>
                        </json:string>
                    </xsl:if>
                    <json:string name="errorCode">
                        <xsl:value-of select="$systemErrorCode"/>
                    </json:string>
                    <json:string name="errorDescription">
                        <xsl:value-of select="$systemErrorMessage"/>
                    </json:string>
                    <xsl:variable name="errorMessage">
                        <xsl:value-of select="normalize-space(concat('id=somSp_re_02| AAA failure for SOM username :', dp:variable('var://context/WSM/identity/username'), ' with Statuscode 401, errorString:', concat('ErrorCode =', $systemErrorCode, ', Error Message = ', $systemErrorMessage)))"/>
                    </xsl:variable>
                    <xsl:message dp:type="all" dp:priority="error">
                        <xsl:value-of select="$errorMessage"/>
                    </xsl:message>
                    <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'401'"/>
<dp:set-variable name="'var://context/ILS/ErrorDescription'" 
                 value="concat($errorMessage)"/>
                </xsl:when>
            </xsl:choose>
        </json:object>
        <dp:set-http-request-header name="'Content-Type'" value="'application/json'"/>
    </xsl:template>
</xsl:stylesheet>
