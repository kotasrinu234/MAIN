var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.INPUT.readAsJSON(function(error, incomingdata) {
    if (error) {
        var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
    }
	if((incomingdata[0].displayID=== undefined)||(incomingdata[0].displayID===null)||(incomingdata[0].displayID=== '')){
		if((incomingdata[0].customId=== undefined)||(incomingdata[0].customId===null)){
		session.reject("The displayID or customId is a mandatory field ");
		}
	};
	if((incomingdata[0].status=== undefined)||(incomingdata[0].status===null)||(incomingdata[0].status==='')){
		session.reject("The status is a mandatory field ");
	};
	/* if((incomingdata[0].location=== undefined)||(incomingdata[0].location===null)||(incomingdata[0].location=== '')){
		session.reject("The location is a mandatory field ");
	}; */
	/* if((incomingdata[0].plannedStart=== undefined)||(incomingdata[0].plannedStart===null)||(incomingdata[0].plannedStart==='')){
		session.reject("The plannedStart is a mandatory field ");
	}; */
	/*if((incomingdata[0].createdAt=== undefined)||(incomingdata[0].createdAt===null)||(incomingdata[0].createdAt==='')){
		session.reject("The createdAt is a mandatory field ");
	};
	if((incomingdata[0].updatedAt=== undefined)||(incomingdata[0].updatedAt===null)||(incomingdata[0].updatedAt==='')){
		session.reject("The updatedAt is a mandatory field ");
	};*/
	if((incomingdata[0].switchOrderTypeObjectID=== undefined)||(incomingdata[0].switchOrderTypeObjectID===null)||(incomingdata[0].switchOrderTypeObjectID==='')){
		session.reject("The switchOrderTypeObjectID is a mandatory field ");
	};
	if((incomingdata[0].customFieldValuesExt=== undefined)||(incomingdata[0].customFieldValuesExt===null)||(incomingdata[0].customFieldValuesExt==='')){
		session.reject("customFieldValuesExt is a mandatory field ");
	};
	/* if((incomingdata[0].customFieldValuesExt.Job_Status===undefined)||(incomingdata[0].customFieldValuesExt.Job_Status===null)||(incomingdata[0].customFieldValuesExt.Job_Status==='')){
		session.reject("The customFieldValuesExt.Job_Status is a mandatory field ");
	}; */
/* 	if((incomingdata[0].customFieldValuesExt.Work_Start=== undefined)||(incomingdata[0].customFieldValuesExt.Work_Start===null)||(incomingdata[0].customFieldValuesExt.Work_Start==='')){
		session.reject("The customFieldValuesExt.Work_Start is a mandatory field ");
	}; */
	if((incomingdata[0].createdByUser=== undefined)||(incomingdata[0].createdByUser===null)||(incomingdata[0].createdByUser==='')){
		session.reject("The createdByUser is a mandatory field ");
	};
	if((incomingdata[0].createdByUser.userID=== undefined)||(incomingdata[0].createdByUser.userID===null)||(incomingdata[0].createdByUser.userID==='')){
		session.reject("The createdByUser.userID is a mandatory field ");
	};
	
});
