var sm = require('service-metadata');
var urlopen = require('urlopen');
var callMQURL = require('./callMQURL.js');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("som") || session.createContext("som");
var ILSctx = session.name('ILS') || session.createContext('ILS');

var uri = new String(sm.URI);
var splituri = uri.toString().split("/");
ctx.setVariable("splituri", splituri);
var seqValue = splituri[5];
ctx.setVariable("seqValue", seqValue);

var createReqQ = session.parameters.createReqQ; //SOM.SP.RECEIVE.SWITCH.ORDER
ILSctx.setVariable("ExitDestination", createReqQ);

var createQueueManager = session.parameters.createQueueManager; //SOM.SP.RECEIVE.SWITCH.ORDER_QMgr

session.input.readAsJSON(function(error, incomingdata) {
	if (error) {
		var errorinfo = "Error in parsing incoming request" + "; error info :" + error
		ILSctx.setVariable('ExitStatus', '500')
		ILSctx.setVariable("ErrorDescription", errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
		//throw error;
	}
	var json = incomingdata;
	var messageID = ILSctx.getVariable('correlationID');

	json[0].messageID = messageID
	if (json[0].messageID === undefined || json[0].messageID === null || json[0].messageID === '') {
		ILSctx.setVariable('correlationID', ' ');
	} else {
		ILSctx.setVariable('correlationID', json[0].messageID);
	}
	var urlopenurl = 'dpmq://' + createQueueManager + '/?RequestQueue=' + createReqQ;
	callMQURL(urlopenurl, seqValue, 'SOM_MQ', json);
	session.output.write(json);
}); 
