var logger = console.options({ 'category': 'all' });
var ctxSPSwitch = session.name("SOM_SPReceiveSwitch_Seq") || session.createContext("SOM_SPReceiveSwitch_Seq");
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.input.readAsJSON(function(readAsJSONError, decodedJsonpayload) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data, details are:"; "error info :" + readAsJSONError
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
		hm.response.statusCode = 500;
		session.output.write(errorinfo);
		session.reject(errorinfo);
	} else {
		ctxSPSwitch.setVariable('IncomingPayload', decodedJsonpayload);
		var base64encode = decodedJsonpayload.payload;
	}
})
