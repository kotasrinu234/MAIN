var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var maximoUpdateLookup = require('./SOM_lookUp.js');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('som') || session.createContext('som');
var jsonPayload = ctx.getVariable('jsonPayload');
var StatusID;

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data for ILS, details are: "; "error info :" + readAsJSONError
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
	} else {
		var transitionHistoryData = jsonPayload[0].transitionHistory;
		var statusMappings = transitionHistoryData[0].statusID
		ctx.setVariable("statusMappings", statusMappings)

		var typeArr = new Array();

		for (var a = 0, b = 1; a < transitionHistoryData.length && b < transitionHistoryData.length - 1; a++, b++) {
			transitionHistoryData.sort(function compare(a, b) {
				var dateA = new Date(a.transitionedAt);
				var dateB = new Date(b.transitionedAt);
				return dateA - dateB;
			});
		}

		var sortedtransitionHistory = transitionHistoryData;
		ctx.setVariable("sortedtransitionHistory", sortedtransitionHistory)

		var elementBeforeLatest;
		if (sortedtransitionHistory.length > 1) {
			elementBeforeLatest = sortedtransitionHistory[sortedtransitionHistory.length - 2];
			if (elementBeforeLatest === null || elementBeforeLatest === undefined || elementBeforeLatest === '') {
				ctx.setVariable("elementBeforeLatest", '');
			}
			else {
				ctx.setVariable("elementBeforeLatest", elementBeforeLatest);
			}
		} else {
			elementBeforeLatest = sortedtransitionHistory[sortedtransitionHistory.length - 1];
			if (elementBeforeLatest === null || elementBeforeLatest === undefined || elementBeforeLatest === '') {
				ctx.setVariable("elementBeforeLatest", '');
			}
			else {
				ctx.setVariable("elementBeforeLatest", elementBeforeLatest);
			}
		}
		StatusID = elementBeforeLatest.statusID;

		//var lastSwitchOrderStatus = transitionHistoryData.reverse().find(entry => entry.statusID);
		//ctx.setVariable("lastSwitchOrderStatus", lastSwitchOrderStatus)

		/*if (lastSwitchOrderStatus !== null && lastSwitchOrderStatus !== undefined && lastSwitchOrderStatus !== '') {
				maximoStatus = statusMappings.includes[lastSwitchOrderStatus.statusID];
				ctx.setVariable("maximoStatus", maximoStatus)
			} */
		var switchOrderWorkflowReq = {};
		switchOrderWorkflowReq.name = "switchOrder.WorkFlowStatus";
		switchOrderWorkflowReq.id = StatusID;
		typeArr.push(switchOrderWorkflowReq);
		maximoUpdateLookup(typeArr, "MaximoUpdate");
	}
});
