var sm = require('service-metadata');
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});
var hm = require('header-metadata');
var ctx = session.name('som') || session.createContext('som');
var seqResponsedata = ctx.getVariable("seqResponse")
session.output.write(seqResponsedata);
