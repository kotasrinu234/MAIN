var sm = require('service-metadata');
var urlopen = require('urlopen');
var doLookup = require('./SOM_lookUp.js');
var logger = console.options({
	'category': 'all'
});
var hm = require('header-metadata');
var ms = require('multistep');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('som') || session.createContext('som');
var ctxSeq = session.name("SOM_SPReceiveSwitch_Seq") || session.createContext("SOM_SPReceiveSwitch_Seq");
var messageId = ctxSeq.getVariable("messageId");
var eventType = ctxSeq.getVariable("eventType");
var serviceName = ctxSeq.getVariable("serviceName");
var dateTime = new Date();
var sendTimeStamp = dateTime.toISOString();
var eventContext = ctxSeq.getVariable("eventContext");
var EventTimeStamp = ctxSeq.getVariable("EventTimeStamp");
var lookupResponse1 = ctx.getVar("lookupResponse1");

//Sequance Confirmation req 

var seqResponse = {
	"messageId": messageId,
	"messageType": session.parameters.messageType,
	"eventType": eventType,
	"serviceName": serviceName,
	"sendTimeStamp": sendTimeStamp,
	"confirmation": 'Y'
}
if (eventContext != undefined || eventContext != null || eventContext != '') {
	seqResponse.eventContext = eventContext
}
if (EventTimeStamp != undefined || EventTimeStamp != null || EventTimeStamp != '') {
	seqResponse.EventTimeStamp = EventTimeStamp
}
SEQResponse(seqResponse);
var ExitDescription = session.parameters.SequenceExitDescription;
session.input.readAsJSON(function(error, incomingdata) {
	/* var headers = hm.current;
	headers.remove('MQMD'); */


	if (error) {
		var errorinfo = "Error in parsing incoming request , details are: "; " error info :" + error
		logger.error(errorinfo);
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		session.reject(errorinfo);
		//throw error;
	}

	//var encodedPayload = incomingdata.payload;
	var jsonPayload = incomingdata;
	ctx.setVariable("jsonPayload", jsonPayload);


	//lookup start
	if (lookupResponse1) {
		if (lookupResponse1.lookupRep.type[0].result == 0) {
			if ((lookupResponse1.lookupRep.type[0].label != undefined) && (lookupResponse1.lookupRep.type[0].label != null) && (lookupResponse1.lookupRep.type[0].label != '')) {
				var orderType = lookupResponse1.lookupRep.type[0].label;
				ctx.setVariable('orderType', orderType);
			}
		}
	}
});

function SEQResponse(seqResponse) {
	var targetQueue = session.parameters.SeqConfirmationURL;
	var options = {
		target: targetQueue,
		data: seqResponse
	};
	ctx.setVariable("seqResponse", seqResponse);
	var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "SOM_AMCreateUpdateSwitchOrder Seq Confirmation Mqurlopen.open error, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo)
				logger.error('SOM_SP_013:' + errorinfo);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("retryFlag", "true");
				//session.reject('** Mqurlopen.open error');
				hm.response.statusCode = 500;
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							var errorinfo = "SOM_AMCreateUpdateSwitchOrder Seq Confirmation Mqurlopen.open error, details are : " + info + "; error info :" + readError
							ILSctx.setVariable('ExitStatus', mqrc);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error('SOM_SP_014:' + errorinfo);
							session.reject(errorinfo);
						} else {
							console.log("MQResponseData " + responseData);
							ILSctx.setVariable('ExitStatus', mqrc);
							ILSctx.setVariable('SequenceExitDescription', ExitDescription)
							ILSctx.setVariable("SequenceExitDestination", targetQueue);
							ms.callRule('SOM_SPSendToAm_SequenceConfirmation_rule', null, null, function(error) {
								if (error) {
									logger.error("Error in SOM_SPSendToAm_SequenceConfirmation_rule");
								}
							});
						}
					});
				} else {
					hm.response.statusCode = 500
					var errorinfo = 'SOM_AMCreateUpdateSwitchOrder Seq Confirmation Mqurlopen.open error [MQRC=' + mqrc + ']' + info
					ILSctx.setVariable('ExitStatus', mqrc);
					ILSctx.setVariable('ErrorDescription', errorinfo)
					logger.error('SOM_SP_015:' + errorinfo);
					session.reject(errorinfo);
				}
			}
		});
	} catch (error) {
		var errorinfo = "SOM_AMCreateUpdateSwitchOrder Seq Confirmation Mqurlopen.open error, details are : " + info + "; error info :" + error
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error('SOM_SP_013:' + errorinfo);
		ctx.setVariable("retry", 'yes');
		ctx.setVariable("retryFlag", "true");
		hm.response.statusCode = 500;
	}
}
