var ctx = session.name("som") || session.createContext("som");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var apiToken = session.parameters.apiToken;
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
function getURLResponse(url, myctx) {
	var options = {
		target: url,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "OMS_SOM_Client_Profile"

	};

	var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "urlopen error 'getURLResponse', details are : " + info + "; error info :" + error
				logger.error(errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo)
				ctx.setVariable("customErrorCode", '500');
				ctx.setVariable("customErrorMessage", errorinfo);
				ctx.setVariable("customReasonMessage", errorinfo);
				session.output.write(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response of 'getURLResponse', details are : " + info + "; error info :" + error
							logger.error(errorinfo);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logEvent(errorinfo);
							session.output.write(errorinfo);
						} else {
							var ctx = session.name('som') || session.createContext('som');
							ctx.setVariable(myctx, responseData);
						}
					})
				} else if (responseStatusCode == 401 || responseStatusCode == 403) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "SOM_SP_01:failure in reading message of getURLResponse, details are :  " + info + "error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "SOM_SP_01: response received from getURLResponse : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)						
								logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});

				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message of 'getURLResponse', details are : " + info + "; error info :" + error
							logger.error(errorinfo);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							session.reject(errorinfo);
						} else {
							var errorinfo = "response received from getURLResponse : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ErrorDescription', errorinfo);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		})
	} catch (error) {
		var errorinfo = "urlopen error 'getURLResponse', details are : " + info + "; error info :" + error
		logger.error(errorinfo);
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		ctx.setVariable("customErrorCode", '500');
		ctx.setVariable("customErrorMessage", errorinfo);
		ctx.setVariable("customReasonMessage", errorinfo);
		session.output.write(errorinfo);
		session.reject(errorinfo);
	}
}

module.exports = getURLResponse;
