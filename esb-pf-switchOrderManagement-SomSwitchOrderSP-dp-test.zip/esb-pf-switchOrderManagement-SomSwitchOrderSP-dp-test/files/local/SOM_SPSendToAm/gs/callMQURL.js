var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("som") || session.createContext("som");
var ILSctx = session.name('ILS') || session.createContext('ILS');

function callMQURL(url, trigValue, myctx, payload) {
	var mqmd = {
		MQMD: {
			StrucId: {
				$: 'MD '
			},
			Format: {
				$: 'MQHRF2 '
			},
			MsgType: {
				$: '8'
			},
			Persistence: {
				$: '1'
			}
		}
	};
	var mqrfh2 = {
		MQRFH2: {
			Version: {
				$: '2'
			},
			Format: {
				$: 'MQSTR'
			},
			NameValueData: {
				NameValue: [{
					usr: {
						somId: {
							$: trigValue
						},retryCount: {
							$: '-1'
						}
					}
				}]
			}
		}
	};
	var urlopenHeaders = {
		MQMD: mqmd,
		MQRFH2: mqrfh2
	};
	var options = {
		target: url,
		headers: urlopenHeaders,
		data: payload
	};
	var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "urlopen error MQ, details are : " + info + "; error info :" + error
				logger.error(errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo)
				/* ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt",error.errorMessage ); */
				ctx.setVariable("customErrorCode", errorinfo);
				ctx.setVariable("customErrorMessage", errorinfo);
				ctx.setVariable("customReasonMessage", errorinfo);
				session.reject(errorinfo);
			} else {
				var mqrc = response.statusCode;
				var reasonPhrase = response.reasonPhrase;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "som_sp error reading response from MQ, details are : " + info + "; error info :" + readError
							ILSctx.setVariable('ExitStatus', mqrc);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
							logger.error(errorinfo);
							//session.reject("som_sp Error reading response from MQ" + readError );	
						} else {
							var ctx = session.name("som") || session.createContext("som");
							ctx.setVariable(myctx + "_response", response);
							logger.info("MQResponseData" + responseData);
						}
					});
				} else {
					var errorinfo = 'som_spr: urlopen.open error [MQRC=' + mqrc + ']' + info
					logger.error(errorinfo);
					ILSctx.setVariable('ExitStatus', mqrc);
					ILSctx.setVariable('ErrorDescription', errorinfo)
					ctx.setVariable("customErrorCode", mqrc);
					ctx.setVariable("customErrorMessage", errorinfo);
					ctx.setVariable("customReasonMessage", errorinfo);
					session.reject(errorinfo);
				}
			}
		});
	} catch (error) {
		var errorinfo = "urlopen.open error MQ, details are : " + info + "; error info :" + error
		logger.error(errorinfo);
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		ctx.setVariable("customErrorCode", errorinfo);
		ctx.setVariable("customErrorMessage", errorinfo);
		ctx.setVariable("customReasonMessage", errorinfo);
		session.reject(errorinfo);
	}
}
module.exports = callMQURL;
