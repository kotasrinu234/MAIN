var sm = require('service-metadata');
var urlopen = require('urlopen');
var callMQURL = require('./callMQURL.js');
var logger = console.options({
	'category': 'all'
});

var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("som") || session.createContext("som");
var uri = new String(sm.URI);
var trigValue = ctx.getVariable('somId');
var updateReqQ = session.parameters.updateReqQ;  //SOM.SP.STATUS.UPDATE.SWITCH.ORDER
var updateQueueManager = session.parameters.updateQueueManager; //SOM.SP.STATUS.UPDATE.SWITCH.ORDER_QMgr
var MaximoExitDescription = session.parameters.MaximoExitDescription;


try {
	session.input.readAsBuffer(function(error, incomingdata) {
		if (error) {
			var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ErrorDescription', errorinfo)
			logger.error(errorinfo);
			session.reject(errorinfo);
			//throw error;
		}
		var json = (incomingdata.toString());
		var html = {

			maxHtmlResp: json
		};
		if (json.includes("DOCTYPE")) {

			session.output.write(html)
			//logger.error("line 35" + JSON.parse(html));
			var ServerErrorCode = session.parameters.ServerErrorCode;
			var ErrorCodeList = ServerErrorCode.split(',');
			var flagvalue;
			for (var i = 0; i < ErrorCodeList.length; i++) {
				var numberval = Number(ErrorCodeList[i])
				var errorcode = ErrorCodeList[i]
				if (json.includes(numberval)) {
					flagvalue = 'yes'
				}
			}
			if (flagvalue) {
				var errorinfo = "Error in parsing incoming request when backside connection failed details are: with responsecde:" + errorcode
				ILSctx.setVariable('ExitStatus', errorcode);
				ILSctx.setVariable('ErrorDescription', errorinfo)
				logger.error(errorinfo);
				ctx.setVariable("retryFlag", "true");
			}
			else {
				var errorinfo = "Error in parsing incoming request when backside connection failed details are: with responsecde:" + errorcode
				ILSctx.setVariable('ExitStatus', errorcode);
				ILSctx.setVariable('ErrorDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
		else {
			var msgId;
			if (json.messageId == undefined || json.messageId == null || json.messageId === '') {
				msgId = ctx.getVariable("messageId");
			}

			incomingdata = JSON.parse(incomingdata);
			msgId = ctx.getVariable("messageId");

			if (incomingdata.Error) {
				incomingdata.Error.messageId = msgId
			} else {
				incomingdata.messageId = msgId
			}

			if (incomingdata.Error) {
				if (incomingdata.Error.reasonCode == 'BMXAA9549E') {
					//ILSctx.setVariable('ExitStatus', errorcode);
					ctx.setVariable("customErrorCode", '401');
					ctx.setVariable("customErrorMessage", 'Authentication Error');
					ctx.setVariable("customReasonMessage", 'Authentication Error');
					session.output.write("Authentication Error ");
					session.reject("Authentication Error");
				} else {
					//ILSctx.setVariable('ExitStatus', errorcode);
					ctx.setVariable("customErrorCode", incomingdata.Error.statusCode);
					ctx.setVariable("customErrorMessage", incomingdata.Error.message);
					ctx.setVariable("customReasonMessage", incomingdata.Error.message);
					logger.error("Error Code :" + incomingdata.Error.statusCode + " -- " + incomingdata.Error.message);
					//session.output.write (incomingdata.Error.message);
					//session.reject(incomingdata.Error.message);
				}

			}


			var urlopenurl = 'dpmq://' + updateQueueManager + '/?RequestQueue=' + updateReqQ;
			ILSctx.setVariable('ExitDescription', MaximoExitDescription)
			ILSctx.setVariable("maximoResponseExitDestination", updateReqQ);
			callMQURL(urlopenurl, trigValue, 'MAXResp_MQ', incomingdata);
			session.output.write(incomingdata)
		}
	});

} catch (error) {
	var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
	ILSctx.setVariable('ExitStatus', '500');
	ILSctx.setVariable('ErrorDescription', errorinfo)
	ctx.setVariable("retryFlag", "true");
	logger.error(errorinfo);
	session.reject(errorinfo);
}//session.input closed
