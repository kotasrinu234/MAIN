var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('som') || session.createContext('som');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data for ILS, details are: "; "error info :" + readAsJSONError
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
	} else {
		var lookupURL = session.parameters.lookUpURL;
		var orderType = incomingdata[0].switchOrderTypeObjectID;
		var orderStatus = incomingdata[0].statusID;
		var maximoID = incomingdata[0].customFieldValuesExt.Maximo_Request_Number;
		if (maximoID === undefined || maximoID === null || maximoID === '') {
			ILSctx.setVariable('maximoID', ' ');
		} else {
			ILSctx.setVariable('maximoID', maximoID);
		}
		if (orderType === undefined || orderType === null || orderType === '') {
			ctx.setVariable('orderType', ' ');
		} else {
			ctx.setVariable("orderType", orderType);
		}
		if (orderStatus === undefined || orderStatus === null || orderStatus === '') {
			ctx.setVariable('orderStatus', ' ');
		} else {
			ctx.setVariable("orderStatus", orderStatus);
		}
		var switchOrderTypeObjectID = {
			"lookupReq": {
				"type": [
					{
						"name": "switchOrderTypeObjectID",
						"id": orderType
					},

				]
			}
		};
		var somlookupService = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: switchOrderTypeObjectID
		};
		var info = " TargetURL :" + somlookupService.target + "; Method :" + somlookupService.method + "; Data :" + JSON.stringify(somlookupService.data) + ". ";
		try {
			urlopen.open(somlookupService, function(error, response) {
				if (error) {
					var errorinfo = "url connection error 'switchOrderTypeObjectID', details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ErrorDescription', errorinfo)
					logger.error(errorinfo);
					//session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response switchOrderTypeObjectID, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								ILSctx.setVariable('ExitStatus', '0');
								logger.debug("response received from LookupServiceResponse " + responseData);
								//var lookupResponse1 = JSON.parse(responseData);
								ctx.setVariable("lookupResponse1", responseData);

							}

						})
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response from  switchOrderTypeObjectID, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								hm.current.statusCode = responseStatusCode;
								var errorinfo = "Error returned from  switchOrderTypeObjectID lookup call :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error(errorinfo);
							}
						});
					}

				}

			});
		} catch (error) {
			var errorinfo = "url connection error 'switchOrderTypeObjectID', details are : " + info + "; error info :" + error
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ErrorDescription', errorinfo)
			logger.error(errorinfo);
		}


		var switchOrderStatus = {
			"lookupReq": {
				"type": [
					{
						"name": "switchOrder.WorkFlowStatus",
						"id": orderStatus,
						//"status": status
					},

				]
			}
		};
		var switchOrderWorkflowReq = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: switchOrderStatus
		};
		var info = " TargetURL :" + switchOrderWorkflowReq.target + "; Method :" + switchOrderWorkflowReq.method + "; Data :" + JSON.stringify(switchOrderWorkflowReq.data) + ". ";
		try {
			urlopen.open(switchOrderWorkflowReq, function(error, response) {
				if (error) {
					var errorinfo = "url connection error 'switchOrderStatus', details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ErrorDescription', errorinfo)
					logger.error(errorinfo);
					//session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response switchOrderStatus, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								ILSctx.setVariable('ExitStatus', '0');
								logger.debug("response received from LookupServiceResponse " + responseData);
								//var lookupResponse2 = JSON.parse(responseData);
								ctx.setVariable("lookupResponse2", responseData);
							}
						})
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response from  switchOrderStatus, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								hm.current.statusCode = responseStatusCode;
								var errorinfo = "Error returned from lookup call :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error(errorinfo);
							}
						});
					}
				}

			});
		} catch (error) {
			var errorinfo = "url connection error 'switchOrderStatus', details are : " + info + "; error info :" + error
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ErrorDescription', errorinfo)
			logger.error(errorinfo);
		}
	}
});
