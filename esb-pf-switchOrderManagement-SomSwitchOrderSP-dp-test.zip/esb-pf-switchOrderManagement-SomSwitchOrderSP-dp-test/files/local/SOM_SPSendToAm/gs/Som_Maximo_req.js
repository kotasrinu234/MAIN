var sm = require('service-metadata');
var hm = require('header-metadata');
var headers = hm.current;
var dte_reqtype = session.parameters.dte_reqtype;
var siteid = session.parameters.siteid;
var classId = session.parameters.classId;
var maxApikey = session.parameters.maxApikey;
var maxUrl = session.parameters.maxUrl;
var ExitDescription = session.parameters.ExitDescription;
headers.set('properties', 'ticketid,status');

var logger = console.options({
	'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ctxHeader = session.name('SOM_SPReceiveSwitch_Seq') || session.createContext('SOM_SPReceiveSwitch_Seq');
var ILSctx = session.name('ILS') || session.createContext('ILS');

var json_mqrfh2 = headers.get({
	type: 'mq'
}, 'MQRFH2');
var trigValue = ctxHeader.getVariable("eventType");
var jsonPayload = ctx.getVariable('jsonPayload');
var maximoUrl = maxUrl + "?lean=1&apikey=" + maxApikey;
//var maximoUrl = "https://172.27.17.64:1549/mqput";
ctx.setVariable("maximoUrl", maximoUrl);
var MaximoLookupMap = new Map([
	['New', 'INPROG'],
	['In Progress', 'INPROG'],
	['Cancelled', 'CAN'],
	['Completed', 'FDCOMP'],
	['Closed', 'CLOSED'],
	['Extend', 'EXTEND'],
	['On Hold', 'ONHOLD'],
	['OCC Review', 'NEEDASGN'],
]);
var status = '';
var tmpclsifyid = "";
var maximoUpdateLookup = ctx.getVariable('MaximoUpdate_lookup');
var maximoUpdate = maximoUpdateLookup[0].label
ctx.setVariable('maximoUpdateStatus', maximoUpdate);
var switchOrderWorkflow_lookup = ctx.getVariable('orderStatus');
ctx.setVariable("switchOrderWorkflow_lookup", switchOrderWorkflow_lookup);
var resptitle = switchOrderWorkflow_lookup;
var switchOrderLabel = ctx.getVariable("orderType");
if (MaximoLookupMap.has(resptitle)) {
	status = ctx.setVariable('maxStatus', MaximoLookupMap.get(resptitle));
}
else if (MaximoLookupMap.has(maximoUpdate)) {
	status = ctx.setVariable('maxStatus', MaximoLookupMap.get(maximoUpdate));
}
else {
	if (resptitle === 'Start Work' || maximoUpdate === 'Start Work' || maximoUpdate === 'In Progress') {
		status = ctx.setVariable('maxStatus', "INPROG");
	}
}
session.input.readAsJSON(function(error, incomingdata) {
	if (error) {
		var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
		//throw error;
	}
	var somId = jsonPayload[0].id;
	ctx.setVariable("somId", somId);
	var messageId = jsonPayload[0].messageID;
	if (messageId === undefined || messageId === null || messageId === '') {
	} else {
		ctx.setVariable("messageId", messageId);

	}
	var maximoReq = mapCepToMaximo(jsonPayload[0]);
	session.output.write(maximoReq);
	ctx.setVariable("maximoReq", maximoReq);
	sm.setVar('var://service/routing-url', maximoUrl);
	ILSctx.setVariable("ExitDestination", maxUrl);
	ILSctx.setVariable('ExitDescription', ExitDescription)
});


function mapCepToMaximo(json) {
	var req = {};
	if (json.displayID !== null && json.displayID !== undefined) {
		req.tmpclsifyid = json.displayID;
	} else {
		req.tmpclsifyid = json.customId;
	}
	req.messageId = json.messageID;

	if (trigValue.includes('Create')) {
		req.changedate = toIsoString(new Date(json.createdAt));
		//req.status = ctx.getVariable('maxStatus');
	}
	if (trigValue.includes('Update')) {
		req.changedate = toIsoString(new Date(json.updatedAt));
		//req.status = ctx.getVariable('maxStatus1')
	}
	req.status = ctx.getVariable('maxStatus');
	//req.status = 'NEW';
	//this is only for update
	if (trigValue.includes('Update')) {
		req.ticketid = json.customFieldValuesExt.Maximo_Request_Number;
	}
	if (json.customFieldValuesExt.Voltage_Class !== null && json.customFieldValuesExt.Voltage_Class !== undefined && json.customFieldValuesExt.Voltage_Class !== "") {
		req.dte_soc_volttype = json.customFieldValuesExt.Voltage_Class;
	}
	//var Voltage_Class=ctx.setVariable("Voltage_Class",json.customFieldValuesExt.Voltage_Class);
	req.tmp_classificationid = switchOrderLabel;
	req.dte_socsr = new Array();
	//req.dte_socsr={}
	var obj = {};
	if ((switchOrderLabel !== 'TRSD') && (switchOrderLabel !== 'ETO')) {
		if (json.customFieldValuesExt.Reason_For_Action !== null && json.customFieldValuesExt.Reason_For_Action !== undefined && json.customFieldValuesExt.Reason_For_Action !== '') {
			obj.dte_reason_reject = json.customFieldValuesExt.Reason_For_Action;
		}
	}
	if (json.customFieldValuesExt.Desk_Assignment !== null && json.customFieldValuesExt.Desk_Assignment !== undefined && json.customFieldValuesExt.Desk_Assignment !== '') {
		req.ownergroup = json.customFieldValuesExt.Desk_Assignment;
	}
	if (json.customFieldValuesExt.Maximo_Reference_Requests !== null && json.customFieldValuesExt.Maximo_Reference_Requests !== undefined && json.customFieldValuesExt.Maximo_Reference_Requests !== '') {
		obj.dte_reference_rsd = json.customFieldValuesExt.Maximo_Reference_Requests;
	}
	if (json.customFieldValuesExt.Maximo_Location !== null && json.customFieldValuesExt.Maximo_Location !== undefined && json.customFieldValuesExt.Maximo_Location !== '') {
		req.location = json.customFieldValuesExt.Maximo_Location;
	}
	if (switchOrderLabel !== 'ETO') {
		if (json.customFieldValuesExt.Equipment_to_be_Shutdown !== null && json.customFieldValuesExt.Equipment_to_be_Shutdown !== undefined && json.customFieldValuesExt.Equipment_to_be_Shutdown !== '') {
			req.remarkdesc = json.customFieldValuesExt.Equipment_to_be_Shutdown
		}
	}
	if ((switchOrderLabel !== 'RECL') && (switchOrderLabel !== 'ETO')) {
		if (json.customFieldValuesExt.Protection_Class !== null && json.customFieldValuesExt.Protection_Class !== undefined && json.customFieldValuesExt.Protection_Class !== '') {
			var protectionClass = json.customFieldValuesExt.Protection_Class;
			var pClass = protectionClass.substring(6, 7);
			req.dte_soc_protection = pClass;
		}
	}
	if (switchOrderLabel !== 'ETO') {
		if (json.customFieldValuesExt.Protection_Limits !== null && json.customFieldValuesExt.Protection_Limits !== undefined && json.customFieldValuesExt.Protection_Limits !== '') {

			obj.dte_limits = json.customFieldValuesExt.Protection_Limits
		}
	}
	if (json.customFieldValuesExt.Protection_Required !== null && json.customFieldValuesExt.Protection_Required !== undefined && json.customFieldValuesExt.Protection_Required !== '') {
		if ((switchOrderLabel !== 'RECL') && (switchOrderLabel !== 'ETO')) {
			if (json.customFieldValuesExt.Protection_Required === 'YES')
				obj.dte_protection_req = "Y"
			else
				obj.dte_protection_req = "N"
		}
	}
	if (json.customFieldValuesExt.Protection_Limits_Description !== null && json.customFieldValuesExt.Protection_Limits_Description !== undefined && json.customFieldValuesExt.Protection_Limits_Description !== '') {
		if (switchOrderLabel !== 'ETO') {
			req.remarkdesc_longdescription = json.customFieldValuesExt.Protection_Limits_Description
		}
	}
	if ((switchOrderLabel !== 'RECL') && (switchOrderLabel !== 'ETO')) {
		if (json.customFieldValuesExt.Assignment_Of_Request !== null && json.customFieldValuesExt.Assignment_Of_Request !== undefined && json.customFieldValuesExt.Assignment_Of_Request !== '') {

			obj.dte_assign_of_req = json.customFieldValuesExt.Assignment_Of_Request
		}
		if (json.customFieldValuesExt.Emergency_Clearance_Time !== null && json.customFieldValuesExt.Emergency_Clearance_Time !== undefined && json.customFieldValuesExt.Emergency_Clearance_Time !== '') {
			obj.dte_em_clear_time = json.customFieldValuesExt.Emergency_Clearance_Time
		}
	}

	if (json.customFieldValuesExt.Character_Of_Work_Selection !== null && json.customFieldValuesExt.Character_Of_Work_Selection !== undefined && json.customFieldValuesExt.Character_Of_Work_Selection !== '') {

		req.description = json.customFieldValuesExt.Character_Of_Work_Selection
	}

	if (json.customFieldValuesExt.Character_Of_Work_Description !== null && json.customFieldValuesExt.Character_Of_Work_Description !== undefined && json.customFieldValuesExt.Character_Of_Work_Description !== '') {

		req.description_longdescription = json.customFieldValuesExt.Character_Of_Work_Description
	}
	if (json.customFieldValuesExt.Responsible_Organization !== null && json.customFieldValuesExt.Responsible_Organization !== undefined && json.customFieldValuesExt.Responsible_Organization !== '') {
		req.dte_soc_discipline = json.customFieldValuesExt.Responsible_Organization
	}
	if (json.customFieldValuesExt.Responsible_Service_Center !== null && json.customFieldValuesExt.Responsible_Service_Center !== undefined && json.customFieldValuesExt.Responsible_Service_Center !== '') {
		req.dte_worklocation = json.customFieldValuesExt.Responsible_Service_Center;
	}
	
		if (json.customFieldValuesExt.Special_Notes_And_Instructions !== null && json.customFieldValuesExt.Special_Notes_And_Instructions !== undefined && json.customFieldValuesExt.Special_Notes_And_Instructions !== '') {
			obj.dte_specialnotes_longdescription = json.customFieldValuesExt.Special_Notes_And_Instructions
		}

	if (json.customFieldValuesExt.Job_Status !== null && json.customFieldValuesExt.Job_Status !== undefined && json.customFieldValuesExt.Job_Status !== '') {

		req.dte_soc_jobstatus = json.customFieldValuesExt.Job_Status;
	}

	if (switchOrderLabel !== 'RECL') {
		if (json.customFieldValuesExt.Job_Status_Details !== null && json.customFieldValuesExt.Job_Status_Details !== undefined && json.customFieldValuesExt.Job_Status_Details !== '') {
			req.dte_soc_jobstatus_longdescription = json.customFieldValuesExt.Job_Status_Details
		}
	}
	if (json.customFieldValuesExt.Resource_Requirements !== null && json.customFieldValuesExt.Resource_Requirements !== undefined && json.customFieldValuesExt.Resource_Requirements !== '') {
		if ((switchOrderLabel !== 'RECL') && (switchOrderLabel !== 'ETO')) {

			obj.dte_resrc_opr = json.customFieldValuesExt.Resource_Requirements
			var reqList = json.customFieldValuesExt.Resource_Requirements;

			if (reqList.includes("OPER"))
				obj.dte_resrc_opr = 1
			else
				obj.dte_resrc_opr = 0

			if (reqList.includes("OHL"))
				obj.dte_resrc_ohl = 1
			else
				obj.dte_resrc_ohl = 0

			if (reqList.includes("UGL"))
				obj.dte_resrc_ugl = 1
			else
				obj.dte_resrc_ugl = 0

			if (reqList.includes("SMM"))
				obj.dte_resrc_smm = 1
			else
				obj.dte_resrc_smm = 0

			if (reqList.includes("CBT"))
				obj.dte_resrc_cbt = 1
			else
				obj.dte_resrc_cbt = 0

			if (reqList.includes("PERT"))
				obj.dte_resrc_prt = 1
			else
				obj.dte_resrc_prt = 0

			if (reqList.includes("PSR"))
				obj.dte_resrc_psr = 1
			else
				obj.dte_resrc_psr = 0

			if (reqList.includes("OTHER"))
				obj.dte_resrc_other = 1
			else
				obj.dte_resrc_other = 0

			if (reqList.includes("Map Update"))
				obj.dte_mapupdatereq = 1
			else
				obj.dte_mapupdatereq = 0
		}
	}
	if (json.customFieldValuesExt.Position_in_Manual !== null && json.customFieldValuesExt.Position_in_Manual !== undefined && json.customFieldValuesExt.Position_in_Manual !== '') {
		if (json.customFieldValuesExt.Position_in_Manual === 'Yes') {
			obj.dte_position_in_manual = "Y"
		} else {
			obj.dte_position_in_manual = "N"
		}
	}

	if ((switchOrderLabel !== 'TRSD') && (switchOrderLabel !== 'ETO')) {
		if (json.customFieldValuesExt.Switching_Start) {
			if (json.customFieldValuesExt.Switching_Start !== null && json.customFieldValuesExt.Switching_Start !== undefined && json.customFieldValuesExt.Switching_Start !== '') {
				obj.dte_preswitchstart = toIsoString(new Date(json.customFieldValuesExt.Switching_Start));
			}
		}
	}
	if ((switchOrderLabel !== 'TRSD') && (switchOrderLabel !== 'ETO')) {
		if (json.customFieldValuesExt.Switching_End) {
			if (json.customFieldValuesExt.Switching_End !== null && json.customFieldValuesExt.Switching_End !== undefined && json.customFieldValuesExt.Switching_End !== '') {
				obj.dte_preswitchfinish = toIsoString(new Date(json.customFieldValuesExt.Switching_End));
			}
		}
	}
	if ((switchOrderLabel !== 'TRSD') && (switchOrderLabel !== 'ETO')) {
		if (json.customFieldValuesExt.Pre_Switch_Date) {
			if (json.customFieldValuesExt.Pre_Switch_Date !== null && json.customFieldValuesExt.Pre_Switch_Date !== undefined && json.customFieldValuesExt.Pre_Switch_Date !== '') {
				obj.dte_preswitchdate = toIsoString(new Date(json.customFieldValuesExt.Pre_Switch_Date));
			}
		}
	}
	req.dte_socsr[0] = obj;
	if ((switchOrderLabel == 'TRSD') || (switchOrderLabel == 'ETO') || (switchOrderLabel == 'RECL') || (switchOrderLabel == 'RSD')) {
		if (json.customFieldValuesExt.Managed_Must == 1 || json.customFieldValuesExt.Must == 1) {
			req.internalpriority = 1;
		}
		else if (json.customFieldValuesExt.Managed_Must != null && json.customFieldValuesExt.Managed_Must != undefined && json.customFieldValuesExt.Managed_Must != '') {
			if (json.customFieldValuesExt.Managed_Must == 1) {
				req.internalpriority = 1;
			}
		}
		else if (json.customFieldValuesExt.Must != null && json.customFieldValuesExt.Must != undefined && json.customFieldValuesExt.Must != '') {
			if (json.customFieldValuesExt.Must === 1) {
				req.internalpriority = 1;
			}
		}
	}
	if ((switchOrderLabel !== 'TRSD') && (switchOrderLabel !== 'ETO')) {
		if (json.plannedStart !== null && json.plannedStart !== undefined && json.plannedStart !== '') {
			req.targetstart = toIsoString(new Date(json.plannedStart)); //TO BE CONVERTED
		}
		if (json.plannedEnd !== null && json.plannedEnd !== undefined && json.plannedEnd !== '') {
			req.targetfinish = toIsoString(new Date(json.plannedEnd)); //TO BE CONVERTED
		}
	}
	if (json.customFieldValuesExt.Work_Start !== null && json.customFieldValuesExt.Work_Start !== undefined && json.customFieldValuesExt.Work_Start !== '') {
		req.actualstart = toIsoString(new Date(json.customFieldValuesExt.Work_Start)); //TO BE CONVERTED
	}
	if (json.customFieldValuesExt.Work_End !== null && json.customFieldValuesExt.Work_End !== undefined && json.customFieldValuesExt.Work_End !== '') {
		req.actualfinish = toIsoString(new Date(json.customFieldValuesExt.Work_End)); //TO BE CONVERTED
	}

	if ((switchOrderLabel !== 'RECL') && (switchOrderLabel !== 'ETO')) {
		if (json.customFieldValuesExt.Must !== null && json.customFieldValuesExt.Must !== undefined && json.customFieldValuesExt.Must !== '') {
			if (json.customFieldValuesExt.Must === false)
				req.dte_soc_must = 0
			else
				req.dte_soc_must = 1
		}
		if (json.customFieldValuesExt.Managed_Must !== null && json.customFieldValuesExt.Managed_Must !== undefined && json.customFieldValuesExt.Managed_Must !== '') {

			if (json.customFieldValuesExt.Managed_Must === false)
				req.dte_soc_mngmust = 0
			else
				req.dte_soc_mngmust = 1
		}
	}
	if (json.officeNumber !== null && json.officeNumber !== undefined && json.officeNumber !== '') {
		req.reportedphone = json.officeNumber
	}
	req.class = classId;
	req.dte_reqtype = dte_reqtype;
	req.siteid = siteid;
	req.reportdate = toIsoString(new Date(json.createdAt)) //TO BE CONVERTED 
	return req;

}



/* const date = new Date(incomingdata.switchOrder.customFieldValues.Updated_At);
			var Updated_AtDate = date.toISOString();
			var beforePlus = Updated_AtDate.split('.').shift();
			var updated_AtdateUTC= beforePlus+'Z';
			payload.switchOrder.customFieldValues.Updated_At = updated_AtdateUTC; */


//var date = new Date('2002-10-10T17:00:00Z');
function toIsoString(date) {
	var tzo = -date.getTimezoneOffset(),
		dif = tzo >= 0 ? '+' : '-',
		pad = function(num) {
			return (num < 10 ? '0' : '') + num;
		};

	return date.getFullYear() +
		'-' + pad(date.getMonth() + 1) +
		'-' + pad(date.getDate()) +
		'T' + pad(date.getHours()) +
		':' + pad(date.getMinutes()) +
		':' + pad(date.getSeconds()) +
		dif + pad(Math.floor(Math.abs(tzo) / 60)) +
		':' + pad(Math.abs(tzo) % 60);
}
//calling the function
