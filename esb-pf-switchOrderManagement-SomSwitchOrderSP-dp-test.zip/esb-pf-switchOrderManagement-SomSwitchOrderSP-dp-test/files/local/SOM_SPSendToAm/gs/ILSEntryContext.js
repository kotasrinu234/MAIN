var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var lookupResponse1 = ctx.getVar("lookupResponse1");
var lookupResponse2 = ctx.getVar("lookupResponse2");
ILSctx.setVariable('ExitStatus', '0');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data, details are:"; "error info :" + readAsJSONError
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
	} else {
		ctx.setVariable('seqPayload',incomingdata)
		var orderType = '';
		var orderStatus = '';
		//var maximoID = '';
		var correlationID = incomingdata.messageId;
		var messageType = session.parameters.messageType;
		var interfaceName = session.parameters.interfaceName;
		var EntryDescription = session.parameters.EntryDescription;
		var ExitDescription = session.parameters.ExitDescription;
		var sourceUrl = sm.getVar('var://service/URL-in');
		//var maximoID = incomingdata.customFieldValuesExt.Maximo_Request_Number;
		var somID = incomingdata.eventContext
		var sourceEventTimestamp = incomingdata.EventTimeStamp;
		if (lookupResponse1) {
			if (lookupResponse1.lookupRep.type[0].result == 0) {
				if ((lookupResponse1.lookupRep.type[0].label != undefined) && (lookupResponse1.lookupRep.type[0].label != null) && (lookupResponse1.lookupRep.type[0].label != '')) {
					orderType = lookupResponse1.lookupRep.type[0].label;
					ILSctx.setVariable('orderType', orderType);
				}
			}
		}
		if (lookupResponse2) {
			if (lookupResponse2.lookupRep.type[0].result == 0) {
				if ((lookupResponse2.lookupRep.type[0].label != undefined) && (lookupResponse2.lookupRep.type[0].label != null) && (lookupResponse2.lookupRep.type[0].label != '')) {
					orderStatus = lookupResponse2.lookupRep.type[0].label;
					ILSctx.setVariable('orderStatus', orderStatus);
				}
			}
		}
		if (somID === undefined || somID === null || somID === '') {
			ILSctx.setVariable('somID', ' ');
		} else {
			ILSctx.setVariable("somID", somID);
		}
		if (sourceEventTimestamp === undefined || sourceEventTimestamp === null || sourceEventTimestamp === '') {
		} else {
			ILSctx.setVariable('sourceEventTimestamp', ' ');
			ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ILSctx.setVariable('correlationID', ' ');
		} else {
			ILSctx.setVariable('correlationID', correlationID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ILSctx.setVariable('messageType', ' ');
		} else {
			ILSctx.setVariable('messageType', messageType);
		}
		if (interfaceName === undefined || interfaceName === null || interfaceName === '') {
			ILSctx.setVariable('interfaceName', ' ');
		} else {
			ILSctx.setVariable('interfaceName', interfaceName);
		}
		if (EntryDescription === undefined || EntryDescription === null || EntryDescription === '') {
			ILSctx.setVariable('EntryDescription', ' ');
		} else {
			ILSctx.setVariable('EntryDescription', EntryDescription);
		}
		if (ExitDescription === undefined || ExitDescription === null || ExitDescription === '') {
			ILSctx.setVariable('ExitDescription', '');
		} else {
			ILSctx.setVariable('ExitDescription', ExitDescription);
		}

		if (sourceUrl === undefined || sourceUrl === null || sourceUrl === '') {
			ILSctx.setVariable('sourceUrl', ' ');
		} else {
			ILSctx.setVariable('sourceUrl', sourceUrl);
		}
	/*	if (incomingdata.customFieldValuesExt.Maximo_Request_Number !== undefined || incomingdata.customFieldValuesExt.Maximo_Request_Number !== null || incomingdata.customFieldValuesExt.Maximo_Request_Number !== '') {
			maximoID = incomingdata.customFieldValuesExt.Maximo_Request_Number;
			ILSctx.setVariable('maximoID', maximoID);
		}*/
	}
});
