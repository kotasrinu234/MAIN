var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("som") || session.createContext("som");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var maxStatus = ctx.getVariable('maxStatus');
ILSctx.setVariable('orderStatus', maxStatus);
var ExitStatus = ILSctx.getVariable("ExitStatus");
var maximoreq = ctx.getVariable("maximoReq");
session.output.write(maximoreq);

var retry = ctx.getVariable('retryFlag');
var ErrorTxt = ILSctx.getVariable('ErrorDescription')
if (retry != 'true') {
	//ILSctx.setVariable('ExitStatus', '0');
	ILSctx.setVariable('ExitDestination', session.parameters.maxUrl);
	ILSctx.setVariable('ExitDescription', session.parameters.ExitDescription)
} else {
	ILSctx.setVariable('ExitStatus', ExitStatus);
	ILSctx.setVariable('ErrorDescription', ErrorTxt)
}
