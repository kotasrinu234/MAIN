var sm = require('service-metadata');
var urlopen = require('urlopen');
var getURLResponse = require('./som_urlopen.js');
var doLookup = require('./SOM_lookUp.js');
var swaggerurl = "https://adms-test.dteco.com:443/somplanner/external/";
//var swaggerurl =session.parameters.swaggerurl;
var logger = console.options({
	'category': 'all'
});

var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var lookupResponse2 = ctx.getVar("lookupResponse2");

session.input.readAsJSON(function(error, incomingdata) {
	if (error) {
		var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
		//throw error;
	}

	var jsonPayload = ctx.getVariable('jsonPayload');

	var switchOrderStatus = jsonPayload[0].statusID;
	/* var userId ='';
	if (jsonPayload[0].createdByUser != undefined ||jsonPayload[0].createdByUser != ''||jsonPayload[0].createdByUser != null){
	userId =jsonPayload[0].createdByUser.userID;	
	}else{
	userId =jsonPayload[0].updatedByUser.userID;
	}
	 ctx.setVariable("userId",userId); */

	//lookup start


if (lookupResponse2) {
			if (lookupResponse2.lookupRep.type[0].result == 0) {
				if ((lookupResponse2.lookupRep.type[0].label != undefined) && (lookupResponse2.lookupRep.type[0].label != null) && (lookupResponse2.lookupRep.type[0].label != '')) {
					var orderStatus = lookupResponse2.lookupRep.type[0].label;
					ctx.setVariable('orderStatus', orderStatus);
				}
			}
		}
	/*var switchOrderTypesResp = ctx.getVariable("switchOrderTypes_lookup");
	var switchOrderWorkFlowID = switchOrderTypesResp[0].switchOrderWorkFlowID;
	var switchOrderLabel = switchOrderTypesResp[0].label;
	ctx.setVariable("switchOrderLabel", switchOrderLabel);
	//var switchOrderStatus = getVariable("switchOrderStatus");

	var typeArr = new Array();
	var switchOrderWorkflowReq = {};
	switchOrderWorkflowReq.name = "switchOrder.WorkFlowStatus";
	//switchOrderWorkflowReq.id=switchOrderWorkFlowID;
	switchOrderWorkflowReq.id = switchOrderStatus;

	//switchOrderWorkflowReq.status=switchOrderStatus;
	typeArr.push(switchOrderWorkflowReq);
	doLookup(typeArr, "switchOrderWorkflow");
*/

	//lookup end
	/* 	 var url = "https://adms-test.dteco.com:8443/platform/api/scim/v2/Users/"+userId;
		// https://adms-test.dteco.com:8443/platform/api/scim/v2/Users/5e430bd608efae19711b1a0f
	 ctx.setVariable("url", url);
	 //getURLResponse(url,"apiresponse"); */

});
