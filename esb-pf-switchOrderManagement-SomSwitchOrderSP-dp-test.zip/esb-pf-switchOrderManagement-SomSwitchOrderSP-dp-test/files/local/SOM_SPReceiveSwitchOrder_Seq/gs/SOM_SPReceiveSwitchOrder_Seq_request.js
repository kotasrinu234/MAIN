var ctx = session.name("SOM_SPReceiveSwitch_Seq") || session.createContext("SOM_SPReceiveSwitch_Seq");
var ctxHeader = session.name("MQMD") || session.createContext("MQMD");
var urlopen = require('urlopen');
var sm = require('service-metadata');
var hm = require('header-metadata');
var headers = hm.current;

var logger = console.options({ 'category': 'all' });
var ILSctx = session.name('ILS') || session.createContext('ILS');
ILSctx.setVariable('ExitStatus', '500');
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data, details are:"; "error info :" + readAsJSONError
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
	} else {
		var incommingdata = JSON.parse(jsonData);
		ctx.setVariable("incommingdata", incommingdata)

		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }

		var eventContext;

		if (incommingdata[0].displayID == undefined || incommingdata[0].displayID == null || incommingdata[0].displayID == '') {
			if (incommingdata[0].customId == undefined || incommingdata[0].customId == null || incommingdata[0].customId == '') {
				logger.debug("DisplayId is null")
			}
			else {
				eventContext = incommingdata[0].customId
				ctx.setVariable("EventContext", eventContext);
			}
		} else {
			eventContext = incommingdata[0].displayID
			ctx.setVariable("EventContext", eventContext);
		}

		var EventTimeStamp;
		if (incommingdata[0].updatedAt === undefined || incommingdata[0].updatedAt === null || incommingdata[0].updatedAt === '') {
			if (incommingdata[0].createdAt === undefined || incommingdata[0].createdAt === null || incommingdata[0].createdAt === '') {
			}
			else {
				EventTimeStamp = incommingdata[0].createdAt;
				//ctx.setVariable("EventTimeStamp", EventTimeStamp);
			}
		} else {
			EventTimeStamp = incommingdata[0].updatedAt;
			//ctx.setVariable("EventTimeStamp", EventTimeStamp);
		}
		var dateTime = new Date();
		var currentTime = dateTime.toISOString();
		var deflatedPayload = ctx.getVariable("deflatedPayload");
		var messageId = incommingdata[0].messageID
		var payload =
		{
			"messageId": messageId,
			"serviceName": "somOrder",
			"messageType": session.parameters.messageType,
			"expiry": session.parameters.expiry,
			//  "eventType" 	   : "SOMOrder",
			"payload": deflatedPayload,
			"EventTimeStamp": EventTimeStamp,
			"sendTimeStamp": currentTime,
			"eventContext": eventContext,
			"waitTime": session.parameters.waitTime,
			"destQueueName": 'SOM.SP.RECEIVE.SWITCH.ORDER.SEQ'
		}

		//var EventType = 

		var triggerValue = ctx.getVariable("triggerValue");
		if (triggerValue.includes('Create')) {
			var eventType = "maximoSwithOrderCreateEvent"
		}
		if (triggerValue.includes('Update')) {
			var eventType = "maximoSwithOrderUpdateEvent"
		}
		payload.eventType = eventType
		ctx.setVar('payload', payload);
		//pushing to queue start

		var StandaloneMQurl = session.parameters.SOM_SPReceiveSwitchOrder_SeqMQSequanceUrl;
		ILSctx.setVariable("ExitDestination", StandaloneMQurl);
		var json_mqmd = headers.get({ type: 'mq' }, 'MQMD');
		var json_mqrfh2 = headers.get({ type: 'mq' }, 'MQRFH2');

		//logger.error("mqrfh2:" +JSON.stringify(mqrfh2));
		var urlopenHeaders = {
			MQMD: json_mqmd,
			MQRFH2: json_mqrfh2
		};
		var publishuri = {
			target: StandaloneMQurl,
			headers: urlopenHeaders,
			data: payload
		};

		var info = " TargetURL :" + publishuri.target + "; Data :" + JSON.stringify(publishuri.data) + ". ";
		try {
			urlopen.open(publishuri, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var errorinfo = "SOM_SPReceiveSwitchOrder_Seq error while keeping message to queue, details are : " + info + "; error info :" + error
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ErrorDescription', errorinfo)
					logger.error("SOM_AM_012:" + errorinfo);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("retryFlag", 'true');
					
					//session.reject("SOM_SPReceiveSwitchOrder_Seq error while keeping message to queue is " + error);
				} else {
					var mqrc = response.statusCode;

					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								var errorinfo = "SOM_SPReceiveSwitchOrder_Seq error while keeping message to queue, details are : " + info + "; error info :" + readError
								hm.response.statusCode = 500
								ILSctx.setVariable('ExitStatus', mqrc);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error("SOM_AM_013:" + errorinfo);
								ctx.setVariable("retry", 'yes');
								ctx.setVariable("retryFlag", 'true');
								//	session.reject("SOM_SPReceiveSwitchOrder_Seq error while keeping message to queue is " + readError);
							} else {
								ILSctx.setVariable('ExitStatus', '0');
								logger.debug("MQResponsecode " + mqrc);
							}
						});
					} else {
						hm.response.statusCode = 500
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						ILSctx.setVariable('ExitStatus', mqrc);
						var ErrorTxt = "SOM_AM_014: SOM_SPReceiveSwitchOrder_Seq response code is urlopen.open error [MQRC=" + mqrc + "]" + info;
						logger.error(ErrorTxt);
						ILSctx.setVariable("ErrorDescription", ErrorTxt);
						ctx.setVariable("retry", 'yes');
						ctx.setVariable("retryFlag", 'true');
						//session.reject(" SOM_SPReceiveSwitchOrder_Seq response code is urlopen.open error [MQRC=" + mqrc + "]");
					}
				}
			});
		} catch (error) {
			var errorinfo = "SOM_SPReceiveSwitchOrder_Seq error while keeping message to queue, details are : " + info + "; error info :" + error
			var mqconnection = 'Forbidden';
			ctx.setVariable("mqconnection", mqconnection);
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ErrorDescription', errorinfo)
			logger.error("SOM_AM_012:" + errorinfo);
			ctx.setVariable("retry", 'yes');
			ctx.setVariable("retryFlag", 'true');
		}
		//pushing to queue end
	}
});
