var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("SOM_SPReceiveSwitch_Seq") || session.createContext("SOM_SPReceiveSwitch_Seq");

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data for ILS, details are: "; "error info :" + readAsJSONError
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
	} else {
		ctx.setVariable('IncomingReq', incomingdata);
		var lookupURL = session.parameters.lookupURL;
		var orderType = '';
		var orderStatus = '';
		if (!(incomingdata[0].switchOrderTypeObjectID == null || incomingdata[0].switchOrderTypeObjectID == '' || incomingdata[0].switchOrderTypeObjectID == undefined)) {
			orderType = incomingdata[0].switchOrderTypeObjectID;
			if (!(incomingdata[0].statusID == null || incomingdata[0].statusID == '' || incomingdata[0].statusID == undefined)) {
				orderStatus = incomingdata[0].statusID;
			}
			var switchOrderTypeObjectID = {
				"lookupReq": {
					"type": [
						{
							"name": "switchOrderTypeObjectID",
							"id": orderType
						},

					]
				}
			};
			var somlookupService = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: switchOrderTypeObjectID
			};
			var info = " TargetURL :" + somlookupService.target + "; Method :" + somlookupService.method + "; Data :" + JSON.stringify(somlookupService.data) + ". ";
			try {
				urlopen.open(somlookupService, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'switchOrderTypeObjectID', details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						//session.reject(errorinfo);
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response switchOrderTypeObjectID, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									//session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;

									if (responseData.lookupRep.type[0].result == 0) {

										if ((responseData.lookupRep.type[0].label != undefined) && (responseData.lookupRep.type[0].label != null) && (responseData.lookupRep.type[0].label != '')) {

											orderType = responseData.lookupRep.type[0].label;
											ILSctx.setVariable('orderType', orderType);

										}
									}
								}
							})
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response from  switchOrderTypeObjectID, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									//session.reject(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("Error returned from lookup call" + " : with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}

					}

				});

			}

			catch (err) {
				var errorinfo = "url connection error catch 'switchOrderTypeObjectID', details are : " + info + "; error info :" + err
				logger.error(errorinfo);
				//session.reject(errorinfo);
			}
			var switchOrderStatus = {
				"lookupReq": {
					"type": [
						{
							"name": "switchOrder.WorkFlowStatus",
							"id": orderStatus
						},

					]
				}
			};
			var switchOrderWorkflowReq = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: switchOrderStatus
			};
			var info = " TargetURL :" + switchOrderWorkflowReq.target + "; Method :" + switchOrderWorkflowReq.method + "; Data :" + JSON.stringify(switchOrderWorkflowReq.data) + ". ";
			try {
				urlopen.open(switchOrderWorkflowReq, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'switchOrderStatus', details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						//session.reject(errorinfo);
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response switchOrderStatus, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									//session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;

									if (responseData.lookupRep.type[0].result == 0) {

										if ((responseData.lookupRep.type[0].label != undefined) && (responseData.lookupRep.type[0].label != null) && (responseData.lookupRep.type[0].label != '')) {

											orderStatus = responseData.lookupRep.type[0].label;
											ILSctx.setVariable('orderStatus', orderStatus);

										}
									}
								}
							})
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response from  switchOrderStatus, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									//session.reject(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("Error returned from lookup call" + " : with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}

					}

				});

			}

			catch (err) {
				var errorinfo = "url connection error catch 'switchOrderStatus', details are : " + info + "; error info :" + err
				logger.error(errorinfo);
				//session.reject(errorinfo);
			}
			var correlationID = incomingdata[0].messageID;
			var messageType = session.parameters.messageType;
			var interfaceName = session.parameters.interfaceName;
			var EntryDescription = session.parameters.EntryDescription;
			var ExitDescription = session.parameters.ExitDescription;
			var sourceUrl = sm.getVar('var://service/URL-in');
			var maximoID = incomingdata[0].customFieldValuesExt.Maximo_Request_Number;
			var somID;
			var sourceEventTimestamp = incomingdata[0].updatedAt;
			
			if (incomingdata[0].displayID === undefined || incomingdata[0].displayID === null || incomingdata[0].displayID === '') {
				logger.debug("displayID is null")
				if (incomingdata[0].customId === undefined || incomingdata[0].customId === null || incomingdata[0].customId === '') {
					logger.debug("customId is null")
				}
				else {
					somID = incomingdata[0].customId
					ILSctx.setVariable("somID", somID);
				}
			} else {
				somID = incomingdata[0].displayID
				ILSctx.setVariable("somID", somID);
			}
			if (sourceEventTimestamp === undefined || sourceEventTimestamp === null || sourceEventTimestamp === '') {
				ILSctx.setVariable("sourceEventTimestamp", '');
			} else {
				ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
			}

			if (correlationID === undefined || correlationID === null || correlationID === '') {
				ILSctx.setVariable('correlationID', ' ');
			} else {
				ILSctx.setVariable('correlationID', correlationID);
			}
			if (messageType === undefined || messageType === null || messageType === '') {
				ILSctx.setVariable('messageType', ' ');
			} else {
				ILSctx.setVariable('messageType', messageType);
			}
			if (interfaceName === undefined || interfaceName === null || interfaceName === '') {
				ILSctx.setVariable('interfaceName', ' ');
			} else {
				ILSctx.setVariable('interfaceName', interfaceName);
			}
			if (EntryDescription === undefined || EntryDescription === null || EntryDescription === '') {
				ILSctx.setVariable('EntryDescription', ' ');
			} else {
				ILSctx.setVariable('EntryDescription', EntryDescription);
			}
			if (ExitDescription === undefined || ExitDescription === null || ExitDescription === '') {
				ILSctx.setVariable('ExitDescription', '');
			} else {
				ILSctx.setVariable('ExitDescription', ExitDescription);
			}
			if (maximoID === undefined || maximoID === null || maximoID === '') {
				ILSctx.setVariable('maximoID', ' ');
			} else {
				ILSctx.setVariable('maximoID', maximoID);
			}
			if (sourceUrl === undefined || sourceUrl === null || sourceUrl === '') {
				ILSctx.setVariable('sourceUrl', ' ');
			} else {
				ILSctx.setVariable('sourceUrl', sourceUrl);
			}
		}
	}
});
