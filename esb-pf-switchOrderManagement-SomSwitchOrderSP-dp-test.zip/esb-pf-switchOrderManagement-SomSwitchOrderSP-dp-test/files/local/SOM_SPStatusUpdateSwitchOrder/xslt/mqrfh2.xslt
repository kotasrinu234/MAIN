<?xml version="1.0" encoding="utf-8"?>
<!-- This XSLT is used to set the headers in the request to IIB -->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"  xmlns:dyn="http://exslt.org/dynamic" extension-element-prefixes="dp date" exclude-result-prefixes="dp date msxsl dyn">
	<xsl:output method="xml" encoding="utf-8" indent="yes"/>

	<xsl:template match="/">
	<xsl:if test="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')">
	<xsl:variable name="mqrfh2" select = "dp:variable('var://context/MQMD/MQRFH2RequestHeaders')" />
		<xsl:variable name="somId" select ="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='somId'])" />
		<dp:set-variable name="'var://context/som/somId'" value="$somId" />
	</xsl:if>
	</xsl:template>
</xsl:stylesheet>