var hm = require('header-metadata');
var headers = hm.current;
var apiUrl = session.parameters.apiUrl;
var apiToken = session.parameters.apiToken;
var postCall = require('./callURL.js')
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var lookupURL = session.parameters.lookUpURL;
var json_mqrfh2 = headers.get({ type: 'mq' }, 'MQRFH2');
var somId = ctx.getVar("somId");
ctx.setVariable("somId", somId);
var checkRetry = ctx.getVar("retryFlag")
if (!(checkRetry == 'true')) {
	session.input.readAsJSON(function(error, incomingdata) {
		if (error) {
			var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ErrorDescription', errorinfo)
			logger.error(errorinfo);
		}
		else {
			var SOMGetCallResponse = ctx.getVariable('SOMGetCallResponse');
			var transitionHistorylist = SOMGetCallResponse.transitionHistory;
			ctx.setVariable("transitionHistory", transitionHistorylist)

			/*var latestTransition = transitionHistory.reduce((latest, current) => {
				return new Date(current.transitionedAt) > new Date(latest.transitionedAt) ? current : latest;
			});*/
			for (var a = 0, b = 1; a < transitionHistorylist.length && b < transitionHistorylist.length - 1; a++, b++) {
				transitionHistorylist.sort(function compare(a, b) {
					var dateA = new Date(a.transitionedAt);
					var dateB = new Date(b.transitionedAt);
					return dateA - dateB;
				});
			}
			var sortedtransitionHistory = transitionHistorylist;
			ctx.setVariable("sortedtransitionHistory", sortedtransitionHistory)
			var preDefinedStatus = session.parameters.preDefinedStatus;
			var latestStatusFlag;
			var latestElement = sortedtransitionHistory[sortedtransitionHistory.length - 1];
			ctx.setVariable("latestTransition", latestElement);

			//var elementBeforeLatest = sortedtransitionHistory[sortedtransitionHistory.length - 2];


			if (latestElement) {
				var StatusID = latestElement.statusID;
				ctx.setVariable("StatusID", StatusID)

				var StatusIDlookup = {
					"lookupReq": {
						"type": [
							{
								"name": "switchOrder.WorkFlowStatus",
								"id": StatusID
							}
						]
					}
				}
			}
			var StatusIDRes = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: StatusIDlookup
			};
			var info = " TargetURL :" + StatusIDRes.target + "; Method :" + StatusIDRes.method + "; Data :" + JSON.stringify(StatusIDRes.data) + ". ";
			try {
				urlopen.open(StatusIDRes, function(error, response) {
					if (error) {
						var errorinfo = "url connection error of 'StatusIDResponse', details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						//session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading StatusIDResponse, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									//session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									//logger.error("response received from  StatusID LookupServiceResponse " + JSON.stringify(responseData));
									//var latestStatus = responseData.lookupRep.type[0].label;
									//logger.error("responsedata error" + JSON.stringify(responseData))
									//ctx.setVariable("lookupResponse", responseData);
									//lookup start
									if (responseData) {
										if (responseData.lookupRep.type[0].result == 0) {
											if ((responseData.lookupRep.type[0].label != undefined) && (responseData.lookupRep.type[0].label != null) && (responseData.lookupRep.type[0].label != '')) {
												var latestStatus = responseData.lookupRep.type[0].label;
												//logger.error("label is not defined", latestStatus)
												ctx.setVariable("StatusIDResponse", latestStatus);
											}
										}
									}
									//ctx.setVariable("StatusIDResponse", latestStatus);




									/*	if(sortedtransitionHistory == 1) {
		
											if (preDefinedStatus.indexOf(latestStatus) !== -1) {
												latestStatusFlag = 'true';
											} else {
												latestStatusFlag = 'false';
											}
											logger.error("statusFlag details" + latestStatusFlag)
										}*/
									var elementBeforeLatest;
									if (sortedtransitionHistory.length > 1) {
										elementBeforeLatest = sortedtransitionHistory[sortedtransitionHistory.length - 2];
										ctx.setVariable("elementBeforeLatest", elementBeforeLatest);
									}
									if (preDefinedStatus.indexOf(latestStatus) !== -1) {
										latestStatusFlag = 'true';
									} else {
										latestStatusFlag = 'false';
									}
									//logger.error("statusFlag details" + latestStatusFlag)


									if (latestStatusFlag === 'true') {


										var postURL = apiUrl + '/somplanner/external/api/v1/switch-order/' + somId + '/workflow'
										if (elementBeforeLatest) {
											var statusID = elementBeforeLatest.statusID;
											ctx.setVariable("statusID", statusID)
											var Payload = {
												"toStateID": statusID
											}
											//ctx.setVariable("Payload", Payload);
											postCall(postURL, "POST", "postCallresponseData", Payload)

										}

									}
								}

							})
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response from  StatusID, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									//session.reject(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("Error returned from lookup call" + " : with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}

					}

				});
			} catch (error) {
				var errorinfo = "url connection error of 'StatusIDResponse', details are : " + info + "; error info :" + error
				logger.error(errorinfo);
			}



			//var statusID = transitionHistory.statusID;
			//ctx.setVariable("statusID", statusID)
			//if (latestStatus === preDefinedStatus) {

			//transitionHistory.sort((a, b) => new Date(b.transitionedAt) - new Date(a.transitionedAt));

			//var sortedTransactionHistory = transitionHistory
			//var elementBeforeLatest = transitionHistory;
			//var statusID = elementBeforeLatest.statusID;



			/*var postURL = apiUrl + '/somplanner/external/api/v1/switch-order/' + somId + '/workflow'
			var Payload = {
				"toStateID": statusID
			}
			ctx.setVariable("Payload", Payload);
			var postStatusIDCall = {
				target: postURL,
				sslClientProfile: 'OMS_SOM_Client_Profile',
				method: 'POST',
				contentType: 'application/json',
				data: Payload,
				headers: {
					'osiApiToken': apiToken
				},
	
			};
			var info = " TargetURL :" + postStatusIDCall.target + "; Method :" + postStatusIDCall.method + "; Data :" + JSON.stringify(postStatusIDCall.data) + ". ";
			try {
				urlopen.open(postPayloadCall, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error while doing post Call, details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						session.output.write(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error message while reading response from postcall, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo)
									session.reject(errorinfo);
								} else {
									var ctx = session.name("SOM") || session.createContext("SOM");
									hm.response.statusCode = responseStatusCode;
									ctx.setVariable("responseData", responseData);
								}
							});
						}
						else {
	
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error message while reading response from postCall, details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo)
									session.reject(errorinfo);
								} else {
									ILSctx.setVariable('ExitDescription', errorinfo)
									var responseinfo = "error message while reading response from apiurlpostCall, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error(responseinfo);
									session.reject(responseinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "urlopen connect error while doing post Call, details are : " + info + "; error info :" + error
				logger.error(errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				session.output.write(errorinfo);
				session.reject(errorinfo);
			}*/
		}

	});
}
