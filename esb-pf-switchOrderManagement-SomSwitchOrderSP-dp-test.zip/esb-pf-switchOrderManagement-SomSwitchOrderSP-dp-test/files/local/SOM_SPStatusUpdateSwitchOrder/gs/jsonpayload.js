var sm = require('service-metadata');
var hm = require('header-metadata');
var headers = hm.current;
var callURL = require('./callURL.js');
var success= session.parameters.successful;
var errorStatusCode = session.parameters.errorStatusCode;
var apiUrl = session.parameters.apiUrl;

var logger = console.options({
    'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.input.readAsJSON(function(error, incomingdata) {
    if (error) {
	var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
        session.reject(errorinfo);
        //throw error;
    }

  var jsonPayload = incomingdata;
    ctx.setVariable("jsonPayload",jsonPayload);	
});
