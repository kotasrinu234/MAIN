var sm = require('service-metadata');
var hm = require('header-metadata');
var headers = hm.current;
var urlopen = require('urlopen');
var getURLResponse = require('./som_urlopen.js');
var apiUrl = session.parameters.apiUrl;
var APIResponse = ""


var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('som') || session.createContext('som');
var json_mqrfh2 = headers.get({ type: 'mq' }, 'MQRFH2');
ctx.setVariable("APIResponse", APIResponse)
ILSctx.setVariable('ExitStatus', '500');
if (json_mqrfh2.MQRFH2.NameValueData.NameValue != undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr != undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.triggerValue != undefined) {
	var somId = json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.triggerValue.$;
	//var somId = somIdstr.substring(somIdstr.indexOf('somId-') + 6);
	ctx.setVariable("somId", somId);
}

/* var testdata =json_mqrfh2.MQRFH2.NameValueData.NameValue.usr;
ctx.setVariable("testdata",testdata);

if(json_mqrfh2.MQRFH2.NameValueData.NameValue !=undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr !=undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.somIdstr !=undefined){
	if(json_mqrfh2.MQRFH2.NameValueData.NameValue !=undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr !=undefined){
	var somIdstrRetry= json_mqrfh2.MQRFH2.NameValueData.NameValue.usr;
	ctx.setVariable("somIdstrRetry",somIdstrRetry);
	var somId = somIdstrRetry.substring(somIdstrRetry.indexOf('somId-') + 6);
	ctx.setVariable("somId",somId);
} */
var somId = ctx.getVariable('somId');

var somApiUrl = apiUrl + "/somplanner/external/api/v1/switch-order/" + somId;
ctx.setVariable("somApiUrl", somApiUrl);
ILSctx.setVariable("ExitDestination", somApiUrl);
session.input.readAsJSON(function(error, incomingdata) {
	if (error) {
		var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
		//throw error;
	}

	var jsonPayload = incomingdata;
	ctx.setVariable("jsonPayload", jsonPayload);


});
getURLResponse(somApiUrl, "SOMGetCallResponse");
