var sm = require('service-metadata');
var hm = require('header-metadata');
var headers = hm.current;
var callURL = require('./callURL.js');
var success = session.parameters.successful;
var errorStatusCode = session.parameters.errorStatusCode;
var apiUrl = session.parameters.apiUrl;
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var somId = ctx.getVar("somId");
/*var json_mqrfh2 = headers.get({ type: 'mq' }, 'MQRFH2');
var somId = json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.triggerValue.$;*/
ctx.setVariable("somId", somId);
var ticketid = '';
var checkRetry = ctx.getVar("retryFlag")
var somApiUrl = apiUrl + "/somplanner/external/api/v1/switch-order/" + somId;
ctx.setVariable("somApiUrl", somApiUrl);
ILSctx.setVariable("ExitDestination", somApiUrl);
var somGetURLResponse = ctx.getVariable('SOMGetCallResponse');
if (!(checkRetry == 'true')) {
	session.input.readAsJSON(function(error, incomingdata) {
		if (error) {
			var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ErrorDescription', errorinfo)
			logger.error(errorinfo);
			session.reject(errorinfo);
			//throw error;
		}

		if (incomingdata.dte_socsr_collectionref) {
			var status = incomingdata.status;
			var ticketid = incomingdata.ticketid;
			var message = success + ' ' + status;
		} else {
			var statuscode = incomingdata.Error.statusCode;
			ctx.setVariable("statuscode", statuscode);

			var errorMessage = incomingdata.Error.message;
			var message = errorStatusCode + ' ' + statuscode + ',' + errorMessage;


		}
		var json = {};
		json.customTableValues = {};
		if (somGetURLResponse.customTableValuesExt.API_Messages !== undefined) {
			json.customTableValues.API_Messages = somGetURLResponse.customTableValuesExt.API_Messages;

		} else {
			json.customTableValues.API_Messages = new Array();
		}
		if (ticketid != '') {
			json.customFieldValues = {};
			json.customFieldValues.Maximo_Request_Number = ticketid;
		}
		var date = new Date();
		var utcDate = date.toISOString().split('.')[0] + 'Z';
		var datereq = {};
		datereq.Date_Time = utcDate;
		datereq.Message = message;
		json.customTableValues.API_Messages.push(datereq);

		callURL(somApiUrl, "PATCH", "somUpdate", json);
	});
}
