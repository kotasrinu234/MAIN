var ctx = session.name("som") || session.createContext("som");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var apiToken = session.parameters.apiToken;
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
function callURL(url, method, myctx, payload) {
	var options = {
		target: url,
		method: method,
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "OMS_SOM_Client_Profile"
	};
	if (method == "POST" || method == "PATCH") {
		options.data = payload;
	}

	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(payload) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				var errorinfo = "urlopen error of 'callURL', details are : " + info + "; error info :" + error
				logger.error(errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo)
				//throw error;
			} else {
				var responseStatusCode = response.statusCode;
				var ctx = session.name("som") || session.createContext("som");
				ctx.setVariable(myctx + "_responseStatusCode", responseStatusCode);
				ctx.setVariable(myctx + "_response", response);

				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, data) {
						if (error) {
							var errorinfo = "Error in reading 'callURL' response data, details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
							//throw error;
						} else {
							var ctx = session.name("som") || session.createContext("som");
							ctx.setVariable(myctx + '_response', data);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message 'callURL', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
						} else {
							var ctx = session.name("som") || session.createContext("som");
							ctx.setVariable(myctx + '_buffer_response', "" + responseData);
							var responseDataStr = "" + responseData;
							ctx.setVariable(myctx + '_buffer_response2', responseDataStr);
							if (responseStatusCode == 400 && responseDataStr !== 'No updates') {
								var responseinfo = "Bad Request response received from callURL, details are : " + info + "; response info :" + responseDataStr + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', responseinfo)
								ctx.setVariable("customErrorMessage", 'Bad Request');
								ctx.setVariable("customReasonMessage", 'Bad Request');
								logger.error(responseinfo);
								session.reject(responseinfo);
								//session.reject("Bad Request");
							}
						}
					});

					if (responseStatusCode == 401) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "SOM_SP_02: error message while reading from callURL, details are :  " + info + "error info :" + JSON.stringify(error);
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "SOM_SP_02: response received from callURL, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ErrorDescription', errorinfo)
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});

					}
					else if (responseStatusCode == 403) {
						var responseinfo = "Forbidden response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ErrorDescription', responseinfo)
						ctx.setVariable("customErrorCode", '403');
						ctx.setVariable("customErrorMessage", 'Forbidden');
						ctx.setVariable("customReasonMessage", 'Forbidden');
						logger.error(responseinfo);
						session.reject(responseinfo);
						//session.reject("Forbidden");
					} else if (responseStatusCode == 404) {
						var responseinfo = "No Records Found response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ErrorDescription', responseinfo)
						ctx.setVariable("customErrorCode", '404');
						ctx.setVariable("customErrorMessage", 'No Records Found');
						ctx.setVariable("customReasonMessage", 'No Records Found');
						logger.error(responseinfo);
						session.reject(responseinfo);
						//session.reject("No Records Found");
					} else if (responseStatusCode == 500) {
						var responseinfo = "Server Error response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ErrorDescription', responseinfo)
						ctx.setVariable("customErrorCode", '500');
						ctx.setVariable("customErrorMessage", 'Server Error');
						ctx.setVariable("customReasonMessage", 'Server Error');
						logger.error(responseinfo);
						session.reject(responseinfo);
						//session.reject("Server Error");
					}
					else if (responseStatusCode == 409) {
						var ctx = session.name("som") || session.createContext("som");
						var responseinfo = "Conflict response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ErrorDescription', responseinfo)
						ctx.setVariable("retryFlag", "true");
						ctx.setVariable("customErrorCode", '409');
						//session.reject(responseinfo);
					}
				}
			}
		});
	} catch (error) {
		var errorinfo = "urlopen error of'callURL', details are : " + info + "; error info :" + error
		logger.error(errorinfo);
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
	}
}
module.exports = callURL;
