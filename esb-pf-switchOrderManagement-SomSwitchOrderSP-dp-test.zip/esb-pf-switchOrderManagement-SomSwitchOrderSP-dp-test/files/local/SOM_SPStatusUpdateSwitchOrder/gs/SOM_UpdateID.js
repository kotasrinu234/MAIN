var hm = require('header-metadata');
var headers = hm.current;
var apiUrl = session.parameters.apiUrl;
var apiToken = session.parameters.apiToken;
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var lookupId = '';
var logger = console.options({
	'category': 'all'
});
var serviceVars = require('service-metadata');
serviceVars.mpgw.skipBackside = true;
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var checkRetry = ctx.getVar("retryFlag")
if (!(checkRetry == 'true')) {
	var switchOrderWorkFlowStatus = ctx.getVariable("switchOrderWorkFlowStatus_lookup");
	var label = switchOrderWorkFlowStatus[0].label;
	if (label === 'New') {
		ILSctx.setVariable('ExitStatus', '500');
		var getStatusId = ctx.getVariable("getStatusId");
		var somId = ctx.getVariable("somId");
		var switchOrderWorkflowResp = ctx.getVariable("switchOrderWorkflow_lookup");
		lookupId = switchOrderWorkflowResp[0].id; ``
		if (getStatusId === lookupId) {

		}
		else {
			session.input.readAsJSON(function(error, incomingdata) {
				if (error) {
					var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ErrorDescription', errorinfo)
					logger.error(errorinfo);
				}
				else {
					var postURL = apiUrl + '/somplanner/external/api/v1/switch-order/' + somId + '/workflow'
					ILSctx.setVariable("ExitDestination", postURL);
					var postPayload = {
						"toStateID": lookupId
					}
					ctx.setVariable("postPayload", postPayload);
					var postPayloadCall = {
						target: postURL,
						sslClientProfile: 'OMS_SOM_Client_Profile',
						method: 'POST',
						contentType: 'application/json',
						data: postPayload,
						headers: {
							'osiApiToken': apiToken
						},

					};
					var info = " TargetURL :" + postPayloadCall.target + "; Method :" + postPayloadCall.method + "; Data :" + JSON.stringify(postPayloadCall.data) + ". ";
					try {
						urlopen.open(postPayloadCall, function(error, response) {
							if (error) {
								var errorinfo = "urlopen connect error while doing post Call, details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								ILSctx.setVariable('ExitStatus', '500');
								ILSctx.setVariable('ErrorDescription', errorinfo)
								session.output.write(errorinfo);
								session.reject(errorinfo);
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error message while reading response from postcall, details are : " + info + "; error info :" + error
											logger.error(errorinfo);
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo)
											session.reject(errorinfo);
										} else {
											ILSctx.setVariable("ExitDestination", postURL);
											var ctx = session.name("SOM") || session.createContext("SOM");
											hm.response.statusCode = responseStatusCode;
											ctx.setVariable("postCallResponse", responseData);
										}
									});
								}

								else if (responseStatusCode == 401 || responseStatusCode == 403) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											//dp:reject stop the transaction and go error rule with error code and description
											var errorinfo = "SOM_SP_03: error message while reading response for somId postCall, details are :  " + info + "error info :" + JSON.stringify(error);
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo)
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "SOM_SP_03: response received for somId postCall : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo)
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});

								}
								else {

									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error message while reading response from postCall, details are : " + info + "; error info :" + error
											logger.error(errorinfo);
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo)
											session.reject(errorinfo);
										} else {
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', responseinfo)
											//ILSctx.setVariable("ExitDestination", postURL);
											var responseinfo = "error message while reading response from apiurlpostCall, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											logger.error(responseinfo);
											session.reject(responseinfo);
										}
									});
								}
							}
						});
					} catch (error) {
						var errorinfo = "urlopen connect error while doing post Call, details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ErrorDescription', errorinfo)
						session.output.write(errorinfo);
						session.reject(errorinfo);
					}
				}
			});
		}
	}
}
