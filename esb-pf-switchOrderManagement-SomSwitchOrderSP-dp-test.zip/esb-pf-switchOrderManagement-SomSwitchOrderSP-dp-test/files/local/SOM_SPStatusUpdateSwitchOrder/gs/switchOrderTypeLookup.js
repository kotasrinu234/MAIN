var hm = require('header-metadata');
var headers = hm.current;
var doLookup = require('./SOM_lookUp.js');
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var checkRetry = ctx.getVar("retryFlag")
if (!(checkRetry == 'true')) {
var getStatusId = ctx.getVariable("getStatusId");
var switchOrderTypeObjectID = ctx.getVariable("switchOrderTypeObjectID");
var switchOrderWorkFlowStatus = ctx.getVariable("switchOrderWorkFlowStatus_lookup");
var label = switchOrderWorkFlowStatus[0].label;
	if (label === 'New') {
		session.input.readAsJSON(function(error, incomingdata) {
			if (error) {
				var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
			else {
				//lookup1 start
				var typeArr = []
				var switchOrderTypesReq = {};
				switchOrderTypesReq.name = "switchOrderTypeObjectID";
				switchOrderTypesReq.id = switchOrderTypeObjectID;
				typeArr.push(switchOrderTypesReq);
				doLookup(typeArr, "switchOrderTypes");
				//lookup1 end
			}
		});
	}
}
