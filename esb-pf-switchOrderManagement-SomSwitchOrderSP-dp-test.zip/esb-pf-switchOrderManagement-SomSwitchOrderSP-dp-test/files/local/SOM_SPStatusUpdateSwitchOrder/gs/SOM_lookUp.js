var ctx = session.name("jobFilter") || session.createContext("jobFilter");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var url = session.parameters.lookUpURL;
//var url = "http://localhost:8080/lookup"; 

function doLookup(arrObj, lookupCtx) {
	//console.error("array length " + arrObj.length);
	/*var ctx = session.name('som') || session.createContext('som');
	var label = arrObj[0].label;
	ctx.setVariable("label", label);*/
	var request = {};
	request.type = arrObj;
	var lookupUrl = url;
	var options = {
		target: lookupUrl,
		method: 'post',
		contentType: 'application/json',
		data: { "lookupReq": request }
	};
ILSctx.setVariable('ExitStatus', '500');
	// open connection to target
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			var ctx = session.name('som') || session.createContext('som');
			if (error) {
				var errorinfo = "url connection error 'lookupURL', details are : " + info + "; error info :" + error
				logger.error(errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo)
				ctx.setVariable("customErrorCode", errorinfo);
				ctx.setVariable("customErrorMessage", errorinfo);
				ctx.setVariable("customReasonPhrase", errorinfo);
				session.output.write(errorinfo);
				session.reject(errorinfo);

			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						var ctx = session.name('som') || session.createContext('som');
						ctx.setVariable('lookupResponseData', responseData);
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response 'lookupURL', details are : " + info + "; error info :" + error
							logger.error(errorinfo);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							session.output.write(errorinfo);
						} else {
							if (responseData.lookupRep.type[0].result == 0) {
								var lookupResponse = responseData.lookupRep.type;
								ctx.setVariable(lookupCtx + "_lookup", lookupResponse);
							}
							else {
								if (responseData.lookupRep.type[0].result == 1) {
									if (lookupCtx === "switchOrderWorkflow") {
										var label = session.parameters.Status_To_SOM;
										logger.error("Invalid " + lookupCtx + " Lookup Response :" + label + " " + JSON.stringify(error));
										session.reject("Invalid " + lookupCtx + " Lookup Response :" + label + " " + JSON.stringify(error));
									}
									else {
										logger.error("Invalid " + lookupCtx + " Lookup Response :" + " " + JSON.stringify(error));
										session.reject("Invalid " + lookupCtx + " Lookup Response :" + " " + JSON.stringify(error));
									}

								}
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading response of 'lookUpURL', details are : " + info + "; error info :" + error
							logger.error(errorinfo);
							ILSctx.setVariable('ExitStatus',responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
						} else {
							logger.error("response received " + responseStatusCode + " " + responseData);
							session.output.write("response received " + responseStatusCode + " " + responseData);

						}
					});
				}
			}
		});
	} catch (error) {
		var errorinfo = "url connection error 'lookupURL', details are : " + info + "; error info :" + error
		logger.error(errorinfo);
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		ctx.setVariable("customErrorCode", errorinfo);
		ctx.setVariable("customErrorMessage", errorinfo);
		ctx.setVariable("customReasonPhrase", errorinfo);
		session.output.write(errorinfo);
		session.reject(errorinfo);
	}
}//end of function 

module.exports = doLookup;
