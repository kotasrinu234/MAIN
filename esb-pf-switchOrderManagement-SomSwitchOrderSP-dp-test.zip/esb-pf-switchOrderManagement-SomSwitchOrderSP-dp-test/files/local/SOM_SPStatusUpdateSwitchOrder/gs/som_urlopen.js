var ctx = session.name("som") || session.createContext("som");
var apiToken = session.parameters.apiToken;
var urlopen = require('urlopen');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var logger = console.options({ 'category': 'all' });
function getURLResponse(url, myctx) {
	var options = {
		target: url,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "OMS_SOM_Client_Profile"

	};

	var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'getURLResponse', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo)
				logger.error(errorinfo);
				ctx.setVariable("customErrorCode", '500');
				ctx.setVariable("customErrorMessage", errorinfo);
				ctx.setVariable("customReasonMessage", errorinfo);
				ctx.setVariable("retryFlag", "true");
				session.output.write(errorinfo);
				//session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response 'getURLResponse', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ErrorDescription', errorinfo)
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							logger.error(errorinfo);
							logEvent(errorinfo);
							session.output.write(errorinfo);
						} else {
							var ctx = session.name('som') || session.createContext('som');
							ctx.setVariable(myctx, responseData);
						}
					})
				} else if (responseStatusCode == 401) {
					var reasonphrase = response.reasonPhrase;
					//logger.error("responseData" + reasonphrase)
					//ILSctx.setVariable("responseData", reasonphrase);
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "SOM_SP_04: failure reading message 'getURLResponse', details are :  " + info + "error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "SOM_SP_04: response received from getURLResponse : " + info + "; response info :" + reasonphrase + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					})
				} else if (responseStatusCode == 403) {
					var reasonphrase = response.reasonPhrase;
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "SOM_SP_06: Forbidden 'getURLResponse', details are :  " + info + "error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "SOM_SP_06: Forbidden response received from getURLResponse : " + info + "; response info :" + reasonphrase + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					})
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "Failure in reading message 'getURLResponse', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseinfo = "response received from getURLResponse details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							logger.error(responseinfo);
							ILSctx.setVariable('ErrorDescription', responseinfo)
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							session.reject(responseinfo);
						}
					});
				}
			}
		})
	} catch (error) {
		var errorinfo = "url connection error 'getURLResponse', details are : " + info + "; error info :" + error
		ILSctx.setVariable('ErrorDescription', errorinfo)
		ILSctx.setVariable('ExitStatus', '500');
		logger.error(errorinfo);
		ctx.setVariable("customErrorCode", '500');
		ctx.setVariable("customErrorMessage", errorinfo);
		ctx.setVariable("customReasonMessage", errorinfo);
		ctx.setVariable("retryFlag", "true");
		session.output.write(errorinfo);
		//session.reject(errorinfo);
	}
}
module.exports = getURLResponse;
