var hm = require('header-metadata');
var headers = hm.current;
var doLookup = require('./SOM_lookUp.js');
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var checkRetry = ctx.getVar("retryFlag")
if (!(checkRetry == 'true')) {
var getStatusId = ctx.getVariable("getStatusId");
var switchOrderWorkFlowStatus = ctx.getVariable("switchOrderWorkFlowStatus_lookup");
var label = switchOrderWorkFlowStatus[0].label;
	if (label === 'New') {
		ILSctx.setVariable('ExitStatus', '500');
		session.input.readAsJSON(function(error, incomingdata) {
			if (error) {
				var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
				ILSctx.setVariable('ErrorDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
			else {
				//lookup2 start
				var switchOrderTypesResp = ctx.getVariable("switchOrderTypes_lookup");
				var switchOrderWorkFlowID = switchOrderTypesResp[0].switchOrderWorkFlowID;
				var switchOrderLabel = switchOrderTypesResp[0].label;
				ctx.setVariable("switchOrderLabel", switchOrderLabel);
				var typeArr = new Array();
				var switchOrderWorkflowReq = {};
				switchOrderWorkflowReq.name = "switchOrder.WorkFlowStatus";
				switchOrderWorkflowReq.id = switchOrderWorkFlowID;
				switchOrderWorkflowReq.label = session.parameters.Status_To_SOM;

				typeArr.push(switchOrderWorkflowReq);
				doLookup(typeArr, "switchOrderWorkflow");
				//lookup2 end
			}
		});
	}
}
