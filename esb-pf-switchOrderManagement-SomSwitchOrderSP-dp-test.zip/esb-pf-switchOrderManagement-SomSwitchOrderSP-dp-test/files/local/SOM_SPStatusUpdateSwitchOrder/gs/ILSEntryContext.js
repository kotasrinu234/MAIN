var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data, details are:"; "error info :" + readAsJSONError
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
	} else {
		var correlationID;

		if (incomingdata.Error) {
			correlationID = incomingdata.Error.messageId
		} else {
			correlationID = incomingdata.messageId
		} var messageType = session.parameters.messageType;
		var interfaceName = session.parameters.interfaceName;
		var EntryDescription = session.parameters.EntryDescription;
		var ExitDescription = session.parameters.ExitDescription;
		var sourceUrl = sm.getVar('var://service/URL-in');
		var maximoID = incomingdata.ticketid;
		var sourceEventTimestamp = new Date().toISOString();
		//ILSctx.setVariable('sourceurlexit', 'SEQ.REQUEST');

		if (sourceEventTimestamp === undefined || sourceEventTimestamp === null || sourceEventTimestamp === '') {
		} else {
			ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ILSctx.setVariable('correlationID', ' ');
		} else {
			ILSctx.setVariable('correlationID', correlationID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ILSctx.setVariable('messageType', ' ');
		} else {
			ILSctx.setVariable('messageType', messageType);
		}
		if (interfaceName === undefined || interfaceName === null || interfaceName === '') {
			ILSctx.setVariable('interfaceName', ' ');
		} else {
			ILSctx.setVariable('interfaceName', interfaceName);
		}
		if (EntryDescription === undefined || EntryDescription === null || EntryDescription === '') {
			ILSctx.setVariable('EntryDescription', ' ');
		} else {
			ILSctx.setVariable('EntryDescription', EntryDescription);
		}
		if (ExitDescription === undefined || ExitDescription === null || ExitDescription === '') {
			ILSctx.setVariable('ExitDescription', '');
		} else {
			ILSctx.setVariable('ExitDescription', ExitDescription);
		}
		if (maximoID === undefined || maximoID === null || maximoID === '') {
			ILSctx.setVariable('maximoID', ' ');
		} else {
			ILSctx.setVariable('maximoID', maximoID);
		}
		if (sourceUrl === undefined || sourceUrl === null || sourceUrl === '') {
			ILSctx.setVariable('sourceUrl', ' ');
		} else {
			ILSctx.setVariable('sourceUrl', sourceUrl);
		}
	}
});
