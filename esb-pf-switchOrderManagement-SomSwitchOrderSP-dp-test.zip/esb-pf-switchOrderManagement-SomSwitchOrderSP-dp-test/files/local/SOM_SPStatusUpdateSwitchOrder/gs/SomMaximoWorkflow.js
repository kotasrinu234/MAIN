var hm = require('header-metadata');
var headers = hm.current;
var doLookup = require('./SOM_lookUp.js');
var apiUrl = session.parameters.apiUrl;
var apiToken = session.parameters.apiToken;
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var getStatusId = '';
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('som') || session.createContext('som');
var ILSctx = session.name('ILS') || session.createContext('ILS');

var json_mqrfh2 = headers.get({ type: 'mq' }, 'MQRFH2');
var somId = ctx.getVar("somId");
ctx.setVariable("somId", somId);
ILSctx.setVariable('ExitStatus', '500');
var checkRetry = ctx.getVar("retryFlag")
if (!(checkRetry == 'true')) {
	session.input.readAsJSON(function(error, incomingdata) {
		if (error) {
			var errorinfo = "Error in parsing incoming request, details are:"; "error info :" + error
			ILSctx.setVariable('ErrorDescription', errorinfo)
			logger.error(errorinfo);
			session.reject(errorinfo);
			//throw error;
		}
		else {

			var GetidUrl = apiUrl + "/somplanner/external/api/v1/switch-order/" + somId + "?includeFields=statusID,switchOrderTypeObjectID";
			ILSctx.setVariable("ExitDestination", GetidUrl);
			var GetCall = {
				target: GetidUrl,
				method: "GET",
				headers: {
					"osiApiToken": apiToken
				},
				contentType: "application/json",
				sslClientProfile: "OMS_SOM_Client_Profile"

			};

			var info = " TargetURL :" + GetCall.target + "; Method :" + GetCall.method + ". ";
			try {
				urlopen.open(GetCall, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error while doing get Call, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ErrorDescription', errorinfo)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "error reading response 'GetCall', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo)
									logEvent(errorinfo);
									session.output.write(errorinfo);
								} else {
									var ctx = session.name('som') || session.createContext('som');
									getStatusId = responseData.statusID;
									ctx.setVariable("getStatusId", getStatusId);
									var switchOrderTypeObjectID = responseData.switchOrderTypeObjectID;
									ctx.setVariable("switchOrderTypeObjectID", switchOrderTypeObjectID);

									//lookup start

									var typeArr = []
									var switchOrderWorkFlowStatusReq = {};
									switchOrderWorkFlowStatusReq.name = "switchOrder.WorkFlowStatus";
									switchOrderWorkFlowStatusReq.id = getStatusId;
									typeArr.push(switchOrderWorkFlowStatusReq);
									doLookup(typeArr, "switchOrderWorkFlowStatus");
									//lookup end
								}
							});
						} else if (responseStatusCode == 401 || responseStatusCode == 403) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "SOM_SP_05: failure in reading message 'GetCall', details are :  " + info + "error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "SOM_SP_05: response received from GetCall : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});

						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading message 'GetCall', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var responseinfo = "response received from GetCall details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error(responseinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', responseinfo)
									session.reject(responseinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "urlopen connect error while doing get Call, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	});
}
