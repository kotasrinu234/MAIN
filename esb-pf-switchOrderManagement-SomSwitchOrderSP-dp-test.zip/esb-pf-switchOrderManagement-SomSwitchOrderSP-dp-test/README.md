    • Interface#32c & d – SOM service request & update(SOM Initiated) 

    • Services:
1.SOM_SPReceiveSwitchOrder
2.SOM_SPReceiveSwitchOrder_Seq
3.SOM_SPSendToAm
4.SOM_SPStatusUpdateSwitchOrder

    • Domain: Switch Order Management Domain

    • Updated Git Repo: esb-pf-switchOrderManagement-SomSwitchOrderSP-dp

    • Objects:
            
                AAA Policy:  SOM_SPCreateUpdate_AAA

                Password Map Alias: SOM_SPCreateUpdate_AAA_PWDAlias 
  

    • HTTPS Handler: 
SOM_SPReceiveSwitchOrder_HTTPS_FSH
Port: 1496

    • IBM MQ Handler: 
SOM_SPReceiveSwitchOrder_Seq_MQFSH
SOM_SPReceiveSwitchOrder_Seq_MQFSH_ALT
SOM_SPReceiveSwitchOrder_Seq_IIB_Retry_MQFSH
SOM_SPSendToAm_MQFSH
SOM_SPSendToAm_MQFSH_ALT
SOM_SPSendToAm_MQFSH_Retry
SOM_SPStatusUpdateSwitchOrder_MQFSH
SOM_SPStatusUpdateSwitchOrder_MQFSH_ALT
SOM_SPStatusUpdateSwitchOrder_MQFSH_Retry

    • MQ Queue Manager: 


SOM_SPReceiveSwitchOrder_Seq_Qmgr
             SOM_SPReceiveSwitchOrder_Seq_Qmgr_ALT
             SOM_SPReceiveSwitchOrder_Seq_IIB_Retry_Qmgr
SOM.SP.RECEIVE.SWITCH.ORDER_QMgr    
SOM.SP.RECEIVE.SWITCH.ORDER_QMgr_ALT    
SOM_SPSendToAm_IIB_Retry_QMgr
SOM.SP.STATUS.UPDATE.SWITCH.ORDER_QMgr
SOM.SP.STATUS.UPDATE.SWITCH.ORDER_QMgr_ALT
SOM.SP.STATUS.UPDATE.SWITCH.ORDER_IIB_RetryQMgr
SOM_SPReceiveSwitchOrder_Seq_Backend_Qmgr
SOM_SPReceiveSwitchOrder_Seq_IIB_Retry_Qmgr
SOM_SPReceiveSwitchOrder_Seq_Qmgr
SOM_SPReceiveSwitchOrder_Seq_Qmgr_ALT


    • Host Name: esbmqst.serv.dteco.com(1260)
Host Name: esbiibst.serv.dteco.com(1259)

    • XML Manager: 

SOM_SPReceiveSwitchOrder_XML_Mgr
SOM_SPReceiveSwitchOrder_Seq_XmlMgr
SOM_SPSendToAm_XML_Mgr
SOM_SPStatusUpdateSwitchOrder_XML_Mgr

    • TLS Server Profile: SOM_SPCreateUpdate_FSH_SSL_Server_Profile

    • Crypto Identification Credentials: SOM_SPCreateUpdate_FSH_IDCred

    • Cryptokey: SOM_SPCreateUpdate_Crypto_Key
                  filename: sharedcert:///esbst.p12
                  passwordalias:esbstkeypass

    • Crypto Certificate: SOM_SPCreateUpdate_Crypto_Cert
                   filename: sharedcert:///esbst.p12
                   passwordalias:esbstkeypass


    • TLS Client Profile:  SOM_SPCreateUpdate_AAA_Client_Policy
                                       SOM_SPSendToAm_Client_Profile
                                       SOM_SPStatusUpdateSwitchOrder_Client_Profile
    • SSL Client profile: OMS_SOM_Client_Profile
              




