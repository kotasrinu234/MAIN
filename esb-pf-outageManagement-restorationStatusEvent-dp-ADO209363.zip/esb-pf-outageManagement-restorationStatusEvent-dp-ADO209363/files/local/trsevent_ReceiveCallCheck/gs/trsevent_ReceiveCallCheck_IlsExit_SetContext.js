var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
	var ctx = session.name("trsevent") || session.createContext("trsevent");
	var retry = ctx.getVariable('retry');
	var ErrorTxt = ctx.getVariable('ErrorTxt')
	var callCode = incomingdata.data[0].externalCallCodeID;
	var contactMethod = incomingdata.data[0].contactMethod
	var exitdescriptionACE = session.parameters.ReceiveCallCheckIlsExitDescriptionACE;
    var exitdescription = session.parameters.ReceiveCallCheckIlsExitDescription;
        var ctx = session.name('ils')|| session.createContext('ils');
	if(retry != 'yes'){
		ctx.setVariable("exitStatus",'0');
		if(callCode === 'AMI_XCURR' || callCode === 'XCURR' || callCode === 'MOMENTARY'){
			if(contactMethod == '6'){
				ctx.setVariable('exitDestination', 'WTP.REQUEST');
				ctx.setVariable('Exitdescription', exitdescriptionACE)
			}
			else{
				ctx.setVariable('exitDestination', 'TROUBLE/STATUS/events/CallStatus');
				ctx.setVariable('Exitdescription', exitdescription)
			}
		}
		else{
			ctx.setVariable('exitDestination', 'TROUBLE/STATUS/events/CallStatus');
			ctx.setVariable('Exitdescription', exitdescription)
		}
	}else{
	
		if(callCode === 'AMI_XCURR' || callCode === 'XCURR' || callCode === 'MOMENTARY'){
				if(contactMethod == '6'){
					ctx.setVariable('exitDestination','WTP.REQUEST');
				}
				else{
					ctx.setVariable('exitDestination','TROUBLE/STATUS/events/CallStatus');
				}
		}
		else{
			ctx.setVariable('exitDestination','TROUBLE/STATUS/events/CallStatus');
		}
		ctx.setVariable("exitStatus",'');
		ctx.setVariable('Exitdescription',ErrorTxt)
	}
	}
	});
