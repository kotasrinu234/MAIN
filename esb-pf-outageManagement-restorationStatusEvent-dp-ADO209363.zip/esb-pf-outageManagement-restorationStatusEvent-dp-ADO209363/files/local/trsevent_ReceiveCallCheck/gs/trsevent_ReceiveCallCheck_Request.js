var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("trsevent") || session.createContext("trsevent");

session.INPUT.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {

		var incomingdata = JSON.parse(jsonData);
		var ACEMQUrl = session.parameters.ACEMQUrl
		var PublishTopicUrl = session.parameters.PublishTopicUrl

		var dateTime = new Date();

		var buff = new Buffer((jsonData));
		var EncodedpayloadMessage = buff.toString('base64');
		var messageId = incomingdata.data[0].displayID + ":" + incomingdata.eventTime;

		/*var StringIncome = incomingdata.toString();
		var EncodedpayloadMessage = Buffer.from(StringIncome).toString('base64')*/
		/*var buff = new Buffer(StringIncome);
		var EncodedpayloadMessage = buff.toString('base64');*/

		ctx.setVariable("EncodedpayloadMessage", EncodedpayloadMessage)
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }

		var payload = {
			"messageId": messageId,
			"serviceName": "interface3",
			"eventType": "CALL",
			"payload": EncodedpayloadMessage,
			"sendTimeStamp": dateTime.toISOString(),
			"waitTime": session.parameters.WaitTime,
			"destQueueName": "TRSEVNT.EFC.CALL.CHECK.RESPONSE"
		};

		if (incomingdata.data[0].displayID != undefined && incomingdata.data[0].displayID != null && incomingdata.data[0].displayID != '') {
			payload.eventContext = incomingdata.data[0].displayID;
		}
		if (incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
			payload.eventTimeStamp = incomingdata.eventTime;
		}
		if (incomingdata.data[0].status != undefined && incomingdata.data[0].status != null && incomingdata.data[0].status != '') {
			payload.eventStatus = incomingdata.data[0].status;
		}

		var ConfigurableContactMethod = session.parameters.ConfigurableContactMethod
		var ConfigurableExternalCallCodeID = session.parameters.ConfigurableExternalCallCodeID

		//ctx.setVariable("ConfigurableContactMethod", ConfigurableContactMethod)
		//ctx.setVariable("ConfigurableExternalCallCodeID", ConfigurableExternalCallCodeID)

		var IncomingContactMethod = incomingdata.data[0].contactMethod
		var IncomingExternalCallCodeID = incomingdata.data[0].externalCallCodeID



		if (ConfigurableContactMethod === null || ConfigurableContactMethod === undefined || ConfigurableContactMethod === '' || ConfigurableContactMethod === []) {
			QueueCall(PublishTopicUrl, incomingdata)
		} else {
			if (ConfigurableExternalCallCodeID === null || ConfigurableExternalCallCodeID === undefined || ConfigurableExternalCallCodeID === '' || ConfigurableExternalCallCodeID === []) {
				QueueCall(PublishTopicUrl, incomingdata)
			} else {
				if (IncomingContactMethod === null || IncomingContactMethod === undefined || IncomingContactMethod === '') {
					QueueCall(PublishTopicUrl, incomingdata)
				} else {
					if (IncomingExternalCallCodeID === null || IncomingExternalCallCodeID === undefined || IncomingExternalCallCodeID === '') {
						QueueCall(PublishTopicUrl, incomingdata)
					} else {
						if (ConfigurableContactMethod.includes(IncomingContactMethod)) {
							if (ConfigurableExternalCallCodeID.includes(IncomingExternalCallCodeID)) {
								QueueCall(ACEMQUrl, payload)
							} else {
								QueueCall(PublishTopicUrl, incomingdata)
							}
						} else {
							QueueCall(PublishTopicUrl, incomingdata)
						}
					}
				}
			}
		}


		ctx.setVariable("payload", payload);
                session.output.write(payload);
		function QueueCall(StandaloneMQurl, payload) {
			var pushingToQueue = {
				target: StandaloneMQurl,
				data: payload
			};

			urlopen.open(pushingToQueue, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					logger.error("error while publishing message to queue is " + error);
					//session.reject(" error while publishing message to queue is " + error);
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = "Trsevent_RCC_001 : urlopen connect error while keeping the payload to Queue " + error;
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								hm.response.statusCode = 500
								session.reject("error while publishing message to queue is " + error);
							} else {
								logger.debug("MQResponsecode " + mqrc);
							}
						});
					} else {
						logger.error("response code for urlopen.open error [MQRC=" + mqrc + "]");
						ctx.setVariable("retry", 'yes');
						var ErrorTxt = "Trsevent_RCC_001 : urlopen connect error while keeping the payload to Queue " + error;
						ctx.setVariable("ErrorTxt", ErrorTxt);
                                                //session.reject(" response code for urlopen.open error [MQRC=" + mqrc + "]");

					}
				}
			})
		}


	}
})
