var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});

var ctx = session.name('ils') || session.createContext('ils');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var incomingdata = incomingdata;
		var json_mqrfh2 = headers.get({ type: 'mq' }, 'MQRFH2');
		var correlationID;
		var eventType = incomingdata.eventType;

		if (eventType === "LinkedJobDetail") {
			correlationID = incomingdata.data.linkedJobId + ':' + incomingdata.data.origEventTime
			ctx.setVariable("correlationID", correlationID);
			ctx.setVariable("messageType", "jobFollowUpEvent");

			if (incomingdata.data.linkedJobId != undefined) {
				ctx.setVariable('linkedjobId', incomingdata.data.linkedJobId);
			}
			if (incomingdata.data.linkedJobDisplayId != undefined) {
				ctx.setVariable('linkedJobDisplayId', incomingdata.data.linkedJobDisplayId);
			}

			if (incomingdata.data.origEventTime != undefined) {
				ctx.setVariable('origEventTime', incomingdata.data.origEventTime);
			}

		}


		if (eventType === "ReportedCallDetails") {
			if (incomingdata.data.origEventTime != undefined) {
				correlationID = incomingdata.data.calls[0].callId + ':' + incomingdata.data.origEventTime
				ctx.setVariable('correlationID', correlationID);
			}
			else {
				correlationID = incomingdata.data.calls[0].callId
				ctx.setVariable('correlationID', correlationID);
			}
			var callDisplayID = incomingdata.data.calls[0].callId
			var jobID = incomingdata.data.jobId
			var callCode = incomingdata.data.calls[0].callCode
			var premiseID = incomingdata.data.calls[0].premiseId
			var sourceEventTimestamp = incomingdata.data.origEventTime
			var Entrydescription = session.parameters.IlsEntryDescription;
			var messageType = session.parameters.callMessageType;
			ctx.setVariable("messageType", messageType);
		}
		else if (eventType === "CrewStatus") {
			if (incomingdata.data.origEventTime != undefined) {
				correlationID = incomingdata.data.crews[0].crewAssignmentId + ':' + incomingdata.data.origEventTime
				ctx.setVariable('correlationID', correlationID);
			}
			else {
				correlationID = incomingdata.data.crews[0].crewAssignmentId
				ctx.setVariable('correlationID', correlationID);
			}
			var crewAssignmentDisplayID = incomingdata.data.crews[0].crewAssignmentId;
			var messageType = session.parameters.CrewMessageType;

			var jobID = incomingdata.data.jobId;
			var sourceEventTimestamp = incomingdata.data.origEventTime;
			var Entrydescription = session.parameters.CrewIlsEntryDecsription;
			ctx.setVariable("messageType", messageType);
		}
		else if (eventType === "JobStatusDetail") {
			if (incomingdata.data.origEventTime != undefined) {
				correlationID = incomingdata.data.jobId + ':' + incomingdata.data.origEventTime
				ctx.setVariable('correlationID', correlationID);
			}
			else {
				correlationID = incomingdata.data.jobId
				ctx.setVariable('correlationID', correlationID);
			}
			var jobID = incomingdata.data.jobId;
			var jobDisplayId = incomingdata.data.jobDisplayId;
			var messageType = session.parameters.jobMessageType;
			var sourceEventTimestamp = incomingdata.data.origEventTime
			var Entrydescription = session.parameters.JobIlsEntryDescription;
			ctx.setVariable("messageType", messageType);
		}
		else if (eventType === "PredictedPremises") {
			if (json_mqrfh2.MQRFH2.NameValueData.NameValue != undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr != undefined && json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.triggerValue != undefined) {
				var operation = json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.operation.$;
				if (operation !== undefined) {
					ctx.setVariable("operation", operation);
				}
			}
			if (operation === 'UPDATE') {
				if (incomingdata.eventTime != undefined) {
					correlationID = incomingdata.data.jobId + ':' + incomingdata.data.origEventTime
					ctx.setVariable('correlationID', correlationID);
				}
				else {
					correlationID = incomingdata.data.jobId
					ctx.setVariable('correlationID', correlationID);
				}
				var jobID = incomingdata.data.jobId
				var jobDisplayID = incomingdata.data.displayID
				var sourceEventTimestamp = incomingdata.eventTime
				var messageType = session.parameters.PPreMessageType;
				var Entrydescription = session.parameters.PPupdateIlsEntryDescription;
				ctx.setVariable("messageType", messageType);
			}
			else {
				if (incomingdata.data.origEventTime != undefined) {
					correlationID = incomingdata.data.jobId + ':' + incomingdata.data.origEventTime
					ctx.setVariable('correlationID', correlationID);
				}
				else {
					correlationID = incomingdata.data.jobId
					ctx.setVariable('correlationID', correlationID);
				}
				var jobID = incomingdata.data.jobId
				var parttotalParts = incomingdata.data.part + ':' + incomingdata.data.totalParts
				var sourceEventTimestamp = incomingdata.data.origEventTime
				var messageType = session.parameters.PPreMessageType;
				var Entrydescription = session.parameters.PPreIlsEntryDescription;
				ctx.setVariable("messageType", messageType);
			}

		}
		else if (eventType === "CustomerStatus") {
			correlationID = incomingdata.data.msgId
			ctx.setVariable('correlationID', correlationID);
			var premiseID = incomingdata.data.premiseId
			var messageType = session.parameters.customerMessageType;
			var sourceEventTimestamp = incomingdata.data.origEventTime
			var Entrydescription = session.parameters.CustIlsEntryDescription;
			ctx.setVariable("messageType", messageType);
		}


		if (callDisplayID != undefined) {
			ctx.setVariable('callDisplayID', callDisplayID);
		}
		if (crewAssignmentDisplayID != undefined) {
			ctx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID);
		}
		if (jobID != undefined) {
			ctx.setVariable('jobID', jobID);
		}
		if (jobDisplayId != undefined) {
			ctx.setVariable('jobDisplayId', jobDisplayId);
		}
		if (parttotalParts != undefined) {
			ctx.setVariable('parttotalParts', parttotalParts);
		}
		if (callCode != undefined) {
			ctx.setVariable('callCode', callCode);
		}
		if (premiseID != undefined) {
			ctx.setVariable('premiseID', premiseID);
		}
		if (sourceEventTimestamp != undefined) {
			ctx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
		}
		if (Entrydescription != undefined) {
			ctx.setVariable('Entrydescription', Entrydescription);
		}

	}
});
