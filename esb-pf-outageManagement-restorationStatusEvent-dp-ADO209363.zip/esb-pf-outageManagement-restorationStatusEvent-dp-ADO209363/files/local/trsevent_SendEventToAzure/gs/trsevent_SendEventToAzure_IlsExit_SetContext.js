var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name('ils') || session.createContext('ils');
var ctx1 = session.name('ilsexit') || session.createContext('ilsexit');
var ctx2 = session.name("trsevent") || session.createContext("trsevent");
var operation = ctx.getVariable("operation")
var exitDest = ctx2.getVariable("exitDestination");
var logger = console.options({
	'category': 'all'
});
var exitDest = session.parameters.AzureURL;
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var retry = ctx2.getVariable('retry');
		var ErrorTxt = ctx2.getVariable('ErrorTxt')
		var eventType = incomingdata.eventType;
		var premises = incomingdata.data.premises;
		var messageType;
		if (retry !== 'yes') {
			
			if(eventType === "LinkedJobDetail"){
				ctx.setVariable('Exitdescription', 'Customer update event  sent to EFC.');
				ctx.setVariable('exitStatus', '0');
				ctx.setVariable('exitDestination', exitDest);
			}
			
			if (eventType === "ReportedCallDetails") {
				ctx.setVariable('exitStatus', '0');
				ctx.setVariable('exitDestination', exitDest);
				var Exitdescription = session.parameters.IlsExitDescription;
				if (Exitdescription != undefined) {
					ctx.setVariable('Exitdescription', Exitdescription);
				}
				messageType = session.parameters.callMessageType;
				ctx1.setVariable("messageType", messageType);
			}
			else if (eventType === "CrewStatus") {
				ctx.setVariable('exitStatus', '0');
				ctx.setVariable('exitDestination', exitDest);
				var Exitdescription = session.parameters.CrewIlsExitDecsription;
				if (Exitdescription != undefined) {
					ctx.setVariable('Exitdescription', Exitdescription);
				}
				messageType = session.parameters.CrewMessageType;
				ctx1.setVariable("messageType", messageType);
			}
			else if (eventType === "JobStatusDetail") {
				ctx.setVariable('exitStatus', '0');
				ctx.setVariable('exitDestination', exitDest);
				var Exitdescription = session.parameters.JobIlsExitDescription;
				if (Exitdescription != undefined) {
					ctx.setVariable('Exitdescription', Exitdescription);
				}
				messageType = session.parameters.jobMessageType;
				ctx1.setVariable("messageType", messageType);
			}
			else if (eventType === "PredictedPremises") {
				if (operation === 'UPDATE') {
					if (premises.length > 1) {
						var parttotalParts = incomingdata.data.part + ':' + incomingdata.data.totalParts;
						
						if (parttotalParts !== undefined) {
							ctx1.setVariable('parttotalParts', parttotalParts);
						}
						messageType = session.parameters.PPreMessageType;
						ctx1.setVariable('messageType', messageType);
						ctx.setVariable('exitStatus', '0');
						ctx.setVariable('exitDestination', exitDest);
						var Exitdescription = session.parameters.PPreupdateIlsExitDescription;
						if (Exitdescription != undefined) {
							ctx.setVariable('Exitdescription', Exitdescription);
						}
					}
					else {
						messageType = session.parameters.PPreMessageType;
						ctx1.setVariable('messageType', messageType);
						ctx.setVariable('exitStatus', '0');
						ctx.setVariable('exitDestination', exitDest);
						var Exitdescription = session.parameters.PPupdateIlsExitDescription;
						if (Exitdescription != undefined) {
							ctx.setVariable('Exitdescription', Exitdescription);
						}
					}

				}
				else {
					ctx.setVariable('exitStatus', '0');
					ctx.setVariable('exitDestination', exitDest);
					var Exitdescription = session.parameters.PPreIlsExitDescription;
					if (Exitdescription != undefined) {
						ctx.setVariable('Exitdescription', Exitdescription);
					}
					messageType = session.parameters.PPreMessageType;
					ctx1.setVariable("messageType", messageType);
				}
			}
			else if (eventType === "CustomerStatus") {
				ctx.setVariable('exitStatus', '0');
				ctx.setVariable('exitDestination', exitDest);
				var Exitdescription = session.parameters.CustIlsExitDescription;
				if (Exitdescription != undefined) {
					ctx.setVariable('Exitdescription', Exitdescription);
				}
				messageType = session.parameters.customerMessageType;
				ctx1.setVariable("messageType", messageType);
			}

		} else {
			if (eventType === "ReportedCallDetails") {
				if (exitDest === '') {
					ctx.setVariable('exitDestination', exitDest);
				}
				messageType = session.parameters.callMessageType;
				ctx1.setVariable("messageType", messageType);
			}
			else if (eventType === "CrewStatus") {
				if (exitDest === '') {
					ctx.setVariable('exitDestination', exitDest);
				}
				messageType = session.parameters.CrewMessageType;
				ctx1.setVariable("messageType", messageType);
			}
			else if (eventType === "JobStatusDetail") {
				if (exitDest === '') {
					ctx.setVariable('exitDestination', exitDest);
				}
				messageType = session.parameters.jobMessageType;
				ctx1.setVariable("messageType", messageType);
			}
			else if (eventType === "PredictedPremises") {
				if (operation === 'UPDATE') {
					var parttotalParts = incomingdata.data.part + ':' + incomingdata.data.totalParts;
					if (parttotalParts !== undefined) {
						ctx1.setVariable('parttotalParts', parttotalParts);
					}
					messageType = session.parameters.PPreMessageType
					ctx1.setVariable('messageType', messageType);
					if (exitDest === '') {
						ctx.setVariable('exitDestination', exitDest);
					}
				}
				else {
					if (exitDest === '') {
						ctx.setVariable('exitDestination', exitDest);
					}
					messageType = session.parameters.PPreMessageType;
					ctx1.setVariable('messageType', messageType)
				}
			}
			else if (eventType === "CustomerStatus") {
				if (exitDest === '') {
					ctx.setVariable('exitDestination', exitDest);
				}
				messageType = session.parameters.customerMessageType;
				ctx1.setVariable("messageType", messageType);
			}
			ctx.setVariable('Exitdescription', ErrorTxt)
		}
	}
});
