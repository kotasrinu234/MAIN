//js is used to set context variables from stylesheet params
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("trsevent") || session.createContext("trsevent");
var ctx1 = session.name('ils') || session.createContext('ils');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Trsevent_Azure_001: Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		ctx.setVariable("incomingdata", incomingdata);
		var GetTokenUrl = session.parameters.GetTokenUrl
		var Options = {
			target: GetTokenUrl,
			method: 'GET',
			contentType: 'application/json',
		};

		urlopen.open(Options, function(error, response) {
			if (error) {
				logger.error("Trsevent_Azure_001: urlopen connect error of Get Token " + JSON.stringify(error));
				//session.reject("urlopen connect error " + JSON.stringify(error));
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "Trsevent_Azure_001 : Error occured in the Token call " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx1.setVariable('exitStatus', '500');
				session.output.write(incomingdata)
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							logger.error("Trsevent_Azure_002: Failure in getting response " + JSON.stringify(error));
							ctx1.setVariable('exitStatus', '500');
							session.reject("Failure in getting response " + JSON.stringify(error));
							
						} else {
							hm.response.statusCode = '200 OK';
							logger.debug("response received :" + JSON.stringify(responseData));
							ctx.setVariable("Response", responseData)
							ctx1.setVariable('exitStatus', '0');
							//session.output.write(responseData)

							var AccessToken = responseData.access_token
							if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
								logger.error("Trsevent_Azure_002:Invalid token response  " + JSON.stringify(responseData))
								//session.reject("Invalid token response  " + JSON.stringify(responseData))
								ctx.setVariable("retry", 'yes');
								var ErrorTxt = "Trsevent_Azure_002: Invalid token response  " + JSON.stringify(error);
								ctx.setVariable("ErrorTxt", ErrorTxt);
							} else {
								var TokenType = responseData.token_type
								var AzureURL = session.parameters.AzureURL
								var Payload = incomingdata
								var Auth = TokenType + ' ' + AccessToken
                                                                session.output.write(Payload);
								var AzureCall = {
									target: AzureURL,
									sslClientProfile: 'trsevent_SendEventToAzure_SSL_ClientProfile',
									method: 'POST',
									headers: {
										'Authorization': Auth,
									},
									contentType: 'application/json',
									data: Payload
								};

								urlopen.open(AzureCall, function(error, response) {
									if (error) {
										logger.error("Trsevent_Azure_003: urlopen connect error " + JSON.stringify(error));
										//session.reject("urlopen connect error " + JSON.stringify(error));
										ctx.setVariable("retry", 'yes');
										var ErrorTxt = "Trsevent_Azure_003: Error occured in the Azure call " + JSON.stringify(error);
										ctx.setVariable("ErrorTxt", ErrorTxt);
										ctx1.setVariable('exitStatus', '500');
										ctx1.setVariable('exitDestination', AzureURL);
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode == 200) {
											response.readAsJSON(function(error, responseData) {
												if (error) {
													logger.error("Trsevent_Azure_003: Failure in getting response " + JSON.stringify(error));
													session.reject("Failure in getting response " + JSON.stringify(error));
													ctx.setVariable('exitStatus', '500');
												} else {
													hm.response.statusCode = '200 OK';
													logger.debug("response received :" + JSON.stringify(responseData));
													ctx.setVariable("ResponseAzure", responseData)
													ctx1.setVariable('exitStatus', responseStatusCode);
												}
											});
										} else if (responseStatusCode == 201) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													logger.error("Trsevent_Azure_003: Failure in getting response " + JSON.stringify(error));
													session.reject("Failure in getting response " + JSON.stringify(error));
												} else {
													hm.response.statusCode = '201 OK';
													logger.debug("response received :" + responseData);
													ctx.setVariable("ResponseAzure", responseData)
													ctx1.setVariable('exitStatus', '0');
												}
											});
										} else if(responseStatusCode == 503){
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													logger.error("Trsevent_Azure_003: failure in reading response  " + JSON.stringify(error));
													session.reject("failure in reading response  ");
												} else {
													hm.current.statusCode = responseStatusCode;
													logger.error("Error returned from Azure " + ": with statusCode " + responseStatusCode + " " + responseData);
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = "Trsevent_Azure_003 : Error occured in the Azure call "+ ": with statusCode " + responseStatusCode + " "  + responseData;
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ctx1.setVariable('exitStatus', responseStatusCode);
												}
											});
										} else {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													logger.error("Trsevent_Azure_003: failure in reading response  " + JSON.stringify(error));
													session.reject("failure in reading response  ");
												} else {
													hm.current.statusCode = responseStatusCode;
													logger.error("Trsevent_Azure_003: Error returned from Azure " + ": with statusCode " + responseStatusCode + " " + responseData);
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = "Trsevent_Azure_003 : Error occured in the Azure call "+ ": with statusCode " + responseStatusCode + " "  + responseData;
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ctx1.setVariable('exitStatus', responseStatusCode);
												}
											});
										}
									}
								});
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("Trsevent_Azure_001: failure in reading response  " + JSON.stringify(error));
							session.reject("failure in reading response  ");
						} else {
							hm.current.statusCode = responseStatusCode;
							logger.error("Trsevent_Azure_001: Error returned from Token call " + ": with statusCode " + responseStatusCode + " " + responseData);
							ctx.setVariable("retry", 'yes');
							var ErrorTxt = "Trsevent_Azure_001 : Error occured in the Token call "+ ": with statusCode " + responseStatusCode + " " + responseData;
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ctx1.setVariable('exitStatus', responseStatusCode);
                                                        //session.reject("Error returned from Token call " + ": with statusCode " + responseStatusCode + " " + responseData);

						}
					});
				}
			}
		});
	}
});
