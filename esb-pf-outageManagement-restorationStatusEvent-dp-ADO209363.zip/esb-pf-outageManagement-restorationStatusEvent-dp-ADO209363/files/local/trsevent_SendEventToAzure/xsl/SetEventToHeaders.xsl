<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:da="http://www.itron.com/ami/2008/10/data"
	xmlns:dp="http://www.datapower.com/extensions"
	extension-element-prefixes="dp da" exclude-result-prefixes="dp da">
	<xsl:variable name="eventType">
		<xsl:value-of disable-output-escaping="no"
			select="/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'eventType']]" />
	</xsl:variable>
	<xsl:variable name="eventTime">
		<xsl:value-of disable-output-escaping="no"
			select="/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'eventTime']]" />
	</xsl:variable>
	<xsl:template match="/">
		<dp:set-http-request-header
			name="'EventType'" value="$eventType" />
		<dp:set-http-request-header
			name="'EventTime'" value="$eventTime" />
	</xsl:template>
</xsl:stylesheet>



	 