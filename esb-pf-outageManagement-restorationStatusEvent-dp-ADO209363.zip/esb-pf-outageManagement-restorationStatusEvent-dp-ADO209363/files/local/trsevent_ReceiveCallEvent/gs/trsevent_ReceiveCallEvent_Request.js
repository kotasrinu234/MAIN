var ctx = session.name("trsevnt") || session.createContext("trsevnt");
var ILSctx = session.name('ils') || session.createContext('ils');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var MQurl;
		var DestQueue;
		var Payload;
		var sourceUrl = sm.getVar('var://service/URL-in');
		if (sourceUrl.includes("CallCanceled")) {
			incomingdata.data[0].status = 'CANCELLED'
			Payload = incomingdata
			session.output.write(Payload)
			ctx.setVariable('CancelledPayload', Payload)
		} else if (sourceUrl.includes("CallResolved")) {
			incomingdata.data[0].status = 'RESOLVED'
			Payload = incomingdata
			session.output.write(Payload)
			ctx.setVariable('ResolvedPayload', Payload)
		} else {
			Payload = incomingdata
			session.output.write(Payload)
			ctx.setVariable('InputPayload', Payload)
		}

		if (sourceUrl.includes("JobCreated")) {
			function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
			incomingdata.messageID = uuidv4()
			Payload = incomingdata
			MQurl = session.parameters.jobCreatedQueueString
			DestQueue = 'TRSEVNT.JOB.CREATED.CALL.REQUEST'
			ctx.setVariable('JobCreatedPayload', Payload)
		} else {
			MQurl = session.parameters.callEventQueueString
			DestQueue = 'TRSEVNT.EFC.CALL.CHECK.REQUEST'
		}

		var pushingToQueue = {
			target: MQurl,
			data: Payload
		};
		var info = " TargetURL :" + pushingToQueue.target + "; Method :" + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";
		ILSctx.setVariable('ExitStatus', '0');
		ILSctx.setVariable('ExitDestination', MQurl);
		try {
			urlopen.open(pushingToQueue, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var errorinfo = "trsevnt_RC_03 : url connection error QueueName '" + DestQueue + "', details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					ILSctx.setVariable('ExitDestination', MQurl);
					var ctx = session.name("trsevnt") || session.createContext("trsevnt");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(errorinfo);
					session.reject(errorinfo)
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								var errorinfo = "failure in reading response QueueName '" + DestQueue + "', details are : " + info + "; error info :" + readError
								ILSctx.setVariable('ExitStatus', '500');
								ILSctx.setVariable('ExitDescription', errorinfo)
								hm.response.statusCode = 500
								logger.error(errorinfo);
							} else {
								logger.debug("MQResponsecode " + mqrc);
							}
						});
					} else {
						var errorinfo = "error response QueueName '" + DestQueue + "', details are : " + info + "; response  info :" + response
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						ILSctx.setVariable('ExitDestination', MQurl);
						var ctx = session.name("trsevnt") || session.createContext("trsevnt");
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						logger.error(" Error received from the response of Queue [MQRC=" + mqrc + "]" + errorinfo);

					}
				}
			});
		} catch (err) {
			var errorinfo = "trsevnt_RC_03 : url connection error QueueName '" + DestQueue + "', details are : " + info + "; error info :" + err
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo)
			ILSctx.setVariable('ExitDestination', MQurl);
			logger.error(errorinfo);
			session.reject(errorinfo)
		}
	}
});