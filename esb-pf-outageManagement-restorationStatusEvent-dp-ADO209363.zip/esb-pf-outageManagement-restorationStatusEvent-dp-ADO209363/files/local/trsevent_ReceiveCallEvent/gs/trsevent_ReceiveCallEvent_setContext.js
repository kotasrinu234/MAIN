var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ils') || session.createContext('ils');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var correlationID;
		if (incomingdata.eventTime != undefined) {
			correlationID = incomingdata.data[0].displayID + ':' + incomingdata.eventTime
		} else {
			correlationID = incomingdata.data[0].displayID
		}

		ilsNullCheck(correlationID, 'correlationID')
		ilsNullCheck(incomingdata.data[0].id, 'callID')
		ilsNullCheck(incomingdata.data[0].displayID, 'callDisplayID')
		ilsNullCheck(incomingdata.data[0].jobID, 'jobID')
		ilsNullCheck(incomingdata.data[0].jobDisplayID, 'jobDisplayID')
		ilsNullCheck(incomingdata.data[0].externalCallCodeID, 'callCode')
		ilsNullCheck(incomingdata.data[0].externalPremiseID, 'premiseID')
		ilsNullCheck(incomingdata.eventTime, 'sourceEventTimestamp')
		ilsNullCheck(session.parameters.IlsEntryDescription, 'entrydescription')
		ilsNullCheck(session.parameters.IlsExitDescription, 'exitdescription')
		ILSctx.setVariable('retryCount', -1);
	}
});

function ilsNullCheck(parameterValue, ilsctxname) {
	if (!(parameterValue === undefined || parameterValue === null || parameterValue === '')) {
		ILSctx.setVariable(ilsctxname, parameterValue);
	} else {
		ILSctx.setVariable(ilsctxname, '');
	}
}