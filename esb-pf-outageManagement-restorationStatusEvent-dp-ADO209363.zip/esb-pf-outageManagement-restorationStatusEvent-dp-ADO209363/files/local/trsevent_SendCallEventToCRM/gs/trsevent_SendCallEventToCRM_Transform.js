var ctx = session.name("trsevent") || session.createContext("trsevent");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("trsevnt_CallEventCRM_001: Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ilsctx = session.name("ils") || session.createContext("ils");
		ilsctx.setVariable("exitStatus", '500');

		var dateTime = new Date();
		var payload = {
			"JobStatusDetails": {
				"eventType": "reportedCall",
				"eventTime": dateTime.toISOString(),
				"ReportedCallDetails": [{}]
			}
		}

		if (!(incomingdata.data[0].jobID == undefined)) { payload.JobStatusDetails.id = incomingdata.data[0].jobID }
		if (!(incomingdata.data[0].jobDisplayID == undefined)) { payload.JobStatusDetails.jobId = incomingdata.data[0].jobDisplayID }
		if (!(incomingdata.eventTime == undefined)) { payload.JobStatusDetails.origEventTime = incomingdata.eventTime }


		var ApplicationID = ctx.getVariable("ApplicationID");
		var contactMethod = ctx.getVariable("contactMethod");
		var CustomFieldValuesExtSource = incomingdata.data[0].customFieldValuesExt.source;
	
		if (!(ApplicationID === undefined || ApplicationID === null || ApplicationID === "")) {
			payload.JobStatusDetails.ReportedCallDetails[0].applicationId = ApplicationID;
		} else if (!(incomingdata.data[0].customFieldValuesExt == null || incomingdata.data[0].customFieldValuesExt == '' ||incomingdata.data[0].customFieldValuesExt == undefined)) {
			if (!(incomingdata.data[0].customFieldValuesExt.ApplicationID === null ||incomingdata.data[0].customFieldValuesExt.ApplicationID === '' ||incomingdata.data[0].customFieldValuesExt.ApplicationID === undefined)) {
				payload.JobStatusDetails.ReportedCallDetails[0].applicationId = incomingdata.data[0].customFieldValuesExt.ApplicationID;
			} else if (contactMethod === undefined || contactMethod === null || contactMethod === "") {
				payload.JobStatusDetails.ReportedCallDetails[0].applicationId = 'A';
			} else if (contactMethod == 7) {
				if (CustomFieldValuesExtSource === undefined || CustomFieldValuesExtSource === null || CustomFieldValuesExtSource === "") {
					payload.JobStatusDetails.ReportedCallDetails[0].applicationId = "C";
				} else {
					if (CustomFieldValuesExtSource == "CRM") {
						payload.JobStatusDetails.ReportedCallDetails[0].applicationId = "C";
					} else if (CustomFieldValuesExtSource == "WISMO") {
						payload.JobStatusDetails.ReportedCallDetails[0].applicationId = "Z";
					} else {
						var errorTxt = "Invalid Source: " + CustomFieldValuesExtSource;
						logger.error(errorTxt);
						ctx.setVariable("ErrorTxt", errorTxt);
						ctx.setVariable("retry", 'yes');
						payload.JobStatusDetails.ReportedCallDetails[0].applicationId = "";
					}
				}
			}
		} else {
			payload.JobStatusDetails.ReportedCallDetails[0].applicationId = " ";
		}
		
		if (!(incomingdata.data[0].customFieldValuesExt == undefined)) {

			if (!(incomingdata.data[0].customFieldValuesExt.CrossStreet1 == undefined)) {
				payload.JobStatusDetails.ReportedCallDetails[0].crossStreet1 = incomingdata.data[0].customFieldValuesExt.CrossStreet1
			}
			if (!(incomingdata.data[0].customFieldValuesExt.CrossStreet2 == undefined)) {
				payload.JobStatusDetails.ReportedCallDetails[0].crossStreet2 = incomingdata.data[0].customFieldValuesExt.CrossStreet2
			}
			if (!(incomingdata.data[0].customFieldValuesExt.Municipality == undefined)) {
				payload.JobStatusDetails.ReportedCallDetails[0].municipality = incomingdata.data[0].customFieldValuesExt.Municipality
			}
			/*if (!(incomingdata.data[0].customFieldValuesExt.external_order_number == undefined)) {
				payload.JobStatusDetails.ReportedCallDetails[0].externalReference = incomingdata.data[0].customFieldValuesExt.external_order_number
			}*/
		}


		if (!(incomingdata.data[0].externalPremiseID == undefined)) { payload.JobStatusDetails.ReportedCallDetails[0].premiseId = incomingdata.data[0].externalPremiseID }
		if (!(incomingdata.data[0].displayID == undefined)) { payload.JobStatusDetails.ReportedCallDetails[0].callId = incomingdata.data[0].displayID }
		if (!(incomingdata.data[0].externalCallCodeID == undefined)) { payload.JobStatusDetails.ReportedCallDetails[0].callCode = incomingdata.data[0].externalCallCodeID }
		if (!(incomingdata.data[0].status == undefined)) { payload.JobStatusDetails.ReportedCallDetails[0].callStatus = incomingdata.data[0].status }
		if (!(incomingdata.data[0].meterID == undefined)) { payload.JobStatusDetails.ReportedCallDetails[0].meterId = incomingdata.data[0].meterID }
		if (!(incomingdata.data[0].customFieldValuesExt == undefined)) {

			if (!(incomingdata.data[0].customFieldValuesExt.CancelDueToGoodVoltage == true)) {
				payload.JobStatusDetails.ReportedCallDetails[0].autoCloseFlag = false
			} else {
				payload.JobStatusDetails.ReportedCallDetails[0].autoCloseFlag = true
			}
		}



		if (!(incomingdata.data[0].phoneNumber == undefined)) {

			var PhoneNumber = incomingdata.data[0].phoneNumber

			PhoneNumber = PhoneNumber.replace(/<[^>]*>|[^a-zA-Z0-9,;\-.!?<> ]/g, '')
			PhoneNumber = PhoneNumber.replace(/\s/g, "")
			PhoneNumber = PhoneNumber.replace(/\,/g, "")
			PhoneNumber = PhoneNumber.replace(/\-/g, "")
			PhoneNumber = PhoneNumber.replace(/\!/g, "")
			PhoneNumber = PhoneNumber.replace(/\</g, "")
			PhoneNumber = PhoneNumber.replace(/\>/g, "")
			PhoneNumber = PhoneNumber.replace(/\./g, "")
			PhoneNumber = PhoneNumber.replace(/\?/g, "")
			PhoneNumber = PhoneNumber.replace(/[a-zA-Z]/g, "")
			//	ctx.setVariable("PhoneNumber", PhoneNumber)
			if (PhoneNumber !== null) {
				payload.JobStatusDetails.ReportedCallDetails[0].phoneNumber = parseInt(PhoneNumber)
			}

		}

		var offDate;
		if (!(incomingdata.data[0].startedTime == undefined)) {
			offDate = incomingdata.data[0].startedTime;
			payload.JobStatusDetails.ReportedCallDetails[0].offDate = incomingdata.data[0].startedTime
		}
		else {
			offDate = incomingdata.data[0].createdAt;
			payload.JobStatusDetails.ReportedCallDetails[0].offDate = incomingdata.data[0].createdAt
		}

		var onDate;
		var lookupResponseData_outageType = ctx.getVar("lookupResponseData_outageType");
		if (!(lookupResponseData_outageType == null)) {
			if (lookupResponseData_outageType == 'UNPLANNED_OUTAGE') {
				if (!(incomingdata.data[0].resolvedAt == undefined)) {
					onDate = incomingdata.data[0].resolvedAt
					payload.JobStatusDetails.ReportedCallDetails[0].onDate = incomingdata.data[0].resolvedAt
				}
			} else {
				if (!(incomingdata.data[0].resolvedAt == undefined)) {
					onDate = incomingdata.data[0].resolvedAt
					payload.JobStatusDetails.ReportedCallDetails[0].onDate = incomingdata.data[0].resolvedAt
				}
			}
		}
		if (onDate != '' && onDate != null && onDate != undefined && offDate != '' && offDate != null && offDate != undefined) {
			const eventStartTime = new Date(onDate);
			const eventEndTime = new Date(offDate);
			var resolution = eventStartTime.valueOf() - eventEndTime.valueOf();
			var resolutionTime = ((resolution / (1000 * 60 * 60))).toFixed()
			//resolutionTime = JSON.stringify(resolutionTime)
			//var resolutionTimeBefore = resolutionTime.split('.')[0];
			//var resolutionTimeAfter = resolutionTime.split('.')[1];
			//resolutionTimeAfter = resolutionTimeAfter.substring(0,2)
			//var outageHours = resolutionTimeBefore+'.'+resolutionTimeAfter;
			payload.JobStatusDetails.ReportedCallDetails[0].outageHours = resolutionTime

		}
		var BackendCRMUrl = session.parameters.BackendCRMUrl;
		headers.remove('MQMD');
		session.output.write(payload);
		var CRMApiCalls = {
			target: BackendCRMUrl,
			sslClientProfile: 'trsevent_SendEventToCRM_SSL_ClientProfile',
			method: 'post',
			contentType: 'application/json',

			data: payload
		};

		urlopen.open(CRMApiCalls, function(error, response) {
			if (error) {
				// an error occurred during request sending or response header parsing
				logger.error("trsevnt_CallEventCRM_001: urlopen connect error with CRMAPI_ReportedCalls" + JSON.stringify(error));
				var ErrorTxt = ("trsevnt_CallEventCRM_001: urlopen connect error with CRMAPI_ReportedCalls" + JSON.stringify(error));
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("retry", 'yes');
			} else {
				var responseStatusCode = response.statusCode;
				ilsctx.setVariable("exitStatus", responseStatusCode);
				if (responseStatusCode == 200 || responseStatusCode == 202) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("trsevnt_CallEventCRM_002: failure in reading message from CRMAPI_ReportedCalls" + JSON.stringify(error));
							session.reject(" failure in reading message from CRMAPI_ReportedCalls" + JSON.stringify(error));
						} else {
							logger.debug("response code received from CRMAPI_ReportedCalls call: " + responseStatusCode);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("trsevnt_CallEventCRM_003: failure in reading message from CRMAPI_ReportedCalls is  " + JSON.stringify(error));
							session.reject("failure in reading message from CRMAPI_ReportedCalls is  " + JSON.stringify(error));
						} else {
							logger.error("trsevnt_CallEventCRM_004: Error returned from CRMAPI_ReportedCalls statusCode " + responseStatusCode + " " + responseData);
							session.reject("Error returned from CRMAPI_ReportedCalls statusCode " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
});
