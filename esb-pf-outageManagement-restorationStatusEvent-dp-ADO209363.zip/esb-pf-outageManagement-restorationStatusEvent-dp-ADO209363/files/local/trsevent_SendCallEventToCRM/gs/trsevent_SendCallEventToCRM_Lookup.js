var ctx = session.name("trsevent") || session.createContext("trsevent");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (!(incomingdata.data[0].jobTypeID == null || incomingdata.data[0].jobTypeID == '' || incomingdata.data[0].jobTypeID == undefined)) {

			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "jobOutageTypes",
							"id": incomingdata.data[0].jobTypeID
						}
					]
				}
			}
			var nslookupservice = session.parameters.lookUpURL + '/jobOutageTypes/' + incomingdata.data[0].jobTypeID;
			var options = {
				target: nslookupservice,
				method: 'post',
				contentType: 'application/json',
				data: lookupMessage
			};
			urlopen.open(options, function(error, response) {
				if (error) {
					logger.error("error while calling lookup service " + JSON.stringify(error));
					session.reject("error while calling lookup service " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					var responseReasonPhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("Error from lookup service: " + JSON.stringify(error));
							} else {
								var lookupResponse = JSON.parse(responseData);
								if (lookupResponse.lookupRep.type[0].result == 0) {
									var lookuplabel = lookupResponse.lookupRep.type[0].label;
									ctx.setVariable("lookupResponseData_outageType", lookuplabel);
								} else {
									ctx.setVariable("lookupResponseData_outageType", '');
								}
							}
						});
					} else {
						logger.error("Response returned from Lookupservice is : " + responseReasonPhrase + "  with status code : " + responseStatusCode);
						session.reject("Response returned from Lookupservice is : " + responseReasonPhrase + "  with status code : " + responseStatusCode);
					}
				}
			});
		} else {
			ctx.setVariable("lookupResponseData_outageType", '');
		}

		if (incomingdata.data[0].contactMethod === undefined || incomingdata.data[0].contactMethod === null || incomingdata.data[0].contactMethod === '') {
		} else {
			fs.readAsJSON("local:/trsevent_ProcessEFCCallEvent/gs/CallSourceMap.json", function(readAsJSONError, jsonInternal) {
				if (readAsJSONError) {
					session.reject(readAsJSONError);
				} else {
					var CallSourceMap = jsonInternal
					ctx.setVariable("CallSourceMap", CallSourceMap)

					var contactMethod = incomingdata.data[0].contactMethod
					ctx.setVariable("contactMethod", contactMethod)
					for (var i = 0; i < jsonInternal.CallSourceMap.length; i++) {
						if (!(contactMethod == jsonInternal.CallSourceMap[i].OMSIdentifier)) {
						} else {
							var ApplicationID = jsonInternal.CallSourceMap[i].CRMIdentifier
							ctx.setVariable("ApplicationID", ApplicationID)

						}
					}
				}
			})
		}
	}
});
