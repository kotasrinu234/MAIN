var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
	var ctx = session.name("crewAssignment") || session.createContext("crewAssignment");
	var retry = ctx.getVariable('retry');
	var ErrorTxt = ctx.getVariable('ErrorTxt')
	var ProcessEFCCrewAssignmentEvent_ExitDescription = session.parameters.ProcessEFCCrewAssignmentEvent_ExitDescription
	var ctx = session.name('ils')|| session.createContext('ils');
	if(retry != 'yes'){
	ctx.setVariable('exitStatus','0');
	ctx.setVariable('exitDestination','TRSEVNT.EFC.SEND');
	ctx.setVariable('Exitdescription',ProcessEFCCrewAssignmentEvent_ExitDescription)
	}else{
	var exitStatus = sm.getVar('var://service/error-code');	
	ctx.setVariable('exitStatus',exitStatus);
	ctx.setVariable('exitDestination','TRSEVNT.EFC.SEND');
	ctx.setVariable('Exitdescription',ErrorTxt)
	}
	}
	});