var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("crewAssignment") || session.createContext("crewAssignment");

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		ctx.setVariable("incomingdata", incomingdata);
		var workTypeID = incomingdata.data[0].workTypeID;
		var workStatus = incomingdata.data[0].status;
		if (workTypeID != null && workTypeID != undefined && workTypeID != '') {
			if (workStatus != null && workStatus != undefined && workStatus != '') {
				
				if (incomingdata.data[0].crew != undefined && incomingdata.data[0].crew != null && incomingdata.data[0].crew != '') {
					if (incomingdata.data[0].crew.type != undefined && incomingdata.data[0].crew.type != null && incomingdata.data[0].crew.type != '') {
						var crewStatus = incomingdata.data[0].crew.type;
						var lookupMessage = {
							"lookupReq": {
								"type": [
									{
										"name": "workType.workflows",
										"id": workTypeID,
										"status": workStatus
									},
									{
										"name": "crewTypes",
										"status": crewStatus
									}
								]
							}
						};
						var lookupService = {
							target: session.parameters.lookupURL + '/crewTypes/' + crewStatus + '/workType.workflows/' + workTypeID + '/' + workStatus,
							method: 'POST',
							contentType: 'application/json',
							data: lookupMessage
						};
						urlopen.open(lookupService, function(error, response) {
							if (error) {
								logger.error("Trsevent_EFCCrew_001 : urlopen connect error from CrewType joblookupService" + JSON.stringify(error));
								session.reject("urlopen connect error from CrewType LookupServiceResponse" + JSON.stringify(error));
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsJSON(function(error, responseData) {
										if (error) {
											logger.error("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
											session.reject("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
										} else {
											ctx.setVariable("res", responseData);
											if (responseData.lookupRep.type[1].result == 0) {
												var crewTypeLabel = responseData.lookupRep.type[1].label;
												ctx.setVariable("crewTypeLabel", crewTypeLabel);
											}
											if (responseData.lookupRep.type[0].result == 0) {
												var workTypeLabel = responseData.lookupRep.type[0].label;
												ctx.setVariable("workTypeLabel", workTypeLabel);
											}
										}
									})
								}
								else {
									logger.error("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
									session.reject("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
								}

							}
						})
					} else {
						LookUpCall(workTypeID,workStatus)
					}
				}
				else {
					LookUpCall(workTypeID,workStatus)
				}
				
				function LookUpCall(workTypeID,workStatus){
					var lookupMessage = {
						"lookupReq": {
							"type": [
								{
									"name": "workType.workflows",
									"id": workTypeID,
									"status": workStatus
								}
							]
						}
					};
					var lookupService = {
						target: session.parameters.lookupURL + '/workType.workflows/' + workTypeID + '/' + workStatus,
						method: 'POST',
						contentType: 'application/json',
						data: lookupMessage
					};
					urlopen.open(lookupService, function(error, response) {
						if (error) {
							logger.error("Trsevent_EFCCrew_001 : urlopen connect error from CrewType joblookupService" + JSON.stringify(error));
							session.reject("urlopen connect error from CrewType LookupServiceResponse" + JSON.stringify(error));
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										logger.error("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
										session.reject("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
									} else {
										ctx.setVariable("res", responseData);
										if (responseData.lookupRep.type[0].result == 0) {
											var workTypeLabel = responseData.lookupRep.type[0].label;
											ctx.setVariable("workTypeLabel", workTypeLabel);
										}
									}
								})
							}
							else {
								logger.error("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
								session.reject("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
							}

						}
					})
				}
			}
		}
	}
})
