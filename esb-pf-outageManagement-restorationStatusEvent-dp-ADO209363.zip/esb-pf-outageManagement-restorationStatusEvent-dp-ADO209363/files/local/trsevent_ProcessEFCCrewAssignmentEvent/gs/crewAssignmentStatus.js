var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("crewAssignment") || session.createContext("crewAssignment");

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {

		var dateTime = new Date();
		var status = incomingdata.data[0].status;
		var transitionHistory = incomingdata.data[0].transitionHistory;
		var transitionedAt;
		if (transitionHistory === null || transitionHistory === undefined || transitionHistory === '') {
		} else {
			for (var a = 0; a < transitionHistory.length; a++) {
				if (status == transitionHistory[a].stateID) {
					transitionedAt = transitionHistory[a].transitionedAt;
				}
			}
		}
		var payload = {
			"eventType": "CrewStatus",
			"eventTime": dateTime.toISOString(),
			"data": {
				//"jobId": incomingdata.data[0].job.id,
				//"origEventTime": incomingdata.data[0].updatedAt,
				"crews": [
					{
						"crewAssignmentId": incomingdata.data[0].displayID,
						"crewStatus": ctx.getVariable("workTypeLabel"),
						"crewStatusDate": transitionedAt,
						"crewAssignmentInternalId": incomingdata.data[0].id,
					}
				]
			}
		};

		if (incomingdata.data[0].job != undefined && incomingdata.data[0].job != null && incomingdata.data[0].job != '') {
			if (incomingdata.data[0].job.id != undefined && incomingdata.data[0].job.id != null && incomingdata.data[0].job.id != '') {
				payload.data.jobId = incomingdata.data[0].job.id
			} 
		} else if (incomingdata.data[0].jobID != undefined && incomingdata.data[0].jobID != null && incomingdata.data[0].jobID != '') {
			payload.data.jobId = incomingdata.data[0].jobID
		}
		if (incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
			payload.data.origEventTime = incomingdata.eventTime
		}
		if (incomingdata.data[0].crew != undefined && incomingdata.data[0].crew != null && incomingdata.data[0].crew != '') {
			if (incomingdata.data[0].crew.externalID != undefined && incomingdata.data[0].crew.externalID != null && incomingdata.data[0].crew.externalID != '') {
				payload.data.crews[0].crewId = incomingdata.data[0].crew.externalID;
			}
		}
		if (incomingdata.data[0].crew != undefined && incomingdata.data[0].crew != null && incomingdata.data[0].crew != '') {
			if (incomingdata.data[0].crew.externalID != undefined && incomingdata.data[0].crew.externalID != null && incomingdata.data[0].crew.externalID != '') {
				payload.data.crews[0].crewType = ctx.getVariable("crewTypeLabel");
			}
		}
		if (incomingdata.data[0].eta != undefined && incomingdata.data[0].eta != null && incomingdata.data[0].eta != '') {
			payload.data.crews[0].eta = incomingdata.data[0].eta;
		}
		if (incomingdata.data[0].customFieldValuesExt != undefined && incomingdata.data[0].customFieldValuesExt != null && incomingdata.data[0].customFieldValuesExt != '') {
			if (incomingdata.data[0].customFieldValuesExt.Disposition != undefined && incomingdata.data[0].customFieldValuesExt.Disposition != null && incomingdata.data[0].customFieldValuesExt.Disposition != '') {
				payload.data.crews[0].disposition = incomingdata.data[0].customFieldValuesExt.Disposition;
			}
		}

		session.output.write(payload);
		ctx.setVariable("payload", payload);
		var StandaloneMQurl = session.parameters.MQUrl;

		var pushingToQueue = {
			target: StandaloneMQurl,
			data: payload
		};

		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.error("error while publishing message to queue is " + error);
				//session.reject(" error while publishing message to queue is " + error);
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "Trsevent_EFCCrew_002 : urlopen connect error while keeping the payload to TRSEVNT.EFC.SEND Queue " + error;
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var mqrc = response.statusCode;

				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							session.reject("error while publishing message to queue is " + error);
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {

					logger.error("response code for urlopen.open error [MQRC=" + mqrc + "]");
					//session.reject(" response code for urlopen.open error [MQRC=" + mqrc + "]");
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = "Trsevent_EFCCrew_002 : urlopen connect error while keeping the payload to TRSEVNT.EFC.SEND Queue " + error;
					ctx.setVariable("ErrorTxt", ErrorTxt);

				}
			}
		})
	}
})
