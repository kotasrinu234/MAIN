var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name('ils') || session.createContext('ils');
var ctx = session.name("crewAssignment") || session.createContext("crewAssignment");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Trsevent_CRMCrew_002: Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		ilsctx.setVariable('exitStatus', '500');
		var dateTime = new Date();
		var status = incomingdata.data[0].status;
		var transitionHistory = incomingdata.data[0].transitionHistory;
		var transitionedAt;
		if (transitionHistory === null || transitionHistory === undefined || transitionHistory === '') {
		} else {
			for (var a = 0; a < transitionHistory.length; a++) {
				if (status == transitionHistory[a].stateID) {
					transitionedAt = transitionHistory[a].transitionedAt;
				}
			}
		}
		var payload = {
			"JobStatusDetails": {
				"eventType": "CrewStatus",
				"eventTime": dateTime.toISOString(),
				//"origEventTime": incomingdata.data[0].updatedAt,
				//"id": incomingdata.data[0].job.id,
				//"jobId": incomingdata.data[0].job.displayID,
				"CrewAssignmentStatus": [
					{}
				]
			}
		};
		if (incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
			payload.JobStatusDetails.origEventTime = incomingdata.eventTime
		}
		if (incomingdata.data[0].job != undefined && incomingdata.data[0].job != null && incomingdata.data[0].job != '') {
			if (incomingdata.data[0].job.id != undefined && incomingdata.data[0].job.id != null && incomingdata.data[0].job.id != '') {
				payload.JobStatusDetails.id = incomingdata.data[0].job.id
			}
		} else if (incomingdata.data[0].jobID != undefined && incomingdata.data[0].jobID != null && incomingdata.data[0].jobID != '') {
			payload.JobStatusDetails.id = incomingdata.data[0].jobID
		}
		if (incomingdata.data[0].job != undefined && incomingdata.data[0].job != null && incomingdata.data[0].job != '') {
			if (incomingdata.data[0].job.displayID != undefined && incomingdata.data[0].job.displayID != null && incomingdata.data[0].job.displayID != '') {
				payload.JobStatusDetails.jobId = incomingdata.data[0].job.displayID
			}
		}
		if (incomingdata.data[0].crew != undefined && incomingdata.data[0].crew != null && incomingdata.data[0].crew != '') {
			if (incomingdata.data[0].crew.externalID != undefined && incomingdata.data[0].crew.externalID != null && incomingdata.data[0].crew.externalID != '') {
				payload.JobStatusDetails.CrewAssignmentStatus[0].crewId = incomingdata.data[0].crew.externalID;
			}
		}
		if (ctx.getVariable("workTypeLabel") != undefined && ctx.getVariable("workTypeLabel") != null && ctx.getVariable("workTypeLabel") != '') {
			payload.JobStatusDetails.CrewAssignmentStatus[0].crewStatus = ctx.getVariable("workTypeLabel");
		}
		if (transitionedAt != undefined && transitionedAt != null && transitionedAt != '') {
			payload.JobStatusDetails.CrewAssignmentStatus[0].crewStatusDate = transitionedAt;
		}
		if (incomingdata.data[0].eta != undefined && incomingdata.data[0].eta != null && incomingdata.data[0].eta != '') {
			payload.JobStatusDetails.CrewAssignmentStatus[0].eta = incomingdata.data[0].eta;
		}
		if (incomingdata.data[0].customFieldValuesExt != undefined && incomingdata.data[0].customFieldValuesExt != null && incomingdata.data[0].customFieldValuesExt != '') {
			if (incomingdata.data[0].customFieldValuesExt.Disposition != undefined && incomingdata.data[0].customFieldValuesExt.Disposition != null && incomingdata.data[0].customFieldValuesExt.Disposition != '') {
				payload.JobStatusDetails.CrewAssignmentStatus[0].disposition = incomingdata.data[0].customFieldValuesExt.Disposition;
			}
		}
		ctx.setVariable("Payload", payload)
		var CrewStatusURL = session.parameters.CrewStatusPOUrl;
		ilsctx.setVariable('exitDestination', CrewStatusURL);
		session.output.write(payload);
		var Options = {
			target: CrewStatusURL,
			sslClientProfile: 'trsevent_SendEventToCRM_SSL_ClientProfile',
			method: 'POST',
			contentType: 'application/json',
			data: payload
		};
		urlopen.open(Options, function(error, response) {
			if (error) {
				logger.error("Trsevent_CRMCrew_002:urlopen connect error " + JSON.stringify(error));
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "Trsevent_CRMCrew_002 : urlopen connect error for CRM call " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ilsctx.setVariable("Exitdescription", ErrorTxt);
				ilsctx.setVariable('exitStatus', '500');
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200 || responseStatusCode == 201 || responseStatusCode == 202) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							ilsctx.setVariable('exitStatus', '500');
							ilsctx.setVariable("Exitdescription", "Failure in getting response");
							logger.error("Trsevent_CRMCrew_002: Failure in getting response " + JSON.stringify(error));
							session.reject("Failure in getting response " + JSON.stringify(error));
						} else {
							hm.response.statusCode = '200 OK';
							ilsctx.setVariable('exitStatus', '0');
							logger.debug("response received :" + JSON.stringify(responseData));
							ctx.setVariable("Response", responseData)
						}
					});
				} else {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							ilsctx.setVariable("Exitdescription", "Trsevent_CRMCrew_002 : urlopen connect error for CRM call");
							ilsctx.setVariable('exitStatus', "responseStatusCode");
							logger.error("Trsevent_CRMCrew_002: failure in reading response  " + JSON.stringify(error));
							session.reject("failure in reading response");

						} else {
							hm.current.statusCode = responseStatusCode;
							ilsctx.setVariable("Exitdescription", "Trsevent_CRMCrew_002 : urlopen connect error for CRM call");
							ilsctx.setVariable('exitStatus', "responseStatusCode");
							logger.error("Trsevent_CRMCrew_002: Error returned from CRM call " + ": with statusCode " + responseStatusCode + " " + responseData);
							session.reject("Error returned from CRM call " + ": with statusCode " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
})
