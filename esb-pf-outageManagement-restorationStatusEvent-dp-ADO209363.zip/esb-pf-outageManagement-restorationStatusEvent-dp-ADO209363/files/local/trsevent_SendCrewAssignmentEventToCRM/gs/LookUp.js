var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("crewAssignment") || session.createContext("crewAssignment");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		var workTypeID = incomingdata.data[0].workTypeID;
		var workStatus = incomingdata.data[0].status;

		if (workTypeID != null && workTypeID != undefined && workTypeID != '') {
			if (workStatus != null && workStatus != undefined && workStatus != '') {
				var lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "workType.workflows",
								"id": workTypeID,
								"status": workStatus
							}
						]
					}
				};
				var lookupService = {
					target: session.parameters.lookupURL + '/workType.workflows/' + workTypeID + '/' + workStatus,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				urlopen.open(lookupService, function(error, response) {
					if (error) {
						logger.error("Trsevent_CRMCrew_001 : urlopen connect error from CrewType joblookupService" + JSON.stringify(error));
						session.reject("urlopen connect error from CrewType LookupServiceResponse" + JSON.stringify(error));
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									logger.error("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
									session.reject("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
								} else {
									ctx.setVariable("res", responseData);
									if (responseData.lookupRep.type[0].result == 0) {
										var workTypeLabel = responseData.lookupRep.type[0].label;
										ctx.setVariable("workTypeLabel", workTypeLabel);
									}
								}
							})
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									logger.error("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
									session.reject("Failure in reading the message for Crewtype LookupServiceResponse " + JSON.stringify(error));
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("Error occured in reading the message for Crewtype LookupServiceResponse " + responseStatusCode + ": " + responseData);
									session.reject("Error occured in reading the message for Crewtype LookupServiceResponse " + responseStatusCode + ": " + responseData);
								}
							});
						}
					}
				})
			}
		}

	}
})