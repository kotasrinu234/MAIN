var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ils') || session.createContext('ils');
var messageType = session.parameters.messageType;
ctx.setVariable('messageType', messageType);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//var incomingdata =incomingdata;
		var correlationID;
		if (incomingdata.eventTime != undefined) { correlationID = incomingdata.data[0].displayID + ':' + incomingdata.eventTime }
		else { correlationID = incomingdata.data[0].displayID }
		var crewAssignmentID = incomingdata.data[0].id;
		var crewAssignmentDisplayID = incomingdata.data[0].displayID;
		var sourceEventTimestamp = incomingdata.eventTime;
		var Entrydescription = session.parameters.trsevent_SendCrewAssignmentEventToCRMIlsEntrydescription;
		var Exitdescription = session.parameters.trsevent_SendCrewAssignmentEventToCRMIlsExitdescription;
		var urlIn = sm.getVar('var://service/URL-in');
		var urlincontains = urlIn.includes('trsevent_SendCrewAssignmentEventToCRM_MQ_FSH_Retry');
		if (urlincontains == true) {
			ctx.setVariable('retryCount', -1);
		} else {
			ctx.setVariable('retryCount', 1);
		}
		ctx.setVariable('correlationID', correlationID);
		if (crewAssignmentID != undefined) { ctx.setVariable('crewAssignmentID', crewAssignmentID); }
		if (crewAssignmentDisplayID != undefined) { ctx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID); }
		if (!(incomingdata.data[0].job === undefined)) {
			if (!(incomingdata.data[0].job.id === undefined)) {
				ctx.setVariable('jobID', incomingdata.data[0].job.id);
			}
			if (!(incomingdata.data[0].job.displayID === undefined)) {
				ctx.setVariable('jobDisplayID', incomingdata.data[0].job.displayID);
			}

		}
		if (sourceEventTimestamp != undefined) { ctx.setVariable('sourceEventTimestamp', sourceEventTimestamp); }
		if (Entrydescription != undefined) { ctx.setVariable('Entrydescription', Entrydescription); }
		if (Exitdescription != undefined) { ctx.setVariable('Exitdescription', Exitdescription); }
	}
});
