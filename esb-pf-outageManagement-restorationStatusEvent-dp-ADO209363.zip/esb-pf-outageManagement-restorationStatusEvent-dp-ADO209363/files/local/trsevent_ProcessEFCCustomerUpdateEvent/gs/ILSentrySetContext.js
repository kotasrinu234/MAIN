var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var messageType = session.parameters.messageType;
var description = session.parameters.Entrydescription;
 
ctx.setVariable('messageType', messageType);
ctx.setVariable('Entrydescription', description);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
		
		var correlationID;
		var PremiseID;
		var meterId;
		var status;
		var reason;
		var sourceEventTimestamp;
        
		if (incomingdata.CustomerStatusUpdate.msgId === undefined || incomingdata.CustomerStatusUpdate.msgId === null || incomingdata.CustomerStatusUpdate.msgId === '') {
		var uuid = uuidv4();
			ctx.setVariable("correlationID", uuid)
			ctx.setVariable("MSGID", uuid);
		} else {
			correlationID = incomingdata.CustomerStatusUpdate.msgId
			ctx.setVariable("correlationID", correlationID);
		}
	if (incomingdata.CustomerStatusUpdate.premiseId === undefined || incomingdata.CustomerStatusUpdate.premiseId === null || incomingdata.CustomerStatusUpdate.premiseId === '') {
		ctx.setVariable("PremiseID", " ");
		} else {
			PremiseID = incomingdata.CustomerStatusUpdate.premiseId
		    ctx.setVariable("PremiseID", PremiseID);
		}
		if (incomingdata.CustomerStatusUpdate.meterId === undefined || incomingdata.CustomerStatusUpdate.meterId === null || incomingdata.CustomerStatusUpdate.meterId === '') {
		ctx.setVariable("correlationID", " ");
		} else {
			meterId = incomingdata.CustomerStatusUpdate.meterId
			ctx.setVariable("meterId", meterId);
		}
		if (incomingdata.CustomerStatusUpdate.status === undefined || incomingdata.CustomerStatusUpdate.status === null || incomingdata.CustomerStatusUpdate.status === '') {
		ctx.setVariable("updateStatus", " ");
		} else {
			status = incomingdata.CustomerStatusUpdate.status
			ctx.setVariable("status", status);
		}
		if (incomingdata.CustomerStatusUpdate.reason === undefined || incomingdata.CustomerStatusUpdate.reason === null || incomingdata.CustomerStatusUpdate.reason === '') {
		ctx.setVariable("reason", " ");
		} else {
			reason = incomingdata.CustomerStatusUpdate.reason
			ctx.setVariable("reason", reason);
		}
		if (incomingdata.CustomerStatusUpdate.jobTimeStamp === undefined || incomingdata.CustomerStatusUpdate.jobTimeStamp === null || incomingdata.CustomerStatusUpdate.jobTimeStamp === '') {
		ctx.setVariable("sourceEventTimestamp", " ");
		} else {
			sourceEventTimestamp = incomingdata.CustomerStatusUpdate.jobTimeStamp
			ctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		
	}
});
