var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("trsevent") || session.createContext("trsevent");
var ILSctx = session.name('ILS') || session.createContext('ILS');

var Exitdescription = session.parameters.Exitdescription

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data " + readAsJSONError);
		session.reject("Error in reading incoming data " + readAsJSONError);
	} else {

		var dateTime = new Date();
		var payload = {
			"eventType": "CustomerStatus",
			"eventTime": dateTime.toISOString(),
			"data": {
			}
		}

		if (incomingdata.CustomerStatusUpdate.jobTimeStamp === undefined || incomingdata.CustomerStatusUpdate.jobTimeStamp === null || incomingdata.CustomerStatusUpdate.jobTimeStamp === '') {
		} else {
			payload.data.origEventTime = incomingdata.CustomerStatusUpdate.jobTimeStamp
		}

		if (incomingdata.CustomerStatusUpdate.msgId === undefined || incomingdata.CustomerStatusUpdate.msgId === null || incomingdata.CustomerStatusUpdate.msgId === '') {
		   var MSGID = ILSctx.getVariable("MSGID");
			payload.data.msgId = MSGID
		} else {
			payload.data.msgId = incomingdata.CustomerStatusUpdate.msgId
		}
		if (incomingdata.CustomerStatusUpdate.premiseId === undefined || incomingdata.CustomerStatusUpdate.premiseId === null || incomingdata.CustomerStatusUpdate.premiseId === '') {
		} else {
			var PremiseID = incomingdata.CustomerStatusUpdate.premiseId
			var StrPremiseID = PremiseID.toString()
			payload.data.premiseId = StrPremiseID
		}
		if (incomingdata.CustomerStatusUpdate.meterId === undefined || incomingdata.CustomerStatusUpdate.meterId === null || incomingdata.CustomerStatusUpdate.meterId === '') {
		} else {
			var MeterID = incomingdata.CustomerStatusUpdate.meterId
			var StrMetrID = MeterID.toString()
			payload.data.meterId = StrMetrID
		}
		if (incomingdata.CustomerStatusUpdate.status === undefined || incomingdata.CustomerStatusUpdate.status === null || incomingdata.CustomerStatusUpdate.status === '') {
		} else {
			payload.data.status = incomingdata.CustomerStatusUpdate.status
		}
		if (incomingdata.CustomerStatusUpdate.reason === undefined || incomingdata.CustomerStatusUpdate.reason === null || incomingdata.CustomerStatusUpdate.reason === '') {
		} else {
			payload.data.reason = incomingdata.CustomerStatusUpdate.reason
		}
		if (incomingdata.CustomerStatusUpdate.jobTimeStamp === undefined || incomingdata.CustomerStatusUpdate.jobTimeStamp === null || incomingdata.CustomerStatusUpdate.jobTimeStamp === '') {
		} else {
			payload.data.jobTimeStamp = incomingdata.CustomerStatusUpdate.jobTimeStamp
		}
		if (incomingdata.CustomerStatusUpdate.offedTimeStamp === undefined || incomingdata.CustomerStatusUpdate.offedTimeStamp === null || incomingdata.CustomerStatusUpdate.offedTimeStamp === '') {
		} else {
			payload.data.offedTimeStamp = incomingdata.CustomerStatusUpdate.offedTimeStamp
		}


		ctx.setVariable("payload", payload);
		var StandaloneMQurl = session.parameters.CustomerQueueURL;
		ILSctx.setVariable("ExitDestination", StandaloneMQurl);
		var pushingToQueue = {
			target: StandaloneMQurl,
			data: payload
		};

		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.error("error while publishing message to queue is " + error);
				//session.reject(" error while publishing message to queue is " + error);
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "Trsevent_EFCCust_001 : urlopen connect error while keeping the payload to TRSEVNT.EFC.SEND Queue " + error;
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ILSctx.setVariable("exitStatus", "500")

			} else {
				var mqrc = response.statusCode;


				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500

							session.reject("error while publishing message to queue is " + error);
						} else {

							ILSctx.setVariable("Exitdescription", Exitdescription)
							ILSctx.setVariable("exitStatus", "0")
							logger.debug("MQResponsecode " + mqrc);

						}
					});
				} else {

					logger.error("response code for urlopen.open error [MQRC=" + mqrc + "]");
					//session.reject(" response code for urlopen.open error [MQRC=" + mqrc + "]");
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = "Trsevent_EFCCust_001 : urlopen connect error while keeping the payload to TRSEVNT.EFC.SEND Queue " + error;
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ILSctx.setVariable("exitStatus", "500")
					Exitdescription = "Trsevent_EFCCust_001 : urlopen connect error while keeping the payload to TRSEVNT.EFC.SEND Queue  [MQRC=" + mqrc + "]"
					ILSctx.setVariable("Exitdescription", Exitdescription)

				}
			}
		})
	}
});
