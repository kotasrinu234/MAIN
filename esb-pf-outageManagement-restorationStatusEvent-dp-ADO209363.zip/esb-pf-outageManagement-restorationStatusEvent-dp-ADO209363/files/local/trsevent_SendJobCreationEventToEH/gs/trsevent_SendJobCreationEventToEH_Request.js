var ctx = session.name("trsevent") || session.createContext("trsevent");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ms = require('multistep');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, json) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var NullCheck;
		var dateTime = new Date();
		var CorrelationPayload = {
			"dataMappingRequirement": [
				{
					"mapping": {
						"sourceEventType": "JobCreationEvent",
						"sourceField": "jobID",
						"destinationEventType": "TroubleReportEvent",
						"destinationField": "jobID"
					}
				}
			], "payload": {

			},
			"sendTimeStamp": dateTime.toISOString(),
		}
		var destQueueName = session.parameters.destQueueName
		var eventType = session.parameters.eventType
		var eventTypeCorrelation = session.parameters.eventTypeCorrelation
		var eventTypeToRelease = session.parameters.eventTypeToRelease
		var expiry = session.parameters.expiry
		var serviceName = session.parameters.serviceName
		var waitTime = session.parameters.waitTime
		var QueueConnectionString = session.parameters.QueueConnectionString



		if (!(json.messageID === undefined || json.messageID === null || json.messageID === '')) {
			CorrelationPayload.messageID = json.messageID
			ILSctx.setVariable('CorrelationID', json.messageID)
		}
		if (!(serviceName === undefined || serviceName === null || serviceName === '')) {
			CorrelationPayload.serviceName = serviceName
		}
		if (!(expiry === undefined || expiry === null || expiry === '')) {
			CorrelationPayload.expiry = expiry
		}
		if (!(json.eventTime === undefined || json.eventTime === null || json.eventTime === '')) {
			CorrelationPayload.eventTimeStamp = json.eventTime
			ILSctx.setVariable('eventTimeStamp', json.eventTime)

		}
		if (!(waitTime === undefined || waitTime === null || waitTime === '')) {
			CorrelationPayload.waitTime = waitTime
		}
		if (!(eventType === undefined || eventType === null || eventType === '')) {
			CorrelationPayload.eventType = eventType
		}
		if (!(json.data[0].displayID === undefined || json.data[0].displayID === null || json.data[0].displayID === '')) {
			CorrelationPayload.eventKey = json.data[0].displayID
			ILSctx.setVariable('displayID', json.data[0].displayID)
		} else {
			NullCheck = 'yes'
		}
		if (!(destQueueName === undefined || destQueueName === null || destQueueName === '')) {
			CorrelationPayload.destQueueName = destQueueName
		}
		if (!(eventTypeCorrelation === undefined || eventTypeCorrelation === null || eventTypeCorrelation === '')) {
			CorrelationPayload.eventTypeCorrelation = pushToArray(eventTypeCorrelation)
		}
		if (!(eventTypeToRelease === undefined || eventTypeToRelease === null || eventTypeToRelease === '')) {
			CorrelationPayload.eventTypeToRelease = pushToArray(eventTypeToRelease)
		}
		if (!(json.data[0].jobID === undefined || json.data[0].jobID === null || json.data[0].jobID === '')) {
			CorrelationPayload.payload.jobID = json.data[0].jobID
			ILSctx.setVariable('jobID', json.data[0].jobID)
		} else {
			var NullCheckforjobID = 'yes'
		}

		if (NullCheckforjobID === 'yes') {
			var errorinfo = 'trsevent_JobcreationEH_001: Rejected by Null Check for jobID and input json is :: ' + JSON.stringify(json)
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo)
			session.output.write(CorrelationPayload)
			logger.error(errorinfo)
			session.reject(errorinfo)
		}
		else if (NullCheck === 'yes') {
			var errorinfo = 'trsevent_JobcreationEH_002: Rejected by Null Check for displayID and input json is :: ' + JSON.stringify(json)
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo)
			session.output.write(CorrelationPayload)
			logger.error(errorinfo)
			session.reject(errorinfo)

		} else {
			session.output.write(CorrelationPayload)
			QueueCall(QueueConnectionString, CorrelationPayload)
		}
	}
})

function QueueCall(StandaloneMQurl, payload) {
	var pushingToQueue = {
		target: StandaloneMQurl,
		data: payload
	};
	var info = " TargetURL :" + pushingToQueue.target + "; Method :" + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";
	ILSctx.setVariable('ExitStatus', '0');
	ILSctx.setVariable('ExitDestination', StandaloneMQurl);
	ILSctx.setVariable('ExitDescription', session.parameters.SJEHExitDescription);

	try {
		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error 'CORRELATION.REQ Queue', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				ILSctx.setVariable('ExitDestination', StandaloneMQurl);
				var ctx = session.name("trsevent") || session.createContext("trsevent");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", errorinfo);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "failure in reading response 'CORRELATION.REQ Queue', details are : " + info + "; error info :" + readError
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							hm.response.statusCode = 500
							logger.error(errorinfo);
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var errorinfo = "error response 'CORRELATION.REQ Queue', details are : " + info + "; response  info :" + JSON.stringify(response)
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					ILSctx.setVariable('ExitDestination', StandaloneMQurl);
					var ctx = session.name("trsevent") || session.createContext("trsevent");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(" Error received from the response of Queue [MQRC=" + mqrc + "]" + errorinfo);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("ErrorTxt", errorinfo);
				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error 'CORRELATION.REQ Queue', details are : " + info + "; error info :" + err
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo)
		ILSctx.setVariable('ExitDestination', StandaloneMQurl);
		logger.error(errorinfo);
		ctx.setVariable("retry", 'yes');
		ctx.setVariable("ErrorTxt", errorinfo);
	}
}

function pushToArray(parameter) {
	var customArray = [];
	var splitParameter = parameter.split(',');
	for (var i = 0; i < splitParameter.length; i++) {
		customArray.push(splitParameter[i])
	}
	return customArray;
}
