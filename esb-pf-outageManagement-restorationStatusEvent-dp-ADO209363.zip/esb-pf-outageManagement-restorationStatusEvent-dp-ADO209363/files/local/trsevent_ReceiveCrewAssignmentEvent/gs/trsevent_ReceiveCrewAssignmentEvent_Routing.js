var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		var payload = JSON.parse(jsonData);
		if (!(jsonData.eventTime == undefined || jsonData.eventTime == null || jsonData.eventTime == '')) {

		} else {
			var dateTime = new Date();
			var currentTime = dateTime.toISOString();
			payload.eventTime = currentTime;
		}
		//pushing to queue start

		var StandaloneMQurl = session.parameters.ReceiveCrewAssignmentEvent_StandaloneURL;
		var publishuri = {
			target: StandaloneMQurl,
			data: payload
		};
		urlopen.open(publishuri, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error("  error while keeping message to queue is " + error);
				var ErrorTxt = " error while keeping message to queue is " + error;
				session.reject("error while keeping message to queue is " + error);
			} else {
				var mqrc = response.statusCode;

				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 403
							var ErrorTxt = "error while keeping message to queue is " + readError;
							session.reject("error while keeping message to queue is " + readError);
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error("  response code is urlopen.open error [MQRC=" + mqrc + "]");
					var ErrorTxt = "response code is urlopen.open error [MQRC=" + mqrc + "]";
					session.reject(" response code is urlopen.open error [MQRC=" + mqrc + "]");

				}
			}
		});
		//pushing to queue end

	}
});