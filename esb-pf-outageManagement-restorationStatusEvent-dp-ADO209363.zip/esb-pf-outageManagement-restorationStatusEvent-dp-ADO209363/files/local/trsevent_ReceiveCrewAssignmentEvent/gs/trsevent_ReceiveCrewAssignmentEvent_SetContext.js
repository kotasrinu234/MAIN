var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var ctx = session.name('ils')|| session.createContext('ils');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
		var incomingdata =incomingdata;
		var correlationID;
		if(incomingdata.eventTime != undefined)
		{correlationID= incomingdata.data[0].displayID+':'+incomingdata.eventTime}
		else{correlationID= incomingdata.data[0].displayID}
		
		var crewAssignmentID= incomingdata.data[0].id;
		var crewAssignmentDisplayID = incomingdata.data[0].displayID
		var jobID
		var jobDisplayID
		if( incomingdata.data[0].job != undefined){jobID = incomingdata.data[0].job.id
		jobDisplayID = incomingdata.data[0].job.displayID
		}
		var sourceEventTimestamp = incomingdata.eventTime
		
	    var sourceUrl = sm.getVar('var://service/URL-in');
		var entrydescription = session.parameters.ReceiveCrewAssignmentEvent_EntryDescription;
		var exitdescription = session.parameters.ReceiveCrewAssignmentEvent_ExitDescription;
		ctx.setVariable('messageType',session.parameters.ReceiveCrewAssignmentEvent_messageType);
		ctx.setVariable('correlationID',correlationID);
	 ctx.setVariable('entrydescription',session.parameters.ReceiveCrewAssignmentEvent_EntryDescription);
ctx.setVariable('exitdescription',session.parameters.ReceiveCrewAssignmentEvent_ExitDescription);
if(crewAssignmentID != undefined){ctx.setVariable('crewAssignmentID',crewAssignmentID);}
if(crewAssignmentDisplayID != undefined){ctx.setVariable('crewAssignmentDisplayID',crewAssignmentDisplayID);}
if(jobID  != undefined){ctx.setVariable('jobID',jobID);}		
if(jobDisplayID  != undefined){		ctx.setVariable('jobDisplayID',jobDisplayID);}
if(sourceEventTimestamp  != undefined){	ctx.setVariable('sourceEventTimestamp',sourceEventTimestamp);}
if(sourceUrl != undefined){ctx.setVariable('sourceUrl',sourceUrl);}

	}
	});