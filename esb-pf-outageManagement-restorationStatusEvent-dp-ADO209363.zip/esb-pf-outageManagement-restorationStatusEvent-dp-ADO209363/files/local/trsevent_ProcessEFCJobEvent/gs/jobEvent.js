var urlopen = require('urlopen');
var fs = require('fs');
var ms = require('multistep');
var hm = require('header-metadata');
var sm = require('service-metadata');
var callMQURL = require('./callMQURL.js');
var PrEFCJobReqQ = session.parameters.PrEFCJobReqQ;
var JobtoAzure_QM = session.parameters.trsevent_PrEFC_JobtoAzure_QM;
var chunk = Number(session.parameters.chunk);
var trigValue = "";
var urlopenurl = 'dpmq://' + JobtoAzure_QM + '/?RequestQueue=' + PrEFCJobReqQ;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("jobEvent") || session.createContext("jobEvent");
var events = session.parameters.events;
var dateTime = new Date();
var outageIndicator = ctx.getVariable("jobOutageTypes_lookup")[0].label;
if (outageIndicator == 'UNPLANNED_OUTAGE') {
	var indicator = true;
}
else {
	var indicator = false;
}

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		var inReq = incomingdata.data[0];
		ctx.setVariable("jsonPayload", incomingdata);
		var outageSteps = inReq.outageSteps;
		var aorID = incomingdata.data[0].aorID;
		var region = inReq.regionName;
		if (aorID != undefined && aorID != null && aorID != '') {
			var aors = ctx.getVariable('aors_lookup')[0].label;
		}
		var payload = {};
		payload.eventType = "JobStatusDetail";
		payload.eventTime = dateTime.toISOString();
		payload.data = {};
		var data = payload.data;

		if (inReq.id != undefined && inReq.id != null && inReq.id != '') {
			data.jobId = inReq.id;
		} else throw Error('jobId is a mandatory field');
		var urlIn = sm.getVar('var://service/URL-in');
		if (urlIn.includes("TRSEVNT.EFC.JOB.UPDATE.REQUEST")) {
			if (incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
				data.origEventTime = incomingdata.eventTime;
			}
		} else if (urlIn.includes("TRSEVNT.EFC.JOB.CREATE.REQUEST")) {

			if (incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
				data.origEventTime = incomingdata.eventTime;
			} else {
				data.origEventTime = incomingdata.data[0].createdAt;
			}
		}
		if (inReq.displayID != undefined && inReq.displayID != null && inReq.displayID != '') {
			data.jobDisplayId = inReq.displayID;
		}
		//data.jobStatus= ctx.getVariable("jobTypeLabel");
		data.jobStatus = ctx.getVariable("jobTypeWorkFlow_lookup")[0].label;
		if (inReq.updatedAt != undefined && inReq.updatedAt != null && inReq.updatedAt != '') {
			data.jobUpdateTime = inReq.updatedAt;
		} else throw Error('updatedAt is a mandatory field');

		if (inReq.createdAt != undefined && inReq.createdAt != null && inReq.createdAt != '') {
			data.jobCreateTime = inReq.createdAt;
		}

		var customFieldValuesExt = inReq.customFieldValuesExt
		if (customFieldValuesExt != undefined && customFieldValuesExt.isAutoClosed != undefined && customFieldValuesExt.isAutoClosed != null) {

			data.autoCloseFlag = inReq.customFieldValuesExt.isAutoClosed;
		}
		data.jobType = ctx.getVariable("jobTypes_lookup")[0].label;

		if (inReq.networkModelType != undefined) {
			data.extent = ctx.getVariable("networkModelTypeLabels_lookup")[0].label;
		}
		if (inReq.deviceInfo != undefined && inReq.deviceInfo != null && inReq.deviceInfo != '' && inReq.deviceInfo.name != undefined && inReq.deviceInfo.name != null && inReq.deviceInfo.name != '') {
			data.deviceName = inReq.deviceInfo.name;
		}
		if (inReq.nominalFeeder != undefined && inReq.nominalFeeder != null && inReq.nominalFeeder != '') {
			data.circuit = inReq.nominalFeeder;
		}
		if (inReq.feederName != undefined && inReq.feederName != null && inReq.feederName != '') {
			data.feeder = inReq.feederName;
		}
		if (indicator != undefined && indicator != null) {
			data.outageIndicator = indicator;
		}
		if (inReq.createdOperationModeID != undefined && inReq.createdOperationModeID != null && inReq.createdOperationModeID != '') {
			data.operationMode = ctx.getVariable("operationModes_lookup")[0].label;
		}
		if (inReq.customFieldValuesExt != undefined && inReq.customFieldValuesExt != null && inReq.customFieldValuesExt != '' && inReq.customFieldValuesExt.cause != undefined && inReq.customFieldValuesExt.cause != null && inReq.customFieldValuesExt.cause != '') {
			data.causeCode = inReq.customFieldValuesExt.cause;
		}
		if (inReq.publishedEtr != undefined && inReq.publishedEtr != null && inReq.publishedEtr != '' && inReq.publishedEtr.value != undefined && inReq.publishedEtr.value != null && inReq.publishedEtr.value != '') {
			data.ert = inReq.publishedEtr.value;
		}

		if (inReq.etrExpirationStatus != undefined && inReq.etrExpirationStatus != null && inReq.etrExpirationStatus != '') {
			data.businessException = ctx.getVariable("etrExpirationStatuses_lookup")[0].label;
		}
		if (inReq.etrStatus != undefined && inReq.etrStatus != null && inReq.etrStatus != '') {
			data.estType = inReq.etrStatus;
		}
		if (inReq.totalAffected != undefined && inReq.totalAffected != null) {
			data.customersAffected = inReq.totalAffected;
		}
		if (inReq.currentAffected != undefined && inReq.currentAffected != null) {
			data.customersStillOut = inReq.currentAffected;
		}
		if (region != undefined && region != null && region != '') {
			data.region = region.substring(0, 2);
		}
		if (inReq.aorID != undefined && inReq.aorID != null && inReq.aorID != '') {
			data.serviceCenter = aors.substring(0, 3);
		}
		if (inReq.energizationStatus != undefined && inReq.energizationStatus != null && inReq.energizationStatus != '') {
			data.energizationStatus = inReq.energizationStatus;
		}
		if (inReq.publishedEtr?.value) {
			var publishedEtrVal = new Date(inReq.publishedEtr.value);
			if (!isNaN(publishedEtrVal.getTime())) {
				var {
					estimate_duration_before_minutes,
					estimate_duration_after_minutes,
					estimate_day_of_flag = false, // Default to false
					estimate_type
				} = inReq.customFieldValuesExt || {};

				if (
					estimate_duration_before_minutes != null &&
					estimate_duration_after_minutes != null
				) {
					var result = calculateStartAndEndTimes(
						publishedEtrVal,
						estimate_duration_before_minutes,
						estimate_duration_after_minutes,
						estimate_day_of_flag
					);

					if (result) {
						data.estimateWindow = {
							start: result.start,
							end: result.end
						};

						if (estimate_type) {
							data.estimateWindow.estimateType = estimate_type;
						}
					}
				}
			}
		}
		ctx.setVariable("JobStatusPayload", payload);
		sendJobStatusQueue(urlopenurl, trigValue, 'JE_Azure_MQ', payload);



		if (outageSteps != undefined && outageSteps != null && outageSteps != '' && outageSteps.length != 0) {
			var allExpremIdArray = new Array();
			var obj = {};
			for (var i = 0; i < outageSteps.length; i++) {
				var ActiveStepActiveCheck = session.parameters.ActiveStepActiveCheck
				ctx.setVariable("ActiveStepActiveCheck", ActiveStepActiveCheck)
				if (ActiveStepActiveCheck === "False") {
					var expremIds = outageSteps[i].externalPremiseIDs;
					var status = outageSteps[i].status;
					for (var j = 0; j < expremIds.length; j++) {
						obj = {};
						obj.id = expremIds[j];
						obj.status = status;
						allExpremIdArray.push(obj);
					}
				} else {
					if ((outageSteps[i].active === undefined) || (outageSteps[i].active !== undefined && outageSteps[i].active !== false)) {
						var expremIds = outageSteps[i].externalPremiseIDs;
						var status = outageSteps[i].status;
						for (var j = 0; j < expremIds.length; j++) {
							obj = {};
							obj.id = expremIds[j];
							obj.status = status;
							allExpremIdArray.push(obj);
						}
					}//end of active condition
				}
			}//end of for loop
			ctx.setVariable("allExpremIdArray", allExpremIdArray);

			var jobId = inReq.id
			var origEventTime
			if (urlIn.includes("TRSEVNT.EFC.JOB.UPDATE.REQUEST")) {
				if (incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
					origEventTime = incomingdata.eventTime;
				}
			} else if (urlIn.includes("TRSEVNT.EFC.JOB.CREATE.REQUEST")) {

				if (incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
					origEventTime = incomingdata.eventTime;
				} else {
					origEventTime = incomingdata.data[0].createdAt;
				}
			}
			var start = 0;
			var end = chunk;
			var totalParts = Math.ceil(allExpremIdArray.length / chunk)
			for (var j = 0; j < allExpremIdArray.length / chunk; j++) {
				//console.error('start '+ start+" , end "+ end)
				var arr = allExpremIdArray.slice(start, end)
				var part = j + 1;
				genEventsOfPremIds(arr, jobId, origEventTime, part, totalParts);
				start = end;
				end = end + chunk;
			}
		}
	}
})



function genEventsOfPremIds(arr, jobId, origEventTime, part, totalParts) {
	var payload2 = {}
	payload2.eventType = "PredictedPremises"
	payload2.eventTime = dateTime.toISOString()
	var data = {}
	data.jobId = jobId
	data.origEventTime = origEventTime;
	data.part = part;
	data.totalParts = totalParts;
	payload2.data = data;
	var premObjectsArr = new Array();
	createPremObjs(arr, premObjectsArr);
	payload2.data.premises = premObjectsArr;
	callMQURL(urlopenurl, trigValue, 'JE_Azure_MQ2', payload2);
}

function createPremObjs(arr, premObjectsArr) {
	for (var i = 0; i < arr.length; i++) {
		var premises = {};
		premises.premiseId = arr[i].id
		premises.energizationStatus = arr[i].status;
		premObjectsArr.push(premises);
	}
}

function sendJobStatusQueue(url, trigValue, myctx, payload) {
	var operation = "";
	var urlIn = sm.getVar('var://service/URL-in');
	if (urlIn.includes("TRSEVNT.EFC.JOB.CREATE.REQUEST")) {
		operation = "CREATE"
	}
	else if (urlIn.includes("TRSEVNT.EFC.JOB.UPDATE.REQUEST")) {
		operation = "UPDATE"
	}
	var mqmd = {
		MQMD: {
			StrucId: {
				$: 'MD '
			},
			Format: {
				$: 'MQHRF2 '
			},
			MsgType: {
				$: '8'
			},
			Persistence: {
				$: '1'
			}
		}
	};
	var mqrfh2 = {
		MQRFH2: {
			Version: {
				$: '2'
			},
			Format: {
				$: 'MQSTR'
			},
			NameValueData: {
				NameValue: [{
					usr: {
						triggerValue: {
							$: trigValue
						},

						operation: {
							$: operation
						},
					}
				}]
			}
		}
	};
	var urlopenHeaders = {
		MQMD: mqmd,
		MQRFH2: mqrfh2
	};
	var options = {
		target: url,
		headers: urlopenHeaders,
		data: payload
	};

	urlopen.open(options, function(error, response) {
		//var ctx = session.name("jobEvent")|| session.createContext("jobEvent");
		if (error) {
			logger.error("unable to connect MQ " + JSON.stringify(error));
			ctx.setVariable("retry", 'yes');
			ctx.setVariable("ErrorTxt", 'trsevnt_pje03 - urlopen.open error MQ [MQRC=' + error.errorMessage + ']');
			ctx.setVariable("customErrorCode", error.errorCode);
			ctx.setVariable("customErrorMessage", 'urlopen.open error MQ [MQRC=' + error.errorMessage + ']');
			ctx.setVariable("customReasonMessage", 'urlopen.open error MQ [MQRC=' + error.errorMessage + ']');
			session.reject("Unable to connect MQ" + JSON.stringify(error));
		} else {
			var mqrc = response.statusCode;
			var reasonPhrase = response.reasonPhrase;
			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						ctx.setVariable("ErrorTxt", error.errorMessage);
						logger.error("error reading response from MQ" + readError);
						session.reject("Error reading response from MQ" + readError);
					} else {




						// logger.error("JOBStatus in CallMQ  : " + JSON.stringify(payload));					


						ms.callRule('trsevent_ProcessEFCJobEvent_JobStatus_Policy_EXITILS_rule', session.name('jobEvent').write(payload), null, function(error) {
							if (error) {
								logger.error(error + "while calling trsevent_ProcessEFCJobEvent_JobStatus_Policy_EXITILS_rule");
							}
						});



						//var ctx = session.name("jobEvent")|| session.createContext("jobEvent");
						//ctx.setVariable(myctx+"_response", response);
						logger.info("MQResponseData" + responseData);
					}
				});
			} else {
				logger.error('urlopen.open error [MQRC=' + mqrc + ']');
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", 'trsevnt_pje04 - urlopen.open error [MQRC=' + mqrc + ']');
				ctx.setVariable("customErrorCode", mqrc);
				ctx.setVariable("customErrorMessage", 'urlopen.open error MQ [MQRC=' + mqrc + ']');
				ctx.setVariable("customReasonMessage", 'urlopen.open error MQ [MQRC=' + mqrc + ']');
				session.reject('urlopen.open error MQ [MQRC=' + mqrc + ']');
			}
		}
	});
}

function calculateStartAndEndTimes(publishedEtrVal, estimate_duration_before_minutes, estimate_duration_after_minutes, estimate_day_of_flag) {
	if (estimate_day_of_flag === undefined || estimate_day_of_flag === null) {
		// No estimate window to return
		return null;
	}

	var published = new Date(publishedEtrVal);
	if (isNaN(published.getTime())) {
		throw new Error("Invalid publishedEtrVal date");
	}

	// Helper to get 2nd Sunday of March (DST start) for a given year
	function getSecondSundayOfMarch(year) {
		var d = new Date(Date.UTC(year, 2, 1)); // March 1 UTC
		var day = d.getUTCDay();
		var addDays = (7 - day + 7) % 7 + 7; // Days to second Sunday
		return new Date(Date.UTC(year, 2, 1 + addDays));
	}

	// Helper to get first Sunday of November (DST end)
	function getFirstSundayOfNovember(year) {
		var d = new Date(Date.UTC(year, 10, 1)); // Nov 1 UTC
		var day = d.getUTCDay();
		var addDays = (7 - day) % 7;
		return new Date(Date.UTC(year, 10, 1 + addDays));
	}

	// Determine if published date is in DST (EDT) or standard (EST)
	function isDST(date) {
		var year = date.getUTCFullYear();
		var secondSundayMarch = getSecondSundayOfMarch(year);
		var firstSundayNovember = getFirstSundayOfNovember(year);

		// DST starts at 2:00 AM local time (which is 7:00 AM UTC in March)
		// DST ends at 2:00 AM local time (which is 6:00 AM UTC in November)
		var dstStartUTC = new Date(secondSundayMarch.getTime() + 7 * 3600 * 1000);
		var dstEndUTC = new Date(firstSundayNovember.getTime() + 6 * 3600 * 1000);

		return date >= dstStartUTC && date < dstEndUTC;
	}

	if (estimate_day_of_flag) {
		// Full ET day window aligned with EST/EDT DST rules

		var estOffsetMinutes = isDST(published) ? -4 * 60 : -5 * 60; // EDT is UTC-4, EST is UTC-5

		// Convert published UTC to ET by adding offset
		var publishedET = new Date(published.getTime() + estOffsetMinutes * 60000);

		// Set ET start of day (midnight)
		var startOfDayET = new Date(publishedET);
		startOfDayET.setUTCHours(0, 0, 0, 0);

		// End of day is midnight next day ET
		var endOfDayET = new Date(startOfDayET.getTime() + 24 * 60 * 60 * 1000);

		// Convert back to UTC by subtracting the offset
		var startUTC = new Date(startOfDayET.getTime() - estOffsetMinutes * 60000);
		var endUTC = new Date(endOfDayET.getTime() - estOffsetMinutes * 60000);

		return {
			start: startUTC.toISOString(),
			end: endUTC.toISOString()
		};

	} else {
		// estimate_day_of_flag false or missing, so use before/after minutes

		if (estimate_duration_before_minutes == null || estimate_duration_after_minutes == null) {
			// missing durations, return null
			return null;
		}

		var startUTC = new Date(published.getTime() - estimate_duration_before_minutes * 60000);
		var endUTC = new Date(published.getTime() + estimate_duration_after_minutes * 60000);

		return {
			start: startUTC.toISOString(),
			end: endUTC.toISOString()
		};
	}
}
