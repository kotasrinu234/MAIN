var ctx = session.name("ILS") || session.createContext("ILS");
var ctx1 = session.name("ILSEXIT") || session.createContext("ILSEXIT");
var ctx2 = session.name("jobEvent") || session.createContext("jobEvent");
var logger = console.options({
	'category': 'all'
});
var PPPayload = ctx2.getVariable("ILSPayload");
var jobPayload = ctx2.getVariable("JobStatusPayload");
var ILSPayload;
if(PPPayload){
	ILSPayload = PPPayload;
} else{
	ILSPayload = jobPayload;
}

//logger.error("ILSPayload 1 " + JSON.stringify(ILSPayload));
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
		var incomingData = ctx2.getVariable("jsonPayload");
		var retry = ctx2.getVariable("retry");
		var ErrorTxt = ctx2.getVariable("ErrorTxt");
		var error = ctx2.getVariable("customErrorCode");
		var urlIn = sm.getVar('var://service/URL-in');
		var correlationID;
			

		 //logger.error("incmoing from callRule"+JSONincomingData);
		if (retry != 'yes') {
			if (incomingData.data[0].id === undefined || incomingData.data[0].id === null || incomingData.data[0].id === "") {

			} else {

				if (urlIn.includes("TRSEVNT.EFC.JOB.CREATE.REQUEST")) {
					if (incomingData.eventTime === undefined || incomingData.eventTime === null || incomingData.eventTime === "") {						
						var correlationID = incomingData.data[0].id + ":" + incomingData.data[0].createdAt;
						ctx1.setVariable("correlationID", correlationID);					
						//ctx1.setVariable("correlationID", incomingData.data[0].id);
					} else {
						var correlationID = incomingData.data[0].id + ":" + incomingData.eventTime;
						ctx1.setVariable("correlationID", correlationID);
					}
					if (ILSPayload.eventType === undefined || ILSPayload.eventType === null || ILSPayload.eventType === "") {
						var sourceEventTimestamp = incomingData.data[0].createdAt;
						var jobDisplayID = incomingData.data[0].displayID;
						var exitDescription = session.parameters.JOBCreateILSExitDescription;
						var messageType = session.parameters.messageType;
					} else
						if (ILSPayload.eventType === "PredictedPremises") {
							var sourceEventTimestamp = incomingData.eventTime;
							var jobDisplayID = incomingData.data[0].displayID;
							var part = ILSPayload.data.part;
							var totalParts = ILSPayload.data.totalParts;
							var exitDescription = session.parameters.JOBCreateILSPredictExitDescription;
							var messageType = session.parameters.ILSPredictmessageType;
						} else if (ILSPayload.eventType === "JobStatusDetail") {
							var sourceEventTimestamp = incomingData.data[0].createdAt;
							var jobDisplayID = incomingData.data[0].displayID;
							var exitDescription = session.parameters.JOBCreateILSExitDescription;
							var messageType = session.parameters.messageType;
						}
					var jobID = incomingData.data[0].id;
					ctx1.setVariable("exitDestination", 'TRSEVNT.EFC.SEND');
					ctx1.setVariable("sourceUrl", 'TRSEVNT.EFC.JOB.CREATE.REQUEST');

				} else if (urlIn.includes("TRSEVNT.EFC.JOB.UPDATE.REQUEST")) {
					if (incomingData.eventTime === undefined || incomingData.eventTime === null || incomingData.eventTime === "") {
						ctx1.setVariable("correlationID", incomingData.data[0].id);
					} else {
						var correlationID = incomingData.data[0].id + ":" + incomingData.eventTime;
						ctx1.setVariable("correlationID", correlationID);
					}
					if (ILSPayload.eventType === undefined || ILSPayload.eventType === null || ILSPayload.eventType === "") {
						var exitDescription = session.parameters.JOBUpdateILSExitDescription;
						var messageType = session.parameters.messageType;
					}
					
					if (ILSPayload.eventType === "PredictedPremises") {
						var messageType = session.parameters.ILSPredictmessageType;
						var part = ILSPayload.data.part;
						
						var totalParts = ILSPayload.data.totalParts;
						
						var exitDescription = session.parameters.JOBUpdateILSPredictExitDescription;
					} else if (ILSPayload.eventType === "JobStatusDetail") {

						var exitDescription = session.parameters.JOBUpdateILSExitDescription;
						var messageType = session.parameters.messageType;
					}
					var jobID = incomingData.data[0].id;
					var jobDisplayID = incomingData.data[0].displayID;
					var sourceEventTimestamp = incomingData.eventTime;
					ctx1.setVariable("exitDestination", 'TRSEVNT.EFC.SEND');
					ctx1.setVariable("sourceUrl", 'TRSEVNT.EFC.JOB.UPDATE.REQUEST');
				}
				ctx1.setVariable('exitStatus', '0');
			}
		} else {
			if (urlIn.includes("TRSEVNT.EFC.JOB.CREATE.REQUEST")) {
				if (incomingData.data[0].createdAt === undefined || incomingData.data[0].createdAt === null || incomingData.data[0].createdAt === "") {
					ctx1.setVariable("correlationID", incomingData.data[0].id);
				} else {
					var correlationID = incomingData.data[0].id + ":" + incomingData.data[0].createdAt;
					ctx1.setVariable("correlationID", correlationID);
				}
				if (ILSPayload.eventType === undefined || ILSPayload.eventType === null || ILSPayload.eventType === "") {
					var sourceEventTimestamp = incomingData.data[0].createdAt;
					var jobDisplayID = incomingData.data[0].displayID;
					var messageType = session.parameters.messageType;
				} else
					if (ILSPayload.eventType === "PredictedPremises") {
						var sourceEventTimestamp = incomingData.eventTime;
						var jobDisplayID = incomingData.data[0].displayID;
						var messageType = session.parameters.ILSPredictmessageType;
						var part = ILSPayload.data.part;
						
						var totalParts = ILSPayload.data.totalParts;
						
					} else if (ILSPayload.eventType === "JobStatusDetail") {
						var sourceEventTimestamp = incomingData.data[0].createdAt;
						var jobDisplayID = incomingData.data[0].displayID;
						var messageType = session.parameters.messageType;
					}
				var jobID = incomingData.data[0].id;
				ctx1.setVariable("exitDestination", 'TRSEVNT.EFC.SEND');
				ctx1.setVariable("sourceUrl", 'TRSEVNT.EFC.JOB.CREATE.REQUEST');

			} else if (urlIn.includes("TRSEVNT.EFC.JOB.UPDATE.REQUEST")) {
				if (incomingData.eventTime === undefined || incomingData.eventTime === null || incomingData.eventTime === "") {
					ctx1.setVariable("correlationID", incomingData.data[0].id);
				} else {
					var correlationID = incomingData.data[0].id + ":" + incomingData.eventTime;
					ctx1.setVariable("correlationID", correlationID);
				}
				if (ILSPayload.eventType === undefined || ILSPayload.eventType === null || ILSPayload.eventType === "") {
					var messageType = session.parameters.messageType;
				}
				
				if (ILSPayload.eventType === "PredictedPremises") {
					var messageType = session.parameters.ILSPredictmessageType;
					var part = ILSPayload.data.part;
					var totalParts = ILSPayload.data.totalParts;
				} else if (ILSPayload.eventType === "JobStatusDetail") {

					var messageType = session.parameters.messageType;
				}
				var jobID = incomingData.data[0].id;
				var jobDisplayID = incomingData.data[0].displayID;
				var sourceEventTimestamp = incomingData.eventTime;
				ctx1.setVariable("sourceUrl", 'TRSEVNT.EFC.JOB.UPDATE.REQUEST');
				ctx1.setVariable("exitStatus", error);
				ctx1.setVariable("exitDescription", ErrorTxt)
			}

		}


	
	if (jobID !== undefined) {
		ctx1.setVariable('jobID', jobID);
	}
	if (jobDisplayID !== undefined) {
		ctx1.setVariable('jobDisplayID', jobDisplayID);
	}
	if (sourceEventTimestamp !== undefined) {
		ctx1.setVariable('sourceEventTimestamp', sourceEventTimestamp);
	}
	if (exitDescription !== undefined) {
		ctx1.setVariable('exitDescription', exitDescription);
	}
	if (messageType !== undefined) {
		ctx1.setVariable('messageType', messageType);
	}
	if (part != undefined) {
		ctx1.setVariable('part', part);
	}
	if (totalParts !== undefined) {
		ctx1.setVariable('totalParts', totalParts)
	}
	var PrEFCJobReqQ = session.parameters.PrEFCJobReqQ;
	var JobtoAzure_QM = session.parameters.trsevent_PrEFC_JobtoAzure_QM;
	var exitDestination = 'dpmq://' + JobtoAzure_QM + '/?RequestQueue=' + PrEFCJobReqQ;
	ctx1.setVariable('exitDestination', exitDestination);
session.output.write(ILSPayload);

		
		
