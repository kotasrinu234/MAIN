var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var doLookup = require('./pje_lookup.js');
var logger = console.options({
    'category': 'all'
});

var ctx = session.name("jobEvent")|| session.createContext("jobEvent");

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } 
	else { 
		var createdOperationModeID = incomingdata.data[0].createdOperationModeID;
		if(incomingdata.data[0].jobTypeID != undefined && incomingdata.data[0].jobTypeID != null && incomingdata.data[0].jobTypeID != '') {
		var jobTypeID = incomingdata.data[0].jobTypeID;
		} else 
		throw Error('jobTypeID is a mandatory field');
		if(incomingdata.data[0].status != undefined && incomingdata.data[0].status != null ) {
		var jobStatus = incomingdata.data[0].status ;
		} else throw Error('status is a mandatory field');
		var etrExpirationStatus = incomingdata.data[0].etrExpirationStatus;
		var aorID = incomingdata.data[0].aorID;
		var networkModelType = incomingdata.data[0].networkModelType;
		
		
		
		
	
		var typeArr = new Array();
		var jobTypeWorkFlow = {};
		var uri ='/jobTypes.workflows/'+jobTypeID+'/'+jobStatus;
		jobTypeWorkFlow.name = "jobTypes.workflows";
		jobTypeWorkFlow.id = jobTypeID;
		jobTypeWorkFlow.status = jobStatus;
		typeArr.push(jobTypeWorkFlow);
		doLookup(typeArr,"jobTypeWorkFlow",uri);

		
		

		typeArr = new Array();
		var jobTypes = {};
		var uri ='/jobTypes/'+jobTypeID;
		jobTypes.name = "jobTypes";
		jobTypes.id = jobTypeID;
		typeArr.push(jobTypes);
		doLookup(typeArr,"jobTypes",uri);

		
		
		
		if(createdOperationModeID !=undefined && createdOperationModeID !=null && createdOperationModeID != ''){
			typeArr = new Array();
			var operationModes ={};
			var uri ='/operationModes/'+createdOperationModeID;
			operationModes.name = "operationModes",
			operationModes.id = createdOperationModeID
			typeArr.push(operationModes);
			doLookup(typeArr,"operationModes",uri);
			
		}
		
		
		
		if(etrExpirationStatus !=undefined && etrExpirationStatus !=null && etrExpirationStatus != ''){
			typeArr = new Array();
			var etrExpirationStatuses ={}
			var uri ='/etrExpirationStatuses/'+etrExpirationStatus;
			etrExpirationStatuses.name = "etrExpirationStatuses",
			etrExpirationStatuses.id = etrExpirationStatus
			typeArr.push(etrExpirationStatuses);
			doLookup(typeArr,"etrExpirationStatuses",uri);
		}
		
		
		if(aorID !=undefined && aorID !=null && aorID != ''){
			typeArr = new Array();
			var aors ={};
			var uri ='/aors/'+aorID;
			aors.name = "aors";
			aors.id = aorID;
			typeArr.push(aors);
			doLookup(typeArr,"aors",uri);
			
		}
		
		if(networkModelType !=undefined){
			typeArr = new Array();
			var networkModelTypeLabels = {}
			var uri ='/networkModelTypeLabels/'+networkModelType;
			networkModelTypeLabels.name = "networkModelTypeLabels";
			networkModelTypeLabels.status = networkModelType;
			typeArr.push(networkModelTypeLabels);
			doLookup(typeArr,"networkModelTypeLabels",uri);
			
		}
		
		
		
		if(jobTypeID !=undefined && jobTypeID !=null && jobTypeID != ''){
			typeArr = new Array();
			var jobOutageTypes = {};
			var uri ='/jobOutageTypes/'+jobTypeID;
			jobOutageTypes.name = "jobOutageTypes";
			jobOutageTypes.id = jobTypeID
			typeArr.push(jobOutageTypes);
			doLookup(typeArr,"jobOutageTypes",uri);		
		}		
	}
})