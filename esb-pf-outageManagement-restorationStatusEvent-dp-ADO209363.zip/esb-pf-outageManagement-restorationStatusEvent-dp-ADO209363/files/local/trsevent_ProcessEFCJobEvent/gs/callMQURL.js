var urlopen = require('urlopen');	
var sm = require('service-metadata');
var ms = require('multistep');
var ctx = session.name("jobEvent")|| session.createContext("jobEvent");
var logger = console.options({
	'category': 'all'
});


 function callMQURL(url,trigValue, myctx,payload) {
var operation = "";
var urlIn = sm.getVar('var://service/URL-in');
if(urlIn.includes("TRSEVNT.EFC.JOB.CREATE.REQUEST")){
	operation = "CREATE"
}
else if(urlIn.includes("TRSEVNT.EFC.JOB.UPDATE.REQUEST")){
	operation = "UPDATE"
}	
var mqmd = {
						MQMD: {
							StrucId: {
								$: 'MD '
							},
							Format: {
								$: 'MQHRF2 '
							}, 
							MsgType: {
								$: '8'
							},
							Persistence: {
								$: '1'
							}
						}
					};
					var mqrfh2 = {
						MQRFH2: {
							Version: {
								$: '2'
							},
							Format: {
								$: 'MQSTR'
							},
							NameValueData: {
								NameValue: [{
									usr: {
										triggerValue: {
											$: trigValue
										},
                                                                                
										operation: {
											$: operation
										},
									}
								}]
							}
						}
					};
					var urlopenHeaders = {
						MQMD: mqmd,
						MQRFH2: mqrfh2
					};
					var options = {
						target: url,
						headers: urlopenHeaders,
						data: payload
					};				
             ctx.setVariable("ILSPayload",payload);
			 urlopen.open(options, function(error, response) {
				//var ctx = session.name("jobEvent")|| session.createContext("jobEvent");
						if (error) {
						    logger.error("unable to connect MQ " + JSON.stringify(error));
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt",'trsevnt_pje03 - urlopen.open error MQ [MQRC=' + error.errorMessage + ']' );
							ctx.setVariable("customErrorCode", error.errorCode);
							ctx.setVariable("customErrorMessage", 'urlopen.open error MQ [MQRC=' + error.errorMessage + ']');
							ctx.setVariable("customReasonMessage", 'urlopen.open error MQ [MQRC=' + error.errorMessage + ']');
							session.reject("Unable to connect MQ" + JSON.stringify(error));
						} else {
							var mqrc = response.statusCode;
							var reasonPhrase = response.reasonPhrase;
							if (mqrc == 0) {
								var replyMQMD = response.get({
									type: 'mq'
								}, 'MQMD');
								var replyMQRFH2 = response.get({
									type: 'mq'
								}, 'MQRFH2');
								response.readAsBuffer(function(readError, responseData) {
									if (readError) {
										ctx.setVariable("ErrorTxt",error.errorMessage );
										logger.error("error reading response from MQ" + readError);
										session.reject("Error reading response from MQ" + readError );	
									} else {
										
										
											
										
	                                    //logger.error("payload in CallMQ  : " + JSON.stringify(payload));					
										
										
										 ms.callRule('trsevent_ProcessEFCJobEvent_Processing_Policy_EXITILS_rule', session.name('jobEvent').write(payload), null, function(error) {
											if (error) {
												 logger.error(error + "while calling trsevent_ProcessEFCJobEvent_JobStatus_Policy_EXITILS_rule");	
											}
										});
									
									   
									
										//var ctx = session.name("jobEvent")|| session.createContext("jobEvent");
										//ctx.setVariable(myctx+"_response", response);
										logger.info("MQResponseData" + responseData);
									}
								});
							} else {
								logger.error('urlopen.open error [MQRC=' + mqrc + ']');
							    ctx.setVariable("retry", 'yes');
								ctx.setVariable("ErrorTxt",'trsevnt_pje04 - urlopen.open error [MQRC=' + mqrc + ']' );
								ctx.setVariable("customErrorCode", mqrc);
								ctx.setVariable("customErrorMessage", 'urlopen.open error MQ [MQRC=' + mqrc + ']');
								ctx.setVariable("customReasonMessage", 'urlopen.open error MQ [MQRC=' + mqrc + ']');
								session.reject('urlopen.open error MQ [MQRC=' + mqrc + ']');
							}
						}
					});
}
module.exports = callMQURL;
