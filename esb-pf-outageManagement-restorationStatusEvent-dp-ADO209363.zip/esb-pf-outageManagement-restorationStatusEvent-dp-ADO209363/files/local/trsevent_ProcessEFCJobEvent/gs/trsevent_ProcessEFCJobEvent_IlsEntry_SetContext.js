var ctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

//var exitDescription = session.parameters.ILSExitDescription;
var messageType = session.parameters.messageType;
var logger = console.options({
    'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingData) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
        session.reject(readAsJSONError);
    } else {
        var urlIn = sm.getVar('var://service/URL-in');
        var correlationID;
        if (incomingData.data[0].id === undefined || incomingData.data[0].id === null || incomingData.data[0].id === "") {
       
        } else {
            if (urlIn.includes("TRSEVNT.EFC.JOB.CREATE.REQUEST")) {
               if (incomingData.eventTime === undefined || incomingData.eventTime === null || incomingData.eventTime === "") {						
						var correlationID = incomingData.data[0].id + ":" + incomingData.data[0].createdAt;
						ctx.setVariable("correlationID", correlationID);					
						//ctx1.setVariable("correlationID", incomingData.data[0].id);
					} else {
						var correlationID = incomingData.data[0].id + ":" + incomingData.eventTime;
						ctx.setVariable("correlationID", correlationID);
					}	
				var jobID = incomingData.data[0].id;
				var jobDisplayID = incomingData.data[0].displayID;
				var sourceEventTimestamp = incomingData.data[0].createdAt;
				var entryDescription = session.parameters.JOBCreateILSEntryDescription;
				ctx.setVariable("sourceUrl", 'TRSEVNT.EFC.JOB.CREATE.REQUEST'); 
            } else if (urlIn.includes("TRSEVNT.EFC.JOB.UPDATE.REQUEST")) {
                if (incomingData.eventTime === undefined || incomingData.eventTime === null || incomingData.eventTime === "") {
                    ctx.setVariable("correlationID", incomingData.data[0].id);
                } else {
                    var correlationID = incomingData.data[0].id + ":" + incomingData.eventTime;
                    ctx.setVariable("correlationID", correlationID);
                }
				var jobID = incomingData.data[0].id;
				var jobDisplayID = incomingData.data[0].displayID;
				var sourceEventTimestamp = incomingData.eventTime;
				var entryDescription = session.parameters.JOBUpdateILSEntryDesciption;
				ctx.setVariable("sourceUrl", 'TRSEVNT.EFC.JOB.UPDATE.REQUEST');
            }
        }

        if (jobID != undefined) {
			ctx.setVariable('jobID', jobID);
		}
		if (jobDisplayID != undefined) {
			ctx.setVariable('jobDisplayID', jobDisplayID);
		}
		if (sourceEventTimestamp != undefined) {
			ctx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
		}
		if (entryDescription != undefined) {
			ctx.setVariable('entryDescription', entryDescription);
		}
		if (messageType != undefined) {
			ctx.setVariable('messageType', messageType);
		}
     
    }
});
