var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

var ctx = session.name('ils')|| session.createContext('ils');


session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
		var incomingdata =incomingdata;
		var correlationID;
		if(incomingdata.eventTime !=undefined)
		{correlationID= incomingdata.data[0].displayID+':'+incomingdata.eventTime}
		else{correlationID= incomingdata.data[0].displayID}
		var callID= incomingdata.data[0].id;
		var callDisplayID = incomingdata.data[0].displayID
		var jobID = incomingdata.data[0].jobID
		var jobDisplayID = incomingdata.data[0].jobDisplayID
		var callCode = incomingdata.data[0].externalCallCodeID
		var premiseID = incomingdata.data[0].externalPremiseID
		var sourceEventTimestamp = incomingdata.eventTime
		var description = session.parameters.trsevent_ProcessEFCCallEventIlsEntryDescription;
		ctx.setVariable('retryCount',-1);
		ctx.setVariable('correlationID',correlationID);
		if(callID != undefined){ctx.setVariable('callID',callID);}
if(callDisplayID != undefined){ctx.setVariable('callDisplayID',callDisplayID);}
if(jobID  != undefined){ctx.setVariable('jobID',jobID);}		
if(jobDisplayID  != undefined){		ctx.setVariable('jobDisplayID',jobDisplayID);}
if(callCode  != undefined){		ctx.setVariable('callCode',callCode);}
if(premiseID  != undefined){			ctx.setVariable('premiseID',premiseID);}
if(sourceEventTimestamp  != undefined){			ctx.setVariable('sourceEventTimestamp',sourceEventTimestamp);}
if(description  != undefined){				ctx.setVariable('description',description);}
		
	}
	});