var ctx = session.name("trsevent") || session.createContext("trsevent");
var ctx1 = session.name("ils") || session.createContext("ils");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ilsctx = session.name("ils") || session.createContext("ils");
		ilsctx.setVariable('exitStatus', '500');

		var dateTime = new Date();
		var payload = {
			"eventType": "ReportedCallDetails",
			"eventTime": dateTime.toISOString(),
			"data": {
				"calls": [{
					//	"outageHours" : "3",
				}]
			}
		}
		if (!(incomingdata.data[0].jobID == undefined)) {
			payload.data.jobId = incomingdata.data[0].jobID
		}
		if (!(incomingdata.eventTime == undefined)) {
			payload.data.origEventTime = incomingdata.eventTime
		}
		if (!(incomingdata.data[0].customFieldValuesExt == undefined)) {
			if (!(incomingdata.data[0].customFieldValuesExt.TBT == true)) {
				payload.data.calls[0].tbt = false
			} else {
				payload.data.calls[0].tbt = true
			}
		}

		if (!(incomingdata.data[0].customFieldValuesExt == undefined)) {
			if (!(incomingdata.data[0].customFieldValuesExt.CancelDueToGoodVoltage == true)) {
				payload.data.calls[0].autoCloseFlag = false
			} else {
				payload.data.calls[0].autoCloseFlag = true
			}
		}
		if (!(incomingdata.data[0].customFieldValuesExt == undefined)) {
			if (!(incomingdata.data[0].customFieldValuesExt.external_order_number == undefined)) {
				payload.data.calls[0].externalReference = incomingdata.data[0].customFieldValuesExt.external_order_number
			}

		}
		var ApplicationID = ctx.getVariable("ApplicationID");
		var contactMethod = ctx.getVariable("contactMethod");
		var CustomFieldValuesExtSource = incomingdata.data[0].customFieldValuesExt.source;
		if (!(ApplicationID === undefined || ApplicationID === null || ApplicationID === "")) {
			payload.data.calls[0].applicationId = ApplicationID;
		} else if (!(incomingdata.data[0].customFieldValuesExt == null || incomingdata.data[0].customFieldValuesExt == '' ||incomingdata.data[0].customFieldValuesExt == undefined)) {
			if (!(incomingdata.data[0].customFieldValuesExt.ApplicationID === null ||incomingdata.data[0].customFieldValuesExt.ApplicationID === '' ||incomingdata.data[0].customFieldValuesExt.ApplicationID === undefined)) {
				payload.data.calls[0].applicationId = incomingdata.data[0].customFieldValuesExt.ApplicationID;
			} else if (contactMethod === undefined || contactMethod === null || contactMethod === "") {
				payload.data.calls[0].applicationId = 'A';
			} else if (contactMethod == 7) {
				if (CustomFieldValuesExtSource === undefined || CustomFieldValuesExtSource === null || CustomFieldValuesExtSource === "") {
					payload.data.calls[0].applicationId = "C";
				} else {
					if (CustomFieldValuesExtSource == "CRM") {
						payload.data.calls[0].applicationId = "C";
					} else if (CustomFieldValuesExtSource == "WISMO") {
						payload.data.calls[0].applicationId = "Z";
					} else {
						// Log error for invalid source
						var errorTxt = "Invalid Source: " + CustomFieldValuesExtSource;
						logger.error(errorTxt);
						ctx.setVariable("ErrorTxt", errorTxt);
						ctx.setVariable("retry", 'yes');
						payload.data.calls[0].applicationId = "";
					}
				}
			}
		} else {
			payload.data.calls[0].applicationId = " ";
		}

		if (!(incomingdata.data[0].customFieldValuesExt.source == undefined)) {
			payload.data.calls[0].applicationIdSource = incomingdata.data[0].customFieldValuesExt.source
		}

		if (!(incomingdata.data[0].externalPremiseID == undefined)) {
			payload.data.calls[0].premiseId = incomingdata.data[0].externalPremiseID
		}
		if (!(incomingdata.data[0].displayID == undefined)) {
			payload.data.calls[0].callId = incomingdata.data[0].displayID
		}
		if (!(incomingdata.data[0].associatedCallDisplayID == undefined)) {
			payload.data.calls[0].associatedCallId = incomingdata.data[0].associatedCallDisplayID
		}
		if (!(incomingdata.data[0].externalCallCodeID == undefined)) {
			payload.data.calls[0].callCode = incomingdata.data[0].externalCallCodeID
		}
		if (!(incomingdata.data[0].status == undefined)) {
			payload.data.calls[0].callStatus = incomingdata.data[0].status
		}
		var offDate;
		if (!(incomingdata.data[0].startedTime == undefined)) {
			offDate = incomingdata.data[0].startedTime;
			payload.data.calls[0].offDate = incomingdata.data[0].startedTime
		}
		else {
			offDate = incomingdata.data[0].createdAt;
			payload.data.calls[0].offDate = incomingdata.data[0].createdAt
		}
		var onDate;
		if (!(incomingdata.data[0].meterID == undefined)) {
			payload.data.calls[0].meterId = incomingdata.data[0].meterID
		}
		var lookupResponseData_outageType = ctx.getVar("lookupResponseData_outageType");
		if (!(lookupResponseData_outageType == null)) {
			if (lookupResponseData_outageType == 'UNPLANNED_OUTAGE') {
				if (!(incomingdata.data[0].resolvedAt == undefined)) {
					onDate = incomingdata.data[0].resolvedAt
					payload.data.calls[0].onDate = incomingdata.data[0].resolvedAt
				}
			} else {
				if (!(incomingdata.data[0].resolvedAt == undefined)) {
					onDate = incomingdata.data[0].resolvedAt
					payload.data.calls[0].onDate = incomingdata.data[0].resolvedAt
				}
			}
		}
		if (onDate != '' && onDate != null && onDate != undefined && offDate != '' && offDate != null && offDate != undefined) {
			const eventStartTime = new Date(onDate);
			const eventEndTime = new Date(offDate);
			var resolution = eventStartTime.valueOf() - eventEndTime.valueOf();
			var resolutionTime = ((resolution / (1000 * 60 * 60))).toFixed()
			//resolutionTime = JSON.stringify(resolutionTime)
			//var resolutionTimeBefore = resolutionTime.split('.')[0];
			//var resolutionTimeAfter = resolutionTime.split('.')[1];
			//resolutionTimeAfter = resolutionTimeAfter.substring(0,2)
			//var outageHours = resolutionTimeBefore+'.'+resolutionTimeAfter;
			payload.data.calls[0].outageHours = resolutionTime

		}
		session.output.write(payload);
		ctx.setVariable("payload", payload);
		var BackendUrl = session.parameters.BackendMQCallUrl;
		var BackendMQcall = {
			target: BackendUrl,
			data: payload
		};

		urlopen.open(BackendMQcall, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.debug("BackendMQcall uri response code is " + error);
				var ErrorTxt = (" trsevnt_PC_04 BackendMQcall uri response code is " + JSON.stringify(error));
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("retry", 'yes');
			} else {
				var mqrc = response.statusCode;
				ilsctx.setVariable('exitStatus', mqrc);
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							logger.debug("mq uri response code is " + readError);
							var ErrorTxt = ("trsevnt_PC_04 mq uri response code is " + JSON.stringify(readError));
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ctx.setVariable("retry", 'yes');

						} else {
							logger.debug("MQResponseData" + responseData);
						}
					});
				} else {
					logger.debug("mq uri response code is urlopen.open error [MQRC=" + mqrc + "]");
					var ErrorTxt = ("trsevnt_PC_04 mq uri response code is urlopen.open error [MQRC=" + mqrc + "]");
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("retry", 'yes');
				}
			}
		});
	}
});
