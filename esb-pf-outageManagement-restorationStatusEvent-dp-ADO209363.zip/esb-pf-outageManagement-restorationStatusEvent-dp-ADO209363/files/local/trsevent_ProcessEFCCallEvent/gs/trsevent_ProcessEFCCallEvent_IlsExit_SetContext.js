var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
	var ctx = session.name("trsevent") || session.createContext("trsevent");
	var retry = ctx.getVariable('retry');
	var ErrorTxt = ctx.getVariable('ErrorTxt')
	var trsevent_ProcessEFCCallEventIlsExitDescription = session.parameters.trsevent_ProcessEFCCallEventIlsExitDescription
	var ctx = session.name('ils')|| session.createContext('ils');
	if(retry != 'yes'){
	ctx.setVariable('exitStatus','0');
	ctx.setVariable('exitDestination','TRSEVNT.EFC.SEND');
	ctx.setVariable('Exitdescription',trsevent_ProcessEFCCallEventIlsExitDescription)
	}else{
	//ctx.setVariable('exitStatus','');
	ctx.setVariable('exitDestination','TRSEVNT.EFC.SEND');
	ctx.setVariable('Exitdescription',ErrorTxt)
	}
	}
	});