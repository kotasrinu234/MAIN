                                                                                               
<!-- This XSLT is used to set the error message when gettoken call errors out
     Author: Sushma Yarlagadda -->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date msxsl dyn">
	<dp:input-mapping href="store:///pkcs7-convert-input.ffd" type="ffd"/> 	
			<xsl:variable name="request">
			<xsl:value-of select="normalize-space(dp:decode(dp:binary-encode(//object/message/node()),'base-64'))" disable-output-escaping = "yes"/> 
		</xsl:variable>
	<xsl:output method="text" encoding="utf-8"/>
	<xsl:template match="/">
	
	<xsl:if test="contains($request,'error')">
		<xsl:message dp:type="all"
				             dp:priority="error">trsevent_001: Unable to retrieve token</xsl:message>

</xsl:if>
	</xsl:template>
</xsl:stylesheet>