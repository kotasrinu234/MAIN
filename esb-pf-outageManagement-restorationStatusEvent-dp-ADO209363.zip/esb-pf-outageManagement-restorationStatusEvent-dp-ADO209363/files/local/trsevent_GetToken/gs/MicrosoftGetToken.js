var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (error) {
		session.output.write(error);
	} else {
		ctx.setVariable("TestIncoming", incomingdata)
	 }
})