var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
/*var messageType = session.parameters.messageType;
ctx.setVariable('messageType', messageType);*/
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
        var incomingdata = incomingdata;
ctx.setVariable("payload", incomingdata)

var EntryDescription= session.parameters.EntryDescription;
 ctx.setVariable('EntryDescription', EntryDescription);
 var messageType =session.parameters.messageType;
  ctx.setVariable('messageType', messageType);
  
        var correlationID;
        if (incomingdata.eventTime != undefined) {
            correlationID = incomingdata.data[0].id + ':' + incomingdata.eventTime
        } else {
            correlationID = incomingData.data[0].createdAt;
        }  
        ctx.setVariable('correlationID', correlationID);
    }
       if (incomingdata.data[0].displayID != undefined) {
	        ctx.setVariable('linkedJobDisplayId', incomingdata.data[0].displayID);
	}
	
	 if (incomingdata.data[0].id != undefined) {
	ctx.setVariable('linkedjobId', incomingdata.data[0].id);
	}
	
	if (incomingdata.eventTime != undefined) {
	       ctx.setVariable('eventTime', incomingdata.eventTime);
	}
});
