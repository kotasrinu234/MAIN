var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
sm.setVar("var://service/mpgw/skip-backside", true)
var ctx = session.name('trsevnt') || session.createContext('trsevnt');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var QueueURL = session.parameters.QueueURL;
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in parsing incoming request " + JSON.stringify(readAsJSONError));
		session.reject("Error in parsing incoming request" + JSON.stringify(readAsJSONError));
	}
	else {
var payload = incomingdata;
var correlationID;
        if (incomingdata.eventTime != undefined) {
            correlationID = incomingdata.data[0].id + ':' + incomingdata.eventTime
        } else {
            correlationID = incomingdata.data[0].createdAt;
        }  
        ctx.setVariable('correlationID', correlationID);
// Prepare current timestamp in ISO format
var now = new Date();
var currentTimestamp = now.toISOString().split('.')[0] + ".000Z";

var jobId = incomingdata.data[0].links[0].linkedID;
var jobDisplayId = incomingdata.data[0].links[0].linkedDisplayID;
var linkedjobId = incomingdata.data[0].id;
var linkedJobDisplayId = incomingdata.data[0].displayID;

var eventTime =incomingdata.eventTime;
// Check if eventTime is not empty
if (eventTime!== "" && eventTime !== null && eventTime !==undefined) {
	var origEventTime = eventTime;
}else{
	var origEventTime = incomingdata.data[0].createdAt;
}
		var payload =
		{
    "eventType" : "LinkedJobDetail",
    "eventTime" : currentTimestamp,
    "data" : { 
        "origEventTime"   : origEventTime, 
		"jobId"           : jobId,
		"jobDisplayId"    : jobDisplayId,
		"linkedJobId"        : linkedjobId,
        "linkedJobDisplayId" : linkedJobDisplayId
	}
};
		
		var options = {
			target: QueueURL,
			data: payload
		};
		var info = " TargetURL :" + options.target ;
		try {
			urlopen.open(options, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var errorinfo = "trsevnt_PJF_EFC_Event_001:url connection error 'TRSEVNT.EFC.SEND' Queue, details are : " + info + "; error info :" + error
					ctx.setVariable("retry", 'yes');
					ILSctx.setVariable("exitStatus", "500")
					ILSctx.setVariable("ExitDescription", errorinfo)
					ILSctx.setVariable('ExitDestination', QueueURL);
					logger.error(errorinfo);
					session.output.write(payload);
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								var errorinfo = "error reading response 'TRSEVNT.EFC.SEND' Queue, details are : " + info + "; error info :" + readError
								ILSctx.setVariable("exitStatus", mqrc)
								ILSctx.setVariable("ExitDescription", errorinfo)
								hm.response.statusCode = 500
								session.reject(errorinfo);
							} else {
								logger.debug("MQResponsecode " + mqrc);
								ILSctx.setVariable('ExitStatus', '0');
								ILSctx.setVariable('ExitDestination', QueueURL);
								ILSctx.setVariable("ExitDescription", session.parameters.ExitDescription);
								session.output.write(payload);
							}
						});
					} else {
						var errorinfo = "trsevnt_PJF_EFC_Event_002:Failed to connect to queue:'TRSEVNT.EFC.SEND' Queue, details are : " + info + "; ResponseStatusCode :" + mqrc
						ctx.setVariable("retry", 'yes');
						ILSctx.setVariable("exitStatus", mqrc)
						ILSctx.setVariable("ExitDescription", errorinfo)
						ILSctx.setVariable('ExitDestination', QueueURL);
						logger.error(errorinfo);
						session.output.write(payload);
					}
				}
			});
		} catch (err) {
			var errorinfo = "trsevnt_PJF_EFC_Event_003:url connection error 'TRSEVNT.EFC.SEND' Queue, details are : " + info + "; error info :" + err
			ctx.setVariable("retry", 'yes');
			ILSctx.setVariable("exitStatus", "500")
			ILSctx.setVariable("ExitDescription", errorinfo)
			ILSctx.setVariable('ExitDestination', QueueURL);
			logger.error(errorinfo);
			session.output.write(payload);
		}
	}
});
