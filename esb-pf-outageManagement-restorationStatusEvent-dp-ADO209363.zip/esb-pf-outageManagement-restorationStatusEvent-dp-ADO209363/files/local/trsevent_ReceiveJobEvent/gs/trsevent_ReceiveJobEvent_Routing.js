var logger = console.options({
    'category': 'all'
});
session.input.readAsJSON(function(error, json) {
    if (error) {
        session.output.write(error);
    } else {
        var sm = require('service-metadata');
        var urlIn = sm.getVar('var://service/URL-in');
        var URI = "";
		if(urlIn.includes("JobStatus")){
			URI = "JobStatus";
				}
        console.log("URI::" + URI);
        var mqmd = {
            MQMD: {
                StrucId: {
                    $: 'MD  '
                },
                Format: {
                    $: 'MQHRF2  '
                },
                MsgType: {
                    $: '8'
                } /* ,
                Persistence: {
                    $: '1'
                },
              ReplyToQ: {
                    $: 'PlaceHolderReplyToQ'
                } */
            }
        };
        var mqrfh2 = {
            MQRFH2: {
                Version: {
                    $: '2'
                },
                Format: {
                    $: 'MQSTR'
                },
                NameValueData: {
                    NameValue: [{
                        usr: {
                            URIExtract: {
                                $: URI
                            },
                        }
                    }]
                }
            }
        };
        sm.setVar('var://service/mpgw/skip-backside', true);
        var urlopen = require('urlopen');
        var urlopenHeaders = {
            MQMD: mqmd,
            MQRFH2: mqrfh2
        };
	var targeturl ;
		if(urlIn.includes("Update")){
			targeturl = 'dpmq://trsevent_ReceiveJobEvent_QM/?PublishTopicString=TROUBLE/STATUS/events/JobStatus/Update'
			}else if(urlIn.includes("Create")){
				targeturl = 'dpmq://trsevent_ReceiveJobEvent_QM/?PublishTopicString=TROUBLE/STATUS/events/JobStatus/Create'
			}
session.output.write(json);
        var options = {
            target: targeturl,
            headers: urlopenHeaders,
            data: json,
        };
        urlopen.open(options, function(error, response) {
            var hm = require('header-metadata');
            if (error) {
                hm.response.statusCode = 500
				logger.error('trsevnt_rje_001:Could not place message in Queue|errorString: ErrorCode = 500' + error );
            } else {
                var mqrc = response.statusCode;
                if (mqrc == 0) {
                    var replyMQMD = response.get({
                        type: 'mq'
                    }, 'MQMD');
                    var replyMQRFH2 = response.get({
                        type: 'mq'
                    }, 'MQRFH2');
                    response.readAsBuffer(function(readError, responseData) {
                        if (readError) {
                            hm.response.statusCode = 500
							logger.error('trsevnt_rje_002:Could not place message in Queue|errorString: ErrorCode = 500' + readError );
                        } else {
							logger.info("MQResponseData" + responseData);
                        }
                    });
                } else {
					logger.error('trsevnt_rje_003:urlopen.open error [MQRC=' + mqrc + ']' );
                    hm.response.statusCode = 500
session.reject('urlopen.open error [MQRC=' + mqrc + ']' );
                }
            }
        });
    }
});
