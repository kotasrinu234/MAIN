var ctx = session.name("ILS") || session.createContext("ILS");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var entryDescription = session.parameters.trsevent_ReceiveJobEventILSEntryDescription;
var exitDescription = session.parameters.trsevent_ReceiveJobEventILSExitDescription;
var messageType = session.parameters.messageType 



var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var urlIn = sm.getVar('var://service/URL-in');
		var correlationID;	
		if(incomingData.data[0].id === undefined || incomingData.data[0].id === null || incomingData.data[0].id === ""){	
			
			}else{
		if(urlIn.includes("Create")){
		if(incomingData.data[0].createdAt === undefined || incomingData.data[0].createdAt ===null || incomingData.data[0].createdAt === ""){
			ctx.setVariable("correlationID", incomingData.data[0].id)
		}
		else {
			var correlationID = incomingData.data[0].id + ":" + incomingData.data[0].createdAt
				ctx.setVariable("correlationID", correlationID)
			}
		}else{
			
		
			
			if(incomingData.eventTime === undefined || incomingData.eventTime === null || incomingData.eventTime === ""){
			ctx.setVariable("correlationID", incomingData.data[0].id)
		}
		else {
			var correlationID = incomingData.data[0].id + ":" + incomingData.eventTime
				ctx.setVariable("correlationID", correlationID)
			}
		}		
				
			}
			
		ctx.setVariable("messageType", messageType)	
		if(incomingData.data[0].id != undefined ){
			ctx.setVariable("jobID", incomingData.data[0].id)
		}	
			if(incomingData.data[0].displayID != undefined ){
			ctx.setVariable("jobDisplayID", incomingData.data[0].displayID)
		}	
		
		if(urlIn.includes("Create")){
			if(incomingData.data[0].createdAt != undefined ){
			ctx.setVariable("sourceEventTimestamp", incomingData.data[0].createdAt)
		}
			}else{
				if(incomingData.eventTime != undefined ){
			ctx.setVariable("sourceEventTimestamp", incomingData.eventTime)
		}
			}
			
		ctx.setVariable("sourceUrl", urlIn)
		
		ctx.setVariable("entryDescription", entryDescription)
		ctx.setVariable("exitDescription", exitDescription)
		    var urlIn = sm.getVar('var://service/URL-in');
			if(urlIn.includes("Update")){
					ctx.setVariable("exitDestination", 'dpmq://trsevent_ReceiveJobEvent_QM/?PublishTopicString=TROUBLE/STATUS/events/JobStatus/Update')
			}else if(urlIn.includes("Create")){
				ctx.setVariable("exitDestination",'dpmq://trsevent_ReceiveJobEvent_QM/?PublishTopicString=TROUBLE/STATUS/events/JobStatus/Create')
			}
	
	

}
});




