<xsl:stylesheet version="1.0" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config">

	<xsl:template match="/">
		<xsl:variable name="systemErrorCode"
			select="dp:variable('var://service/error-protocol-response')" />

		<xsl:variable name="dpErrorMessage"
			select="dp:variable('var://service/error-protocol-reason-phrase')" />


		<json:object xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
			<json:object name="fault">
				<json:string name="faultcode">
					<xsl:value-of select="$systemErrorCode" />
				</json:string>
				<json:object name="detail">
					<json:string name="faultstring">
						<xsl:value-of select="$dpErrorMessage" />
					</json:string>
				</json:object>
			</json:object>
		</json:object>
<xsl:choose>
            <!-- When dpErrorMessage is equal to 'unauthorized' -->
            <xsl:when test="$systemErrorCode = '401'">
                <xsl:message dp:type="all" dp:priority="error">
                    trsevnt_rje_004:AAA failure for username:
                    <xsl:value-of select="dp:variable('var://context/WSM/identity/username')" /> |
                    errorString: <xsl:value-of select="concat('ErrorCode =', $systemErrorCode, ',', 'Error Message = ', $dpErrorMessage)" />
                </xsl:message>
            </xsl:when>
			<xsl:when test="contains(dp:variable('var://service/error-message'),'Invalid object syntax' )">
			 <xsl:message dp:type="all" dp:priority="error"><xsl:value-of select="concat('ErrorCode =', $systemErrorCode, ',', 'Error Message = ', $dpErrorMessage)" />
                </xsl:message>
			 </xsl:when>
			 <xsl:when test="contains(dp:variable('var://service/error-message'),'Internal Error' )">
			 <xsl:message dp:type="all" dp:priority="error">trsevnt_rje_004:Could not place the message to Queue|errorString:<xsl:value-of select="concat('ErrorCode =', $systemErrorCode, ',', 'Error Message = ', $dpErrorMessage)" />
                </xsl:message>
			 </xsl:when>
            <!-- When dpErrorMessage is NOT equal to 'unauthorized' -->
            <xsl:otherwise>
                <xsl:message dp:type="all" dp:priority="error"><xsl:value-of select="concat('ErrorCode =', $systemErrorCode, ',', 'Error Message = ', $dpErrorMessage)" />
				</xsl:message>
            </xsl:otherwise>
        </xsl:choose>										
	</xsl:template>
</xsl:stylesheet>
