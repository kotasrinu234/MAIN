var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
    var ctx = session.name("trsevent") || session.createContext("trsevent");
	var ilsctx = session.name("ILS") || session.createContext("ILS");
	var retry = ctx.getVariable('retry');
	var ErrorTxt = ilsctx.getVariable('ExitDescription');
	var ExitStatus = ilsctx.getVariable('ExitStatus');
	
	if(retry == 'yes'){
	ilsctx.setVariable('exitStatus', ExitStatus);
	ilsctx.setVariable('exitDestination','SEQ.REQUEST');
	ilsctx.setVariable('Exitdescription',ErrorTxt)
	}
	}
	});
