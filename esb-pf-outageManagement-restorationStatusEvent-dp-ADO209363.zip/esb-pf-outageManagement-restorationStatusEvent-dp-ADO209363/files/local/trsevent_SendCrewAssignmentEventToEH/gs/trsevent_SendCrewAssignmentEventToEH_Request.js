var ctx = session.name("trsevent") || session.createContext("trsevent");
var SeqQueueURL = session.parameters.SeqQueueURL
var SeqRequest = require('./SeqQueueCall.js');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsBuffer(function(error, json) {
	if (error) {
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
		logger.error("Error in reading incoming json" + JSON.stringify(error));
		session.reject("error in reading incoming json" + JSON.stringify(error));
	} else {
		var date = new Date();
		var incomingdata = JSON.parse(json);

		var diaplayID = incomingdata.data[0].displayID
		var eventTime = incomingdata.eventTime

		if (!(diaplayID === undefined || diaplayID === null || diaplayID === '') && !(eventTime === undefined || eventTime === null || eventTime === '')) {
			var messageId = incomingdata.data[0].displayID + ":" + incomingdata.eventTime;
		} else {
			if (!(diaplayID === undefined || diaplayID === null || diaplayID === '')) {
				var messageId = incomingdata.data[0].displayID + ":"
			}
			if (!(eventTime === undefined || eventTime === null || eventTime === '')) {
				var messageId = eventTime + ":"
			}
		}
		session.output.write(incomingdata)
		var workTypeID = incomingdata.data[0].workTypeID
		var buff = new Buffer((json));
		var EncodedpayloadMessage = buff.toString('base64');
		var eventHubsPayload = {
			"messageId": messageId,
			"serviceName": "interface3",
			"expiry": session.parameters.expiry,
			"eventType": "update",
			"payload": EncodedpayloadMessage,
			"sendTimeStamp": date.toISOString(),
			"waitTime": session.parameters.waitTime,
			"messageType": "updateEvent",
			"workFlowRequirementEvent": "Y"
		}

		ctx.setVariable('EventHubsPayload', eventHubsPayload)
		if (!(diaplayID === undefined || diaplayID === null || diaplayID === '')) {
			eventHubsPayload.eventContext = diaplayID
			eventHubsPayload.crewAssignmentDisplayID = diaplayID
			eventHubsPayload.eventKey = diaplayID
		}
		if (!(eventTime === undefined || eventTime === null || eventTime === '')) {
			eventHubsPayload.EventTimeStamp = eventTime
		}
		if (!(incomingdata.data[0].id === undefined || incomingdata.data[0].id === null || incomingdata.data[0].id === '')) {
			eventHubsPayload.crewAssignmentID = incomingdata.data[0].id
		}
		if (!(incomingdata.data[0].jobID === undefined || incomingdata.data[0].jobID === null || incomingdata.data[0].jobID === '')) {
			eventHubsPayload.jobID = incomingdata.data[0].jobID
		}
		if (!(incomingdata.data[0].job === undefined || incomingdata.data[0].job === null || incomingdata.data[0].job === '')) {
			if (!(incomingdata.data[0].job.displayID === undefined || incomingdata.data[0].job.displayID === null || incomingdata.data[0].job.displayID === '')) {
				eventHubsPayload.jobDisplayID = incomingdata.data[0].job.displayID
			}
		}


		var LookupPayload = {
			"lookupReq": {
				"type": [
					{
						"name": "workTypes",
						"id": workTypeID,
						"status": "none"
					}
				]
			}
		};
		var LinksLookup = {
			target: session.parameters.LookUpURL,
			method: 'POST',
			contentType: 'application/json',
			data: LookupPayload
		};
		var info = " TargetURL: " + LinksLookup.target + "; Method: " + LinksLookup.method + "; Data: " + JSON.stringify(LinksLookup.data) + ". ";
		urlopen.open(LinksLookup, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'WorkType Lookup', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'WorkType Lookup', details are :" + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							ctx.setVariable('workTypeLookupResp', responseData)
							if (responseData.lookupRep.type[0].result == 1) {
								var invalidresp = "Invalid Lookup Request 'WorkType Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', '1');
								ILSctx.setVariable('ExitDescription', invalidresp);
								logger.error(invalidresp);
								session.reject(invalidresp)
							} else {
								var workTypeLabel = responseData.lookupRep.type[0].label
								var workFlowId = responseData.lookupRep.type[0].id

								var ConfigurableworkTypeLabel = session.parameters.ConfigurableworkTypeLabel
								if (ConfigurableworkTypeLabel.includes(workTypeLabel)) {
									eventHubsPayload.workFlowType = workTypeLabel
									var status = incomingdata.data[0].status
									var WorkFlowLookupPayload = {
										"lookupReq": {
											"type": [
												{
													"name": "workType.workflows",
													"id": workTypeID,
													"status": status
												}
											]
										}
									};
									ctx.setVariable('testingPay', WorkFlowLookupPayload)
									var WorkFlowLookup = {
										target: session.parameters.LookUpURL,
										method: 'POST',
										contentType: 'application/json',
										data: WorkFlowLookupPayload
									};
									var info = " TargetURL: " + WorkFlowLookupPayload.target + "; Method: " + WorkFlowLookupPayload.method + "; Data: " + JSON.stringify(WorkFlowLookupPayload.data) + ". ";
									urlopen.open(WorkFlowLookup, function(error, response) {
										if (error) {
											var errorinfo = "url connection error 'WorkType Lookup', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', '500');
											ILSctx.setVariable('ExitDescription', errorinfo)
											logger.error(errorinfo);
											ctx.setVariable("retry", 'yes');
											ctx.setVariable("ErrorTxt", errorinfo);

										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsJSON(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'WorkType Lookup', details are :" + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														//ctx.setVariable('LabelLookupResp', responseData)
														if (responseData.lookupRep.type[0].result == 1) {
															var invalidresp = "Invalid Lookup Request 'assignmentStatus Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
															ILSctx.setVariable('ExitStatus', '1');
															ILSctx.setVariable('ExitDescription', invalidresp);
															logger.error(invalidresp);
															session.reject(invalidresp)
														} else {
															if (!(responseData.lookupRep.type[0].label === undefined || responseData.lookupRep.type[0].label === null || responseData.lookupRep.type[0].label === '')) {
																eventHubsPayload.assignmentStatus = responseData.lookupRep.type[0].label
																var workFlowType = workTypeLabel
																var assignmentStatus = responseData.lookupRep.type[0].label
																fs.readAsJSON("local:/trsevent_SendCrewAssignmentEventToEH/gs/workTypeTable.json", function(readAsJSONError, jsonInternal) {
																	if (readAsJSONError) {
																		session.reject(readAsJSONError);
																	}
																	else {
																		var sendEvent = false;
																		for (var i = 0; i < jsonInternal.workTypeTable.length; i++) {
																			if (jsonInternal.workTypeTable[i].workType === workFlowType) {
																				if (jsonInternal.workTypeTable[i].CrewAssignmentStatus === assignmentStatus) {
																					sendEvent = true
																					break;
																				} else {
																					sendEvent = false
																					break;
																				}
																			} else {
																				sendEvent = true
																			}
																		}
																		if (sendEvent === true) {
																			SeqRequest(SeqQueueURL, eventHubsPayload)
																			ILSctx.setVariable('exitStatus', '0');
																			ILSctx.setVariable('exitDestination', 'SEQ.REQUEST');
																			var Exitdescription = session.parameters.ExitDescription
																			ILSctx.setVariable('Exitdescription', Exitdescription);
																			session.output.write(eventHubsPayload)
																		}
																	}
																})
															} else {
																var invalidresp = "Invalid label 'assignmentStatus Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
																ILSctx.setVariable('ExitStatus', '1');
																ILSctx.setVariable('ExitDescription', invalidresp);
																logger.error(invalidresp);
																session.reject(invalidresp)
															}

														}
													}
												})
											} else {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "failure reading the error response 'WorkType Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', responseStatusCode);
														ILSctx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														var errorinfo = "error response 'WorkType Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', responseStatusCode);
														ILSctx.setVariable('ExitDescription', errorinfo);
														hm.current.statusCode = responseStatusCode;
														logger.error(errorinfo);
														ctx.setVariable("retry", 'yes');
														ctx.setVariable("ErrorTxt", errorinfo);
													}
												});
											}
										}
									});
								}
							}
						}
					})
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure reading the error response 'WorkType Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "error response 'WorkType Lookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							hm.current.statusCode = responseStatusCode;
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
						}
					});
				}
			}
		});
	}
});
