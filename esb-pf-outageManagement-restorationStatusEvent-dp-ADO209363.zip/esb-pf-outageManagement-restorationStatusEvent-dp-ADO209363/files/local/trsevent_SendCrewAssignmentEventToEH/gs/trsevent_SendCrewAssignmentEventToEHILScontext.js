var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var ctx = session.name('ils') || session.createContext('ils');
/*var messageType = session.parameters.messageType;
ctx.setVariable('messageType', messageType);*/
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
        var incomingdata = incomingdata;
ctx.setVariable("payload", incomingdata)
        var correlationID;
        if (incomingdata.eventTime != undefined) {
            correlationID = incomingdata.data[0].displayID + ':' + incomingdata.eventTime
        } else {
            correlationID = incomingdata.data[0].displayID
        }
       
        var Exitdescription = session.parameters.trsevent_SendCrewAssignmentEventToEHIlsExitdescription;
       
        ctx.setVariable('correlationID', correlationID);
       
        
        if (Exitdescription != undefined) {
            ctx.setVariable('Exitdescription', Exitdescription);
        }
    }
});
