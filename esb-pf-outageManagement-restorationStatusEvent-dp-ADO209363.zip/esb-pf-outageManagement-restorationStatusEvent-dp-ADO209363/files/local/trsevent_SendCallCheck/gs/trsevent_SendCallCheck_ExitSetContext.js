var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
	
	var ctx = session.name('trsevent')|| session.createContext('trsevent');	
	var jsondecodedpayload = ctx.getVariable("requestJsonDecoded");
		var decodedPayload = JSON.parse(jsondecodedpayload);
		var correlationID;		
		if(decodedPayload.eventTime === undefined){
			correlationID= decodedPayload.data[0].displayID
		}
		else{
			correlationID= decodedPayload.data[0].displayID+':'+decodedPayload.eventTime
		}
		var callID= decodedPayload.data[0].id;
		var callDisplayID = decodedPayload.data[0].displayID
		var jobID = decodedPayload.data[0].jobID
		var jobDisplayID = decodedPayload.data[0].jobDisplayID
		var callCode = decodedPayload.data[0].externalCallCodeID
		var premiseID = decodedPayload.data[0].externalPremiseID
		var sourceEventTimestamp = decodedPayload.eventTime
		var description = session.parameters.IlsExitDescription;
		var retry = ctx.getVariable('retry');
		var ErrorTxt = ctx.getVariable('ErrorTxt')
		var ctx = session.name('ilsExit')|| session.createContext('ilsExit');
		if(retry != 'yes'){
		ctx.setVariable('exitStatus','0');
		ctx.setVariable('exitDestination','TROUBLE/STATUS/events/CallStatus');
		}else{
		ctx.setVariable('exitStatus','');
		ctx.setVariable('exitDestination','TROUBLE/STATUS/events/CallStatus');
		ctx.setVariable('Exitdescription',ErrorTxt)
		}
                
		ctx.setVariable('correlationID',correlationID);
		ctx.setVariable("sourceUrl",'TTRSEVNT.EFC.CALL.CHECK.RESPONSE');
		if(callID != undefined){
			ctx.setVariable('callID',callID);
		}
		if(callDisplayID != undefined){
			ctx.setVariable('callDisplayID',callDisplayID);
		}
		if(jobID  != undefined){
			ctx.setVariable('jobID',jobID);
		}		
		if(jobDisplayID  != undefined){
			ctx.setVariable('jobDisplayID',jobDisplayID);
		}
		if(callCode  != undefined){
			ctx.setVariable('callCode',callCode);
		}
		if(premiseID  != undefined){
			ctx.setVariable('premiseID',premiseID);
		}
		if(sourceEventTimestamp  != undefined){
			ctx.setVariable('sourceEventTimestamp',sourceEventTimestamp);
		}
		if(description  != undefined){
			ctx.setVariable('description',description);
		}
		
	}
});
