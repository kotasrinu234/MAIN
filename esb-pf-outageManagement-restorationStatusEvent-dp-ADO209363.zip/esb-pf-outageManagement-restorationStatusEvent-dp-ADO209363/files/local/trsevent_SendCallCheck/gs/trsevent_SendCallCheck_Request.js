var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("trsevent") || session.createContext("trsevent");

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {
		ctx.setVariable('IncomingPayload', incomingdata);
		var base64encode = incomingdata.payload;


		//var decodedString = base64Decode(base64encode.replace(/\0/g, ''));
		var decodedString = new Buffer.from(base64encode, 'base64').toString();
		//var decodedString2 = JSON.parse(decodedString);
		var requestJsonDecoded = JSON.stringify(decodedString);
		requestJsonDecoded = JSON.parse(requestJsonDecoded)
		ctx.setVariable('requestJsonDecoded', requestJsonDecoded);
                session.output.write(requestJsonDecoded);

		var PublishTopicUrl = session.parameters.PublishTopicUrl

		var pushingToQueue = {
			target: PublishTopicUrl,
			data: requestJsonDecoded
		};

		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.error("error while publishing message to PublishTopicString=TROUBLE/STATUS/events/CallStatus " + error);
				//session.reject(" error while publishing message to queue is " + error);
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "Trsevent_SCC_001 : urlopen connect error while Publishing the payload to PublishTopicString=TROUBLE/STATUS/events/CallStatus " + error;
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var mqrc = response.statusCode;

				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							session.reject("error while publishing message to queue is " + error);
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {

					logger.error("response code for urlopen.open error [MQRC=" + mqrc + "]");

					ctx.setVariable("retry", 'yes');
					var ErrorTxt = "Trsevent_SCC_001 : urlopen connect error while Publishing the payload to PublishTopicString=TROUBLE/STATUS/events/CallStatus " + error;
					ctx.setVariable("ErrorTxt", ErrorTxt);
                                        //session.reject(" response code for urlopen.open error [MQRC=" + mqrc + "]");

				}
			}
		})
	}
})
