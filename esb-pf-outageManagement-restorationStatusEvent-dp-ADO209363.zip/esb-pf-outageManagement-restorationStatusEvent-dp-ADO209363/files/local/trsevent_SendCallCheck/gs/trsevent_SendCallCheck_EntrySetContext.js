var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

var ctx = session.name('ilsEntry')|| session.createContext('ilsEntry');


session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
		var incomingdata =incomingdata;
		var correlationID;
		correlationID= incomingdata.messageId
		var callDisplayID = incomingdata.eventContext
		var sourceEventTimestamp = incomingdata.eventTimeStamp
		var description = session.parameters.IlsEntryDescription;
		var messageType = session.parameters.messageType;
		ctx.setVariable('messageType',messageType);
		ctx.setVariable('correlationID',correlationID);
		ctx.setVariable('sourceUrl','TRSEVNT.EFC.CALL.CHECK.RESPONSE');
		if(callDisplayID != undefined){
			ctx.setVariable("callDisplayID",callDisplayID);
		}
		if(sourceEventTimestamp  != undefined){
			ctx.setVariable('sourceEventTimestamp',sourceEventTimestamp);
		}
		if(description  != undefined){
			ctx.setVariable('description',description);
		}
		
	}
});
