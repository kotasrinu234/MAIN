var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
var ILSctx = session.name("ILS")|| session.createContext("ILS");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var headers = hm.current;
var logger = console.options({'category':'all'});
var exitDest = session.parameters.POurl; 
 ILSctx.setVariable("exitDest",exitDest)
function callURL(url, method, myctx,payload) {
	var options = {
        target: url,
        method: method,
        contentType: "application/json",
        sslClientProfile: 'trsevent_SendEventToCRM_SSL_ClientProfile'
    };
	headers.remove('MQMD');
    if (method == "POST" || method=="PATCH") {
        options.data = payload;
    }
 urlopen.open(options, function(error, response) {
        if (error) {
			var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
            // an error occurred during reading the file
			logger.error("trsevnt_sje04: unable to connect MQ " + JSON.stringify(error));
			ctx.setVariable("retry", 'yes');
			ctx.setVariable("ErrorTxt",'trsevnt_sje04 - urlopen.open error- Connection Error' );
			ctx.setVariable("customErrorCode", '500');
			ctx.setVariable("customErrorMessage", 'Connection Error');
			ctx.setVariable("customReasonMessage", 'Connection Error');
			//session.reject("Connection Error");
			ILSctx.setVariable("exitStatus", "500")
			ILSctx.setVariable("exitDescription", "trsevnt_sje04 - urlopen.open error- Connection Error" + JSON.stringify(error))
        } else {
            var responseStatusCode = response.statusCode;
            var responseReasonPhrase = response.reasonPhrase;
			 var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
             ctx.setVariable(myctx+"_responseStatusCode", responseStatusCode);
				ctx.setVariable(myctx+"_response", response);
							
            if (responseStatusCode == 200) {
				response.readAsJSON(function(error,data){
				if(error){
					var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
					logger.error("Error in reading response data");
					throw error;
				}else{
				 var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
				 ctx.setVariable(myctx + '_response',data);	
				 ctx.setVariable("customErrorCode", '0');
				 ILSctx.setVariable("exitStatus", "0")
				
				}
			});
			}else  if (responseStatusCode == 201 || responseStatusCode == 202) {
						 
				logger.info(responseStatusCode +'-' + responseReasonPhrase);
				ctx.setVariable("customErrorCode", 0);
				ILSctx.setVariable("exitStatus", "0")
			
			}else{
			  response.readAsBuffer(function(error, responseData) {
			     if (error) {
					 var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
                         logger.error("failure in reading message" + JSON.stringify(error));
                         ILSctx.setVariable("exitStatus", responseStatusCode)
			             ILSctx.setVariable("exitDescription", "failure in reading message" + JSON.stringify(error))
                        } else {
							var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
							ctx.setVariable(myctx + '_buffer_response',""+responseData);
                         logger.error("response received with responseStatusCode "+responseStatusCode+" "+ responseData);
						 var responseDataStr = ""+responseData;
						 ctx.setVariable(myctx + '_buffer_response2',responseDataStr);
						 if (responseStatusCode == 400 && responseDataStr !=='No updates') {
							ctx.setVariable("customErrorCode", '400');
							ctx.setVariable("customErrorMessage", 'Bad Request');
							ctx.setVariable("customReasonMessage", 'Bad Request');
							ILSctx.setVariable("exitStatus", responseStatusCode)
			               // ILSctx.setVariable("exitDest","response received with responseStatusCode "+responseStatusCode+" "+ responseData)
							session.reject("Bad Request");
							
							}
			     }
			  });
			  
			   			
			if(responseStatusCode == 403){
				ctx.setVariable("customErrorCode", '403');
				ctx.setVariable("customErrorMessage", 'Forbidden');
				ctx.setVariable("customReasonMessage", 'Forbidden');
				ILSctx.setVariable("exitStatus", responseStatusCode)
				session.reject("Forbidden");
				
			   // ILSctx.setVariable("exitDest","Forbidden")
			}else if(responseStatusCode==404){
				ctx.setVariable("customErrorCode", '404');
				ctx.setVariable("customErrorMessage", 'No Records Found');
				ctx.setVariable("customReasonMessage", 'No Records Found');
				ILSctx.setVariable("exitStatus", responseStatusCode)
				session.reject("No Records Found");
			   // ILSctx.setVariable("exitDest","No Records Found")
			}else if(responseStatusCode==500){
				ctx.setVariable("customErrorCode", '500');
				ctx.setVariable("customErrorMessage", 'Server Error');
				ctx.setVariable("customReasonMessage", 'Server Error');
				ILSctx.setVariable("exitStatus", responseStatusCode)
				session.reject("Server Error");
			    //ILSctx.setVariable("exitDest","Server Error")
			}
		}
}
 });
}
module.exports = callURL;
