var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var callURL = require('./callURL.js');
var POurl= session.parameters.POurl;
var CommentsDelimiter=session.parameters.CommentsDelimiter;
var logger = console.options({
    'category': 'all'
});

var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
var dateTime = new Date();
var outageIndicator = ctx.getVariable("jobOutageTypes_lookup")[0].label;
if(outageIndicator == 'UNPLANNED_OUTAGE') {
	var indicator = true;
}
else {
	var indicator = false;
}

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } 
	else {
		    var inReq = incomingdata.data[0];
			ctx.setVariable("jsonPayload",incomingdata);
			var aorID = incomingdata.data[0].aorID;
			//var outageSteps = inReq.outageSteps;
			var region = inReq.regionName;	
		if(aorID !=undefined && aorID !=null && aorID != ''){
		var aors = ctx.getVariable('aors_lookup')[0].label;
		}
			var payload ={};
			payload.JobStatusDetails ={};
			var JobStatusDetails=payload.JobStatusDetails;
			payload.JobStatusDetails.eventType = "Job";
			payload.JobStatusDetails.eventTime = dateTime.toISOString();
			        var urlIn = sm.getVar('var://service/URL-in');

			if(urlIn.includes("TRSEVNT.CRM.JOB.UPDATE.REQUEST")){
					if(incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
		        JobStatusDetails.origEventTime= incomingdata.eventTime;
			}
			}else if(urlIn.includes("TRSEVNT.CRM.JOB.CREATE.REQUEST")){
	if(incomingdata.eventTime != undefined && incomingdata.eventTime != null && incomingdata.eventTime != '') {
      JobStatusDetails.origEventTime= incomingdata.eventTime;
			}else{
				JobStatusDetails.origEventTime= incomingdata.data[0].createdAt;
			}			}
			
			if(inReq.id != undefined && inReq.id != null && inReq.id != '') {
		        JobStatusDetails.id= inReq.id;
			} else throw Error ('id is a mandatory field');
			
			if(inReq.displayID != undefined && inReq.displayID != null && inReq.displayID != '') {
		        JobStatusDetails.jobId= inReq.displayID;
			}
		        JobStatusDetails.jobStatus= ctx.getVariable("jobTypeWorkFlow_lookup")[0].label;
				if(inReq.updatedAt != undefined && inReq.updatedAt != null && inReq.updatedAt != '') {
		        JobStatusDetails.jobUpdateTime= inReq.updatedAt;
			} else throw Error ('updatedAt is a mandatory field');	
			
				var customFieldValuesExt = inReq.customFieldValuesExt 
				if(customFieldValuesExt != undefined && customFieldValuesExt.isAutoClosed != undefined && customFieldValuesExt.isAutoClosed != null){				
		        JobStatusDetails.autoCloseFlag= inReq.customFieldValuesExt.isAutoClosed;
				}
		        JobStatusDetails.jobType= ctx.getVariable("jobTypes_lookup")[0].label;
				
				if(inReq.networkModelType != undefined){
		        JobStatusDetails.extent= ctx.getVariable("networkModelTypeLabels_lookup")[0].label;
				}
				if(inReq.deviceInfo != undefined && inReq.deviceInfo != null && inReq.deviceInfo != '' && inReq.deviceInfo.name != undefined && inReq.deviceInfo.name != null && inReq.deviceInfo.name != ''){ 
		        JobStatusDetails.deviceName= inReq.deviceInfo.name;
				}
				if(indicator != undefined && indicator != null){
		        JobStatusDetails.outageIndicator= indicator;
				}
				if(inReq.etrExpirationStatus != undefined && inReq.etrExpirationStatus != null && inReq.etrExpirationStatus != ''){
				JobStatusDetails.businessException= ctx.getVariable("etrExpirationStatuses_lookup")[0].label;
				}
				if(inReq.createdOperationModeID != undefined && inReq.createdOperationModeID != null && inReq.createdOperationModeID != ''){
		        JobStatusDetails.operationMode= ctx.getVariable("operationModes_lookup")[0].label;
				}
				if(inReq.etrStatus != undefined && inReq.etrStatus != null && inReq.etrStatus != ''){
				JobStatusDetails.estType= inReq.etrStatus;
				}
				if(inReq.nominalFeeder != undefined && inReq.nominalFeeder != null && inReq.nominalFeeder != ''){
		        JobStatusDetails.circuit= inReq.nominalFeeder;
				}
				if(inReq.customFieldValuesExt != undefined && inReq.customFieldValuesExt != null && inReq.customFieldValuesExt != ''&& inReq.customFieldValuesExt.cause != undefined && inReq.customFieldValuesExt.cause != null && inReq.customFieldValuesExt.cause != ''){
		        JobStatusDetails.causeCode= inReq.customFieldValuesExt.cause;
				}
				if(inReq.publishedEtr != undefined && inReq.publishedEtr != null && inReq.publishedEtr != ''&& inReq.publishedEtr.value != undefined && inReq.publishedEtr.value != null && inReq.publishedEtr.value != ''){
				JobStatusDetails.ert= inReq.publishedEtr.value;
				}
				if(region != undefined && region != null && region != '') {
				JobStatusDetails.region= region.substring(0,2);
				}
				if(inReq.aorID != undefined && inReq.aorID != null && inReq.aorID != ''){
				JobStatusDetails.serviceCenter= aors.substring(0,3);
				}
				if(inReq.totalAffected != undefined && inReq.totalAffected != null ){
				JobStatusDetails.customersAffected= inReq.totalAffected;
				}
				if(inReq.currentAffected != undefined && inReq.currentAffected != null ){
				JobStatusDetails.customersStillOut= inReq.currentAffected;
				}
				
//start of comments
				
			if (!(inReq.comments === undefined || inReq.comments === '' || inReq.comments === null)){
				var Incomingcomments = [];	
				Incomingcomments = inReq.comments;
				Incomingcomments = Incomingcomments.sort(sortFunction);
				var remarks = "";
				if (Incomingcomments.length > 0) {
					var GMTDate, ESTDateVar, ESTDate,localOffset,offset,utc;;
					for (var p = 0; p < Incomingcomments.length; p++) {
						if (!(Incomingcomments[p].deprecated)) {
							GMTDate = new Date(Incomingcomments[p].createdAt);
							ESTDateVar = GMTDate.getTime();
							localOffset = GMTDate.getTimezoneOffset() * 60000;
							offset = -5;
							utc = ESTDateVar + (3600000*offset);
							ESTDate = new Date(utc).toISOString();
							//logger.error("CommentsDelimiter+++"+CommentsDelimiter);
							remarks = remarks + ESTDate + ':' + Incomingcomments[p].comment+ CommentsDelimiter;
							//remarks = remarks + ESTDate + CommentsDelimiter + Incomingcomments[p].comment;
							logger.info("remarks in loop is " + remarks);
							//JobStatusDetails.remarks = remarks;
						}
					}
					
					var commentslength=parseInt(session.parameters.commentslengthvalue);
					
					if(remarks.length>commentslength){
						remarks = remarks.substr(0,commentslength);
						JobStatusDetails.remarks = remarks;
					}else{
						var remarksfinal = remarks.substring(0,remarks.length-1);
						JobStatusDetails.remarks = remarksfinal;
					}
				}

			}else{
				JobStatusDetails.remarks = "";
			}
			
			//logger.error("JobStatusDetails.remarks+++"+JobStatusDetails.remarks);
			function sortFunction(a,b){  
				var dateA = new Date(a.createdAt).getTime();
				var dateB = new Date(b.createdAt).getTime();
				return dateA < dateB ? 1 : -1;  
			};
//end of comments			
						
						
			var inputLinks = inReq.links;
			var linkedJobs =new Array();
			var linkedJob;
			if(inputLinks != undefined && inputLinks != null && inputLinks != '' && inputLinks.length != 0) {
			for(var i=0;i<inputLinks.length;i++) {	
				linkedJob = {};	
				linkedJob.id=inputLinks[i].linkedID;	
				linkedJob.jobId=inputLinks[i].linkedDisplayID;
				linkedJobs.push(linkedJob);	 						
			}
			payload.JobStatusDetails.LinkedJobs = linkedJobs;
			}			
					
			ctx.setVariable("payload", payload);
			session.output.write(payload);
			callURL(POurl,"POST","POResp",payload);
	}
})
