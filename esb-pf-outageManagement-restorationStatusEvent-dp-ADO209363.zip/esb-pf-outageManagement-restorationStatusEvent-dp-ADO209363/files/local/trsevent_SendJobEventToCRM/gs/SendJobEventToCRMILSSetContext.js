var ctx = session.name("ILS") || session.createContext("ILS");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');



var entryDescription = session.parameters.SJECILSEntryDescription;
var exitDescription = session.parameters.SJECILSExitDescription;
var messageType = session.parameters.messageType;





var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var urlIn = sm.getVar('var://service/URL-in');
		var correlationID;
		if (incomingData.data[0].id === undefined || incomingData.data[0].id === null || incomingData.data[0].id === "") {
		} else {
			var eventTime = incomingData.eventTime
			if (urlIn.includes('CREATE')) {
				if (incomingData.data[0].createdAt !== undefined || incomingData.data[0].createdAt !== null || incomingData.data[0].createdAt !== "") {
					var correlationID = incomingData.data[0].id + ":" + incomingData.data[0].createdAt
					ctx.setVariable("correlationID", correlationID)
					ctx.setVariable("sourceUrl", 'TRSEVNT.EFC.JOB.CREATE.REQUEST');
				}
			}
			else if (urlIn.includes('UPDATE')) {
				if (eventTime !== undefined || eventTime !== null || eventTime !== "") {
					var correlationID = incomingData.data[0].id + ":" + eventTime
					ctx.setVariable("correlationID", correlationID)
					ctx.setVariable("sourceUrl", 'TRSEVNT.EFC.JOB.UPDATE.REQUEST');
				}
			}
			else {
				ctx.setVariable("correlationID", incomingData.data[0].id)
			}
		}
		ctx.setVariable("messageType", messageType)
		if (incomingData.data[0].id != undefined) {
			ctx.setVariable("jobID", incomingData.data[0].id)
		}
		if (incomingData.data[0].displayID != undefined) {
			ctx.setVariable("jobDisplayID", incomingData.data[0].displayID)
		}
		if (eventTime != undefined) {
			ctx.setVariable("sourceEventTimestamp", eventTime)
		}
		else if (incomingData.data[0].createdAt != undefined) {
			ctx.setVariable("sourceEventTimestamp", incomingData.data[0].createdAt)
		}
		if (entryDescription !== undefined || entryDescription !== null || entryDescription !== "") {
			ctx.setVariable("entryDescription", entryDescription)
		}
		if (exitDescription !== undefined || exitDescription !== null || exitDescription !== "") {
			ctx.setVariable("exitDescription", exitDescription)
		}
		
		
	}
});