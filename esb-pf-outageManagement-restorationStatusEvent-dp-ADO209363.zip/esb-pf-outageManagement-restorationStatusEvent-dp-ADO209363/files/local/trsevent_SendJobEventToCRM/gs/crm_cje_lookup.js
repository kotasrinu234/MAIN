var ctx = session.name("cjobEvent")|| session.createContext("cjobEvent");
var urlopen = require('urlopen');
var logger = console.options({'category':'all'});
var lookupUrl = session.parameters.lookupURL;
//var url = "http://localhost:8080/lookup"; 

function doLookup(arrObj,lookupCtx,uri){
	//console.error("array length " + arrObj.length);
var request = {};
request.type= arrObj;
var options = {
  target: lookupUrl+uri,
  method: 'post',
  contentType: 'application/json',
  data:{"lookupReq": request}
}; 

// open connection to target
urlopen.open (options, function (error, response) {
	var ctx = session.name('cjobEvent') || session.createContext('cjobEvent');
    if (error) {
                  ctx.setVariable("customErrorCode", error.errorCode);
		ctx.setVariable("customErrorMessage", error.errorMessage);
		ctx.setVariable("customReasonPhrase", error.errorMessage);
		session.output.write ("urlopen error: " + JSON.stringify(error));
session.reject(error.errorMessage);
        
    } else {
        var responseStatusCode = response.statusCode;
        if (responseStatusCode == 200) {
            response.readAsJSON(function(error, responseData) {
                var ctx = session.name('cjobEvent') || session.createContext('cjobEvent');
				//ctx.setVariable('lookupResponseData', responseData);
				if (error) {
                    // error while reading response or transferring data to Buffer
					session.output.write("readAsBuffer error: " + JSON.stringify(error));
                } else {
					var lookupResponse = responseData.lookupRep.type;
					ctx.setVariable(lookupCtx+"_lookup", lookupResponse);
                } 
            });
        } else {
			response.readAsBuffer(function(error, responseData) {
			                                    if (error) {
			                                           logger.error("failure in reading message" + JSON.stringify(error));
			                                           
			                                    } else {
			                                           logger.error("response received "+responseStatusCode+" "+ responseData);
													   session.output.write ("response received "+responseStatusCode+" "+ responseData);
			                                         
			                                      }
			                             });
			
            
        }
    }
});
/* 
 */

	
}//end of function 

module.exports = doLookup;
