<?xml version="1.0" encoding="utf-8"?>
<!-- This XSLT is used to set the headers in the request to IIB -->
<xsl:stylesheet
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:msxsl="urn:schemas-microsoft-com:xslt"
    xmlns:dp="http://www.datapower.com/extensions"
    xmlns:date="http://exslt.org/dates-and-times"
    xmlns:dyn="http://exslt.org/dynamic" extension-element-prefixes="dp date" exclude-result-prefixes="dp date msxsl dyn">
    <xsl:output method="xml" encoding="utf-8" indent="yes"/>
    <xsl:variable name="HeaderProperties" select="document('local:///trsevent_SendJobEventToCRM/xml/trsevent_SendJobEventToCRM_Header_properties.xml')"/>
    <xsl:template match="/">
        <xsl:variable name="retryvalue">
            <xsl:copy-of select="dp:variable('var://context/cjobEvent/retry')" />
        </xsl:variable>
        <xsl:if test="contains($retryvalue,'yes')">
            <xsl:variable name="mqmd-headers" select="dp:variable('var://context/MQMD/MQMDRequestHeaders')"/>
            <xsl:variable name="CorrelId-RQ" select="dp:variable('var://context/store/msgId')"/>
            <xsl:variable name="MsgId-RQ" select="dp:variable('var://context/store/msgId')"/>
            <xsl:message dp:priority="debug">
                <xsl:value-of select="concat('The Request MQMD : ', $CorrelId-RQ)"/>
            </xsl:message>
            <xsl:variable name="current-headers" select="$mqmd-headers"/>
            <xsl:variable name="MQMDStr">
                <MQMD>
                    <xsl:for-each select="$current-headers/MQMD/*[local-name()]">
                        <xsl:variable name="header-name" select="local-name()"/>
                        <xsl:choose>
                            <xsl:when test="((normalize-space($header-name) = 'CorrelId') and ($CorrelId-RQ != '000000000000000000000000000000000000000000000000'))">
                                <xsl:element name="CorrelId">
                                    <xsl:value-of select="$MsgId-RQ"/>
                                </xsl:element>
                            </xsl:when>
                            <xsl:when test="(normalize-space($header-name) = 'Version')">
                                <xsl:element name="Version">
                                    <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQMD/Version/text()"/>
                                </xsl:element>
                            </xsl:when>
                            <xsl:when test="(normalize-space($header-name) = 'Format')">
                                <xsl:element name="Format">
                                    <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQMD/Format/text()"/>
                                </xsl:element>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:element name="{$header-name}">
                                    <xsl:value-of select="."/>
                                </xsl:element>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:for-each>
                </MQMD>
            </xsl:variable>
           <xsl:variable name="entriesMQRFH2" select="dp:request-header('MQRFH2')" />
            <xsl:if test="normalize-space($entriesMQRFH2)!=''">
                <xsl:variable name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)" />
                <!-- Placing the MQMD headers in the context variables -->
                <dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value="$mqrfh2-headers" />
            </xsl:if>
            <xsl:if
				test="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')">
                <xsl:variable name="mqrfh2" select="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')" />
                <xsl:variable name="CurrentCount" select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='CurrentCount'])" />
                <xsl:variable name="LastRetry" select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='LastRetry'])" />
                <dp:set-variable name="'var://context/RetryContext/LastRetry'" value="$LastRetry" />
                <xsl:if
					test="$CurrentCount = 'undefined' or $CurrentCount = 'null' or $CurrentCount = ''">
                    <dp:set-variable name="'var://context/RetryContext/CurrentCount'" value="'0'" />
                    <xsl:variable name="CurrentCount" select="'0'"></xsl:variable>
                </xsl:if>
                <dp:set-variable name="'var://context/RetryContext/CurrentCount'" value="$CurrentCount" />
            </xsl:if>
            <xsl:variable name="ErrorMessage">
                <xsl:copy-of select="dp:variable('var://context/cjobEvent/ErrorTxt')" />
            </xsl:variable>
            <xsl:variable name="MQRFH2Request">
                <MQRFH2>
                    <StrucId>
                        <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQRFH2/StrucId/text()"/>
                    </StrucId>
                    <Version>
                        <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQRFH2/Version/text()"/>
                    </Version>
                    <Format>
                        <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQRFH2/Format/text()"/>
                    </Format>
                    <CodedCharSetId>
                        <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQRFH2/CodedCharSetId/text()"/>
                    </CodedCharSetId>
                    <Flags>
                        <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQRFH2/Flags/text()"/>
                    </Flags>
                    <NameValueCCSID>
                        <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQRFH2/NameValueCCSID/text()"/>
                    </NameValueCCSID>
                    <NameValueData>
                        <NameValue>
                            <usr>
                                <xsl:variable name="mqrfh2-headers" select="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')"/>
                                <xsl:variable name="mqrfh2HeaderTS" select="$mqrfh2-headers//Timestamp"/>
                                <xsl:choose>
                                    <xsl:when test="not($mqrfh2HeaderTS)">
                                        <Timestamp>
                                            <xsl:variable name="timestamp" select="date:date-time()"/>
                                            <xsl:variable name="ZuluTime" select="date:add($timestamp,'PT0H')"/>
                                            <xsl:variable name="ms" select="substring(dp:time-value(),11,3)"/>
                                            <xsl:value-of select="concat(substring($ZuluTime,1,19),'Z')"/>
                                        </Timestamp>
                                    </xsl:when>
                                    <xsl:otherwise>
                                        <Timestamp>
                                            <xsl:value-of select="$mqrfh2HeaderTS"/>
                                        </Timestamp>
                                    </xsl:otherwise>
                                </xsl:choose>
                                <Sleep>
                                    <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/Sleep/text()"/>
                                </Sleep>
                                <RetryTime>
                                    <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/RetryTime/text()"/>
                                </RetryTime>
                                <xsl:variable name="routingUrl" select="dp:variable('var://service/URL-in')"/>
                                <dp:set-variable name="'var://context/RTQ/SS'" value="$routingUrl"/>
                                <!-- <xsl:variable name="ReplyToQMgr"><xsl:value-of select="substring-before(substring-after($routingUrl,'//'),'/')"/></xsl:variable> -->
                                <xsl:variable name="ReplyToQMgr" select="substring-before(substring-after($routingUrl,'//'),'/')"/>
                                <dp:set-variable name="'var://context/RTQ/QM'" value="$ReplyToQMgr"/>
                                <xsl:message dp:priority="info">
                                QMMM:: 
                                    <xsl:value-of select="$ReplyToQMgr"/>
                                </xsl:message>
                                <xsl:variable name="QueueManager">
                                    <xsl:value-of select="concat('$HeaderProperties/MQ_HeaderValues/Interfaces/',$ReplyToQMgr,'/QueueManager/text()')"/>
                                </xsl:variable>
                                <QueueManager>
                                    <xsl:value-of select="dyn:evaluate($QueueManager)"/>
                                </QueueManager>
                                <xsl:variable name="OutputDestinationQueue">
                                    <xsl:value-of select="concat('$HeaderProperties/MQ_HeaderValues/Interfaces/',$ReplyToQMgr,'/OutputDestinationQueue/text()')"/>
                                </xsl:variable>
                                <OutputDestinationQueue>
                                    <xsl:value-of select="dyn:evaluate($OutputDestinationQueue)"/>
                                </OutputDestinationQueue>
                                <xsl:variable name="LoggingQueue">
                                    <xsl:value-of select="concat('$HeaderProperties/MQ_HeaderValues/Interfaces/',$ReplyToQMgr,'/LoggingQueue/text()')"/>
                                </xsl:variable>
                                <LoggingQueue>
                                    <xsl:value-of select="dyn:evaluate($LoggingQueue)"/>
                                </LoggingQueue>
                                <xsl:variable name="Host">
                                    <xsl:value-of select="concat('$HeaderProperties/MQ_HeaderValues/Interfaces/',$ReplyToQMgr,'/Host/text()')"/>
                                </xsl:variable>
                                <Host>
                                    <xsl:value-of select="dyn:evaluate($Host)"/>
                                </Host>
                                <xsl:variable name="Port">
                                    <xsl:value-of select="concat('$HeaderProperties/MQ_HeaderValues/Interfaces/',$ReplyToQMgr,'/Port/text()')"/>
                                </xsl:variable>
                                <Port>
                                    <xsl:value-of select="dyn:evaluate($Port)"/>
                                </Port>
                                <xsl:variable name="Channel">
                                    <xsl:value-of select="concat('$HeaderProperties/MQ_HeaderValues/Interfaces/',$ReplyToQMgr,'/Channel/text()')"/>
                                </xsl:variable>
                                <Channel>
                                    <xsl:value-of select="dyn:evaluate($Channel)"/>
                                </Channel>
                                <ProcessorName>
                                    <xsl:value-of select="dp:variable('var://service/processor-name')"/>
                                </ProcessorName>
                                <DomainName>
                                    <xsl:value-of select="dp:variable('var://service/domain-name')"/>
                                </DomainName>
                                <DataPowerBackendUrl>
                                    <xsl:value-of select="dp:variable('var://service/routing-url')"/>
                                </DataPowerBackendUrl>
                                <InterfaceNo>
                                    <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQRFH2/InterfaceNo/text()"/>
                                </InterfaceNo>
                                <Alert>
                                    <xsl:value-of select="$HeaderProperties/MQ_HeaderValues/MQRFH2/Alert/text()"/>
                                </Alert>
                                <ErrorTxt>
                                    <xsl:value-of select="$ErrorMessage" />
                                </ErrorTxt>
                                <triggerValue>
                                    <xsl:value-of select="dp:variable('var://context/cjobEvent/trigValue')"/>
                                </triggerValue>
                                <CurrentCount>
                                    <xsl:value-of select="dp:variable('var://context/RetryContext/CurrentCount')" />
                                </CurrentCount>
                                <LastRetry>
                                    <xsl:value-of select="dp:variable('var://context/RetryContext/LastRetry')" />
                                </LastRetry>
								<retryCount>
                                    <xsl:value-of select="dp:variable('var://context/RetryContext/CurrentCount')" />
                                </retryCount>
                            </usr>
                        </NameValue>
                    </NameValueData>
                </MQRFH2>
            </xsl:variable>
            <xsl:variable name="serializedMQRFH2Request">
                <dp:serialize select="$MQRFH2Request" omit-xml-decl="yes"/>
            </xsl:variable>
            <xsl:variable name="MQMDStr2">
                <dp:serialize select="$MQMDStr" omit-xml-decl="yes"/>
            </xsl:variable>
            <xsl:variable name="headers">
                <header name="MQMD">
                    <xsl:copy-of select="$MQMDStr2"/>
                </header>
                <header name="MQRFH2">
                    <xsl:copy-of select="$serializedMQRFH2Request"/>
                </header>
            </xsl:variable>
            <xsl:variable name="MqUrlopen" select="concat('dpmq://',$HeaderProperties/MQ_HeaderValues/Interfaces/Common/QueueManager/text(),'/?RequestQueue=',$HeaderProperties/MQ_HeaderValues/Interfaces/Common/RetryQueue/text())"/>
            <xsl:message dp:priority="debug">
                       MqUrlopen:::::
                <xsl:value-of select="$MqUrlopen"/>
            </xsl:message>
            <dp:set-variable name="'var://context/RTQ/MqUrlopen'" value="$MqUrlopen"/>
            <xsl:variable name="result">
                <dp:url-open http-headers="$headers" response="responsecode-ignore" target="{$MqUrlopen}">
                    <xsl:copy-of select="dp:variable('var://context/cjobEvent/jsonPayload')"/>
                </dp:url-open>
            </xsl:variable>
            <xsl:copy-of select="dp:variable('var://context/cjobEvent/errmsg')"/>
            <xsl:message dp:priority="debug">
                       url-open():::::
                <xsl:copy-of select="$result"/>
            </xsl:message>
            <dp:set-variable name="'var://context/RTQ/MQRFH2Headers'" value="$headers"/>
            <dp:set-variable name="'var://context/RTQ/RetryQueueData'" value="$MqUrlopen"/>
            <dp:set-variable name="'var://context/RTQ/RetryQueueResult'" value="$result"/>
            <dp:set-response-header name="'MQMD'" value="$MQMDStr2"/>
            <dp:set-response-header name="'MQRFH2'" value="$serializedMQRFH2Request"/>
        </xsl:if>
    </xsl:template>
</xsl:stylesheet>
