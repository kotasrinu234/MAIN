<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" version="1.0" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
	<xsl:variable name="pjeErrorCode" select="dp:variable('var://context/cjobEvent/customErrorCode')" />
	<xsl:variable name="pjeErrorMessage" select="dp:variable('var://context/cjobEvent/customErrorMessage')" />
	<xsl:variable name="pjeReasonMessage" select="dp:variable('var://context/cjobEvent/customReasonMessage')" />

	<xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
	<xsl:variable name="systemErrorMessage" select="dp:variable('var://service/error-message')"/>
     
	

	<xsl:template match="/">
		
		<xsl:variable name="customErrorCode">
			<xsl:if test="$pjeErrorCode">
				<xsl:value-of select="$pjeErrorCode"/>
			</xsl:if>
			
		</xsl:variable>
		<xsl:variable name="customErrorMessage">
			<xsl:if test="$pjeErrorMessage">
				<xsl:value-of select="$pjeErrorMessage"/>
			</xsl:if>
			
		</xsl:variable>
		<xsl:variable name="customReasonMessage" >
			<xsl:if test="$pjeReasonMessage">
				<xsl:value-of select="$pjeReasonMessage"/>
			</xsl:if>
			
		</xsl:variable>
		
		<!-- <dp:set-variable name="'var://context//retry'" value="string('yes')" /> -->
		<xsl:choose>
		<xsl:when test="string($customErrorCode) !=''">
			<xsl:variable name="ErrorText"><xsl:value-of select="$pjeErrorMessage"/>
			</xsl:variable>
			</xsl:when>
			<xsl:when test="string($customErrorCode) =''">
			<xsl:variable name="ErrorText"><xsl:value-of select="$systemErrorMessage"/>
			</xsl:variable>
			</xsl:when>
			
			</xsl:choose>
			<dp:set-variable name="'var://context/cjobEvent/ErrorText'" value="string($ErrorText)" />

		<json:object xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">

			<xsl:choose>
				<xsl:when test="string($customErrorCode) !=''">
					<xsl:variable name="code" select="$customErrorCode"/>
					<xsl:variable name="text" select="concat(' ', $customReasonMessage)"/>
					<dp:set-variable name="'var://service/error-protocol-response'" value="$code"/>
					<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$customReasonMessage"/>
					
					<json:string name="errorCode">
						<xsl:value-of select="$customErrorCode"/>
					</json:string>
					<json:string name="errorDescription">
						<xsl:value-of select="$customErrorMessage"/>
					</json:string>
					<xsl:message dp:type="all" dp:priority="error">trsevnt_cjobEvent_001: errorString:<xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage)"/>
					</xsl:message>
				</xsl:when>
				
				<xsl:when test="string($customErrorCode) =''">
				
					<json:string name="errorCode">
						<xsl:value-of select="$systemErrorCode"/>
					</json:string>
					<json:string name="errorDescription">
						<xsl:value-of select="$systemErrorMessage"/>
					</json:string>
					<xsl:message dp:type="all" dp:priority="error">trsevnt_cjobEvent_002: errorString:<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $systemErrorMessage)"/>
					</xsl:message>
				</xsl:when>
			</xsl:choose>
		</json:object>
		<dp:set-http-request-header name="'Content-Type'" value="'application/json'"/>
	</xsl:template>
</xsl:stylesheet>
