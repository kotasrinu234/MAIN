// null check is done for fcc and non fcc payload
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var ctx = session.name("csyn")|| session.createContext("csyn");
	 var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken= ctx.getVar("apiToken");
	var nullCheckRequired = ctx.getVar("nullCheckRequired");
	
	if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		
		if(nullCheckRequired == 'yes'){
		if (incomingdata.EFO_EngineerUpdate_FCC != undefined){	
			var FCC_name = incomingdata.EFO_EngineerUpdate_FCC.Engineer.Name;
			if (FCC_name === null || FCC_name === '' || FCC_name === undefined) {
				logger.error('csyn_037 Engineer.Name is not present in FCC input payload');
	            session.reject(' Engineer.Name is not present in FCC input payload');
	        }	
			var FCC_ID = incomingdata.EFO_EngineerUpdate_FCC.Engineer.ID;
			if (FCC_ID === null || FCC_ID === '' || FCC_ID === undefined) {
				logger.error('csyn_037 Engineer.ID is not present in FCC input payload');
				session.reject(' Engineer.ID is not present in FCC input payload');
	        }		
			var FCC_PSCrewID = incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSCrewID;
			if (FCC_PSCrewID === null || FCC_PSCrewID === '' || FCC_PSCrewID === undefined) {
	           logger.error('csyn_037 Engineer.PSCrewID is not present in FCC input payload');
				session.reject(' Engineer.PSCrewID is not present in FCC input payload');
	        }			
			var FCC_PSIsAssignedToOMS = incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS;
			if(FCC_PSIsAssignedToOMS != undefined){			
				var FCC_PSIsAssignedToOMS_name = incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name;
			if (FCC_PSIsAssignedToOMS_name === null || FCC_PSIsAssignedToOMS_name === '' || FCC_PSIsAssignedToOMS_name === undefined) {
	            logger.error('csyn_037 Engineer.PSIsAssignedToOMS.Name is not present in FCC input payload');
				session.reject('Engineer.PSIsAssignedToOMS.Name is not present in FCC input payload');
	        }		}else{
	        	logger.error('csyn_037 Engineer.PSIsAssignedToOMS is not present in FCC input payload');
	        	 session.reject('Engineer.PSIsAssignedToOMS is not present in FCC input payload');
	        }
			
		}else if(incomingdata.EFO_EngineerUpdate != undefined){		
			var name = incomingdata.EFO_EngineerUpdate.Engineer.Name;
			if (name === null || name === '' || name === undefined) {
	            logger.error('csyn_037 Engineer.Name is not present in NON_FCC input payload');
				session.reject(' Engineer.Name is not present in NON_FCC input payload');
	        }
			var id = incomingdata.EFO_EngineerUpdate.Engineer.ID;
			if (id === null || id === '' || id === undefined) {
	            logger.error('csyn_037 Engineer.ID is not present in NON_FCC input payload');
				session.reject('Engineer.ID is not present in NON_FCC input payload');
	        }
			var Dname = incomingdata.EFO_EngineerUpdate.Engineer.District.Name;
			if (Dname === null || Dname === '' || Dname === undefined) {
	            logger.error('csyn_037 Engineer.District.Name is not present in NON_FCC input payload');
				session.reject('Engineer.District.Name is not present in NON_FCC input payload');
	        }
			var Postcode = incomingdata.EFO_EngineerUpdate.Engineer.Postcode;
			if (Postcode === null || Postcode === '' || Postcode === undefined) {
	            logger.error('csyn_037 Engineer.Postcode is not present in NON_FCC input payload');
				session.reject(' Engineer.Postcode is not present in NON_FCC input payload');
	        }
			var EngineerTypeName = incomingdata.EFO_EngineerUpdate.Engineer.EngineerType.Name;
			if (EngineerTypeName === null || EngineerTypeName === '' || EngineerTypeName === undefined) {
	            logger.error('csyn_037 Engineer.EngineerType.Name is not present in NON_FCC input payload');
				session.reject(' Engineer.EngineerType.Name is not present in NON_FCC input payload');
	        }
			var Active = incomingdata.EFO_EngineerUpdate.Engineer.Active;
			if (Active === null || Active === '' || Active === undefined) {
	            logger.error('csyn_037 Engineer.Active is not present in NON_FCC input payload');
				session.reject(' Engineer.Active is not present in NON_FCC input payload');
	        }
			var Internal = incomingdata.EFO_EngineerUpdate.Engineer.Internal;
			if (Internal === null || Internal === '' || Internal === undefined) {
	            logger.error('csyn_037 Engineer.Internal is not present in NON_FCC input payload');
				session.reject(' Engineer.Internal is not present in NON_FCC input payload');
	        }
			var Street = incomingdata.EFO_EngineerUpdate.Engineer.Street;
			if (Street === null || Street === '' || Street === undefined) {
	            logger.error('csyn_037 Engineer.Street is not present in NON_FCC input payload');
				session.reject('Engineer.Street is not present in NON_FCC input payload');
	        }
			var City = incomingdata.EFO_EngineerUpdate.Engineer.City;
			if (City === null || City === '' || City === undefined) {
	            logger.error('csyn_037 Engineer.City is not present in NON_FCC input payload');
				session.reject(' Engineer.City is not present in NON_FCC input payload');
	        }
			var MobilePhone = incomingdata.EFO_EngineerUpdate.Engineer.MobilePhone;
			if (MobilePhone === null || MobilePhone === '' || MobilePhone === undefined) {
	            logger.error('csyn_037 Engineer.MobilePhone is not present in NON_FCC input payload');
				session.reject('Engineer.MobilePhone is not present in NON_FCC input payload');
	        }
			var Email = incomingdata.EFO_EngineerUpdate.Engineer.Email;
			if (Email === null || Email === '' || Email === undefined) {
	            logger.error('csyn_037 Engineer.Email is not present in NON_FCC input payload');
				session.reject('Engineer.Email is not present in NON_FCC input payload');
	        }
			var AreaName = incomingdata.EFO_EngineerUpdate.Engineer.Area.Name;
			if (AreaName === null || AreaName === '' || AreaName === undefined) {
	            logger.error('csyn_037 Engineer.Area.Name is not present in NON_FCC input payload');
				session.reject(' Engineer.Area.Name is not present in NON_FCC input payload');
	        }
			var AreaName = incomingdata.EFO_EngineerUpdate.Engineer.Area.Name;
			if (AreaName === null || AreaName === '' || AreaName === undefined) {
	            logger.error('csyn_037 Engineer.Area.Name is not present in NON_FCC input payload');
				session.reject('Engineer.Area.Name is not present in NON_FCC input payload');
	        }
			var IsSupervisor = incomingdata.EFO_EngineerUpdate.Engineer.IsSupervisor;
			if (IsSupervisor === null || IsSupervisor === '' || IsSupervisor === undefined) {
	            logger.error('csyn_037 Engineer.IsSupervisor is not present in NON_FCC input payload');
				session.reject(' Engineer.IsSupervisor is not present in NON_FCC input payload');
	        }
			var PSCrewID = incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID;
			if (PSCrewID === null || PSCrewID === '' || PSCrewID === undefined) {
	            logger.error('csyn_037 Engineer.PSCrewID is not present in NON_FCC input payload');
				session.reject(' Engineer.PSCrewID is not present in NON_FCC input payload');
	        }
			var PSBusinessUnits = incomingdata.EFO_EngineerUpdate.Engineer.PSBusinessUnits;
			if (PSBusinessUnits === null || PSBusinessUnits === '' || PSBusinessUnits === undefined) {
	            logger.error('csyn_037 Engineer.PSBusinessUnits is not present in NON_FCC input payload');
				session.reject(' Engineer.PSBusinessUnits is not present in NON_FCC input payload');
	        }
			var PSSubArea = incomingdata.EFO_EngineerUpdate.Engineer.PSSubArea;
			if (PSSubArea === null || PSSubArea === '' || PSSubArea === undefined) {
	            logger.error('csyn_037 Engineer.PSSubArea is not present in NON_FCC input payload');
				session.reject(' Engineer.PSSubArea is not present in NON_FCC input payload');
	        }
			
			
		}
		}
		}
	
		
	});
