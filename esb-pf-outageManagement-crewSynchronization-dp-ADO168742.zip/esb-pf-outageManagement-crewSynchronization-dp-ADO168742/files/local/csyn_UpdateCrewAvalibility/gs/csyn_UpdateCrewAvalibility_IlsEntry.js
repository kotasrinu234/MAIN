var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var urlIn = sm.getVar('var://service/URL-in');
var ctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		function uuidv4() {
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
				var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
				return v.toString(16);
			});
		}
		var uuid = uuidv4();
		ctx.setVariable('correlationID', uuid);
		var messageType = session.parameters.messageType;
		ctx.setVariable('messageType', messageType);
		if (incomingData.EFO_EngineerUpdate_FCC) {
			if(incomingData.EFO_EngineerUpdate_FCC.Engineer.PSCrewID != undefined){
				ctx.setVariable("crewDisplayID", incomingData.EFO_EngineerUpdate_FCC.Engineer.PSCrewID);
			}if(incomingData.EFO_EngineerUpdate_FCC.Engineer.ID != undefined){
				ctx.setVariable("employeeDisplayID", incomingData.EFO_EngineerUpdate_FCC.Engineer.ID);
			}
			
		}
		else if (incomingData.EFO_EngineerUpdate) {
			if(incomingData.EFO_EngineerUpdate.Engineer.PSCrewID != undefined){
				ctx.setVariable("crewDisplayID", incomingData.EFO_EngineerUpdate.Engineer.PSCrewID)
			}if(incomingData.EFO_EngineerUpdate.Engineer.ID != undefined){
ctx.setVariable("employeeDisplayID", incomingData.EFO_EngineerUpdate.Engineer.ID)
			}
		}
		var dateTime = new Date();
		var currentTime = dateTime.toISOString();
		ctx.setVariable("sourceEventTimestamp", currentTime);
		var description = session.parameters.description;
		ctx.setVariable("Entrydescription", description);
		ctx.setVariable("sourceUrl", urlIn);
	}
})
