//lookup service for non-fcc payload
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("csyn") || session.createContext("csyn");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	var ExitDescription = session.parameters.ExitDescription;

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.EFO_EngineerUpdate != undefined) {

			fs.readAsJSON("local:/csyn_UpdateCrewAvalibility/gs/csyn_aorIDs.json", function(readAsJSONError, jsonInternal) {
				if (readAsJSONError) {
					session.reject(readAsJSONError);
				} else {
					//local:/csyn_UpdateCrewAvalibility/gs/csyn_aorIDs.json

					var id = incomingdata.EFO_EngineerUpdate.Engineer.District.Name;

					//var obj = {};
					var checkforAor = false;
					for (var i = 0; i < jsonInternal.aorIDs.length; i++) {
						if (id == jsonInternal.aorIDs[i].name) {
							checkforAor = true;
							var obj1 = [];
							for (var j = 0; j < jsonInternal.aorIDs[i].table.length; j++) {
								var label = jsonInternal.aorIDs[i].table[j].value;
								var ctx = session.name("csyn") || session.createContext("csyn");
								var lookupURL = ctx.getVar("lookupURL");
								var lookupMessage = {
									"lookupReq": {
										"type": [
											{
												"name": "aors",
												"label": label
											}
										]
									}
								}

								var url = lookupURL;
								var LookupServiceResponse = {
									target: url,
									method: 'POST',
									contentType: 'application/json',
									data: lookupMessage
								};
								var obj1 = [];

								var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "Data: " + lookupMessage +". ";

								urlopen.open(LookupServiceResponse, function(error, response) {
									if (error) {
										var errorinfo = "csyn_010 urlopen connect error with aors LookupService" + JSON.stringify(error) + info;
										logger.error("csyn_010 urlopen connect error with aors LookupService" + JSON.stringify(error));
										ilsctx.setVariable("exitStatus", 500);
										ilsctx.setVariable("ExitDescription", errorinfo);
										session.reject(errorinfo);
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode == 200) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "csyn_030 error in reading response from LookupServiceResponse " + JSON.stringify(error) + info;
													logger.error("csyn_030 error in reading response from LookupServiceResponse " + JSON.stringify(error));
													ilsctx.setVariable("exitStatus", 500);
													ilsctx.setVariable("ExitDescription", errorinfo);
													session.reject(errorinfo);
												} else {
													hm.response.statusCode = responseStatusCode;
													logger.debug("response received from CrewType LookupServiceResponse for label " + label + " is " + responseData);
													var lookupResponse = JSON.parse(responseData);
													ilsctx.setVariable("exitStatus", "0");
													ilsctx.setVariable("ExitDescription", ExitDescription);

													var test2;
													if (lookupResponse.lookupRep.type[0].result == 0) {
														var crewTypeid = lookupResponse.lookupRep.type[0].id;
														var obj = {};
														obj.id = crewTypeid;
														obj1.push(obj);
														test2 = JSON.stringify(obj1);
														var ctx = session.name("csyn") || session.createContext("csyn");
														ctx.setVariable("aorIDLookup", obj1);

													} else {
														logger.error("csyn_037 aors lookup result is not 0 for label " + label);
														//session.reject(" aors lookup result is not 0 for label " + label);
														var errorinfo = "csyn_037 aors lookup result is not 0 for label" + JSON.stringify(error) + info;

														ilsctx.setVariable("exitStatus", 500);
														ilsctx.setVariable("ExitDescription", errorinfo);
														session.reject(errorinfo);
													}
												}
											});
										} else {
											logger.error("csyn_031 response code from lookup service is " + responseStatusCode);
											var errorinfo = "csyn_031 response code from lookup service is" + JSON.stringify(error) + info;
											//session.reject("response code from lookup service is " + responseStatusCode);
											ilsctx.setVariable("exitStatus", 500);
											ilsctx.setVariable("ExitDescription", errorinfo);
											session.reject(errorinfo);
										}
									}

								});
							}
						}

					}

					if (checkforAor == false) {
						logger.error("csyn_011 " + id + " is not present in aorid inbuild list");
						session.reject(id + " is not present in aorid inbuild list");
					}
					// for loop i block closed 
					// second lookup start
					if (incomingdata.EFO_EngineerUpdate.Engineer.Area != undefined || incomingdata.EFO_EngineerUpdate.Engineer.Area != '' || incomingdata.EFO_EngineerUpdate.Engineer.Area != null) {

						var label = incomingdata.EFO_EngineerUpdate.Engineer.Area.Name;
						if (label != undefined || label != '' || label != null) {

							//second lookup start
							var lookupMessage = {
								"lookupReq": {
									"type": [
										{
											"name": "crewTypes",
											"label": label
										}
									]
								}
							}

							var ctx = session.name("csyn") || session.createContext("csyn");
							var lookupURL = ctx.getVar("lookupURL");
							var omsExternalURL = ctx.getVar("omsExternalURL");
							var apiToken = ctx.getVar("apiToken");

							var url = lookupURL;
							var LookupServiceResponse = {
								target: url,
								method: 'POST',
								contentType: 'application/json',
								data: lookupMessage
							};

							var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method +"; Data: "+JSON.stringify(lookupMessage)  +". ";

							urlopen.open(LookupServiceResponse, function(error, response) {
								if (error) {
									var errorinfo = "csyn_012 error in reading response from LookupServiceResponse " + JSON.stringify(error) + info;
									logger.error("csyn_012 error in reading response from LookupServiceResponse " + JSON.stringify(error));
									//session.reject("urlopen connect error with crewTypes label for LookupService " + JSON.stringify(error));
									ilsctx.setVariable("exitStatus", 500);
									ilsctx.setVariable("ExitDescription", errorinfo);
									session.reject(errorinfo);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("csyn_032 failure in putting message to CrewType LookupServiceResponse" + JSON.stringify(error));
												var errorinfo = "csyn_032 failure in putting message to CrewType LookupServiceResponse " + JSON.stringify(error) + info;

												//session.reject(" failure in putting message to CrewType LookupServiceResponse" + JSON.stringify(error));
												ilsctx.setVariable("exitStatus", 500);
												ilsctx.setVariable("ExitDescription", errorinfo);
												session.reject(errorinfo);
											} else {
												ilsctx.setVariable("exitStatus", "0");
												ilsctx.setVariable("ExitDescription", ExitDescription);
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from CrewType LookupServiceResponse for label " + label + " is " + responseData);
												var lookupResponse = JSON.parse(responseData);
												if (lookupResponse.lookupRep.type[0].result == 0) {
													var lookupcrewtypestatus = lookupResponse.lookupRep.type[0].status;
													var ctx = session.name("csyn") || session.createContext("csyn");
													ctx.setVariable("lookupcrewtypestatus", lookupcrewtypestatus);
												} else {
													logger.error("csyn_013 lookup response for crewtypes with label as " + label + " is not 0 ");
													var errorinfo = "csyn_013 lookup response for crewtypes with label as " + label + JSON.stringify(error) + info + "Responseinfo " + responseData + "Response status code:" + responseStatusCode;

													//session.reject(" lookup response for crewtypes with label as " + label + " is not 0 ");
													ilsctx.setVariable("exitStatus", 500);
													ilsctx.setVariable("ExitDescription", errorinfo);
													session.reject(errorinfo);

												}
											}
										});
									} else {
										logger.error("csyn_034 responsecode from lookup service is" + responseStatusCode);
										var errorinfo = "csyn_034 responsecode from lookup service is" + JSON.stringify(error) + info;
										//session.reject("responsecode from lookup service is" + responseStatusCode);
										ilsctx.setVariable("exitStatus", 500);
										ilsctx.setVariable("ExitDescription", errorinfo);
										session.reject(errorinfo);
									}
								}
							});

						} else {
							logger.error("csyn_035 EFO_EngineerUpdate.Engineer.Area.Name  is not present in input payload");
							var errorinfo = "csyn_035 EFO_EngineerUpdate.Engineer.Area.Name  is not present in input payload" + JSON.stringify(error) + info;
							//session.reject(" EFO_EngineerUpdate.Engineer.Area.Name is not present in input payload");
							ilsctx.setVariable("exitStatus", 500);
							ilsctx.setVariable("ExitDescription", errorinfo);
							session.reject(errorinfo);
						}
					} else {
						logger.error("csyn_036 Engineer.Area block is not present in input payload");
						var errorinfo = "csyn_036 Engineer.Area block is not present in input payload" + JSON.stringify(error) + info;
							
						//session.reject("Engineer.Area block is not present in input payload");
						ilsctx.setVariable("exitStatus", 500);
						ilsctx.setVariable("ExitDescription", errorinfo);
						session.reject(errorinfo);
					}
					//second lookup end
				}

			});
		}
	}
});
