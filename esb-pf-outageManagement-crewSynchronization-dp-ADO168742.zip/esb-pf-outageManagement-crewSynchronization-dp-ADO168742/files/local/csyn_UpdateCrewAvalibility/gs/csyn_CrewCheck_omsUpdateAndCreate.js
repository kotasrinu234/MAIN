//oms api calls for fcc payload
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("csyn") || session.createContext("csyn");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	var ExternalRefIDCrewAssignmentID = ctx.getVar("ExternalRefIDCrewAssignmentID");
	var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
	var ExternalRefIDCallid = ctx.getVar("ExternalRefIDCallid");
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
	var ExitDescription = session.parameters.ExitDescription;
	ilsctx.setVariable("ExitDescription", ExitDescription)
	ilsctx.setVariable("exitDestination", 'SEQ.REQUEST')
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//CrewSync_FCC start
		if (incomingdata.EFO_EngineerUpdate_FCC != undefined) {
			//check for engineer.id which is needed for crew api call
			var crewid;
			if (incomingdata.EFO_EngineerUpdate_FCC.Engineer != undefined) {
				if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSCrewID != undefined) {
					crewid = incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSCrewID;
					//crew api call starts
					var crewApiUri = omsExternalURLV1 + 'Crew/' + crewid;
					var TokenValue = apiToken;
					var Crewapi = {
						target: crewApiUri,
						sslClientProfile: 'OMS_Client_Profile',
						method: 'GET',
						contentType: 'application/json',
						headers: {
							'osiApiToken': TokenValue
						},
					};
					var info = " TargetURL: " + Crewapi.target + "; Method: " + Crewapi.method + ". ";
					urlopen.open(Crewapi, function(error, response) {
						if (error) {
							var errorinfo = "csyn_001: urlopen connection error 'Crewapi' details are: " + info + "; error info: " + error;
							var ctx = session.name("csyn") || session.createContext("csyn");
							ctx.setVariable("retry", 'yes');
							logger.debug("urlopen connect error with Get Crewapi for PSCrewID " + crewid + " with error as " + JSON.stringify(error));
							var ErrorTxt = "csyn_001 urlopen connect error with Get Crewapi for PSCrewID " + crewid + " with error as " + JSON.stringify(error);
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ilsctx.setVariable("ExitDescription", errorinfo)
							ilsctx.setVariable("exitStatus", "500")
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200 || responseStatusCode == 404) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'Crewapi' details are: " + info + "; error info: " + error;
										logger.error("csyn_021 failure in reading message from crewapi" + JSON.stringify(error));
										ilsctx.setVariable("ExitDescription", errorinfo)
										ilsctx.setVariable("exitStatus", "500")
										session.reject(errorinfo);
									}
									else {
										ilsctx.setVariable("ExitDescription", ExitDescription)
										ilsctx.setVariable("exitStatus", responseStatusCode)
										var payload =
										{
											"customFieldValues": {}
										}
										var disableCheck;
										var CrewResponseId;
										if (responseStatusCode == 200) {
											disableCheck = JSON.parse(responseData).deprecated;
											CrewResponseId = JSON.parse(responseData).id;
										}
										if (responseStatusCode == 200 && disableCheck == false) {

											if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.Name != undefined) {
												payload.name = incomingdata.EFO_EngineerUpdate_FCC.Engineer.Name;
											}
											if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.ID != undefined) {
												payload.customFieldValues.employeeid = incomingdata.EFO_EngineerUpdate_FCC.Engineer.ID;
											}
											if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSCrewID != undefined) {
												payload.externalID = incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSCrewID;
												payload.customFieldValues.CrewID = incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSCrewID;
											}
											var PSIsAssignedToOMSName;
											if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS != undefined) {
												if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name != undefined) {
													if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name == 'Yes' || incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name == 'YES') {
														PSIsAssignedToOMSName = true;
														payload.customFieldValues.PSIsAssignedToOMS = PSIsAssignedToOMSName;
														payload.customFieldValues.crewStatusCustom = "AVAILABLE";
														payload.customFieldValues.PSIsAssignedToOMS = 'True';
													}
													else if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name == 'No' || incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name == 'NO') {
														PSIsAssignedToOMSName = false;
														payload.customFieldValues.PSIsAssignedToOMS = PSIsAssignedToOMSName;
														payload.customFieldValues.crewStatusCustom = "UN-AVAILABLE";
														payload.customFieldValues.PSIsAssignedToOMS = 'False';
													}
												}
											}
											//calling patch apistart CALL PATCH/api/ServiceType/{sid}/Crew/{id}
											var crewid = incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSCrewID;
											var crewapiuri = omsExternalURL + 'Crew/' + crewid;
											var TokenValue = apiToken;
											var crewapi = {
												target: crewapiuri,
												sslClientProfile: 'OMS_Client_Profile',
												method: 'PATCH',
												contentType: 'application/json',
												headers: {
													'osiApiToken': TokenValue
												},
												data: payload
											};
											var info = " TargetURL: " + crewapi.target + "; Method: " + crewapi.method + "; Data: " + JSON.stringify(crewapi.data) + ". ";
											urlopen.open(crewapi, function(error, response) {
												if (error) {
													var errorinfo = "csyn_003: urlopen connection error 'crewapi' details are: " + info + "; error info: " + error;
													var ctx = session.name("csyn") || session.createContext("csyn");
													ctx.setVariable("retry", 'yes');
													var ctx = session.name("csyn") || session.createContext("csyn");
													logger.debug("urlopen connect error with Get Crewapi for PSCrewID " + crewid + " with error as " + JSON.stringify(error));
													var ErrorTxt = "csyn_003 urlopen connect error with PATCH Crewapi for PSCrewID " + crewid + " with error as " + JSON.stringify(error);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ilsctx.setVariable("ExitDescription", errorinfo)
													ilsctx.setVariable("exitStatus", "500")
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response 'crewapi' details are: " + info + "; error info: " + error;
																logger.error("csyn_022 failure in getting message to crewapi" + JSON.stringify(error));
																session.reject(" failure in getting message to crewapi" + JSON.stringify(error));
																ilsctx.setVariable("ExitDescription", errorinfo)
																ilsctx.setVariable("exitStatus", "500")
															} else {
																hm.response.statusCode = responseStatusCode;
																hm.response.statusCode = responseStatusCode;
																ilsctx.setVariable("ExitDescription", ExitDescription)
																ilsctx.setVariable("exitStatus", "0")
																ilsctx.setVariable("exitDestination", '"SEQ.REQUEST"')
																logger.debug("response received from crewapi for crewid:" + crewid + "is :" + responseStatusCode);
																//calling patch api end	
																// calling //offset api start
																//PATCH /api/v1/ServiceType/Electric/Crew/{id}/OffShift NO
																//POST  /api/v1/ServiceType/Electric/Crew/{id}/OnShift YES
																//"shiftOffTime": "2018-01-13T10:00:00Z"
																var now = new Date();
																var year = now.getFullYear();
																var month = now.getMonth() + 1;
																var month1 = month.toString();
																var strmonthlength = month1.length;
																var todaymonth;
																if (strmonthlength == 1) {
																	todaymonth = '0' + month;
																} else {
																	todaymonth = month;
																}
																var day = now.getDate();
																var day1 = day.toString();
																var strdaylength = day1.length;
																var todaydate;
																if (strdaylength == 1) {
																	todaydate = '0' + day;
																} else {
																	todaydate = day;
																}
																var hour = now.getHours();
																var todayhour = hour.toString();
																var strhourlength = todayhour.length;
																var todayhour;
																if (strhourlength == 1) {
																	todayhour = '0' + hour;
																} else {
																	todayhour = hour;
																}
																var minute = now.getMinutes();
																var todayminute = minute.toString();
																var strminutelength = todayminute.length;
																var todayminute;
																if (strminutelength == 1) {
																	todayminute = '0' + minute;
																} else {
																	todayminute = minute;
																}
																var second = now.getSeconds();
																var todaysecond = second.toString();
																var strsecondlength = todaysecond.length;
																var todaysecond;
																if (strsecondlength == 1) {
																	todaysecond = '0' + todaysecond;
																} else {
																	todaysecond = todaysecond;
																}
																var currentTimeStamp = new Date().toISOString();
																if (incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name == 'Yes' || incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name == 'YES' || incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSIsAssignedToOMS.Name == 'yes') {
																	//POST  /api/v1/ServiceType/Electric/Crew/{id}/OnShift
																	var crewpostonshiftapiuri = omsExternalURLV1 + 'Crew/' + CrewResponseId + '/OnShift';
																	var TokenValue = apiToken;
																	var payload = {
																		"shiftOnTime": currentTimeStamp
																	}
																	var crewpostonshiftapi = {
																		target: crewpostonshiftapiuri,
																		sslClientProfile: 'OMS_Client_Profile',
																		method: 'POST',
																		contentType: 'application/json',
																		headers: {
																			'osiApiToken': TokenValue
																		},
																		data: payload
																	};
																	var info = " TargetURL: " + crewpostonshiftapi.target + "; Method: " + crewpostonshiftapi.method + "; Data: " + JSON.stringify(crewpostonshiftapi.data) + ". ";
																	urlopen.open(crewpostonshiftapi, function(error, response) {
																		if (error) {
																			var errorinfo = "csyn_004: urlopen connection error 'crewpostonshiftapi' details are: " + info + "; error info: " + error;
																			var ctx = session.name("csyn") || session.createContext("csyn");
																			ctx.setVariable("retry", 'yes');
																			logger.error("urlopen connect error with crewpostonshiftapi" + JSON.stringify(error));
																			var ctx = session.name("csyn") || session.createContext("csyn");
																			logger.debug("urlopen connect error with post Crewapi onshift for crewid " + CrewResponseId + " with error as " + JSON.stringify(error));
																			var ErrorTxt = "csyn_004 urlopen connect error with Post Crewapi OnShift for crewid " + CrewResponseId + " with error as " + JSON.stringify(error);
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																			ilsctx.setVariable("ExitDescription", errorinfo)
																			ilsctx.setVariable("exitStatus", "500")
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error reading response 'crewpostonshiftapi' details are: " + info + "; error info: " + error;
																						logger.error("csyn_023 failure in reading response message from crewpostonshiftapi" + JSON.stringify(error));
																						session.reject(" failure in reading response message from crewpostonshiftapi" + JSON.stringify(error));
																						ilsctx.setVariable("exitStatus", "500")
																						ilsctx.setVariable("ExitDescription", errorinfo)
																						session.reject(errorinfo);
																					} else {
																						//store status code with response body in context variable
																						hm.response.statusCode = responseStatusCode;
																						hm.response.statusCode = responseStatusCode;
																						logger.debug("response received from crewpostonshiftapi" + responseStatusCode);
																						ilsctx.setVariable("ExitDescription", ExitDescription)
																						ilsctx.setVariable("exitStatus", "0")
																						ilsctx.setVariable("exitDestination", "SEQ.REQUEST")
																					}
																				});
																			} else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						//dp:reject stop the transaction and go error rule with error code and description
																						var errorinfo = "failure in reading response from 'crewpostonshiftapi' details are: " + info + "; error info: " + error;
																						logger.error("failure in reading message from crewpostonshiftapi " + JSON.stringify(error));
																						ilsctx.setVariable("exitStatus", "500")
																						ilsctx.setVariable("ExitDescription", errorinfo)
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "failure in reading response from 'crewpostonshiftapi' details are: " + info + + responseStatusCode + "; error info: " + responseData;
																						logger.error("csyn_024 response code received from crewpostonshiftapi" + responseStatusCode + " " + responseData);
																						ilsctx.setVariable("exitStatus", "400")
																						ilsctx.setVariable("ExitDescription", responseData.toString())
																					}
																				});
																			}
																		}
																	});
																}
																else {
																	//PATCH /api/v1/ServiceType/Electric/Crew/{id}/OffShift
																	var crewpatchonshiftapiuri = omsExternalURLV1 + 'Crew/' + CrewResponseId + '/OffShift';
																	var TokenValue = apiToken;
																	var payload = {
																		"shiftOffTime": currentTimeStamp
																	}
																	var crewpatchtoffshiftapi = {
																		target: crewpatchonshiftapiuri,
																		sslClientProfile: 'OMS_Client_Profile',
																		method: 'PATCH',
																		contentType: 'application/json',
																		headers: {
																			'osiApiToken': TokenValue
																		},
																		data: payload
																	};
																	var info = " TargetURL: " + crewpatchtoffshiftapi.target + "; Method: " + crewpatchtoffshiftapi.method + JSON.stringify(crewpatchtoffshiftapi.data) + ". ";
																	urlopen.open(crewpatchtoffshiftapi, function(error, response) {
																		if (error) {
																			var errorinfo = "csyn_005: urlopen connection error 'crewpatchtoffshiftapi' details are: " + info + "; error info: " + error;
																			var ctx = session.name("csyn") || session.createContext("csyn");
																			ctx.setVariable("retry", 'yes');
																			var ctx = session.name("csyn") || session.createContext("csyn");
																			logger.debug("urlopen connect error with patch Crewapi offshift for PSCrewID " + CrewResponseId + " with error as " + JSON.stringify(error));
																			var ErrorTxt = "csyn_005 urlopen connect error with Patch Crewapi OffShift for PSCrewID " + CrewResponseId + " with error as " + JSON.stringify(error);
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																			ilsctx.setVariable("ExitDescription", errorinfo)
																			ilsctx.setVariable("exitStatus", "500")
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error reading response 'crewpatchtoffshiftapi' details are: " + info + "; error info: " + error;
																						logger.error("csyn_025 failure in getting message from crewpatchtoffshiftapi" + JSON.stringify(error));
																						session.reject(" failure in getting message from crewpatchtoffshiftapi" + JSON.stringify(error));
																						ilsctx.setVariable("ExitDescription", errorinfo)
																						ilsctx.setVariable("exitStatus", "500")
																					} else {
																						//store status code with response body in context variable
																						hm.response.statusCode = responseStatusCode;
																						hm.response.statusCode = responseStatusCode;
																						logger.debug("response received from crewpatchtoffshiftapi" + responseStatusCode);
																						ilsctx.setVariable("ExitDescription", ExitDescription)
																						ilsctx.setVariable("exitStatus", "0")
																						ilsctx.setVariable("exitDestination", "SEQ.REQUEST")
																					}
																				});
																			}
																			else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						//dp:reject stop the transaction and go error rule with error code and description
																						var errorinfo = "failure in reading response from 'crewpatchtoffshiftapi' details are: " + info + "; error info: " + error;
																						logger.error("failure in reading message from Jobcommentsapi  for jobinternalid " + JSON.stringify(error));
																						ilsctx.setVariable("exitStatus", "500")
																						ilsctx.setVariable("ExitDescription", errorinfo)
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "failure in reading response from 'crewapi' details are: " + info + "; error info: " + responseData + responseStatusCode;
																						logger.error("csyn_026 response code received from crewpatchtoffshiftapi" + responseStatusCode + " " + responseData);
																						ilsctx.setVariable("exitStatus", "400")
																						ilsctx.setVariable("ExitDescription", responseData.toString())
																					}
																				});
																			}
																		}
																	});
																}
																//calling offset api end
															}
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																//dp:reject stop the transaction and go error rule with error code and description
																var errorinfo = "failure in reading response from 'crewapi' details are: " + info + "; error info: " + error;
																logger.error("failure in reading message from crewapi for PSCrewID " + JSON.stringify(error));
																ilsctx.setVariable("exitStatus", "500")
																ilsctx.setVariable("ExitDescription", errorinfo)
																session.reject(errorinfo);
															} else {
																var errorinfo = "failure in reading response from 'crewapi' details are: " + info + "; error info: " + responseStatusCode + responseData;
																logger.error("csyn_027 response received from crewapi for PSCrewID:" + crewid + "is :" + responseStatusCode + " " + responseData);
																ilsctx.setVariable("exitStatus", "500")
																ilsctx.setVariable("ExitDescription", errorinfo)
																session.reject(errorinfo);
															}
														});
													}
												}
											});
										} else if (responseStatusCode == 404 || disableCheck == true) {
											var ctx = session.name("csyn") || session.createContext("csyn");
											ctx.setVariable("retry", 'yes');
											
											if (disableCheck == true) {
												logger.error("response code return from crew api call is " + responseStatusCode + " with deprected value as true " );
												var ErrorTxt = "csyn_006 response code return from crew api call is " + responseStatusCode + " with deprected value as true";
												ilsctx.setVariable("ExitDescription", ErrorTxt)
												ctx.setVariable("ErrorTxt", ErrorTxt);
											}
											else {
												var crewid = incomingdata.EFO_EngineerUpdate_FCC.Engineer.PSCrewID;
											var crewApiUri = omsExternalURLV1 + 'Crew/' + crewid;
												logger.error("response code return from crew api call is " + responseStatusCode + ' '+crewApiUri );
												var ErrorTxt = "csyn_006 response code return from crew api call is " + responseStatusCode +' '+crewApiUri;
												ilsctx.setVariable("ExitDescription", ErrorTxt)
												ctx.setVariable("ErrorTxt", ErrorTxt);
											}
										}
									}
								});
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure in reading response from 'crewapi' details are: " + info + "; error info: " + error;
										logger.error("failure in reading message from Crewapi for Crewid " + JSON.stringify(error));
										ilsctx.setVariable("exitStatus", "500")
										ilsctx.setVariable("ExitDescription", errorinfo)
										session.reject(errorinfo);
									} else {
										var errorinfo = "failure in reading response from 'crewpostonshiftapi' details are: " + info + "; error info: " + responseData + responseStatusCode;
										logger.error("csyn_028 Error code return from Crewapi for PSCrewID " + crewid + "is " + responseStatusCode + " " + responseData);
										ilsctx.setVariable("exitStatus", "500")
										ilsctx.setVariable("ExitDescription", errorinfo)
										session.reject(errorinfo);
									}
								});
							}
						}
					});
				}
			} else {
				logger.error("csyn_029 Engineer.PSCrewID is not present in fsm payload");
				session.reject(" Engineer.PSCrewID is not present in fsm payload");
			}//engineer id check ends
		}//CrewSync_FCC
	}
});
