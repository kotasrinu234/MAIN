//oms api call for non fcc payload
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("csyn") || session.createContext("csyn");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	var ExternalRefIDCrewAssignmentID = ctx.getVar("ExternalRefIDCrewAssignmentID");
	var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
	var ExternalRefIDCallid = ctx.getVar("ExternalRefIDCallid");
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
	var ExitDescription = session.parameters.ExitDescription;
	ilsctx.setVariable("exitDestination", "SEQ.REQUEST")
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//CrewSync_NON_FCC start
		if (incomingdata.EFO_EngineerUpdate != undefined) {
			var ctx = session.name("csyn") || session.createContext("csyn");
			var aorIDLookup = ctx.getVar("aorIDLookup");
			if (aorIDLookup != undefined || aorIDLookup != '' || aorIDLookup != null) {
				var crewid;
				if ((incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== undefined && incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== '' && incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== null)) {
					crewid = incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID;
				} else if ((incomingdata.EFO_EngineerUpdate.Engineer.ID !== undefined && incomingdata.EFO_EngineerUpdate.Engineer.ID !== '' && incomingdata.EFO_EngineerUpdate.Engineer.ID !== null)) {
					crewid = incomingdata.EFO_EngineerUpdate.Engineer.ID;
				} else {
					logger.error("Engineer.Id or PSCrewID is not present in fsm payload");
					seesion.reject("Engineer.Id or PSCrewID is not present in fsm payload");
				}//engineer id check end
				//crew api call starts
				var crewApiUri = omsExternalURLV1 + 'Crew/' + crewid;
				var TokenValue = apiToken;
				var Crewapi = {
					target: crewApiUri,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'GET',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
				};
				var info = " TargetURL: " + Crewapi.target + "; Method: " + Crewapi.method + ". ";
				urlopen.open(Crewapi, function(error, response) {
					if (error) {
						var errorinfo = "csyn_007: urlopen connection error 'Crewapi' details are: " + info + "; error info: " + error;
						var ctx = session.name("csyn") || session.createContext("csyn");
						ctx.setVariable("retry", 'yes');
						var ctx = session.name("csyn") || session.createContext("csyn");
						logger.debug("urlopen connect error with Get Crewapi call for non-fcc with " + crewid + " with error as " + JSON.stringify(error));
						var ErrorTxt = "csyn_007 urlopen connect error with Get Crewapi call for non-fcc with " + crewid + " with error as " + JSON.stringify(error);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						ilsctx.setVariable("ExitDescription", errorinfo)
						ilsctx.setVariable("exitStatus", "500")
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200 || responseStatusCode == 404) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'Crewapi' details are: " + info + "; error info: " + error;
									logger.error("csyn_013 failure in getting message from get crewapi for non-fcc" + JSON.stringify(error));
									ilsctx.setVariable("ExitDescription", errorinfo)
									ilsctx.setVariable("exitStatus", "500")
									session.reject(errorinfo);
								}
								else {
									ilsctx.setVariable("ExitDescription", ExitDescription)
									ilsctx.setVariable("exitStatus", responseStatusCode)
									var payload =
									{
										"customFieldValues": {}
									}
									var disableCheck ;
									var CrewResponseId;
									if (responseStatusCode == 200) {
										disableCheck = JSON.parse(responseData).deprecated;
										CrewResponseId = JSON.parse(responseData).id;
										var getresponsedata = JSON.parse(responseData);
										var ctx = session.name("csyn") || session.createContext("csyn");
										ctx.setVariable("getresponsedata", getresponsedata);
										ilsctx.setVariable("ExitDescription ", ExitDescription)
										ilsctx.setVariable("exitStatus", "0")
										ilsctx.setVariable("exitDestination", "SEQ.REQUEST")
									}
									if (responseStatusCode == 200 && disableCheck == false) {
										var ctx = session.name("csyn") || session.createContext("csyn");
										var aorIDLookup = ctx.getVar("aorIDLookup");
										var lookupcrewtypestatus = ctx.getVar("lookupcrewtypestatus");
										var aorIDs = [];
										for (var i = 0; i < aorIDLookup.length; i++) {
											aorIDs.push(aorIDLookup[i].id);
										}
										payload.aorIDs = aorIDs;
										payload.type = lookupcrewtypestatus;
										if (incomingdata.EFO_EngineerUpdate.Engineer.Name != undefined) {
											payload.name = incomingdata.EFO_EngineerUpdate.Engineer.Name;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.ID != undefined) {
											payload.customFieldValues.employeeid = incomingdata.EFO_EngineerUpdate.Engineer.ID;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Postcode != undefined) {
											payload.customFieldValues.Postcode = incomingdata.EFO_EngineerUpdate.Engineer.Postcode;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.EngineerType != undefined) {
											if (incomingdata.EFO_EngineerUpdate.Engineer.EngineerType.Name != undefined) {
												payload.customFieldValues.EngineerType = incomingdata.EFO_EngineerUpdate.Engineer.EngineerType.Name;
											}
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Active != undefined) {
											payload.active = incomingdata.EFO_EngineerUpdate.Engineer.Active;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Internal != undefined) {
											payload.customFieldValues.Internal = incomingdata.EFO_EngineerUpdate.Engineer.Internal;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Street != undefined) {
											payload.customFieldValues.Street = incomingdata.EFO_EngineerUpdate.Engineer.Street;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.City != undefined) {
											payload.customFieldValues.City = incomingdata.EFO_EngineerUpdate.Engineer.City;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.MobilePhone) {
											payload.phoneNumber = incomingdata.EFO_EngineerUpdate.Engineer.MobilePhone;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Email != undefined) {
											payload.email = incomingdata.EFO_EngineerUpdate.Engineer.Email;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.IsSupervisor != undefined) {
											payload.customFieldValues.IsSupervisor = incomingdata.EFO_EngineerUpdate.Engineer.IsSupervisor;
										}
										var getcallresponseData = JSON.parse(responseData);
                                        var currentTimeStamp = new Date().toISOString();
										var shiftType
										var doShiftCall = false
										if (getcallresponseData.customFieldValuesExt !== undefined && getcallresponseData.customFieldValuesExt !== '' && getcallresponseData.customFieldValuesExt !== null) {
											if (getcallresponseData.customFieldValuesExt.PSIsAssignedToOMS != undefined || getcallresponseData.customFieldValuesExt.PSIsAssignedToOMS != '' || getcallresponseData.customFieldValuesExt.PSIsAssignedToOMS != null) {
												if (getcallresponseData.customFieldValuesExt.PSIsAssignedToOMS == true) {
													payload.customFieldValues.PSIsAssignedToOMS = true;
													payload.customFieldValues.crewStatusCustom = 'AVAILABLE';
                                                    doShiftCall = true
                                                    var shiftCallPayload = {
                                                        "shiftOnTime": currentTimeStamp
                                                    };
                                                    shiftType = "OnShift"
												} else if (getcallresponseData.customFieldValuesExt.PSIsAssignedToOMS == false) {
													payload.customFieldValues.PSIsAssignedToOMS = false;
													payload.customFieldValues.crewStatusCustom = 'UN-AVAILABLE';
                                                    doShiftCall = true
                                                    var shiftCallPayload = {
                                                        "shiftOffTime": currentTimeStamp
                                                    };
                                                    shiftType = "OffShift"
												}
											}
										}
										if ((incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== undefined && incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== '' && incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== null)) {
											payload.externalID = incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID;
											payload.customFieldValues.CrewID = incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID;
										} else if ((incomingdata.EFO_EngineerUpdate.Engineer.ID !== undefined && incomingdata.EFO_EngineerUpdate.Engineer.ID !== '' && incomingdata.EFO_EngineerUpdate.Engineer.ID !== null)) {
											payload.externalID = incomingdata.EFO_EngineerUpdate.Engineer.ID;
											payload.customFieldValues.CrewID = incomingdata.EFO_EngineerUpdate.Engineer.ID;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.PSBusinessUnits != undefined) {
											var PSBusinessUnits = incomingdata.EFO_EngineerUpdate.Engineer.PSBusinessUnits;
											var myarray = [];
											for (var i = 0; i < PSBusinessUnits.length; i++) {
												myarray.push(PSBusinessUnits[i].Name);
											}
											var i;
											var ConditionFoundmsg = "";
											for (i = 0; i < myarray.length; i++) {
												var k = i + 1;
												if (k == myarray.length) {
													ConditionFoundmsg += myarray[i];
												} else {
													ConditionFoundmsg += myarray[i] + '\n';
												}
											}
											payload.customFieldValues.PSBusinessUnits = ConditionFoundmsg;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.PSSubArea != undefined) {
											if (incomingdata.EFO_EngineerUpdate.Engineer.PSSubArea.Name != undefined) {
												var PSSubAreas = incomingdata.EFO_EngineerUpdate.Engineer.PSSubArea.Name;
												payload.customFieldValues.PSSubAreas = PSSubAreas;
											}
										}
										//calling patch apistart CALL PATCH/api/ServiceType/{sid}/Crew/{id}
										var crewid;
										if ((incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== undefined && incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== '' && incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== null)) {
											crewid = incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID;
										} else if ((incomingdata.EFO_EngineerUpdate.Engineer.ID != undefined && incomingdata.EFO_EngineerUpdate.Engineer.ID != '' && incomingdata.EFO_EngineerUpdate.Engineer.ID != null)) {
											crewid = incomingdata.EFO_EngineerUpdate.Engineer.ID;
										}
										var crewapiuri = omsExternalURL + 'Crew/' + crewid;
										var TokenValue = apiToken;
										var crewapi = {
											target: crewapiuri,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'PATCH',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										var info = " TargetURL: " + crewapi.target + "; Method: " + crewapi.method + "; Data: " + JSON.stringify(crewapi.data) + ". ";
										urlopen.open(crewapi, function(error, response) {
											if (error) {
												var errorinfo = "csyn_008: urlopen connection error 'crewapi' details are: " + info + "; error info: " + error;
												var ctx = session.name("csyn") || session.createContext("csyn");
												ctx.setVariable("retry", 'yes');
												var ctx = session.name("csyn") || session.createContext("csyn");
												logger.debug("csyn_008 urlopen connect error with patch Crewapi call for non-fcc with crewid " + crewid + " with error as " + JSON.stringify(error));
												var ErrorTxt = "csyn_008 urlopen connect error with patch Crewapi call for non-fcc with crewid " + crewid + " with error as " + JSON.stringify(error);
												ctx.setVariable("ErrorTxt", ErrorTxt);
												ilsctx.setVariable("ExitDescription", errorinfo)
												ilsctx.setVariable("exitStatus", "500")
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "csyn_014 error reading response 'crewapi' details are: " + info + "; error info: " + error;
															logger.error("csyn_014 failure in reading message from patch crewapi for non-fcc " + JSON.stringify(error));
															ilsctx.setVariable("ExitDescription", errorinfo)
															ilsctx.setVariable("exitStatus", "500")
															session.reject(" failure in reading message from patch crewapi for non-fcc " + JSON.stringify(error));
														} else {
															hm.response.statusCode = responseStatusCode;
															hm.response.statusCode = responseStatusCode;
															logger.debug("response received from crewapi for crewid:" + crewid + "is :" + responseStatusCode);
															ilsctx.setVariable("ExitDescription", ExitDescription)
															ilsctx.setVariable("exitStatus", "0")
															ilsctx.setVariable("exitDestination", "SEQ.REQUEST")
                                                            if (doShiftCall === true) {
																shiftCall(shiftType, shiftCallPayload, crewid)
															}
														}
													});
												} else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															//dp:reject stop the transaction and go error rule with error code and exitdescription
															logger.error("failure in reading message from crewapi for crewid " + JSON.stringify(error));
															var errorinfo = "failure in reading message from crewapi for crewid details are : "+ info + "error details" + JSON.stringify(error);
															ilsctx.setVariable("ExitDescription", errorinfo)
															ilsctx.setVariable("exitStatus", "500")
															session.reject(errorinfo);
														} else {
															logger.error("csyn_015 response received from crewapi for crewid:" + crewid + "is :" + responseStatusCode + " " + responseData);
															var errorinfo =  "csyn_015 response received from crewapi for crewid:" + crewid + "is :" + responseStatusCode + " " + responseData + "with details are"+ info;
															ilsctx.setVariable("ExitDescription", errorinfo)
															ilsctx.setVariable("exitStatus", responseStatusCode)
															session.reject(errorinfo);
														}
													});
												}
											}
										});
									} else if(responseStatusCode == 404 || disableCheck == true) {
										var ctx = session.name("csyn") || session.createContext("csyn");
										ilsctx.setVariable("ExitDescription", 'not found')
										var aorIDLookup = ctx.getVar("aorIDLookup");
										var aorIDs = [];
										for (var i = 0; i < aorIDLookup.length; i++) {
											aorIDs.push(aorIDLookup[i].id);
										}
										var lookupcrewtypestatus = ctx.getVar("lookupcrewtypestatus");
										payload.aorIDs = aorIDs;
										payload.type = lookupcrewtypestatus;
										if (incomingdata.EFO_EngineerUpdate.Engineer.Name == undefined) {
										} else {
											payload.name = incomingdata.EFO_EngineerUpdate.Engineer.Name;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.ID != undefined) {
											payload.customFieldValues.employeeid = incomingdata.EFO_EngineerUpdate.Engineer.ID;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Active != undefined) {
											payload.active = incomingdata.EFO_EngineerUpdate.Engineer.Active;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Postcode != undefined) {
											payload.customFieldValues.Postcode = incomingdata.EFO_EngineerUpdate.Engineer.Postcode;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.EngineerType != undefined) {
											if (incomingdata.EFO_EngineerUpdate.Engineer.EngineerType.Name != undefined) {
												payload.customFieldValues.EngineerType = incomingdata.EFO_EngineerUpdate.Engineer.EngineerType.Name;
											}
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Internal != undefined) {
											payload.customFieldValues.Internal = incomingdata.EFO_EngineerUpdate.Engineer.Internal;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Street != undefined) {
											payload.customFieldValues.Street = incomingdata.EFO_EngineerUpdate.Engineer.Street;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.City != undefined) {
											payload.customFieldValues.City = incomingdata.EFO_EngineerUpdate.Engineer.City;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.MobilePhone != undefined) {
											payload.phoneNumber = incomingdata.EFO_EngineerUpdate.Engineer.MobilePhone;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.Email != undefined) {
											payload.email = incomingdata.EFO_EngineerUpdate.Engineer.Email;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.IsSupervisor != undefined) {
											payload.customFieldValues.IsSupervisor = incomingdata.EFO_EngineerUpdate.Engineer.IsSupervisor;
										}
										payload.customFieldValues.PSIsAssignedToOMS = false;
										payload.customFieldValues.crewStatusCustom = 'UN-AVAILABLE';
										if ((incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== undefined && incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== '' && incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID !== null)) {
											payload.externalID = incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID;
											payload.customFieldValues.CrewID = incomingdata.EFO_EngineerUpdate.Engineer.PSCrewID;
										} else if ((incomingdata.EFO_EngineerUpdate.Engineer.ID !== undefined && incomingdata.EFO_EngineerUpdate.Engineer.ID !== '' && incomingdata.EFO_EngineerUpdate.Engineer.ID !== null)) {
											payload.externalID = incomingdata.EFO_EngineerUpdate.Engineer.ID;
											payload.customFieldValues.CrewID = incomingdata.EFO_EngineerUpdate.Engineer.ID;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.PSBusinessUnits) {
											var PSBusinessUnits = incomingdata.EFO_EngineerUpdate.Engineer.PSBusinessUnits;
											var myarray = [];
											for (var i = 0; i < PSBusinessUnits.length; i++) {
												myarray.push(PSBusinessUnits[i].Name);
											}
											var i;
											var ConditionFoundmsg = "";
											for (i = 0; i < myarray.length; i++) {
												var k = i + 1;
												if (k == myarray.length) {
													ConditionFoundmsg += myarray[i];
												} else {
													ConditionFoundmsg += myarray[i] + '\n';
												}
											}
											payload.customFieldValues.PSBusinessUnits = ConditionFoundmsg;
										}
										if (incomingdata.EFO_EngineerUpdate.Engineer.PSSubArea != undefined) {
											if (incomingdata.EFO_EngineerUpdate.Engineer.PSSubArea.Name != undefined) {
												var PSSubAreas = incomingdata.EFO_EngineerUpdate.Engineer.PSSubArea.Name;
												payload.customFieldValues.PSSubAreas = PSSubAreas;
											}
										}
										payload.customFieldValues.PSIsAssignedToOMS = false;
										var crewapiuri = omsExternalURLV1 + 'Crew';
										var TokenValue = apiToken;
										var crewapi = {
											target: crewapiuri,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'POST',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										var info = " TargetURL: " + crewapi.target + "; Method: " + crewapi.method + "; Data: " + JSON.stringify(crewapi.data) + ". ";
										urlopen.open(crewapi, function(error, response) {
											if (error) {
												var errorinfo = "csyn_009: urlopen connection error 'crewpostonshiftapi' details are: " + info + "; error info: " + error;
												var ctx = session.name("csyn") || session.createContext("csyn");
												ctx.setVariable("retry", 'yes');
												var ctx = session.name("csyn") || session.createContext("csyn");
												logger.debug("csyn_009 urlopen connect error with post Crewapi call for non-fcc with crewid " + crewid + " with error as " + JSON.stringify(error));
												var ErrorTxt = "csyn_009 urlopen connect error with post Crewapi call for non-fcc with crewid " + crewid + " with error as " + JSON.stringify(error);
												ctx.setVariable("ErrorTxt", ErrorTxt);
												ilsctx.setVariable("ExitDescription", errorinfo)
												ilsctx.setVariable("exitStatus", "500")
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error reading response 'crewpostonshiftapi' details are: " + info + "; error info: " + error;
															logger.error("csyn_016 failure in putting message to crewapi post" + JSON.stringify(error));
															ilsctx.setVariable("exitStatus", "500")
															ilsctx.setVariable("ExitDescription", errorinfo)
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = responseStatusCode;
															hm.response.statusCode = responseStatusCode;
															  var currentTimeStamp = new Date().toISOString();
                                                            var Internalid = JSON.parse(responseData).id;
                                                            var shiftCallPayload = {
																"shiftOffTime": currentTimeStamp
															};
															var shiftType = "OffShift"
															shiftCall(shiftType, shiftCallPayload, Internalid)
															logger.debug("response received from crewapi POSt is :" + responseStatusCode);
															ilsctx.setVariable("ExitDescription", ExitDescription)
															ilsctx.setVariable("exitStatus", "0")
															ilsctx.setVariable("exitDestination", "SEQ.REQUEST")
														}
													});
												} 
												else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "failure in reading response from 'crewpostonshiftapi' details are: " + info + "; error info: " + error;
															logger.error("failure in reading message from Jobcommentsapi  for jobinternalid " + JSON.stringify(error));
															ilsctx.setVariable("exitStatus", "500")
															ilsctx.setVariable("ExitDescription", errorinfo)
															session.reject(errorinfo);
														} else {
															var errorinfo = "failure in reading response from 'crewpostonshiftapi' details are: " + info + "responseStatusCode" + responseStatusCode + "; error info: " + responseData;
															logger.error("csyn_017 response received from crewapi Post is :" + responseStatusCode + " " + responseData);
															ilsctx.setVariable("exitStatus", responseStatusCode)
															ilsctx.setVariable("ExitDescription", errorinfo)
															session.reject(errorinfo);
														}
													});
												}
											}
										});
									}
								}
							});
						}else if (responseStatusCode == 401 || responseStatusCode == 403) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "csyn_029: error reading response crew api, details are : " + info + "; error info :" + error;
												ilsctx.setVariable('ExitStatus', responseStatusCode);
												ilsctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "csyn_029: error response  crew api, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
												ilsctx.setVariable('ExitStatus', responseStatusCode);
												ilsctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});
									}else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading response from 'crewapi' details are: " + info + "; error info: " + error;
									logger.error("failure in reading message from Crewapi for Crewid " + JSON.stringify(error));
			ilsctx.setVariable("exitStatus", "500")
									ilsctx.setVariable("ExitDescription", errorinfo)
									session.reject(errorinfo);
								} else {
									logger.error("csyn_018 Error code return from Crewapi for Crewid " + crewid + "is " + responseStatusCode + " " + responseData);
									ilsctx.setVariable("exitStatus", responseStatusCode)
									ilsctx.setVariable("ExitDescription", errorinfo)
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			} else {
				var value = incomingdata.EFO_EngineerUpdate.Engineer.District.Name;
				logger.error("Engineer.District.Name from NON_FCC payload is " + value + " and it didn't match with oms aorsID");
				session.reject(" Engineer.District.Name from NON_FCC payload is " + value + " and it didn't match with oms aorsID");
			}
		}//CrewSync_Non_FCC
	}
});
function shiftCall(shiftType, data, crewid) {
    var ctx = session.name("csyn") || session.createContext("csyn");
	var apiToken = ctx.getVar("apiToken");
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
    var methodCall;
    if(shiftType=='OnShift'){
        methodCall='POST'
    } else {
        methodCall='PATCH'
    }
	var Options =
	{
		target: omsExternalURLV1 + 'Crew/' + crewid +'/'+ shiftType,
		sslClientProfile: 'OMS_Client_Profile',
		method: methodCall,
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: data
	};
	var info = " TargetURL :" + Options.target + "; Method :" + Options.method + "; Data :" + JSON.stringify(Options.data) + ". ";
	urlopen.open(Options, function(error, response) {
		if (error) {
			var errorinfo = "error reading response 'Crewapi' details are: " + info + "; error info: " + error;
			ctx.setVariable("retry", 'yes');
			logger.debug("urlopen connect error with Get Crewapi call for non-fcc with " + crewid + " with error as " + JSON.stringify(error));
			var ErrorTxt = "csyn_038 urlopen connect error with Get Crewapi call for non-fcc with " + crewid + " with error as " + JSON.stringify(error);
			ctx.setVariable("ErrorTxt", ErrorTxt);
			ilsctx.setVariable("ExitDescription", errorinfo)
			ilsctx.setVariable("exitStatus", "500")
		}
		else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "csyn_039 error reading response 'crewapi' details are: " + info + "; error info: " + error;
						logger.error("csyn_039 failure in reading message from patch crewapi for non-fcc " + JSON.stringify(error));
						ilsctx.setVariable("ExitDescription", errorinfo)
						ilsctx.setVariable("exitStatus", "500")
						session.reject(" failure in reading message from patch crewapi for non-fcc " + JSON.stringify(error));
					} else {
						hm.response.statusCode = responseStatusCode;
						hm.response.statusCode = responseStatusCode;
						logger.debug("response received from crewapi for crewid:" + crewid + "is :" + responseStatusCode);
						ilsctx.setVariable("ExitDescription", ExitDescription)
						ilsctx.setVariable("exitStatus", "0")
						ilsctx.setVariable("exitDestination", "SEQ.REQUEST")
					}
				});
			}
			else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						logger.error("failure in reading message from crewapi for crewid " + JSON.stringify(error));
						var errorinfo = "failure in reading message from crewapi for crewid details are : " + info + "error details" + JSON.stringify(error);
						ilsctx.setVariable("ExitDescription", errorinfo)
						ilsctx.setVariable("exitStatus", "500")
						session.reject(errorinfo);
					} else {
						logger.error("csyn_040 response received from crewapi for crewid:" + crewid + "is :" + responseStatusCode + " " + responseData);
						var errorinfo = "csyn_040 response received from crewapi for crewid:" + crewid + "is :" + responseStatusCode + " " + responseData + "with details are" + info;
						ilsctx.setVariable("ExitDescription", responseData.toString())
						ilsctx.setVariable("exitStatus", responseStatusCode)
					}
				});
			}
		}
	});
}
