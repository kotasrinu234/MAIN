<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" extension-element-prefixes="dp" exclude-result-prefixes="dp">
<xsl:template match="@*|node()">
		<xsl:apply-templates select="@*|node()"/>
  </xsl:template>
  
	<xsl:template match="//json:string[@name='payload']">
		 <xsl:variable name="inflated" select="dp:inflate(//json:string[@name='payload'])"/>
	    <xsl:variable name="parsed" select="dp:parse($inflated)"/>
	    <xsl:copy-of select="$parsed"/>
	</xsl:template>
</xsl:stylesheet>
