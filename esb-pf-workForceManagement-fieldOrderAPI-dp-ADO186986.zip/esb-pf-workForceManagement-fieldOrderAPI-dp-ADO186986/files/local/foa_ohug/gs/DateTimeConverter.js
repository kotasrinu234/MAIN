var ctx = session.name("foa_dateTime") || session.createContext("foa_dateTime");
var hm = require('header-metadata');
var logger = console.options({'category': 'all'});
var conversionVal,GMTDate, ESTDateVar, ESTDate,localOffset,offset,utc,finalESTDate,dateArray;
session.input.readAsJSON(function(readAsJSONError, requestJson){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		dateArray = requestJson.DateConversion.dateList;

		ctx.setVariable("dateArray.length",dateArray.length);
		if(requestJson.DateConversion.action == 1){
			for (let i=0; i < dateArray.length; i++){
				GMTDate = new Date(dateArray[i].fromDateTime);
				ESTDateVar = GMTDate.getTime();
				localOffset = GMTDate.getTimezoneOffset() * 60000;
				var datestrng = GMTDate.toString();
				var edt1 = "Eastern Daylight Time";
				var edt = "EDT";
				if(datestrng.includes(edt) || datestrng.includes(edt1)){
					offset = -4;
				} else {
					offset = -5;
				}
				utc = ESTDateVar + (3600000*offset);
				ctx.setVariable("utc",utc);
				ESTDate = new Date(utc).toISOString();
				finalESTDate = ESTDate.replace('Z', '');
				requestJson.DateConversion.dateList[i].toDateTime = finalESTDate;
				ctx.setVariable("requestJson",requestJson);
				ctx.setVariable("finalESTDate",finalESTDate);
				session.output.write(requestJson);
			}
		}
	}
});
