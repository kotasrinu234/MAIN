var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var reqDataToFSE;
var FSEResponse = ctx.getVariable('FSEResponse');
if (FSEResponse == 'yes') {
	var ExitResponse = ctx.getVariable('ExitResponse');
	var ResponsePayload = JSON.stringify((ExitResponse));
	session.output.write(ResponsePayload);
}

session.input.readAsJSON(function(readAsJSONError, requestJson) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		session.output.write(requestJson);
		var retry = session.name('foa_dispatchWork').getVariable('retry');
		if (requestJson.reqType == 'Job_update') {
			var CrewAssignmentIdArray = ctx.getVariable("CrewAssignmentIdArray");
			var CrewAssignmentIdArraylength = ctx.getVariable("CrewAssignmentIdArraylength");
			var array = [];
			for (var i = 0; i < CrewAssignmentIdArraylength; i++) {
				var JobCallID = '';
				JobCallID = ctx.getVariable('Job_updatecallID_' + CrewAssignmentIdArray[i].displayID);
				if (JobCallID != undefined) {
					if (JobCallID.length > 0) {
						array.push(JobCallID)
					}
					JobCallID = ''
				}
			}
			//checking array length and comparing with CrewAssignmentIdArraylength ,if both are same then we can trigger sequenace
			if (CrewAssignmentIdArraylength == array.length) {
				var incomingPayload = ctx.getVariable("IncomingPayload");
				var seqResponse = {
					"messageId": incomingPayload.messageId,
					"eventType": "Status",
					"serviceName": "workOrderFSE",
					"sendTimeStamp": incomingPayload.sendTimeStamp
				}
				if (!(incomingPayload.workFlowType === undefined || incomingPayload.workFlowType === null)) {
					seqResponse.workFlowType = incomingPayload.workFlowType
				}
				if (!(incomingPayload.workFlowRequirementEvent === undefined || incomingPayload.workFlowRequirementEvent === null)) {
					seqResponse.workFlowRequirementEvent = incomingPayload.workFlowRequirementEvent
				}
				if (incomingPayload.eventKey != undefined || incomingPayload.eventKey != null) {
					seqResponse.eventKey = incomingPayload.eventKey
				}
				if (incomingPayload.crewAssignmentID != undefined || incomingPayload.crewAssignmentID != null) {
					seqResponse.crewAssignmentID = incomingPayload.crewAssignmentID
				}
				if (incomingPayload.crewAssignmentDisplayID != undefined || incomingPayload.crewAssignmentDisplayID != null) {
					seqResponse.crewAssignmentDisplayID = incomingPayload.crewAssignmentDisplayID
				}
				if (incomingPayload.jobID != undefined || incomingPayload.jobID != null) {
					seqResponse.jobID = incomingPayload.jobID
				}
				if (incomingPayload.jobDisplayID != undefined || incomingPayload.jobDisplayID != null) {
					seqResponse.jobDisplayID = incomingPayload.jobDisplayID
				}
				if (incomingPayload.crewDisplayID != undefined || incomingPayload.crewDisplayID != null) {
					seqResponse.crewDisplayID = incomingPayload.crewDisplayID
				}
				if (incomingPayload.messageType != undefined || incomingPayload.messageType != null) {
					seqResponse.messageType = incomingPayload.messageType
				}
				if (incomingPayload.assignmentStatus != undefined || incomingPayload.assignmentStatus != null) {
					seqResponse.assignmentStatus = incomingPayload.assignmentStatus
				}
				if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
					seqResponse.crewAssigmentTrigger = incomingPayload.crewAssigmentTrigger
				}
				if (incomingPayload.eventContext != undefined || incomingPayload.eventContext != null) {
					seqResponse.eventContext = incomingPayload.eventContext
				}
				if (incomingPayload.EventTimeStamp != undefined || incomingPayload.EventTimeStamp != null) {
					seqResponse.EventTimeStamp = incomingPayload.EventTimeStamp
				}
				SEQResponse(seqResponse);
				UdpdateImage(requestJson);

			}
		}else{
			var Outputpayload = ctx.getVariable('Outputpayload');
			if(!(Outputpayload == undefined)){
				session.output.write(Outputpayload);				
			}

		}
		var retry = ctx.getVariable('retry');
		if (retry == 'yes') {

			var FsePayload = ctx.getVariable('FseInputPayload');
			if (!(FsePayload == undefined || FsePayload == null || FsePayload == '')) {
				session.output.write(FsePayload);
			} else {
				session.output.write(requestJson);
			}
		}


	}
});
function SEQResponse(seqResponse) {
	var targetQueue = session.parameters.SEQResponseQueue;
	seqResponse.confirmation = "Y"
	var options = {
		target: targetQueue,
		data: seqResponse
	};
	try {
		urlopen.open(options, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.error('FSE45_14:foa_ohug_dispatch Mqurlopen.open error');
				var ErrorTxt = "Mqurlopen.open error";
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("exitDestination", session.parameters.SEQResponseQueue);
				//session.reject('** Mqurlopen.open error');
				hm.response.statusCode = 500;
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							logger.error('FSE45_14: foa_ohug_dispatch Mqurlopen.open error ' + readError);
							session.reject('Mqurlopen.open error');
						} else {
							console.log("MQResponseData " + responseData);
							//ilsexit for seq conf success call
							ctx.setVariable('Exitdescription', session.parameters.SEQResponseDescription);
							ctx.setVariable('Exitdestination', session.parameters.SEQResponseQueue)
							ctx.setVariable('ReqData', seqResponse)
							var ms = require('multistep');
							ms.callRule('foa_ohug_dispatch_ExitIls_Rule', null, null, function(error) {
								if (error) {
									throw error;
								}
							});
							//ilsexit for seq conf success call end
						}
					});
				} else {
					var ErrorTxt = 'FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']';
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("exitDestination", session.parameters.SEQResponseQueue);
					//logger.error('FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']');
					//session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
					hm.response.statusCode = 500
				}
			}
		});
	} catch (err) {
		var ErrorTxt = 'FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + err + ']';
		ctx.setVariable("ErrorTxt", ErrorTxt);
		ctx.setVariable("retry", 'yes');
		ctx.setVariable("exitDestination", session.parameters.SEQResponseQueue);
	}
}
function UdpdateImage(requestJson) {
	var targetQueue = session.parameters.UpdateImage;
	var JsonPayload = requestJson;
	var options = {
		target: targetQueue,
		data: requestJson
	};
	try {
		urlopen.open(options, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.error('FSE45_14:foa_ohug_dispatch Mqurlopen.open error');
				var ErrorTxt = "Mqurlopen.open error";
				ctx.setVariable("ErrorTxt", ErrorTxt);
				//ctx.setVariable("retry", 'yes');
				ctx.setVariable("exitDestination", session.parameters.UpdateImage);
				session.reject('** Mqurlopen.open error');
				hm.response.statusCode = 500;
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							logger.error('FSE45_14: foa_ohug_dispatch Mqurlopen.open error ' + readError);
							session.reject('Mqurlopen.open error');
						} else {
							var retry = ctx.getVariable('retry');
							if (retry == 'yes') {
								var FsePayload = ctx.getVariable('FseInputPayload');
								session.output.write(FsePayload);
							} else {
								session.output.write(requestJson);
								console.log("MQResponseData " + responseData);
							}
						}
					});
				} else {
					var ErrorTxt = 'FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']';
					ctx.setVariable("ErrorTxt", ErrorTxt);
					//ctx.setVariable("retry", 'yes');
					ctx.setVariable("exitDestination", session.parameters.UpdateImage);
					logger.error(' foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']');
					session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
					hm.response.statusCode = 500
				}
			}
		});
	} catch (err) {
		var ErrorTxt = 'FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + err + ']';
		ctx.setVariable("ErrorTxt", ErrorTxt);
		//	ctx.setVariable("retry", 'yes');
		ctx.setVariable("exitDestination", session.parameters.UpdateImage);
		session.reject(' foa_ohug_dispatch Mqurlopen.open error [MQRC=' + err + ']');
	}
}
