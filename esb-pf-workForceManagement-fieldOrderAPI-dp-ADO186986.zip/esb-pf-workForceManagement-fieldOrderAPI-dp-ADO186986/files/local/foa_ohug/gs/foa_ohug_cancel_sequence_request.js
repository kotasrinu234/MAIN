var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
ctx.setVariable("exitstatus", '500')
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		var incommingdata =JSON.parse(jsonData)
		if(!(incommingdata.data[0].workTypeID == undefined || incommingdata.data[0].workTypeID == null ||incommingdata.data[0].workTypeID == '' )){
			var lookupmessage=
					{"lookupReq":{"type":[{"name":"workTypes",
					"id":incommingdata.data[0].workTypeID,
					"status": "none"}]}}
				var lookupService = {
				target: session.parameters.lookUpURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupmessage  
				};
				urlopen.open(lookupService, function(error, response) {
						if (error) {
							logger.error(" urlopen connect error with LookupServiceResponse  " + JSON.stringify(error));
							//session.reject(" urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200 )  {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										logger.error(" error message from with LookupServiceResponse for " + JSON.stringify(error));
										//session.reject("error message from with LookupServiceResponse for " + JSON.stringify(error));
									} else {
										hm.response.statusCode = responseStatusCode;
										logger.debug("response received from LookupServiceResponse "+ responseStatusCode);			
										var lookupResponse = JSON.parse(responseData)
										var label;
										if(lookupResponse.lookupRep.type[0].result==0){
										 label= lookupResponse.lookupRep.type[0].label;
										}else{
											label="";
											}
    var publish = publishcall( label,incommingdata );
}
})
}//	200 lookup response
else{
	var label =''
	   var publish = publishcall( label,incommingdata );
}
}
})
			}else{
			var label =''
	   var publish = publishcall( label,incommingdata );
				}
		}
});
function publishcall(label,incommingdata){
	
		var incommingdata = incommingdata;
		//function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }

		var eventContext;
		if (incommingdata.reqType == 'Job_update') {
			eventContext = incommingdata.data[0].displayID
		} else {
			if (incommingdata.data[0].jobDisplayID !== undefined || incommingdata.data[0].jobDisplayID !== null) {
				eventContext = incommingdata.data[0].jobDisplayID
			} else {
				eventContext = incommingdata.data[0].job.displayID
			}
		}
		var EventTimeStamp;
		if (incommingdata.eventTime != undefined || incommingdata.eventTime != null) {
			EventTimeStamp = incommingdata.eventTime
		}
		var messageId;
		if (incommingdata.messageId != undefined || incommingdata.messageId != null) {
			messageId = incommingdata.messageId
		}
		var crewDisplayID;
		if (incommingdata.crewDisplayID != undefined || incommingdata.crewDisplayID != null) {
			crewDisplayID = incommingdata.crewDisplayID
		}
		var messageType;
		if (incommingdata.messageType != undefined || incommingdata.messageType != null) {
			messageType = incommingdata.messageType
		}
		var assignmentStatus;
		if (incommingdata.assignmentStatus != undefined || incommingdata.assignmentStatus != null) {
			assignmentStatus = incommingdata.assignmentStatus
		}
		var crewAssigmentTrigger;
		if (incommingdata.crewAssigmentTrigger != undefined || incommingdata.crewAssigmentTrigger != null) {
			crewAssigmentTrigger = incommingdata.crewAssigmentTrigger
		}
		var dateTime = new Date();
		var currentTime = dateTime.toISOString();
		var deflatedPayload = ctx.getVariable("deflatedPayload");
		var payload = {};
		if (incommingdata.messageType === "crewAssignmentEvent") {
			var crewAssignmentID;
			if (incommingdata.data[0].id != undefined || incommingdata.data[0].id != null) {
				crewAssignmentID = incommingdata.data[0].id
			}
			var crewAssignmentDisplayID;
			if (incommingdata.data[0].displayID != undefined || incommingdata.data[0].displayID != null) {
				crewAssignmentDisplayID = incommingdata.data[0].displayID
			}
			payload.crewAssignmentID = crewAssignmentID,
				payload.crewAssignmentDisplayID = crewAssignmentDisplayID
		}
		if (incommingdata.messageType === "jobEvent") {
			var jobID;
			if (incommingdata.data[0].job.id != undefined || incommingdata.data[0].job.id != null) {
				jobID = incommingdata.data[0].job.id
			} else {
				jobID = incommingdata.data[0].id
			}
			var jobDisplayID;
			if (incommingdata.data[0].job.displayID != undefined || incommingdata.data[0].job.displayID != null) {
				jobDisplayID = incommingdata.data[0].job.displayID
			} else {
				jobID = incommingdata.data[0].displayID
			}
			payload.jobID = jobID,
				payload.jobDisplayID = jobDisplayID
		}
		payload.messageId = messageId,
			payload.jobID = jobID,
			payload.serviceName = "workOrderFSE",
			payload.expiry = session.parameters.expiry,
			payload.eventType = "Status",
			payload.eventContext = eventContext,
			payload.payload = deflatedPayload,
			payload.EventTimeStamp = EventTimeStamp,
			payload.sendTimeStamp = currentTime,
			payload.waitTime = session.parameters.waitTime,
			payload.destQueueName = 'FOA.OHUG.RECEIVE.OHUG.CANCEL.WORK.SEQ',
			payload.crewDisplayID = crewDisplayID,
			payload.messageType = messageType,
			payload.assignmentStatus = assignmentStatus,
			payload.crewAssigmentTrigger = crewAssigmentTrigger,
	                payload.eventKey = incommingdata.data[0].displayID
	if(label.length>0){
		payload.workFlowType =	label
		payload.workFlowRequirementEvent ='N'
		}
		//ctx.setVar('payload',payload);
		//pushing to queue start
		session.output.write(payload);
		var StandaloneMQurl = session.parameters.foa_ohug_cancel_sequence_BackendMQSequanceUrl;
		var publishuri = {
			target: StandaloneMQurl,
			data: payload
		};

try{
		urlopen.open(publishuri, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(" foa_ohug_cancel_sequence error while keeping message to queue is " + error);
				var ErrorTxt = "FSE45_21: foa_ohug_cancel_sequence error while keeping message to queue is " + error;
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("retry", 'yes');
				//ctx.setVariable("exitstatus", response.statusCode)
				//session.reject("foa_ohug_sequence error while keeping message to queue is " + error);
			} else {
				var mqrc = response.statusCode;

				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 403
							//	session.reject("foa_ohug_sequence error while keeping message to queue is " + readError);
							var ErrorTxt = "FSE45_21: foa_ohug_cancel_sequence error while keeping message to queue is " + readError;
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("exitstatus", mqrc)
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(" foa_ohug_cancel_sequence response code is urlopen.open error [MQRC=" + mqrc + "]");
					
					//	session.reject(" foa_ohug_sequence response code is urlopen.open error [MQRC=" + mqrc + "]");
					var ErrorTxt = "FSE45_21: foa_ohug_cancel_sequence response code is urlopen.open error [MQRC=" + mqrc + "]";
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("exitstatus", mqrc);
					ctx.setVariable("retry", 'yes');
				}
			}
		});
		}
		catch (err) {
					var ErrorTxt = "FSE45_21: foa_ohug_cancel_sequence response code is urlopen.open error [MQRC=" + err + "]";
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("retry", 'yes');
						}
		//pushing to queue end

	
	}
	
	
	
