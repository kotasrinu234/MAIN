var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
session.INPUT.readAsBuffer(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		var BackoutURL = "dpmq://foa_ohug_sequence_Qmgr/?RequestQueue=FOA.OHUG.RECEIVE.OHUG.WORK.BACKOUT";
		var sendBackout = {
			target: BackoutURL,
			data: incomingdata
		};
		var info = " TargetURL :" + sendBackout.target + "; Data :" + JSON.stringify(sendBackout.data) + ". ";
		try {
			urlopen.open(sendBackout, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var errorinfo = "url open error in sending the message to backuout queue, details are : " + info + "; error info :" + error
					ctx.setVariable("exitStatus", "500")
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								hm.response.statusCode = 403
								var errorinfo = "Error in sending message to the backuout queue, details are : " + info + "; error info :" + readError
								ctx.setVariable("exitStatus", "500")
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								logger.debug("MQResponsecode " + mqrc);
								ctx.setVar("response", responseData);
							}
						});
					} else {
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								var errorinfo = "Failed to send message to the backuout queue, details are : " + info + "; error info :" + readError
								ctx.setVariable("exitStatus", mqrc)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "Failed to send message to the backuout queue, details are : " + info + "; response Info:" + responseData + "; ResponseStatusCode :" + mqrc
								ctx.setVariable("exitStatus", mqrc)
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "url open error in sending the message to the backuout queue, details are : " + info + "; error info :" + error
			ctx.setVariable("exitStatus", "500")
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	}
});
