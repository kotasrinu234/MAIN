var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
ctx.setVariable("exitstatus", '500');
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		var incommingdata = JSON.parse(jsonData);
		if (incommingdata.reqType == 'Job_update') {
			var label = ''
    var publish = publishcall( label,incommingdata );
		} else {
			if(!(incommingdata.data[0].workTypeID == undefined || incommingdata.data[0].workTypeID == null ||incommingdata.data[0].workTypeID == '' )){
			var lookupmessage=
					{"lookupReq":{"type":[{"name":"workTypes",
					"id":incommingdata.data[0].workTypeID,
					"status": "none"}]}}
				var lookupService = {
				target: session.parameters.lookUpURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupmessage  
				};
				urlopen.open(lookupService, function(error, response) {
						if (error) {
							logger.error(" urlopen connect error with LookupServiceResponse  " + JSON.stringify(error));
							//session.reject(" urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200 )  {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										logger.error(" error message from with LookupServiceResponse for " + JSON.stringify(error));
										//session.reject("error message from with LookupServiceResponse for " + JSON.stringify(error));
									} else {
										hm.response.statusCode = responseStatusCode;
										logger.debug("response received from LookupServiceResponse "+ responseStatusCode);			
										var lookupResponse = JSON.parse(responseData)
										var label;
										if(lookupResponse.lookupRep.type[0].result==0){
										 label= lookupResponse.lookupRep.type[0].label;
										}else{
											label="";
											}
											
    var publish = publishcall( label,incommingdata );
}
})
}//	200 lookup response
else{
	var label =''
	   var publish = publishcall( label,incommingdata );
}
}
})
			}else{
			var label =''
	   var publish = publishcall( label,incommingdata );
				}
		}
	}
});
function publishcall(label,incommingdata){
	
			var incommingdata = incommingdata
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }

		var eventContext;
		var crewAssignmentID;
		var crewAssignmentDisplayID;
		var jobID;
		var JobdisplayID;
		var crewDisplayID;
		if (incommingdata.reqType == 'Job_update') {
			if(!(incommingdata.data[0].displayID == undefined)){
			eventContext = incommingdata.data[0].displayID
			JobdisplayID = incommingdata.data[0].displayID
			}
			jobID = incommingdata.data[0].id
		} else {
			
			if (incommingdata.data[0].jobDisplayID != undefined || incommingdata.data[0].jobDisplayID != null) {
				eventContext = incommingdata.data[0].jobDisplayID
			} else {
				eventContext = incommingdata.data[0].job.displayID
			}
			if (incommingdata.data[0].id != undefined || incommingdata.data[0].id != null) {
				crewAssignmentID = incommingdata.data[0].id
			}
			if (incommingdata.data[0].displayID != undefined || incommingdata.data[0].displayID != null) {
				crewAssignmentDisplayID = incommingdata.data[0].displayID
			}
			if (incommingdata.data[0].job != undefined || incommingdata.data[0].job != null) {
				if (incommingdata.data[0].job.id != undefined || incommingdata.data[0].job.id != null) {
				jobID = incommingdata.data[0].job.id
			}
				if (incommingdata.data[0].job.displayID != undefined || incommingdata.data[0].job.displayID != null) {
				JobdisplayID = incommingdata.data[0].job.displayID
			}
			}
			if(incommingdata.data[0].crewDisplayID != undefined || incommingdata.data[0].crewDisplayID != null){
				crewDisplayID = incommingdata.data[0].crewDisplayID
			}
		}
		var EventTimeStamp;
		if (incommingdata.eventTime != undefined || incommingdata.eventTime != null) {
			EventTimeStamp = incommingdata.eventTime
		} else if (incommingdata.data[0].updatedAt != undefined || incommingdata.data[0].updatedAt != null) {
			EventTimeStamp = incommingdata.data[0].updatedAt;
		} else if (incommingdata.data[0].createdAt != undefined || incommingdata.data[0].createdAt != null) {
			EventTimeStamp = incommingdata.data[0].createdAt;
		}
		var dateTime = new Date();
		var currentTime = dateTime.toISOString();
		var deflatedPayload = ctx.getVariable("deflatedPayload");
		var payload =
		{
			"messageId": incommingdata.messageId,
			"serviceName": "workOrderFSE",
			"expiry": session.parameters.expiry,
			"eventType": "Status",
			"eventContext": eventContext,
			"payload": deflatedPayload,
			"EventTimeStamp": EventTimeStamp,
			"sendTimeStamp": currentTime,
			"waitTime": session.parameters.waitTime,
			"crewAssignmentID" : crewAssignmentID,
			"crewAssignmentDisplayID" :crewAssignmentDisplayID,
			"jobID" : jobID,
			"jobDisplayID" :JobdisplayID,
			"crewDisplayID" : crewDisplayID,
			"messageType" : incommingdata.messageType,
			"assignmentStatus" : incommingdata.assignmentStatus,
			"crewAssigmentTrigger" : incommingdata.crewAssigmentTrigger,
			"destQueueName": 'FOA.OHUG.RECEIVE.OHUG.WORK.SEQ',
		}
				if (!(incommingdata.reqType == 'Job_update')) {
					if(!(incommingdata.data[0].displayID == null || incommingdata.data[0].displayID == undefined || incommingdata.data[0].displayID == '')){
					payload.eventKey = incommingdata.data[0].displayID						
					}

					}
		if(label.length>0){
		payload.workFlowType =	label
		payload.workFlowRequirementEvent ='N'
		}
		session.output.write(payload);
		ctx.setVar('payload', payload);
		//pushing to queue start

		var StandaloneMQurl = session.parameters.foa_ohug_sequenceMQSequanceUrl;
		var publishuri = {
			target: StandaloneMQurl,
			data: payload
		};
 try{
		urlopen.open(publishuri, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(" foa_ohug_sequence error while keeping message to queue is " + error);
				var ErrorTxt = "FSE45_24: foa_ohug_sequence error while keeping message to queue is " + error;
				ctx.setVariable("ErrorTxt", ErrorTxt);
			//	ctx.setVariable("exitstatus", response.statusCode);
				ctx.setVariable("retry", 'yes');
				//session.reject("foa_ohug_sequence error while keeping message to queue is " + error);
			} else {
				var mqrc = response.statusCode;

				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 403
							var ErrorTxt = "FSE45_24: foa_ohug_sequence error while keeping message to queue is " + readError;
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("exitstatus", "403");
							//	session.reject("foa_ohug_sequence error while keeping message to queue is " + readError);
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(" foa_ohug_sequence response code is urlopen.open error [MQRC=" + mqrc + "]");
					var ErrorTxt = "FSE45_24: foa_ohug_sequence response code is urlopen.open error [MQRC=" + mqrc + "]";
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("exitstatus", mqrc);
					ctx.setVariable("retry", 'yes');
					//session.reject(" foa_ohug_sequence response code is urlopen.open error [MQRC=" + mqrc + "]");

				}
			}
		});
		} catch (err) {
							//session.reject("URL Open Connection Error :" + JSON.stringify(err));
							logger.error("URL Open Connection Error :" + JSON.stringify(err));
					var ErrorTxt = "FSE45_24: foa_ohug_sequence response code is urlopen.open error [MQRC=" + err + "]";
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("retry", 'yes');
						}
		//pushing to queue end
}
