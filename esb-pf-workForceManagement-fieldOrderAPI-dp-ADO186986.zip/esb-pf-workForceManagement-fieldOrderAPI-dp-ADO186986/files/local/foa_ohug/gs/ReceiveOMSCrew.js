var ctx = session.name("omsfoa_ohug") || session.createContext("omsfoa_ohug");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({'category': 'all'});
var urlIn = sm.getVar('var://service/URL-in');
var CancelQueue = session.parameters.CancelQueue;
var CreateUpdateQueue = session.parameters.CreateUpdateQueue;
session.input.readAsJSON(function(readAsJSONError, incommingdata){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
	} else {
		if(urlIn.includes('Cancel')){
			sentToQueue(CancelQueue,incommingdata);
		} else if (urlIn.includes('Update')){
			if(!(incommingdata.data[0].jobTypeID == null || incommingdata.data[0].jobTypeID == '' || incommingdata.data[0].jobTypeID == undefined)){
				incommingdata.reqType = "Job_update";
				sentToQueue(CreateUpdateQueue,incommingdata);
			} else {
				sentToQueue(CreateUpdateQueue,incommingdata);
			}
		} else if(urlIn.includes('Create')){
				incommingdata.reqType = "Create";
				sentToQueue(CreateUpdateQueue,incommingdata);
		} else {
			sentToQueue(CreateUpdateQueue,incommingdata);
		}
	}
});

function sentToQueue(targetQueue, incommingdata){
	var options = {
			target : targetQueue,
			data : incommingdata
	};
	urlopen.open(options, function(error, response){
		var hm = require('header-metadata');
		if(error){
			logger.error('FSE45_01: Mqurlopen.open error');
			session.reject('** Mqurlopen.open error');
			hm.response.statusCode = 500;
		} else {
			var mqrc = response.statusCode;
			if(mqrc == 0){
				response.readAsBuffer(function(readError, responseData){
					if(readError){
						hm.response.statusCode = 500
						logger.error('FSE45_01: Mqurlopen.open error')
					} else {
						
						console.log("MQResponseData "+ responseData);
					}
				});
			} else {
				logger.error('FSE45_01: ** Mqurlopen.open error [MQRC=' + mqrc + ']');
				session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
				hm.response.statusCode = 500
			}
		}
	});
}
