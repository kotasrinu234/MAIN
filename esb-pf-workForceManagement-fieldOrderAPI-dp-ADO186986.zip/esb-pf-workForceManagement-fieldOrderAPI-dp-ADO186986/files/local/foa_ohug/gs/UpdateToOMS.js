var ctx = session.name("foa_updateOMS") || session.createContext("foa_updateOMS");
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var crewAssignmentRes, workflowIdLabel, workTypeIdLabel, getCommentApiRes, workTypeIdStatus, crewWorkFlowApiRes, commentTime;
var ctxILS = session.name("ILS") || session.createContext("ILS");

session.input.readAsJSON(function(readAsJSONError, requestJson) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		var jobId = requestJson.ExternalRefID;
		var idArr = jobId.split(":");
		var reqType = requestJson.reqType;


		if ((!(reqType == "" || reqType == null || reqType == undefined)) && (reqType == "Cancel")) {
			CommentUpdate(null, requestJson.jobComment, idArr[0]);
		} else {
			// CrewAssignment by JobId API
			var crewAssignmentUri = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + idArr[1];
			var getcrewAssignmentApi = {
				target: crewAssignmentUri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': apiToken
				}
			};
			urlopen.open(getcrewAssignmentApi, function(error, response) {
				if (error) {
					logger.error("FSE45_17: urlopen connect error with Get getcrewAssignmentApi " + JSON.stringify(error));
					//	session.reject("urlopen connect error with Get getcrewAssignmentApi " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("failure in reading message from getcrewAssignmentApi" + JSON.stringify(error));
								session.reject(" failure in reading message from getcrewAssignmentApi" + JSON.stringify(error));
							} else {
								crewAssignmentRes = JSON.parse(responseData);
								//ctx.setVariable("crewAssignmentRes", crewAssignmentRes); 

								commentTime = new Date().toISOString();
								//								ctx.setVariable("commentTime", commentTime);
								// workflowIdLabellookup based on Crew Assignment by job id response
								var workflowIdLabellookup = {
									"lookupReq": {
										"type": [
											{
												"name": "workType.workflows",
												"id": crewAssignmentRes.workTypeID,
												"status": crewAssignmentRes.status
											}]
									}
								}
								var workflowIdLabelService = {
									target: session.parameters.lookUpURL,
									method: 'POST',
									contentType: 'application/json',
									data: workflowIdLabellookup
								};
								lookup(workflowIdLabelService, function(error, responseData) {
									if (error) {
										logger.error("Error in reading message with  workflowIdLabelService" + JSON.stringify(error));
									} else {
										var lookupResponse = responseData;
										if (lookupResponse.lookupRep.type[0].result == 0) {
											if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
												workflowIdLabel = lookupResponse.lookupRep.type[0].label;
												//ctx.setVariable("workflowIdLabel", workflowIdLabel);

												// workTypeIdlookup based on Crew Assignment by job id response
												if (workflowIdLabel == 'Dispatched' && (requestJson.status == 'Success' || requestJson.status == 'success')) {
													var workTypeIdlookup = {
														"lookupReq": {
															"type": [
																{
																	"name": "workType.workflows",
																	"id": crewAssignmentRes.workTypeID,
																	"label": "Dispatch Successful"
																}]
														}
													}
													var workTypeIdService = {
														target: session.parameters.lookUpURL,
														method: 'POST',
														contentType: 'application/json',
														data: workTypeIdlookup
													};
													lookup(workTypeIdService, function(error, responseData) {
														if (error) {
															logger.error("Error in reading message with  workTypeIdService" + JSON.stringify(error));
														} else {
															var lookupResponse = responseData;
															if (lookupResponse.lookupRep.type[0].result == 0) {
																if ((lookupResponse.lookupRep.type[0].status != undefined) && (lookupResponse.lookupRep.type[0].status != null) && (lookupResponse.lookupRep.type[0].status != '')) {
																	workTypeIdLabel = lookupResponse.lookupRep.type[0].label;
																	workTypeIdStatus = lookupResponse.lookupRep.type[0].status;
																	//																	ctx.setVariable("workTypeIdLabel", workTypeIdLabel);
																	//																	ctx.setVariable("workTypeIdStatus", workTypeIdStatus);

																	if (reqType == "" || reqType == null || reqType == undefined || reqType != "Job_update") {
																		//Calling Lookup Function to update the workflow status & Comments
																		var commentstatus = requestJson.status
																		LookUpUpdate(crewAssignmentRes.id, workTypeIdStatus, commentTime, requestJson.jobComment, idArr[0], commentstatus);
																	}
																} else {
																	workTypeIdLabel = "";
																}
															} else {
																workTypeIdLabel = "";
															}
														}
													})
												} else if (workflowIdLabel == 'Dispatched' && (requestJson.status == 'Failure' || requestJson.status == 'failure')) {
													var workTypeIdlookup = {
														"lookupReq": {
															"type": [
																{
																	"name": "workType.workflows",
																	"id": crewAssignmentRes.workTypeID,
																	"label": "Dispatch Failed"
																}]
														}
													}
													var workTypeIdService = {
														target: session.parameters.lookUpURL,
														method: 'POST',
														contentType: 'application/json',
														data: workTypeIdlookup
													};
													lookup(workTypeIdService, function(error, responseData) {
														if (error) {
															logger.error("Error in reading message with  workTypeIdService" + JSON.stringify(error));
														} else {
															var lookupResponse = responseData;
															if (lookupResponse.lookupRep.type[0].result == 0) {
																if ((lookupResponse.lookupRep.type[0].status != undefined) && (lookupResponse.lookupRep.type[0].status != null) && (lookupResponse.lookupRep.type[0].status != '')) {
																	workTypeIdLabel = lookupResponse.lookupRep.type[0].label;
																	workTypeIdStatus = lookupResponse.lookupRep.type[0].status;
																	//																	ctx.setVariable("workTypeIdLabel", workTypeIdLabel);
																	//																	ctx.setVariable("workTypeIdStatus", workTypeIdStatus);

																	if (reqType == "" || reqType == null || reqType == undefined || reqType != "Job_update") {
																		//Calling Lookup Function to update the workflow status & Comments
																		var commentstatus = requestJson.status
																		LookUpUpdate(crewAssignmentRes.id, workTypeIdStatus, null, requestJson.jobComment, idArr[0], commentstatus);
																	}
																} else {
																	workTypeIdLabel = "";
																}
															} else {
																workTypeIdLabel = "";
															}
														}
													})
												} else {
													if (reqType == "" || reqType == null || reqType == undefined || reqType != "Job_update") {
														//Calling Lookup Function to update the workflow status & Comments
														//	CommentUpdate(null,requestJson.jobComment,idArr[0]);
													}
												}// ENDS:  workTypeIdlookup based on Crew Assignment by job id	

											} else {
												workflowIdLabel = "";
											}
										} else {
											workflowIdLabel = "";
										}
									}
								})
								// ENDS:  workflowIdLabellookup based on Crew Assignment by job id
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								logger.error("failure in reading message from getcrewAssignmentApi" + JSON.stringify(error));
								session.reject("failure in reading message from getcrewAssignmentApi");
							} else {
								logger.error("Error code returned from getcrewAssignmentApi " + responseStatusCode + " " + responseData);
								//session.reject("Error code returned from getcrewAssignmentApi " + responseStatusCode + " " + responseData);
							}
						});
					}
				}
			})
			// END of CrewAssignment by JobId API
		}
		session.output.write(requestJson);
	}
	sm.setVar('var://service/mpgw/skip-backside', true);
});

function lookup(url, data) {
	urlopen.open(url, function(error, response) {
		if (error) {
			// an error occurred during request sending or response header parsing
			logger.error("FSE45_18: urlopen connect error lookup API" + JSON.stringify(error));
			session.reject("urlopen connect error lookup API" + JSON.stringify(error))
		} else {
			// read response data
			// get the response status code
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						// error while reading response or transferring data to Buffer
						logger.error("failure in reading message from  lookup call lookup API" + JSON.stringify(error));
						data(error, null);
					} else {
						ctxILS.setVariable("exitStatus", '0');
						hm.response.statusCode = '200 Message is received';
						logger.debug("response received from Lookup api:" + responseData);
						data(null, responseData);
					}
				})
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error("failure in reading message from  lookup API" + JSON.stringify(error));
						session.reject("failure in reading message from  lookup API");
					} else {
						hm.current.statusCode = responseStatusCode;
						logger.error("Error returned from lookup API call with statusCode " + responseStatusCode + " " + responseData);
						data("Error returned from lookup API call with statusCode " + responseStatusCode, null);

					}
				});
			}
		}
	});
}

function LookUpUpdate(id, workTypeIdStatus, commentTime, jobComment, idArr, commentstatus) {
	// CrewAssignment by JobId API
	var crewWorkFlowUri = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + id + '/WorkFlow';
	var crewWorkFlowMessage = {
		"status": workTypeIdStatus
	}
	var crewWorkFlowApi = {
		target: crewWorkFlowUri,
		sslClientProfile: 'OMS_Client_Profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: crewWorkFlowMessage
	};
	urlopen.open(crewWorkFlowApi, function(error, response) {
		if (error) {
			logger.error("FSE45_19: urlopen connect error with Get crewWorkFlowApi " + JSON.stringify(error));
			session.reject("urlopen connect error with Get crewWorkFlowApi " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						logger.error("failure in reading message from crewWorkFlowApi" + JSON.stringify(error));
						session.reject(" failure in reading message from crewWorkFlowApi" + JSON.stringify(error));
					} else {
						ctxILS.setVariable("exitStatus", '0');
						crewWorkFlowApiRes = JSON.parse(responseData);
						//						ctx.setVariable("crewWorkFlowApiRes", crewWorkFlowApiRes); 
						if (commentstatus != 'Success') {
							CommentUpdate(commentTime, jobComment, idArr);
						}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error("failure in reading message from crewWorkFlowApi" + JSON.stringify(error));
						session.reject("failure in reading message from crewWorkFlowApi");
					} else {
						logger.error("Error code returned from crewWorkFlowApi" + responseStatusCode + " " + responseData);
						session.reject("Error code returned from crewWorkFlowApi" + responseStatusCode + " " + responseData);
						// CommentUpdate(null,jobComment,idArr);
					}
				});
			}
		}
	})
	// END of CrewAssignment by JobId API
}

function CommentUpdate(commentTime, jobComment, idArr) {
	// Comment API by JobId

	if (!(commentTime == null || commentTime == "" || commentTime == undefined)) {
		var CommentAPIPayload = {
			"comment": "RECEIVED ON " + commentTime
		}
	} else {
		var CommentAPIPayload = {
			"comment": jobComment
		}
	}
	var CommentAPIUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + idArr + '/Comment';
	var getCommentApi = {
		target: CommentAPIUri,
		sslClientProfile: 'OMS_Client_Profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: CommentAPIPayload
	};
	urlopen.open(getCommentApi, function(error, response) {
		if (error) {
			logger.error("FSE45_20: urlopen connect error with Get getCommentApi " + JSON.stringify(error));
			session.reject("urlopen connect error with Get getCommentApi " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						logger.error("failure in reading message from getCommentApi" + JSON.stringify(error));
						session.reject(" failure in reading message from getCommentApi" + JSON.stringify(error));
					} else {
						getCommentApiRes = JSON.parse(responseData);
						ctxILS.setVariable("exitStatus", '0');
						//						ctx.setVariable("getCommentApiRes", getCommentApiRes);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error("failure in reading message from getCommentApi" + JSON.stringify(error));
						session.reject("failure in reading message from getCommentApi");
					} else {
						var ErrorTxt = ("Error code returned from getCommentApi" + responseStatusCode + " " + responseData);
						logger.error("Error code returned from getCommentApi" + responseStatusCode + " " + responseData);
						ctxILS.setVariable("exitStatus", responseStatusCode);
						ctxILS.setVariable("exitDescription", ErrorTxt);
						//session.reject("Error code returned from getCommentApi" + responseStatusCode + " " + responseData);
					}
				});
			}
		}
	})
	// END of Comment API by JobId
}
