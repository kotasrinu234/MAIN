var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var hm = require('header-metadata');
var urlopen = require('urlopen');
var logger = console.options({'category': 'all'});
var aoridLabel,aorIdslabel,crewAssignmentRes,callCodeLabel,workTypeIdLabel,workFlowIdLabel,WorkTypeIDLabelVal,workType,etrExpirationStatus,jobTypeIDLabel,JobTypeStatus,outageSubtypeIDLabel,getCommentApiRes,LeadCallApiRes,dateList,OUGAssociatedCrews,networkModelTypeLabel,EngineerReqAPIRes;
var omsExternalURL= session.parameters.omsExternalURL;
var apiToken= session.parameters.apiToken;
var aorlabelMap = new Map([
	['NAE','North Area Energy Ctr'],
	['MTC','Mt. Clemens'],
	['MAR','Marysville'],
	['LAP','Lapeer'],
	['SBY','Shelby'],
	['PON','Pontiac'],
	['HWL','Howell'],
	['RFD','Redford'],
	['CAN','Caniff'],
	['TBY','Trombly'],
	['ANN','Ann Arbor'],
	['WWS','Western Wayne'],
	['NPT','Newport']
	]);

var phasesMap = new Map([
	[1,'X'],
	[2,'Y'],
	[3,'Z']
	]);

var outageStepsTime = [];
var outageTimeVal = {};
var outageStepsRespArr = [];
var outageStepsArr = [];
var outageStepsResp = {};
var newArr = {};
var outageStepsTimeArr = [];
var outageStepsTimeVal = {};
var offOperationID,OffNetworkModelOperation,splitOperationID,SplitNetworkModelOperation,onOperationID,OnNetworkModelOperation,durationMs,StepID,AffectedCustomers,EnergizationStatus;
var phases;
var crewAssignmentUri;
var crewAssignments;
var aorIDsVal;
var observationsVal;

session.input.readAsJSON(function(readAsJSONError, requestJson){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
		logger.debug("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {

		var LookupPayload;
		var LookupPayloadArr = [];
		if(requestJson.crewAssigmentTrigger == 'Y'){
			if(!(requestJson.data[0].job.leadCallID == undefined || requestJson.data[0].job.leadCallID == null || requestJson.data[0].job.leadCallID == '')){
			var inputleadCallID = requestJson.data[0].job.leadCallID
				var GetCallapiuri = session.parameters.omsExternalURL +'/api/ServiceType/Electric/Call/'+inputleadCallID+'?includeFields=externalPremiseID';
					var apiToken = session.parameters.apiToken;
					var GetCallapi = {
								target: GetCallapiuri,
								sslClientProfile: 'OMS_Client_Profile',
								method: 'GET',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
										},
									};
						urlopen.open(GetCallapi, function(error, response) {
			if (error) {
				logger.error(" urlopen connect error with get GetCallapi for leadcallid"+inputleadCallID +' is '+ JSON.stringify(error));
				session.reject("urlopen connect error with get GetCallapi for leadcallid"+inputleadCallID +' is '+ JSON.stringify(error));
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200 )  {
					
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error(" while reading repsonse  from GetCallapi for leadcallid"+inputleadCallID +' is '+ JSON.stringify(error));
							session.reject("while reading repsonse  from GetCallapi for leadcallid"+inputleadCallID +' is '+ JSON.stringify(error));
						} else {				
							hm.response.statusCode = responseStatusCode;
							hm.response.statusCode = responseStatusCode;
							var  GetexternalPremiseID = JSON.parse(responseData).externalPremiseID
							if(!(GetexternalPremiseID == undefined || GetexternalPremiseID == null || GetexternalPremiseID ==  '' )){
							ctx.setVariable("PremisephasesData", GetexternalPremiseID );
							}else{
						ctx.setVariable("PremisephasesData", '' );								
							}

}
});
}else{
		response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error("failure while reading repsonse  from GetCallapi for leadcallid "+inputleadCallID+ " is :" + JSON.stringify(error));
						session.reject("failure while reading repsonse  from GetCallapi for leadcallid "+inputleadCallID + " is :" + JSON.stringify(error));
					} else {
						
						logger.error(" response while reading repsonse  from GetCallapi for leadcallid "+inputleadCallID+ " is :"+ responseStatusCode+" "+ responseData);	
						session.reject("response while reading repsonse  from GetCallapi for leadcallid "+inputleadCallID+ " is :"+ responseStatusCode+" "+ responseData);
			}
				});
	
	}				
}});
}
		}else{
			
			if(!(requestJson.data[0].leadCallID == undefined || requestJson.data[0].leadCallID == null || requestJson.data[0].leadCallID == '')){
			var inputleadCallID = requestJson.data[0].leadCallID
				var GetCallapiuri = session.parameters.omsExternalURL +'/api/ServiceType/Electric/Call/'+inputleadCallID+'?includeFields=externalPremiseID';
					var apiToken = session.parameters.apiToken;
					var GetCallapi = {
								target: GetCallapiuri,
								sslClientProfile: 'OMS_Client_Profile',
								method: 'GET',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
										},
									};
						urlopen.open(GetCallapi, function(error, response) {
			if (error) {
				logger.error(" urlopen connect error with get GetCallapi for leadcallid"+inputleadCallID +' is '+ JSON.stringify(error));
				session.reject("urlopen connect error with get GetCallapi for leadcallid"+inputleadCallID +' is '+ JSON.stringify(error));
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200 )  {
					
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error(" while reading repsonse  from GetCallapi for leadcallid"+inputleadCallID +' is '+ JSON.stringify(error));
							session.reject("while reading repsonse  from GetCallapi for leadcallid"+inputleadCallID +' is '+ JSON.stringify(error));
						} else {				
							hm.response.statusCode = responseStatusCode;
							hm.response.statusCode = responseStatusCode;
							var  GetexternalPremiseID = JSON.parse(responseData).externalPremiseID
							if(!(GetexternalPremiseID == undefined || GetexternalPremiseID == null || GetexternalPremiseID ==  '' )){
							ctx.setVariable("PremisephasesData", GetexternalPremiseID );
							}else{
						ctx.setVariable("PremisephasesData", '' );								
							}

}
});
}else{
		response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error("failure while reading repsonse  from GetCallapi for leadcallid "+inputleadCallID+ " is :" + JSON.stringify(error));
						session.reject("failure while reading repsonse  from GetCallapi for leadcallid "+inputleadCallID + " is :" + JSON.stringify(error));
					} else {
						
						logger.error(" response while reading repsonse  from GetCallapi for leadcallid "+inputleadCallID+ " is :"+ responseStatusCode+" "+ responseData);	
						session.reject("response while reading repsonse  from GetCallapi for leadcallid "+inputleadCallID+ " is :"+ responseStatusCode+" "+ responseData);
			}
				});
	
	}				
}});
}	
		
		
			
			
		}
		
		if ((!(requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined)) && (requestJson.reqType == "Job_update")){
			if(!(requestJson.data[0].aorIDs == undefined || requestJson.data[0].aorIDs == null || requestJson.data[0].aorIDs == '')) {
				LookupPayload = {
						"name": "aors",
						"id": requestJson.data[0].aorIDs[0]
				}
				LookupPayloadArr.push(LookupPayload);
			}
			if(!(requestJson.data[0].leadAssignmentWorkTypeID == undefined || requestJson.data[0].leadAssignmentWorkTypeID == null || requestJson.data[0].leadAssignmentWorkTypeID == '')) {
				LookupPayload = {
						"name": "workType.workflows",
						"id": requestJson.data[0].leadAssignmentWorkTypeID,
						"status": requestJson.data[0].status
				}

				var LookupPayload2={
						"name": "workTypes",
						"id": requestJson.data[0].leadAssignmentWorkTypeID,
						"status": "none"
				};
				LookupPayloadArr.push(LookupPayload,LookupPayload2);
			}
			if(!(requestJson.data[0].jobTypeID == undefined || requestJson.data[0].jobTypeID == null || requestJson.data[0].jobTypeID == '')) {
				LookupPayload = {
						"name": "jobTypes",
						"id": requestJson.data[0].jobTypeID,
						"status": "none"
				}	
				var LookupPayload2 ={
						"name": "jobTypes.workflows",
						"id": requestJson.data[0].jobTypeID,
						"status": requestJson.data[0].status
				}
				LookupPayloadArr.push(LookupPayload,LookupPayload2);
			}
			if(!(requestJson.data[0].outageSubtypeID == undefined || requestJson.data[0].outageSubtypeID == null || requestJson.data[0].outageSubtypeID == '')) {
				LookupPayload = {
						"name": "outageSubtypes",
						"id": requestJson.data[0].outageSubtypeID,
						"status": "none"
				}
				LookupPayloadArr.push(LookupPayload);
			}
			if(!(requestJson.data[0].etrExpirationStatus == undefined || requestJson.data[0].etrExpirationStatus == null || requestJson.data[0].etrExpirationStatus == '')) {
				LookupPayload = {
						"name": "etrExpirationStatuses",
						"id": requestJson.data[0].etrExpirationStatus
				}
				LookupPayloadArr.push(LookupPayload);
			}
			ctx.setVariable("LookupPayloadArr", LookupPayloadArr);
			
		} else {
			if(!(requestJson.data[0].job == undefined)){
			if(!(requestJson.data[0].job.aorIDs == undefined || requestJson.data[0].job.aorIDs == null || requestJson.data[0].job.aorIDs == '')) {
				LookupPayload = {
						"name": "aors",
						"id": requestJson.data[0].job.aorIDs[0]
				}
				LookupPayloadArr.push(LookupPayload);
			}
			}
			if(!(requestJson.data[0].workTypeID == undefined || requestJson.data[0].workTypeID == null || requestJson.data[0].workTypeID == '')) {
				LookupPayload = {
						"name": "workType.workflows",
						"id": requestJson.data[0].workTypeID,
						"status": requestJson.data[0].status
				}

				var LookupPayload2= {
						"name": "workTypes",
						"id": requestJson.data[0].workTypeID,
						"status": "none"
				};
				LookupPayloadArr.push(LookupPayload,LookupPayload2);
			}
			if(!(requestJson.data[0].job.jobTypeID == undefined || requestJson.data[0].job.jobTypeID == null || requestJson.data[0].job.jobTypeID == '')) {
				LookupPayload = {
						"name": "jobTypes",
						"id": requestJson.data[0].job.jobTypeID,
						"status": "none"
				}

				var LookupPayload2 ={
						"name": "jobTypes.workflows",
						"id": requestJson.data[0].job.jobTypeID,
						"status": requestJson.data[0].job.status
				};
				LookupPayloadArr.push(LookupPayload,LookupPayload2);
			}
			if(!(requestJson.data[0].job.outageSubtypeID == undefined || requestJson.data[0].job.outageSubtypeID == null || requestJson.data[0].job.outageSubtypeID == '')) {
				LookupPayload = {
						"name": "outageSubtypes",
						"id": requestJson.data[0].job.outageSubtypeID,
						"status": "none"
				}
				LookupPayloadArr.push(LookupPayload);
			}
			if(!(requestJson.data[0].job.etrExpirationStatus == undefined || requestJson.data[0].job.etrExpirationStatus == null || requestJson.data[0].job.etrExpirationStatus == '')) {
				LookupPayload = {
						"name": "etrExpirationStatuses",
						"id": requestJson.data[0].job.etrExpirationStatus
				}
				LookupPayloadArr.push(LookupPayload);
			}

			ctx.setVariable("LookupPayloadArr", LookupPayloadArr);
		}

		var lookupMessage = {
				"lookupReq": {
					"type": LookupPayloadArr
				}
		};
		var lookupService = {
				target: session.parameters.lookUpURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage  
		};
		lookup(lookupService, function(error, responseData) {
			if (error) {
				logger.error("Error in reading message with  lookupService" + JSON.stringify(error));
			} else {
				var lookupResponse = responseData;
				ctx.setVariable("lookupResponse", lookupResponse);	

				for(let i=0; i< lookupResponse.lookupRep.type.length; i++){
					if(lookupResponse.lookupRep.type[i].name == "aors"){
						// IF condition to identify label of aorid retrieved from data.job
						if (lookupResponse.lookupRep.type[i].result == 0) {
							if ((lookupResponse.lookupRep.type[i].label != undefined) && (lookupResponse.lookupRep.type[i].label != null) && (lookupResponse.lookupRep.type[i].label != '')) {
								aoridLabel = lookupResponse.lookupRep.type[i].label.substring(0,3);
								if (aoridLabel.includes("NAE") || aoridLabel.includes("MTC")||aoridLabel.includes("MAR")||aoridLabel.includes("LAP")||aoridLabel.includes("SBY")||aoridLabel.includes("PON")||aoridLabel.includes("HWL")||aoridLabel.includes("RFD")||aoridLabel.includes("CAN")||aoridLabel.includes("TBY")||aoridLabel.includes("ANN")||aoridLabel.includes("WWS")||aoridLabel.includes("NPT")) {
									var aoridLabelVal = aorlabelMap.get(aoridLabel);
									ctx.setVariable("aoridLabel", aoridLabelVal);
								} else {
									ctx.setVariable("aoridLabel", '');							
								}
							} else {
								aoridLabel = "";
							}
						} else {
							aoridLabel = "";
						}
					} else if (lookupResponse.lookupRep.type[i].name == "workType.workflows"){
						// IF condition to identify label of WorkTypeID retrieved from data
						if (lookupResponse.lookupRep.type[i].result == 0) {
							if ((lookupResponse.lookupRep.type[i].label != undefined) && (lookupResponse.lookupRep.type[i].label != null) && (lookupResponse.lookupRep.type[i].label != '')) {
								WorkTypeIDLabelVal = lookupResponse.lookupRep.type[i].label;
								ctx.setVariable("Data_WorkTypeID", WorkTypeIDLabelVal);
							} else {
								WorkTypeIDLabelVal = "";
							}
						} else {
							WorkTypeIDLabelVal = "";
						}
					} else if (lookupResponse.lookupRep.type[i].name == "jobTypes"){
						// IF condition to identify label of jobTypeID retrieved from data.job
						if (lookupResponse.lookupRep.type[i].result == 0) {
							if ((lookupResponse.lookupRep.type[i].label != undefined) && (lookupResponse.lookupRep.type[i].label != null) && (lookupResponse.lookupRep.type[i].label != '')) {
								jobTypeIDLabel = lookupResponse.lookupRep.type[i].label;
								ctx.setVariable("jobTypeIDLabel", jobTypeIDLabel);
							} else {
								jobTypeIDLabel = "";
							}
						} else {
							jobTypeIDLabel = "";
						}
					} else if (lookupResponse.lookupRep.type[i].name =="outageSubtypes"){
						// IF condition to identify label of outageSubtypes retrieved from data.job
						if (lookupResponse.lookupRep.type[i].result == 0) {
							if ((lookupResponse.lookupRep.type[i].label != undefined) && (lookupResponse.lookupRep.type[i].label != null) && (lookupResponse.lookupRep.type[i].label != '')) {
								outageSubtypeIDLabel = lookupResponse.lookupRep.type[i].label;
								ctx.setVariable("outageSubtypeIDLabel", outageSubtypeIDLabel);
							} else {
								outageSubtypeIDLabel = "";
							}
						} else {
							outageSubtypeIDLabel = "";
						}
					} else if (lookupResponse.lookupRep.type[i].name =="workTypes"){
						// IF condition to identify label of workType retrieved from data 
						if (lookupResponse.lookupRep.type[i].result == 0) {
							if ((lookupResponse.lookupRep.type[i].label != undefined) && (lookupResponse.lookupRep.type[i].label != null) && (lookupResponse.lookupRep.type[i].label != '')) {
								workType = lookupResponse.lookupRep.type[i].label;
								ctx.setVariable("workType", workType);
							} else {
								workType = "";
							}
						} else {
							workType = "";
						}
					}  else if (lookupResponse.lookupRep.type[i].name =="jobTypes.workflows"){
						// IF condition to identify label of JobType Workflows
						if (lookupResponse.lookupRep.type[i].result == 0) {
							if ((lookupResponse.lookupRep.type[i].label != undefined) && (lookupResponse.lookupRep.type[i].label != null) && (lookupResponse.lookupRep.type[i].label != '')) {
								JobTypeStatus = lookupResponse.lookupRep.type[i].label;
								ctx.setVariable("JobTypeStatus", JobTypeStatus);
							} else {
								JobTypeStatus = "";
							}
						} else {
							JobTypeStatus = "";
						}
					} else if (lookupResponse.lookupRep.type[i].name =="etrExpirationStatuses"){
						// IF condition to identify label of etrExpirationStatus retrieved from data.job 
						if (lookupResponse.lookupRep.type[i].result == 0) {
							if ((lookupResponse.lookupRep.type[i].label != undefined) && (lookupResponse.lookupRep.type[i].label != null) && (lookupResponse.lookupRep.type[i].label != '')) {
								etrExpirationStatus = lookupResponse.lookupRep.type[i].label;
								ctx.setVariable("etrExpirationStatus", etrExpirationStatus);
							} else {
								etrExpirationStatus = "";
							}
						} else {
							etrExpirationStatus = "";
						}
					}
				}

			}
		});

		//Time declaration from date&time Conversion 
		var etaTime,DTVal,jobStart,publishedEtr,outageStepsoffTime,createdAt,outageStepsonTime;
		DTVal = session.name('foa_dispatchWork').getVariable('DateConversionAPIResponse');

		for(let i=0; i< DTVal.DateConversion.dateList.length; i++){
			if(DTVal.DateConversion.dateList[i].fieldName == "job.publishedEtr.value"){
				publishedEtr = DTVal.DateConversion.dateList[i].toDateTime;
				ctx.setVariable("publishedEtr", publishedEtr);
			} else if (DTVal.DateConversion.dateList[i].fieldName == "eta") {
				etaTime = DTVal.DateConversion.dateList[i].toDateTime;
				ctx.setVariable("etaTime", etaTime);
			} else if (DTVal.DateConversion.dateList[i].fieldName == "job.start"){
				jobStart =  DTVal.DateConversion.dateList[i].toDateTime;
				ctx.setVariable("jobStart", jobStart);
//				var strDate = jobStart.split('T');
//				var arr = strDate[1].split(':');
//				var hour = 1 + parseInt(arr[0])+":";
//				var min = arr[1]+":";
//				var sec = arr[2];
//				ctx.setVariable("finishtime", strDate[0]+"T"+hour+min+sec);		
				
//				var date = "2022-07-20T00:34:04.418";
//				console.log('inputDate is ' + jobStart);
//				var changedDate = changeOffset(jobStart,1);
//				console.log('changedDate is ' + changedDate.toISOString());
//				ctx.setVariable("finishtime", changedDate.toISOString());
//
//				function changeOffset(jobStart,offset){
//				    var targetTime = new Date(jobStart);
//				    var tzDifference = offset * 60 + targetTime.getTimezoneOffset();
//				    var offsetTime = new Date(targetTime.getTime() + tzDifference*60*1000);
//				    return offsetTime;
//				}				
			} else if (DTVal.DateConversion.dateList[i].fieldName == "job.outageSteps.offTime"){
				outageStepsoffTime =  DTVal.DateConversion.dateList[i].toDateTime;
				ctx.setVariable("outageStepsoffTime", outageStepsoffTime);
				//outageTimeVal.StartTime = outageStepsoffTime;
			}  else if (DTVal.DateConversion.dateList[i].fieldName == "job.outageSteps.onTime"){
				outageStepsonTime =  DTVal.DateConversion.dateList[i].toDateTime;
				ctx.setVariable("outageStepsonTime", outageStepsonTime);
				//outageTimeVal.EndTime = outageStepsonTime;
			} else if (DTVal.DateConversion.dateList[i].fieldName == "createdAt") {
				createdAt =  DTVal.DateConversion.dateList[i].toDateTime;
				ctx.setVariable("createdAt", createdAt);
						//finish value 
		var finish = new Date(createdAt);
		var finishtime = 1;
									var datestrng = finish.toString();
							var edt = "Eastern Daylight Time";
							var edt1 = "EDT";
							var offset;
						if(datestrng.includes(edt) || datestrng.includes(edt1)){
							offset = -4;
						}else{
							offset = -5;
						}
						
						finish.setTime(finish.getTime() + finishtime * 60 * 60 * 1000);
						var	ESTDateVar = finish.getTime();
						var	localOffset = finish.getTimezoneOffset() * 60000;
						var	utc = ESTDateVar + (3600000*offset);
						var	ESTDate = new Date(utc).toISOString();
						ESTDate = ESTDate.replace('Z','');
		ctx.setVariable("finishtime", ESTDate);
			}
			outageStepsTime.push(outageTimeVal);
		}
		var CommentAPIUri;
		var LeadCallUri;
		var linkedDisplayVal;
		var networkModelOperations;
		var outageStepsVal;
		if ((!(requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined)) && (requestJson.reqType == "Job_update")){

			// aorsIds lookup
			if(!(requestJson.data[0].aorIDs == undefined || requestJson.data[0].aorIDs == null || requestJson.data[0].aorIDs =='')){
				aorIDsVal = requestJson.data[0].aorIDs;
				aorIDslookup(aorIDsVal);
			}

			//Observations lookup
			if(!(requestJson.data[0].observations == undefined || requestJson.data[0].observations == null || requestJson.data[0].observations =='')){
				observationsVal = requestJson.data[0].observations;
				observationslookup(observationsVal);
			}

			// Crew Assignment API by Assignment ID
			if(!(requestJson.data[0].crewAssignments == undefined || requestJson.data[0].crewAssignments == null || requestJson.data[0].crewAssignments =='')){
				crewAssignments= requestJson.data[0].crewAssignments;
				crewAssignmentsLookup(crewAssignments);
			} else {
				//logger.info("JobUpdate trigger doesn't have CrewAssignment information");
				session.reject("JobUpdate trigger doesn't have CrewAssignment information");
			}

			// Crew Assignment API by JobId
		//	crewAssignmentUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/'+requestJson.data[0].id+'/CrewAssignment';
		//	CrewAssignmentAPI(crewAssignmentUri,requestJson);
			// END of Crew Assignment API by JobId
			
			// Comment API by JobId
			CommentAPIUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/'+requestJson.data[0].id+'/Comment';
			CommentAPI(CommentAPIUri);
			// END of Comment API by JobId

			// LeadCall API by LeadCallId from Job
			if (!(requestJson.data[0].leadCallID == "" || requestJson.data[0].leadCallID == null || requestJson.data[0].leadCallID == undefined)){
				LeadCallUri = omsExternalURL + '/api/ServiceType/Electric/Call/'+requestJson.data[0].leadCallID;
				LeadCallAPI(LeadCallUri);
			}
			// END of LeadCall API by LeadCallId

			//Phases Representation
			if(!(requestJson.data[0].phases == undefined || requestJson.data[0].phases == null || requestJson.data[0].phases == '')){
				phases = requestJson.data[0].phases;
				phase(phases);
			}

			// Linked display representation
		//	linkedDisplayVal = requestJson.data[0].links;
		//	linkedRep(linkedDisplayVal);

			if(!(requestJson.data[0].networkModelOperations == undefined || requestJson.data[0].networkModelOperations == null || requestJson.data[0].networkModelOperations == '')){
				networkModelOperations = requestJson.data[0].networkModelOperations;
			}

			// outageSteps representation
			if(!(requestJson.data[0].outageSteps == undefined || requestJson.data[0].outageSteps == null || requestJson.data[0].outageSteps == '')){
				outageStepsVal = requestJson.data[0].outageSteps;
				// networkModelOperations representation
				outageSteps(outageStepsVal, networkModelOperations);
			}

			//Schema Validation for Non Mandate Values 
			if(!(requestJson.data[0].nominalFeeder == undefined || requestJson.data[0].nominalFeeder == null || requestJson.data[0].nominalFeeder == '')){
				ctx.setVariable("nominalFeeder", requestJson.data[0].nominalFeeder);
			}
			if(!(requestJson.data[0].nominalSubstation == undefined || requestJson.data[0].nominalSubstation == null || requestJson.data[0].nominalSubstation == '')){
				ctx.setVariable("nominalSubstation", requestJson.data[0].nominalSubstation);
			}
			if(!(requestJson.data[0].publishedEtrChangeCount == undefined || requestJson.data[0].publishedEtrChangeCount == null || requestJson.data[0].publishedEtrChangeCount == '')){
				ctx.setVariable("publishedEtrChangeCount", requestJson.data[0].publishedEtrChangeCount);
			}
			if(!(requestJson.data[0].substation == undefined || requestJson.data[0].substation == null || requestJson.data[0].substation == '')){
				ctx.setVariable("substation", requestJson.data[0].substation);
			}
			if(!(requestJson.data[0].validMeterRestorationNotifReceivedPercentage === undefined || requestJson.data[0].validMeterRestorationNotifReceivedPercentage === null || requestJson.data[0].validMeterRestorationNotifReceivedPercentage === '')){
				ctx.setVariable("validMeterOutageNotifReceivedPercentage", requestJson.data[0].validMeterRestorationNotifReceivedPercentage);
			}
			if(!(requestJson.data[0].etrStatus == undefined || requestJson.data[0].etrStatus == null || requestJson.data[0].etrStatus == '')){
				ctx.setVariable("etrStatus", requestJson.data[0].etrStatus);
			}

			if(!(requestJson.data[0].customFieldValuesExt == undefined || requestJson.data[0].customFieldValuesExt == null || requestJson.data[0].customFieldValuesExt == '')) {
				if(!(requestJson.data[0].customFieldValuesExt.cause == undefined || requestJson.data[0].customFieldValuesExt.cause == null || requestJson.data[0].customFieldValuesExt.cause == '')) {
					ctx.setVariable("cause", requestJson.data[0].customFieldValuesExt.cause);
				}
				if(!(requestJson.data[0].customFieldValuesExt.Remarks == undefined || requestJson.data[0].customFieldValuesExt.Remarks == null || requestJson.data[0].customFieldValuesExt.Remarks == '')) {
				   var newcomments = requestJson.data[0].customFieldValuesExt.Remarks.split("\\n").join("<br>");
													   newcomments = newcomments.split("\n").join("<br>");
												     	newcomments = newcomments.split("&lt;br&gt;").join("<br>");
					ctx.setVariable("Remarks", newcomments);
				}
				if(!(requestJson.data[0].customFieldValuesExt.Exchange_Meter_In == undefined || requestJson.data[0].customFieldValuesExt.Exchange_Meter_In == null || requestJson.data[0].customFieldValuesExt.Exchange_Meter_In == '')) {
					ctx.setVariable("Exchange_Meter_In", requestJson.data[0].customFieldValuesExt.Exchange_Meter_In);
				}
				if(!(requestJson.data[0].customFieldValuesExt.Exchange_Meter_Out == undefined || requestJson.data[0].customFieldValuesExt.Exchange_Meter_Out == null || requestJson.data[0].customFieldValuesExt.Exchange_Meter_Out == '')) {
					ctx.setVariable("Exchange_Meter_Out", requestJson.data[0].customFieldValuesExt.Exchange_Meter_Out);
				} 
				if(!(requestJson.data[0].customFieldValuesExt.Exchange_Meter_Out_Reading == undefined || requestJson.data[0].customFieldValuesExt.Exchange_Meter_Out_Reading == null || requestJson.data[0].customFieldValuesExt.Exchange_Meter_Out_Reading == '')) {
					ctx.setVariable("Exchange_Meter_Out_Reading", requestJson.data[0].customFieldValuesExt.Exchange_Meter_Out_Reading);
				}
				if(!(requestJson.data[0].customFieldValuesExt.Resource_Needed == undefined || requestJson.data[0].customFieldValuesExt.Resource_Needed == null || requestJson.data[0].customFieldValuesExt.Resource_Needed == '')) {
					ctx.setVariable("Resource_Needed", requestJson.data[0].customFieldValuesExt.Resource_Needed);
				}
				if(!(requestJson.data[0].customFieldValuesExt.crossStreets == undefined || requestJson.data[0].customFieldValuesExt.crossStreets == null || requestJson.data[0].customFieldValuesExt.crossStreets == '')){
					ctx.setVariable("OUGCrossStreets", requestJson.data[0].customFieldValuesExt.crossStreets);
				}
			}

			//OUGExtent, URDOPERATINGMAP, OHOPERATINGMAP
			if(!(requestJson.data[0].deviceInfo == null || requestJson.data[0].deviceInfo == '' || requestJson.data[0].deviceInfo == undefined)){
				if(!(requestJson.data[0].deviceInfo.customFieldValuesExt == null || requestJson.data[0].deviceInfo.customFieldValuesExt == '' || requestJson.data[0].deviceInfo.customFieldValuesExt == undefined)){
					if(!(requestJson.data[0].deviceInfo.customFieldValuesExt.URDOPERATINGMAP == null || requestJson.data[0].deviceInfo.customFieldValuesExt.URDOPERATINGMAP == '' || requestJson.data[0].deviceInfo.customFieldValuesExt.URDOPERATINGMAP == undefined)){
						ctx.setVariable("URDOPERATINGMAP", requestJson.data[0].deviceInfo.customFieldValuesExt.URDOPERATINGMAP);
					}
					if(!(requestJson.data[0].deviceInfo.customFieldValuesExt.OHOPERATINGMAP == null || requestJson.data[0].deviceInfo.customFieldValuesExt.OHOPERATINGMAP == '' || requestJson.data[0].deviceInfo.customFieldValuesExt.OHOPERATINGMAP == undefined)){
						ctx.setVariable("OHOPERATINGMAP", requestJson.data[0].deviceInfo.customFieldValuesExt.OHOPERATINGMAP);
					}
					
				}
			}
			
		} else {
			// aorsIds lookup 
			if(!(requestJson.data[0].job.aorIDs == undefined || requestJson.data[0].job.aorIDs == null || requestJson.data[0].job.aorIDs =='')){
				aorIDsVal = requestJson.data[0].job.aorIDs;
				aorIDslookup(aorIDsVal);
			}

			//Observations lookup 
			if(!(requestJson.data[0].job.observations == undefined || requestJson.data[0].job.observations == null || requestJson.data[0].job.observations =='')){
				observationsVal = requestJson.data[0].job.observations;
				observationslookup(observationsVal);
			}

			// Comment API by JobId
			CommentAPIUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/'+requestJson.data[0].job.id+'/Comment';
			CommentAPI(CommentAPIUri);
			// END of Comment API by JobId

			// Crew Assignment API by JobId
		//	crewAssignmentUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/'+requestJson.data[0].job.id+'/CrewAssignment';
		//	CrewAssignmentAPI(crewAssignmentUri,requestJson);
			// END of Crew Assignment API by JobId

			// LeadCall API by LeadCallId from Job
			if (!(requestJson.data[0].job.leadCallID == "" || requestJson.data[0].job.leadCallID == null || requestJson.data[0].job.leadCallID == undefined)){
				LeadCallUri = omsExternalURL + '/api/ServiceType/Electric/Call/'+requestJson.data[0].job.leadCallID;
				LeadCallAPI(LeadCallUri);
			}
			// END of LeadCall API by LeadCallId

			//Phases Representation
			if(!(requestJson.data[0].job.phases == undefined || requestJson.data[0].job.phases == null || requestJson.data[0].job.phases == '')){
				phases = requestJson.data[0].job.phases;
				phase(phases);
			}

			// Linked display representation
			//linkedDisplayVal = requestJson.data[0].job.links;
			//linkedRep(linkedDisplayVal);

			if(!(requestJson.data[0].job.networkModelOperations == undefined || requestJson.data[0].job.networkModelOperations == null || requestJson.data[0].job.networkModelOperations == '')){
				networkModelOperations = requestJson.data[0].job.networkModelOperations;
			}
			// outageSteps representation
			if(!(requestJson.data[0].job.outageSteps == undefined || requestJson.data[0].job.outageSteps == null || requestJson.data[0].job.outageSteps == '')){
				outageStepsVal = requestJson.data[0].job.outageSteps;
				// networkModelOperations representation 
				outageSteps(outageStepsVal, networkModelOperations);
			}

			//Schema Validation for Non Mandate Values
			if(!(requestJson.data[0].job.nominalFeeder == undefined || requestJson.data[0].job.nominalFeeder == null || requestJson.data[0].job.nominalFeeder == '')){
				ctx.setVariable("nominalFeeder", requestJson.data[0].job.nominalFeeder);
			}
			if(!(requestJson.data[0].job.nominalSubstation == undefined || requestJson.data[0].job.nominalSubstation == null || requestJson.data[0].job.nominalSubstation == '')){
				ctx.setVariable("nominalSubstation", requestJson.data[0].job.nominalSubstation);
			}
			if(!(requestJson.data[0].job.publishedEtrChangeCount == undefined || requestJson.data[0].job.publishedEtrChangeCount == null || requestJson.data[0].job.publishedEtrChangeCount == '')){
				ctx.setVariable("publishedEtrChangeCount", requestJson.data[0].job.publishedEtrChangeCount);
			}
			if(!(requestJson.data[0].job.substation == undefined || requestJson.data[0].job.substation == null || requestJson.data[0].job.substation == '')){
				ctx.setVariable("substation", requestJson.data[0].job.substation);
			}
			if(!(requestJson.data[0].job.validMeterRestorationNotifReceivedPercentage === undefined || requestJson.data[0].job.validMeterRestorationNotifReceivedPercentage === null || requestJson.data[0].job.validMeterRestorationNotifReceivedPercentage === '')){
				ctx.setVariable("validMeterOutageNotifReceivedPercentage", requestJson.data[0].job.validMeterRestorationNotifReceivedPercentage);
			}
			if(!(requestJson.data[0].job.etrStatus == undefined || requestJson.data[0].job.etrStatus == null || requestJson.data[0].job.etrStatus == '')){
				ctx.setVariable("etrStatus", requestJson.data[0].job.etrStatus);
			}

			if(!(requestJson.data[0].job.customFieldValuesExt == undefined || requestJson.data[0].job.customFieldValuesExt == null || requestJson.data[0].job.customFieldValuesExt == '')) {
				if(!(requestJson.data[0].job.customFieldValuesExt.cause == undefined || requestJson.data[0].job.customFieldValuesExt.cause == null || requestJson.data[0].job.customFieldValuesExt.cause == '')) {
					ctx.setVariable("cause", requestJson.data[0].job.customFieldValuesExt.cause);
				}
				if(!(requestJson.data[0].job.customFieldValuesExt.Remarks == undefined || requestJson.data[0].job.customFieldValuesExt.Remarks == null || requestJson.data[0].job.customFieldValuesExt.Remarks == '')) {
				      var newcomments = requestJson.data[0].job.customFieldValuesExt.Remarks.split("\\n").join("<br>");
													   newcomments = newcomments.split("\n").join("<br>");
												     	newcomments = newcomments.split("&lt;br&gt;").join("<br>");
					ctx.setVariable("Remarks", newcomments);
				}
				if(!(requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_In == undefined || requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_In == null || requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_In == '')) {
					ctx.setVariable("Exchange_Meter_In", requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_In);
				}
				if(!(requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_Out == undefined || requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_Out == null || requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_Out == '')) {
					ctx.setVariable("Exchange_Meter_Out", requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_Out);
				} 
				if(!(requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_Out_Reading == undefined || requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_Out_Reading == null || requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_Out_Reading == '')) {
					ctx.setVariable("Exchange_Meter_Out_Reading", requestJson.data[0].job.customFieldValuesExt.Exchange_Meter_Out_Reading);
				}
				if(!(requestJson.data[0].job.customFieldValuesExt.Resource_Needed == undefined || requestJson.data[0].job.customFieldValuesExt.Resource_Needed == null || requestJson.data[0].job.customFieldValuesExt.Resource_Needed == '')) {
					ctx.setVariable("Resource_Needed", requestJson.data[0].job.customFieldValuesExt.Resource_Needed);
				}
				if(!(requestJson.data[0].job.customFieldValuesExt.crossStreets == undefined || requestJson.data[0].job.customFieldValuesExt.crossStreets == null || requestJson.data[0].job.customFieldValuesExt.crossStreets == '')){
					ctx.setVariable("OUGCrossStreets", requestJson.data[0].job.customFieldValuesExt.crossStreets);
				}
			}

			if(!(requestJson.data[0].job.deviceInfo == null || requestJson.data[0].job.deviceInfo == '' || requestJson.data[0].job.deviceInfo == undefined)){
				if(!(requestJson.data[0].job.deviceInfo.customFieldValuesExt == null || requestJson.data[0].job.deviceInfo.customFieldValuesExt == '' || requestJson.data[0].job.deviceInfo.customFieldValuesExt == undefined)){
					if(!(requestJson.data[0].job.deviceInfo.customFieldValuesExt.URDOPERATINGMAP == null || requestJson.data[0].job.deviceInfo.customFieldValuesExt.URDOPERATINGMAP == '' || requestJson.data[0].job.deviceInfo.customFieldValuesExt.URDOPERATINGMAP == undefined)){
						ctx.setVariable("URDOPERATINGMAP", requestJson.data[0].job.deviceInfo.customFieldValuesExt.URDOPERATINGMAP);
					}
					if(!(requestJson.data[0].job.deviceInfo.customFieldValuesExt.OHOPERATINGMAP == null || requestJson.data[0].job.deviceInfo.customFieldValuesExt.OHOPERATINGMAP == '' || requestJson.data[0].job.deviceInfo.customFieldValuesExt.OHOPERATINGMAP == undefined)){
						ctx.setVariable("OHOPERATINGMAP", requestJson.data[0].job.deviceInfo.customFieldValuesExt.OHOPERATINGMAP);
					}
					
					if(!(requestJson.data[0].job.deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE == null || requestJson.data[0].job.deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE == '' || requestJson.data[0].job.deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE == undefined)){
					ctx.setVariable("OUGExtent", requestJson.data[0].job.deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE);
				}
				}
			}
		}
		//OUGExtent, URDOPERATINGMAP, OHOPERATINGMAP
		if(!(requestJson.data[0].deviceInfo == null || requestJson.data[0].deviceInfo == '' || requestJson.data[0].deviceInfo == undefined)){
			if(!(requestJson.data[0].deviceInfo.customFieldValuesExt == null || requestJson.data[0].deviceInfo.customFieldValuesExt == '' || requestJson.data[0].deviceInfo.customFieldValuesExt == undefined)){
				if(!(requestJson.data[0].deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE == null || requestJson.data[0].deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE == '' || requestJson.data[0].deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE == undefined)){
					ctx.setVariable("OUGExtent", requestJson.data[0].deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE);
				}
			}
		}

		if(!(requestJson.data[0].customFieldValuesExt == undefined || requestJson.data[0].customFieldValuesExt == null || requestJson.data[0].customFieldValuesExt == '')) {
			if(!(requestJson.data[0].customFieldValuesExt.CompletionRemarks == undefined || requestJson.data[0].customFieldValuesExt.CompletionRemarks == null || requestJson.data[0].customFieldValuesExt.CompletionRemarks == '')) {
				ctx.setVariable("CompletionRemarks", requestJson.data[0].customFieldValuesExt.CompletionRemarks);
			}
		}

		// Latitude & Logitude Update
		var Latitude,Longitude,OUGLatitude,OUGLongitude;
		if ((!(requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined)) && (requestJson.reqType == "Job_update")){
			if(!(requestJson.data[0].location == null || requestJson.data[0].location == '' || requestJson.data[0].location == undefined)){
				Latitude = requestJson.data[0].location.coordinates[1] * 1000000;
				ctx.setVariable("Latitude", parseInt(Latitude));
				ctx.setVariable("OUGLatitude", requestJson.data[0].location.coordinates[1]);
				ctx.setVariable("OUGAddressLat", requestJson.data[0].location.coordinates[1]);
				Longitude = requestJson.data[0].location.coordinates[0] * 1000000;
				ctx.setVariable("Longitude", parseInt(Longitude));
				ctx.setVariable("OUGLongitude", requestJson.data[0].location.coordinates[0]);
				ctx.setVariable("OUGAddressLong", requestJson.data[0].location.coordinates[0]);
			}
			if(!(requestJson.data[0].leadLocation == null || requestJson.data[0].leadLocation == '' || requestJson.data[0].leadLocation == undefined)){
				if(!(requestJson.data[0].leadLocation.label == null || requestJson.data[0].leadLocation.label == '' || requestJson.data[0].leadLocation.label == undefined)){
					ctx.setVariable("OUGLeadLocation", requestJson.data[0].leadLocation.label);
				}
				if(!(requestJson.data[0].leadLocation.gpsLocation == null || requestJson.data[0].leadLocation.gpsLocation == '' || requestJson.data[0].leadLocation.gpsLocation == undefined)){
					if(!(requestJson.data[0].leadLocation.gpsLocation.coordinates == null || requestJson.data[0].leadLocation.gpsLocation.coordinates == '' || requestJson.data[0].leadLocation.gpsLocation.coordinates == undefined)){
						ctx.setVariable("OUGLeadLocationLat", requestJson.data[0].leadLocation.gpsLocation.coordinates[1]);
						ctx.setVariable("OUGLeadLocationLong", requestJson.data[0].leadLocation.gpsLocation.coordinates[0]);
					}
				}
			}
		} else {
			if(!(requestJson.data[0].job.location == null || requestJson.data[0].job.location == '' || requestJson.data[0].job.location == undefined)){
				Latitude = requestJson.data[0].job.location.coordinates[1] * 1000000;
				ctx.setVariable("Latitude", parseInt(Latitude));
				ctx.setVariable("OUGAddressLat", requestJson.data[0].job.location.coordinates[1]);
				Longitude = requestJson.data[0].job.location.coordinates[0] * 1000000;
				ctx.setVariable("Longitude", parseInt(Longitude));
				ctx.setVariable("OUGAddressLong", requestJson.data[0].job.location.coordinates[0]);
			}
			if(!(requestJson.data[0].location == null || requestJson.data[0].location == '' || requestJson.data[0].location == undefined)){
				if(!(requestJson.data[0].location.coordinates == null || requestJson.data[0].location.coordinates == '' || requestJson.data[0].location.coordinates == undefined)){
					OUGLatitude = requestJson.data[0].location.coordinates[1];
					ctx.setVariable("OUGLatitude", OUGLatitude);
					OUGLongitude = requestJson.data[0].location.coordinates[0];
					ctx.setVariable("OUGLongitude", OUGLongitude);
				}
			}
			if(!(requestJson.data[0].job.leadLocation == null || requestJson.data[0].job.leadLocation == '' || requestJson.data[0].job.leadLocation == undefined)){
				if(!(requestJson.data[0].job.leadLocation.label == null || requestJson.data[0].job.leadLocation.label == '' || requestJson.data[0].job.leadLocation.label == undefined)){
					ctx.setVariable("OUGLeadLocation", requestJson.data[0].job.leadLocation.label);
				}
				if(!(requestJson.data[0].job.leadLocation.gpsLocation == null || requestJson.data[0].job.leadLocation.gpsLocation == '' || requestJson.data[0].job.leadLocation.gpsLocation == undefined)){
					if(!(requestJson.data[0].job.leadLocation.gpsLocation.coordinates == null || requestJson.data[0].job.leadLocation.gpsLocation.coordinates == '' || requestJson.data[0].job.leadLocation.gpsLocation.coordinates == undefined)){
						ctx.setVariable("OUGLeadLocationLat", requestJson.data[0].job.leadLocation.gpsLocation.coordinates[1]);
						ctx.setVariable("OUGLeadLocationLong", requestJson.data[0].job.leadLocation.gpsLocation.coordinates[0]);
					}
				}
			}
		}

		if ((requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined || requestJson.reqType !== "Job_update")){
			// FSE request to get the Engineer Name
			var employeeid = requestJson.data[0].crew.customFieldValuesExt.employeeid;
			//var EngineerReqURI = "https://fse-na-sb-int01.cloud.clicksoftware.com/so/api/objects/Engineer?$filter=ID%20eq%20'"+crewID+"'&$select=ID,Name,District,Region";  
			var EngineerReqURI = session.parameters.EngineerReqURIFSE+"?$filter=ID%20eq%20'"+employeeid+"'&$select=ID,Name,District,Region"
			var displayID = requestJson.data[0].displayID;
			var EngineerReqAPI = {
					target: EngineerReqURI,
					sslClientProfile: 'FSE_Client_Profile',
					method: 'GET',
					contentType: 'application/json',
					headers: {
						'Authorization': 'Basic '+session.parameters.FSEToken
					},
			};
			urlopen.open(EngineerReqAPI, function(error, response){
				if (error) {
					logger.error(": urlopen connect error with Get EngineerReqAPI " + JSON.stringify(error));
						var ErrorTxt = "FSE45_12 : urlopen connect error with Get EngineerReqAPI " + JSON.stringify(error) ;
						ctx.setVariable("ErrorTxt", ErrorTxt);
						ctx.setVariable("retry", 'yes')
						ctx.setVariable('exitDestination',EngineerReqURI)
				//	session.reject("urlopen connect error with Get EngineerReqAPI " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//logger.error("failure in reading message from EngineerReqAPI" + JSON.stringify(error));
								session.reject(" failure in reading message from EngineerReqAPI" + JSON.stringify(error));
							} else {
								EngineerReqAPIRes = JSON.parse(responseData);
								ctx.setVariable("EngineerReqAPIRes", EngineerReqAPIRes);
								var propertyName= '@DisplayString';
								var displayString;
								if(!(EngineerReqAPIRes.length < 1)){
									if (!(EngineerReqAPIRes[0].District == undefined || EngineerReqAPIRes[0].District == null || EngineerReqAPIRes[0].District == '')) {
										displayString = EngineerReqAPIRes[0].District[propertyName];
										ctx.setVariable("displayString", displayString);
									} else {
										logger.error("Null District value received from FSE Engineer API respective to employeeid "+employeeid+" for displayID "+displayID);
										ctx.setVariable("displayString", '');
										//sendtoQueue("DisplayString is null at FSE Engineer API respective to "+crewID);
									} 
								} else {
									logger.error("District object is either greater then one or zero from FSE Engineer API respective to employeeid "+employeeid+" for displayID "+displayID);
									ctx.setVariable("displayString", '');
									//sendtoQueue("DisplayString is null at FSE Engineer API respective to "+crewID);
								} 
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//session reject stop the transaction and go error rule with error code and description
							//	logger.info("failure in reading message from EngineerReqAPI" + JSON.stringify(error));
								session.reject("failure in reading message from EngineerReqAPI");
								sendtoQueue(error);
							} else {
						logger.error(": urlopen  error with Get EngineerReqAPI " + JSON.stringify(responseData));
						var ErrorTxt = "FSE45_12 : urlopen  error with Get EngineerReqAPI " + JSON.stringify(responseData) ;
						ctx.setVariable("ErrorTxt", ErrorTxt);
						ctx.setVariable("retry", 'yes')
						ctx.setVariable('exitDestination',EngineerReqURI)
//							//	logger.info("Error code returned from EngineerReqAPI" + responseStatusCode + " " + responseData);
//								session.reject("Error code returned from EngineerReqAPI" + responseStatusCode + " " + responseData);
//								sendtoQueue(responseData);
							}
						});
					}
				}
			}); // END FSE request to get the Engineer Name
		}
	}
});

/*function linkedRep(linkedDisplayVal){
	var linkedDisplayID;
	if (!(linkedDisplayVal == null || linkedDisplayVal == undefined || linkedDisplayVal == '')){
		var idVal;
		var idArr = new Array();
		if(linkedDisplayVal.length > 1) {
			for( var i=0; i< linkedDisplayVal.length; i++){
				idVal=linkedDisplayVal[i].linkedDisplayID;
				idArr.push(idVal);
			}
			ctx.setVariable("linkedDisplayID", idArr.join('-'));
			linkedDisplayID = idArr.join('-');
		} else {
			idVal = linkedDisplayVal[0].linkedDisplayID;
			ctx.setVariable("linkedDisplayID", idVal);
		}
	} 
}*/

//Logic of OperationId retrieved from OutageSteps
function outageSteps(outageStepsVal,networkModelOperations){
var offTime,onTime;
	for (let j=0;j< outageStepsVal.length;j++) {
		if(!(outageStepsVal[j].offOperationID == undefined || outageStepsVal[j].offOperationID == null || outageStepsVal[j].offOperationID == '')){
			offOperationID = outageStepsVal[j].offOperationID;
			outageStepsResp.offOperationID = offOperationID;
		}
		if(!(outageStepsVal[j].splitOperationID == undefined || outageStepsVal[j].splitOperationID == null ||outageStepsVal[j].splitOperationID == '')){
			splitOperationID =outageStepsVal[j].splitOperationID;
			outageStepsResp.splitOperationID = splitOperationID;
		}
		if(!(outageStepsVal[j].onOperationID == undefined ||outageStepsVal[j].onOperationID == null ||outageStepsVal[j].onOperationID == '')){
			onOperationID =outageStepsVal[j].onOperationID;
			outageStepsResp.onOperationID = onOperationID;
		}
		if(!(outageStepsVal[j].displayID == undefined ||outageStepsVal[j].displayID == null ||outageStepsVal[j].displayID == '')){
			StepID = outageStepsVal[j].displayID;
			outageStepsResp.StepID = StepID;
		}
		if(!(outageStepsVal[j].durationMs == undefined ||outageStepsVal[j].durationMs == null ||outageStepsVal[j].durationMs == '')){
			durationMs =JSON.stringify(outageStepsVal[j].durationMs / 1000);
			outageStepsResp.durationMs = durationMs;
		}
		if(!(outageStepsVal[j].premiseIDs == undefined ||outageStepsVal[j].premiseIDs == null ||outageStepsVal[j].premiseIDs == '')){
			AffectedCustomers =outageStepsVal[j].premiseIDs.length;
			outageStepsResp.AffectedCustomers = AffectedCustomers;
		}
		if(!(outageStepsVal[j].status == undefined ||outageStepsVal[j].status == null ||outageStepsVal[j].status == '')){
			EnergizationStatus =outageStepsVal[j].status;
			outageStepsResp.EnergizationStatus = EnergizationStatus;
		}
		if(!(outageStepsVal[j].offTime == undefined ||outageStepsVal[j].offTime == null ||outageStepsVal[j].offTime == '')){
			offTime =outageStepsVal[j].offTime;
			outageStepsResp.offTime = offTime;
		}
		if(!(outageStepsVal[j].onTime == undefined ||outageStepsVal[j].onTime == null ||outageStepsVal[j].onTime == '')){
			onTime =outageStepsVal[j].onTime;
			outageStepsResp.onTime = onTime;
		}
		outageStepsArr.push(outageStepsResp);
		outageStepsResp ={}
	}
	ctx.setVariable("outageStepsArr", outageStepsArr);

	for (let i=0;i < outageStepsArr.length;i++) {
		if(!(outageStepsArr[i].StepID == undefined || outageStepsArr[i].StepID == null || outageStepsArr[i].StepID == '')){
			newArr.StepID = outageStepsArr[i].StepID;
		}
		if(!(outageStepsArr[i].offTime == undefined || outageStepsArr[i].offTime == null || outageStepsArr[i].offTime == '')){
			var name = "outageSteps.offTime";
			var changedDate = DateConversion(name, outageStepsArr[i].offTime ,outageStepsArr[i].StepID ,"offTime");
			//ctx.setVariable("changedOffDate", changedDate);
			
			newArr.StartTime = changedDate;
		}
		if(!(outageStepsArr[i].onTime == undefined || outageStepsArr[i].onTime == null || outageStepsArr[i].onTime == '')){
			var name = "outageSteps.onTime";
			var changedDate = DateConversion(name, outageStepsArr[i].onTime ,outageStepsArr[i].StepID , "onTime");
		//	ctx.setVariable("changedOnDate", changedDate);
			newArr.EndTime = changedDate;
		}
		if(!(outageStepsArr[i].durationMs == undefined || outageStepsArr[i].durationMs == null || outageStepsArr[i].durationMs == '')){
			newArr.OutageDuration =outageStepsArr[i].durationMs;
		}
		if(!(outageStepsArr[i].AffectedCustomers == undefined ||outageStepsArr[i].AffectedCustomers == null || outageStepsArr[i].AffectedCustomers == '')){
			
			newArr.AffectedCustomers =outageStepsArr[i].AffectedCustomers;
		}
		if(!(outageStepsArr[i].EnergizationStatus == undefined || outageStepsArr[i].EnergizationStatus == null || outageStepsArr[i].EnergizationStatus == '')){
			newArr.EnergizationStatus = outageStepsArr[i].EnergizationStatus;
		}
		if(!(networkModelOperations == null || networkModelOperations == '' || networkModelOperations == undefined)){
			for (let j=0;j < networkModelOperations.length;j++) {
				if (networkModelOperations[j].id == outageStepsArr[i].offOperationID) {
					var OffNetworkModelOperation = [];
					var OffNetworkModelOperationpart1 = [];
					//	operationType = networkModelOperations[j].operationType,networkModelOperations[j].deviceInfo.type,networkModelOperations[j].device,networkModelOperations[j].operationTime,networkModelOperations[j].phases,networkModelOperations[j].affectedPremises,networkModelOperations[j].deviceInfo.address
					//newArr.OffNetworkModelOperation = OffNetworkModelOperation.join(';');
					if(!(networkModelOperations[j].operationType == undefined || networkModelOperations[j].operationType == null || networkModelOperations[j].operationType == '')){
						OffNetworkModelOperationpart1.push(networkModelOperations[j].operationType);
					}
					if(!(networkModelOperations[j].deviceInfo == undefined || networkModelOperations[j].deviceInfo == null || networkModelOperations[j].deviceInfo == '')){
						OffNetworkModelOperationpart1.push(networkModelOperations[j].deviceInfo.type);
					}
					if(!(networkModelOperations[j].device == undefined || networkModelOperations[j].device == null || networkModelOperations[j].device == '')){
						OffNetworkModelOperationpart1.push(networkModelOperations[j].device);
					}
					if(!(networkModelOperations[j].operationTime == undefined || networkModelOperations[j].operationTime == null || networkModelOperations[j].operationTime == '')){
						//OffNetworkModelOperation.push(networkModelOperations[j].operationTime);
						var name = "operationTime"
							var changedDate = DateConversion(name, networkModelOperations[j].operationTime ,outageStepsArr[i].StepID , "OffNetworkModelOperation");
					}
					if(!(networkModelOperations[j].phases == undefined || networkModelOperations[j].phases == null || networkModelOperations[j].phases == '')){
					
					var phasesIn = networkModelOperations[j].phases;
					var phasevalue;
					if(phasesIn == '100'){phasevalue = 'X'
					}else if(phasesIn == '020'){phasevalue = 'Y'	
					}else if(phasesIn == '003'){phasevalue = 'Z'
					}else if(phasesIn == '120'){phasevalue = 'XY'
					}else if(phasesIn == '023'){phasevalue = 'YZ'					
					}else if(phasesIn == '103'){phasevalue = 'XZ'						
					}else if(phasesIn == '123'){phasevalue = 'XYZ'}
					
						OffNetworkModelOperation.push(phasevalue);
					}
					if(!(networkModelOperations[j].affectedPremises == undefined || networkModelOperations[j].phases == null || networkModelOperations[j].affectedPremises == '')){
						OffNetworkModelOperation.push(networkModelOperations[j].affectedPremises);
					}
					if(!(networkModelOperations[j].deviceInfo == undefined || networkModelOperations[j].deviceInfo == null || networkModelOperations[j].deviceInfo == '')){
						OffNetworkModelOperation.push(networkModelOperations[j].deviceInfo.address);
					}
					newArr.OffNetworkModelOperationpart1 = OffNetworkModelOperationpart1.join(';');
					newArr.OffNetworkModelOperation = OffNetworkModelOperation.join(';');
				}
				if (networkModelOperations[j].id == outageStepsArr[i].splitOperationID) {
					var SplitNetworkModelOperation = [];
					var SplitNetworkModelOperationpart1 = [];
					if(!(networkModelOperations[j].operationType == undefined || networkModelOperations[j].operationType == null || networkModelOperations[j].operationType == '')){
						SplitNetworkModelOperationpart1.push(networkModelOperations[j].operationType);
					}
					if(!(networkModelOperations[j].deviceInfo == undefined || networkModelOperations[j].deviceInfo == null || networkModelOperations[j].deviceInfo == '')){
						SplitNetworkModelOperationpart1.push(networkModelOperations[j].deviceInfo.type);
					}
					if(!(networkModelOperations[j].device == undefined || networkModelOperations[j].device == null || networkModelOperations[j].device == '')){
						SplitNetworkModelOperationpart1.push(networkModelOperations[j].device);
					}
					if(!(networkModelOperations[j].operationTime == undefined || networkModelOperations[j].operationTime == null || networkModelOperations[j].operationTime == '')){
						//SplitNetworkModelOperation.push(networkModelOperations[j].operationTime);
							var name = "operationTime"
							var changedDate = DateConversion(name, networkModelOperations[j].operationTime ,outageStepsArr[i].StepID , "SplitNetworkModelOperation");
					}
					if(!(networkModelOperations[j].phases == undefined || networkModelOperations[j].phases == null || networkModelOperations[j].phases == '')){
						//SplitNetworkModelOperation.push(networkModelOperations[j].phases);
						var phasesIn = networkModelOperations[j].phases;
					var phasevalue;
					if(phasesIn == '100'){phasevalue = 'X'
					}else if(phasesIn == '020'){phasevalue = 'Y'	
					}else if(phasesIn == '003'){phasevalue = 'Z'
					}else if(phasesIn == '120'){phasevalue = 'XY'
					}else if(phasesIn == '023'){phasevalue = 'YZ'					
					}else if(phasesIn == '103'){phasevalue = 'XZ'						
					}else if(phasesIn == '123'){phasevalue = 'XYZ'}
					SplitNetworkModelOperation.push(phasevalue);
					}
					if(!(networkModelOperations[j].affectedPremises == undefined || networkModelOperations[j].phases == null || networkModelOperations[j].affectedPremises == '')){
						SplitNetworkModelOperation.push(networkModelOperations[j].affectedPremises);
					}
					if(!(networkModelOperations[j].deviceInfo == undefined || networkModelOperations[j].deviceInfo == null || networkModelOperations[j].deviceInfo == '')){
						SplitNetworkModelOperation.push(networkModelOperations[j].deviceInfo.address);
					}
					newArr.SplitNetworkModelOperationpart1 = SplitNetworkModelOperationpart1.join(';');
					newArr.SplitNetworkModelOperation = SplitNetworkModelOperation.join(';');
				}
				if (networkModelOperations[j].id == outageStepsArr[i].onOperationID) {
					var OnNetworkModelOperationpart1 = [];
					var OnNetworkModelOperation = [];
					if(!(networkModelOperations[j].operationType == undefined || networkModelOperations[j].operationType == null || networkModelOperations[j].operationType == '')){
						OnNetworkModelOperationpart1.push(networkModelOperations[j].operationType);
					}
					if(!(networkModelOperations[j].deviceInfo == undefined || networkModelOperations[j].deviceInfo == null || networkModelOperations[j].deviceInfo == '')){
						OnNetworkModelOperationpart1.push(networkModelOperations[j].deviceInfo.type);
					}
					if(!(networkModelOperations[j].device == undefined || networkModelOperations[j].device == null || networkModelOperations[j].device == '')){
						OnNetworkModelOperationpart1.push(networkModelOperations[j].device);
					}
					if(!(networkModelOperations[j].operationTime == undefined || networkModelOperations[j].operationTime == null || networkModelOperations[j].operationTime == '')){
						//OnNetworkModelOperation.push(networkModelOperations[j].operationTime);
						var name = "operationTime"
							var changedDate = DateConversion(name, networkModelOperations[j].operationTime ,outageStepsArr[i].StepID , "operationTime");
					}
					if(!(networkModelOperations[j].phases == undefined || networkModelOperations[j].phases == null || networkModelOperations[j].phases == '')){
						//OnNetworkModelOperation.push(networkModelOperations[j].phases);
						var phasesIn = networkModelOperations[j].phases;
					var phasevalue;
					if(phasesIn == '100'){phasevalue = 'X'
					}else if(phasesIn == '020'){phasevalue = 'Y'	
					}else if(phasesIn == '003'){phasevalue = 'Z'
					}else if(phasesIn == '120'){phasevalue = 'XY'
					}else if(phasesIn == '023'){phasevalue = 'YZ'					
					}else if(phasesIn == '103'){phasevalue = 'XZ'						
					}else if(phasesIn == '123'){phasevalue = 'XYZ'}
						OnNetworkModelOperation.push(phasevalue);
					}
					if(!(networkModelOperations[j].affectedPremises == undefined || networkModelOperations[j].phases == null || networkModelOperations[j].affectedPremises == '')){
						OnNetworkModelOperation.push(networkModelOperations[j].affectedPremises);
					}
					if(!(networkModelOperations[j].deviceInfo == undefined || networkModelOperations[j].deviceInfo == null || networkModelOperations[j].deviceInfo == '')){
						OnNetworkModelOperation.push(networkModelOperations[j].deviceInfo.address);
					}
					newArr. OnNetworkModelOperationpart1= OnNetworkModelOperationpart1.join(';');
					newArr.OnNetworkModelOperation = OnNetworkModelOperation.join(';');
				}
			}
		}
		outageStepsRespArr.push(newArr);
		newArr ={}
	}

	ctx.setVariable("outageStepsRespArr", outageStepsRespArr);
}


function DateConversion(name, DateTimeVal ,StepID, Time){
	
	dateList = {
			"DateConversion": {
				"action": "1",
				"dateList": [
					{
						"fieldName": name,
						"fromDateTime": DateTimeVal
					}
					]
			}
	};
	var DateConversionAPI = {
			target : session.parameters.ConversionService,
			data : dateList,
			contentType: 'application/json',
			method: 'POST'
	};
	urlopen.open(DateConversionAPI, function(error, response) {
		if (error) {
			logger.error("FSE45_08: urlopen connect error to the DateConversion for OutageStepsVal" + JSON.stringify(error));
			session.reject("urlopen connect error to the DateConversion for OutageStepsVal" + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				logger.info("FSEapi response status code 200 ");
				response.readAsBuffer(function(error, responseData) {
					if (error) {
					//	logger.error("Failure in reading message from DateConversion for OutageStepsVal"+JSON.stringify(error));
						session.reject("Failure in reading message from Get DateConversion for OutageStepsVal" + JSON.stringify(error));
					} else {
						var DateTimeConversionAPIRes = JSON.parse(responseData);
						ctx.setVariable("DateTimeConversionAPIRes",DateTimeConversionAPIRes);
						ctx.setVariable("DateTime_"+Time+"_"+StepID,DateTimeConversionAPIRes.DateConversion.dateList[0].toDateTime);
						return DateTimeConversionAPIRes.DateConversion.dateList[0].toDateTime;
					}
				});
			}
		}
	});
}

function lookup(url, data){
	urlopen.open(url, function(error, response) {
		if (error) {
			// an error occurred during request sending or response header parsing
			logger.error("FSE45_06: urlopen connect error Lookup API " + JSON.stringify(error));
			session.reject("urlopen connect error Lookup API " + JSON.stringify(error));
		} else {
			// read response data
			// get the response status code
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						// error while reading response or transferring data to Buffer
						logger.error("failure in reading message from  lookup call" + JSON.stringify(error));
						data(error, null);
					} else {
						hm.response.statusCode = '200 Message is received';
						logger.debug("response received from Lookup api:" + responseData);
						data(null, responseData);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						//logger.error("failure in reading message from  OMS call" + JSON.stringify(error));
						session.reject("failure in reading message from  OMS call ");
					} else {
						hm.current.statusCode = responseStatusCode;
						logger.error("Error returned from lookup OMS call with statusCode " + responseStatusCode+" "+ responseData);
						data("Error returned from lookup OMS call with statusCode " + responseStatusCode, null);
					}
				});
			}
		}
	});
}

function aorIDslookup(aorIDsVal){
	var aorIdslabelarr = [];
	for (let i=0; i < aorIDsVal.length;i++) {
		var aorIdsmessage = {
				"lookupReq": {
					"type": [
						{
							"name": "aors",
							"id": aorIDsVal[i]
						}	]
				}
		};
		var aorIdslookup = {
				target: session.parameters.lookUpURL,
				method: 'POST',
				contentType: 'application/json',
				data: aorIdsmessage  
		};
		lookup(aorIdslookup, function(error, responseData) {
			if (error) {
				logger.error("Error in reading message with  aorIdslookup" + JSON.stringify(error));
			} else {
				var lookupResponse = responseData;
				if (lookupResponse.lookupRep.type[0].result == 0) {
					if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
						aorIdslabel = lookupResponse.lookupRep.type[0].label;
						if(aorIDsVal.length <= 1){
							ctx.setVariable("aorIdslabel", aorIdslabel);
						} else {
							aorIdslabelarr.push(aorIdslabel);
							ctx.setVariable("aorIdslabel", aorIdslabelarr);
						}
					} else {
						aorIdslabel = "";
					}
				} else {
					aorIdslabel = "";
				}
			}
		});
	}
}
//END of aorsIds Lookup

function observationslookup(observationsVal){
	var observationslabelarr =[];
	var observationslabel;
	for (let i=0; i < observationsVal.length;i++) {
		var OBlookupmessage = {
				"lookupReq": {
					"type": [
						{
							"name": "observations",
							"status": observationsVal[i]
						}	]
				}
		};
		var OBlookup = {
				target: session.parameters.lookUpURL,
				method: 'POST',
				contentType: 'application/json',
				data: OBlookupmessage  
		};
		lookup(OBlookup, function(error, responseData) {
			if (error) {
				logger.error("Error in reading message with  OBlookup" + JSON.stringify(error));
			} else {
				var lookupResponse = responseData;
				if (lookupResponse.lookupRep.type[0].result == 0) {
					if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
						observationslabel = lookupResponse.lookupRep.type[0].label;
						if(observationsVal.length <= 1){
							ctx.setVariable("observationslabel", observationslabel);
						} else {
							observationslabelarr.push(observationslabel);
							ctx.setVariable("observationslabel", observationslabelarr.join(','));
						}
					} else {
						observationslabel = "";
					}
				} else {
					observationslabel = "";
				}
			}
		});
	}
}
//END of Observations Lookup

function crewAssignmentsLookup(crewAssignments){
	var crewworkTypeIdLabel;
	// workTypeIdlookup based on Crew Assignment by job id response
	var CrewAssignmentIdArray =  [];
	for(let i=0; i< crewAssignments.length;i++){
		if(crewAssignments[i].resolved == false){
			var crewworkTypeIdlookup = {
					"lookupReq": {
						"type": [
							{
								"name": "workTypes",
								"id": crewAssignments[i].workTypeID,
								"status": "none"
							}	]
					}
			};
			var crewworkTypeIdService = {
					target: session.parameters.lookUpURL,
					method: 'POST',
					contentType: 'application/json',
					data: crewworkTypeIdlookup  
			};
			lookup(crewworkTypeIdService, function(error, responseData) {
				if (error) {
					logger.error("Error in reading message with crewworkTypeIdService" + JSON.stringify(error));
				} else {
					var lookupResponse = responseData;
					if (lookupResponse.lookupRep.type[0].result == 0) {
						if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
							crewworkTypeIdLabel = lookupResponse.lookupRep.type[0].label;
							ctx.setVariable("crewworkTypeIdLabel__"+[i]+"__"+crewAssignments[i].id,crewworkTypeIdLabel);
							if(lookupResponse.lookupRep.type[0].label == 'OH/UG'){

//					var workTypeLookup = {
//								"lookupReq": {
//										"type": [
//												{
//												"name": "workType.workflows",
//												"id": crewAssignments[i].workTypeID,
//												"status": crewAssignments[i].status
//												}	]
//												}
//										};			
//										var id =crewAssignments[i].id
//								var workTypeLookupRes = workTypeLookuplookup(workTypeLookup,id)
	
						//
						//
						
								var CrewAssignmentIds = { 
										"id": crewAssignments[i].id,
										"displayID": crewAssignments[i].displayID,
										"OUGCrewGUID" :crewAssignments[i].id,
								};
//								if(crewAssignments[i].customFieldValuesExt.CrewID != undefined){
//									CrewAssignmentIds.OUGCrewID = crewAssignments[i].customFieldValuesExt.CrewID;
//								}
//								if(crewAssignments[i].name != undefined){
//								CrewAssignmentIds.OUGCrewName =crewAssignments[i].name;
//								}
								if(crewAssignments[i].eta != undefined){
								//CrewAssignmentIds.OUGETA =crewAssignments[i].eta;
								var name = "etatime"
							var changedDate = DateConversion(name, crewAssignments[i].eta ,crewAssignments[i].id , "ETA");
								}
//								if(crewAssignments[i].createdAt != undefined){
//								var name = "crewAssignments"
//							var changedDate = DateConversion(name, crewAssignments[i].createdAt ,crewAssignments[i].id , "crewAssignmentscreatedAt");
//								}
								
								CrewAssignmentIdArray.push(CrewAssignmentIds);
								//logger.error("CrewAssignmentIdArray" + JSON.stringify(CrewAssignmentIdArray));
								ctx.setVariable("CrewAssignmentIdArray",CrewAssignmentIdArray);
							} else {
								ctx.setVariable("CrewAssignmentIdNullArray",'');
							}
						} else {
							crewworkTypeIdLabel = "";
							ctx.setVariable("CrewAssignmentIdNullArray",'');
						}
					} else {
						crewworkTypeIdLabel = "";
						ctx.setVariable("CrewAssignmentIdNullArray",'');
					}
				}
			});
		} else {
			ctx.setVariable("CrewAssignmentIdNullArray",'');
		}
	}
}

//function workTypeLookuplookup(workTypeLookup, id){
//		var workTypeLookupPayload = workTypeLookup
//		var workTypeLookupCall = {
//				target: session.parameters.lookUpURL,
//				method: 'POST',
//				contentType: 'application/json',
//				data:workTypeLookupPayload   
//		};
//		lookup(workTypeLookupCall, function(error, responseData) {
//			if (error) {
//				logger.error("Error in reading message with  workTypeLookupCall" + JSON.stringify(error));
//			} else {
//				var lookupResponse = responseData;
//				if (lookupResponse.lookupRep.type[0].result == 0) {
//					if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
//							ctx.setVariable("workTypeLookupCall_"+id, lookupResponse.lookupRep.type[0].label);
//					} 
//				}
//			}
//		});
//	}
	
function phase(phases){
	var phasesValue  = [];
	for(let i=0; i < phases.length; i++){
		var phasesVal = phasesMap.get(phases[i]);
		phasesValue.push(phasesVal);
		ctx.setVariable("phasesVal", phasesValue);
	}
}

function CommentAPI(CommentAPIUri){ 
	var getCommentApi = {
			target: CommentAPIUri,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			}
	};
	urlopen.open(getCommentApi, function(error, response){
		if (error) {
			logger.error("FSE45_07: urlopen connect error with Get getCommentApi " + JSON.stringify(error));
			//	session.reject("urlopen connect error with Get getCommentApi " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//logger.info("failure in reading message from getCommentApi" + JSON.stringify(error));
						session.reject(" failure in reading message from getCommentApi" + JSON.stringify(error));
					} else {
						getCommentApiRes = JSON.parse(responseData);
						ctx.setVariable("getCommentApiRes", getCommentApiRes);
						var OUGCommentsVal =[];
						
						async function main() {
							for (let i=0; i<getCommentApiRes.length;i++) {
								dateList = {
									"DateConversion": {
										"action": "1",
										"dateList": [
											{
												"fieldName": "Comment.updatedAt",
												"fromDateTime": getCommentApiRes[i].updatedAt
											}
											]
									}
							};
								var Target = {
											target: session.parameters.ConversionService,
											method: 'POST',
											contentType: 'application/json',
											data: dateList,
											};
											try {
													var responseData = await makeRequest(Target , getCommentApiRes[i]);
													hm.response.statusCode = '200 OK';
													logger.debug("response received :" + JSON.stringify(responseData));
												} catch (error) {
																	hm.current.statusCode = responseStatusCode;
																	logger.error(error);
																//	session.reject(error);
																}
															}
											}
						main();
			function makeRequest(Target , getCommentApiRes) {
			return new Promise(function(resolve, reject) {
				urlopen.open(Target, function(error, response) {
					if (error) {
						reject("urlopen connect error " + JSON.stringify(error));
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									reject("Failure in getting response " + JSON.stringify(error));
								} else {
									resolve(responseData);
										var DateConversionAPIRes = responseData;
											//	ctx.setVariable("DateConversion_CommentAPI_"+[i]+"_",DateConversionAPIRes);
												//Creating the ""OUGComments" array in the final response
												var maxlength =1020;
												      var newcomments = getCommentApiRes.comment.split("\\n").join("<br>");
													   newcomments = newcomments.split("\n").join("<br>");
												     	newcomments = newcomments.split("&lt;br&gt;").join("<br>");
												var getCommentApiReslength = newcomments.length
												if( getCommentApiReslength> maxlength){
													var str = newcomments;
													var intialarr = str.split(' ');
													var arr =[]
													for (var q=0 ; q<intialarr.length ;q++){
   														 if(intialarr[q].length<1021){
        													arr.push(intialarr[q]);
    													}else{
     												 		for(var l=0 ;l<intialarr[q].length ;l+1) {
        														  var valuestrng = intialarr[q].substr(l,1020)
    															      l=l+1020;
        														  arr.push(valuestrng);
														valuestrng=''
      														} 
  													  }
													}
												//ctx.setVariable("arr", arr);
													var parts = new Array();
													var temp='';
											for (var p=0; p< arr.length; p++){
												 if((arr[p].length + (temp.length+1)) < 1022){
    												  if(temp.length == 0){
       													 temp = arr[p];
   													}else{
														 temp = temp+' '+arr[p];         
  														}
   													 if(p == (arr.length-1)){
        												parts.push(temp);
    														}
													}else{
																if(temp.length == 0){
																	temp='';
																	p = p-1;
    															}
										else{
 															parts.push(temp);
																	temp='';
																		p = p-1;         
    															 }
														 }	
															}
													ctx.setVariable("parts", parts);		
													for (var k =0 ; k<parts.length ; k++){
														var OUGComments = { 
													"Author" : getCommentApiRes.updatedByUserName,
														"Comment": parts[k],
														"Timestamp": DateConversionAPIRes.DateConversion.dateList[0].toDateTime
												}
										    	OUGCommentsVal.push(OUGComments);
												ctx.setVariable("OUGComments", OUGCommentsVal);
												}
													
													}else{
													var OUGComments = { 
														"Author" : getCommentApiRes.updatedByUserName,
														"Comment": newcomments,
														"Timestamp": DateConversionAPIRes.DateConversion.dateList[0].toDateTime
												};
												OUGCommentsVal.push(OUGComments);
												ctx.setVariable("OUGComments", OUGCommentsVal);
												}
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									reject("failure in reading response " + JSON.stringify(error));
								} else {
									reject("Error returned " + ": with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}
					}
				});
			});
		}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						//logger.error("failure in reading message from getCommentApi" + JSON.stringify(error));
						session.reject("failure in reading message from getCommentApi");
					} else {
						logger.error("Error code returned from getCommentApi" + responseStatusCode + " " + responseData);
						//session.reject("Error code returned from getCommentApi" + responseStatusCode + " " + responseData);
					}
				});
			}
		}
	});
}


function LeadCallAPI(LeadCallUri){
	var LeadCallApi = {
			target: LeadCallUri,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			}
	};
	urlopen.open(LeadCallApi, function(error, response){
		if (error) {
			logger.error("FSE45_09: urlopen connect error with Get LeadCallApi " + JSON.stringify(error));
			//	session.reject("urlopen connect error with Get LeadCallApi " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						logger.error("failure in reading message from LeadCallApi" + JSON.stringify(error));
						//session.reject(" failure in reading message from LeadCallApi" + JSON.stringify(error));
					} else {
						LeadCallApiRes = JSON.parse(responseData);
						ctx.setVariable("LeadCallApiRes", LeadCallApiRes);

						if(!(LeadCallApiRes.address == null || LeadCallApiRes.address == '' || LeadCallApiRes.address == undefined)){
							ctx.setVariable("LeadCalladdress", LeadCallApiRes.address);
						}
						if(!(LeadCallApiRes.location == null || LeadCallApiRes.location == '' || LeadCallApiRes.location == undefined)){
							if(!(LeadCallApiRes.location.coordinates[1] == null || LeadCallApiRes.location.coordinates[1] == '' || LeadCallApiRes.location.coordinates[1] == undefined)){
								ctx.setVariable("LeadCallLat", LeadCallApiRes.location.coordinates[1]);
							}
							if(!(LeadCallApiRes.location.coordinates[0] == null || LeadCallApiRes.location.coordinates[0] == '' || LeadCallApiRes.location.coordinates[0] == undefined)){
								ctx.setVariable("LeadCallLong", LeadCallApiRes.location.coordinates[0]);
							}
						}
						if(!(LeadCallApiRes.callCodeID == null || LeadCallApiRes.callCodeID == '' || LeadCallApiRes.callCodeID == undefined)){
							// callcodeLookup based on callcode by get call response
							var callcodeLookup = {
								"lookupReq": {
									"type": [
										{
											"name": "callCodeLabel",
											"id": LeadCallApiRes.callCodeID,
										}
										]
								}
							};
							var callCodeIDService = {
									target: session.parameters.lookUpURL,
									method: 'POST',
									contentType: 'application/json',
									data: callcodeLookup  
							};
							lookup(callCodeIDService, function(error, responseData) {
								if (error) {
									logger.error("Error in reading message with  workTypeIdService" + JSON.stringify(error));
								} else {
									var lookupResponse = responseData;
									
									
									if (lookupResponse.lookupRep.type[0].result == 0) {
										if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
											callCodeLabel = lookupResponse.lookupRep.type[0].label;
											ctx.setVariable("LeadCallCode", callCodeLabel); 
										
										} else {
											callCodeLabel = "";
										}
									} else {
										callCodeLabel = "";
										
									}
								}
							});
							// ENDS:  callcodeLookup based on callcode by get call response
							//ctx.setVariable("LeadCallCode", LeadCallApiRes.externalCallCodeID);
						}
						if(!(LeadCallApiRes.notes == null || LeadCallApiRes.notes == '' || LeadCallApiRes.notes == undefined)){
							 var newcomments = LeadCallApiRes.notes.split("\\n").join("<br>");
													   newcomments = newcomments.split("\n").join("<br>");
												     	newcomments = newcomments.split("&lt;br&gt;").join("<br>");
							ctx.setVariable("LeadCallnotes", newcomments);
						}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error("failure in reading message from LeadCallApi" + JSON.stringify(error));
						//session.reject("failure in reading message from LeadCallApi");
					} else {
						logger.error("Error code returned from LeadCallApi" + responseStatusCode + " " + responseData);
						//	session.reject("Error code returned from LeadCallApi" + responseStatusCode + " " + responseData);
					}
				});
			}
		}
	});
}



function sendtoQueue(fseResponse){
	logger.info("Inside Function");
	var targetQueue = session.parameters.Queue;
	var options = {
			target:targetQueue,
			data: fseResponse
	};
	urlopen.open(options, function(error, response){
		var hm = require('header-metadata');
		if(error){
			logger.error('FSE45_11: Mqurlopen.open error');
			session.reject('** Mqurlopen.open error');
			hm.response.statusCode = 500;
		} else {
			var mqrc = response.statusCode;
			if(mqrc == 0){
				response.readAsBuffer(function(readError, responseData){
					if(readError){
						hm.response.statusCode = 500;
						logger.error('FSE45_11: Mqurlopen.open error');
					} else {
						console.log("MQResponseData "+ responseData);
					}
				});
			} else {
				logger.error('**FSE45_11: Mqurlopen.open error [MQRC=' + mqrc + ']');
				session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
				hm.response.statusCode = 500;
			}
		}
	});
}
