var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({'category': 'all'});
session.input.readAsJSON(function(readAsJSONError, incomingPayload){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
	} else {		
								var seqResponse ={
									"messageId" :incomingPayload.messageId,
									"eventType" : "Status",
									"serviceName" : "workOrderFSE",
							 		"sendTimeStamp" : incomingPayload.sendTimeStamp
								}
								if(! (incomingPayload.workFlowType === undefined || incomingPayload.workFlowType === null)) {
							seqResponse.workFlowType = incomingPayload.workFlowType
						}
						if (!(incomingPayload.workFlowRequirementEvent === undefined || incomingPayload.workFlowRequirementEvent === null)) {
							seqResponse.workFlowRequirementEvent = incomingPayload.workFlowRequirementEvent
						}
						if (incomingPayload.eventKey != undefined || incomingPayload.eventKey != null) {
							seqResponse.eventKey = incomingPayload.eventKey
						}
								if(incomingPayload.eventContext != undefined || incomingPayload.eventContext != null){
								seqResponse.eventContext = incomingPayload.eventContext	
								}
								if(incomingPayload.EventTimeStamp != undefined || incomingPayload.EventTimeStamp != null  ){
								seqResponse.EventTimeStamp = incomingPayload.EventTimeStamp	
								}
							SEQResponse(seqResponse);
								
		
	}
});
function SEQResponse(seqResponse){
	var targetQueue = session.parameters.SEQCACELResponseQueue;
	seqResponse.confirmation = "Y"
	var options = {
			target:targetQueue,
			data: seqResponse
	};
	urlopen.open(options, function(error, response){
		var hm = require('header-metadata');
		if(error){
			logger.error('FSE45_14: foa_ohug_cancel Mqurlopen.open error');
			session.reject('** Mqurlopen.open error');
			hm.response.statusCode = 500;
		} else {
			var mqrc = response.statusCode;
			if(mqrc == 0){
				response.readAsBuffer(function(readError, responseData){
					if(readError){
						hm.response.statusCode = 500
						logger.error('FSE45_14:foa_ohug_cancel  Mqurlopen.open error '+readError);
						session.reject( 'Mqurlopen.open error');
					} else {
						console.log("MQResponseData "+ responseData);
						//ils exit success call
						ctx.setVariable("seqResponse", seqResponse);
						ctx.setVariable('Exitdescription',session.parameters.SEQResponseDescription);
						ctx.setVariable('Exitdestination',session.parameters.SEQCACELResponseQueue)
						var ms = require('multistep');
                        ms.callRule('foa_ohug_cancel_ExitIls_Rule', null, null, function(error) {
                            if (error) {
                             //   throw error;
                            }
                        });
					}
				});
			} else {
				logger.error('FSE45_14 foa_ohug_cancel Mqurlopen.open error [MQRC=' + mqrc + ']');
				session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
				hm.response.statusCode = 500
			}
		}
	});
}
