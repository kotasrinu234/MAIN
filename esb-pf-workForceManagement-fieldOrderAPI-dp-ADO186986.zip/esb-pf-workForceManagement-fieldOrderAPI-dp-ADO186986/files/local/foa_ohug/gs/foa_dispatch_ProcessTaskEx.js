var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
var incommingdata;
var encodedPayload;
var decodedPayload;
var workTypesLookupServiceResponse;
var CrewAssignmentapiResponse;
var fseCreateAttachmentResKey;
ctx.setVariable("exitstatus", '500')
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {

		var SkipCall = ctx.getVariable('SkipCall');
		var retry = ctx.getVariable('retry');
		if (retry != 'yes') {
			if (SkipCall != 'yes') {
				incommingdata = JSON.parse(jsonData);
				encodedPayload = incommingdata.payLoad;
				decodedPayload = JSON.parse(new Buffer(encodedPayload, 'base64').toString('utf8'));
				workTypesLookupServiceResponse = ctx.getVariable('workTypesLookupServiceResponse');
				CrewAssignmentapiResponse = ctx.getVariable('CrewAssignmentapi');
				fseCreateAttachmentResKey = ctx.getVariable('fseCreateAttachmentResKey');
				var worktypeIds = [];
				for (var m = 0; m < workTypesLookupServiceResponse.lookupRep.type.length; m++) {
					if (workTypesLookupServiceResponse.lookupRep.type[m].label == 'OH/UG') {
						var message = workTypesLookupServiceResponse.lookupRep.type[m].id
					}
					worktypeIds.push(message)
				}
				var uniqueIds = worktypeIds.filter((element, index) => {
					return worktypeIds.indexOf(element) === index;
				})

				for (var j = 0; j < uniqueIds.length; j++) {
					for (var i = 0; CrewAssignmentapiResponse.data.length > i; i++) {
						if (CrewAssignmentapiResponse.data[i].workTypeID == uniqueIds[j]) {

							//fse call start
							var fseUpdateReqPayload =
							{
								"Task": {
									"@objectType": "Task",
									"@createOrUpdate": true,
									"Key": -1,
									"CallID": CrewAssignmentapiResponse.data[i].displayID,
									"Number": 0,
									//	"ExternalRefID": decodedPayload.data[0].id+":"+CrewAssignmentapiResponse.data[i].id,
									"Attachments": fseCreateAttachmentResKey
								},
								"ReturnSchedulingError": true,
								"ReturnAssignment": false,
								"TaskRequestedProperties": ["CallID", "Number"],
								"AssignmentRequestedProperties": ["Task", "Start", "Finish", "Engineers"],
								"ErrorOnNonExistingDictionaries": true

							}
							if (decodedPayload.messageType === "crewAssignmentEvent") {
								if (decodedPayload.data[0].job != undefined) {
									fseUpdateReqPayload.ExternalRefID = decodedPayload.data[0].job.id + ":" + CrewAssignmentapiResponse.data[i].id
								} else {
									fseUpdateReqPayload.ExternalRefID = ":" + CrewAssignmentapiResponse.data[i].id
								}
							} else {
								fseUpdateReqPayload.ExternalRefID = decodedPayload.data[0].id + ":" + CrewAssignmentapiResponse.data[i].id
							}
							ctx.setVariable("fseUpdateReqPayload", fseUpdateReqPayload);
							var FSEupdateapi = {
								target: session.parameters.FSEUpdateAPI,
								sslClientProfile: 'FSE_Client_Profile',
								method: 'POST',
								contentType: 'application/json',
								headers: {
									'Authorization': 'Basic ' + session.parameters.FSEToken
								},
								data: fseUpdateReqPayload
							};
							urlopen.open(FSEupdateapi, function(error, response) {
								if (error) {
									logger.debug(": urlopen connect error to the FSEupdateapi" + JSON.stringify(error));
									var ErrorTxt = "FSE45_04 : urlopen connect error to the fseUpdateAttachmentRes_ foa_ohug_dispatch_Image " + JSON.stringify(error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ctx.setVariable("retry", 'yes');
									//	ctx.setVariable("exitstatus", response.statusCode)
									//session.reject("urlopen connect error to the FSEupdateapi" + JSON.stringify(error));
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										logger.info("FSEapi response status code 200 ");
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Failure in reading message from FSEupdateapi" + JSON.stringify(error));
												session.reject("Failure in reading message from Get FSEupdateapi" + JSON.stringify(error));
											} else {
												var fseUpdateAttachmentRes = JSON.parse(responseData);
												//	ctx.setVariable("fseUpdateAttachmentRes_"+[i]+"_",fseUpdateAttachmentRes);
												session.output.write(fseUpdateAttachmentRes);
												sm.setVar('var://service/mpgw/skip-backside', true);
											}
										})
									} else {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												logger.error("failure in reading message from fseUpdateAttachmentRes_ post operation for foa_ohug_dispatch_Image is  " + JSON.stringify(error));
												session.reject("failure in reading message from fseUpdateAttachmentRes_ post operation for foa_ohug_dispatch_Image is  " + JSON.stringify(error));
											} else {
												// Check if ExceptionMessage contains "SQL query execution failure"
												var Responsedata = responseData;
												var fseResponse = JSON.parse(Responsedata);
												var message = fseResponse.ExceptionMessage;
												if (!(fseResponse.ExceptionMessage == undefined || fseResponse.ExceptionMessage == '')) {
													if (message.includes("SQL query execution failure")) {
														logger.error(ErrorTxt);
														var ErrorTxt = "SQL query execution failure in foa_ohug_dispatch_Image " + responseStatusCode + " " + JSON.stringify(message);
														ctx.setVariable("ErrorTxt", ErrorTxt);
														ctx.setVariable("retry", 'yes');
													}
												}
												else {
													logger.debug("urlopen connect error to the fseUpdateAttachmentRes_ foa_ohug_dispatch_Image " + responseStatusCode + " " + responseData);
													var ErrorTxt = "FSE45_03 : urlopen connect error to the fseUpdateAttachmentRes_ foa_ohug_dispatch_Image " + responseStatusCode + " " + JSON.stringify(responseData);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ctx.setVariable("retry", 'yes');
													ctx.setVariable("exitstatus", responseStatusCode)
												}
											}
										});
									}
									//									else {
									//										response.readAsBuffer(function(error, responseData) {
									//											if (error) {
									//												//dp:reject stop the transaction and go error rule with error code and description
									//												logger.error("failure in reading message from fseUpdateAttachmentRes_ post operation for foa_ohug_dispatch_Image is  " + JSON.stringify(error));
									//												session.reject("failure in reading message from fseUpdateAttachmentRes_ post operation for foa_ohug_dispatch_Image is  " + JSON.stringify(error));
									//											} else {
									//												logger.error(" response received from fseUpdateAttachmentRes_ post operation for foa_ohug_dispatch_Image is " + responseStatusCode + " " + responseData);
									//												session.reject("response received from fseUpdateAttachmentRes_ post operation for foa_ohug_dispatch_Image is " + responseStatusCode + " " + responseData);
									//											}
									//										});
									//									}


								}
							})
							// fse call end	
						}

					}

				}
			} else {
				sm.setVar('var://service/mpgw/skip-backside', true);
			}
		} else {

			sm.setVar('var://service/mpgw/skip-backside', true);

		}
	}
});
