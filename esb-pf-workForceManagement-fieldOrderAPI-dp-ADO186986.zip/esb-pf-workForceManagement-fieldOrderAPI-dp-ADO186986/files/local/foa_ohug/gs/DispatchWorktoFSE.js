var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var reqDataToFSE;
session.input.readAsJSON(function(readAsJSONError, requestJson) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		logger.error("Error in reading incoming data");
		session.output.write(readAsJSONError);
	} else {
		session.output.write(requestJson)
		var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
		var retry = session.name('foa_dispatchWork').getVariable('retry');
		ctx.setVariable("ExitStatusCode", '500');
		if (retry != 'yes') {
			var aorIdslabelVal = JoinValues('aorIdslabel', session.name('foa_dispatchWork').getVariable('aorIdslabel'));
			var OUGAOR;
			var phasesVal = JoinValues('phasesVal', session.name('foa_dispatchWork').getVariable('phasesVal'));
			var Phases;
			// aorsIDs  & OUGAOR representation 
			function JoinValues(inputName, displayInput) {
				if (Array.isArray(displayInput)) {
					var displayInputVal;
					var displayInputArr = new Array();
					for (var i = 0; i < displayInput.length; i++) {
						displayInputVal = displayInput[i];
						displayInputArr.push(displayInputVal);
					}
					if (inputName == 'aorIdslabel') {
						OUGAOR = displayInputArr.join('-');
					}
					if (inputName == 'phasesVal') {
						Phases = displayInputArr.join(',');
					}
				} else {
					if (inputName == 'aorIdslabel') {
						OUGAOR = displayInput;
					}
					if (inputName == 'phasesVal') {
						Phases = displayInput;
					}
				}
			}

			var OUGComments = session.name('foa_dispatchWork').getVariable('OUGComments');
			if (OUGComments != undefined) {
				var arr = OUGComments;
				if (arr.length > 0) {
					const sortByDate = arr => {
						const sorter = (a, b) => {
							return new Date(a.Timestamp).getTime() - new Date(b.Timestamp).getTime();
						}
						arr.sort(sorter);
					};

					sortByDate(arr);
				}
			}
			//var OUGAssociatedCrews = session.name('foa_dispatchWork').getVariable('OUGAssociatedCrews');
			var jobStart = session.name('foa_dispatchWork').getVariable('jobStart');
			var publishedEtr = session.name('foa_dispatchWork').getVariable('publishedEtr');
			var createdAt = session.name('foa_dispatchWork').getVariable('createdAt');
			var finishtime = session.name('foa_dispatchWork').getVariable('finishtime');
			var displayString = session.name('foa_dispatchWork').getVariable('displayString');
			var Data_WorkTypeID = session.name('foa_dispatchWork').getVariable('Data_WorkTypeID');
			var workType = session.name('foa_dispatchWork').getVariable('workType');
			var etrExpirationStatus = session.name('foa_dispatchWork').getVariable('etrExpirationStatus');
			var etrStatus = session.name('foa_dispatchWork').getVariable('etrStatus');
			var aoridLabel = session.name('foa_dispatchWork').getVariable('aoridLabel');
			var jobTypeIDLabel = session.name('foa_dispatchWork').getVariable('jobTypeIDLabel');
			var outageSubtypeIDLabel = session.name('foa_dispatchWork').getVariable('outageSubtypeIDLabel');
			var LeadCalladdress = session.name('foa_dispatchWork').getVariable('LeadCalladdress');
			var LeadCallLat = session.name('foa_dispatchWork').getVariable('LeadCallLat');
			var LeadCallLong = session.name('foa_dispatchWork').getVariable('LeadCallLong');
			var LeadCallCode = session.name('foa_dispatchWork').getVariable('LeadCallCode');
			var LeadCallnotes = session.name('foa_dispatchWork').getVariable('LeadCallnotes');
			var Latitude = session.name('foa_dispatchWork').getVariable('Latitude');
			var Longitude = session.name('foa_dispatchWork').getVariable('Longitude');
			var OUGLatitude = session.name('foa_dispatchWork').getVariable('OUGLatitude');
			var OUGLongitude = session.name('foa_dispatchWork').getVariable('OUGLongitude');
			var OUGAddressLat = session.name('foa_dispatchWork').getVariable('OUGAddressLat');
			var OUGAddressLong = session.name('foa_dispatchWork').getVariable('OUGAddressLong');
			//var linkedDisplayID = session.name('foa_dispatchWork').getVariable('linkedDisplayID');
			var JobTypeStatus = session.name('foa_dispatchWork').getVariable('JobTypeStatus');
			var outageStepsRespArr = session.name('foa_dispatchWork').getVariable('outageStepsRespArr');
			var cause = session.name('foa_dispatchWork').getVariable('cause');
			var Remarks = session.name('foa_dispatchWork').getVariable('Remarks');
			var CompletionRemarks = session.name('foa_dispatchWork').getVariable('CompletionRemarks');
			var OUGExtent = session.name('foa_dispatchWork').getVariable('OUGExtent');
			var Exchange_Meter_In = session.name('foa_dispatchWork').getVariable('Exchange_Meter_In');
			var Exchange_Meter_Out = session.name('foa_dispatchWork').getVariable('Exchange_Meter_Out');
			var Exchange_Meter_Out_Reading = session.name('foa_dispatchWork').getVariable('Exchange_Meter_Out_Reading');
			var URDOPERATINGMAP = session.name('foa_dispatchWork').getVariable('URDOPERATINGMAP');
			var OHOPERATINGMAP = session.name('foa_dispatchWork').getVariable('OHOPERATINGMAP');
			var Resource_Needed = session.name('foa_dispatchWork').getVariable('Resource_Needed');
			var OUGObservations = session.name('foa_dispatchWork').getVariable('observationslabel');
			var substation = session.name('foa_dispatchWork').getVariable('substation');
			var nominalFeeder = session.name('foa_dispatchWork').getVariable('nominalFeeder');
			var nominalSubstation = session.name('foa_dispatchWork').getVariable('nominalSubstation');
			var publishedEtrChangeCount = session.name('foa_dispatchWork').getVariable('publishedEtrChangeCount');
			var validMeterOutageNotifReceivedPercentage = session.name('foa_dispatchWork').getVariable('validMeterOutageNotifReceivedPercentage')
			var CrewAssignmentIdArray = session.name('foa_dispatchWork').getVariable('CrewAssignmentIdArray');
			var OUGLeadLocation = session.name('foa_dispatchWork').getVariable('OUGLeadLocation');
			var OUGLeadLocationLat = session.name('foa_dispatchWork').getVariable('OUGLeadLocationLat');
			var OUGLeadLocationLong = session.name('foa_dispatchWork').getVariable('OUGLeadLocationLong');
			var etaTime = session.name('foa_dispatchWork').getVariable('etaTime');
			var OUGCrossStreets = session.name('foa_dispatchWork').getVariable('OUGCrossStreets');
			var OUGPremiseID = ctx.getVariable("PremisephasesData");
			var ExternalRefID;

			var newarray = [];
			var payload = {}
			if (outageStepsRespArr != undefined) {
				for (var m = 0; outageStepsRespArr.length > m; m++) {
					var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
					var offdatetime = ctx.getVariable("DateTime_offTime_" + outageStepsRespArr[m].StepID);
					var ondatetime = ctx.getVariable("DateTime_onTime_" + outageStepsRespArr[m].StepID);

					var operationTime = ctx.getVariable("DateTime_operationTime_" + outageStepsRespArr[m].StepID);
					var OffNetworkModelOperationtime = ctx.getVariable("DateTime_OffNetworkModelOperation_" + outageStepsRespArr[m].StepID);
					var SplitNetworkModelOperationtime = ctx.getVariable("DateTime_SplitNetworkModelOperation_" + outageStepsRespArr[m].StepID);
					//	var OUGPremiseID = ctx.getVariable("PremisephasesData");
					var OnNetworkModelOperationMessage = undefined;
					var SplitNetworkModelOperationMessage = undefined;
					var OffNetworkModelOperationMessage = undefined;
					var splitNetworkModelOperationMaxSize = session.parameters.Truncatevalue; // This should be configurable.


					if (!(OffNetworkModelOperationtime == undefined && outageStepsRespArr[m].OffNetworkModelOperationpart1 == undefined && OffNetworkModelOperationtime + ';' + outageStepsRespArr[m].OffNetworkModelOperation)) {

						OffNetworkModelOperationMessage = outageStepsRespArr[m].OffNetworkModelOperationpart1 + ';' + OffNetworkModelOperationtime + ';' + outageStepsRespArr[m].OffNetworkModelOperation

					}
					if (!(outageStepsRespArr[m].OnNetworkModelOperationpart1 == undefined && operationTime == undefined && outageStepsRespArr[m].OnNetworkModelOperation == undefined)) {

						OnNetworkModelOperationMessage = outageStepsRespArr[m].OnNetworkModelOperationpart1 + ';' + operationTime + ';' + outageStepsRespArr[m].OnNetworkModelOperation;
					}


					if (!(SplitNetworkModelOperationtime == undefined && outageStepsRespArr[m].SplitNetworkModelOperationpart1 == undefined && outageStepsRespArr[m].SplitNetworkModelOperation == undefined)) {
						SplitNetworkModelOperationMessage = outageStepsRespArr[m].SplitNetworkModelOperationpart1 + ';' + SplitNetworkModelOperationtime + ';' + outageStepsRespArr[m].SplitNetworkModelOperation;
					}
					if (SplitNetworkModelOperationMessage && SplitNetworkModelOperationMessage.length > splitNetworkModelOperationMaxSize) {
						SplitNetworkModelOperationMessage = SplitNetworkModelOperationMessage.substring(0, splitNetworkModelOperationMaxSize);
					}
					payload = {
						"StepID": outageStepsRespArr[m].StepID,
						"StartTime": offdatetime,
						"EndTime": ondatetime,

						//"objectType" : "Assignment",
						"OutageDuration": outageStepsRespArr[m].OutageDuration,
						"AffectedCustomers": outageStepsRespArr[m].AffectedCustomers,
						"EnergizationStatus": outageStepsRespArr[m].EnergizationStatus,

						"OffNetworkModelOperation": OffNetworkModelOperationMessage,
						"OnNetworkModelOperation": OnNetworkModelOperationMessage,
						"SplitNetworkModelOperation": SplitNetworkModelOperationMessage
					}
					newarray.push(payload)
					payload = {}

				}
			}
			if ((!(requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined)) && (requestJson.reqType == "Job_update")) {
				if (!(CrewAssignmentIdArray == "" || CrewAssignmentIdArray == null || CrewAssignmentIdArray == undefined)) {
					var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
					ctx.setVariable("CrewAssignmentIdArraylength", CrewAssignmentIdArray.length);
					ctx.setVariable("CrewAssignmentIdArray", CrewAssignmentIdArray);

					for (let i = 0; i < CrewAssignmentIdArray.length; i++) {
						ExternalRefID = requestJson.data[0].id + ":" + CrewAssignmentIdArray[i].id;
						reqDataToFSE =
						{
							"Task": {
								"@objectType": "Task",
								"@createOrUpdate": true,
								"Key": -1,
								"CallID": CrewAssignmentIdArray[i].displayID,
								"Number": 0,
								"ExternalRefID": ExternalRefID,
								"Region": requestJson.data[0].regionName,
								"District": aoridLabel,
								"OUGLatitude": OUGLatitude,
								"OUGLongitude": OUGLongitude,
								"Latitude": Latitude,
								"Longitude": Longitude,
								"TaskType": workType,
								//                                                                                                                "Status" : ,
								"OUGJobID": requestJson.data[0].displayID,
								"OUGJobIDGUID": requestJson.data[0].id,
								"OUGAddress": requestJson.data[0].address,
								"OUGCrossStreets": OUGCrossStreets,
								"OUGAddressLat": OUGAddressLat,
								"OUGAddressLong": OUGAddressLong,
								"OUGETRExpireStatus": etrExpirationStatus,
								"OUGAOR": OUGAOR,
								//"OUGAssociatedCrews": OUGAssociatedCrews,
								"OUGBasekV": requestJson.data[0].voltage,
								"OUGCauseCode": cause,
								"OUGCloseCancelRemarks": Remarks,
								"OUGComments": arr,
								"OUGCompletionRemarks": CompletionRemarks,
								"OUGCurrentAffected": requestJson.data[0].currentAffected,
								"OUGDestination": requestJson.data[0].destination,
								"OUGDeviceName": requestJson.data[0].networkModelName,
								"OUGEnergizationStatus": requestJson.data[0].energizationStatus,
								"OUGETA": etaTime,
								"OUGETRStatus": etrStatus,
								"OUGExchangeMeterIn": Exchange_Meter_In,
								"OUGExchangeMeterOut": Exchange_Meter_Out,
								"OUGExchangeMeterOutReading": Exchange_Meter_Out_Reading,
								"OUGExtent": OUGExtent,
								"OUGFeederName": requestJson.data[0].feederName,
								"OUGOperatingMapUGURL": URDOPERATINGMAP,
								"OUGOperatingMapOHURL": OHOPERATINGMAP,
								"OUGJobLeadCallAddr": LeadCalladdress,
								"OUGJobLeadCallAddrLat": LeadCallLat,
								"OUGJobLeadCallAddrLong": LeadCallLong,
								"OUGJobLeadCallCode": LeadCallCode,
								"OUGJobLeadCallNotes": LeadCallnotes,
								"OUGObservations": OUGObservations,
								"OUGJobStatus": JobTypeStatus,
								"OUGJobType": jobTypeIDLabel,
								"OUGLeadLocation": OUGLeadLocation,
								"OUGLeadLocationLat": OUGLeadLocationLat,
								"OUGLeadLocationLong": OUGLeadLocationLong,
								//"OUGLinkedJobs": linkedDisplayID,
								"OUGNominalFeeder": nominalFeeder,
								"OUGNominalSubstation": nominalSubstation,
								"OUGOutageStartTime": jobStart,
								"OUGOutageSubtype": outageSubtypeIDLabel,
								"OUGPcntAMIRestoratnNotifRec": validMeterOutageNotifReceivedPercentage,
								"OUGPhases": Phases,
								"OUGPublishedETR": publishedEtr,
								"OUGPublishedETRChangeCount": publishedEtrChangeCount,
								"OUGResourceNeeded": Resource_Needed,
								"OUGSubstationName": substation,
								"OUGOutageSteps": newarray,
								"OUGPremiseID": OUGPremiseID,
								"OUGTotalAffected": requestJson.data[0].totalAffected
							},

							"ReturnSchedulingError": true,
							"ReturnAssignment": false,
							"TaskRequestedProperties": ["CallID", "Number"],
							"AssignmentRequestedProperties": ["Task", "Start", "Finish", "Engineers"],
							"ErrorOnNonExistingDictionaries": true
						}
						var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
						//var status = ctx.getVariable("workTypeLookupCall_"+CrewAssignmentIdArray[i].OUGCrewGUID);
						//           var eta = ctx.getVariable("DateTime_ETA_"+CrewAssignmentIdArray[i].OUGCrewGUID);
						//var crewAssignmentscreatedAt = ctx.getVariable("DateTime_crewAssignmentscreatedAt_"+CrewAssignmentIdArray[i].OUGCrewGUID);
						//if(crewAssignmentscreatedAt != undefined){
						//           reqDataToFSE.Assignment.Start = crewAssignmentscreatedAt;
						//var finish = new Date(crewAssignmentscreatedAt);
						//           var finishtime = 1;
						//finish.setTime(finish.getTime() + finishtime * 60 * 60 * 1000);

						//           var         ESTDateVar = finish.getTime();
						//           var         localOffset = finish.getTimezoneOffset() * 60000;
						//                                                                                                 
						//                                                                                                 var datestrng = finish.toString();
						//                                                                                                 var edt = "EDT";
						//                                                                                                 var offset;
						//                                                                                   if(datestrng.includes(edt)){
						//                                                                                                 offset = -4;
						//                                                                                   }else{
						//                                                                                                 offset = -5;
						//                                                                                   }
						//                                                                                   var         utc = ESTDateVar + (3600000*offset);
						//                                                                                   var         ESTDate = new Date(utc).toISOString();
						//                                                                                   ESTDate = ESTDate.replace('Z','');
						//                                                                    reqDataToFSE.Assignment.Finish = ESTDate;
						//                                                                    }

						//                                                                    if(status != undefined){
						//                                                                    //reqDataToFSE.Task.status = status;
						//                                                                    }
						//                                                                    if(CrewAssignmentIdArray[i].OUGCrewGUID != undefined){
						//                                                                    reqDataToFSE.Task.OUGCrewGUID = CrewAssignmentIdArray[i].OUGCrewGUID       
						//                                                                    }
						//                                                                    if(CrewAssignmentIdArray[i].OUGCrewID != undefined){
						//                                                                    reqDataToFSE.Task.OUGCrewID = CrewAssignmentIdArray[i].OUGCrewID  
						//                                                                    }
						//                                                                    if(CrewAssignmentIdArray[i].OUGCrewName != undefined){
						//                                                                    reqDataToFSE.Task.OUGCrewName = CrewAssignmentIdArray[i].OUGCrewName         
						//                                                                    }
						//                                                                    if(eta != undefined){
						//                                                                    reqDataToFSE.Task.OUGETA = eta              
						//                                                                    }

						if (!(requestJson.data[0].operationEventIDs == undefined)) {
							if (!(requestJson.data[0].operationEventIDs[0] == undefined || requestJson.data[0].operationEventIDs[0] == null || requestJson.data[0].operationEventIDs[0] == '')) {
								reqDataToFSE.Task.Priority = 2
							}
						}
						FSETrigger(reqDataToFSE, ExternalRefID, requestJson);
						ctx.setVariable("FseInputPayload", reqDataToFSE);
						session.output.write(reqDataToFSE)
					}
				}
			} else {
				ExternalRefID = requestJson.data[0].job.id + ":" + requestJson.data[0].id;
				reqDataToFSE =
				{
					"Task": {
						"@objectType": "Task",
						"@createOrUpdate": true,
						"Key": -1,
						"CallID": requestJson.data[0].displayID,
						"Number": 0,
						"ExternalRefID": ExternalRefID,
						"Region": requestJson.data[0].job.regionName,
						"District": aoridLabel,
						"OUGLatitude": OUGLatitude,
						"OUGLongitude": OUGLongitude,
						"Latitude": Latitude,
						"Longitude": Longitude,
						"TaskType": workType,
						"Status": Data_WorkTypeID,
						"OUGJobID": requestJson.data[0].job.displayID,
						"OUGJobIDGUID": requestJson.data[0].job.id,
						"OUGAddress": requestJson.data[0].job.address,
						"OUGCrossStreets": OUGCrossStreets,
						"OUGAddressLat": OUGAddressLat,
						"OUGAddressLong": OUGAddressLong,
						"OUGETRExpireStatus": etrExpirationStatus,
						"OUGAOR": OUGAOR,
						//"OUGAssociatedCrews": OUGAssociatedCrews,
						"OUGBasekV": requestJson.data[0].job.voltage,
						"OUGCauseCode": cause,
						"OUGCloseCancelRemarks": Remarks,
						"OUGComments": arr,
						"OUGCompletionRemarks": CompletionRemarks,
						"OUGCrewGUID": requestJson.data[0].crew.id,
						"OUGCrewID": requestJson.data[0].crew.customFieldValuesExt.CrewID,
						"OUGCrewName": requestJson.data[0].crew.name,
						"OUGCurrentAffected": requestJson.data[0].job.currentAffected,
						"OUGDestination": requestJson.data[0].destination,
						"OUGDeviceName": requestJson.data[0].networkModelName,
						"OUGEnergizationStatus": requestJson.data[0].job.energizationStatus,
						"OUGETA": etaTime,
						"OUGETRStatus": etrStatus,
						"OUGExchangeMeterIn": Exchange_Meter_In,
						"OUGExchangeMeterOut": Exchange_Meter_Out,
						"OUGExchangeMeterOutReading": Exchange_Meter_Out_Reading,
						"OUGExtent": OUGExtent,
						"OUGFeederName": requestJson.data[0].job.feederName,
						"OUGOperatingMapUGURL": URDOPERATINGMAP,
						"OUGOperatingMapOHURL": OHOPERATINGMAP,
						"OUGJobLeadCallAddr": LeadCalladdress,
						"OUGJobLeadCallAddrLat": LeadCallLat,
						"OUGJobLeadCallAddrLong": LeadCallLong,
						"OUGJobLeadCallCode": LeadCallCode,
						"OUGJobLeadCallNotes": LeadCallnotes,
						"OUGObservations": OUGObservations,
						"OUGJobStatus": JobTypeStatus,
						"OUGJobType": jobTypeIDLabel,
						"OUGLeadLocation": OUGLeadLocation,
						"OUGLeadLocationLat": OUGLeadLocationLat,
						"OUGLeadLocationLong": OUGLeadLocationLong,
						//"OUGLinkedJobs": linkedDisplayID,
						"OUGNominalFeeder": nominalFeeder,
						"OUGNominalSubstation": nominalSubstation,
						"OUGOutageStartTime": jobStart,
						"OUGOutageSubtype": outageSubtypeIDLabel,
						"OUGPcntAMIRestoratnNotifRec": validMeterOutageNotifReceivedPercentage,
						"OUGPhases": Phases,
						"OUGPublishedETR": publishedEtr,
						"OUGPublishedETRChangeCount": publishedEtrChangeCount,
						"OUGResourceNeeded": Resource_Needed,
						"OUGSubstationName": substation,
						"OUGOutageSteps": newarray,
						"OUGPremiseID": OUGPremiseID,
						"OUGTotalAffected": requestJson.data[0].job.totalAffected
					},
					"Assignment": {
						"@objectType": "Assignment",
						"Start": createdAt,
						"Finish": finishtime,
						"Engineers": [
							{
								"ID": requestJson.data[0].crew.customFieldValuesExt.employeeid,
								"District": {
									"Name": displayString
								}
							}
						]
					},
					"ReturnSchedulingError": true,
					"ReturnAssignment": false,
					"TaskRequestedProperties": ["CallID", "Number"],
					"AssignmentRequestedProperties": ["Task", "Start", "Finish", "Engineers"],
					"ErrorOnNonExistingDictionaries": true
				}
				if (!(requestJson.data[0].job.operationEventIDs == undefined)) {
					if (!(requestJson.data[0].job.operationEventIDs[0] == undefined || requestJson.data[0].job.operationEventIDs[0] == null || requestJson.data[0].job.operationEventIDs[0] == '')) {
						reqDataToFSE.Task.Priority = 2
					}
				}
				FSETrigger(reqDataToFSE, ExternalRefID, requestJson);
				ctx.setVariable("FseInputPayload", reqDataToFSE);
				session.output.write(reqDataToFSE)
			}
		}
	}
});

function FSETrigger(reqDataToFSE, ExternalRefID, requestJson) {
	var currentTimeStamp = new Date().toISOString();
	var FSEAPIRes;
	var fseResponse = {};
	var incomingPayload = ctx.getVariable("IncomingPayload");
	if (incomingPayload.messageId != undefined || incomingPayload.messageId != null) {
		fseResponse.messageId = incomingPayload.messageId
	}
	if (incomingPayload.crewAssignmentID != undefined || incomingPayload.crewAssignmentID != null) {
		fseResponse.crewAssignmentID = incomingPayload.crewAssignmentID
	}
	if (incomingPayload.crewAssignmentDisplayID != undefined || incomingPayload.crewAssignmentDisplayID != null) {
		fseResponse.crewAssignmentDisplayID = incomingPayload.crewAssignmentDisplayID
	}
	if (incomingPayload.jobID != undefined || incomingPayload.jobID != null) {
		fseResponse.jobID = incomingPayload.jobID
	}
	if (incomingPayload.jobDisplayID != undefined || incomingPayload.jobDisplayID != null) {
		fseResponse.jobDisplayID = incomingPayload.jobDisplayID
	}
	if (incomingPayload.crewDisplayID != undefined || incomingPayload.crewDisplayID != null) {
		fseResponse.crewDisplayID = incomingPayload.crewDisplayID
	}
	if (incomingPayload.messageType != undefined || incomingPayload.messageType != null) {
		fseResponse.messageType = incomingPayload.messageType
	}
	if (incomingPayload.assignmentStatus != undefined || incomingPayload.assignmentStatus != null) {
		fseResponse.assignmentStatus = incomingPayload.assignmentStatus
	}
	if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
		fseResponse.crewAssigmentTrigger = incomingPayload.crewAssigmentTrigger
	}
	if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
		fseResponse.EventTimeStamp = incomingPayload.eventTime
	}


	var errorDesc;
	let getXmlValue = function(str, key) {
		return str.substring(
			str.lastIndexOf('<' + key + '>') + ('<' + key + '>').length,
			str.lastIndexOf('</' + key + '>')
		);
	}
	ctx.setVariable('Exitdescription', session.parameters.FSEUpdateDescription)
	ctx.setVariable('Exitdestination', session.parameters.FSEApi)
	// FSE request
	var FSEAPI = {
		target: session.parameters.FSEApi,
		sslClientProfile: 'FSE_Client_Profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'Authorization': 'Basic ' + session.parameters.FSEToken
		},
		data: reqDataToFSE
	};

	urlopen.open(FSEAPI, function(error, response) {
		if (error) {
			logger.debug(" urlopen connect error with FSEAPI " + JSON.stringify(error));
			var ErrorTxt = "FSE45_13: foa_ohug_dispatch urlopen connect error with FSEAPI " + JSON.stringify(error);
			ctx.setVariable("ErrorTxt", ErrorTxt);
			ctx.setVariable("retry", 'yes');
			session.output.write(reqDataToFSE)
			ctx.setVariable("exitDestination", session.parameters.FSEApi);
			//session.reject("urlopen connect error with Get FSEAPI " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			ctx.setVariable("ExitStatusCode", responseStatusCode);
			//checking errorcode from file start
			var errorStatus;
			if (responseStatusCode == 200) { } else {
				var ErrorCodes = session.name('foa_dispatchWork').getVariable('ErrodeCodes');
				for (var i = 0; i < ErrorCodes.ErrorCode.length; i++) {
					if (responseStatusCode == ErrorCodes.ErrorCode[i].value) {
						errorStatus = 'yes';
					}
				}
			}
			//checking errorcode from file end
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//logger.error("failure in reading message from FSEAPI" + JSON.stringify(error));
						session.reject(" failure in reading message from FSEAPI" + JSON.stringify(error));
					} else {
						FSEAPIRes = JSON.parse(responseData);
						ctx.setVariable("FSEAPIRes", FSEAPIRes);
						var flagvalue;
						var flagnumber;
						if (!(FSEAPIRes.ExceptionMessage == undefined || FSEAPIRes.ExceptionMessage == '')) {
							errorDesc = getXmlValue(FSEAPIRes.ExceptionMessage, 'ErrorDescription');
							ctx.setVariable("errorDesc", errorDesc);
							var ServerErrorCode = session.parameters.responseErrorcodes;
							var ErrorCodeList = ServerErrorCode.split(',');
							var meesage = FSEAPIRes.ExceptionMessage;
							for (var i = 0; i < ErrorCodeList.length; i++) {
								var numberval = Number(ErrorCodeList[i])
								if (meesage.includes(String(numberval))) {
									flagvalue = 'yes'
									flagnumber = numberval;
								}
							}
							if (errorDesc.includes("SQL query execution failure")) {
								var ErrorTxt = "SQL query execution failure in foa_ohug_dispatch: " + JSON.stringify(FSEAPIRes.ExceptionMessage);
								logger.error(ErrorTxt)
								ctx.setVariable("ErrorTxt", ErrorTxt);
								ctx.setVariable("retry", 'yes');
							}
						}

						if (flagvalue) {
							logger.debug("FSEAPIRes.ExceptionMessage : " + FSEAPIRes.ExceptionMessage);
							var ErrorTxt = "FSEAPIRes.ExceptionMessage errorCode : " + JSON.stringify(FSEAPIRes.ExceptionMessage);
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ctx.setVariable("retry", 'yes');
							session.output.write(reqDataToFSE)
							ctx.setVariable("exitDestination", session.parameters.FSEApi);
						}
						else {
							//ilsexit for fse success call

							ctx.setVariable('ReqData', reqDataToFSE)
							var ms = require('multistep');
							ms.callRule('foa_ohug_dispatch_ExitIls_Rule', null, null, function(error) {
								if (error) {
									//   throw error;
								}
							});
							//ilsexit for fse success call end
							var incomingPayload = ctx.getVariable("IncomingPayload");
							var seqResponse = {
								"messageId": incomingPayload.messageId,
								"eventType": "Status",
								"serviceName": "workOrderFSE",
								"sendTimeStamp": incomingPayload.sendTimeStamp

							}
							if (!(incomingPayload.workFlowType === undefined || incomingPayload.workFlowType === null)) {
								seqResponse.workFlowType = incomingPayload.workFlowType
							}
							if (!(incomingPayload.workFlowRequirementEvent === undefined || incomingPayload.workFlowRequirementEvent === null)) {
								seqResponse.workFlowRequirementEvent = incomingPayload.workFlowRequirementEvent
							}
							if (incomingPayload.eventKey != undefined || incomingPayload.eventKey != null) {
								seqResponse.eventKey = incomingPayload.eventKey
							}
							if (incomingPayload.crewAssignmentID != undefined || incomingPayload.crewAssignmentID != null) {
								seqResponse.crewAssignmentID = incomingPayload.crewAssignmentID
							}
							if (incomingPayload.crewAssignmentDisplayID != undefined || incomingPayload.crewAssignmentDisplayID != null) {
								seqResponse.crewAssignmentDisplayID = incomingPayload.crewAssignmentDisplayID
							}
							if (incomingPayload.jobID != undefined || incomingPayload.jobID != null) {
								seqResponse.jobID = incomingPayload.jobID
							}
							if (incomingPayload.jobDisplayID != undefined || incomingPayload.jobDisplayID != null) {
								seqResponse.jobDisplayID = incomingPayload.jobDisplayID
							}
							if (incomingPayload.crewDisplayID != undefined || incomingPayload.crewDisplayID != null) {
								seqResponse.crewDisplayID = incomingPayload.crewDisplayID
							}
							if (incomingPayload.messageType != undefined || incomingPayload.messageType != null) {
								seqResponse.messageType = incomingPayload.messageType
							}
							if (incomingPayload.assignmentStatus != undefined || incomingPayload.assignmentStatus != null) {
								seqResponse.assignmentStatus = incomingPayload.assignmentStatus
							}
							if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
								seqResponse.crewAssigmentTrigger = incomingPayload.crewAssigmentTrigger
							}
							if (incomingPayload.eventContext != undefined || incomingPayload.eventContext != null) {
								seqResponse.eventContext = incomingPayload.eventContext
							}

							if (incomingPayload.EventTimeStamp != undefined || incomingPayload.EventTimeStamp != null) {
								seqResponse.EventTimeStamp = incomingPayload.EventTimeStamp
							}

							if (FSEAPIRes.ReturnCode == 'Success') {
								fseResponse.ExternalRefID = ExternalRefID;
								fseResponse.createdAt = currentTimeStamp;
								fseResponse.status = "Success";
								fseResponse.jobComment = "Success in FSE";

								if ((requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined) || (requestJson.reqType != "Job_update")) {
									sendtoQueue(fseResponse);
									if (requestJson.crewAssigmentTrigger == "Y") { UdpdateImage(requestJson); }
									SEQResponse(seqResponse);

								} else {
									var callID = reqDataToFSE.Task.CallID;
									ctx.setVariable("Job_updatecallID_" + callID, callID);
								}
								ctx.setVariable("Outputpayload", fseResponse);
								//session.output.write(fseResponse);
							} else if (FSEAPIRes.ReturnCode == 'Failure') {
								if (FSEAPIRes.ExceptionMessage != undefined) {
									errorDesc = getXmlValue(FSEAPIRes.ExceptionMessage, 'ErrorDescription');
								}
								fseResponse.ExternalRefID = ExternalRefID;
								fseResponse.createdAt = currentTimeStamp;
								fseResponse.status = "Failure";
								fseResponse.jobComment = errorDesc;

								if ((requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined) || (requestJson.reqType != "Job_update")) {
									sendtoQueue(fseResponse);
									if (requestJson.crewAssigmentTrigger == "Y") { UdpdateImage(requestJson); }
									SEQResponse(seqResponse);
								} else {
									var callID = reqDataToFSE.Task.CallID;
									ctx.setVariable("Job_updatecallID_" + callID, callID);
								}
								ctx.setVariable("Outputpayload", fseResponse);
								//session.output.write(fseResponse);
							} else if (FSEAPIRes.ReturnCode == 'ScheduleFailed') {
								if (FSEAPIRes.ExceptionMessage != undefined) {
									errorDesc = getXmlValue(FSEAPIRes.ExceptionMessage, 'ErrorDescription');
								}
								fseResponse.ExternalRefID = ExternalRefID;
								fseResponse.createdAt = currentTimeStamp;
								fseResponse.status = "Failure";
								fseResponse.jobComment = errorDesc;

								if ((requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined) || (requestJson.reqType != "Job_update")) {
									sendtoQueue(fseResponse);
									if (requestJson.crewAssigmentTrigger == "Y") { UdpdateImage(requestJson); }
									SEQResponse(seqResponse);
								} else {
									var callID = reqDataToFSE.Task.CallID;
									ctx.setVariable("Job_updatecallID_" + callID, callID);
								}
								//	session.output.write(fseResponse);
							}

						}
					}// clsing tag
				});
			}
			else if (errorStatus == 'yes') {

				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error("failure in reading message from FSEAPI" + JSON.stringify(error));
						//session.reject("failure in reading message from FSEAPI");
					} else {
						var flagvalue;
						var flagnumber;
						var FSEAPIRes = JSON.parse(responseData);
						if (!(FSEAPIRes.ExceptionMessage == undefined || FSEAPIRes.ExceptionMessage == '')) {
							errorDesc = getXmlValue(FSEAPIRes.ExceptionMessage, 'ErrorDescription');
							ctx.setVariable("errorDesc", errorDesc);
							var ServerErrorCode = session.parameters.responseErrorcodes;
							var ErrorCodeList = ServerErrorCode.split(',');
							var meesage = FSEAPIRes.ExceptionMessage;
							for (var i = 0; i < ErrorCodeList.length; i++) {
								var numberval = Number(ErrorCodeList[i])
								if (meesage.includes(String(numberval))) {
									flagvalue = 'yes'
									flagnumber = numberval;
								}
							}
							if (errorDesc.includes("SQL query execution failure")) {
								var ErrorTxt = "SQL query execution failure in foa_ohug_dispatch: " + JSON.stringify(FSEAPIRes.ExceptionMessage);
								logger.error(ErrorTxt)
								ctx.setVariable("ErrorTxt", ErrorTxt);
								ctx.setVariable("retry", 'yes');
							}
						}

						if (flagvalue) {
							logger.debug("FSEAPIRes.ExceptionMessage : " + FSEAPIRes.ExceptionMessage);
							var ErrorTxt = "FSEAPIRes.ExceptionMessage errorCode : " + JSON.stringify(FSEAPIRes.ExceptionMessage);
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ctx.setVariable("retry", 'yes');
							session.output.write(reqDataToFSE)
							ctx.setVariable("exitDestination", session.parameters.FSEApi);
						}
						else {
							//logger.error("FSE45_23: foa_ohug_dispatch Error code returned from FSEAPI" + responseStatusCode + " " + responseData);
							//session.reject("Error code returned from FSEAPI" + responseStatusCode + " " + responseData);
							FSEAPIRes = JSON.parse(responseData);
							if (FSEAPIRes.ExceptionMessage != undefined) {
								errorDesc = getXmlValue(FSEAPIRes.ExceptionMessage, 'ErrorDescription');
							}
							//ilsexit for fse success call
							if (errorDesc != undefined) {
								ctx.setVariable('Exitdescription', session.parameters.FSEUpdateDescription)
							}
							ctx.setVariable('Exitdestination', session.parameters.FSEApi)
							ctx.setVariable('ReqData', reqDataToFSE)
							var ms = require('multistep');
							ms.callRule('foa_ohug_dispatch_ExitIls_Rule', null, null, function(error) {
								if (error) {
									//       throw error;
								}
							});
							//ilsexit for fse success call end
							fseResponse.ExternalRefID = ExternalRefID;
							fseResponse.createdAt = currentTimeStamp;
							fseResponse.status = "Failure";
							fseResponse.jobComment = errorDesc;

							var incomingPayload = ctx.getVariable("IncomingPayload");
							var seqResponse = {
								"messageId": incomingPayload.messageId,
								"eventType": "Status",
								"serviceName": "workOrderFSE",
								"sendTimeStamp": incomingPayload.sendTimeStamp
							}
							if (!(incomingPayload.workFlowType === undefined || incomingPayload.workFlowType === null)) {
								seqResponse.workFlowType = incomingPayload.workFlowType
							}
							if (!(incomingPayload.workFlowRequirementEvent === undefined || incomingPayload.workFlowRequirementEvent === null)) {
								seqResponse.workFlowRequirementEvent = incomingPayload.workFlowRequirementEvent
							}
							if (incomingPayload.eventKey != undefined || incomingPayload.eventKey != null) {
								seqResponse.eventKey = incomingPayload.eventKey
							}
							if (incomingPayload.crewAssignmentID != undefined || incomingPayload.crewAssignmentID != null) {
								seqResponse.crewAssignmentID = incomingPayload.crewAssignmentID
							}
							if (incomingPayload.crewAssignmentDisplayID != undefined || incomingPayload.crewAssignmentDisplayID != null) {
								seqResponse.crewAssignmentDisplayID = incomingPayload.crewAssignmentDisplayID
							}
							if (incomingPayload.jobID != undefined || incomingPayload.jobID != null) {
								seqResponse.jobID = incomingPayload.jobID
							}
							if (incomingPayload.jobDisplayID != undefined || incomingPayload.jobDisplayID != null) {
								seqResponse.jobDisplayID = incomingPayload.jobDisplayID
							}
							if (incomingPayload.crewDisplayID != undefined || incomingPayload.crewDisplayID != null) {
								seqResponse.crewDisplayID = incomingPayload.crewDisplayID
							}
							if (incomingPayload.messageType != undefined || incomingPayload.messageType != null) {
								seqResponse.messageType = incomingPayload.messageType
							}
							if (incomingPayload.assignmentStatus != undefined || incomingPayload.assignmentStatus != null) {
								seqResponse.assignmentStatus = incomingPayload.assignmentStatus
							}
							if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
								seqResponse.crewAssigmentTrigger = incomingPayload.crewAssigmentTrigger
							}
							if (incomingPayload.eventContext != undefined || incomingPayload.eventContext != null) {
								seqResponse.eventContext = incomingPayload.eventContext
							}
							if (incomingPayload.EventTimeStamp != undefined || incomingPayload.EventTimeStamp != null) {
								seqResponse.EventTimeStamp = incomingPayload.EventTimeStamp
							}

							if ((requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined) || (requestJson.reqType != "Job_update")) {
								sendtoQueue(fseResponse);
								if (requestJson.crewAssigmentTrigger == "Y") { UdpdateImage(requestJson); }
								SEQResponse(seqResponse);
							}

							//session.output.write(fseResponse);
							ctx.setVariable("Outputpayload", fseResponse);
						}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.debug("failure in reading message from FSEAPI" + JSON.stringify(error));
						//session.reject("failure in reading message from FSEAPI");
					} else {
						logger.debug("  urlopen connect error with FSEAPI " + responseData);
						var ErrorTxt = "FSE45_13: foa_ohug_dispatch urlopen connect error with FSEAPI for responseStatusCode " + responseStatusCode + " is " + JSON.stringify(responseData);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						ctx.setVariable("retry", 'yes');
						ctx.setVariable("Outputpayload", reqDataToFSE);
						session.output.write(reqDataToFSE)
						ctx.setVariable("exitDestination", session.parameters.FSEApi);
					}
				})
			}
		}
		sm.setVar('var://service/mpgw/skip-backside', true);
	})
	//session.output.write(reqDataToFSE)
	// END FSE request
}
//session.output.write(reqDataToFSE)
function sendtoQueue(fseResponse) {

	var targetQueue = session.parameters.Queue;
	var options = {
		target: targetQueue,
		data: fseResponse
	};

	try {
		urlopen.open(options, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.debug('foa_ohug_dispatch Mqurlopen.open error');
				var ErrorTxt = "FSE45_14: foa_ohug_dispatch Mqurlopen.open error";
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("retry", 'yes');
				session.output.write(fseResponse)
				ctx.setVariable("ExitStatusCode", '500');
				ctx.setVariable("exitDestination", session.parameters.Queue);
				//session.reject('** Mqurlopen.open error');
				hm.response.statusCode = 500;
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							logger.error('FSE45_14: foa_ohug_dispatch Mqurlopen.open error ' + readError);
							session.reject('Mqurlopen.open error');
						} else {
							//								//ilsexit for seq conf success call
							//						ctx.setVariable('Exitdescription',session.parameters.fseResponseSucessDescription);
							//						ctx.setVariable('Exitdestination', session.parameters.Queue)
							//						ctx.setVariable('ReqData',fseResponse  )
							//						var ms = require('multistep');
							//                        ms.callRule('foa_ohug_dispatch_ExitIls_Rule', null, null, function(error) {
							//                            if (error) {
							//                                throw error;
							//                            }
							//                        });
							//						//ilsexit for seq conf success call end
							console.log("MQResponseData " + responseData);
							ctx.setVariable("FSEResponse", 'yes');
							ctx.setVariable("ExitResponse", fseResponse);
							session.output.write(fseResponse)
						}
					});
				} else {
					ctx.setVariable("exitDestination", session.parameters.Queue);
					var ErrorTxt = 'FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']';
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("retry", 'yes');
					session.output.write(fseResponse)
					ctx.setVariable("ExitStatusCode", '500');
					hm.response.statusCode = 500
				}
			}
		});
	} catch (err) {
		ctx.setVariable("exitDestination", session.parameters.Queue);
		var ErrorTxt = 'FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + err + ']';
		ctx.setVariable("ErrorTxt", ErrorTxt);
		ctx.setVariable("retry", 'yes');
		session.output.write(fseResponse)
		ctx.setVariable("ExitStatusCode", '500');
	}
}

;
function SEQResponse(seqResponse) {

	var targetQueue = session.parameters.SEQResponseQueue;
	seqResponse.confirmation = "Y"
	var options = {
		target: targetQueue,
		data: seqResponse
	};
	//session.output.write(seqResponse)
	try {
		urlopen.open(options, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.debug('foa_ohug_dispatch Mqurlopen.open error');
				var ErrorTxt = "FSE45_22 foa_ohug_dispatch Mqurlopen.open error";
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ExitStatusCode", '500');
				session.output.write(seqResponse)
				ctx.setVariable("exitDestination", session.parameters.SEQResponseQueue);
				//session.reject('** Mqurlopen.open error');
				hm.response.statusCode = 500;
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							logger.error('FSE45_22:foa_ohug_dispatch Mqurlopen.open error ' + readError);
							session.reject('Mqurlopen.open error');
						} else {
							console.log("MQResponseData " + responseData);
							//ilsexit for seq conf success call
							ctx.setVariable('Exitdescription', session.parameters.SEQResponseDescription);
							ctx.setVariable('Exitdestination', session.parameters.SEQResponseQueue)
							ctx.setVariable('ReqData', seqResponse)
							var ms = require('multistep');
							ms.callRule('foa_ohug_dispatch_ExitIls_Rule', null, null, function(error) {
								if (error) {
									throw error;
								}
							});
							//ilsexit for seq conf success call end
						}
					});
				} else {
					var ErrorTxt = 'FSE45_22 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']';
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("retry", 'yes');
					session.output.write(seqResponse)
					ctx.setVariable("ExitStatusCode", '500');
					ctx.setVariable("exitDestination", session.parameters.SEQResponseQueue);
					hm.response.statusCode = 500
				}
			}
		});
	} catch (err) {
		var ErrorTxt = 'FSE45_22 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + err + ']';
		ctx.setVariable("ErrorTxt", ErrorTxt);
		ctx.setVariable("retry", 'yes');
		session.output.write(seqResponse)
		ctx.setVariable("ExitStatusCode", '500');
		ctx.setVariable("exitDestination", session.parameters.SEQResponseQueue);
	}
}
function UdpdateImage(requestJson) {
	var targetQueue = session.parameters.UpdateImage;
	var options = {
		target: targetQueue,
		data: requestJson
	};
	//session.output.write(requestJson)
	try {
		urlopen.open(options, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.error('FSE45_14 foa_ohug_dispatch Mqurlopen.open error');
				var ErrorTxt = "FSE45_14:foa_ohug_dispatch Mqurlopen.open error";
				ctx.setVariable("ExitStatusCode", '500');
				ctx.setVariable("ErrorTxt", ErrorTxt);
				//ctx.setVariable("retry", 'yes');
				session.reject('** Mqurlopen.open error');
				hm.response.statusCode = 500;
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							logger.error('FSE45_14: foa_ohug_dispatch Mqurlopen.open error ' + readError);
							session.reject('Mqurlopen.open error');
						} else {
							session.output.write(requestJson)
							console.log("MQResponseData " + responseData);
						}
					});
				} else {
					logger.error(' foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']');
					var ErrorTxt = 'FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']';
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("ExitStatusCode", '500');
					session.reject(' foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']');
					//ctx.setVariable("retry", 'yes');
					hm.response.statusCode = 500
				}
			}
		});
	} catch (err) {
		logger.error(' foa_ohug_dispatch Mqurlopen.open error [MQRC=' + err + ']');
		var ErrorTxt = 'FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + err + ']';
		ctx.setVariable("ErrorTxt", ErrorTxt);
		ctx.setVariable("ExitStatusCode", '500');
		session.reject(' foa_ohug_dispatch Mqurlopen.open error [MQRC=' + err + ']');
		//	ctx.setVariable("retry", 'yes');
	}
}
