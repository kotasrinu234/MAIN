var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
var incommingdata;
var attachment;
var encodedPayload;
var decodedPayload;
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		incommingdata = JSON.parse(jsonData);
		encodedPayload = incommingdata.payLoad;
		ctx.setVariable("fseUpdateReqPayload", incommingdata);
		ctx.setVariable("encodedPayload", encodedPayload);
		decodedPayload = JSON.parse(Buffer.from(encodedPayload, 'base64').toString('utf8'));
		// decodedPayload =  JSON.parse(Buffer.from(encodedPayload, 'base64').toString('ascii'));
		ctx.setVariable("decodedPayload", decodedPayload);
		attachment = incommingdata.Attachments;
		ctx.setVariable("attachment", attachment);
		ctx.setVariable("attachment.length", attachment.length);
		var arrayvalue = []
		var FileType = session.parameters.FileTypeValue
		for (let i = 0; i < attachment.length; i++) {
			var message =
			{
				"Action": "Create",
				"Object": {
					"@objectType": "Attachment",
					"@createOrUpdate": "true",
					"FileIndex": parseInt(attachment[i].FileIndex),
					"FileSize": parseInt(attachment[i].FileSize),
					"FileType": { "Key": parseInt(FileType) },
					"TimeAttached": attachment[i].TimeAttached,
					//"MobileKey": atatachment[i].ExternalKey_SO,
					"UploadedBy": attachment[i].UploadedBy,
					"FileName": attachment[i].FileName,
					"ExternalKey_SO": attachment[i].ExternalKey_SO,
					"ExternalURL_SO": attachment[i].ExternalURL_SO
				}
			}
			arrayvalue.push(message)
		}
		var fseCreateReqPayload = {
			"Operations": arrayvalue,
			"OneTransaction": true,
			"ContinueOnError": true
		}
		var FSECreateapi = {
			target: session.parameters.FSECreateAPI,
			sslClientProfile: 'FSE_Client_Profile',
			method: 'POST',
			contentType: 'application/json',
			headers: {
				'Authorization': 'Basic ' + session.parameters.FSEToken
			},
			data: fseCreateReqPayload
		};
		urlopen.open(FSECreateapi, function(error, response) {
			if (error) {
				logger.error("urlopen connect error to the FSECreateapi foa_ohug_dispatch_Image " + JSON.stringify(error));
				var ErrorTxt = "FSE45_02 : urlopen connect error to the FSECreateapi foa_ohug_dispatch_Image " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("retry", 'yes');
				//session.reject("urlopen connect error to the FSECreateapi" + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					logger.info("FSEapi response status code 200 ");
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("Failure in reading message from FSECreateapi" + JSON.stringify(error));
							session.reject("Failure in reading message from FSECreateapi" + JSON.stringify(error));
						} else {
							var fseCreateAttachmentRes = JSON.parse(responseData);
							ctx.setVariable("fseCreateAttachmentRes", fseCreateAttachmentRes);

							var keyvalue = []
							for (var k = 0; k < fseCreateAttachmentRes.Operations.length; k++) {
								var message = {
									"Key": fseCreateAttachmentRes.Operations[k].Object.ObjectReference.Key
								}
								keyvalue.push(message)

							}
							ctx.setVariable("fseCreateAttachmentResKey", keyvalue);
							//GET /api/ServiceType/{sid}/Job/{id}/CrewAssignment with includeFields=workTypeID%2Cid%2CdisplayID&excludeResolved=true&join=false - use <data.id> as {id}
							var GetCrewAssignmentId;
							if (decodedPayload.reqType == 'Create' || decodedPayload.reqType == undefined) {
								GetCrewAssignmentId = decodedPayload.data[0].job.id;
							} else {
								GetCrewAssignmentId = decodedPayload.data[0].id;
							}
							var CrewAssignmentomsExternalURL = session.parameters.omsExternalURL + '/api/ServiceType/Electric/Job/' + GetCrewAssignmentId + '/CrewAssignment?includeFields=workTypeID,id,displayID&excludeResolved=true&join=false';
							var TokenValue = session.parameters.apiToken;
							var CrewAssignmentapi = {
								target: CrewAssignmentomsExternalURL,
								sslClientProfile: 'OMS_Client_Profile',
								method: 'GET',
								contentType: 'application/json',
								headers: {
									'osiApiToken': TokenValue
								},
							};
							urlopen.open(CrewAssignmentapi, function(error, response) {
								if (error) {
									logger.error(" urlopen connect error with GET CrewAssignmentapi with id as " + GetCrewAssignmentId + " " + JSON.stringify(error));
									session.reject("urlopen connect error with GET CrewAssignmentapi with id as " + GetCrewAssignmentId + " " + JSON.stringify(error));
								} else {
									// read response data
									// get the response status code
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												logger.error(" error message while reading response from CrewAssignmentapi" + JSON.stringify(error));
												session.reject(" error message while reading response from CrewAssignmentapi" + JSON.stringify(error));
											} else {
												//200 sucess here for get call
												ctx.setVariable("CrewAssignmentapi", JSON.parse(responseData));
												//lookup call start
												var CrewAssignmentapi = JSON.parse(responseData)
												if (CrewAssignmentapi.data.length > 0) {
													var arrayvalue = []

													var CrewAssignmentapilength = CrewAssignmentapi.data.length
													for (var i = 0; i < CrewAssignmentapilength; i++) {
														var message = {
															"name": 'workTypes',
															"id": CrewAssignmentapi.data[i].workTypeID,
															"status": "none"
														}
														arrayvalue.push(message)
													}
													var lookupMessage = { "lookupReq": { "type": arrayvalue } }
													var workTypesLookupServiceResponse = {
														target: session.parameters.lookUpURL,
														method: 'POST',
														contentType: 'application/json',
														data: lookupMessage
													};
													//start
													urlopen.open(workTypesLookupServiceResponse, function(error, response) {
														if (error) {
															logger.error(" urlopen connect error with Outage LookupServiceResponse" + JSON.stringify(error));
														} else {
															var responsseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																response.readAsJSON(function(error, responseData) {
																	if (error) {
																		// error while reading response or transferring data to Buffer
																		logger.error("failure in putting message to  workTypesLookupServiceResponse" + JSON.stringify(error));
																	} else {
																		hm.response.statusCode = responseStatusCode;
																		logger.debug("response received from workTypesLookupServiceResponse " + JSON.stringify(responseData));
																		var responseDatapayload = responseData
																		ctx.setVariable('workTypesLookupServiceResponse', responseDatapayload);
																	}
																})
															} else {
																logger.error("urlopen connect error with lookupservice api " + JSON.stringify(error));
																session.reject("urlopen connect error with lookupservice api " + JSON.stringify(error));
															}
														}
													});	//lookup call ends
												} else {
													ctx.setVariable('SkipCall', 'yes');
												}
											}
										})

									} else {

										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												logger.error("failure in reading message from GetCrewAssignment is  " + JSON.stringify(error));
												session.reject("failure in reading message from GetCrewAssignment is  " + JSON.stringify(error));
											} else {
												logger.error(" response received from GetCrewAssignment is " + responseStatusCode + " " + responseData);
												session.reject("response received from GetCrewAssignment is " + responseStatusCode + " " + responseData);
											}
										});

									}
								}
							});
							//GET /api/ServiceType/{sid}/Job/{id}/CrewAssignment  ends				
						}
					});
				} else if (responseStatusCode == 504) {
					logger.error("urlopen connect error to the FSECreateapi foa_ohug_dispatch_Image  response code is 504");
					var ErrorTxt = "FSE45_02 : urlopen connect error to the FSECreateapi foa_ohug_dispatch_Image response code is 504";
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("retry", 'yes');
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error("failure in reading message from FSECreateapi foa_ohug_dispatch_Image  " + JSON.stringify(error));
							session.reject("failure in reading message from FSECreateapi foa_ohug_dispatch_Image  " + JSON.stringify(error));
						}
						else {
							// Check if ExceptionMessage contains "SQL query execution failure"
							var Responsedata = responseData;
							var fseResponse = JSON.parse(Responsedata);
							var message = fseResponse.ExceptionMessage;
							if (!(fseResponse.ExceptionMessage == undefined || fseResponse.ExceptionMessage == '')) {
								if (message.includes("SQL query execution failure")) {
									logger.error(ErrorTxt);
									var ErrorTxt = "SQL query execution failure in foa_ohug_dispatch_Image " + responseStatusCode + " " + JSON.stringify(message);
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ctx.setVariable("retry", 'yes');
								}
							}
							else {
								logger.error(" response received from FSECreateapi foa_ohug_dispatch_Image " + responseStatusCode + " " + responseData);
								session.reject("response received from FSECreateapi foa_ohug_dispatch_Image " + responseStatusCode + " " + responseData);
							}
						}
					});
				}
			}
		});//clsing for urlopen create
	}
});
