var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var hm = require('header-metadata');
var urlopen = require('urlopen');
var logger = console.options({'category': 'all'});
var fromDateTime;
var toDateTime;
var conversionVal;
var dateList;

session.input.readAsJSON(function(readAsJSONError, requestJson){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		var eta,jobStart,publishedEtr,outageStepsoffTime,outageStepsonTime,createdAt;
		var dateListArr = [];
		var data = requestJson.data[0];
		if ((!(requestJson.reqType == "" || requestJson.reqType == null || requestJson.reqType == undefined)) && (requestJson.reqType == "Job_update")){

			if(!(data.start == null || data.start == '' || data.start == undefined)){
				var dateTimeAddition = {};
				dateTimeAddition.fieldName = "job.start";
				dateTimeAddition.fromDateTime = data.start;
				dateListArr.push(dateTimeAddition);
			} else if(!(data.createdAt == null || data.createdAt == '' || data.createdAt == undefined)){
				var dateTimeAddition = {};
				dateTimeAddition.fieldName = "job.start";
				dateTimeAddition.fromDateTime = data.createdAt;
				dateListArr.push(dateTimeAddition);
			} else {
				jobStart = '';
			}
	
			if(!(data.publishedEtr == null || data.publishedEtr == '' || data.publishedEtr == undefined)){
				if(!(data.publishedEtr.value == null || data.publishedEtr.value == '' || data.publishedEtr.value == undefined)){
					var dateTimeAddition = {};
					dateTimeAddition.fieldName = "job.publishedEtr.value";
					dateTimeAddition.fromDateTime = data.publishedEtr.value;
					dateListArr.push(dateTimeAddition);
				} else {
					publishedEtr = '';
				}
			} else {
				publishedEtr = '';
			}
			
			if(!(data.outageSteps == null || data.outageSteps == '' || data.outageSteps == undefined)) {
				for (let i=0;i<data.outageSteps.length; i++){
					if(!(data.outageSteps[i].offTime == null || data.outageSteps[i].offTime == '' || data.outageSteps[i].offTime == undefined)){
						var dateTimeAddition = {};
						dateTimeAddition.fieldName = "job.outageSteps.offTime";
						dateTimeAddition.fromDateTime = data.outageSteps[i].offTime;
						dateListArr.push(dateTimeAddition);
					} else {
						outageStepsoffTime = ''; 
					}

					if(!(data.outageSteps[i].onTime == null || data.outageSteps[i].onTime == '' || data.outageSteps[i].onTime == undefined)){
						var dateTimeAddition = {};
						dateTimeAddition.fieldName = "job.outageSteps.onTime";
						dateTimeAddition.fromDateTime = data.outageSteps[i].onTime;
						dateListArr.push(dateTimeAddition);
					} else {
						outageStepsonTime = ''; 
					}
				}
			}

			if(!(data.createdAt == null || data.createdAt == '' || data.createdAt == undefined)){
				var dateTimeAddition = {};
				dateTimeAddition.fieldName = "createdAt";
				dateTimeAddition.fromDateTime = data.createdAt;
				dateListArr.push(dateTimeAddition);
			} else {
				createdAt = '';
			}
		} else {
			if(!(data.eta == null || data.eta == '' || data.eta == undefined)){
				var dateTimeAddition = {};
				dateTimeAddition.fieldName = "eta";
				dateTimeAddition.fromDateTime = data.eta;
				dateListArr.push(dateTimeAddition);
			} else {
				eta = '';
			}

			if(!(data.job.start == null || data.job.start == '' || data.job.start == undefined)){
				var dateTimeAddition = {};
				dateTimeAddition.fieldName = "job.start";
				dateTimeAddition.fromDateTime = data.job.start;
				dateListArr.push(dateTimeAddition);
			} else if(!(data.job.createdAt == null || data.job.createdAt == '' || data.job.createdAt == undefined)){
				var dateTimeAddition = {};
				dateTimeAddition.fieldName = "job.start";
				dateTimeAddition.fromDateTime = data.job.createdAt;
				dateListArr.push(dateTimeAddition);
			} else {
				jobStart = '';
			}
			
			if(!(data.job.publishedEtr == null || data.job.publishedEtr == '' || data.job.publishedEtr == undefined)){
				if(!(data.job.publishedEtr.value == null || data.job.publishedEtr.value == '' || data.job.publishedEtr.value == undefined)){
					var dateTimeAddition = {};
					dateTimeAddition.fieldName = "job.publishedEtr.value";
					dateTimeAddition.fromDateTime = data.job.publishedEtr.value;
					dateListArr.push(dateTimeAddition);
				} else {
					publishedEtr = '';
				}
			} else {
				publishedEtr = '';
			}

			if(!(data.job.outageSteps == null || data.job.outageSteps == '' || data.job.outageSteps == undefined)){
				for (let i=0;i<data.job.outageSteps.length; i++){
					if(!(data.job.outageSteps[i].offTime == null || data.job.outageSteps[i].offTime == '' || data.job.outageSteps[i].offTime == undefined)){
						var dateTimeAddition = {};
						dateTimeAddition.fieldName = "job.outageSteps.offTime";
						dateTimeAddition.fromDateTime = data.job.outageSteps[i].offTime;
						dateListArr.push(dateTimeAddition);
					} else {
						outageStepsoffTime = ''; 
					}

					if(!(data.job.outageSteps[i].onTime == null || data.job.outageSteps[i].onTime == '' || data.job.outageSteps[i].onTime == undefined)){
						var dateTimeAddition = {};
						dateTimeAddition.fieldName = "job.outageSteps.onTime";
						dateTimeAddition.fromDateTime = data.job.outageSteps[i].onTime;
						dateListArr.push(dateTimeAddition);
					} else {
						outageStepsonTime = ''; 
					}
				}
			}

			if(!(data.createdAt == null || data.createdAt == '' || data.createdAt == undefined)){
				var dateTimeAddition = {};
				dateTimeAddition.fieldName = "createdAt";
				dateTimeAddition.fromDateTime = data.createdAt;
				dateListArr.push(dateTimeAddition);
			} else {
				createdAt = '';
			}
		}

		dateList = {
				"DateConversion": {
					"action": "1",
					"dateList": dateListArr
				}
		}
		ctx.setVariable("dateList",dateList);

		var DateConversionAPI = {
				target : session.parameters.ConversionService,
				data : dateList,
				contentType: 'application/json',
				method: 'POST'
		};
		urlopen.open(DateConversionAPI, function(error, response) {
			if (error) {
				logger.error("FSE45_05 : urlopen connect error to the DateConversionAPI" + JSON.stringify(error));
				session.reject("urlopen connect error to the DateConversionAPI" + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					logger.info("FSEapi response status code 200 ");
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("Failure in reading message from DateConversionAPI"+JSON.stringify(error));
							session.reject("Failure in reading message from Get DateConversionAPI" + JSON.stringify(error));
						} else {
							var DateConversionAPIRes = JSON.parse(responseData);
							ctx.setVariable("DateConversionAPIResponse",DateConversionAPIRes);
							session.output.write(DateConversionAPIRes);
						}
					})
				}
			}
		})
	}
});
