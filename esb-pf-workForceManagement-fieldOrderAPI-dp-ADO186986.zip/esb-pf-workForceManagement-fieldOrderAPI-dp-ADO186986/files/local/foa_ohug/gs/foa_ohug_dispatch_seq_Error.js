var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({'category': 'all'});
session.input.readAsJSON(function(readAsJSONError, incomingPayload){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
	} else {		
								var seqResponse ={
									"messageId" :incomingPayload.messageId,
									"eventType" : "Status",
									"serviceName" : "workOrderFSE",
							 		"sendTimeStamp" : incomingPayload.sendTimeStamp
								}
								
								if(! (incomingPayload.workFlowType === undefined || incomingPayload.workFlowType === null)) {
							seqResponse.workFlowType = incomingPayload.workFlowType
						}
						if (!(incomingPayload.workFlowRequirementEvent === undefined || incomingPayload.workFlowRequirementEvent === null)) {
							seqResponse.workFlowRequirementEvent = incomingPayload.workFlowRequirementEvent
						}
						if (incomingPayload.eventKey != undefined || incomingPayload.eventKey != null) {
							seqResponse.eventKey = incomingPayload.eventKey
						}
								
								if(incomingPayload.eventContext != undefined || incomingPayload.eventContext != null){
								seqResponse.eventContext = incomingPayload.eventContext	
								}
								if(incomingPayload.EventTimeStamp != undefined || incomingPayload.EventTimeStamp != null  ){
								seqResponse.EventTimeStamp = incomingPayload.EventTimeStamp	
								}
								if (incomingPayload.crewAssignmentID != undefined || incomingPayload.crewAssignmentID != null) {
							seqResponse.crewAssignmentID = incomingPayload.crewAssignmentID
						}
						if (incomingPayload.crewAssignmentDisplayID != undefined || incomingPayload.crewAssignmentDisplayID != null) {
							seqResponse.crewAssignmentDisplayID = incomingPayload.crewAssignmentDisplayID
						}
						if (incomingPayload.jobID != undefined || incomingPayload.jobID != null) {
							seqResponse.jobID = incomingPayload.jobID
						}
						if (incomingPayload.jobDisplayID != undefined || incomingPayload.jobDisplayID != null) {
							seqResponse.jobDisplayID = incomingPayload.jobDisplayID
						}
						if (incomingPayload.crewDisplayID != undefined || incomingPayload.crewDisplayID != null) {
							seqResponse.crewDisplayID = incomingPayload.crewDisplayID
						}
						if (incomingPayload.messageType != undefined || incomingPayload.messageType != null) {
							seqResponse.messageType = incomingPayload.messageType
						}
						if (incomingPayload.assignmentStatus != undefined || incomingPayload.assignmentStatus != null) {
							seqResponse.assignmentStatus = incomingPayload.assignmentStatus
						}
						if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
							seqResponse.crewAssigmentTrigger = incomingPayload.crewAssigmentTrigger
						}
							SEQResponse(seqResponse);
								
		
	}
});
function SEQResponse(seqResponse){
	var targetQueue = session.parameters.SEQResponseQueue;
	seqResponse.confirmation = "Y"
	var options = {
			target:targetQueue,
			data: seqResponse
	};
	urlopen.open(options, function(error, response){
		var hm = require('header-metadata');
		if(error){
			logger.error('FSE45_14: foa_ohug_dispatch Mqurlopen.open error');
			session.reject('** Mqurlopen.open error');
			hm.response.statusCode = 500;
		} else {
			var mqrc = response.statusCode;
			if(mqrc == 0){
				response.readAsBuffer(function(readError, responseData){
					if(readError){
						hm.response.statusCode = 500
						logger.error('FSE45_14: foa_ohug_dispatch Mqurlopen.open error '+readError);
						session.reject( 'Mqurlopen.open error');
					} else {
						console.log("MQResponseData "+ responseData);
						//ilsexit for seq conf success call
						ctx.setVariable('Exitdescription',session.parameters.SEQResponseDescription);
						ctx.setVariable('Exitdestination',session.parameters.SEQResponseQueue)
						ctx.setVariable('ReqData',seqResponse)
						var ms = require('multistep');
                        ms.callRule('foa_ohug_dispatch_ExitIls_Rule', null, null, function(error) {
                            if (error) {
                                throw error;
                            }
                        });
						//ilsexit for seq conf success call end
					}
				});
			} else {
				logger.error('FSE45_14 foa_ohug_dispatch Mqurlopen.open error [MQRC=' + mqrc + ']');
				session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
				hm.response.statusCode = 500
			}
		}
	});
}
