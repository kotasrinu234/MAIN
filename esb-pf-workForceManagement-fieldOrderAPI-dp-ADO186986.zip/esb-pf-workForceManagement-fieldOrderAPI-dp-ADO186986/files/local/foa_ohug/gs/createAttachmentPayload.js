var ctx = session.name("omsfoa_UI") || session.createContext("omsfoa_UI");
var ctxretry = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
var jobId;
var encodedJson;
var createdAt;
var ExternalRefID;
var IIBPayload;
var incommingdata;
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		incommingdata = JSON.parse(jsonData);
		session.output.write(incommingdata);
		//	Do a GET /api/ServiceType/{sid}/Job/{id} with includeFields=displayID  - Use <data.id> as {id}
		var GetcallId;
		if (incommingdata.reqType == 'Create' || incommingdata.reqType == undefined) {
			GetcallId = incommingdata.data[0].job.id;
		} else {
			GetcallId = incommingdata.data[0].id;
		}
		var JobapiomsExternalURL = session.parameters.omsExternalURL + '/api/ServiceType/Electric/Job/' + GetcallId + '?includeFields=attachmentCount,displayID';
		var TokenValue = session.parameters.apiToken;
		var Jobapi = {
			target: JobapiomsExternalURL,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},
		};
		urlopen.open(Jobapi, function(error, response) {
			if (error) {
				logger.error(" urlopen connect error with GET Jobapi with id as " + GetcallId + " " + JSON.stringify(error));
				session.reject("urlopen connect error with GET Callapi with id as " + GetcallId + " " + JSON.stringify(error));
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error(" error message while reading response from Jobapi" + JSON.stringify(error));
							session.reject(" error message while reading response from Callapi" + JSON.stringify(error));
						} else {
							//200 sucess here for get call
							var ctx = session.name("trap") || session.createContext("trap");
							ctx.setVariable("jobUpdateCheckResponse", JSON.parse(responseData));
							var attachmentCount = JSON.parse(responseData).attachmentCount;
							var displayid = JSON.parse(responseData).displayID
							ctx.setVariable("attachmentCount", JSON.parse(attachmentCount));
							if ((attachmentCount > 0) && (displayid.length > 0) && (displayid != undefined)) {
								//GET /api/ServiceType/{sid}/Job/{id}/CrewAssignment with includeFields=workTypeID%2Cid%2CdisplayID&excludeResolved=false&join=false - use <data.id> as {id}									
								incommingdata = JSON.parse(jsonData);
								//	Do a GET /api/ServiceType/{sid}/Job/{id} with includeFields=displayID  - Use <data.id> as {id}
								var GetCrewAssignmentId;
								if (incommingdata.reqType == 'Create' || incommingdata.reqType == undefined) {
									GetCrewAssignmentId = incommingdata.data[0].job.id;
								} else {
									GetCrewAssignmentId = incommingdata.data[0].id;
								}

								var CrewAssignmentomsExternalURL = session.parameters.omsExternalURL + '/api/ServiceType/Electric/Job/' + GetCrewAssignmentId + '/CrewAssignment?includeFields=workTypeID,id,displayID&excludeResolved=false&join=false';
								var TokenValue = session.parameters.apiToken;
								var CrewAssignmentapi = {
									target: CrewAssignmentomsExternalURL,
									sslClientProfile: 'OMS_Client_Profile',
									method: 'GET',
									contentType: 'application/json',
									headers: {
										'osiApiToken': TokenValue
									},

								};
								urlopen.open(CrewAssignmentapi, function(error, response) {
									if (error) {
										logger.error(" urlopen connect error with GET CrewAssignmentapi with id as " + GetCrewAssignmentId + " " + JSON.stringify(error));
										session.reject("urlopen connect error with GET CrewAssignmentapi with id as " + GetCrewAssignmentId + " " + JSON.stringify(error));
									} else {
										// read response data
										// get the response status code
										var responseStatusCode = response.statusCode;
										if (responseStatusCode == 200) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													//dp:reject stop the transaction and go error rule with error code and description
													logger.error(" error message while reading response from CrewAssignmentapi" + JSON.stringify(error));
													session.reject(" error message while reading response from CrewAssignmentapi" + JSON.stringify(error));
												} else {
													//200 sucess here for get call
													var ctx = session.name("trap") || session.createContext("trap");
													ctx.setVariable("CrewAssignmentapi", JSON.parse(responseData));
													var CrewAssignmentapi = JSON.parse(responseData)
													var arrayvalue = []
													var CrewAssignmentapilength = CrewAssignmentapi.data.length
													for (var i = 0; i < CrewAssignmentapilength; i++) {
														var message = {
															"name": 'workTypes',
															"id": CrewAssignmentapi.data[i].workTypeID,
															"status": "none"
														}
														arrayvalue.push(message)
													}
													var lookupMessage = { "lookupReq": { "type": arrayvalue } }
													var workTypesLookupServiceResponse = {
														target: session.parameters.lookUpURL,
														method: 'POST',
														contentType: 'application/json',
														data: lookupMessage
													};
													//start
													urlopen.open(workTypesLookupServiceResponse, function(error, response) {
														if (error) {
															logger.error(" urlopen connect error with Outage LookupServiceResponse" + JSON.stringify(error));
															session.reject(" urlopen connect error with Outage LookupServiceResponse" + JSON.stringify(error))
														} else {
															var responsseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																response.readAsJSON(function(error, responseData) {
																	if (error) {
																		// error while reading response or transferring data to Buffer
																		logger.error("failure in putting message to  workTypesLookupServiceResponse" + JSON.stringify(error));
																	} else {
																		hm.response.statusCode = responseStatusCode;
																		logger.debug("response received from workTypesLookupServiceResponse " + JSON.stringify(responseData));
																		var ctx = session.name("trap") || session.createContext("trap");
																		var responseDatapayload = responseData
																		ctx.setVariable('workTypesLookupServiceResponse', responseDatapayload);
																		var typeslength = responseDatapayload.lookupRep.type.length;
																		var ohugFlag;
																		for (var j = 0; j < typeslength; j++) {
																			if (responseData.lookupRep.type[j].label == 'OH/UG') {
																				ohugFlag = 'yes'
																				var ctx = session.name("trap") || session.createContext("trap");
																				ctx.setVariable('ohugFlag', ohugFlag);
																			}
																		}

																		if (ohugFlag == 'yes') {
																			incommingdata = JSON.parse(jsonData);
																			if (incommingdata.reqType == 'Create' || incommingdata.reqType == undefined) {
																				jobId = incommingdata.data[0].job.displayID;
																			} else {
																				jobId = incommingdata.data[0].displayID;
																			}
																			ctx.setVariable("jobId", jobId);
																			if (incommingdata.reqType == 'Create' || incommingdata.reqType == undefined) {
																				ExternalRefID = incommingdata.data[0].job.id
																			} else {
																				ExternalRefID = incommingdata.data[0].id
																			}

																			ctx.setVariable("ExternalRefID", ExternalRefID);
																			createdAt = incommingdata.data[0].createdAt;
																			ctx.setVariable("createdAt", createdAt);
																			encodedJson = jsonData.toString('base64');
																			ctx.setVariable("encodedJson", encodedJson);

																			IIBPayload = {
																				"jobId": jobId,
																				"messageId": incommingdata.messageId,
																				"timeModified": incommingdata.eventTime,
																				"messageType": incommingdata.messageType,
																				"ExternalRefID": ExternalRefID,
																				"createdAt": createdAt,
																				"payLoad": encodedJson
																			}
																			ctx.setVariable("IIBPayload", IIBPayload);
																			session.output.write(IIBPayload);
																			var targetQueue = session.parameters.Queue;
																			var options = {
																				target: targetQueue,
																				data: IIBPayload
																			};

																			try {
																				urlopen.open(options, function(error, response) {
																					var hm = require('header-metadata');
																					if (error) {
																						logger.error('Mqurlopen.open error');
																						var ErrorTxt = "FSE45_21: Mqurlopen.open error";
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																						ctxretry.setVariable("retry", 'yes');
																						ctx.setVariable("foa_dispatchWork", 'yes');
																						//session.reject('** Mqurlopen.open error');
																						hm.response.statusCode = 500;
																					} else {
																						var mqrc = response.statusCode;
																						if (mqrc == 0) {
																							response.readAsBuffer(function(readError, responseData) {
																								if (readError) {
																									hm.response.statusCode = 500
																									logger.debug('FSE45_21:Could not place message in Queue|errorString: ErrorCode = 500' + readError);
																									var ErrorTxt = 'FSE45_21:Could not place message in Queue|errorString: ErrorCode = 500' + readError;
																									ctx.setVariable("ErrorTxt", ErrorTxt);
																									ctx.setVariable("foa_dispatchWork", 'yes');
																									ctxretry.setVariable("retry", 'yes');
																								} else {
																									console.log("MQResponseData " + responseData);
																									sm.setVar('var://service/mpgw/skip-backside', true);
																								}
																							});
																						} else {
																							logger.error(' ** Mqurlopen.open error [MQRC=' + mqrc + ']');
																							var ErrorTxt = 'FSE45_21 ** Mqurlopen.open error [MQRC=' + mqrc + ']';
																							ctx.setVariable("ErrorTxt", ErrorTxt);
																							ctx.setVariable("foa_dispatchWork", 'yes');
																							ctxretry.setVariable("retry", 'yes');
																							//	session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
																							hm.response.statusCode = 500
																						}
																					}
																				});	//urlopen for mq close
																			} catch (err) {
																				var ErrorTxt = 'FSE45_21 ** Mqurlopen.open error [MQRC=' + err + ']';
																				ctx.setVariable("ErrorTxt", ErrorTxt);
                                                                                                                                                                ctxretry.setVariable("retry", 'yes');
																				ctx.setVariable("foa_dispatchWork", 'yes');
																			}
																		}
																	}
																});
															}
														}
													});
													//end														
												}
											})
										} else {
											logger.error("urlopen connect error with GetCrewAssignment api " + JSON.stringify(error));
											session.reject("urlopen connect error with GetCrewAssignment api " + JSON.stringify(error));
										}
									}
								});
								// crewassignment call end
							} else {
								console.log("MQResponseData " + responseData);
								sm.setVar('var://service/mpgw/skip-backside', true);
							}
						}
					})
				}// closing 200 responsecode
				else {
					sm.setVar('var://service/mpgw/skip-backside', true);
				}
			}
		});
	}
});
