var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var logger = console.options({ 'category': 'all' });
var FSErequest;
var incommingdata;
var CallID;
var ExternalRefID;
var createdAt;
var errorDesc;
ctx.setVariable('ExitStatusCode', '500');
session.input.readAsBuffer(function(readAsJSONError, jsonData) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		//session.output.write(readAsJSONError);
	} else {
		incommingdata = JSON.parse(jsonData);
		var ExternalRefID = incommingdata.data[0].jobID + ":" + incommingdata.data[0].id;
		var fseResponse = {};
		var incomingPayload = ctx.getVariable("IncomingPayload");
		fseResponse.messageId = incomingPayload.messageId
		if (incomingPayload.crewAssignmentID != undefined || incomingPayload.crewAssignmentID != null) {
			fseResponse.crewAssignmentID = incomingPayload.crewAssignmentID
		}
		if (incomingPayload.crewAssignmentDisplayID != undefined || incomingPayload.crewAssignmentDisplayID != null) {
			fseResponse.crewAssignmentDisplayID = incomingPayload.crewAssignmentDisplayID
		}
		if (incomingPayload.crewDisplayID != undefined || incomingPayload.crewDisplayID != null) {
			fseResponse.crewDisplayID = incomingPayload.crewDisplayID
		}
		if (incomingPayload.messageType != undefined || incomingPayload.messageType != null) {
			fseResponse.messageType = incomingPayload.messageType
		}
		if (incomingPayload.assignmentStatus != undefined || incomingPayload.assignmentStatus != null) {
			fseResponse.assignmentStatus = incomingPayload.assignmentStatus
		}
		if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
			fseResponse.crewAssigmentTrigger = incomingPayload.crewAssigmentTrigger
		}
		let getXmlValue = function(str, key) {
			return str.substring(
				str.lastIndexOf('<' + key + '>') + ('<' + key + '>').length,
				str.lastIndexOf('</' + key + '>')
			);
		}
		FSErequest = {
			"Task": {
				"@objectType": "Task",
				"@createOrUpdate": true,
				"CallID": incommingdata.data[0].displayID,
				"Number": 0,
				"ExternalRefID": incommingdata.data[0].jobID + ":" + incommingdata.data[0].id,
				"Status": "Canceled"
			},
			ErrorOnNonExistingDictionaries: true
		}
		var currentTimeStamp = new Date().toISOString();
		var targetFSE = session.parameters.FSEurl;
		var options = {
			target: targetFSE,
			data: FSErequest,
			contentType: 'application/json',
			sslClientProfile: 'FSE_Client_Profile',
			method: 'POST',
			headers: {
				'Authorization': 'Basic ' + session.parameters.FSEToken
			}
		};
		//session.output.write(FSErequest);
		urlopen.open(options, function(error, response) {
			if (error) {
				logger.error(" urlopen connect error with Cancel FSEAPI " + JSON.stringify(error));
				var ErrorTxt = "FSE45_15: foa_ohug_cancel urlopen connect error with Get Cancel FSEAPI " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				session.output.write(FSErequest);
				ctx.setVariable("retry", 'yes');
				//	ctx.setVariable("ExitStatusCode", error.status code);
				//	session.reject("urlopen connect error with FSEAPI " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				//checking errorcode from file start
				var errorStatus;
				if (responseStatusCode == 200) { } else {
					var ErrorCodes = session.name('ILS').getVariable('ErrodeCodes');
					for (var i = 0; i < ErrorCodes.ErrorCode.length; i++) {
						if (responseStatusCode == ErrorCodes.ErrorCode[i].value) {


							errorStatus = 'yes';
						}
					}
				}
				//checking errorcode from file end
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in reading message from Cancel FSEAPI" + JSON.stringify(error));
							ctx.setVariable("ErrorTxt", "failure in reading message from Cancel FSEAPI" + JSON.stringify(error));
							ctx.setVariable("ExitStatusCode", responseStatusCode);
							session.reject(" failure in reading message from Cancel FSEAPI" + JSON.stringify(error));
						} else {
							var FSEResponse = JSON.parse(responseData);
							ctx.setVariable("FSEResponse", FSEResponse);
							var flagvalue;
							var flagnumber;
							var FSEAPIRes = JSON.parse(responseData);
							if (!(FSEAPIRes.ExceptionMessage == undefined || FSEAPIRes.ExceptionMessage == '')) {
								var errorDesc = getXmlValue(FSEAPIRes.ExceptionMessage, 'ErrorDescription');
								ctx.setVariable("errorDesc", errorDesc);
								var meesage = FSEAPIRes.ExceptionMessage;
								var ServerErrorCode = session.parameters.CancelresponseErrorcodes;
								var ErrorCodeList = ServerErrorCode.split(',');
								for (var i = 0; i < ErrorCodeList.length; i++) {
									var numberval = Number(ErrorCodeList[i])
									if (meesage.includes(String(numberval))) {
										flagvalue = 'yes'
										flagnumber = numberval;
									}
								}
								if (errorDesc.includes("SQL query execution failure")) {
									var ErrorTxt = "SQL query execution failure in foa_ohug_cancel: " + JSON.stringify(FSEAPIRes.ExceptionMessage);
									logger.error(ErrorTxt)
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ctx.setVariable("retry", 'yes');
								}
							}

							if (flagvalue) {
								logger.debug("FSEAPIRes.ExceptionMessage : " + FSEAPIRes.ExceptionMessage);
								var ErrorTxt = "FSEAPIRes.ExceptionMessage errorCode : " + JSON.stringify(FSEAPIRes.ExceptionMessage);
								ctx.setVariable("ErrorTxt", ErrorTxt);
								ctx.setVariable("retry", 'yes');
								session.output.write(FSErequest);
								ctx.setVariable("exitDestination", session.parameters.FSEurl);
							} else {

								//ils exit success
								ctx.setVariable("fseResponse", FSErequest)
								ctx.setVariable('Exitdestination', session.parameters.FSEurl);
								ctx.setVariable('Exitdescription', session.parameters.FSEDescription);
								var ms = require('multistep');
								ms.callRule('foa_ohug_cancel_ExitIls_Rule', null, null, function(error) {
									if (error) {
										// throw error;
									}
								});
								var incomingPayload = ctx.getVariable("IncomingPayload");
								var seqResponse = {
									"messageId": incomingPayload.messageId,
									"eventType": "Status",
									"serviceName": "workOrderFSE",
									"sendTimeStamp": incomingPayload.sendTimeStamp
								}
								if (!(incomingPayload.workFlowType === undefined || incomingPayload.workFlowType === null)) {
									seqResponse.workFlowType = incomingPayload.workFlowType
								}
								if (!(incomingPayload.workFlowRequirementEvent === undefined || incomingPayload.workFlowRequirementEvent === null)) {
									seqResponse.workFlowRequirementEvent = incomingPayload.workFlowRequirementEvent
								}
								if (incomingPayload.eventKey != undefined || incomingPayload.eventKey != null) {
									seqResponse.eventKey = incomingPayload.eventKey
								}

								if (incomingPayload.crewAssignmentID != undefined || incomingPayload.crewAssignmentID != null) {
									seqResponse.crewAssignmentID = incomingPayload.crewAssignmentID
								}
								if (incomingPayload.crewAssignmentDisplayID != undefined || incomingPayload.crewAssignmentDisplayID != null) {
									seqResponse.crewAssignmentDisplayID = incomingPayload.crewAssignmentDisplayID
								}
								if (incomingPayload.crewDisplayID != undefined || incomingPayload.crewDisplayID != null) {
									seqResponse.crewDisplayID = incomingPayload.crewDisplayID
								}
								if (incomingPayload.messageType != undefined || incomingPayload.messageType != null) {
									seqResponse.messageType = incomingPayload.messageType
								}
								if (incomingPayload.assignmentStatus != undefined || incomingPayload.assignmentStatus != null) {
									seqResponse.assignmentStatus = incomingPayload.assignmentStatus
								}
								if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
									seqResponse.crewAssigmentTrigger = incomingPayload.crewAssigmentTrigger
								}

								if (incomingPayload.eventContext != undefined || incomingPayload.eventContext != null) {
									seqResponse.eventContext = incomingPayload.eventContext
								}
								if (incomingPayload.EventTimeStamp != undefined || incomingPayload.EventTimeStamp != null) {
									seqResponse.EventTimeStamp = incomingPayload.EventTimeStamp
								}

								if (FSEResponse.ReturnCode == 'Success') {
									fseResponse.ExternalRefID = ExternalRefID;
									fseResponse.createdAt = currentTimeStamp;
									fseResponse.status = "Success";
									fseResponse.jobComment = "Cancel ACK from FSE";
									fseResponse.reqType = "Cancel";
									//session.output.write(fseResponse);
									sendtoQueue(fseResponse);
									SEQResponse(seqResponse);
								} else if (FSEResponse.ReturnCode == 'Failure') {
									var errorDesc = getXmlValue(FSEResponse.ExceptionMessage, 'ErrorDescription');
									fseResponse.ExternalRefID = ExternalRefID;
									fseResponse.createdAt = currentTimeStamp;
									fseResponse.status = "Failure";
									fseResponse.jobComment = errorDesc;
									fseResponse.reqType = "Cancel";
									//session.output.write(fseResponse);
									sendtoQueue(fseResponse);
									SEQResponse(seqResponse);
								}

							}
						}
					});
				} else if (errorStatus == 'yes') {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error("failure in reading message from Cancel FSEAPI" + JSON.stringify(error));
							ctx.setVariable("ErrorTxt", "failure in reading message from Cancel FSEAPI" + JSON.stringify(error));
							ctx.setVariable("ExitStatusCode", responseStatusCode);
							session.reject("failure in reading message from Cancel FSEAPI");
						} else {
							var flagvalue;
							var flagnumber;
							if (errorStatus == 'yes' && responseStatusCode === 401) {
								var FSEAPIRes = responseData.toString();
							} else if(errorStatus=='yes'){
								var FSEAPIRes = JSON.parse(responseData);
							}
							if (!(FSEAPIRes.ExceptionMessage == undefined || FSEAPIRes.ExceptionMessage == '')) {
								errorDesc = getXmlValue(FSEAPIRes.ExceptionMessage, 'ErrorDescription');
								ctx.setVariable("errorDesc", errorDesc);
								var ServerErrorCode = session.parameters.CancelresponseErrorcodes;
								var ErrorCodeList = ServerErrorCode.split(',');
								var meesage = FSEAPIRes.ExceptionMessage;
								for (var i = 0; i < ErrorCodeList.length; i++) {
									var numberval = Number(ErrorCodeList[i])
									var meesage = FSEAPIRes.ExceptionMessage;
									if (meesage.includes(String(numberval))) {
										flagvalue = 'yes'
										flagnumber = numberval;
									}
								}
								if (errorDesc.includes("SQL query execution failure")) {
									var ErrorTxt = "SQL query execution failure in foa_ohug_cancel: " + JSON.stringify(FSEAPIRes.ExceptionMessage);
									logger.error(ErrorTxt)
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ctx.setVariable("retry", 'yes');
								}
							}

							if (flagvalue) {
								logger.debug("FSEAPIRes.ExceptionMessage : " + FSEAPIRes.ExceptionMessage);
								var ErrorTxt = "FSEAPIRes.ExceptionMessage errorCode : " + JSON.stringify(FSEAPIRes.ExceptionMessage);
								ctx.setVariable("ErrorTxt", ErrorTxt);
								ctx.setVariable("retry", 'yes');
								session.output.write(FSErequest);
								ctx.setVariable("exitDestination", session.parameters.FSEurl);
							} else {


								//logger.error("Error code returned from Cancel FSEAPI" + responseStatusCode + " " + responseData);
								//session.reject("Error code returned from Cancel FSEAPI" + responseStatusCode + " " + responseData);
								fseResponse.ExternalRefID = ExternalRefID;
								fseResponse.createdAt = currentTimeStamp;
								fseResponse.status = "Failure";
								fseResponse.jobComment = "Failed in FSE";
								fseResponse.reqType = "Cancel";
								//session.output.write(fseResponse);

								//ils exit success
								ctx.setVariable("fseResponse", FSErequest)
								ctx.setVariable('Exitdestination', session.parameters.FSEurl);
								ctx.setVariable('Exitdescription', session.parameters.FSEDescription);

								if (!(responseStatusCode === 401)) {
									var ms = require('multistep');
									ms.callRule('foa_ohug_cancel_ExitIls_Rule', null, null, function(error) {
										if (error) {
											// throw error;
										}
									});
								}


								var incomingPayload = ctx.getVariable("IncomingPayload");
								var seqResponse = {
									"messageId": incomingPayload.messageId,
									"eventType": "Status",
									"serviceName": "workOrderFSE",
									"sendTimeStamp": incomingPayload.sendTimeStamp
								}

								if (!(incomingPayload.workFlowType === undefined || incomingPayload.workFlowType === null)) {
									seqResponse.workFlowType = incomingPayload.workFlowType
								}
								if (!(incomingPayload.workFlowRequirementEvent === undefined || incomingPayload.workFlowRequirementEvent === null)) {
									seqResponse.workFlowRequirementEvent = incomingPayload.workFlowRequirementEvent
								}
								if (incomingPayload.eventKey != undefined || incomingPayload.eventKey != null) {
									seqResponse.eventKey = incomingPayload.eventKey
								}
								if (incomingPayload.crewAssignmentID != undefined || incomingPayload.crewAssignmentID != null) {
									seqResponse.crewAssignmentID = incomingPayload.crewAssignmentID
								}
								if (incomingPayload.crewAssignmentDisplayID != undefined || incomingPayload.crewAssignmentDisplayID != null) {
									seqResponse.crewAssignmentDisplayID = incomingPayload.crewAssignmentDisplayID
								}
								if (incomingPayload.crewDisplayID != undefined || incomingPayload.crewDisplayID != null) {
									seqResponse.crewDisplayID = incomingPayload.crewDisplayID
								}
								if (incomingPayload.messageType != undefined || incomingPayload.messageType != null) {
									seqResponse.messageType = incomingPayload.messageType
								}
								if (incomingPayload.assignmentStatus != undefined || incomingPayload.assignmentStatus != null) {
									seqResponse.assignmentStatus = incomingPayload.assignmentStatus
								}
								if (incomingPayload.crewAssigmentTrigger != undefined || incomingPayload.crewAssigmentTrigger != null) {
									seqResponse.crewAssigmentTrigger = incomingPayload.crewAssigmentTrigger
								}

								if (incomingPayload.eventContext != undefined || incomingPayload.eventContext != null) {
									seqResponse.eventContext = incomingPayload.eventContext
								}
								if (incomingPayload.EventTimeStamp != undefined || incomingPayload.EventTimeStamp != null) {
									seqResponse.EventTimeStamp = incomingPayload.EventTimeStamp
								}

								if (!(responseStatusCode === 401)) {
									sendtoQueue(fseResponse);
									SEQResponse(seqResponse);
									
								} else {
									ctx.setVariable("AuthError",true);
									ctx.setVariable('AuthExitdescription', "401 - Unauthorized: Access is denied due to invalid credentials");
									ctx.setVariable('AuthExitstatus', "401");
									session.reject(FSEAPIRes)
									//session.reject("401 - Unauthorized: Access is denied due to invalid credentials")
								}
							}
						}//
					});
				} else {
					logger.error(" urlopen connect error with Cancel FSEAPI " + JSON.stringify(response));
					var ErrorTxt = "FSE45_15: foa_ohug_cancel urlopen connect error with Get Cancel FSEAPI " + JSON.stringify(response);
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("ExitStatusCode", responseStatusCode);
					ctx.setVariable("retry", 'yes');
					session.output.write(FSErequest);
				}
			}
		})
		// END FSE request
	}
});



//cancelQueue
function sendtoQueue(fseResponse) {
	logger.info("Inside Function");
	var targetQueue = session.parameters.Queue;
	var options = {
		target: targetQueue,
		data: fseResponse
	};
	try {
		urlopen.open(options, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.error('FSE45_16:foa_ohug_cancel  Mqurlopen.open error');
				ctx.setVariable("ErrorTxt", 'FSE45_16:foa_ohug_cancel  Mqurlopen.open error ' + session.parameters.Queue);
				ctx.setVariable("ExitStatusCode", "500");
				ctx.setVariable("retry", 'yes');
				session.reject('** Mqurlopen.open error');
				hm.response.statusCode = 500;
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							logger.error('FSE45_16: foa_ohug_cancel Mqurlopen.open error');
							ctx.setVariable("ErrorTxt", 'FSE45_16: foa_ohug_cancel Mqurlopen.open error ' + session.parameters.Queue);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ExitStatusCode", "500")
							session.reject('** Mqurlopen.open error');
						} else {
							console.log("MQResponseData " + responseData);
							session.output.write(fseResponse);
							//						//ils exit success
							//						ctx.setVariable("fseResponse", fseResponse)
							//						ctx.setVariable('Exitdestination',session.parameters.Queue);
							//						ctx.setVariable('Exitdescription',session.parameters.fseResponseSucessDescription);
							//						var ms = require('multistep');
							//                        ms.callRule('foa_ohug_cancel_ExitIls_Rule', null, null, function(error) {
							//                            if (error) {
							//                                throw error;
							//                            }
							//                        });
						}
					});
				} else {
					logger.error(' foa_ohug_cancel ** Mqurlopen.open error [MQRC=' + mqrc + ']');
					ctx.setVariable("ErrorTxt", 'FSE45_16: foa_ohug_cancel ** Mqurlopen.open error [MQRC=' + mqrc + '] ' + session.parameters.Queue);
					ctx.setVariable("ExitStatusCode", "500");
					ctx.setVariable("retry", 'yes');
					session.output.write(fseResponse);
					hm.response.statusCode = 500
				}
			}
		});
	} catch (err) {
		ctx.setVariable("ErrorTxt", 'FSE45_16: foa_ohug_cancel ** Mqurlopen.open error [MQRC=' + err + '] ' + session.parameters.Queue);
		ctx.setVariable("retry", 'yes');
		session.output.write(fseResponse);
	}
}


//confirmation request
function SEQResponse(seqResponse) {
	seqResponse.confirmation = "Y"
	var targetQueue = session.parameters.SEQCACELResponseQueue;
	var options = {
		target: targetQueue,
		data: seqResponse
	};
	//session.output.write(seqResponse);
	try {
		urlopen.open(options, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				logger.error('foa_ohug_cancel Mqurlopen.open error');
				var ErrorTxt = ('FSE45_25: foa_ohug_cancel Mqurlopen.open error ' + error + ' ' + session.parameters.SEQCACELResponseQueue);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ExitStatusCode", "500");
				//session.reject('** Mqurlopen.open error');
				hm.response.statusCode = 500;
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							logger.error('FSE45_25:foa_ohug_cancel Mqurlopen.open error ' + readError);
							ctx.setVariable("ErrorTxt", 'FSE45_25:foa_ohug_cancel Mqurlopen.open error ' + session.parameters.SEQCACELResponseQueue);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ExitStatusCode", "500")
							//	session.reject( 'Mqurlopen.open error');
						} else {
							console.log("MQResponseData " + responseData);
							//ils exit success call
							ctx.setVariable("seqResponseStatus", "yes");
							ctx.setVariable("seqResponse", seqResponse);
							ctx.setVariable('Exitdescription', session.parameters.SEQResponseDescription);
							ctx.setVariable('Exitdestination', session.parameters.SEQCACELResponseQueue)
							var ms = require('multistep');
							ms.callRule('foa_ohug_cancel_ExitIls_Rule', null, null, function(error) {
								if (error) {
									//      throw error;
								}
							});
						}
					});
				} else {
					logger.error('FSE45_25 foa_ohug_cancel Mqurlopen.open error [MQRC=' + mqrc + ']');
					ctx.setVariable("ErrorTxt", 'FSE45_25 foa_ohug_cancel Mqurlopen.open error [MQRC=' + mqrc + '] ' + session.parameters.SEQCACELResponseQueue);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("ExitStatusCode", "500")
					hm.response.statusCode = 500
				}
			}
		});
	} catch {
		ctx.setVariable("ErrorTxt", 'FSE45_25 foa_ohug_cancel Mqurlopen.open error [MQRC=' + mqrc + '] ' + session.parameters.SEQCACELResponseQueue);
		ctx.setVariable("retry", 'yes');
	}
}
