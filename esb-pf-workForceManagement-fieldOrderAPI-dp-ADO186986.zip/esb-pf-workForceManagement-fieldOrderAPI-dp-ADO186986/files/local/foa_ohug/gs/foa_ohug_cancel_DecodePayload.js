var logger = console.options({'category': 'all'});
var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
session.input.readAsJSON(function(readAsJSONError, requestJsonpayload){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		 ctx.setVariable('IncomingPayload',requestJsonpayload);

}
});