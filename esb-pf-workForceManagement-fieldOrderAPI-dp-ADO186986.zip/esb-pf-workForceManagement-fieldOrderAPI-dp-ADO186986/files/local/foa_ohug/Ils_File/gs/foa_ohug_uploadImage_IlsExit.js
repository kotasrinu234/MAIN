var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
	var ctx = session.name("omsfoa_ohug") || session.createContext("omsfoa_ohug");
	var retry = ctx.getVariable('retry');
	var ErrorTxt = ctx.getVariable('ErrorTxt')
	if(retry != 'yes'){
	ctx.setVariable('exitStatus','0');
	}else{
	ctx.setVariable('exitStatus','');
	ctx.setVariable('exitDestination','FOA_UPLOADATTACHMENT.SEND');
	ctx.setVariable('Exitdescription',ErrorTxt)
	}
	}
	});