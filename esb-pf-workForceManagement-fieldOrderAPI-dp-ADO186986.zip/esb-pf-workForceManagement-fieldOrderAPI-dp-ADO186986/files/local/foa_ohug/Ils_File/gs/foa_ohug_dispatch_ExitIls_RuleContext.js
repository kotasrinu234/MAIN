var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
	var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
	var payload = ctx.getVariable('ReqData')
	session.output.write(payload);
	
	}
	
	});
