var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var exitdescription = session.parameters.exitdescription;
var exitDestination = session.parameters.FSEUpdateAPI;
var logger = console.options({
	'category': 'all'

});
var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var ctx1 = session.name("ILS") || session.createContext("ILS");
var exitStatus = ctx.getVariable("exitstatus")
var retry = ctx.getVariable('retry');
var ErrorTxt = ctx.getVariable('ErrorTxt')
var payload = ctx.getVariable("fseUpdateReqPayload")
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		
		    ctx1.setVariable("exitDestination", exitDestination);
		if (retry != 'yes') {
			ctx1.setVariable("exitdescription", exitdescription);
			ctx1.setVariable('exitStatus', '0');
		} else {
			ctx1.setVariable('exitStatus', exitStatus);
			ctx1.setVariable('exitdescription', ErrorTxt);
		}
	}
});
session.output.write(payload)
