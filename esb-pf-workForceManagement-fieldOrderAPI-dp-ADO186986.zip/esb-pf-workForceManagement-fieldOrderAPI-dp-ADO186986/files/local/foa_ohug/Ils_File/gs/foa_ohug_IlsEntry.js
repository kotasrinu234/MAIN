var ctx = session.name("omsfoa_ohug") || session.createContext("omsfoa_ohug");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({'category': 'all'});
var urlIn = sm.getVar('var://service/URL-in');
var CancelQueue = session.parameters.CancelQueue;
var CreateUpdateQueue = session.parameters.CreateUpdateQueue;
session.input.readAsJSON(function(readAsJSONError, incommingdata){
    if (readAsJSONError){
        hm.response.statusCode = 500 ;
        session.output.write(readAsJSONError);
    } else {
    function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var corid= uuidv4();
        incommingdata.messageId  =corid

                ctx.setVariable('correlationID',corid);
                ctx.setVariable('interfaceName', 'interface45');
        if(incommingdata.eventTime != undefined){incommingdata.eventTime = incommingdata.eventTime
        }else if(incommingdata.data[0].updatedAt != undefined){incommingdata.eventTime = incommingdata.data[0].updatedAt
        }else if(incommingdata.data[0].createdAt != undefined){incommingdata.eventTime =incommingdata.data[0].createdAt}
        ctx.setVariable('sourceEventTimestamp',incommingdata.eventTime);
        var urlIn = sm.getVar('var://service/URL-in');
        ctx.setVariable('sourceUrl',urlIn);
        ctx.setVariable('EXITdestination',session.parameters.CreateUpdateQueue);
        if(urlIn.includes('Cancel')){
	             ctx.setVariable('messageType','crewAssignmentEvent');
	            if(incommingdata.data[0].id !=undefined){ctx.setVariable('crewAssignmentID',incommingdata.data[0].id);}
            if(incommingdata.data[0].displayID !=undefined){ctx.setVariable('crewAssignmentDisplayID',incommingdata.data[0].displayID);}
incommingdata.messageType = 'crewAssignmentEvent'
incommingdata.crewAssigmentTrigger = 'Y'


                    ctx.setVariable('EXITdestination',session.parameters.CancelQueue);
                            ctx.setVariable('messageType','crewAssignmentEvent');
                            ctx.setVariable('description',session.parameters.crewAssignmentCancelEventdescription);
                            ctx.setVariable('EXITdescription',session.parameters.CancelExitdescription);
                            session.output.write(incommingdata)

//lookup start
                var crewworkTypeIdlookup = {
                     "lookupReq": {
                                                "type": [
                                                    {
                        "name": "workType.workflows",
                        "id": incommingdata.data[0].workTypeID,
                        "status": incommingdata.data[0].status
                                                  }      
                                                          ]
                                                        }
            };
            var url = session.parameters.lookUpURL;
            var LookupServiceResponse = {
                                        target: url,
                                        method: 'POST',
                                        contentType: 'application/json',
                                        data:crewworkTypeIdlookup
                                        };
            urlopen.open(LookupServiceResponse, function(error, response) {
                    if (error) {
                        logger.error(" urlopen connect error for LookupServiceResponse" + JSON.stringify(error));
                        session.reject("urlopen connect error for LookupServiceResponse" + JSON.stringify(error));
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200 )  {
                        response.readAsBuffer(function(error, responseData) {
                        if (error) {
                        logger.error(" failure in reading message LookupServiceResponse" + JSON.stringify(error));
                        session.reject("failure in putting message LookupServiceResponse" + JSON.stringify(error));
                        } else {
                        hm.response.statusCode = responseStatusCode;
                        logger.debug("response received from LookupServiceResponse "+ responseData);            
                        var lookupResponse = JSON.parse(responseData)
                        if(lookupResponse.lookupRep.type[0].result==0){
                incommingdata.messageType = "crewAssignmentEvent" ;
                incommingdata.crewAssigmentTrigger = 'Y';
                incommingdata.assignmentStatus = lookupResponse.lookupRep.type[0].label
            ctx.setVariable('assignmentStatus',lookupResponse.lookupRep.type[0].label);
                session.output.write(incommingdata)
                                                }else{
                                                    incommingdata.messageType = "crewAssignmentEvent" ;
                                                    incommingdata.crewAssigmentTrigger = 'Y';
    session.output.write(incommingdata)
                                }// lookup end;
                                                }
                                            });
                                        }else {
                                            logger.error(" lookup service responsecode is "+responseStatusCode);
                                            session.reject("lookup service responsecode is "+responseStatusCode);
                                        }
                                    }
                                        });


        } else if (urlIn.includes('Update')){
            if(!(incommingdata.data[0].jobTypeID == null || incommingdata.data[0].jobTypeID == '' || incommingdata.data[0].jobTypeID == undefined)){
                incommingdata.reqType = "Job_update";
                incommingdata.messageType = "jobEvent";
                incommingdata.crewAssigmentTrigger = 'N'                
//ils setting context
        ctx.setVariable('EXITdescription',session.parameters.JobExitdescription);
        ctx.setVariable('messageType','jobEvent');
            if(incommingdata.data[0].id !=undefined){ctx.setVariable('jobID',incommingdata.data[0].id);}
            if(incommingdata.data[0].displayID !=undefined){ctx.setVariable('jobDisplayID',incommingdata.data[0].displayID);}
            if(incommingdata.data[0].job != undefined){
        if(incommingdata.data[0].job.id !=undefined){ctx.setVariable('jobID',incommingdata.data[0].job.id);}
        if(incommingdata.data[0].job.displayID !=undefined){ctx.setVariable('jobDisplayID',incommingdata.data[0].job.displayID);}
        }
        ctx.setVariable('description',session.parameters.Jobupdatedescription);
            session.output.write(incommingdata)

            } else {
	
            //ils setting for crewassignment update
            ctx.setVariable('EXITdescription',session.parameters.CrewExitdescription);
            if(incommingdata.data[0].id !=undefined){ctx.setVariable('crewAssignmentID',incommingdata.data[0].id);}
            if(incommingdata.data[0].displayID !=undefined){ctx.setVariable('crewAssignmentDisplayID',incommingdata.data[0].displayID);}
            if(incommingdata.data[0].job != undefined){
            if(incommingdata.data[0].job.id !=undefined){ctx.setVariable('jobID',incommingdata.data[0].job.id);}
            if(incommingdata.data[0].job.displayID !=undefined){ctx.setVariable('jobDisplayID',incommingdata.data[0].job.displayID);}
        }
           ctx.setVariable('description',session.parameters.crewAssignmentUpdateEventdescription);
        if(incommingdata.data[0].crew !=undefined){
								if(incommingdata.data[0].crew.customFieldValuesExt !=undefined){
				   if(incommingdata.data[0].crew.customFieldValuesExt.CrewID != undefined){
					ctx.setVariable('crewDisplayID',incommingdata.data[0].crew.customFieldValuesExt.CrewID);}}}
                ctx.setVariable('messageType','crewAssignmentEvent');
                //lookup start
                var crewworkTypeIdlookup = {
                     "lookupReq": {
                                                "type": [
                                                    {
                        "name": "workType.workflows",
                        "id": incommingdata.data[0].workTypeID,
                        "status": incommingdata.data[0].status
                                                  }      
                                                          ]
                                                        }
            };
            var url = session.parameters.lookUpURL;
            var LookupServiceResponse = {
                                        target: url,
                                        method: 'POST',
                                        contentType: 'application/json',
                                        data:crewworkTypeIdlookup
                                        };
            urlopen.open(LookupServiceResponse, function(error, response) {
                    if (error) {
                        logger.error(" urlopen connect error for LookupServiceResponse" + JSON.stringify(error));
                        session.reject("urlopen connect error for LookupServiceResponse" + JSON.stringify(error));
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200 )  {
                        response.readAsBuffer(function(error, responseData) {
                        if (error) {
                        logger.error(" failure in reading message LookupServiceResponse" + JSON.stringify(error));
                        session.reject("failure in putting message LookupServiceResponse" + JSON.stringify(error));
                        } else {
                        hm.response.statusCode = responseStatusCode;
                        logger.debug("response received from LookupServiceResponse "+ responseData);            
                        var lookupResponse = JSON.parse(responseData)
                        if(lookupResponse.lookupRep.type[0].result==0){
                incommingdata.messageType = "crewAssignmentEvent" ;
                incommingdata.crewAssigmentTrigger = 'Y';
                incommingdata.assignmentStatus = lookupResponse.lookupRep.type[0].label
            ctx.setVariable('assignmentStatus',lookupResponse.lookupRep.type[0].label);
                session.output.write(incommingdata)
                                                }else{
                                                    incommingdata.messageType = "crewAssignmentEvent" ;
                                                    incommingdata.crewAssigmentTrigger = 'Y';
    session.output.write(incommingdata)
                                }// lookup end;
                                                }
                                            });
                                        }else {
                                            logger.error(" lookup service responsecode is "+responseStatusCode);
                                            session.reject("lookup service responsecode is "+responseStatusCode);
                                        }
                                    }
                                        });
            }
        } else if(urlIn.includes('Create')){
                        //ils setting for crewassignment update
            ctx.setVariable('EXITdescription',session.parameters.CrewCreateExitdescription);
            if(incommingdata.data[0].id !=undefined){ctx.setVariable('crewAssignmentID',incommingdata.data[0].id);}
            if(incommingdata.data[0].displayID !=undefined){ctx.setVariable('crewAssignmentDisplayID',incommingdata.data[0].displayID);}
            if(incommingdata.data[0].job != undefined){
            if(incommingdata.data[0].job.id !=undefined){ctx.setVariable('jobID',incommingdata.data[0].job.id);}
            if(incommingdata.data[0].job.displayID !=undefined){ctx.setVariable('jobDisplayID',incommingdata.data[0].job.displayID);}
    }     
       ctx.setVariable('description',session.parameters.crewAssignmentEventdescription);
if(incommingdata.data[0].crew !=undefined){
				if(incommingdata.data[0].crew.customFieldValuesExt !=undefined){
				   if(incommingdata.data[0].crew.customFieldValuesExt.CrewID != undefined){
					ctx.setVariable('crewDisplayID',incommingdata.data[0].crew.customFieldValuesExt.CrewID);}}}
            ctx.setVariable('messageType','crewAssignmentEvent');
            var crewworkTypeIdlookup = {
                     "lookupReq": {
                                                "type": [
                                                    {
                        "name": "workType.workflows",
                        "id": incommingdata.data[0].workTypeID,
                        "status": incommingdata.data[0].status
                                                  }      
                                                          ]
                                                        }
            };
            var url = session.parameters.lookUpURL;
            var LookupServiceResponse = {
                                        target: url,
                                        method: 'POST',
                                        contentType: 'application/json',
                                        data:crewworkTypeIdlookup
                                        };
            urlopen.open(LookupServiceResponse, function(error, response) {
                    if (error) {
                        logger.error(" urlopen connect error for LookupServiceResponse" + JSON.stringify(error));
                        session.reject("urlopen connect error for LookupServiceResponse" + JSON.stringify(error));
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200 )  {
                        response.readAsBuffer(function(error, responseData) {
                        if (error) {
                        logger.error(" failure in reading message LookupServiceResponse" + JSON.stringify(error));
                        session.reject("failure in putting message LookupServiceResponse" + JSON.stringify(error));
                        } else {
                        hm.response.statusCode = responseStatusCode;
                        logger.debug("response received from LookupServiceResponse "+ responseData);            
                        var lookupResponse = JSON.parse(responseData)
                        if(lookupResponse.lookupRep.type[0].result==0){
                incommingdata.messageType = "crewAssignmentEvent" ;
                incommingdata.crewAssigmentTrigger = 'Y';
                incommingdata.reqType = "Create";
                incommingdata.assignmentStatus = lookupResponse.lookupRep.type[0].label
                ctx.setVariable('assignmentStatus',lookupResponse.lookupRep.type[0].label);
                    session.output.write(incommingdata)
                                }else{
                                    incommingdata.messageType = "crewAssignmentEvent" ;
                incommingdata.crewAssigmentTrigger = 'Y';
                incommingdata.reqType = "Create";
                    session.output.write(incommingdata)
                                }// lookup end;
                                                }
                                            });
                                        }else {
                                            logger.error(" lookup service responsecode is "+responseStatusCode);
                                            session.reject("lookup service responsecode is "+responseStatusCode);
                                        }
                                    }
                                        });
        } else {
        }
    }
});
