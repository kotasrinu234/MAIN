var ctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var logger = console.options({
	'category': 'all'
});


session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {

		var correlationID; 

		var messageType;

		var jobID;
		
		var jobDisplayID;

		var sourceEventTimestamp; 

		var description = session.parameters.ILSEntryDescription;
		ctx.setVariable('description', description);

		var exitDestination = session.parameters.FSEUpdateAPI;
		ctx.setVariable("exitDestination", exitDestination);
	
	if (incomingData.messageId === undefined || incomingData.messageId === null || incomingData.messageId === '') {
			ctx.setVariable("correlationID", "")

		} else {
			correlationID = incomingData.messageId
			ctx.setVariable("correlationID", correlationID);
		}
		
		if (incomingData.messageType === undefined || incomingData.messageType === null || incomingData.messageType === '') {
			ctx.setVariable("messageType", "")

		} else {
			messageType = incomingData.messageType
			ctx.setVariable("messageType", messageType);
		}
		
		if (incomingData.ExternalRefID === undefined || incomingData.ExternalRefID === null || incomingData.ExternalRefID === '') {
			ctx.setVariable("jobID", "")

		} else {
			jobID = incomingData.ExternalRefID
			ctx.setVariable("jobID", jobID);
		}
	
	
	if (incomingData.jobId === undefined || incomingData.jobId === null || incomingData.jobId === '') {
			ctx.setVariable("jobDisplayID", "")

		} else {
			jobDisplayID = incomingData.jobId
			ctx.setVariable("jobDisplayID", jobDisplayID);
		}
	
	if (incomingData.timeModified === undefined || incomingData.timeModified === null || incomingData.timeModified === '') {
			ctx.setVariable("sourceEventTimestamp", "")

		} else {
			sourceEventTimestamp = incomingData.timeModified
			ctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}


	}

});

