var ctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var logger = console.options({
	'category': 'all'
});


session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var correlationID;
		var messageType ;
		var crewAssignmentID ;
		var crewAssignmentDisplayID;
		var sourceEventTimestamp;
		var jobDisplayID;
		var description = session.parameters.CancelEntryDescription
		ctx.setVariable('description', description);
	
	if (incomingData.messageId === undefined || incomingData.messageId === null || incomingData.messageId === '') {
			ctx.setVariable("correlationID", "")
		} else {
			correlationID = incomingData.messageId
			ctx.setVariable("correlationID", correlationID);
		}
		if (incomingData.messageType === undefined || incomingData.messageType === null || incomingData.messageType === '') {
			ctx.setVariable("messageType", "")
		} else {
			messageType = incomingData.messageType
			ctx.setVariable("messageType", messageType);
		}
		if (incomingData.crewAssignmentID === undefined || incomingData.crewAssignmentID === null || incomingData.crewAssignmentID === '') {
			ctx.setVariable("crewAssignmentID", "")
		} else {
			crewAssignmentID = incomingData.crewAssignmentID
			ctx.setVariable("crewAssignmentID", crewAssignmentID);
		}
	if (incomingData.crewAssignmentDisplayID === undefined || incomingData.crewAssignmentDisplayID === null || incomingData.crewAssignmentDisplayID === '') {
			ctx.setVariable("crewAssignmentDisplayID", "")
		} else {
			crewAssignmentDisplayID = incomingData.crewAssignmentDisplayID
			ctx.setVariable("crewAssignmentDisplayID", crewAssignmentDisplayID);
		}
	
	if (incomingData.EventTimeStamp === undefined || incomingData.EventTimeStamp === null || incomingData.EventTimeStamp === '') {
			ctx.setVariable("sourceEventTimestamp", "")
		} else {
			sourceEventTimestamp = incomingData.EventTimeStamp
			ctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
	if (incomingData.jobDisplayID === undefined || incomingData.jobDisplayID === null || incomingData.jobDisplayID === '') {
			ctx.setVariable("jobDisplayID", "")
		} else {
			jobDisplayID = incomingData.jobDisplayID
			ctx.setVariable("jobDisplayID", jobDisplayID);
		}
			
			 fs.readAsJSON("local:/foa_ohug/gs/Errorcodes.json", function(readAsJSONError, jsonInternal) {
				  if (readAsJSONError) {
						session.reject(readAsJSONError);
					} else {
	
	 var jsonInternal = jsonInternal
				ctx.setVariable('ErrodeCodes',jsonInternal)
}
});
	
	}

});
