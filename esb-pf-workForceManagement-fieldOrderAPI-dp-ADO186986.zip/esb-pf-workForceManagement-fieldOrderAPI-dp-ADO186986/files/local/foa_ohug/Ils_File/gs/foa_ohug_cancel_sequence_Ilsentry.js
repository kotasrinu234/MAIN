var ctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlIn = sm.getVar('var://service/URL-in');
var logger = console.options({
	'category': 'all'
});

var entryDescription = session.parameters.SEQCancelILSEntrydescription;
var exitdestination = session.parameters.SEQcancelexitdescription;
var messageType = session.parameters.messageType;

ctx.setVariable('entryDescription', entryDescription);
ctx.setVariable('exitdestination', exitdestination);
ctx.setVariable('messageType', messageType);
ctx.setVariable('sourceUrl', urlIn);
session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var correlationID;
		var crewAssignmentID;
		var crewAssignmentDisplayID;
		var jobDisplayID;
		var sourceEventTimestamp;

		if (incomingData.messageId === undefined || incomingData.messageId === null || incomingData.messageId === '') {
			ctx.setVariable("correlationID", "")

		} else {
			correlationID = incomingData.messageId
			ctx.setVariable("correlationID", correlationID);
		}
		if (incomingData.data[0].id === undefined || incomingData.data[0].id === null || incomingData.data[0].id === '') {
			ctx.setVariable("crewAssignmentID", " ");
		} else {
			crewAssignmentID = incomingData.data[0].id
			ctx.setVariable("crewAssignmentID", crewAssignmentID);
		}
		if (incomingData.data[0].displayID === undefined || incomingData.data[0].displayID === null || incomingData.data[0].displayID === '') {
			ctx.setVariable("crewAssignmentDisplayID", " ");
		} else {
			crewAssignmentDisplayID = incomingData.data[0].displayID
			ctx.setVariable("crewAssignmentDisplayID", crewAssignmentDisplayID);
		}
		if (incomingData.data[0].jobID === undefined || incomingData.data[0].jobID === null || incomingData.data[0].jobID === '') {
			ctx.setVariable("jobDisplayID", " ");
		} else {
			jobDisplayID = incomingData.data[0].jobID
			ctx.setVariable("jobDisplayID", jobDisplayID);
		}
		if (incomingData.eventTime === undefined || incomingData.eventTime === null || incomingData.eventTime === '') {
			ctx.setVariable("sourceEventTimestamp", " ");
		} else {
			sourceEventTimestamp = incomingData.eventTime
			ctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}

	}
});