var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
	var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
	var retry = ctx.getVariable('retry');
	var ExitStatusCode = ctx.getVariable('ExitStatusCode');
	var ErrorTxt = ctx.getVariable('ErrorTxt')
	if(retry != 'yes'){
	ctx.setVariable('exitStatus','0');
	ctx.setVariable('exitDestination','FOA.OHUG.SEND.OHUG.RESPONSE');
	ctx.setVariable('Exitdescription',session.parameters.fseResponseSucessDescription )
	}else{
		
	ctx.setVariable('exitStatus',ExitStatusCode);
	ctx.setVariable('Exitdescription',ErrorTxt)
	}
	}
	});