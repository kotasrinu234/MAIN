var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
		var seqResponseStatus = ctx.getVariable('seqResponseStatus')
		var fseResponse = ctx.getVariable('fseResponse')
		var seqResponse = ctx.getVariable('seqResponse')

		if (seqResponseStatus == "yes") {
			ctx.setVariable("SEQPayload", seqResponse);
			session.output.write(seqResponse);
		}
		else {
			if (fseResponse === undefined || fseResponse === null || fseResponse === "") {

			} else {
				ctx.setVariable("FSEPayload", fseResponse);
				session.output.write(fseResponse);
			}
		}
	}
});
