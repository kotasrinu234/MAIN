var ctx = session.name("omsfoa_ohug") || session.createContext("omsfoa_ohug");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({'category': 'all'});
var urlIn = sm.getVar('var://service/URL-in');
var CancelQueue = session.parameters.CancelQueue;
var CreateUpdateQueue = session.parameters.CreateUpdateQueue;
session.input.readAsJSON(function(readAsJSONError, incommingdata){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
	} else {
				ctx.setVariable('correlationID',incommingdata.messageId);
				ctx.setVariable('interfaceName', 'interface45');
				ctx.setVariable('messageType',incommingdata.messageType);
				ctx.setVariable('sourceEventTimestamp',incommingdata.eventTime)
				var urlIn = sm.getVar('var://service/URL-in');
				ctx.setVariable('sourceUrl',urlIn)
				ctx.setVariable('description',urlIn)
				ctx.setVariable('ENTRYdescription',session.parameters.ENTRYdescription)
				ctx.setVariable('Exitdescription',session.parameters.EXITdescription)
				ctx.setVariable('exitDestination','FOA_UPLOADATTACHMENT.SEND')
				if (incommingdata.messageType == 'crewAssignmentEvent'){
					if(incommingdata.data[0].id !=undefined){ctx.setVariable('crewAssignmentID',incommingdata.data[0].id);}
				    if(incommingdata.data[0].displayID !=undefined){ctx.setVariable('crewAssignmentDisplayID',incommingdata.data[0].displayID);}
		if(incommingdata.data[0].job !=undefined){
			if(incommingdata.data[0].job.id !=undefined){ctx.setVariable('jobID',incommingdata.data[0].job.id);}
			if(incommingdata.data[0].job.displayID !=undefined){ctx.setVariable('jobDisplayID',incommingdata.data[0].job.displayID);}
			}
if(incommingdata.data[0].crew !=undefined){
				if(incommingdata.data[0].crew.customFieldValuesExt !=undefined){
				   if(incommingdata.data[0].crew.customFieldValuesExt.CrewID != undefined){
					ctx.setVariable('crewDisplayID',incommingdata.data[0].crew.customFieldValuesExt.CrewID);}}}
					ctx.setVariable('assignmentStatus',incommingdata.assignmentStatus)
				}
				if (incommingdata.messageType == 'jobEvent'){
					//if(incommingdata.data[0].id !=undefined){ctx.setVariable('crewAssignmentID',incommingdata.data[0].id);}
				    //if(incommingdata.data[0].displayID !=undefined){ctx.setVariable('crewAssignmentDisplayID',incommingdata.data[0].displayID);}
//				if(incommingdata.data[0].job !=undefined){
//				if(incommingdata.data[0].job.id !=undefined){ctx.setVariable('jobID',incommingdata.data[0].job.id);}
//		if(incommingdata.data[0].job.displayID !=undefined){ctx.setVariable('jobDisplayID',incommingdata.data[0].job.displayID);
//}	
					//} 
		if(incommingdata.data[0].id !=undefined){ctx.setVariable('jobID',incommingdata.data[0].id);}
		if(incommingdata.data[0].displayID !=undefined){ctx.setVariable('jobDisplayID',incommingdata.data[0].displayID);}	
					
					}
	
	}
});
