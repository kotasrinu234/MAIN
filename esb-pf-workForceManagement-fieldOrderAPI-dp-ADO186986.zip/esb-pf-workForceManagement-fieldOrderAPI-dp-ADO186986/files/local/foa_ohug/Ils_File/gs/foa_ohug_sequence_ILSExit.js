var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
		var retry = ctx.getVariable('retry');
		var ErrorTxt = ctx.getVariable('ErrorTxt')
		var errorStatus = ctx.getVariable("exitstatus");
		if (retry != 'yes') {
			var exitdescription = session.parameters.SEQexitdescription;
			ctx.setVariable("exitdescription", exitdescription);
			ctx.setVariable('exitStatus', '0');
		} else {
			ctx.setVariable('exitStatus', errorStatus);
			//ctx.setVariable('exitDestination','FOA_UPLOADATTACHMENT.SEND');
			ctx.setVariable('exitdescription', ErrorTxt)
		}
	}
});