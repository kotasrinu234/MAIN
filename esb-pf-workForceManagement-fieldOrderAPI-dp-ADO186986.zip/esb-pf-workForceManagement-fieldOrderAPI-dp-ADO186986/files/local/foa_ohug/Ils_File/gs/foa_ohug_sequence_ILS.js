var ctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else if (incomingData.crewAssigmentTrigger === "Y") {
		if (incomingData.data[0].id !== undefined) {
			ctx.setVariable("crewAssignmentID", incomingData.data[0].id);
		}
		if (incomingData.data[0].displayID !== undefined) {
			ctx.setVariable("crewAssignmentDisplayID", incomingData.data[0].displayID);
		}
		if (incomingData.data[0].job != undefined) {
			if (incomingData.data[0].job.id != undefined) { ctx.setVariable('jobID', incomingData.data[0].job.id); }
			if (incomingData.data[0].job.displayID != undefined) { ctx.setVariable('jobDisplayID', incomingData.data[0].job.displayID); }
		}
		if (incomingData.data[0].crew != undefined) {
			if (incomingData.data[0].crew.customFieldValuesExt != undefined) {
				if (incomingData.data[0].crew.customFieldValuesExt.CrewID != undefined) {
					ctx.setVariable('crewDisplayID', incomingData.data[0].crew.customFieldValuesExt.CrewID);
				}
			}
		}
	} else {
		if (incomingData.data[0].id !== undefined) {
			ctx.setVariable('jobID', incomingData.data[0].id);
		}
		if (incomingData.data[0].displayID !== undefined) {
			ctx.setVariable('jobDisplayID', incomingData.data[0].displayID);
		}
	}
	if (incomingData.assignmentStatus !== undefined) {
		ctx.setVariable("assignmentStatus", incomingData.assignmentStatus);
	}
	var correlationID = incomingData.messageId;
	var messageType = incomingData.messageType;
	var sourceEventTimestamp = incomingData.eventTime;
	var description = session.parameters.SEQILSEntrydescription;
	var exitdestination = session.parameters.foa_ohug_sequenceMQSequanceUrl;

	if (exitdestination !== undefined) {
		ctx.setVariable('exitdestination', exitdestination);
	}
	if (correlationID !== undefined) {
		ctx.setVariable('correlationID', correlationID);
	}
	if (messageType !== undefined) {
		ctx.setVariable('messageType', messageType);
	}
	if (sourceEventTimestamp !== undefined) {
		ctx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
	}
	if (description !== undefined) {
		ctx.setVariable('description', description);
	}

});
