var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ilsctx = session.name("ILS") || session.createContext("ILS");
var exitdescription = session.parameters.SEQcancelexitdescription;
var exitDestination = session.parameters.foa_ohug_cancel_sequence_BackendMQSequanceUrl;
var logger = console.options({
	'category': 'all'
	
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
		var exitStatus = ctx.getVariable("exitstatus")
		ilsctx.setVariable("exitDestination", exitDestination);
		var retry = ctx.getVariable('retry');
		var ErrorTxt = ctx.getVariable('ErrorTxt')
		if (retry != 'yes') {
			ilsctx.setVariable("exitdescription", exitdescription);
			ilsctx.setVariable('exitStatus', '0');
		} else {
			ilsctx.setVariable('exitStatus', exitStatus);
			//ctx.setVariable('exitDestination','FOA_UPLOADATTACHMENT.SEND');
			ilsctx.setVariable('exitdescription', ErrorTxt)
		}
	}
});
