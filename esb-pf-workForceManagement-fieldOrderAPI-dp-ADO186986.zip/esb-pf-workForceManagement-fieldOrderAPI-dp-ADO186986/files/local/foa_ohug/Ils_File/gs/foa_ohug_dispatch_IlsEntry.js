var ctx = session.name("foa_dispatchWork") || session.createContext("foa_dispatchWork");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var fs = require('fs');
var logger = console.options({'category': 'all'});
var urlIn = sm.getVar('var://service/URL-in');
var CancelQueue = session.parameters.CancelQueue;
var CreateUpdateQueue = session.parameters.CreateUpdateQueue;
session.input.readAsJSON(function(readAsJSONError, incommingdata){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
	} else {
				ctx.setVariable('correlationID',incommingdata.messageId);
				ctx.setVariable('interfaceName', 'interface45');
				ctx.setVariable('messageType',incommingdata.messageType);
				if(incommingdata.messageType == 'jobEvent' && incommingdata.crewAssigmentTrigger == 'N' ){
					ctx.setVariable('MessageJobUpdate', 'yes');
				}else{ctx.setVariable('MessageJobUpdate', 'no');}
				if(incommingdata.EventTimeStamp != undefined){
				ctx.setVariable('sourceEventTimestamp',incommingdata.EventTimeStamp)}
				var urlIn = sm.getVar('var://service/URL-in');
				ctx.setVariable('sourceUrl',urlIn)
				ctx.setVariable('description',urlIn)
				ctx.setVariable('ENTRYdescription',session.parameters.ENTRYdescription)
				if(incommingdata.crewAssignmentID !=undefined){ctx.setVariable('crewAssignmentID',incommingdata.crewAssignmentID);}
				if(incommingdata.crewAssignmentDisplayID !=undefined){ctx.setVariable('crewAssignmentDisplayID',incommingdata.crewAssignmentDisplayID);}
				if(incommingdata.jobID !=undefined){ctx.setVariable('jobID',incommingdata.jobID);}
				if(incommingdata.jobDisplayID !=undefined){ctx.setVariable('jobDisplayID',incommingdata.jobDisplayID);}
				if(incommingdata.crewDisplayID !=undefined){ctx.setVariable('crewDisplayID',incommingdata.crewDisplayID);}
				if(incommingdata.assignmentStatus !=undefined){ctx.setVariable('assignmentStatus',incommingdata.assignmentStatus);}
				if(incommingdata.sourceEventTimestamp !=undefined){ctx.setVariable('sourceEventTimestamp',incommingdata.sourceEventTimestamp);}
				
				 fs.readAsJSON("local:/foa_ohug/gs/Errorcodes.json", function(readAsJSONError, jsonInternal) {
				  if (readAsJSONError) {
						session.reject(readAsJSONError);
					} else {
	
	 var jsonInternal = jsonInternal
				ctx.setVariable('ErrodeCodes',jsonInternal)
}
});
	}
});
