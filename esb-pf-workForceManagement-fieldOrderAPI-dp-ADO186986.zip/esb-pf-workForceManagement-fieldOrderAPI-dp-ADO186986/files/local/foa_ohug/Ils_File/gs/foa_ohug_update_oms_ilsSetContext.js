

var ctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');


var entryDescription = session.parameters.FOUPEntryDescription;
var exitDescription = session.parameters.FOUPExitDescription;
var exitDestination = session.parameters.omsExternalURL;

var logger = console.options({
	'category': 'all'
});


session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {

		
		ctx.setVariable('sourceurlexit', 'FOA.OHUG.RECEIVE.OHUG.WORK.SEQ');
		ctx.setVariable('exitDestination', exitDestination);
		ctx.setVariable('entryDescription', entryDescription);
        ctx.setVariable('exitDescription', exitDescription);


	
	if(incomingData.messageId === undefined || incomingData.messageId === null || incomingData.messageId === '') {
		ctx.setVariable("correlationID", "")
	}
	else {
           ctx.setVariable("correlationID", incomingData.messageId);
         }
	
	if(incomingData.messageType === undefined || incomingData.messageType === null || incomingData.messageType === '') {
		ctx.setVariable('messageType', "");
	}
	else {
           ctx.setVariable("messageType", incomingData.messageType);
         }
	
	
	if(incomingData.crewAssignmentID === undefined || incomingData.crewAssignmentID === null || incomingData.crewAssignmentID === '') {
		ctx.setVariable('crewAssignmentID', "");
	}
	else {
           ctx.setVariable("crewAssignmentID", incomingData.crewAssignmentID);
         }
         
         
         
	if(incomingData.crewAssignmentDisplayID === undefined || incomingData.crewAssignmentDisplayID === null || incomingData.crewAssignmentDisplayID === '') {
		ctx.setVariable('crewAssignmentDisplayID', "");
	}
	else {
           ctx.setVariable("crewAssignmentDisplayID", incomingData.crewAssignmentDisplayID);
         }
         
	
	if( incomingData.jobID === undefined ||  incomingData.jobID === null ||  incomingData.jobID === '') {
		ctx.setVariable('jobID', "");
	}
	else {
           ctx.setVariable("jobID",  incomingData.jobID);
         }
	
	
	if(incomingData.jobDisplayID === undefined || incomingData.jobDisplayID === null || incomingData.jobDisplayID === '') {
		ctx.setVariable('jobDisplayID', "");
	}
	else {
           ctx.setVariable("jobDisplayID", incomingData.jobDisplayID);
         }
         
	
	
	if(incomingData.crewDisplayID === undefined || incomingData.crewDisplayID === null || incomingData.crewDisplayID === '') {
		ctx.setVariable('crewDisplayID', "");
	}
	else {
           ctx.setVariable("crewDisplayID", incomingData.crewDisplayID);
         }
	
	
	if(incomingData.assignmentStatus === undefined || incomingData.assignmentStatus === null || incomingData.assignmentStatus === '') {
		ctx.setVariable('assignmentStatus', "");
	}
	else {
           ctx.setVariable("assignmentStatus", incomingData.assignmentStatus);
         }
	
	
	if(incomingData.EventTimeStamp === undefined || incomingData.EventTimeStamp === null || incomingData.EventTimeStamp === '') {
		ctx.setVariable('sourceEventTimestamp', "");
	}
	else {
           ctx.setVariable("sourceEventTimestamp", incomingData.EventTimeStamp);
         }

	
 }
});



