# esb-pf-enterpriseAssetManagement-SNTLServices-dp
PnFSNTLServices  -> SNTLServices
