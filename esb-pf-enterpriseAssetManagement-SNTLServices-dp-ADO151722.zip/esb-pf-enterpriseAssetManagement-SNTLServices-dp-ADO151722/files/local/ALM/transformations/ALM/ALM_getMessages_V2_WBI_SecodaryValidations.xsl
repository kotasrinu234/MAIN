<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpfunc="http://www.datapower.com/extensions/functions" xmlns:regexp="http://exslt.org/regular-expressions" xmlns:exslt="http://exslt.org/common" extension-element-prefixes="dp dpfunc regexp exslt">
	<xsl:template match="/">
		<xsl:variable name="Tests">
			<xsl:apply-templates select="/*/*/*/*"/>
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="local-name(/*) = 'PublishDTEDZLEAD'">
				<xsl:if test="$Tests/elements/name[text() ='LEAD']/@value='false'">
					<dp:reject>
						<xsl:value-of select="'No update value found in PublishDTEDZLEAD'"/>
					</dp:reject>
				</xsl:if>
			</xsl:when>
			<xsl:when test="local-name(/*) = 'PublishDTEDZVERSTAT'">
				<xsl:if test="$Tests/elements/name[text() ='REQUESTNUM']/@value='false' and $Tests/elements/name[text() ='STATUS']/@value='false' and $Tests/elements/name[text() ='STATUSDATE']/@value='false'">
					<dp:reject>
						<xsl:value-of select="'No update value found in PublishDTEDZVERSTAT'"/>
					</dp:reject>
				</xsl:if>
			</xsl:when>
			<xsl:when test="local-name(/*) = 'PublishDTEDZWOSTAT'">
				<xsl:if test="$Tests/elements/name[text() ='DESCRIPTION']/@value='false' and $Tests/elements/name[text() ='STATUS']/@value='false' and $Tests/elements/name[text() ='DTE_UNIT_CENTER']/@value='false' and $Tests/elements/name[text() ='DTE_ADDSTRTNUM']/@value='false' and $Tests/elements/name[text() ='DTE_ADDSTREET']/@value='false' and $Tests/elements/name[text() ='DTE_ADDCITY']/@value='false' and $Tests/elements/name[text() ='DTE_ADDSTATE']/@value='false' and $Tests/elements/name[text() ='DTE_ADDZIP']/@value='false' and $Tests/elements/name[text() ='DTE_CUSTNAME']/@value='false' and $Tests/elements/name[text() ='DTE_CONTPHONEPRIM']/@value='false' and $Tests/elements/name[text() ='SITEID']/@value='false' and $Tests/elements/name[text() ='TARGSTARTDATE']/@value='false' and $Tests/elements/name[text() ='TARGCOMPDATE']/@value='false' and $Tests/elements/name[text() ='STATUSDATE']/@value='false' ">
					<dp:reject>
						<xsl:value-of select="'No update value found in PublishDTEDZWOSTAT'"/>
					</dp:reject>
				</xsl:if>
			</xsl:when>
		</xsl:choose>
	</xsl:template>
	<xsl:template match="/*/*/*/*">
		<elements>
			<name>
				<xsl:attribute name="value"><xsl:value-of select="./text() !=''"/></xsl:attribute>
				<xsl:value-of select="local-name()"/>
			</name>
		</elements>
	</xsl:template>
</xsl:stylesheet>