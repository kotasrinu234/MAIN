<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpfunc="http://www.datapower.com/extensions/functions" xmlns:regexp="http://exslt.org/regular-expressions" xmlns:exslt="http://exslt.org/common" extension-element-prefixes="dp dpfunc regexp exslt">
	<xsl:template match="/*[local-name()='PublishDTECSWOCOMP']/*[local-name()='DTECSWOCOMPSet']/*[local-name()='WORKORDER']">
		<xsl:if test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'CONTRACT_EXPIRATION_DATE' and *[local-name()='ALNVALUE']!= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'CONTRACT_EXPIRATION_DATE' and *[local-name()='NUMVALUE']!= '']">
			<xsl:variable name="CONTRACT_EXPIRATION_DATE" select="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'CONTRACT_EXPIRATION_DATE' and *[local-name()='ALNVALUE'] != '']/*[local-name()='ALNVALUE'] | //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'CONTRACT_EXPIRATION_DATE' and *[local-name()='NUMVALUE'] != '']/*[local-name()='NUMVALUE']"/>
			<xsl:if test="not(regexp:test($CONTRACT_EXPIRATION_DATE, '^([0]?[1-9]|[1][0-2])[/]([0]?[1-9]|[1|2][0-9]|[3][0|1])[/]([0-9]{4}|[0-9]{2})$'))">
				<dp:reject>
					<xsl:value-of select="concat('Validation error at CONTRACT_EXPIRATION_DATE:', $CONTRACT_EXPIRATION_DATE)"/>
				</dp:reject>
			</xsl:if>
		</xsl:if>
		<xsl:if test="/*[local-name()='PublishDTECSWOCOMP']/*[local-name()='DTECSWOCOMPSet']/*[local-name()='WORKORDER']/*[local-name()='STATUS'][text()='CP'] and //*[local-name()='WORKORDERSPEC']">
			<xsl:choose>
				<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ASBFIELDCOMPDATE' and *[local-name()='ALNVALUE']!= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ASBFIELDCOMPDATE' and *[local-name()='NUMVALUE']!= '']">
					<xsl:variable name="ASBFIELDCOMPDATE" select="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ASBFIELDCOMPDATE' and *[local-name()='ALNVALUE'] != '']/*[local-name()='ALNVALUE'] | //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ASBFIELDCOMPDATE' and *[local-name()='NUMVALUE'] != '']/*[local-name()='NUMVALUE']"/>
					<xsl:if test="not(regexp:test($ASBFIELDCOMPDATE, '^([0]?[1-9]|[1][0-2])[/]([0]?[1-9]|[1|2][0-9]|[3][0|1])[/]([0-9]{4}|[0-9]{2})$'))">
						<dp:reject>
							<xsl:value-of select="concat('Validation error at ASBFIELDCOMPDATE:', $ASBFIELDCOMPDATE)"/>
						</dp:reject>
					</xsl:if>
				</xsl:when>
				<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'INSTALLATION_DATE' and *[local-name()='ALNVALUE']!= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'INSTALLATION_DATE' and *[local-name()='NUMVALUE']!= '']">
					<xsl:variable name="INSTALLATION_DATE" select="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'INSTALLATION_DATE' and *[local-name()='ALNVALUE'] != '']/*[local-name()='ALNVALUE'] | //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'INSTALLATION_DATE' and *[local-name()='NUMVALUE'] != '']/*[local-name()='NUMVALUE']"/>
					<xsl:if test="not(regexp:test($INSTALLATION_DATE, '^([0]?[1-9]|[1][0-2])[/]([0]?[1-9]|[1|2][0-9]|[3][0|1])[/]([0-9]{4}|[0-9]{2})$'))">
						<dp:reject>
							<xsl:value-of select="concat('Validation error at INSTALLATION_DATE:', $INSTALLATION_DATE)"/>
						</dp:reject>
					</xsl:if>
				</xsl:when>
				<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'REMOVAL_DATE' and *[local-name()='ALNVALUE']!= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'REMOVAL_DATE' and *[local-name()='NUMVALUE']!= '']">
					<xsl:variable name="REMOVAL_DATE" select="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'REMOVAL_DATE' and *[local-name()='ALNVALUE'] != '']/*[local-name()='ALNVALUE'] | //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'REMOVAL_DATE' and *[local-name()='NUMVALUE'] != '']/*[local-name()='NUMVALUE']"/>
					<xsl:if test="not(regexp:test($REMOVAL_DATE, '^([0]?[1-9]|[1][0-2])[/]([0]?[1-9]|[1|2][0-9]|[3][0|1])[/]([0-9]{4}|[0-9]{2})$'))">
						<dp:reject>
							<xsl:value-of select="concat('Validation error at REMOVAL_DATE:', $REMOVAL_DATE)"/>
						</dp:reject>
					</xsl:if>
				</xsl:when>
				<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'COMPLETION_DATE' and *[local-name()='ALNVALUE']!= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'COMPLETION_DATE' and *[local-name()='NUMVALUE']!= '']">
					<xsl:variable name="COMPLETION_DATE" select="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'COMPLETION_DATE' and *[local-name()='ALNVALUE'] != '']/*[local-name()='ALNVALUE'] | //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'COMPLETION_DATE' and *[local-name()='NUMVALUE'] != '']/*[local-name()='NUMVALUE']"/>
					<xsl:if test="not(regexp:test($COMPLETION_DATE, '^([0]?[1-9]|[1][0-2])[/]([0]?[1-9]|[1|2][0-9]|[3][0|1])[/]([0-9]{4}|[0-9]{2})$'))">
						<dp:reject>
							<xsl:value-of select="concat('Validation error at COMPLETION_DATE:', $COMPLETION_DATE)"/>
						</dp:reject>
					</xsl:if>
				</xsl:when>
				<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ORDER_COMP_DATE' and *[local-name()='ALNVALUE']!= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ORDER_COMP_DATE' and *[local-name()='NUMVALUE']!= '']">
					<xsl:variable name="ORDER_COMP_DATE" select="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ORDER_COMP_DATE' and *[local-name()='ALNVALUE'] != '']/*[local-name()='ALNVALUE'] | //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ORDER_COMP_DATE' and *[local-name()='NUMVALUE'] != '']/*[local-name()='NUMVALUE']"/>
					<xsl:if test="not(regexp:test($ORDER_COMP_DATE, '^([0]?[1-9]|[1][0-2])[/]([0]?[1-9]|[1|2][0-9]|[3][0|1])[/]([0-9]{4}|[0-9]{2})$'))">
						<dp:reject>
							<xsl:value-of select="concat('Validation error at ORDER_COMP_DATE:', $ORDER_COMP_DATE)"/>
						</dp:reject>
					</xsl:if>
				</xsl:when>
				<xsl:otherwise>
					<xsl:choose>
						<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ASBFIELDCOMPDATE' and *[local-name()='ALNVALUE']= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'ASBFIELDCOMPDATE' and *[local-name()='NUMVALUE']= '']">
							<dp:reject>
								<xsl:value-of select="'Validation error at ASBFIELDCOMPDATE is empty'"/>
							</dp:reject>
						</xsl:when>
						<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'INSTALLATION_DATE' and *[local-name()='ALNVALUE']= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'INSTALLATION_DATE' and *[local-name()='NUMVALUE']= '']">
							<dp:reject>
								<xsl:value-of select="'Validation error at INSTALLATION_DATE is empty'"/>
							</dp:reject>
						</xsl:when>
						<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'REMOVAL_DATE' and *[local-name()='ALNVALUE']= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'REMOVAL_DATE' and *[local-name()='NUMVALUE']= '']">
							<dp:reject>
								<xsl:value-of select="'Validation error at REMOVAL_DATE is empty'"/>
							</dp:reject>
						</xsl:when>
						<xsl:when test="//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'COMPLETION_DATE' and *[local-name()='ALNVALUE']= ''] or //*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID']= 'COMPLETION_DATE' and *[local-name()='NUMVALUE']= '']">
							<dp:reject>
								<xsl:value-of select="'Validation error at COMPLETION_DATE is empty'"/>
							</dp:reject>
						</xsl:when>
						<xsl:otherwise>
							<xsl:if test="not(//*[local-name()='WORKORDERSPEC'][*[local-name()='ASSETATTRID'][text()='ASBFIELDCOMPDATE' or text()='INSTALLATION_DATE' or text()='REMOVAL_DATE' or text()='COMPLETION_DATE']])">
								<dp:reject>
									<xsl:value-of select="'Validation error at Completion date not available'"/>
								</dp:reject>
							</xsl:if>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>