<xsl:stylesheet xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions" extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp" version="1.0">
	<xsl:output method="xml"/>


	<xsl:param name="dpconfig:messageType" select="''"/>
	<xsl:param name="dpconfig:interfaceName" select="''"/>
	<xsl:param name="dpconfig:exitDescription" select="''"/>
	<xsl:param name="dpconfig:entryDescription" select="''"/>
	<xsl:param name="dpconfig:sourceUrl" select="''"/>
	<xsl:param name="dpconfig:exitDestination" select="''"/>
	

	<xsl:template match="/">
	
	

	
	
<xsl:variable name="messageType" select="$dpconfig:messageType"/>
<xsl:variable name="interfaceName" select="$dpconfig:interfaceName"/>
<xsl:variable name="exitDescription" select="$dpconfig:exitDescription"/>
<xsl:variable name="entryDescription" select="$dpconfig:entryDescription"/>
<xsl:variable name="sourceUrl" select="$dpconfig:sourceUrl"/>
<xsl:variable name="exitDestination" select="$dpconfig:exitDestination"/>

<xsl:variable name="correlationID" select="string(/*[local-name()='PublishDTE_WOSENTINEL']/@*[local-name()='messageID'])"/>
<xsl:variable name="sourceEventTimestamp" select="string(/*[local-name()='PublishDTE_WOSENTINEL']/@*[local-name()='creationDateTime'])"/>
<xsl:variable name="workOrderNumber" select="string(/*[local-name()='PublishDTE_WOSENTINEL']/*[local-name()='DTE_WOSENTINELSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM'])"/>



		<dp:set-variable name="'var://context/ILS/messageType'" value="$messageType" />
		<dp:set-variable name="'var://context/ILS/interfaceName'" value="$interfaceName" />
		<dp:set-variable name="'var://context/ILS/exitDescription'" value="$exitDescription" />
		<dp:set-variable name="'var://context/ILS/entryDescription'" value="$entryDescription" />
		<dp:set-variable name="'var://context/ILS/sourceUrl'" value="$sourceUrl" />
		<dp:set-variable name="'var://context/ILS/retryCount'" value="'-1'" />
		<dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'" />
		<dp:set-variable name="'var://context/ILS/exitDestination'" value="$exitDestination" />
	

		<dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID" />
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$sourceEventTimestamp" />
		<dp:set-variable name="'var://context/ILS/workOrderNumber'" value="$workOrderNumber" />

	</xsl:template>

</xsl:stylesheet>