<xsl:stylesheet xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions" extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp" version="1.0">
	<xsl:output method="xml"/>
	<xsl:param name="dpconfig:ALM_PublishGroup" select="'UNKNOWN'"/>
	<xsl:param name="dpconfig:ALM_EDM_PublishGroup" select="'UNKNOWN'"/>
	<xsl:param name="dpconfig:ALM_PublishTopicString" select="'UNKNOWN'"/>
	
	<xsl:param name="dpconfig:queueManager" select="''"/>
	<xsl:param name="dpconfig:destQueue" select="''"/>
	
<xsl:variable name="queueManager" select="$dpconfig:queueManager"/>
<xsl:variable name="destQueue" select="$dpconfig:destQueue"/>
<xsl:variable name="target-url" select="concat('dpmq://', $queueManager,'/?RequestQueue=',$destQueue,';Sync=true')"/>

	
	<xsl:template match="/">
		<xsl:variable name="PublishTopicString">
			<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement5')"/>
		</xsl:variable>
		<xsl:variable name="PublishGroup">
			<xsl:value-of select="dp:variable('var://context/ServiceLog/PublishGroup')"/>
		</xsl:variable>
		<!-- create a variable to hold the new MQMD -->
		<xsl:variable name="MQMDStr">
			<MQMD>
				<Format>MQHRF2</Format>
			</MQMD>
		</xsl:variable>
		<xsl:variable name="RFH2">
			<MQRFH2>
				<StrucId>RFH</StrucId>
				<Version>2</Version>
				<Encoding>546</Encoding>
				<CodedCharSetId>819</CodedCharSetId>
				<Format>MQSTR</Format>
				<Flags>0</Flags>
				<NameValueCCSID>1208</NameValueCCSID>
				<NameValueData>
					<NameValue>
						<usr>
							<CorrelationID>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/CorrelationId')"/>
							</CorrelationID>
							<MQMsgPriority/>
							<Context1>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement1')"/>
							</Context1>
							<Context2>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement2')"/>
							</Context2>
							<Context3>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement3')"/>
							</Context3>
							<Context4>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement4')"/>
							</Context4>
							<Context5>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement5')"/>
							</Context5>
						</usr>
					</NameValue>
				</NameValueData>
			</MQRFH2>
		</xsl:variable>
		<!-- serialize the nodeset for transport -->
		<xsl:variable name="mqmdStr">
			<dp:serialize select="$MQMDStr"/>
		</xsl:variable>
		<xsl:variable name="rfh2Str">
			<dp:serialize select="$RFH2"/>
		</xsl:variable>
		<!-- set the MQMD of the response with new MQMD -->
		<dp:set-request-header name="'MQMD'" value="substring-after($mqmdStr, '?>')"/>
		<dp:set-request-header name="'MQRFH2'" value="substring-after($rfh2Str, '?>')"/>
		<!-- <xsl:choose>
			<xsl:when test="$PublishGroup = 'EDM'">
				<xsl:variable name="dpurl" select="concat('dpmq://',$dpconfig:ALM_EDM_PublishGroup,'/?PublishTopicString=',$PublishTopicString)"/>
				<dp:set-variable name="'var://service/routing-url'" value="$dpurl"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:variable name="dpurl" select="concat('dpmq://',$dpconfig:ALM_PublishGroup,'/?PublishTopicString=',$PublishTopicString)"/>
				<dp:set-variable name="'var://service/routing-url'" value="$dpurl"/>
			</xsl:otherwise>
		</xsl:choose> -->
		
		
		
		<dp:set-variable name="'var://service/routing-url'" value="$target-url"/>
		
	</xsl:template>
</xsl:stylesheet>
