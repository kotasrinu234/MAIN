<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:regexp="http://exslt.org/regular-expressions" extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp" xmlns:date="http://exslt.org/dates-and-times" version="1.0">
	<xsl:variable name="Delimiter" select="'_'"/>
	<xsl:template match="/">
		<xsl:variable name="messageType">
			<xsl:value-of select="local-name(/*)"/>
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="$messageType= 'PublishDTECRBLEAKSURVY'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTECRBLEAKSURVY']/*[local-name()='DTECRBLEAKSURVYSet']/*[local-name()='DTE_LEAKSURVEY']/*[local-name()='DTE_LEAKSURVEYID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTECRBLEAKSURVY']/*[local-name()='DTECRBLEAKSURVYSet']/*[local-name()='DTE_LEAKSURVEY']/*[local-name()='DTE_WONUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTECRBLEAKSURVY']/*[local-name()='DTECRBLEAKSURVYSet']/*[local-name()='DTE_LEAKSURVEY']/*[local-name()='DTE_MTRNUM']/text()"/>
				<xsl:variable name="Type" select="'LS'"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTECSWOCOMP'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTECSWOCOMP']/*[local-name()='DTECSWOCOMPSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_ADDEXTERNALID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTECSWOCOMP']/*[local-name()='DTECSWOCOMPSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTECSWOCOMP']/*[local-name()='DTECSWOCOMPSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_EXTERNALID']/text()"/>
				<xsl:variable name="Type" select="'SO'"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderID"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="/*[local-name()='PublishDTECSWOCOMP']/*[local-name()='DTECSWOCOMPSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_EVENTSUBTYPE']/text()"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEESRWOREQ'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEESRWOREQ']/*[local-name()='DTEESRWOREQSet']/*[local-name()='WORKORDER'][1]/*[local-name()='LOCATION']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEESRWOREQ']/*[local-name()='DTEESRWOREQSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WONUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEESRWOREQ']/*[local-name()='DTEESRWOREQSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WORKORDERID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEESRWOREQ']/*[local-name()='DTEESRWOREQSet']/*[local-name()='WORKORDER'][1]/*[local-name()='PM'][1]/*[local-name()='DTE_SURVTYPE']"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDZWOSTAT'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDZWOSTAT']/*[local-name()='DTEDZWOSTATSet']/*[local-name()='WORKORDER'][1]/*[local-name()='TARGSTARTDATE']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDZWOSTAT']/*[local-name()='DTEDZWOSTATSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WONUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDZWOSTAT']/*[local-name()='DTEDZWOSTATSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WORKORDERID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDZWOSTAT']/*[local-name()='DTEDZWOSTATSet']/*[local-name()='WORKORDER'][1]/@action"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDZVERSTAT'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDZVERSTAT']/*[local-name()='DTEDZVERSTATSet']/*[local-name()='PLUSDESTVERSION'][1]/*[local-name()='STATUSDATE']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDZVERSTAT']/*[local-name()='DTEDZVERSTATSet']/*[local-name()='PLUSDESTVERSION'][1]/*[local-name()='MASTERWONUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDZVERSTAT']/*[local-name()='DTEDZVERSTATSet']/*[local-name()='PLUSDESTVERSION'][1]/*[local-name()='REQUESTNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDZVERSTAT']/*[local-name()='DTEDZVERSTATSet']/*[local-name()='PLUSDESTVERSION'][1]/*[local-name()='STATUS']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDZLEAD'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDZLEAD']/*[local-name()='DTEDZLEADSet']/*[local-name()='WOACTIVITY'][1]/*[local-name()='PARENT']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDZLEAD']/*[local-name()='DTEDZLEADSet']/*[local-name()='WOACTIVITY'][1]/*[local-name()='WONUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDZLEAD']/*[local-name()='DTEDZLEADSet']/*[local-name()='WOACTIVITY'][1]/*[local-name()='WORKORDERID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDZLEAD']/*[local-name()='DTEDZLEADSet']/*[local-name()='WOACTIVITY'][1]/*[local-name()='DTE_TASKTYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCPM'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCPM']/*[local-name()='DTEDOCPMSet']/*[local-name()='PM'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCPM']/*[local-name()='DTEDOCPMSet']/*[local-name()='PM'][1]/*[local-name()='PMUID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCPM']/*[local-name()='DTEDOCPMSet']/*[local-name()='PM'][1]/*[local-name()='PMNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCPM']/*[local-name()='DTEDOCPMSet']/*[local-name()='PM'][1]/*[local-name()='TYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCASSET'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCASSET']/*[local-name()='DTEDOCASSETSet']/*[local-name()='ASSET'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCASSET']/*[local-name()='DTEDOCASSETSet']/*[local-name()='ASSET'][1]/*[local-name()='ASSETUID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCASSET']/*[local-name()='DTEDOCASSETSet']/*[local-name()='ASSET'][1]/*[local-name()='ASSETNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCASSET']/*[local-name()='DTEDOCASSETSet']/*[local-name()='ASSET'][1]/*[local-name()='TYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCSR'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCSR']/*[local-name()='DTEDOCSRSet']/*[local-name()='SR'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCSR']/*[local-name()='DTEDOCSRSet']/*[local-name()='SR'][1]/*[local-name()='TICKETUID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCSR']/*[local-name()='DTEDOCSRSet']/*[local-name()='SR'][1]/*[local-name()='TICKETID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCSR']/*[local-name()='DTEDOCSRSet']/*[local-name()='SR'][1]/*[local-name()='DTE_REQTYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCSAFETYPLAN'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCSAFETYPLAN']/*[local-name()='DTEDOCSAFETYPLANSet']/*[local-name()='SAFETYPLAN'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCSAFETYPLAN']/*[local-name()='DTEDOCSAFETYPLANSet']/*[local-name()='SAFETYPLAN'][1]/*[local-name()='SAFETYPLANUID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCSAFETYPLAN']/*[local-name()='DTEDOCSAFETYPLANSet']/*[local-name()='SAFETYPLAN'][1]/*[local-name()='SAFETYPLANID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCSAFETYPLAN']/*[local-name()='DTEDOCSAFETYPLANSet']/*[local-name()='SAFETYPLAN'][1]/*[local-name()='TYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCSERVRECPT'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCSERVRECPT']/*[local-name()='DTEDOCSERVRECPTSet']/*[local-name()='SERVRECTRANS'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCSERVRECPT']/*[local-name()='DTEDOCSERVRECPTSet']/*[local-name()='SERVRECTRANS'][1]/*[local-name()='SERVRECTRANSID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCSERVRECPT']/*[local-name()='DTEDOCSERVRECPTSet']/*[local-name()='SERVRECTRANS'][1]/*[local-name()='POLINENUM']/text()"/>
				<xsl:variable name="Type" select="'RECEIPT'"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCMASTERPM'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCMASTERPM']/*[local-name()='DTEDOCMASTERPMSet']/*[local-name()='MASTERPM'][1]/*[local-name()='MASTERPMNUM']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCMASTERPM']/*[local-name()='DTEDOCMASTERPMSet']/*[local-name()='MASTERPM'][1]/*[local-name()='MASTERPMID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCMASTERPM']/*[local-name()='DTEDOCMASTERPMSet']/*[local-name()='MASTERPM'][1]/*[local-name()='MASTERPMNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCMASTERPM']/*[local-name()='DTEDOCMASTERPMSet']/*[local-name()='MASTERPM'][1]/*[local-name()='TYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCLOCATION'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCLOCATION']/*[local-name()='DTEDOCLOCATIONSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCLOCATION']/*[local-name()='DTEDOCLOCATIONSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='LOCATIONSID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCLOCATION']/*[local-name()='DTEDOCLOCATIONSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='LOCATION']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCLOCATION']/*[local-name()='DTEDOCLOCATIONSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='WMOTYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCJOBPLAN'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCJOBPLAN']/*[local-name()='DTEDOCJOBPLANSet']/*[local-name()='JOBPLAN'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCJOBPLAN']/*[local-name()='DTEDOCJOBPLANSet']/*[local-name()='JOBPLAN'][1]/*[local-name()='JOBPLANID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCJOBPLAN']/*[local-name()='DTEDOCJOBPLANSet']/*[local-name()='JOBPLAN'][1]/*[local-name()='JPNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCJOBPLAN']/*[local-name()='DTEDOCJOBPLANSet']/*[local-name()='JOBPLAN'][1]/*[local-name()='TYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCITEM'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCITEM']/*[local-name()='DTEDOCITEMSet']/*[local-name()='ITEM'][1]/*[local-name()='ITEMSETID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCITEM']/*[local-name()='DTEDOCITEMSet']/*[local-name()='ITEM'][1]/*[local-name()='ITEMID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCITEM']/*[local-name()='DTEDOCITEMSet']/*[local-name()='ITEM'][1]/*[local-name()='ITEMNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCITEM']/*[local-name()='DTEDOCITEMSet']/*[local-name()='ITEM'][1]/*[local-name()='TYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCINVENTORY'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCINVENTORY']/*[local-name()='DTEDOCINVENTORYSet']/*[local-name()='INVENTORY'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCINVENTORY']/*[local-name()='DTEDOCINVENTORYSet']/*[local-name()='INVENTORY'][1]/*[local-name()='INVENTORYID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCINVENTORY']/*[local-name()='DTEDOCINVENTORYSet']/*[local-name()='INVENTORY'][1]/*[local-name()='ITEMNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCINVENTORY']/*[local-name()='DTEDOCINVENTORYSet']/*[local-name()='INVENTORY'][1]/*[local-name()='TYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTEDOCWO'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTEDOCWO']/*[local-name()='DTEDOCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTEDOCWO']/*[local-name()='DTEDOCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WORKORDERID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTEDOCWO']/*[local-name()='DTEDOCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WONUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTEDOCWO']/*[local-name()='DTEDOCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='TYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTE_WOSENTINEL'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTE_WOSENTINEL']/*[local-name()='DTE_WOSENTINELSet']/*[local-name()='WORKORDER'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTE_WOSENTINEL']/*[local-name()='DTE_WOSENTINELSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WONUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTE_WOSENTINEL']/*[local-name()='DTE_WOSENTINELSet']/*[local-name()='WORKORDER'][1]/*[local-name()='DTE_RWPNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTE_WOSENTINEL']/*[local-name()='DTE_WOSENTINELSet']/*[local-name()='WORKORDER'][1]/*[local-name()='STATUS']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="concat('WO',$WorkOrderNO)"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTENUCASST'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTENUCASST']/*[local-name()='DTENUCASSTSet']/*[local-name()='ASSET'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTENUCASST']/*[local-name()='DTENUCASSTSet']/*[local-name()='ASSET'][1]/*[local-name()='ASSETNUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTENUCASST']/*[local-name()='DTENUCASSTSet']/*[local-name()='ASSET'][1]/*[local-name()='ASSETUID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTENUCASST']/*[local-name()='DTENUCASSTSet']/*[local-name()='ASSET'][1]/@action"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTENUCCHGPPR'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTENUCCHGPPR']/*[local-name()='DTENUCCHGPPRSet']/*[local-name()='DTE_CHANGEPAPER'][1]/*[local-name()='LOCATION']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTENUCCHGPPR']/*[local-name()='DTENUCCHGPPRSet']/*[local-name()='DTE_CHANGEPAPER'][1]/*[local-name()='DTE_CHANGEPAPERID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTENUCCHGPPR']/*[local-name()='DTENUCCHGPPRSet']/*[local-name()='DTE_CHANGEPAPER'][1]/*[local-name()='DTE_DESCHGNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTENUCCHGPPR']/*[local-name()='DTENUCCHGPPRSet']/*[local-name()='DTE_CHANGEPAPER'][1]/@action"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTENUCLOC'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTENUCLOC']/*[local-name()='DTENUCLOCSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTENUCLOC']/*[local-name()='DTENUCLOCSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='LOCATION']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTENUCLOC']/*[local-name()='DTENUCLOCSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='LOCATIONSID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTENUCLOC']/*[local-name()='DTENUCLOCSet']/*[local-name()='LOCATIONS'][1]/@action"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTENUCIMPLOC'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTENUCIMPLOC']/*[local-name()='DTENUCIMPLOCSet']/*[local-name()='PLUSIPUNVASSET'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTENUCIMPLOC']/*[local-name()='DTENUCIMPLOCSet']/*[local-name()='PLUSIPUNVASSET'][1]/*[local-name()='ASSOCID']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTENUCIMPLOC']/*[local-name()='DTENUCIMPLOCSet']/*[local-name()='PLUSIPUNVASSET'][1]/*[local-name()='PLUSIPUNVASSETID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTENUCIMPLOC']/*[local-name()='DTENUCIMPLOCSet']/*[local-name()='PLUSIPUNVASSET'][1]/@action"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTENUCWO'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTENUCWO']/*[local-name()='DTENUCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTENUCWO']/*[local-name()='DTENUCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WONUM']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTENUCWO']/*[local-name()='DTENUCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='WORKORDERID']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTENUCWO']/*[local-name()='DTENUCWOSet']/*[local-name()='WORKORDER'][1]/@action"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:when test="$messageType= 'PublishDTENUCPMREF'">
				<xsl:variable name="MessageID" select="/*[local-name()='PublishDTENUCPMREF']/*[local-name()='DTENUCPMREFSet']/*[local-name()='PLUSPMREF'][1]/*[local-name()='SITEID']/text()"/>
				<xsl:variable name="WorkOrderNO" select="/*[local-name()='PublishDTENUCPMREF']/*[local-name()='DTENUCPMREFSet']/*[local-name()='PLUSPMREF'][1]/*[local-name()='REF']/text()"/>
				<xsl:variable name="WorkOrderID" select="/*[local-name()='PublishDTENUCPMREF']/*[local-name()='DTENUCPMREFSet']/*[local-name()='PLUSPMREF'][1]/*[local-name()='PMNUM']/text()"/>
				<xsl:variable name="Type" select="/*[local-name()='PublishDTENUCPMREF']/*[local-name()='DTENUCPMREFSet']/*[local-name()='PLUSPMREF'][1]/*[local-name()='DTE_REFTYPE']/text()"/>
				<xsl:call-template name="set_ILS_Context">
					<xsl:with-param name="MessageID" select="$MessageID"/>
					<xsl:with-param name="OrderID" select="$WorkOrderNO"/>
					<xsl:with-param name="OrderNO" select="$WorkOrderID"/>
					<xsl:with-param name="OrderType" select="$Type"/>
					<xsl:with-param name="MessageType" select="$messageType"/>
					<xsl:with-param name="TopicName" select="concat('PnF/ALM/',$messageType)"/>
				</xsl:call-template>
			</xsl:when>
		</xsl:choose>
	</xsl:template>
	<xsl:template name="set_ILS_Context">
		<xsl:param name="MessageID"/>
		<xsl:param name="OrderID"/>
		<xsl:param name="OrderNO"/>
		<xsl:param name="OrderType"/>
		<xsl:param name="TopicName"/>
		<xsl:param name="MessageType"/>
		<xsl:choose>
			<xsl:when test="$MessageType= 'PublishDTEESRWOREQ'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDZWOSTAT'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDZVERSTAT'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDZLEAD'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCPM'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCASSET'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCSR'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCSAFETYPLAN'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCSERVRECPT'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCMASTERPM'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCLOCATION'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCJOBPLAN'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCITEM'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCINVENTORY'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCWO'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTE_WOSENTINEL'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCLOC'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCASST'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCCHGPPR'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCIMPLOC'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCWO'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCPMREF'">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('ALM',$Delimiter,$OrderType,$Delimiter,$OrderID)"/>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="concat('CRM',$Delimiter,$OrderType,$OrderID)"/>
			</xsl:otherwise>
		</xsl:choose>
		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()"/>
		<dp:set-variable name="'var://context/ServiceLog/LogMsgTimestamp'" value="date:date-time()"/>
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'RECEIVED'"/>
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'ESB'"/>
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')"/>
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))"/>
		<dp:set-variable name="'var://context/ServiceLog/User'" value="' '"/>
		<xsl:choose>
			<xsl:when test="$MessageType= 'PublishDTEESRWOREQ'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEESRWOREQ']/*[local-name()='DTEESRWOREQSet']/*[local-name()='WORKORDER'][1]/*[local-name()='STATUS']"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDZWOSTAT'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDZWOSTAT']/*[local-name()='DTEDZWOSTATSet']/*[local-name()='WORKORDER'][1]/*[local-name()='STATUS']"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDZVERSTAT'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDZVERSTAT']/*[local-name()='DTEDZVERSTATSet']/*[local-name()='PLUSDESTVERSION'][1]/*[local-name()='STATUS']"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDZLEAD'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDZLEAD']/*[local-name()='DTEDZLEADSet']/*[local-name()='WOACTIVITY'][1]/*[local-name()='DTE_TASKTYPE']"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTECRBLEAKSURVY'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTECRBLEAKSURVY']/*[local-name()='DTECRBLEAKSURVYSet']/*[local-name()='DTE_LEAKSURVEY'][1]/@action"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCPM'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCPM']/*[local-name()='DTEDOCPMSet']/*[local-name()='PM'][1]/*[local-name()='STATUS']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCASSET'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCASSET']/*[local-name()='DTEDOCASSETSet']/*[local-name()='ASSET'][1]/*[local-name()='STATUS']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCSR'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCSR']/*[local-name()='DTEDOCSRSet']/*[local-name()='SR'][1]/*[local-name()='STATUS']/@maxvalue"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCSAFETYPLAN'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCSAFETYPLAN']/*[local-name()='DTEDOCSAFETYPLANSet']/*[local-name()='SAFETYPLAN'][1]/*[local-name()='ORGID']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCSERVRECPT'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCSERVRECPT']/*[local-name()='DTEDOCSERVRECPTSet']/*[local-name()='SERVRECTRANS'][1]/*[local-name()='DTE_APPROVED']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCMASTERPM'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCMASTERPM']/*[local-name()='DTEDOCMASTERPMSet']/*[local-name()='MASTERPM'][1]/*[local-name()='TYPE']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCLOCATION'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCLOCATION']/*[local-name()='DTEDOCLOCATIONSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='STATUS']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCJOBPLAN'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCJOBPLAN']/*[local-name()='DTEDOCJOBPLANSet']/*[local-name()='JOBPLAN'][1]/*[local-name()='STATUS']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCITEM'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCITEM']/*[local-name()='DTEDOCITEMSet']/*[local-name()='ITEM'][1]/*[local-name()='TYPE']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCINVENTORY'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCINVENTORY']/*[local-name()='DTEDOCINVENTORYSet']/*[local-name()='INVENTORY'][1]/*[local-name()='LOCATION']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTEDOCWO'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTEDOCWO']/*[local-name()='DTEDOCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='STATUS']/text()"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTE_WOSENTINEL'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTE_WOSENTINEL']/*[local-name()='DTE_WOSENTINELSet']/*[local-name()='WORKORDER'][1]/*[local-name()='LOCATION']/text()"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCASST'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTENUCASST']/*[local-name()='DTENUCASSTSet']/*[local-name()='ASSET'][1]/*[local-name()='STATUS']"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCCHGPPR'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTENUCCHGPPR']/*[local-name()='DTENUCCHGPPRSet']/*[local-name()='DTE_CHANGEPAPER'][1]/*[local-name()='DTE_DES_STATUS']"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCLOC'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTENUCLOC']/*[local-name()='DTENUCLOCSet']/*[local-name()='LOCATIONS'][1]/*[local-name()='STATUS']"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCIMPLOC'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTENUCIMPLOC']/*[local-name()='DTENUCIMPLOCSet']/*[local-name()='PLUSIPUNVASSET'][1]/*[local-name()='LOCATION']"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCWO'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTENUCWO']/*[local-name()='DTENUCWOSet']/*[local-name()='WORKORDER'][1]/*[local-name()='STATUS']"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:when test="$MessageType= 'PublishDTENUCPMREF'">
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTENUCPMREF']/*[local-name()='DTENUCPMREFSet']/*[local-name()='PLUSPMREF'][1]/*[local-name()='PM'][1]/*[local-name()='WORKORDER']/*[local-name()='STATUS']"/>
				<dp:set-variable name="'var://context/ServiceLog/PublishGroup'" value="'EDM'"/>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="/*[local-name()='PublishDTENUCPMREF']/*[local-name()='DTECSWOCOMPSet']/*[local-name()='WORKORDER']/*[local-name()='STATUS']"/>
			</xsl:otherwise>
		</xsl:choose>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="$MessageID"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement3'" value="$OrderNO"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement4'" value="$MessageType"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement5'" value="$TopicName"/>
	</xsl:template>
</xsl:stylesheet>
