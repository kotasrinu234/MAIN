<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp dpconfig dpquery " xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions" xmlns:date="http://exslt.org/dates-and-times" version="1.0">
	<xsl:variable name="Delimiter" select="'_'"/>
	<xsl:template match="/">
		<xsl:variable name="messageType">
			<xsl:value-of select="local-name(/*)"/>
		</xsl:variable>
		<xsl:variable name="mqmdHeader" select="dp:request-header('MQMD')"/>
		<xsl:variable name="mqmdParseheader" select="dp:parse($mqmdHeader)"/>
		<xsl:variable name="Priority">
			<xsl:value-of select="$mqmdParseheader/*[local-name()='MQMD']/*[local-name()='Priority']/text()"/>
		</xsl:variable>
		<xsl:variable name="mqrfh2Header" select="dp:request-header('MQRFH2')"/>
		<xsl:variable name="header" select="dp:parse($mqrfh2Header)"/>
		<dp:set-variable name="'var://context/mq/header'" value="$header"/>
		<xsl:variable name="correlationID">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='CorrelationID']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context1">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context1']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context2">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context2']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context3">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context3']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context4">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context4']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context5">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context5']/text()"/>
		</xsl:variable>
		<xsl:call-template name="set_ILS_Context">
			<xsl:with-param name="Priority" select="$Priority"/>
			<xsl:with-param name="correlationID" select="string($correlationID)"/>
			<xsl:with-param name="Context1" select="string($Context1)"/>
			<xsl:with-param name="Context2" select="string($Context2)"/>
			<xsl:with-param name="Context3" select="string($Context3)"/>
			<xsl:with-param name="Context4" select="string($Context4)"/>
			<xsl:with-param name="Context5" select="string($Context5)"/>
		</xsl:call-template>
	</xsl:template>
	<xsl:template name="set_ILS_Context">
		<xsl:param name="Priority"/>
		<xsl:param name="correlationID"/>
		<xsl:param name="Context1"/>
		<xsl:param name="Context2"/>
		<xsl:param name="Context3"/>
		<xsl:param name="Context4"/>
		<xsl:param name="Context5"/>
		<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="$correlationID"/>
		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()"/>
		<dp:set-variable name="'var://context/ServiceLog/LogMsgTimestamp'" value="date:date-time()"/>
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'PROCESSED'"/>
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'ESB'"/>
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')"/>
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))"/>
		<dp:set-variable name="'var://context/ServiceLog/User'" value="' '"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="$Context1"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="$Context2"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement3'" value="$Context3"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement4'" value="$Context4"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement5'" value="$Context5"/>
		<dp:set-variable name="'var://context/ServiceLog/Priority'" value="$Priority"/>
	</xsl:template>
</xsl:stylesheet>
