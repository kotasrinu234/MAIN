<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpfunc="http://www.datapower.com/extensions/functions" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:func="http://exslt.org/functions" extension-element-prefixes="dp funcÂ dpfunc" exclude-result-prefixes="dp dpfunc func dpconfig" version="1.0">
	<xsl:template match="/">
		<xsl:variable name="RequestMQMD">
			<xsl:value-of select="dp:request-header('MQMD')" disable-output-escaping="yes"/>
		</xsl:variable>
		<xsl:variable name="MQMDStr">
			<MQMD>
				<Format>MQHRF2</Format>
				<Priority>
					<xsl:value-of select="dp:variable('var://context/ServiceLog/Priority')"/>
				</Priority>
			</MQMD>
		</xsl:variable>
		<xsl:variable name="RFH2">
			<MQRFH2>
				<StrucId>RFH</StrucId>
				<Version>2</Version>
				<Encoding>546</Encoding>
				<CodedCharSetId>819</CodedCharSetId>
				<Format>MQSTR</Format>
				<Flags>0</Flags>
				<NameValueCCSID>1208</NameValueCCSID>
				<NameValueData>
					<NameValue>
						<usr>
							<CorrelationID>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/CorrelationId')"/>
							</CorrelationID>
							<MQMsgPriority>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/Priority')"/>
							</MQMsgPriority>
							<Context1>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement1')"/>
							</Context1>
							<Context2>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement2')"/>
							</Context2>
							<Context3>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement3')"/>
							</Context3>
							<Context4>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement4')"/>
							</Context4>
							<Context5>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement5')"/>
							</Context5>
						</usr>
					</NameValue>
				</NameValueData>
			</MQRFH2>
		</xsl:variable>
		<!-- serialize the nodeset for transport -->
		<xsl:variable name="mqmdStr">
			<dp:serialize select="$MQMDStr"/>
		</xsl:variable>
		<xsl:variable name="rfh2Str">
			<dp:serialize select="$RFH2"/>
		</xsl:variable>
		<!-- set the MQMD of the response with new MQMD -->
		<xsl:choose>
			<xsl:when test="dp:responding()=false()">
				<dp:set-request-header name="'MQMD'" value="substring-after($mqmdStr, '?>')"/>
				<dp:set-request-header name="'MQRFH2'" value="substring-after($rfh2Str, '?>')"/>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-response-header name="'MQMD'" value="substring-after($mqmdStr, '?>')"/>
				<dp:set-response-header name="'MQRFH2'" value="substring-after($rfh2Str, '?>')"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
