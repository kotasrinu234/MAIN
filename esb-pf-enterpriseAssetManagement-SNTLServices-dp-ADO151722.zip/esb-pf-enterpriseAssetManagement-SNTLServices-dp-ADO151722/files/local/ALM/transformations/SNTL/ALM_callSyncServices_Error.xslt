<xsl:stylesheet xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions"  xmlns:date="http://exslt.org/dates-and-times" version="1.0" extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp" >
	<xsl:output method="xml"/>
	
	<xsl:template match="/">
	<xsl:choose>
<xsl:when test="contains(dp:variable('var://service/error-message'),'Failed to establish a backside connection')">
<xsl:message dp:type="all" dp:priority="error">SNTL_Pro_001 ErrorMessage <xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>
 
</xsl:when>
 
<xsl:when test="contains(dp:variable('var://service/error-code'),'0x01130006' )">
<xsl:message dp:type="all" dp:priority="error">SNTL_Pro_001 ErrorMessage <xsl:value-of select="dp:variable('var://service/error-message')"/></xsl:message>
</xsl:when>

<xsl:when test="contains(dp:variable('var://service/error-code'),'0x00d30003')">
<xsl:message dp:type="all" dp:priority="error">SNTL_Pro_001 ErrorMessage <xsl:value-of select="'Failed to establish a database connection'"/>
</xsl:message>
</xsl:when>

</xsl:choose>

</xsl:template>
</xsl:stylesheet>