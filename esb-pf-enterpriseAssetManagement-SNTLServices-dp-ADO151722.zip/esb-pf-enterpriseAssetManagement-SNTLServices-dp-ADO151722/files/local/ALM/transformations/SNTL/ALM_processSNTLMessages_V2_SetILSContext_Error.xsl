<xsl:stylesheet xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions" extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp" xmlns:date="http://exslt.org/dates-and-times" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:max="http://www.ibm.com/maximo" version="1.0">
	<xsl:template match="/">
              <!--  <xsl:variable name="inputXMLRef" select="." /> 
                <xsl:variable name="dataSerialized">
                   <dp:serialize select="$inputXMLRef" /> 
                </xsl:variable>-->	
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/ServiceLog/CorrelationId') = '' or not(dp:variable('var://context/ServiceLog/CorrelationId'))">
				<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="dp:generate-uuid()" />  
			</xsl:when>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/ServiceLog/MessageId') = '' or not(dp:variable('var://context/ServiceLog/MessageId'))">
				<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()" />
			</xsl:when>
		</xsl:choose>  
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/ServiceLog/LogMsgTimestamp') = '' or not(dp:variable('var://context/ServiceLog/LogMsgTimestamp'))">
				<dp:set-variable name="'var://context/ServiceLog/LogMsgTimestamp'" value="date:date-time()" />
			</xsl:when>
		</xsl:choose>  
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/ServiceLog/Application') = '' or not(dp:variable('var://context/ServiceLog/Application'))">
				<dp:set-variable name="'var://context/ServiceLog/Application'" value="'ESB'" />
			</xsl:when>
		</xsl:choose>  
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/ServiceLog/ServiceName') = '' or not(dp:variable('var://context/ServiceLog/ServiceName'))">
				<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')" />
			</xsl:when>
		</xsl:choose>  
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/ServiceLog/System') = '' or not(dp:variable('var://context/ServiceLog/System'))">
				<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))" />
			</xsl:when>
		</xsl:choose>    
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'ERROR'" /> 
		<dp:set-variable name="'var://context/ServiceLog/ContextElement5'" value="dp:variable('var://service/error-message')" /> 
		<!--<dp:set-variable name="'var://context/ServiceLog/RawData'" value="$dataSerialized" />-->		
	</xsl:template>
</xsl:stylesheet>