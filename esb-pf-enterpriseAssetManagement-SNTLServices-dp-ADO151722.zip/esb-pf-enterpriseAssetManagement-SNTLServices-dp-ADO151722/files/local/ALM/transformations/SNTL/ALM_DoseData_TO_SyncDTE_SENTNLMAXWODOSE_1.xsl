<?xml version="1.0" encoding="UTF-8"?>
<!-- 
	Name: ALM_DoseData_TO_SyncDTE_SENTNLMAXWODOSE.xsl
	
	Description: Constructing xml for Maximo from the input DoseData given by SNTL.
	
	Change History:
	- Initial version			Anil Damodara	   2018/02/12
   
 

  -->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" version="1.0" exclude-result-prefixes="dp xsl dpconfig ser" extension-element-prefixes="dp dpconfig" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml"/>
	<xsl:template match="/*[local-name()='DoseData']">
		<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:max="http://www.ibm.com/maximo">
			<soapenv:Header/>
			<soapenv:Body>
				<max:SyncDTE_SENTNLMAXWODOSE>
					<max:DTE_SENTNLMAXWODOSESet>
						<!-- <max:WORKORDER action="Change">
							<max:WONUM>
								<xsl:value-of select="./*[local-name()='WO_NUMBER']"/>
							</max:WONUM>
							<max:DTE_WORKORDER action="Change">
								<max:DTE_TOTALACTDOSE>
									<xsl:value-of select="./*[local-name()='DOSE']"/>
								</max:DTE_TOTALACTDOSE>
							</max:DTE_WORKORDER>
						</max:WORKORDER> -->
						<max:WORKORDER action="Change">
							<!-- <max:MAXINTERRORMSG>
								<xsl:value-of select="./*[local-name()='MAXINTERRORMSG']"/>
							</max:MAXINTERRORMSG>
							<max:CHANGEBY>
								<xsl:value-of select="./*[local-name()='CHANGEBY']"/>
							</max:CHANGEBY> -->
							<max:DTE_TOTALACTDOSE changed="true">
								<xsl:value-of select="./*[local-name()='DOSE']"/>
							</max:DTE_TOTALACTDOSE>
							<!-- <max:SITEID>
								<xsl:value-of select="./*[local-name()='SITEID']"/>
							</max:SITEID> -->
							<max:WONUM changed="true">
								<xsl:value-of select="./*[local-name()='WO_NUMBER']"/>
							</max:WONUM>
						</max:WORKORDER>
					</max:DTE_SENTNLMAXWODOSESet>
				</max:SyncDTE_SENTNLMAXWODOSE>
			</soapenv:Body>
		</soapenv:Envelope>
	</xsl:template>
</xsl:stylesheet>
