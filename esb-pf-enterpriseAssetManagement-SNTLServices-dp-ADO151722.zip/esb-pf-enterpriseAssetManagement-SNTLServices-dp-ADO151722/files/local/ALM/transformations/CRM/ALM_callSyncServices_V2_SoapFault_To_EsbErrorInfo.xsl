<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions" extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp" xmlns:date="http://exslt.org/dates-and-times" version="1.0">
	<xsl:template match="/">
		<xsl:variable name="inputXMLRef" select="."/>
		<xsl:variable name="dataSerialized">
			<dp:serialize select="$inputXMLRef"/>
		</xsl:variable>
		<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
			<soapenv:Header/>
			<soapenv:Body>
				<EsbErrorInfo>
					<msgStatus>ALM_ERROR</msgStatus>
					<statusDetails>
						<statusDetail>
							<errorNo>
								<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/*[local-name()='faultcode']"/>
							</errorNo>
							<errorText>
								<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/*[local-name()='faultstring']"/>
							</errorText>
						</statusDetail>
					</statusDetails>
				</EsbErrorInfo>
			</soapenv:Body>
		</soapenv:Envelope>
		<dp:set-variable name="'var://context/ServiceLog/RawData'" value="$dataSerialized"/>
	</xsl:template>
</xsl:stylesheet>
