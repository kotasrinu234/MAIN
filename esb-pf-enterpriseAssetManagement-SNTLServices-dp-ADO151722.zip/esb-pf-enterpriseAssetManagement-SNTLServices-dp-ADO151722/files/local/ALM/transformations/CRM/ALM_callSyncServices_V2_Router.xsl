<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp dpconfig dpquery " xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions" xmlns:date="http://exslt.org/dates-and-times" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:max="http://www.ibm.com/maximo" version="1.0">
	<xsl:output method="xml"/>
	<xsl:param name="dpconfig:CreateDTECSSR" select="'UNKNOWN'"/>
	<xsl:param name="dpconfig:SyncSENTNLMAXWODOSE" select="'UNKNOWN'"/>
	<xsl:template match="/">
		<xsl:variable name="inputXMLRef" select="."/>
		<xsl:variable name="dataSerialized">
			<dp:serialize select="$inputXMLRef"/>
		</xsl:variable>
		<xsl:variable name="messageType">
			<xsl:value-of select="local-name(/soapenv:Envelope/soapenv:Body/*)"/>
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="$messageType='CreateDTECSSR'">
				<dp:set-variable name="'var://service/routing-url'" value="$dpconfig:CreateDTECSSR"/>
			</xsl:when>
			<xsl:when test="$messageType='SyncDTE_SENTNLMAXWODOSE'">
				<dp:set-variable name="'var://service/routing-url'" value="$dpconfig:SyncSENTNLMAXWODOSE"/>
			</xsl:when>
			<xsl:otherwise>
				<dp:reject>Not a Valid MessageType</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:variable name="mqmdHeader" select="dp:request-header('MQMD')"/>
		<xsl:variable name="mqmdParseheader" select="dp:parse($mqmdHeader)"/>
		<xsl:variable name="Priority">
			<xsl:value-of select="$mqmdParseheader/*[local-name()='MQMD']/*[local-name()='Priority']/text()"/>
		</xsl:variable>
		<xsl:variable name="mqrfh2Header" select="dp:request-header('MQRFH2')"/>
		<xsl:variable name="header" select="dp:parse($mqrfh2Header)"/>
		<xsl:variable name="correlationID">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='CorrelationID']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context1">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context1']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context2">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context2']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context3">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context3']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context4">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context4']/text()"/>
		</xsl:variable>
		<xsl:variable name="Context5">
			<xsl:value-of select="$header/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='Context5']/text()"/>
		</xsl:variable>
		<dp:remove-http-request-header name="MQMD"/>
		<dp:remove-http-request-header name="MQRFH2"/>
		<dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="string($correlationID)"/>
		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()"/>
		<dp:set-variable name="'var://context/ServiceLog/LogMsgTimestamp'" value="date:date-time()"/>
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'ESB'"/>
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')"/>
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))"/>
		<dp:set-variable name="'var://context/ServiceLog/User'" value="' '"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="string($Context1)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="string($Context2)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement3'" value="string($Context3)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement4'" value="string($Context4)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement5'" value="string($Context5)"/>
		<dp:set-variable name="'var://context/ServiceLog/Priority'" value="$Priority"/>
		<dp:set-variable name="'var://context/ServiceLog/messageType'" value="$messageType"/>
		<dp:set-variable name="'var://context/ServiceLog/InputData'" value="$dataSerialized"/>
	</xsl:template>
</xsl:stylesheet>
