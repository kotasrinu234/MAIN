<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp dpconfig dpquery " xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions" xmlns:date="http://exslt.org/dates-and-times" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:max="http://www.ibm.com/maximo" version="1.0">
	<xsl:output method="xml"/>
	<xsl:template match="/">
		<xsl:copy-of select="dp:variable('var://context/ServiceLog/InputData')"/>
		<dp:reject>Received Invalid Response, Re-processing InputData request Msg</dp:reject>
	</xsl:template>
</xsl:stylesheet>
