<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:dp="http://www.datapower.com/extensions" xmlns:dpquery="http://www.datapower.com/param/query" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dyn="http://exslt.org/dynamic" xmlns:regexp="http://exslt.org/regular-expressions" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp" version="1.0">
	<xsl:output method="xml"/>
	<xsl:param name="dpconfig:ALM_PublishGroup" select="'UNKNOWN'"/>
	<xsl:param name="dpconfig:ALM_PublishTopicString" select="'UNKNOWN'"/>
	<xsl:template match="/">
		<xsl:variable name="inputMsgType">
			<xsl:value-of select="local-name(/soapenv:Envelope/soapenv:Body/*)"/>
		</xsl:variable>
		<xsl:variable name="messageType">
			<xsl:value-of select="dp:variable('var://context/ServiceLog/messageType')"/>
		</xsl:variable>
		<!-- Set topic string from param-->
		<xsl:variable name="PublishTopicString">
			<xsl:choose>
				<xsl:when test="$inputMsgType='EsbErrorInfo'">
					<xsl:value-of select="concat('PnF/ALM/', $inputMsgType, '/', $messageType)"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="concat('PnF/ALM/', $inputMsgType)"/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="RequestMQMD">
			<xsl:value-of select="dp:request-header('MQMD')" disable-output-escaping="yes"/>
		</xsl:variable>
		<xsl:variable name="MQMDStr">
			<MQMD>
				<Format>MQHRF2</Format>
				<Priority>
					<xsl:value-of select="dp:variable('var://context/ServiceLog/Priority')"/>
				</Priority>
			</MQMD>
		</xsl:variable>
		<xsl:variable name="RFH2">
			<MQRFH2>
				<StrucId>RFH</StrucId>
				<Version>2</Version>
				<Encoding>546</Encoding>
				<CodedCharSetId>819</CodedCharSetId>
				<Format>MQSTR</Format>
				<Flags>0</Flags>
				<NameValueCCSID>1208</NameValueCCSID>
				<NameValueData>
					<NameValue>
						<usr>
							<CorrelationID>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/CorrelationId')"/>
							</CorrelationID>
							<MQMsgPriority>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/Priority')"/>
							</MQMsgPriority>
							<Context1>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement1')"/>
							</Context1>
							<Context2>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement2')"/>
							</Context2>
							<Context3>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement3')"/>
							</Context3>
							<Context4>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement4')"/>
							</Context4>
							<Context5>
								<xsl:value-of select="dp:variable('var://context/ServiceLog/ContextElement5')"/>
							</Context5>
						</usr>
					</NameValue>
				</NameValueData>
			</MQRFH2>
		</xsl:variable>
		<xsl:variable name="MQMDStr2">
			<dp:serialize select="$MQMDStr" omit-xml-decl="yes"/>
		</xsl:variable>
		<xsl:variable name="rfh2Str">
			<dp:serialize select="$RFH2" omit-xml-decl="yes"/>
		</xsl:variable>
		<xsl:variable name="headers">
			<header name="MQMD">
				<xsl:copy-of select="$MQMDStr2"/>
			</header>
			<header name="MQRFH2">
				<xsl:copy-of select="$rfh2Str"/>
			</header>
		</xsl:variable>
		<xsl:variable name="dpurl" select="concat('dpmq://',$dpconfig:ALM_PublishGroup,'/?PublishTopicString=',$PublishTopicString)"/>
		<xsl:variable name="result">
			<dp:url-open target="{$dpurl}" response="responsecode-ignore" http-headers="$headers">
				<xsl:copy-of select="/"/>
			</dp:url-open>
		</xsl:variable>
	</xsl:template>
</xsl:stylesheet>
