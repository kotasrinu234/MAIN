var hm = require('header-metadata');
var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
var urlopen = require('urlopen');
var workGroup_OH = session.parameters.workGroup_OH;
var workGroup_UG = session.parameters.workGroup_UG;
var OH = ctx.setVariable("workGroup_OH", workGroup_OH);
var UG = ctx.setVariable("workGroup_UG", workGroup_UG);

var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(error, incomingdata) {
	if (error) {
		session.reject("Invalid Request Json");
		//logger.error("Invalid Request Json");
		//throw error;
	} else {
		var rosterDate = incomingdata.rosterDate;
		var currentDate = new Date().toISOString();
		if (rosterDate > currentDate) {
			ctx.setVar("errorStatus", "400");
			ctx.setVar("errorDescription", "Roster ignored and will not be published as the roster is of future date.");
			var rosterError = {
				"errorCode": "400",
				"errorDescription": "Roster ignored and will not be published as the roster is of future date"
			};
			logger.error(JSON.stringify(rosterError));
			session.reject(JSON.stringify(rosterError));
		}
		else {
			ctx.setVariable("incomingdata", incomingdata);
			var shiftsCrewMemberArray = [];
			var crewLeadarray = [];
			var shiftLst = incomingdata.shifts;
			if ((shiftLst == null || shiftLst == '' || shiftLst == undefined)) {
				session.reject("Unable to find Shift block from Input");
				//logger.error("cms_002:Unable to find Shift block from Input");
			} else {
				var shiftLst = incomingdata.shifts.length;
				for (var i = 0; i < shiftLst; i++) {
					var crewsLength = incomingdata.shifts[i].crews.length;
					for (var j = 0; j < crewsLength; j++) {
						var crewLeader = incomingdata.shifts[i].crews[j].crewLeader.length;
						var crewLeaderCrewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
						if (crewLeaderCrewId != undefined) {
							ctx.setVariable("shiftCrewLeaderCrewId", crewLeaderCrewId);
						} else {
							session.reject("crewId not found from ShiftcrewLeader block");
							logger.error("cms_003:crewId not found from ShiftcrewLeader block");
						}
						var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
						for (var k = 0; k < crewMembersLength; k++) {
							var shiftCrewMemberCrewId = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
							if (shiftCrewMemberCrewId != undefined) {
								shiftsCrewMemberArray.push(shiftCrewMemberCrewId);
								ctx.setVariable("shiftCrewMemberCrewId", shiftsCrewMemberArray);
							} else {
								session.reject("crewId not found from Shift CrewMember block");
								logger.error("cms_004:crewId not found from Shift CrewMember block");
							}
						}
					}
				}
			}

			var unAssignCrewIDArray = [];
			var unsasLst = incomingdata.unassigned;
			if ((unsasLst == null || unsasLst == '' || unsasLst == undefined)) {
				//session.reject("Unable to find Unassignedblock from input request");
				logger.debug("cms_005:Unable to find Unassignedblock from input request");
			} else {
				var unAssignLst = incomingdata.unassigned.length;
				for (var i = 0; i < unAssignLst; i++) {
					var unAssignCrewId = incomingdata.unassigned[i].crewId;
					if (unAssignCrewId != undefined) {
						unAssignCrewIDArray.push(unAssignCrewId);
						//ctx.setVariable("unAssignEmpIdArray", unAssignEmpIdArray);
					} else {
						//session.reject("empId not found from Unassignedblock");
						logger.debug("cms_006:crewId not found from Unassignedblock");
					}

				}
				ctx.setVariable("unAssignCrewIDArray", unAssignCrewIDArray);
			}

			var suprVsrCrewIDArray = [];
			var suprVsrLst = incomingdata.supervisors;
			if ((suprVsrLst == null || suprVsrLst == '' || suprVsrLst == undefined)) {
				//session.reject("Unable to find supervisorsblock from input request");
				logger.debug("cms_007:Unable to find supervisorsblock from input request");
			} else {
				var suprVisorLst = incomingdata.supervisors.length;
				for (var i = 0; i < suprVisorLst; i++) {
					var suprVsrCrewId = incomingdata.supervisors[i].crewId;
					if (suprVsrCrewId != undefined) {
						suprVsrCrewIDArray.push(suprVsrCrewId);
					} else {
						logger.debug("cms_008:crewId not found from superVisorsblock");
					}
					ctx.setVariable("suprVsrCrewIDArray", suprVsrCrewIDArray);
				}
			}

			var workGroup = incomingdata.workGroup;
			if (workGroup == undefined || workGroup == null || workGroup == '') {
				session.reject("workGroup cannot be empty in incoming request");
				logger.error("cms_009:workGroup cannot be empty in incoming request");
			}
			else if (workGroup != undefined || workGroup != null || workGroup != '') {
				if (workGroup === workGroup_OH) {
					ctx.setVariable("workGroup", workGroup_OH);
				} else if (workGroup === workGroup_UG) {
					ctx.setVariable("workGroup", workGroup_UG);
				} else {
					session.reject("workGroup can be either OH or UG");
					logger.error("cms_010:workGroup can be either OH or UG");
				}
			}

			var serviceCenter = incomingdata.serviceCenter;
			if (serviceCenter == null || serviceCenter == '' || serviceCenter == undefined) {
				session.reject("serviceCenter cannot be empty in incoming request");
				logger.error("cms_011:serviceCenter cannot be empty in incoming request");
			} else {
				ctx.setVariable("serviceCenter", serviceCenter);
			}

			var rosterId = incomingdata.rosterId;
			if (rosterId == null || rosterId == '' || rosterId == undefined) {
				session.reject("rosterId cannot be empty in incoming request");
				logger.error("cms_012:rosterId cannot be empty in incoming request");
			} else {
				ctx.setVariable("rosterId", rosterId);
			}

			var rosterDate = incomingdata.rosterDate;
			if (rosterDate == null || rosterDate == '' || rosterDate == undefined) {
				session.reject("rosterDate cannot be empty in incoming request");
				logger.error("cms_013:rosterDate cannot be empty in incoming request");
			} else {
				ctx.setVariable("rosterDate", rosterDate);
			}

			var rosterNotes = incomingdata.rosterNotes;
			if (rosterNotes == null || rosterNotes == '' || rosterNotes == undefined) {
				//session.reject("rosterNotes cannot be empty in incoming request");
				logger.debug("rosterNotes cannot be empty in incoming request");
			} else {
				ctx.setVariable("rosterNotes", rosterNotes);
			}

			var createdTimestamp = incomingdata.createdTimestamp;
			if (createdTimestamp == null || createdTimestamp == '' || createdTimestamp == undefined) {
				session.reject("createdTimestamp cannot be empty in incoming request");
				logger.error("cms_014:createdTimestamp cannot be empty in incoming request");
			}
			else {
				ctx.setVariable("createdTimestamp", createdTimestamp);
			}
		}
	}
});
