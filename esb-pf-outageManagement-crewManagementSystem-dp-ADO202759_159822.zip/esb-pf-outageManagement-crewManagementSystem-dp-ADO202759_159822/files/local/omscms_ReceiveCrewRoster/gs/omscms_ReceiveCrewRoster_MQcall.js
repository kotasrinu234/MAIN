//js is used to push message to standalone queue 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
	var ctx = session.name("omscms") || session.createContext("omscms");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var StandaloneMQurl = session.parameters.StandaloneMQurl;
	var incomingdataframed = {}
	incomingdataframed = incomingdata;
	ctx.setVariable("ExitDestination", StandaloneMQurl)
	var corid = ctx.getVariable("correlationID");
	incomingdataframed.messageID = corid ;
	var PusingToQueue = {
		target: StandaloneMQurl,
		data: incomingdataframed
	};
	
	var info = " TargetURL :" + StandaloneMQurl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(incomingdata) + ". ";
	try {
		urlopen.open(PusingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var ctx = session.name("omscms") || session.createContext("omscms");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(" cms_002 error while keeping RestoreVerify omsapijob_RestoreVerify_GetRequest message to queue is " + error);
				var errorinfo = "error while keeping  message to queue , details are : " + info + "; error info :" + "Error returned mq call " + error
				ctx.setVariable("errormessage", errorinfo);
				session.reject(" error while keeping omsapijob_RestoreVerify_GetRequest message to queue is " + error);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							var errorinfo = "error while keeping message to queue , details are : " + info + "; error info :" + "Error returned mq call " + readError
							ctx.setVariable("errormessage", errorinfo);
							session.reject("cms_002 error while keeping message to queue is " + error);
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var ctx = session.name("omscms") || session.createContext("omscms");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(" cms_002 response code for mq connection urlopen.open error [MQRC=" + mqrc + "]");
					var errorinfo = "error while keeping message   to queue , details are : " + info + "; error info :" + "Error returned mq call " + mqrc
					ctx.setVariable("errormessage", errorinfo);
					session.reject(" response code for mq connection urlopen.open error [MQRC=" + mqrc + "]");

				}
			}
		});
	} catch (err) {
		var errorinfo = "error while keeping message   to queue , details are : " + info + "; error info :" + "Error returned mq call " + err;
		ctx.setVariable("errormessage", errorinfo);
		session.reject('** Mqurlopen.open error [MQRC=' + err + ']');
	}
});
