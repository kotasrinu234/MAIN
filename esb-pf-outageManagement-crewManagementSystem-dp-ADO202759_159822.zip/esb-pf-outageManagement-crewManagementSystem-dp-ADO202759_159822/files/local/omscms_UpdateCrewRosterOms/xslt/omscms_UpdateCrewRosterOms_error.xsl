<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">
			<xsl:variable name="TransactionID">
				<xsl:copy-of select="dp:variable('var://service/global-transaction-id')" />
			</xsl:variable>
			<xsl:variable name="errorMessage" select="dp:variable('var://service/error-message')"/>
			<xsl:choose>
					<xsl:when test="contains(dp:variable('var://service/error-code'),'0x0213000e' ) or contains(dp:variable('var://service/error-code'),'0x00d30003' ) or contains(dp:variable('var://service/error-code'),'0x02130008' ) or contains(dp:variable('var://service/error-code'),'0x01130006' )"> 
						<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$errorMessage"/>
					</xsl:when>
					<xsl:when test="contains(dp:variable('var://service/error-code'),'0x00230001' )">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Request'" />
					</xsl:when>
					<xsl:when test="contains(dp:variable('var://context/pdss/schemacheck'),'schema failed' )">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Request'" />
					</xsl:when>
					<xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'401'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'" />
					</xsl:when>
					<xsl:when test="contains(dp:variable('var://context/pdss/mqconnection'),'Forbidden')"> 
						<dp:set-variable name="'var://service/error-protocol-response'" value="'502'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Gateway'" />
					</xsl:when>
					<xsl:otherwise>
						<dp:set-variable name="'var://service/error-protocol-response'" value="'500'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Interval Server Error (General Error)'" />
					</xsl:otherwise>
			</xsl:choose>		
	</xsl:template>
</xsl:stylesheet>
