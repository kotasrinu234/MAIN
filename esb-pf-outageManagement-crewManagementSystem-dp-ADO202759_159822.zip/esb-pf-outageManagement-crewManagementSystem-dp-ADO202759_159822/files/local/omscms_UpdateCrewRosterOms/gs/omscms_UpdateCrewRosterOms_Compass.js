var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');

var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");

var compassURL = session.parameters.compassURL;
var compassToken = session.parameters.compassToken;
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.osiApiToken;
var description = session.parameters.compassPositiveDescription;
var description2 = session.parameters.compassNegativeDescription;
var retry = ctx.getVar("retry");

var notFoundEmpUserIds = [];
var successEmpUserIds = [];
var __successSet = Object.create(null);


var successDetails = Object.create(null);
var successPayloads = Object.create(null);
var notFoundDetails = Object.create(null);
var notFoundPayloads = Object.create(null);

var pendingCompassLookups = 0;

function addNotFoundOnce(empUserId) {
    if (empUserId && notFoundEmpUserIds.indexOf(empUserId) === -1) {
        notFoundEmpUserIds.push(empUserId);
    }
}

function logEmpToILS(empUserId, outcome, payload, detail) {
    try {
        if (empUserId == null || empUserId === '') return;

        if (outcome === 'FOUND') {
            if (!__successSet[empUserId]) {
                __successSet[empUserId] = true;
                successEmpUserIds.push(String(empUserId));
            }
            if (detail !== undefined) successDetails[empUserId] = detail;
            if (payload !== undefined) successPayloads[empUserId] = payload;

        } else if (outcome === 'NOT_FOUND') {
            addNotFoundOnce(String(empUserId));
            if (detail !== undefined) notFoundDetails[empUserId] = detail;
            if (payload !== undefined) notFoundPayloads[empUserId] = payload;

        } else {
            // 'ERROR' or 'NON_200' -> no batching by new requirement
        }
    } catch (e) {
        logger.error('Batch collector failed for empUserId=' + empUserId + ' | ' + JSON.stringify(e));
    }
}

function finalizeCompassResults() {
    try {

        var listNF = notFoundEmpUserIds.join(",");
        ctx.setVariable("CompassEmpNotFound", listNF);
        if (notFoundEmpUserIds.length > 0) {
            logger.error(
                "cms_021:Employee Ids not found in Compass | count=" + notFoundEmpUserIds.length +
                " | empUserIds=" + listNF
            );
        }

        var successJson = JSON.stringify(successEmpUserIds);
        var notFoundJson = JSON.stringify(notFoundEmpUserIds);
        var successDetail = description;
        var notFoundDetail = description2;

        function callBatchStepExit(batchType, idsJson, detailText, done) {
            try {
                ILSctx.setVariable('ILS.BatchType', batchType);
                ILSctx.setVariable('EmpUserId', idsJson);
                ILSctx.setVariable('detail', String(detailText));
                ms.callRule('omscms_UpdateCrewRosterOms_PP_ILSStepExit_Rule', null, null, function(error) {
                    if (error) {
                        logger.error('Batch step-exit error [' + batchType + '] | ' + JSON.stringify(error));
                    }
                    done && done();
                });
            } catch (e) {
                logger.error('Batch step-exit threw [' + batchType + '] | ' + JSON.stringify(e));
                done && done();
            }
        }

        if (successEmpUserIds.length > 0) {
            callBatchStepExit('SUCCESS', successJson, successDetail, function() {
                if (notFoundEmpUserIds.length > 0) {
                    callBatchStepExit('NOT_FOUND', notFoundJson, notFoundDetail, function() {});
                }
            });
        } else if (notFoundEmpUserIds.length > 0) {
            callBatchStepExit('NOT_FOUND', notFoundJson, notFoundDetail, function() {});
        }
    } catch (e) {
        logger.error('finalizeCompassResults failed | ' + JSON.stringify(e));
    }
}

function decCompass() {
    pendingCompassLookups--;
    if (pendingCompassLookups === 0) {
        finalizeCompassResults();
    }
}

function countCompassLookups(data) {
    var n = 0;
    if (data && Array.isArray(data.shifts)) {
        for (var i = 0;i < data.shifts.length;i++) {
            var crews = Array.isArray(data.shifts[i].crews) ? data.shifts[i].crews : [];
            for (var j = 0;j < crews.length;j++) {
                var cm = Array.isArray(crews[j].crewMembers) ? crews[j].crewMembers : [];
                n += cm.length; // members
                if (crews[j].crewLeader && crews[j].crewLeader.empUserId) n += 1; // leader
            }
        }
    }
    if (data && Array.isArray(data.unassigned)) n += data.unassigned.length;
    if (data && Array.isArray(data.supervisors)) n += data.supervisors.length;
    return n;
}


var logger = console.options({
    'category': 'all'
});

session.input.readAsJSON(function(error, incomingdata) {
    if (error) {
        logger.error("Connection Error");
        throw error;
    } else {
        if (retry == "yes") {
            session.output.write(incomingdata);
        }
        else {
            pendingCompassLookups = countCompassLookups(incomingdata);
            if (pendingCompassLookups === 0) {
                finalizeCompassResults();
            }

            var ShiftLst = incomingdata.shifts;
            if (ShiftLst === null || ShiftLst === '' || ShiftLst === undefined) {
                logger.error("Unable to find empList from Shiftblock");
            } else {
                var ShiftLength = incomingdata.shifts.length;
                for (var i = 0;i < ShiftLength;i++) {
                    var crewsLength = incomingdata.shifts[i].crews.length;
                    for (var j = 0;j < crewsLength;j++) {
                        var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
                        for (var k = 0;k < crewMembersLength;k++) {
                            var empUserIdCrewMember = incomingdata.shifts[i].crews[j].crewMembers[k].empUserId;
                            var shiftCrewMemberCrewId = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
                            var getShiftCrewMemberCompassUrl = compassURL + "?filter=userName%20eq%20%22" + empUserIdCrewMember + "%22";
                            getShiftCrewMemberCompassCall(getShiftCrewMemberCompassUrl, 'GET', '', shiftCrewMemberCrewId, empUserIdCrewMember);
                        }
                        var shiftCrewLeaderCrewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
                        var empUserIdCrewLeader = incomingdata.shifts[i].crews[j].crewLeader.empUserId;
                        var getShiftCrewCalleaderCompassUrl = compassURL + "?filter=userName%20eq%20%22" + empUserIdCrewLeader + "%22";
                        getShiftCrewLeaderCompassCall(getShiftCrewCalleaderCompassUrl, 'GET', '', shiftCrewLeaderCrewId, empUserIdCrewLeader);

                    }
                }
            }
            //End: Check If Shift block is exist or not	
            //Start : Check If UnAssign block is exist or not
            var unsasLst = incomingdata.unassigned;
            if (unsasLst === null || unsasLst === '' || unsasLst === undefined) {
                logger.debug("Unable to find crewList from Unassignedblock");
            } else {
                var unsasLstLen = incomingdata.unassigned.length;
                for (var i = 0;i < unsasLstLen;i++) {
                    // Make GET call for each unassignedEmpId from UnAssigned block :GET:/api/v1/ServiceType/Electric/Crew/{id}
                    var unAssignCrewId = incomingdata.unassigned[i].crewId;
                    var empUserIdUnassigned = incomingdata.unassigned[i].empUserId;
                    var getUnAssignCompassUrl = compassURL + "?filter=userName%20eq%20%22" + empUserIdUnassigned + "%22";
                    getUnAssignCompassCall(getUnAssignCompassUrl, 'GET', '', unAssignCrewId, empUserIdUnassigned);
                }
            }
            //End: Check If UnAssign block is exist or not


            //Start: Check If supervisors block is exist or not
            var supervisorsLst = incomingdata.supervisors;
            if (supervisorsLst === null || supervisorsLst === '' || supervisorsLst === undefined) {
                logger.debug("Unable to find crewList from supervisorsblock");
            } else {
                var supervisorsLstLen = incomingdata.supervisors.length;
                for (var i = 0;i < supervisorsLstLen;i++) {
                    // Make GET call for each supervisorEmpId from supervisors block :GET:/api/v1/ServiceType/Electric/Crew/{id}
                    var supervisorsCrewId = incomingdata.supervisors[i].crewId;
                    var empUserIdSupervisors = incomingdata.supervisors[i].empUserId;
                    var getSupervisorsCompassUrl = compassURL + "?filter=userName%20eq%20%22" + empUserIdSupervisors + "%22";
                    getSupervisorCompassCall(getSupervisorsCompassUrl, 'GET', '', supervisorsCrewId, empUserIdSupervisors);

                }
            }
            //End: Check If supervisors block is exist or not


            function getShiftCrewMemberCompassCall(url, method, payload, shiftCrewMemberCrewId, empUserIdCrewMember) {
                var getShiftCrewMemberAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': compassToken
                    }
                };
                var info = " TargetURL: " + getShiftCrewMemberAPI.target + "; Method: " + getShiftCrewMemberAPI.method + ". ";
                urlopen.open(getShiftCrewMemberAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        // ctx.setVariable("retry", 'yes');
                        var errorinfo = "urlopen connect error with getShiftCrewMemberCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        ILSctx.setVariable('CompassExitStatus', '500');
                        ILSctx.setVariable('CompassExitDescription', errorinfo);
                        logger.error("cms_022:urlopen connect error with getShiftCrewMemberCompassAPI" + JSON.stringify(error));
                        var ErrorTxt = "urlopen connect error with getShiftCrewMemberCompassAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                        logEmpToILS(empUserIdCrewMember, 'ERROR', 'network/connect');
                        decCompass();
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to getShiftCrewMemberCompassAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to getShiftCrewMemberCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    session.reject("failure in putting message to getShiftCrewMemberCompassAPI");
                                    logEmpToILS(empUserIdCrewMember, 'ERROR', 'readAsJSON');
                                } else {
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ILSctx.setVariable('CompassExitStatus', '0');
                                    hm.response.statusCode = responseStatusCode;
                                    if (responseData.totalResults > 0) {
                                        var internalid = responseData.Resources[0].id;
                                        ctx.setVariable("responseCompass", responseData);
                                        ctx.setVariable("compassid", internalid);
                                        var payload = {};
                                        payload.externalMemberUserIDs = [internalid];
                                        ctx.setVariable("compasspayload", payload);
                                        var getShiftCrewMemberUrl = omsExternalURL + 'Crew/' + shiftCrewMemberCrewId;
                                        logEmpToILS(empUserIdCrewMember, 'FOUND', responseData, description);
                                        getShiftCrewMemberCall(getShiftCrewMemberUrl, 'GET', payload, shiftCrewMemberCrewId);

                                    }
                                    else {
                                        // logger.error("No internal id found for this Emp User id:" + empUserIdCrewMember + " in the Compass System");
                                        logEmpToILS(empUserIdCrewMember, 'NOT_FOUND', responseData, description2);
                                        addNotFoundOnce(empUserIdCrewMember);
                                    }
                                    decCompass();
                                }
                            });
                        }
                        else if (responseStatusCode == 401) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    var errorinfo = "Not Found Error response received from Compass " + info + "; error info :" + JSON.stringify(error);
                                    ilsctx.setVariable('exitStatus', responseStatusCode);
                                    ilsctx.setVariable('ExitDescription', errorinfo)
                                    logger.error(errorinfo);
                                    session.reject(errorinfo);
                                } else {
                                    var errorinfo = "cms_023: Authentication Failure received from Compass" + info + "; error info :" + JSON.stringify(error);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ILSctx.setVariable('CompassExitStatus', '500');
                                    ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    logger.error("cms_022:Authentication Failure received from Compass" + JSON.stringify(error));
                                    var ErrorTxt = "Authentication Failure received from Compass ";
                                    ctx.setVariable("ErrorTxt", ErrorTxt);
                                    logEmpToILS(empUserIdCrewMember, 'NON_200', 'status=' + responseStatusCode);
                                    decCompass();
                                }
                            });
                        }
                        else {
                            var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                            // ctx.setVariable("retry", 'yes');
                            var errorinfo = "urlopen connect error with getShiftCrewMemberCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                            ILSctx.setVariable('CompassExitStatus', '500');
                            ILSctx.setVariable('CompassExitDescription', errorinfo);
                            logger.error("cms_022:urlopen connect error with getShiftCrewMemberCompassAPI" + JSON.stringify(error));
                            var ErrorTxt = "urlopen connect error with getShiftCrewMemberCompassAPI";
                            ctx.setVariable("ErrorTxt", ErrorTxt);
                            logEmpToILS(empUserIdCrewMember, 'NON_200', 'status=' + responseStatusCode);
                            decCompass();
                        }
                    }

                });
            }

            function getShiftCrewLeaderCompassCall(url, method, payload, shiftCrewLeaderCrewId, empUserIdCrewLeader) {
                var getShiftCrewLeaderAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': compassToken
                    }
                };
                var info = " TargetURL: " + getShiftCrewLeaderAPI.target + "; Method: " + getShiftCrewLeaderAPI.method + ". ";
                urlopen.open(getShiftCrewLeaderAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        // ctx.setVariable("retry", 'yes');
                        logger.error("cms_022:urlopen connect error with getShiftCrewLeaderCompassAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with getShiftCrewLeaderCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        ILSctx.setVariable('CompassExitStatus', '500');
                        ILSctx.setVariable('CompassExitDescription', errorinfo);
                        var ErrorTxt = "urlopen connect error with getShiftCrewLeaderCompassAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                        logEmpToILS(empUserIdCrewLeader, 'ERROR', 'network/connect');
                        decCompass();
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to getShiftCrewLeaderCompassAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to getShiftCrewLeaderCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    logEmpToILS(empUserIdCrewLeader, 'ERROR', 'readAsJSON');
                                    session.reject("failure in putting message to getShiftCrewLeaderCompassAPI");
                                } else {
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ILSctx.setVariable('CompassExitStatus', '0');
                                    hm.response.statusCode = responseStatusCode;
                                    if (responseData.totalResults > 0) {
                                        var internalid = responseData.Resources[0].id;
                                        ctx.setVariable("responseCompass", JSON.stringify(responseData));
                                        ctx.setVariable("compassid", internalid);
                                        var payload = {};
                                        payload.externalMemberUserIDs = [internalid];
                                        ctx.setVariable("compasspayload", payload);
                                        var getShiftCrewMemberCalleaderUrl = omsExternalURL + 'Crew/' + shiftCrewLeaderCrewId;
                                        logEmpToILS(empUserIdCrewLeader, 'FOUND', responseData, description);
                                        getShiftCrewLeaderCall(getShiftCrewMemberCalleaderUrl, 'GET', payload, shiftCrewLeaderCrewId);
                                    }
                                    else {
                                        //logger.error("No internal id found for this Emp User id:" + empUserIdCrewLeader + " in the Compass System");
                                        logEmpToILS(empUserIdCrewLeader, 'NOT_FOUND', responseData, description2);
                                        addNotFoundOnce(empUserIdCrewLeader);
                                    }
                                    decCompass();
                                }
                            });
                        }
                        else if (responseStatusCode == 401) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    var errorinfo = "Not Found Error response received from Compass " + info + "; error info :" + JSON.stringify(error);
                                    ilsctx.setVariable('exitStatus', responseStatusCode);
                                    ilsctx.setVariable('ExitDescription', errorinfo)
                                    logger.error(errorinfo);
                                    session.reject(errorinfo);
                                } else {
                                    var errorinfo = "cms_023: Authentication Failure received from Compass" + info + "; error info :" + JSON.stringify(error);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ILSctx.setVariable('CompassExitStatus', '500');
                                    ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    logger.error("cms_022:Authentication Failure received from Compass" + JSON.stringify(error));
                                    var ErrorTxt = "Authentication Failure received from Compass ";
                                    ctx.setVariable("ErrorTxt", ErrorTxt);
                                    logEmpToILS(empUserIdCrewMember, 'NON_200', 'status=' + responseStatusCode);
                                    decCompass();
                                }
                            });
                        }

                        else {
                            var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                            // ctx.setVariable("retry", 'yes');
                            logger.error("cms_017:urlopen connect error with getShiftCrewLeaderCompassAPI" + JSON.stringify(error));
                            var errorinfo = "cms_022:urlopen connect error with getShiftCrewLeaderCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                            ILSctx.setVariable('CompassExitStatus', '500');
                            ILSctx.setVariable('CompassExitDescription', errorinfo);
                            var ErrorTxt = "urlopen connect error with getShiftCrewLeaderCompassAPI";
                            ctx.setVariable("ErrorTxt", ErrorTxt);
                            logEmpToILS(empUserIdCrewLeader, 'NON_200', 'status=' + responseStatusCode);
                            decCompass();
                        }
                    }

                });
            }
            function getShiftCrewLeaderCall(url, method, payload, shiftCrewLeaderCrewId) {
                var getShiftCrewLeaderAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    }
                };
                var info = " TargetURL: " + getShiftCrewLeaderAPI.target + "; Method: " + getShiftCrewLeaderAPI.method + ". ";
                urlopen.open(getShiftCrewLeaderAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("urlopen connect error with getShiftCrewLeaderAPI after Compass GET call" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with getShiftCrewLeaderAPI after Compass GET call, details are : " + info + "; error info :" + JSON.stringify(error);
                        // ILSctx.setVariable('CompassExitStatus', '500');
                        // ILSctx.setVariable('CompassExitDescription', errorinfo);
                        var ErrorTxt = "urlopen connect error with getShiftCrewLeaderAPI after Compass GET call";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to getShiftCrewLeaderAPI after Compass GET call" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to getShiftCrewLeaderAPI after Compass GET call, details are : " + info + "; error info :" + JSON.stringify(error);
                                    // ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    // ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    session.reject("failure in putting message to getShiftCrewLeaderAPI after Compass GET call");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from getShiftCrewLeaderAPI for crewId:" + shiftCrewLeaderCrewId + "" + responseStatusCode);
                                    var getShiftCrewLeaderAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("getShiftCrewLeaderAPIResponse", getShiftCrewLeaderAPIResponse);
                                    var ShiftLength = incomingdata.shifts.length;
                                    for (var i = 0;i < ShiftLength;i++) {
                                        var crewsLength = incomingdata.shifts[i].crews.length;
                                        for (var j = 0;j < crewsLength;j++) {
                                            //start
                                            var getShiftCrewLeader_crewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
                                            if (getShiftCrewLeader_crewId === shiftCrewLeaderCrewId) {

                                                var getShiftCrewLeadePatchUrl = omsExternalURL + 'Crew/' + shiftCrewLeaderCrewId
                                                var getShiftCrewLeadId = getShiftCrewLeaderAPIResponse.id
                                                patchShiftCrewLeaderCall(getShiftCrewLeadePatchUrl, 'PATCH', payload, shiftCrewLeaderCrewId, getShiftCrewLeadId);
                                            }

                                        }
                                    }
                                }
                            });
                        } else {
                            //Start if ShiftCrewLeaderCrewId not found 
                            logger.debug("Unable to find the crewId details in getShiftCrewLeaderCrewId API call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode);

                            var ShiftLength = incomingdata.shifts.length;
                            for (var i = 0;i < ShiftLength;i++) {
                                var crewsLength = incomingdata.shifts[i].crews.length;
                                for (var j = 0;j < crewsLength;j++) {
                                    var getShiftCrewLeader_EmpId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
                                    if (getShiftCrewLeader_EmpId === shiftCrewLeaderCrewId) {

                                        var postShiftCrewLeaderUrl = omsExternalURL + 'Crew'
                                        postShiftCrewLeaderCall(postShiftCrewLeaderUrl, 'POST', payload, shiftCrewLeaderCrewId);
                                    }
                                }
                            }
                        }
                    }
                });
            }
            //End :Make GET,PATCH and POST call to Create/Update the  shiftCrewLeaderCrewId

            //Start :Make GET,PATCH and POST call to Create/Update the UnAssignedCrewId's
            function getUnAssignCompassCall(url, method, payload, unAssignCrewId, empUserIdUnassigned) {
                var getUnAssignAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': compassToken
                    }
                };
                var info = " TargetURL: " + getUnAssignAPI.target + "; Method: " + getUnAssignAPI.method + ". ";
                urlopen.open(getUnAssignAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("cms_022:urlopen connect error with getUnAssignCompassAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with getUnAssignCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        ILSctx.setVariable('CompassExitStatus', '500');
                        ILSctx.setVariable('CompassExitDescription', errorinfo);
                        var ErrorTxt = "urlopen connect error with getUnAssignCompassAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                        logEmpToILS(empUserIdUnassigned, 'ERROR', 'network/connect');
                        decCompass();
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to getUnAssignCompassAPI" + JSON.stringify(error));
                                    var errorinfo = "urlopen connect error with getUnAssignCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    logEmpToILS(empUserIdUnassigned, 'ERROR', 'readAsJSON'); // <<< ADD
                                    session.reject("failure in putting message to getUnAssignCompassAPI");
                                } else {
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ILSctx.setVariable('CompassExitStatus', '0');
                                    hm.response.statusCode = responseStatusCode;
                                    if (responseData.totalResults > 0) {
                                        var internalid = responseData.Resources[0].id;
                                        ctx.setVariable("responseCompass", responseData);
                                        ctx.setVariable("compassid", internalid);
                                        var payload = {};
                                        payload.externalMemberUserIDs = [internalid];
                                        ctx.setVariable("compasspayload", payload);
                                        var getUnAssignUrl = omsExternalURL + 'Crew/' + unAssignCrewId;
                                        logEmpToILS(empUserIdUnassigned, 'FOUND', responseData, description); // <<< ADD
                                        getUnAssignCall(getUnAssignUrl, 'GET', payload, unAssignCrewId);

                                    }
                                    else {
                                        // logger.error("No internal id found for this Emp User id:" + empUserIdUnassigned + " in the Compass System");
                                        logEmpToILS(empUserIdUnassigned, 'NOT_FOUND', responseData, description2);
                                        addNotFoundOnce(empUserIdUnassigned);
                                    }
                                    decCompass();
                                }
                            });
                        }
                        else if (responseStatusCode == 401) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    var errorinfo = "Not Found Error response received from Compass " + info + "; error info :" + JSON.stringify(error);
                                    ilsctx.setVariable('exitStatus', responseStatusCode);
                                    ilsctx.setVariable('ExitDescription', errorinfo)
                                    logger.error(errorinfo);
                                    session.reject(errorinfo);
                                } else {
                                    var errorinfo = "cms_023: Authentication Failure received from Compass" + info + "; error info :" + JSON.stringify(error);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ILSctx.setVariable('CompassExitStatus', '500');
                                    ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    logger.error("cms_022:Authentication Failure received from Compass" + JSON.stringify(error));
                                    var ErrorTxt = "Authentication Failure received from Compass ";
                                    ctx.setVariable("ErrorTxt", ErrorTxt);
                                    logEmpToILS(empUserIdCrewMember, 'NON_200', 'status=' + responseStatusCode);
                                    decCompass();
                                }
                            });
                        }
                        else {
                            var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                            //ctx.setVariable("retry", 'yes');
                            logger.error("cms_022:urlopen connect error with getUnAssignCompassAPI" + JSON.stringify(error));
                            var errorinfo = "urlopen connect error with getUnAssignCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                            ILSctx.setVariable('CompassExitStatus', '500');
                            ILSctx.setVariable('CompassExitDescription', errorinfo);
                            var ErrorTxt = "urlopen connect error with getUnAssignCompassAPI";
                            ctx.setVariable("ErrorTxt", ErrorTxt);
                            logEmpToILS(empUserIdUnassigned, 'NON_200', 'status=' + responseStatusCode);
                            decCompass();
                        }
                    }

                });

            }

            //Start :Make GET,PATCH and POST call to Create/Update the UnAssignedCrewId's
            function getSupervisorCompassCall(url, method, payload, supervisorsCrewId, empUserIdSupervisors) {
                var getUnAssignAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': compassToken
                    }
                };
                var info = " TargetURL: " + getUnAssignAPI.target + "; Method: " + getUnAssignAPI.method + ". ";
                urlopen.open(getUnAssignAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("cms_022:urlopen connect error with getSupervisorCompassAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with getSupervisorCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        ILSctx.setVariable('CompassExitStatus', '500');
                        ILSctx.setVariable('CompassExitDescription', errorinfo);
                        var ErrorTxt = "urlopen connect error with getSupervisorCompassAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                        logEmpToILS(empUserIdSupervisors, 'ERROR', 'network/connect'); // <<< ADD
                        decCompass();
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to getSupervisorCompassAPI" + JSON.stringify(error));
                                    var errorinfo = "urlopen connect error with getSupervisorCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    logEmpToILS(empUserIdSupervisors, 'ERROR', 'readAsJSON'); // <<< ADD
                                    session.reject("failure in putting message to getSupervisorCompassAPI");
                                } else {
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ILSctx.setVariable('CompassExitStatus', '0');
                                    hm.response.statusCode = responseStatusCode;
                                    if (responseData.totalResults > 0) {
                                        var internalid = responseData.Resources[0].id;
                                        ctx.setVariable("responseCompass", responseData);
                                        ctx.setVariable("compassid", internalid);
                                        var payload = {};
                                        payload.externalMemberUserIDs = [internalid];
                                        ctx.setVariable("compasspayload", payload);
                                        var getSupervisorsUrl = omsExternalURL + 'Crew/' + supervisorsCrewId;
                                        logEmpToILS(empUserIdSupervisors, 'FOUND', responseData, description); // <<< ADD
                                        getSupervisorCall(getSupervisorsUrl, 'GET', payload, supervisorsCrewId);

                                    }
                                    else {
                                        // logger.error("No internal id found for this Emp User id:" + empUserIdSupervisors + " in the Compass System");
                                        logEmpToILS(empUserIdSupervisors, 'NOT_FOUND', responseData, description2); // <<< ADD
                                        addNotFoundOnce(empUserIdSupervisors);
                                    }
                                    decCompass();
                                }
                            });
                        }
                        else if (responseStatusCode == 401) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    var errorinfo = "Not Found Error response received from Compass " + info + "; error info :" + JSON.stringify(error);
                                    ilsctx.setVariable('exitStatus', responseStatusCode);
                                    ilsctx.setVariable('ExitDescription', errorinfo)
                                    logger.error(errorinfo);
                                    session.reject(errorinfo);
                                } else {
                                    var errorinfo = "cms_023: Authentication Failure received from Compass" + info + "; error info :" + JSON.stringify(error);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ILSctx.setVariable('CompassExitStatus', '500');
                                    ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    logger.error("cms_022:Authentication Failure received from Compass" + JSON.stringify(error));
                                    var ErrorTxt = "Authentication Failure received from Compass ";
                                    ctx.setVariable("ErrorTxt", ErrorTxt);
                                    logEmpToILS(empUserIdCrewMember, 'NON_200', 'status=' + responseStatusCode);
                                    decCompass();
                                }
                            });
                        }
                        else {
                            var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                            //ctx.setVariable("retry", 'yes');
                            logger.error("cms_022:urlopen connect error with getSupervisorCompassAPI" + JSON.stringify(error));
                            var errorinfo = "urlopen connect error with getSupervisorCompassAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                            ILSctx.setVariable('CompassExitStatus', '500');
                            ILSctx.setVariable('CompassExitDescription', errorinfo);
                            var ErrorTxt = "urlopen connect error with getSupervisorCompassAPI";
                            ctx.setVariable("ErrorTxt", ErrorTxt);
                            logEmpToILS(empUserIdSupervisors, 'NON_200', 'status=' + responseStatusCode); // <<< ADD
                            decCompass();
                        }
                    }

                });

            }
            //Start :Make GET,PATCH and POST call to Create/Update the UnAssignedCrewId's
            function getUnAssignCall(url, method, payload, unAssignCrewId) {
                var getUnAssignAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    }
                };
                var info = " TargetURL: " + getUnAssignAPI.target + "; Method: " + getUnAssignAPI.method + ". ";
                urlopen.open(getUnAssignAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("urlopen connect error with getUnAssignCrewAPI after the Compass GET call" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with getUnAssignCrewAPI after the Compass GET call, details are : " + info + "; error info :" + JSON.stringify(error);
                        //ILSctx.setVariable('CompassExitStatus', '500');
                        // ILSctx.setVariable('CompassExitDescription', errorinfo);
                        var ErrorTxt = "urlopen connect error with getUnAssignCrewAPI after the Compass GET call";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to getUnAssignAPI after the Compass GET call" + JSON.stringify(error));
                                    var errorinfo = "urlopen connect error with getUnAssignAPI after the Compass GET call, details are : " + info + "; error info :" + JSON.stringify(error);
                                    //  ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    //  ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    session.reject("failure in putting message to getUnAssignAPI after the Compass GET call");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from getUnAssignAPI for crewId:" + unAssignCrewId + "" + responseStatusCode);
                                    var getUnAssignResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("getUnAssignResponse", getUnAssignResponse);
                                    var unAssignedLength = incomingdata.unassigned.length;
                                    for (var i = 0;i < unAssignedLength;i++) {
                                        var unAssigned_crewId = incomingdata.unassigned[i].crewId;
                                        if (unAssigned_crewId === unAssignCrewId) {
                                            var patchUnAssignUrl = omsExternalURL + 'Crew/' + unAssignCrewId
                                            var getUnAssignid = getUnAssignResponse.id
                                            patchUnAssignCall(patchUnAssignUrl, 'PATCH', payload, unAssignCrewId, getUnAssignid);
                                        }
                                    } //end for loop
                                }
                            });
                        } else {
                            //Make Post call If UnAssigned crewId not found
                            logger.debug("Unable to find the crewId details for " + unAssignCrewId + " " + responseStatusCode);
                            var unAssignedLength = incomingdata.unassigned.length;
                            for (var i = 0;i < unAssignedLength;i++) {
                                var unAssigned_crewId = incomingdata.unassigned[i].crewId;
                                if (unAssigned_crewId === unAssignCrewId) {
                                    var postUnAssignUrl = omsExternalURL + 'Crew';
                                    postUnAssignCall(postUnAssignUrl, 'POST', payload, unAssignCrewId);
                                }
                            }
                        }
                    }
                });

            }
            //End :Make GET,PATCH and POST call to Create/Update the UnAssignedCrewId's

            //Start :Make GET,PATCH and POST call to Create/Update the supervisorsCrewId's
            function getSupervisorCall(url, method, payload, supervisorsCrewId) {
                var getSupervisorAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    }
                };
                var info = " TargetURL: " + getSupervisorAPI.target + "; Method: " + getSupervisorAPI.method + ". ";
                urlopen.open(getSupervisorAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("urlopen connect error with getSupervisorAPI after the Compass GET call" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with getSupervisorAPI after the Compass GET call, details are : " + info + "; error info :" + JSON.stringify(error);
                        // ILSctx.setVariable('CompassExitStatus', '500');
                        //ILSctx.setVariable('CompassExitDescription', errorinfo);
                        var ErrorTxt = "urlopen connect error with getSupervisorAPI after the Compass GET call";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to getSupervisorAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to getSupervisorAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    //  ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    //  ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    session.reject("failure in putting message to getSupervisorAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from getSupervisorAPI for crewId:" + supervisorsCrewId + "" + responseStatusCode);
                                    var getSupervisorAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("getSupervisorAPIResponse", getSupervisorAPIResponse);

                                    var supervisorsLength = incomingdata.supervisors.length;
                                    for (var i = 0;i < supervisorsLength;i++) {
                                        var supervisors_crewId = incomingdata.supervisors[i].crewId;
                                        if (supervisors_crewId === supervisorsCrewId) {
                                            var patchSupervisorsUrl = omsExternalURL + 'Crew/' + supervisorsCrewId
                                            var getSupervisorAPIResponseId = getSupervisorAPIResponse.id
                                            patchSupervisorsCall(patchSupervisorsUrl, 'PATCH', payload, supervisorsCrewId, getSupervisorAPIResponseId);
                                        }
                                    }
                                }
                            });
                        } else {

                            logger.debug("Unable to find the crewId details in getSupervisorsAPI call" + " " + supervisorsCrewId + " " + responseStatusCode);
                            var supervisorsLength = incomingdata.supervisors.length;
                            for (var i = 0;i < supervisorsLength;i++) {
                                var supervisors_crewId = incomingdata.supervisors[i].crewId;
                                if (supervisors_crewId === supervisorsCrewId) {
                                    var postSupervisorsUrl = omsExternalURL + 'Crew'
                                    postSupervisorsCall(postSupervisorsUrl, 'POST', payload, supervisorsCrewId);
                                }
                            }
                        }
                    }
                });
            }
            //End : Make GET,PATCH and POST call to Create/Update the supervisorsCrewId's

            //Start:CrewLeader POST call function start to  Update the shiftCrewLeaderCrewId CustomFields
            function postShiftCrewLeaderCall(url, method, payload, shiftCrewLeaderCrewId) {
                var postShiftCrewLeaderAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: payload
                };
                ILSctx.setVariable("exitpayload", JSON.stringify(postShiftCrewLeaderAPI.data));
                var info = " TargetURL :" + postShiftCrewLeaderAPI.target + "; Method :" + postShiftCrewLeaderAPI.method + "; Data :" + JSON.stringify(postShiftCrewLeaderAPI.data) + ". ";
                urlopen.open(postShiftCrewLeaderAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("urlopen connect error with postShiftCrewLeaderAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with postShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        // ILSctx.setVariable('CompassExitStatus', '500');
                        //ILSctx.setVariable('CompassExitDescription', errorinfo);
                        var ErrorTxt = "urlopen connect error with postShiftCrewLeaderAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to postShiftCrewLeaderAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to postShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    // ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    // ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    session.reject("failure in putting message to postShiftCrewLeaderAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from compassPostShiftCrewLeaderAPI for empId:" + shiftCrewLeaderCrewId + "" + responseStatusCode);
                                    var postShiftCrewLeaderAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("compassPostShiftCrewLeaderAPIResponse", postShiftCrewLeaderAPIResponse);
                                }
                            });
                        } else {
                            logger.error("Unable to find the crewId details in postCrewLeaderOnshiftAPIResponse call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode);
                            var errorinfo = "Unable to find the crewId details in postCrewLeaderOnshiftAPIResponse call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode;
                        }
                    }
                });
            }
            //End:CrewLeader POST call function start to  Update the shiftCrewLeaderCrewId CustomFields 

            //Start:CrewLeader PATCH call function start to Update the shiftCrewLeaderCrewId CustomFields 
            function patchShiftCrewLeaderCall(url, method, payload, shiftCrewLeaderCrewId, getShiftCrewLeadId) {
                var patchShiftCrewLeaderAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: payload
                };
                var info = " TargetURL :" + patchShiftCrewLeaderAPI.target + "; Method :" + patchShiftCrewLeaderAPI.method + "; Data :" + JSON.stringify(patchShiftCrewLeaderAPI.data) + ". ";
                urlopen.open(patchShiftCrewLeaderAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("urlopen connect error with patchShiftCrewLeaderAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with patchShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        var ErrorTxt = "urlopen connect error with patchShiftCrewLeaderAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to patchShiftCrewLeaderAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to patchShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    session.reject("failure in putting message to patchShiftCrewLeaderAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from compassPatchShiftCrewLeaderAPI for crewId:" + shiftCrewLeaderCrewId + "" + responseStatusCode);
                                    var patchShiftCrewLeaderAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("compassPatchShiftCrewLeaderAPIResponse", patchShiftCrewLeaderAPIResponse);

                                }

                            });
                        } else {
                            logger.error("Unable to find the crewId details in patchShiftCrewLeaderOnShiftPatchAPI call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode);
                            var errorinfo = "Unable to find the crewId details in patchShiftCrewLeaderOnShiftPatchAPI call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode;
                        }
                    }
                });
            }
            //End:CrewLeader PATCH call function start to  Update the shiftCrewLeaderCrewId CustomFields 

            function getShiftCrewMemberCall(url, method, payload, shiftCrewMemberCrewId) {
                var getShiftCrewMemberAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    }
                };
                var info = " TargetURL: " + getShiftCrewMemberAPI.target + "; Method: " + getShiftCrewMemberAPI.method + ". ";
                urlopen.open(getShiftCrewMemberAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        var errorinfo = "urlopen connect error with getShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        logger.error("cms_016:urlopen connect error with getShiftCrewMemberAPI" + JSON.stringify(error));
                        var ErrorTxt = "urlopen connect error with getShiftCrewMemberAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to getShiftCrewMemberAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to getShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    session.reject("failure in putting message to getShiftCrewMemberAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from getShiftCrewMemberAPI for empId:" + shiftCrewMemberCrewId + "" + responseStatusCode);
                                    var getShiftCrewMemberAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("getShiftCrewMemberAPIResponse", getShiftCrewMemberAPIResponse);
                                    var ShiftLength = incomingdata.shifts.length;
                                    for (var i = 0;i < ShiftLength;i++) {
                                        var crewsLength = incomingdata.shifts[i].crews.length;
                                        for (var j = 0;j < crewsLength;j++) {
                                            var getShiftCrewLeader_CrewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
                                            var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
                                            for (var k = 0;k < crewMembersLength;k++) {
                                                var getShiftCrewMember_CrewId = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
                                                if (getShiftCrewMember_CrewId === shiftCrewMemberCrewId) {
                                                    var getShiftCrewMemberPatchUrl = omsExternalURL + 'Crew/' + shiftCrewMemberCrewId
                                                    var idTopass = getShiftCrewMemberAPIResponse.id
                                                    patchShiftCrewMemberCall(getShiftCrewMemberPatchUrl, 'PATCH', payload, shiftCrewMemberCrewId, idTopass);
                                                }
                                            }
                                        }
                                    }

                                }
                            });
                        } else {
                            //Start if Shift CrewMemberCrewId not found 
                            logger.debug("Unable to find the empId details in getShiftCrewMemberAPI call shiftCrewMemberCrewId " + " " + shiftCrewMemberCrewId + " " + "responseStatusCode" + " " + responseStatusCode);

                            var ShiftLength = incomingdata.shifts.length;
                            for (var i = 0;i < ShiftLength;i++) {
                                var crewsLength = incomingdata.shifts[i].crews.length;
                                for (var j = 0;j < crewsLength;j++) {
                                    var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
                                    var getShiftCrewLeader_CrewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
                                    for (var k = 0;k < crewMembersLength;k++) {
                                        var shiftCrew_Id = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
                                        if (shiftCrew_Id === shiftCrewMemberCrewId) {
                                            var postShiftCrewMemberUrl = omsExternalURL + 'Crew'
                                            postShiftCrewMemberCall(postShiftCrewMemberUrl, 'POST', payload, shiftCrewMemberCrewId);
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            }
            //End :Make GET,PATCH and POST call to Create/Update the Shift CrewMember crewMembeCrewId
            //Start:CrewMember POST call function start to  Update the Shift CrewMemberEmpId CustomFields
            function postShiftCrewMemberCall(url, method, payload, shiftCrewMemberCrewId) {
                var postShiftCrewMemberAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: payload
                };
                ILSctx.setVariable("exitpayload", JSON.stringify(postShiftCrewMemberAPI.data));
                var info = " TargetURL :" + postShiftCrewMemberAPI.target + "; Method :" + postShiftCrewMemberAPI.method + "; Data :" + JSON.stringify(postShiftCrewMemberAPI.data) + ". ";
                urlopen.open(postShiftCrewMemberAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        // ctx.setVariable("retry", 'yes');
                        logger.error("urlopen connect error with postShiftCrewMemberAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with postShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        // ILSctx.setVariable('CompassExitStatus', '500');
                        //  ILSctx.setVariable('CompassExitDescription', errorinfo);
                        var ErrorTxt = "urlopen connect error with postShiftCrewMemberAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to postShiftCrewMemberAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to postShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    //  ILSctx.setVariable('CompassExitStatus', responseStatusCode);
                                    //   ILSctx.setVariable('CompassExitDescription', errorinfo);
                                    session.reject("failure in putting message to postShiftCrewMemberAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from postShiftCrewMemberAPI for crewId:" + shiftCrewMemberCrewId + "" + responseStatusCode);
                                    var postShiftCrewMemberAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("compassPostShiftCrewMemberAPIResponse", postShiftCrewMemberAPIResponse);

                                }
                            });
                        } else {
                            logger.error("Unable to find the empId details in postCrewMemberOnshiftAPI call" + " " + shiftCrewMemberCrewId + " " + responseStatusCode);
                            var errorinfo = "Unable to find the empId details in postCrewMemberOnshiftAPI call" + " " + shiftCrewMemberCrewId + " " + responseStatusCode;
                        }
                    }
                });
            }
            //End:CrewMember POST call function start to  Update the Shift CrewMemberEmpId CustomFields 


            //Start:CrewMember PATCH call function start to  Update the Shift CrewMemberEmpId CustomFields 
            function patchShiftCrewMemberCall(url, method, payload, shiftCrewMemberCrewId, idTopass) {
                var patchShiftCrewMemberAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: payload
                };
                var info = " TargetURL :" + patchShiftCrewMemberAPI.target + "; Method :" + patchShiftCrewMemberAPI.method + "; Data :" + JSON.stringify(patchShiftCrewMemberAPI.data) + ". ";
                urlopen.open(patchShiftCrewMemberAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        logger.error("urlopen connect error with patchShiftCrewMemberAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with patchShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        var ErrorTxt = "urlopen connect error with patchShiftCrewMemberAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to patchShiftCrewMemberAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to patchShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    session.reject("failure in putting message to patchShiftCrewMemberAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from patchShiftCrewMemberAPI for empId:" + shiftCrewMemberCrewId + "" + responseStatusCode);
                                    var patchShiftCrewMemberAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("compassPatchShiftCrewMemberAPIResponse", patchShiftCrewMemberAPIResponse);

                                }
                            });
                        } else {
                            logger.error("Unable to find the empId details in patchShiftCrewMemberOnShiftPatchAPI call" + " " + shiftCrewMemberCrewId + " " + responseStatusCode);
                            var errorinfo = "Unable to find the empId details in patchShiftCrewMemberOnShiftPatchAPI call" + " " + shiftCrewMemberCrewId + " " + responseStatusCode;
                        }
                    }
                });
            }
            //End:CrewMember PATCH call function start to  Update the shiftCrewMemberCrewId CustomFields 
            //Start:UnAssign PATCH call function start to  Update the UnAssignEmpId CustomFields
            function patchUnAssignCall(url, method, payload, unAssignCrewId, getUnAssignid) {
                var patchUnAssignAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: payload
                };
                ILSctx.setVariable("exitpayload", JSON.stringify(patchUnAssignAPI.data));
                var info = " TargetURL :" + patchUnAssignAPI.target + "; Method :" + patchUnAssignAPI.method + "; Data :" + JSON.stringify(patchUnAssignAPI.data) + ". ";
                urlopen.open(patchUnAssignAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        logger.error("urlopen connect error with patchUnAssignAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with patchUnAssignAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        var ErrorTxt = "urlopen connect error with patchUnAssignAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to patchUnAssignAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to patchUnAssignAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    session.reject("failure in putting message to patchUnAssignAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from patchUnAssignAPI for crewId:" + unAssignCrewId + "" + responseStatusCode);
                                    var patchUnAssignAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("patchUnAssignAPIResponse", patchUnAssignAPIResponse);

                                }
                            });
                        }
                    }
                });
            }
            //End: UnAssign PATCH call function start to  Update the UnAssignEmpId CustomFields


            //Start: UnAssign POST call function start to  Update the UnAssignEmpId CustomFields 
            function postUnAssignCall(url, method, payload, unAssignCrewId) {
                var postUnAssignAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: payload
                };
                ILSctx.setVariable("exitpayload", JSON.stringify(postUnAssignAPI.data));
                var info = " TargetURL :" + postUnAssignAPI.target + "; Method :" + postUnAssignAPI.method + "; Data :" + JSON.stringify(postUnAssignAPI.data) + ". ";
                urlopen.open(postUnAssignAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("urlopen connect error with postUnAssignAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with postUnAssignAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        var ErrorTxt = "urlopen connect error with postUnAssignAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {

                                    logger.error("failure in putting message to postUnAssignAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to postUnAssignAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    session.reject("failure in putting message to postUnAssignAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from postUnAssignAPI for crewId:" + unAssignCrewId + "" + responseStatusCode);
                                    var postUnAssignAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("postUnAssignAPIResponse", postUnAssignAPIResponse);
                                }
                            });
                        }
                    }
                });
            }
            //End: UnAssign PATCH call function start to  Update the UnAssignCrewId CustomFields

            //Start:supervisors PATCH call function start to  Update the supervisorsEmpId CustomFields
            function patchSupervisorsCall(url, method, payload, supervisorsCrewId, getSupervisorAPIResponseId) {

                var patchSupervisorAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: payload
                };
                ILSctx.setVariable("exitpayload", JSON.stringify(patchSupervisorAPI.data));
                var info = " TargetURL :" + patchSupervisorAPI.target + "; Method :" + patchSupervisorAPI.method + "; Data :" + JSON.stringify(patchSupervisorAPI.data) + ". ";
                urlopen.open(patchSupervisorAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                        //ctx.setVariable("retry", 'yes');
                        logger.error("urlopen connect error with patchSupervisorAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with patchSupervisorAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        var ErrorTxt = "urlopen connect error with patchSupervisorAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to patchSupervisorAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to patchSupervisorAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    session.reject("failure in putting message to patchSupervisorAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from patchSupervisorAPI for crewId:" + supervisorsCrewId + "" + responseStatusCode);
                                    var patchSupervisorAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("patchSupervisorAPIResponse", patchSupervisorAPIResponse);
                                }
                            });
                        }
                    }
                });
            }
            //End: SuperVisor PATCH call function start to  Update the supervisorsEmpId CustomFields

            //Start: supervisors POST call function start to  Update the supervisorsEmpId CustomFields 
            function postSupervisorsCall(url, method, payload, supervisorsCrewId) {

                var postSupervisorsAPI = {
                    target: url,
                    sslClientProfile: 'omscms_oms_ssl_ClientProfile',
                    method: method,
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: payload
                };
                ILSctx.setVariable("exitpayload", JSON.stringify(postSupervisorsAPI.data));
                var info = " TargetURL :" + postSupervisorsAPI.target + "; Method :" + postSupervisorsAPI.method + "; Data :" + JSON.stringify(postSupervisorsAPI.data) + ". ";
                urlopen.open(postSupervisorsAPI, function(error, response) {
                    if (error) {
                        var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");

                        logger.error("urlopen connect error with postSupervisorsAPI" + JSON.stringify(error));
                        var errorinfo = "urlopen connect error with postSupervisorsAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                        var ErrorTxt = "urlopen connect error with postSupervisorsAPI";
                        ctx.setVariable("ErrorTxt", ErrorTxt);
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    logger.error("failure in putting message to postSupervisorsAPI" + JSON.stringify(error));
                                    var errorinfo = "failure in putting message to postSupervisorsAPI, details are : " + info + "; error info :" + JSON.stringify(error);
                                    session.reject("failure in putting message to postSupervisorsAPI");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    logger.debug("response received from postSupervisorsAPI for crewId:" + supervisorsCrewId + "" + responseStatusCode);
                                    var postSupervisorsAPIResponse = JSON.parse(responseData);
                                    var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
                                    ctx.setVariable("postSupervisorsAPIResponse", postSupervisorsAPIResponse);
                                }
                            });
                        }
                    }
                });
            }
            //End: Supervisor PATCH call function start to  Update the supervisorsCrewId CustomFields
        }
    }
});
