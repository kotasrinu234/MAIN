var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
var apiToken = ctx.getVariable("apiToken");
var timestamp = ctx.getVar("timestampframed");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
var ILSctx = session.name("ILS") || session.createContext("ILS");
	var InternalIDArray = ctx.getVar("InternalIDArray");

	for (var i = 0; i < InternalIDArray.length; i++) {
		var extrId = InternalIDArray[i];
		//Patch: api/ServiceType/Electric/Crew/{id}
		var patchCrewUrl = omsExternalURL + 'Crew/' + extrId;
		var customFieldValues = {};
		var payload = {};
		var crew_members = [];
		var customTableValues = {
			crew_members
		};
		customFieldValues.Crew_Leader = null;
		customFieldValues.Crew_Compliment = null;
		customFieldValues.isLeader = false;
		customFieldValues.IsSupervisor = false;
		payload.customTableValues = customTableValues;
		payload.customFieldValues = customFieldValues;
		patchOffshiftCall(patchCrewUrl, 'PATCH', payload, extrId);
	}

	//Set crew member,leader and compliment to null
	function patchOffshiftCall(url, method, payload, extrId) {
		var patchAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		var info = " TargetURL :" + patchAPI.target + "; Method :" + patchAPI.method + "; Data :" + JSON.stringify(patchAPI.data) + ". ";
		urlopen.open(patchAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("urlopen connect error with patchAPI" + JSON.stringify(error));
				var ErrorTxt = "urlopen connect error with patchAPI";
				var errorinfo = "urlopen connect error with patchAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to patchAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to patchAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to patchAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from patchAPI for crewId:" + extrId + "" + responseStatusCode);
							var patchCrewAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							var patchOffShiftUrl = omsExternalURL + 'Crew/' + extrId + '/OffShift';
							var payload = {
								"shiftOffTime": timestamp
							}
							// ADO146962 commenting the offshift PATCH call
							
							/* var patchOffShiftAPI = {
								target: patchOffShiftUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: payload
							};
							var info = " TargetURL :" + patchOffShiftAPI.target + "; Method :" + patchOffShiftAPI.method + "; Data :" + JSON.stringify(patchOffShiftAPI.data) + ". ";
							urlopen.open(patchOffShiftAPI, function(error, response) {
								if (error) {
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									ctx.setVariable("retry", 'yes');
									logger.error("urlopen connect error with patchOffShiftAPI" + JSON.stringify(error));
									var errorinfo = "urlopen connect error with patchOffShiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									var ErrorTxt = "urlopen connect error with patchOffShiftAPI";
									ctx.setVariable("ErrorTxt", ErrorTxt);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("failure in putting message to patchOffShiftAPI" + JSON.stringify(error));
												var errorinfo = "failure in putting message to patchOffShiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												session.reject("failure in putting message to patchOffShiftAPI");
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from patchOffShiftAPI for crewId:" + extrId + " " + responseStatusCode);
												var patchOffShiftAPIResponse = JSON.parse(responseData);
											}
										});
									} else {

										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  patchOffShiftAPI " + " " + JSON.stringify(error));
												var errorinfo = "Error response received from  patchOffShiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											} else {
												logger.error("Error response received from patchOffShiftAPI " + " " + responseData);
												var errorinfo = "Error response received from patchOffShiftAPI, details are : " + info + "; error info :" + responseData;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											}
										});
										//end
									}
								}
							});*/
						}
					});
				} else {
					logger.debug("Unable to find the extrId details for " + extrId + " " + "responseStatusCode" + " " + responseStatusCode);
				}
			}
		});
	}
});
