var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
var  aorIDArrayfromLookup=  ctx.getVar("aorIDArray");
var IdfromCrewTypesfromLookup=  ctx.getVar("IdfromCrewTypes");
var statusfromCrewTypesLookup=  ctx.getVar("statusfromLookupCrewTypes");
var logger = console.options({
    'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	 var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
     var exIDArray=[];
var InternalIDArray=[];
	 var  crewAPICallArray=  ctx.getVar("crewAPICallArray");
	 for(var i=0;i<crewAPICallArray.length;i++){
		 var type = crewAPICallArray[i].type;
		 if(type===statusfromCrewTypesLookup) {
			  var matchaorIDs =[];
			  var aorIdLen = crewAPICallArray[i].aorIDs.length;
			  var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
			  var aorIDArrayLookupLen = aorIDArrayfromLookup.length;
			  var eId='';
			  for(var j=0;j<aorIdLen;j++) {
				  for(var l=0;l<aorIDArrayLookupLen;l++) {
					  var crewAPIaorIdLen = crewAPICallArray[i].aorIDs[j].length;
					   if(crewAPICallArray[i].aorIDs[j]==aorIDArrayfromLookup[l]){
						 if(aorIdLen == aorIDArrayLookupLen){
							   if(eId=='') {
									eId = crewAPICallArray[i].externalID;
									var InternalID =crewAPICallArray[i].id
									 exIDArray.push(eId);
								InternalIDArray.push(InternalID)
								}
						   }
			              matchaorIDs.push(aorIDArrayfromLookup[l]);
						  }
					  }
				   var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
				   ctx.setVariable('matchaorIDs', matchaorIDs);
				   ctx.setVariable('exIDArray', exIDArray);
	ctx.setVariable('InternalIDArray', InternalIDArray);
			  }
		}
	 }
});
