var hm = require('header-metadata');
var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
var urlopen = require('urlopen');
var workGroup_OH = session.parameters.workGroup_OH;
var workGroup_UG = session.parameters.workGroup_UG;
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(error, incomingdata) {
    if (error) {
    	logger.debug("Invalid Request Json" );
        //throw error;
    } else {
    	
	      //Start: Check If Shift block is exist or not
	    	var ShiftLst = incomingdata.shifts;
	    	var shiftCrewMemArray=[];
	    	if(ShiftLst === null || ShiftLst === '' || ShiftLst === undefined) {
				logger.error("Unable to find empList from Shiftblock");
			} else {
				var ShiftLength = incomingdata.shifts.length;
				for(var i=0;  i<ShiftLength;  i++)
				{
					var crewsLength = incomingdata.shifts[i].crews.length;
				     for(var j=0; j<crewsLength; j++) {
				    	 var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
				    	  for(var k=0; k<crewMembersLength; k++) {
				    		  var shiftCrewMemberCrewId= incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
				    		  shiftCrewMemArray.push(shiftCrewMemberCrewId);
				    	  }
				    	
				    	  var shiftCrewLeaderCrewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
				    	  ctx.setVariable("shiftCrewLeaderCrewId", shiftCrewLeaderCrewId);
				     }
				    
				}
				  ctx.setVariable("shiftCrewMemCrewId", shiftCrewMemArray);
			}
	    //End: Check If Shift block is exist or not	
    	
       //Start : Check If UnAssign block is exist or not
    	var unsasLst = incomingdata.unassigned;
    	var unAssignCrewArray=[];
		if(unsasLst === null || unsasLst === '' || unsasLst === undefined) {
			logger.debug("Unable to find crewList from Unassignedblock");
		}  else {
			var unsasLst = incomingdata.unassigned.length;
			for(var i =0; i < unsasLst ; i++){
				var unAssignCrewId= incomingdata.unassigned[i].crewId;
				unAssignCrewArray.push(unAssignCrewId);
			}
			ctx.setVariable("unAssignCrewIds", unAssignCrewArray);
		}
    	//End: Check If UnAssign block is exist or not
    	
		
		//Start: Check If supervisors block is exist or not
				var supervisorsLst = incomingdata.supervisors;
				var supervisorsArray=[];
				if(supervisorsLst === null || supervisorsLst === '' || supervisorsLst === undefined) {
					logger.debug("Unable to find crewId's from supervisorsblock");
				}  else {
					var supervisorsLst = incomingdata.supervisors.length;
					for(var i =0; i < supervisorsLst ; i++){
						var supervisorsCrewId= incomingdata.supervisors[i].crewId;
						supervisorsArray.push(supervisorsCrewId);
					}
					ctx.setVariable("supervisorsCrewIds", supervisorsArray);
				}
	   //End: Check If supervisors block is exist or not
    	
    	var workGroup = incomingdata.workGroup;
		if(workGroup == undefined || workGroup == null || workGroup == ''){
			logger.debug("workGroup cannot be empty in incoming request");
		}
		else if(workGroup != undefined || workGroup != null || workGroup != ''){
			if(workGroup==='OH'){
				ctx.setVariable("workGroup", 'OH');
			}else if(workGroup==='UG'){
				ctx.setVariable("workGroup", 'UG');
			}else{
				logger.debug("workGroup can be either OH or UG");
			}
		}
    		
		    var serviceCenter = incomingdata.serviceCenter;	
		    if (serviceCenter == null || serviceCenter == '' || serviceCenter == undefined) {
		    	logger.debug("serviceCenter cannot be empty in incoming request");
		    }
			else{
				ctx.setVariable("serviceCenter", serviceCenter);
			}
		    
		    var rosterId = incomingdata.rosterId;	
		    if (rosterId == null || rosterId == '' || rosterId == undefined) {
		    	logger.debug("rosterId cannot be empty in incoming request");
		    }
			else{
				ctx.setVariable("rosterId", rosterId);
			}
		    
		    var rosterDate = incomingdata.rosterDate;	
		    if (rosterDate == null || rosterDate == '' || rosterDate == undefined) {
		    	logger.debug("rosterDate cannot be empty in incoming request");
		    }
			else{
				ctx.setVariable("rosterDate", rosterDate);
			}
		    
		    var createdTimestamp = incomingdata.createdTimestamp;	
		    if (createdTimestamp == null || createdTimestamp == '' || createdTimestamp == undefined) {
		    	logger.debug("createdTimestamp cannot be empty in incoming request");
		    }
			else{
				ctx.setVariable("createdTimestamp", createdTimestamp);
			}
		    
		    var rosterNotes = incomingdata.rosterNotes;	
		    if (rosterNotes == null || rosterNotes == '' || rosterNotes == undefined) {
		    	logger.debug("rosterNotes cannot be empty in incoming request");
		    }
			else{
				ctx.setVariable("rosterNotes", rosterNotes);
			}
		    var now = new Date();
			var year = now.getFullYear();
			
			var month = now.getMonth()+1;
			var month1=month.toString();
			var strmonthlength = month1.length;
			var todaymonth;
			if (strmonthlength== 1){
				todaymonth = '0'+month;
			}else
				{
				todaymonth=month;
				}
			
			var day = now.getDate();
			var day1= day.toString();
			var strdaylength = day1.length;
			var todaydate;
			if (strdaylength== 1){
				todaydate = '0'+day;
			}else
				{
				todaydate=day;
				}

			var hour = now.getHours();
			var todayhour= hour.toString();
			var strhourlength = todayhour.length;
			var todayhour;
			if (strhourlength== 1){
				todayhour = '0'+hour;
			}else
				{
				todayhour=hour;
				}
			
			var minute = now.getMinutes();
			var todayminute= minute.toString();
			var strminutelength = todayminute.length;
			var todayminute;
			if (strminutelength== 1){
				todayminute = '0'+minute;
			}else
				{
				todayminute=minute;
				}
			
			var second = now.getSeconds();
			var todaysecond=second.toString();
			var strsecondlength = todaysecond.length;
			var todaysecond;
			if (strsecondlength== 1){
				todaysecond = '0'+todaysecond;
			}else
				{
				todaysecond=todaysecond;
				}
			var timestampframed =  year+'-'+todaymonth+'-'+todaydate+'T'+todayhour+':'+todayminute+':'+todaysecond+'Z';
			var finish = new Date(timestampframed);
	//	var finishtime = 1;
	//	finish.setTime(finish.getTime() + finishtime * 60 * 1000);
		
						var	ESTDateVar = finish.getTime();
						var	localOffset = finish.getTimezoneOffset() * 60000;
							var datestrng = finish.toString();
							var edt = "Eastern Daylight Time";
							var edt1 = "EDT";
							var offset;
							
						if(datestrng.includes(edt) || datestrng.includes(edt1)){
							
							offset = 4;
						}else{
							offset = 5;
						}
						var	utc = ESTDateVar + (3600000*offset);
						var	ESTDate = new Date(utc).toISOString();
						//ESTDate = ESTDate.replace('Z','');
	//	ctx.setVariable("finishtime", ESTDate);
			ctx.setVariable("timestampframed", ESTDate);
    	}
});
