var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var exitpayload = ilsctx.getVariable('exitpayload')
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var retry = ctx.getVariable('retry');
		var ExitStatusCode = ilsctx.getVariable('ExitStatus');
		var ErrorTxt = ilsctx.getVariable('ExitDescription')
		if (!(retry == 'yes')) {
			ilsctx.setVariable('exitStatus', '0');
			ilsctx.setVariable('exitDestination', session.parameters.omsurl);
			ilsctx.setVariable('Exitdescription', session.parameters.UpdateCrewRosterExitdescription)
		} else {
			ilsctx.setVariable('exitStatus', ExitStatusCode);
			ilsctx.setVariable('Exitdescription', ErrorTxt)
			ilsctx.setVariable('exitDestination', 'dpmq://foa_ohug_IIB_Retry_QMgr/?RequestQueue=RETRY.IIB.QUEUE')

		}
	}
	session.output.write(exitpayload)
});