var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
//var apiToken = session.parameters.TokenValue;
var urlopen = require('urlopen');
var apiToken = ctx.getVariable("apiToken");
var logger = console.options({
	'category': 'all'
});

function callURL(url, method, myctx,payload) {
	//logger.info("Inside callURL :: url" + url + ', '+ method+ ', '+ myctx);
	
    var options = {
        target: url,
        method: method,
        headers: {
            "osiApiToken": apiToken
        },
        contentType: "application/json",
        sslClientProfile: "omscms_oms_ssl_ClientProfile"
    };
    if (method == "POST" || method=="PATCH") {
        options.data = payload;
    }
 urlopen.open(options, function(error, response) {
        if (error) {
            // an error occurred during reading the file
        	
        	var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
			ctx.setVariable("retry", 'yes');
			logger.error("cms_001:urlopen connect error with omsAPI " + JSON.stringify(error));
			var ErrorTxt = "urlopen connect error with omsAPI" + JSON.stringify(error);
			ctx.setVariable("ErrorTxt", ErrorTxt);
			//session.reject("Connection Error---- :: ");
        } else {
            var responseStatusCode = response.statusCode;
            var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
            ctx.setVariable(myctx+'_StatusCode', responseStatusCode);
            if (responseStatusCode == 200) {
                response.readAsJSON(function(error, responseData) {
                    if (error) {
                        // error while reading response or transferring data to Buffer
                        logger.error("Error in reading the response data " + JSON.stringify(error));
						throw error;
                    } else {
						logger.info("success url response received" );
						var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
                        ctx.setVariable(myctx, responseData);
					}
                });
            } else {
            	logger.error("response returned from omsapi  call is "+responseStatusCode);
            }
        }
    });
}

module.exports = callURL;
