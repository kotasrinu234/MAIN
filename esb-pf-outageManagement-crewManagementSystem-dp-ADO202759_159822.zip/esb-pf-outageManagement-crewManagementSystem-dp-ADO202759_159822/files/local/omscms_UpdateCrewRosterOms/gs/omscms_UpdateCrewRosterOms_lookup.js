var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
var lookupURL = ctx.getVar("lookupURL");
var apiToken = ctx.getVar("apiToken");
var workGroup = ctx.getVar("workGroup");
var serviceCenter = ctx.getVar("serviceCenter");
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var lookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "crewTypes",
						"label": workGroup
					}
				]
			}
		}
		var crewLookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		console.log("crewTypes lookupmessage" + JSON.stringify(lookupMessage));
		var info = " TargetURL :" + crewLookupServiceResponse.target + "; Method :" + crewLookupServiceResponse.method + "; Data :" + JSON.stringify(crewLookupServiceResponse.data) + ". ";
		urlopen.open(crewLookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with crewLookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable("ExitDescription", errorinfo);
				ILSctx.setVariable("ExitStatus", '500')
				logger.error("urlopen connect error with crewLookupServiceResponse" + JSON.stringify(error));
				session.reject("urlopen connect error with crewLookupServiceResponse");
				//throw error;
			} else {

				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in putting message to  crewLookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable("ExitDescription", errorinfo);
							ILSctx.setVariable("ExitStatus", responseStatusCode)
							logger.error("failure in putting message to  crewLookupServiceResponse" + JSON.stringify(error));
							session.reject("failure in putting message to  crewLookupServiceResponse");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from  crewtypeLookupServiceResponse " + responseData);
							var crewLookupServiceResponse = JSON.parse(responseData)
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							//ctx.setVariable("crewLookupServiceResponse", crewLookupServiceResponse);
							//logger.debug("crewLookupServiceResponse----"+JSON.stringify(crewLookupServiceResponse));		
							var Id;
							var status;
							if (crewLookupServiceResponse.lookupRep.type[0].result == 0) {
								Id = crewLookupServiceResponse.lookupRep.type[0].id;
								status = crewLookupServiceResponse.lookupRep.type[0].status;
								var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
								ctx.setVariable("IdfromCrewTypes", Id);
								ctx.setVariable("statusfromLookupCrewTypes", status);
							} else {
								var errorinfo = "Id is not found from crewLookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("ExitStatus", responseStatusCode)
								logger.error("Id is not found from crewLookupServiceResponse");
								ctx.setVariable("IdfromCrewTypes", '');
								ctx.setVariable("statusfromLookupCrewTypes", '');
							}
						}
					});

				} else {
					var errorinfo = "crewLookupServiceResponse is not 200 , details are : " + info + "; error info :" + JSON.stringify(error);
					ILSctx.setVariable("ExitDescription", errorinfo);
					ILSctx.setVariable("ExitStatus", responseStatusCode)
					logger.error("crewLookupServiceResponse is not 200");
				}
			}

		});

		//Start : Aor lookup
		var aorIDArray = [];
		var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
		var serviceCenter = ctx.getVar("serviceCenter");
		var serviceCenterLen = incomingdata.serviceCenter.length;
		//logger.error("serviceCenterLen-----"+serviceCenterLen);
		if (serviceCenterLen == 3) {
			//logger.error("inside if condition-----");
			var serviceCenter = incomingdata.serviceCenter;
			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "aors",
						}
					]
				}
			}
			var aorLookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + aorLookupServiceResponse.target + "; Method :" + aorLookupServiceResponse.method + "; Data :" + JSON.stringify(aorLookupServiceResponse.data) + ". ";
			urlopen.open(aorLookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "urlopen connect error with aorLookupServiceResponse , details are : " + info + "; error info :" + JSON.stringify(error);
					ILSctx.setVariable("ExitDescription", errorinfo);
					ILSctx.setVariable("ExitStatus", '500')
					logger.error("urlopen connect error with aorLookupServiceResponse" + JSON.stringify(error));
					session.reject("urlopen connect error with lookupservice");
					//throw error;
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in putting message to  aorLookupServiceResponse , details are : " + info + "; error info :" + JSON.stringify(error);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("ExitStatus", responseStatusCode)
								logger.error("failure in putting message to  aorLookupServiceResponse" + JSON.stringify(error));
								session.reject("failure in putting message to  aorLookupServiceResponse");
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from  aor LookupServiceResponse " + responseData);
								var service_Center = incomingdata.serviceCenter;
								var aorLookupServiceResponse = JSON.parse(responseData);
								var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
								//ctx.setVariable("aorLookupServiceResponse", aorLookupServiceResponse);
								var respLength = aorLookupServiceResponse.lookupRep.type.length;
								var searchField = incomingdata.serviceCenter;
								for (var i = 0; i < respLength; i++) {
									var label = aorLookupServiceResponse.lookupRep.type[i].label;
									if (label === undefined || label === null || label === '') {
										var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
										ctx.setVariable("aorIDArray", aorIDArray);
									} else {
										var InternalPremiseIDS = label.slice(0, 3);
										if (searchField == InternalPremiseIDS) {
											var id = aorLookupServiceResponse.lookupRep.type[i].id;
											aorIDArray.push(id);
										}
									}
								}
								var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
								ctx.setVariable("aorIDArray", aorIDArray);
							}
						});
					} else {
						var errorinfo = "aorLookupSearchServiceResponse  response is not 200 , details are : " + info + "; error info :" + JSON.stringify(error);
						ILSctx.setVariable("ExitDescription", errorinfo);
						ILSctx.setVariable("ExitStatus", responseStatusCode)
						logger.error("aorLookupSearchServiceResponse  response is not 200");
					}
				}
			});
		} else {
			//logger.error("inside else  condition-----");
			logger.debug("Id is not found from aorLookupServiceResponse");
			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "aors",
							"label": serviceCenter
						}
					]
				}
			}
			var aorLookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + aorLookupServiceResponse.target + "; Method :" + aorLookupServiceResponse.method + "; Data :" + JSON.stringify(aorLookupServiceResponse.data) + ". ";
			urlopen.open(aorLookupServiceResponse, function(error, response) {
				if (error) {
					logger.error("urlopen connect error with aorLookupServiceResponse" + JSON.stringify(error));
					var errorinfo = "urlopen connect error with aorLookupServiceResponse , details are : " + info + "; error info :" + JSON.stringify(error);
					ILSctx.setVariable("ExitDescription", errorinfo);
					ILSctx.setVariable("ExitStatus", '500')
					session.reject("urlopen connect error with lookupservice");
					//throw error;
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("failure in putting message to  aorLookupServiceResponse" + JSON.stringify(error));
								var errorinfo = "failure in putting message to  aorLookupServiceResponse , details are : " + info + "; error info :" + JSON.stringify(error);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("ExitStatus", responseStatusCode)
								session.reject("failure in putting message to  aorLookupServiceResponse");
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from  aor LookupServiceResponse " + responseData);
								var aorLookupServiceResponse = JSON.parse(responseData)
								var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
								//ctx.setVariable("aorLookupServiceResponse", aorLookupServiceResponse);
								var Id;
								if (aorLookupServiceResponse.lookupRep.type[0].result == 0) {
									Id = aorLookupServiceResponse.lookupRep.type[0].id;
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									aorIDArray.push(Id);
									ctx.setVariable("aorIDArray", aorIDArray);
								}
							}
						});
					} else {
						var errorinfo = "aorLookupServiceResponse  response is not 200 , details are : " + info + "; error info :" + JSON.stringify(error);
						ILSctx.setVariable("ExitDescription", errorinfo);
						ILSctx.setVariable("ExitStatus", responseStatusCode)
						logger.error("aorLookupServiceResponse  response is not 200");
					}
				}
			});
		}



		//End: Aor Lookup
	}
});
