var getURLResponse = require('./urlopenutil.js');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
var omsExternalURL = ctx.getVar("omsExternalURL");
var timestamp = ctx.getVar("timestampframed");
var apiToken = ctx.getVar("apiToken");
var retry = ctx.getVar("retry");
var contactMethodtoAppIdMap = new Map([
	['1M', '1MAN'],
	['2M', '2MAN'],
	['3M', '3MAN'],
	['AP', 'APPRENTICE'],
	['1A', 'APPRENTICE WITHOUT LEADER'],
	['CM', 'CABLE MECHANIC'],
	['MH', 'CLEAN MANHOLE'],
	['CD', 'CONDUIT'],
	['PL', 'PULLING'],
	['ET', 'ENGINEERING TECHNICIAN'],
	['ES', 'EQUIPMENT SUPPLY'],
	['LC', 'LABOR'],
	['PH', 'POLE HAUL'],
	['PM', 'PUMP MANHOLE'],
	['RS', 'REGIONAL SPLICER'],
	['SET', 'SENIOR ENGINEERING TECHNICIAN'],
	['UO', 'OPERATING'],
	['SP', 'SPECIALIST'],
	['US', 'SPLICING'],
	['VM', 'VACUM MANHOLE']
]);

var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");

session.input.readAsJSON(function(error, incomingdata) {
ILSctx.setVariable("exitpayload", incomingdata);
	if (error) {
		logger.error("Connection Error");
		throw error;
	} else {
		if (retry == "yes") {
			session.output.write(incomingdata);
		}
		else {
			//Start: Check If Shift block is exist or not
			var ShiftLst = incomingdata.shifts;
			if (ShiftLst === null || ShiftLst === '' || ShiftLst === undefined) {
				logger.error("Unable to find empList from Shiftblock");
			} else {
				var ShiftLength = incomingdata.shifts.length;
				for (var i = 0; i < ShiftLength; i++) {
					var crewsLength = incomingdata.shifts[i].crews.length;
					for (var j = 0; j < crewsLength; j++) {
						var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
						for (var k = 0; k < crewMembersLength; k++) {
							var shiftCrewMemberCrewId = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
							//Make GET call for each CrewMember EmpId from Shifts block :GET:/api/v1/ServiceType/Electric/Crew/{id}
							var getShiftCrewMemberUrl = omsExternalURL + 'Crew/' + shiftCrewMemberCrewId;
							getShiftCrewMemberCall(getShiftCrewMemberUrl, 'GET', '', shiftCrewMemberCrewId);
						}
						var shiftCrewLeaderCrewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
						// Make GET call for each CrewLeader EmpId from Shifts block :GET:/api/v1/ServiceType/Electric/Crew/{id}
						var getShiftCrewLgetShiftCrewMemberCalleaderUrl = omsExternalURL + 'Crew/' + shiftCrewLeaderCrewId;
						getShiftCrewLeaderCall(getShiftCrewLgetShiftCrewMemberCalleaderUrl, 'GET', '', shiftCrewLeaderCrewId);
					}
				}
			}
			//End: Check If Shift block is exist or not	


			//Start : Check If UnAssign block is exist or not
			var unsasLst = incomingdata.unassigned;
			if (unsasLst === null || unsasLst === '' || unsasLst === undefined) {
				logger.debug("Unable to find crewList from Unassignedblock");
			} else {
				var unsasLst = incomingdata.unassigned.length;
				for (var i = 0; i < unsasLst; i++) {
					// Make GET call for each unassignedEmpId from UnAssigned block :GET:/api/v1/ServiceType/Electric/Crew/{id}
					var unAssignCrewId = incomingdata.unassigned[i].crewId;
					var getUnAssignUrl = omsExternalURL + 'Crew/' + unAssignCrewId;
					getUnAssignCall(getUnAssignUrl, 'GET', '', unAssignCrewId);
				}
			}
			//End: Check If UnAssign block is exist or not


			//Start: Check If supervisors block is exist or not
			var supervisorsLst = incomingdata.supervisors;
			if (supervisorsLst === null || supervisorsLst === '' || supervisorsLst === undefined) {
				logger.debug("Unable to find crewList from supervisorsblock");
			} else {
				var supervisorsLst = incomingdata.supervisors.length;
				for (var i = 0; i < supervisorsLst; i++) {
					// Make GET call for each supervisorEmpId from supervisors block :GET:/api/v1/ServiceType/Electric/Crew/{id}
					var supervisorsCrewId = incomingdata.supervisors[i].crewId;
					var getSupervisorsUrl = omsExternalURL + 'Crew/' + supervisorsCrewId;
					getSupervisorCall(getSupervisorsUrl, 'GET', '', supervisorsCrewId); 

				}
			}
			//End: Check If supervisors block is exist or not
		}
	}

	//Start :Make GET,PATCH and POST call to Create/Update the Shift CrewMember crewMemberEmpId

	function getShiftCrewMemberCall(url, method, payload, shiftCrewMemberCrewId) {
		var getShiftCrewMemberAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			}
		};
		var info = " TargetURL: " + getShiftCrewMemberAPI.target + "; Method: " + getShiftCrewMemberAPI.method + ". ";
		urlopen.open(getShiftCrewMemberAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				var errorinfo = "urlopen connect error with getShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				logger.error("cms_016:urlopen connect error with getShiftCrewMemberAPI" + JSON.stringify(error));
				var ErrorTxt = "urlopen connect error with getShiftCrewMemberAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to getShiftCrewMemberAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to getShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to getShiftCrewMemberAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from getShiftCrewMemberAPI for empId:" + shiftCrewMemberCrewId + "" + responseStatusCode);
							var getShiftCrewMemberAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("getShiftCrewMemberAPIResponse", getShiftCrewMemberAPIResponse);
							var ShiftLength = incomingdata.shifts.length;
							for (var i = 0; i < ShiftLength; i++) {
								var crewsLength = incomingdata.shifts[i].crews.length;
								for (var j = 0; j < crewsLength; j++) {
									var getShiftCrewLeader_CrewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
									var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
									for (var k = 0; k < crewMembersLength; k++) {
										var getShiftCrewMember_CrewId = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
										if (getShiftCrewMember_CrewId === shiftCrewMemberCrewId) {
											var fname = incomingdata.shifts[i].crews[j].crewMembers[k].firstName;
											var lname = incomingdata.shifts[i].crews[j].crewMembers[k].lastName;

											var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");

											var customFieldValues = {};
											var payload = {};


											if (getShiftCrewLeader_CrewId != null || getShiftCrewLeader_CrewId != '' || getShiftCrewLeader_CrewId != undefined) {
												customFieldValues.Crew_Leader = incomingdata.shifts[i].crews[j].crewLeader.crewId;
											}

											/*if(aorID != null || aorID != '' || aorID != undefined){ 
												payload.aorIDs = aorID;
											 }*/

											//start
											if (getShiftCrewMember_CrewId != null || getShiftCrewMember_CrewId != '' || getShiftCrewMember_CrewId != undefined) {
												payload.externalID = getShiftCrewMember_CrewId;
											}
											if (incomingdata.shifts[i].crews[j].crewMembers[k].empUserId !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].empUserId !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].empUserId !== '') {
												customFieldValues.employeeid = incomingdata.shifts[i].crews[j].crewMembers[k].empUserId;
											}
											if (incomingdata.shifts[i].crews[j].crewMembers[k].crewId != null || incomingdata.shifts[i].crews[j].crewMembers[k].crewId != '' || incomingdata.shifts[i].crews[j].crewMembers[k].crewId != undefined) {
												customFieldValues.CrewID = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
											}
											//end 

											if (incomingdata.shifts[i].startTime != null || incomingdata.shifts[i].startTime != '' || incomingdata.shifts[i].startTime != undefined) {
												customFieldValues.startTime = incomingdata.shifts[i].startTime;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone != null || incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone != '' || incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone != undefined) {
												payload.phoneNumber = incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone;
											}

											payload.name = fname + ' ' + lname;

											if (incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.name !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.name !== '') {
												customFieldValues.vehiclename = incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.name;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.radio !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.radio !== undefined) {
												customFieldValues.vehicleradio = incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.radio;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.vehicleId !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.vehicleId !== undefined) {
												customFieldValues.vehicleId = incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.vehicleId;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.name !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.name !== undefined) {
												customFieldValues.secondaryVehicleName = incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.name;
											}
											if (incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.radio !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.radio !== undefined) {
												customFieldValues.secondaryVehicleRadio = incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.radio;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.vehicleId !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.vehicleId !== undefined) {
												customFieldValues.secondaryVehicleId = incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.vehicleId;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].classification != null || incomingdata.shifts[i].crews[j].crewMembers[k].classification != '' || incomingdata.shifts[i].crews[j].crewMembers[k].classification != undefined) {
												customFieldValues.EngineerType = incomingdata.shifts[i].crews[j].crewMembers[k].classification;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].oot != null || incomingdata.shifts[i].crews[j].crewMembers[k].oot != '' || incomingdata.shifts[i].crews[j].crewMembers[k].oot != undefined) {
												customFieldValues.oot = JSON.stringify(incomingdata.shifts[i].crews[j].crewMembers[k].oot);
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].phone != null || incomingdata.shifts[i].crews[j].crewMembers[k].phone != '' || incomingdata.shifts[i].crews[j].crewMembers[k].phone != undefined) {
												customFieldValues.secondaryPhoneNumber = incomingdata.shifts[i].crews[j].crewMembers[k].phone;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].rc != null || incomingdata.shifts[i].crews[j].crewMembers[k].rc != '' || incomingdata.shifts[i].crews[j].crewMembers[k].rc != undefined) {
												customFieldValues.rc = incomingdata.shifts[i].crews[j].crewMembers[k].rc;
											}
											if (incomingdata.shifts[i].crews[j].crewMembers[k].rcLeader != null || incomingdata.shifts[i].crews[j].crewMembers[k].rcLeader != '' || incomingdata.shifts[i].crews[j].crewMembers[k].rcLeader != undefined) {
												customFieldValues.rcLeader = incomingdata.shifts[i].crews[j].crewMembers[k].rcLeader;
											}



											if (incomingdata.rosterDate != null || incomingdata.rosterDate != '' || incomingdata.rosterDate != undefined) {
												customFieldValues.rosterDate = incomingdata.rosterDate;
											}

											if (incomingdata.createdTimestamp != null || incomingdata.createdTimestamp != '' || incomingdata.createdTimestamp != undefined) {
												customFieldValues.createdTimeStamp = incomingdata.createdTimestamp;
											}
											if (incomingdata.rosterNotes != null || incomingdata.rosterNotes != '' || incomingdata.rosterNotes != undefined) {
												customFieldValues.rosterNotes = incomingdata.rosterNotes;
											}
											if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].notes != '' || incomingdata.shifts[i].crews[j].notes != undefined) {
												customFieldValues.notes = incomingdata.shifts[i].crews[j].notes;
											}

											if (incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition != null || incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition != '' || incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition != undefined) {
												customFieldValues.crew_position = incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition;
											}

											customFieldValues.isLeader = "FALSE";

											payload.customFieldValues = customFieldValues;
											var getShiftCrewMemberPatchUrl = omsExternalURL + 'Crew/' + shiftCrewMemberCrewId
											var idTopass = getShiftCrewMemberAPIResponse.id
											patchShiftCrewMemberCall(getShiftCrewMemberPatchUrl, 'PATCH', payload, shiftCrewMemberCrewId, idTopass);
										}
									}
								}
							}

						}
					});
				} else {
					//Start if Shift CrewMemberCrewId not found 
					logger.debug("Unable to find the empId details in getShiftCrewMemberAPI call shiftCrewMemberCrewId " + " " + shiftCrewMemberCrewId + " " + "responseStatusCode" + " " + responseStatusCode);

					var ShiftLength = incomingdata.shifts.length;
					for (var i = 0; i < ShiftLength; i++) {
						var crewsLength = incomingdata.shifts[i].crews.length;
						for (var j = 0; j < crewsLength; j++) {
							var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
							var getShiftCrewLeader_CrewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
							for (var k = 0; k < crewMembersLength; k++) {
								var shiftCrew_Id = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
								if (shiftCrew_Id === shiftCrewMemberCrewId) {
									var fname = incomingdata.shifts[i].crews[j].crewMembers[k].firstName;
									var lname = incomingdata.shifts[i].crews[j].crewMembers[k].lastName;
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									var aorID = ctx.getVar("aorIDArray");
									var crewtype = ctx.getVar("statusfromLookupCrewTypes");
									var customFieldValues = {};
									var payload = {};
									var externalIDcustomFieldValues = {};

									if (getShiftCrewLeader_CrewId != null || getShiftCrewLeader_CrewId != '' || getShiftCrewLeader_CrewId != undefined) {
										customFieldValues.Crew_Leader = incomingdata.shifts[i].crews[j].crewLeader.crewId;
									}

									if (aorID != null || aorID != '' || aorID != undefined) {
										payload.aorIDs = aorID;
									}
									if (crewtype != null || crewtype != '' || crewtype != undefined) {
										payload.type = crewtype;
									}

									//start
									if (shiftCrewMemberCrewId != null || shiftCrewMemberCrewId != '' || shiftCrewMemberCrewId != undefined) {
										payload.externalID = shiftCrewMemberCrewId;
									}
									if (incomingdata.shifts[i].crews[j].crewMembers[k].empUserId !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].empUserId !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].empUserId !== '') {
										customFieldValues.employeeid = incomingdata.shifts[i].crews[j].crewMembers[k].empUserId;
									}
									if (incomingdata.shifts[i].crews[j].crewMembers[k].crewId != null || incomingdata.shifts[i].crews[j].crewMembers[k].crewId != '' || incomingdata.shifts[i].crews[j].crewMembers[k].crewId != undefined) {
										customFieldValues.CrewID = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
									}
									//end 

									if (incomingdata.shifts[i].crews[j].crewMembers[k].crewId != null || incomingdata.shifts[i].crews[j].crewMembers[k].crewId != '' || incomingdata.shifts[i].crews[j].crewMembers[k].crewId != undefined) {
										customFieldValues.CrewID = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
									}

									if (incomingdata.shifts[i].startTime != null || incomingdata.shifts[i].startTime != '' || incomingdata.shifts[i].startTime != undefined) {
										customFieldValues.startTime = incomingdata.shifts[i].startTime;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone != null || incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone != '' || incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone != undefined) {
										payload.phoneNumber = incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone;
									}

									payload.name = fname + ' ' + lname;

									if (incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.name !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.name !== '') {
										customFieldValues.vehiclename = incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.name;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.radio !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.radio !== undefined) {
										customFieldValues.vehicleradio = incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.radio;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.vehicleId !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.vehicleId !== undefined) {
										customFieldValues.vehicleId = incomingdata.shifts[i].crews[j].crewMembers[k].primaryVehicle.vehicleId;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.name !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.name !== undefined) {
										customFieldValues.secondaryVehicleName = incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.name;
									}
									if (incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.radio !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.radio !== undefined) {
										customFieldValues.secondaryVehicleRadio = incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.radio;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.vehicleId !== '' && incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.vehicleId !== undefined) {
										customFieldValues.secondaryVehicleId = incomingdata.shifts[i].crews[j].crewMembers[k].secondaryVehicle.vehicleId;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].classification != null || incomingdata.shifts[i].crews[j].crewMembers[k].classification != '' || incomingdata.shifts[i].crews[j].crewMembers[k].classification != undefined) {
										customFieldValues.EngineerType = incomingdata.shifts[i].crews[j].crewMembers[k].classification;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].oot != null || incomingdata.shifts[i].crews[j].crewMembers[k].oot != '' || incomingdata.shifts[i].crews[j].crewMembers[k].oot != undefined) {
										customFieldValues.oot = JSON.stringify(incomingdata.shifts[i].crews[j].crewMembers[k].oot);
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].phone != null || incomingdata.shifts[i].crews[j].crewMembers[k].phone != '' || incomingdata.shifts[i].crews[j].crewMembers[k].phone != undefined) {
										customFieldValues.secondaryPhoneNumber = incomingdata.shifts[i].crews[j].crewMembers[k].phone;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].rc != null || incomingdata.shifts[i].crews[j].crewMembers[k].rc != '' || incomingdata.shifts[i].crews[j].crewMembers[k].rc != undefined) {
										customFieldValues.rc = incomingdata.shifts[i].crews[j].crewMembers[k].rc;
									}
									if (incomingdata.shifts[i].crews[j].crewMembers[k].rcLeader != null || incomingdata.shifts[i].crews[j].crewMembers[k].rcLeader != '' || incomingdata.shifts[i].crews[j].crewMembers[k].rcLeader != undefined) {
										customFieldValues.rcLeader = incomingdata.shifts[i].crews[j].crewMembers[k].rcLeader;
									}
									if (incomingdata.rosterDate != null || incomingdata.rosterDate != '' || incomingdata.rosterDate != undefined) {
										customFieldValues.rosterDate = incomingdata.rosterDate;
									}
									if (incomingdata.createdTimestamp != null || incomingdata.createdTimestamp != '' || incomingdata.createdTimestamp != undefined) {
										customFieldValues.createdTimeStamp = incomingdata.createdTimestamp;
									}
									if (incomingdata.rosterNotes != null || incomingdata.rosterNotes != '' || incomingdata.rosterNotes != undefined) {
										customFieldValues.rosterNotes = incomingdata.rosterNotes;
									}
									if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].notes != '' || incomingdata.shifts[i].crews[j].notes != undefined) {
										customFieldValues.notes = incomingdata.shifts[i].crews[j].notes;
									}

									if (incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition != null || incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition != '' || incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition != undefined) {
										customFieldValues.crew_position = incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition;
									}
									customFieldValues.isLeader = "FALSE";

									payload.customFieldValues = customFieldValues;
									var postShiftCrewMemberUrl = omsExternalURL + 'Crew'
									postShiftCrewMemberCall(postShiftCrewMemberUrl, 'POST', payload, shiftCrewMemberCrewId);
								}
							}
						}
					}
				}//end if crewId not found
			}
		});
	}
	//End :Make GET,PATCH and POST call to Create/Update the Shift CrewMember crewMembeCrewId


	//Start :Make GET,PATCH and POST call to Create/Update the shiftCrewLeaderCrewId
	function getShiftCrewLeaderCall(url, method, payload, shiftCrewLeaderCrewId) {
		var getShiftCrewLeaderAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			}
		};
		var info = " TargetURL: " + getShiftCrewLeaderAPI.target + "; Method: " + getShiftCrewLeaderAPI.method + ". ";
		urlopen.open(getShiftCrewLeaderAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("cms_017:urlopen connect error with getShiftCrewLeaderAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with getShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with getShiftCrewLeaderAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to getShiftCrewLeaderAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to getShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to getShiftCrewLeaderAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from getShiftCrewLeaderAPI for crewId:" + shiftCrewLeaderCrewId + "" + responseStatusCode);
							var getShiftCrewLeaderAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("getShiftCrewLeaderAPIResponse", getShiftCrewLeaderAPIResponse);
							var ShiftLength = incomingdata.shifts.length;
							for (var i = 0; i < ShiftLength; i++) {
								var crewsLength = incomingdata.shifts[i].crews.length;
								var crewsLength = incomingdata.shifts[i].crews.length;
								for (var j = 0; j < crewsLength; j++) {
									//start
									var getShiftCrewLeader_crewId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
									if (getShiftCrewLeader_crewId === shiftCrewLeaderCrewId) {
										var fname = incomingdata.shifts[i].crews[j].crewLeader.firstName;
										var lname = incomingdata.shifts[i].crews[j].crewLeader.lastName;
										var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
										//var aorID = ctx.getVar("aorIDArray"); 
										var customFieldValues = {};
										var externalIDcustomFieldValues = {};
										var payload = {};

										/*if(aorID != null || aorID != '' || aorID != undefined){ 
											   payload.aorIDs = aorID;
											   }*/

										//start
										if (shiftCrewLeaderCrewId != null || shiftCrewLeaderCrewId != '' || shiftCrewLeaderCrewId != undefined) {
											payload.externalID = shiftCrewLeaderCrewId;
										}
										if (incomingdata.shifts[i].crews[j].crewLeader.empUserId !== undefined && incomingdata.shifts[i].crews[j].crewLeader.empUserId !== undefined && incomingdata.shifts[i].crews[j].crewLeader.empUserId !== '') {
											customFieldValues.employeeid = incomingdata.shifts[i].crews[j].crewLeader.empUserId;
										}
										if (incomingdata.shifts[i].crews[j].crewLeader.crewId != null || incomingdata.shifts[i].crews[j].crewLeader.crewId != '' || incomingdata.shifts[i].crews[j].crewLeader.crewId != undefined) {
											customFieldValues.CrewID = incomingdata.shifts[i].crews[j].crewLeader.crewId;
										}
										//end 

										if (incomingdata.shifts[i].crews[j].crewLeader.cellPhone != null || incomingdata.shifts[i].crews[j].crewLeader != '' || incomingdata.shifts[i].crews[j].crewLeader != undefined) {
											payload.phoneNumber = incomingdata.shifts[i].crews[j].crewLeader;
										}

										payload.name = fname + ' ' + lname;

										if (incomingdata.shifts[i].crews[j].crewLeader.classification != null || incomingdata.shifts[i].crews[j].crewLeader.classification != '' || incomingdata.shifts[i].crews[j].crewLeader.classification != undefined) {
											customFieldValues.EngineerType = incomingdata.shifts[i].crews[j].crewLeader.classification;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader.cellPhone != null || incomingdata.shifts[i].crews[j].crewLeader.cellPhone != '' || incomingdata.shifts[i].crews[j].crewLeader.cellPhone != undefined) {
											payload.phoneNumber = incomingdata.shifts[i].crews[j].crewLeader.cellPhone;
										}

										if (incomingdata.shifts[i].startTime != null || incomingdata.shifts[i].startTime != '' || incomingdata.shifts[i].startTime != undefined) {
											customFieldValues.startTime = incomingdata.shifts[i].startTime;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.name !== undefined && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.name !== '') {
											customFieldValues.vehiclename = incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.name;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.radio !== '' && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.radio !== undefined) {
											customFieldValues.vehicleradio = incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.radio;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.vehicleId !== '' && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.vehicleId !== undefined) {
											customFieldValues.vehicleId = incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.vehicleId;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.name !== '' && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.name !== undefined) {
											customFieldValues.secondaryVehicleName = incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.name;
										}
										if (incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.radio !== '' && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.radio !== undefined) {
											customFieldValues.secondaryVehicleRadio = incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.radio;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.vehicleId !== '' && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.vehicleId !== undefined) {
											customFieldValues.secondaryVehicleId = incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.vehicleId;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader.oot != null || incomingdata.shifts[i].crews[j].crewLeader.oot != '' || incomingdata.shifts[i].crews[j].crewLeader.oot != undefined) {
											customFieldValues.oot = JSON.stringify(incomingdata.shifts[i].crews[j].crewLeader.oot);
										}

										if (incomingdata.shifts[i].crews[j].crewLeader !== undefined || incomingdata.shifts[i].crews[j].crewLeader.phone != '' || incomingdata.shifts[i].crews[j].crewLeader.phone != undefined) {
											customFieldValues.secondaryPhoneNumber = incomingdata.shifts[i].crews[j].crewLeader.phone;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader !== undefined || incomingdata.shifts[i].crews[j].crewLeader.rc != '' || incomingdata.shifts[i].crews[j].crewLeader.rc != undefined) {
											customFieldValues.rc = incomingdata.shifts[i].crews[j].crewLeader.rc;
										}
										if (incomingdata.shifts[i].crews[j].crewLeader !== undefined || incomingdata.shifts[i].crews[j].crewLeader.rcLeader != '' || incomingdata.shifts[i].crews[j].crewLeader.rcLeader != undefined) {
											customFieldValues.rcLeader = incomingdata.shifts[i].crews[j].crewLeader.rcLeader;
										}

										if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].nodeStart != '' || incomingdata.shifts[i].crews[j].nodeStart != undefined) {
											customFieldValues.nodeStart = incomingdata.shifts[i].crews[j].nodeStart;
										}

										if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].isTrouble != '' || incomingdata.shifts[i].crews[j].isTrouble != undefined) {
											customFieldValues.isTrouble = JSON.stringify(incomingdata.shifts[i].crews[j].isTrouble);
										}
										if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].notes != '' || incomingdata.shifts[i].crews[j].notes != undefined) {
											customFieldValues.notes = incomingdata.shifts[i].crews[j].notes;
										}
										if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].crewType != '' || incomingdata.shifts[i].crews[j].crewType != undefined) {
											var crewType_compliment = incomingdata.shifts[i].crews[j].crewType;
											if (contactMethodtoAppIdMap.has(crewType_compliment.toString())) {
												customFieldValues.Crew_Compliment = contactMethodtoAppIdMap.get(crewType_compliment.toString());
											} else {
												customFieldValues.Crew_Compliment = "";
											}
										}

										customFieldValues.IsSupervisor = "TRUE";

										if (incomingdata.rosterDate != null || incomingdata.rosterDate != '' || incomingdata.rosterDate != undefined) {
											customFieldValues.rosterDate = incomingdata.rosterDate;
										}
										if (incomingdata.createdTimestamp != null || incomingdata.createdTimestamp != '' || incomingdata.createdTimestamp != undefined) {
											customFieldValues.createdTimeStamp = incomingdata.createdTimestamp;
										}
										if (incomingdata.rosterNotes != null || incomingdata.rosterNotes != '' || incomingdata.rosterNotes != undefined) {
											customFieldValues.rosterNotes = incomingdata.rosterNotes;
										}

										if (incomingdata.shifts[i].crews[j].crewLeader.crewPosition != null || incomingdata.shifts[i].crews[j].crewLeader.crewPosition != '' || incomingdata.shifts[i].crews[j].crewLeader.crewPosition != undefined) {
											customFieldValues.crew_position = incomingdata.shifts[i].crews[j].crewLeader.crewPosition;
										}

										customFieldValues.isLeader = "TRUE";

										//start   
										var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
										var crew_members = [];
										for (var k = 0; k < crewMembersLength; k++) {
											var custom_crewId = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
											var custom_fname = incomingdata.shifts[i].crews[j].crewMembers[k].firstName;
											var custom_lname = incomingdata.shifts[i].crews[j].crewMembers[k].lastName;
											var custom_cellPhone = incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone;
											var custom_crewPosition = incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition;
											var crew_memPayload = {
												"crew_member_ID": custom_crewId,
												"crew_member_name": custom_fname + ' ' + custom_lname,
												"crew_member_phone": custom_cellPhone,
												"crew_member_position": custom_crewPosition
											}
											crew_members.push(crew_memPayload);

											var customTableValues = {
												crew_members
											};
										}
										//end 
										payload.customFieldValues = customFieldValues;
										payload.customTableValues = customTableValues;
										var getShiftCrewLeadePatchUrl = omsExternalURL + 'Crew/' + shiftCrewLeaderCrewId
										var getShiftCrewLeadId = getShiftCrewLeaderAPIResponse.id
										patchShiftCrewLeaderCall(getShiftCrewLeadePatchUrl, 'PATCH', payload, shiftCrewLeaderCrewId, getShiftCrewLeadId);
									}
									// }
									//}
								}
							}
						}
					});
				} else {
					//Start if ShiftCrewLeaderCrewId not found 
					logger.debug("Unable to find the crewId details in getShiftCrewLeaderCrewId API call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode);

					var ShiftLength = incomingdata.shifts.length;
					for (var i = 0; i < ShiftLength; i++) {
						var crewsLength = incomingdata.shifts[i].crews.length;
						for (var j = 0; j < crewsLength; j++) {
							var getShiftCrewLeader_EmpId = incomingdata.shifts[i].crews[j].crewLeader.crewId;
							if (getShiftCrewLeader_EmpId === shiftCrewLeaderCrewId) {
								var fname = incomingdata.shifts[i].crews[j].crewLeader.firstName;
								var lname = incomingdata.shifts[i].crews[j].crewLeader.lastName;
								var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
								var aorID = ctx.getVar("aorIDArray");
								var crewtype = ctx.getVar("statusfromLookupCrewTypes");
								var customFieldValues = {};
								var payload = {};
								var externalIDcustomFieldValues = {};
								if (aorID != null || aorID != '' || aorID != undefined) {
									payload.aorIDs = aorID;
								}

								if (crewtype != null || crewtype != '' || crewtype != undefined) {
									payload.type = crewtype;
								}
								//start
								if (shiftCrewLeaderCrewId != null || shiftCrewLeaderCrewId != '' || shiftCrewLeaderCrewId != undefined) {
									payload.externalID = shiftCrewLeaderCrewId;
								}
								if (incomingdata.shifts[i].crews[j].crewLeader.empUserId !== undefined && incomingdata.shifts[i].crews[j].crewLeader.empUserId !== undefined && incomingdata.shifts[i].crews[j].crewLeader.empUserId !== '') {
									customFieldValues.employeeid = incomingdata.shifts[i].crews[j].crewLeader.empUserId;
								}
								if (incomingdata.shifts[i].crews[j].crewLeader.crewId != null || incomingdata.shifts[i].crews[j].crewLeader.crewId != '' || incomingdata.shifts[i].crews[j].crewLeader.crewId != undefined) {
									customFieldValues.CrewID = incomingdata.shifts[i].crews[j].crewLeader.crewId;
								}
								//end 
								if (incomingdata.shifts[i].crews[j].crewLeader.cellPhone != null || incomingdata.shifts[i].crews[j].crewLeader != '' || incomingdata.shifts[i].crews[j].crewLeader != undefined) {
									payload.phoneNumber = incomingdata.shifts[i].crews[j].crewLeader;
								}

								payload.name = fname + ' ' + lname;

								if (incomingdata.shifts[i].startTime != null || incomingdata.shifts[i].startTime != '' || incomingdata.shifts[i].startTime != undefined) {
									customFieldValues.startTime = incomingdata.shifts[i].startTime;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader.classification != null || incomingdata.shifts[i].crews[j].crewLeader.classification != '' || incomingdata.shifts[i].crews[j].crewLeader.classification != undefined) {
									customFieldValues.EngineerType = incomingdata.shifts[i].crews[j].crewLeader.classification;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader.cellPhone != null || incomingdata.shifts[i].crews[j].crewLeader.cellPhone != '' || incomingdata.shifts[i].crews[j].crewLeader.cellPhone != undefined) {
									payload.phoneNumber = incomingdata.shifts[i].crews[j].crewLeader.cellPhone;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.name !== undefined && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.name !== '') {
									customFieldValues.vehiclename = incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.name;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.radio !== '' && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.radio !== undefined) {
									customFieldValues.vehicleradio = incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.radio;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.vehicleId !== '' && incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.vehicleId !== undefined) {
									customFieldValues.vehicleId = incomingdata.shifts[i].crews[j].crewLeader.primaryVehicle.vehicleId;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.name !== '' && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.name !== undefined) {
									customFieldValues.secondaryVehicleName = incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.name;
								}
								if (incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.radio !== '' && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.radio !== undefined) {
									customFieldValues.secondaryVehicleRadio = incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.radio;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle !== undefined && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.vehicleId !== '' && incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.vehicleId !== undefined) {
									customFieldValues.secondaryVehicleId = incomingdata.shifts[i].crews[j].crewLeader.secondaryVehicle.vehicleId;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader !== undefined || incomingdata.shifts[i].crews[j].crewLeader.oot != '' || incomingdata.shifts[i].crews[j].crewLeader.oot != undefined) {
									customFieldValues.oot = JSON.stringify(incomingdata.shifts[i].crews[j].crewLeader.oot);
								}

								if (incomingdata.shifts[i].crews[j].crewLeader !== undefined || incomingdata.shifts[i].crews[j].crewLeader.phone != '' || incomingdata.shifts[i].crews[j].crewLeader.phone != undefined) {
									customFieldValues.secondaryPhoneNumber = incomingdata.shifts[i].crews[j].crewLeader.phone;
								}

								if (incomingdata.shifts[i].crews[j].crewLeader !== undefined || incomingdata.shifts[i].crews[j].crewLeader.rc != '' || incomingdata.shifts[i].crews[j].crewLeader.rc != undefined) {
									customFieldValues.rc = incomingdata.shifts[i].crews[j].crewLeader.rc;
								}
								if (incomingdata.shifts[i].crews[j].crewLeader !== undefined || incomingdata.shifts[i].crews[j].crewLeader.rcLeader != '' || incomingdata.shifts[i].crews[j].crewLeader.rcLeader != undefined) {
									customFieldValues.rcLeader = incomingdata.shifts[i].crews[j].rcLeader;
								}

								if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].nodeStart != '' || incomingdata.shifts[i].crews[j].nodeStart != undefined) {
									customFieldValues.nodeStart = incomingdata.shifts[i].crews[j].nodeStart;
								}

								if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].isTrouble != '' || incomingdata.shifts[i].crews[j].isTrouble != undefined) {
									customFieldValues.isTrouble = JSON.stringify(incomingdata.shifts[i].crews[j].isTrouble);
								}
								if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].notes != '' || incomingdata.shifts[i].crews[j].notes != undefined) {
									customFieldValues.notes = incomingdata.shifts[i].crews[j].notes;
								}

								if (incomingdata.shifts[i].crews[j] !== undefined || incomingdata.shifts[i].crews[j].crewType != '' || incomingdata.shifts[i].crews[j].crewType != undefined) {
									var crewType_compliment = incomingdata.shifts[i].crews[j].crewType;
									if (contactMethodtoAppIdMap.has(crewType_compliment.toString())) {
										customFieldValues.Crew_Compliment = contactMethodtoAppIdMap.get(crewType_compliment.toString());
									} else {
										customFieldValues.Crew_Compliment = "";
									}
								}

								if (incomingdata.rosterDate != null || incomingdata.rosterDate != '' || incomingdata.rosterDate != undefined) {
									customFieldValues.rosterDate = incomingdata.rosterDate;
								}
								if (incomingdata.createdTimestamp != null || incomingdata.createdTimestamp != '' || incomingdata.createdTimestamp != undefined) {
									customFieldValues.createdTimeStamp = incomingdata.createdTimestamp;
								}
								if (incomingdata.rosterNotes != null || incomingdata.rosterNotes != '' || incomingdata.rosterNotes != undefined) {
									customFieldValues.rosterNotes = incomingdata.rosterNotes;
								}
								customFieldValues.IsSupervisor = "TRUE";

								if (incomingdata.shifts[i].crews[j].crewLeader.crewPosition != null || incomingdata.shifts[i].crews[j].crewLeader.crewPosition != '' || incomingdata.shifts[i].crews[j].crewLeader.crewPosition != undefined) {
									customFieldValues.crew_position = incomingdata.shifts[i].crews[j].crewLeader.crewPosition;
								}

								customFieldValues.isLeader = "TRUE";
								//start   
								var crewMembersLength = incomingdata.shifts[i].crews[j].crewMembers.length;
								var crew_members = [];
								for (var k = 0; k < crewMembersLength; k++) {
									var custom_crewId = incomingdata.shifts[i].crews[j].crewMembers[k].crewId;
									var custom_fname = incomingdata.shifts[i].crews[j].crewMembers[k].firstName;
									var custom_lname = incomingdata.shifts[i].crews[j].crewMembers[k].lastName;
									var custom_cellPhone = incomingdata.shifts[i].crews[j].crewMembers[k].cellPhone;
									var custom_crewPosition = incomingdata.shifts[i].crews[j].crewMembers[k].crewPosition;
									var crew_memPayload = {
										"crew_member_ID": custom_crewId,
										"crew_member_name": custom_fname + ' ' + custom_lname,
										"crew_member_phone": custom_cellPhone,
										"crew_member_position": custom_crewPosition
									}
									crew_members.push(crew_memPayload);

									var customTableValues = {
										crew_members
									};
								}
								//end 

								payload.customFieldValues = customFieldValues;
								payload.customTableValues = customTableValues;
								var postShiftCrewLeaderUrl = omsExternalURL + 'Crew'
								postShiftCrewLeaderCall(postShiftCrewLeaderUrl, 'POST', payload, shiftCrewLeaderCrewId);
							}
						}
					}
				}//end if crewId not found
			}
		});
	}
	//End :Make GET,PATCH and POST call to Create/Update the  shiftCrewLeaderCrewId


	//Start :Make GET,PATCH and POST call to Create/Update the UnAssignedCrewId's
	function getUnAssignCall(url, method, payload, unAssignCrewId) {
		var getUnAssignAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			}
		};
		var info = " TargetURL: " + getUnAssignAPI.target + "; Method: " + getUnAssignAPI.method + ". ";
		urlopen.open(getUnAssignAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("cms_018:urlopen connect error with getUnAssignCrewAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with getUnAssignCrewAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with getUnAssignCrewAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to getUnAssignAPI" + JSON.stringify(error));
							var errorinfo = "urlopen connect error with getShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to getUnAssignAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from getUnAssignAPI for crewId:" + unAssignCrewId + "" + responseStatusCode);
							var getUnAssignResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("getUnAssignResponse", getUnAssignResponse);
							var unAssignedLength = incomingdata.unassigned.length;
							for (var i = 0; i < unAssignedLength; i++) {
								var unAssigned_crewId = incomingdata.unassigned[i].crewId;
								if (unAssigned_crewId === unAssignCrewId) {
									var fname = incomingdata.unassigned[i].firstName;
									var lname = incomingdata.unassigned[i].lastName;
									var crewId = incomingdata.unassigned[i].crewId;
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									//var aorID = ctx.getVar("aorIDArray"); 
									var customFieldValues = {};
									var externalIDcustomFieldValues = {};
									var payload = {};

									/*if(aorID != null || aorID != '' || aorID != undefined){ 
										payload.aorIDs = aorID;
										}*/

									if (incomingdata.unassigned[i].startTime != null || incomingdata.unassigned[i].startTime != '' || incomingdata.unassigned[i].startTime != undefined) {
										customFieldValues.startTime = incomingdata.unassigned[i].startTime;
									}
									//start

									if (crewId != null || crewId != '' || crewId != undefined) {
										payload.externalID = crewId;
									}

									if (incomingdata.unassigned[i].empUserId !== undefined && incomingdata.unassigned[i].empUserId !== undefined && incomingdata.unassigned[i].empUserId !== '') {
										customFieldValues.employeeid = incomingdata.unassigned[i].empUserId;
									}

									if (incomingdata.unassigned[i].crewId != null || incomingdata.unassigned[i].crewId != '' || incomingdata.unassigned[i].crewId != undefined) {
										customFieldValues.CrewID = crewId;
									}
									//end 

									if (incomingdata.unassigned[i].cellPhone != null || incomingdata.unassigned[i].cellPhone != '' || incomingdata.unassigned[i].cellPhone != undefined) {
										payload.phoneNumber = incomingdata.unassigned[i].cellPhone;
									}

									payload.name = fname + ' ' + lname;


									if (incomingdata.unassigned[i].primaryVehicle !== undefined && incomingdata.unassigned[i].primaryVehicle.name !== undefined && incomingdata.unassigned[i].primaryVehicle.name !== '') {
										customFieldValues.vehiclename = incomingdata.unassigned[i].primaryVehicle.name;
									}

									if (incomingdata.unassigned[i].primaryVehicle !== undefined && incomingdata.unassigned[i].primaryVehicle.radio !== '' && incomingdata.unassigned[i].primaryVehicle.radio !== undefined) {
										customFieldValues.vehicleradio = incomingdata.unassigned[i].primaryVehicle.radio;
									}

									if (incomingdata.unassigned[i].primaryVehicle !== undefined && incomingdata.unassigned[i].primaryVehicle.vehicleId !== '' && incomingdata.unassigned[i].primaryVehicle.vehicleId !== undefined) {
										customFieldValues.vehicleId = incomingdata.unassigned[i].primaryVehicle.vehicleId;
									}

									if (incomingdata.unassigned[i].secondaryVehicle !== undefined && incomingdata.unassigned[i].secondaryVehicle.name !== '' && incomingdata.unassigned[i].secondaryVehicle.name !== undefined) {
										customFieldValues.secondaryVehicleName = incomingdata.unassigned[i].secondaryVehicle.name;
									}
									if (incomingdata.unassigned[i].secondaryVehicle !== undefined && incomingdata.unassigned[i].secondaryVehicle.radio !== '' && incomingdata.unassigned[i].secondaryVehicle.radio !== undefined) {
										customFieldValues.secondaryVehicleRadio = incomingdata.unassigned[i].secondaryVehicle.radio;
									}

									if (incomingdata.unassigned[i].secondaryVehicle !== undefined && incomingdata.unassigned[i].secondaryVehicle.vehicleId !== '' && incomingdata.unassigned[i].secondaryVehicle.vehicleId !== undefined) {
										customFieldValues.secondaryVehicleId = incomingdata.unassigned[i].secondaryVehicle.vehicleId;
									}

									if (incomingdata.unassigned[i].classification != null || incomingdata.unassigned[i].classification != '' || incomingdata.unassigned[i].classification != undefined) {
										customFieldValues.EngineerType = incomingdata.unassigned[i].classification;
									}

									if (incomingdata.unassigned[i].oot != null || incomingdata.unassigned[i].oot != '' || incomingdata.unassigned[i].oot != undefined) {
										customFieldValues.oot = JSON.stringify(incomingdata.unassigned[i].oot);
									}

									if (incomingdata.unassigned[i].phone != null || incomingdata.unassigned[i].phone != '' || incomingdata.unassigned[i].phone != undefined) {
										customFieldValues.secondaryPhoneNumber = incomingdata.unassigned[i].phone;
									}

									if (incomingdata.unassigned[i].rc != null || incomingdata.unassigned[i].rc != '' || incomingdata.unassigned[i].rc != undefined) {
										customFieldValues.rc = incomingdata.unassigned[i].rc;
									}
									if (incomingdata.unassigned[i].rcLeader != null || incomingdata.unassigned[i].rcLeader != '' || incomingdata.unassigned[i].rcLeader != undefined) {
										customFieldValues.rcLeader = incomingdata.unassigned[i].rcLeader;
									}
									if (incomingdata.rosterDate != null || incomingdata.rosterDate != '' || incomingdata.rosterDate != undefined) {
										customFieldValues.rosterDate = incomingdata.rosterDate;
									}
									if (incomingdata.createdTimestamp != null || incomingdata.createdTimestamp != '' || incomingdata.createdTimestamp != undefined) {
										customFieldValues.createdTimeStamp = incomingdata.createdTimestamp;
									}
									if (incomingdata.rosterNotes != null || incomingdata.rosterNotes != '' || incomingdata.rosterNotes != undefined) {
										customFieldValues.rosterNotes = incomingdata.rosterNotes;
									}

									payload.customFieldValues = customFieldValues;
									var patchUnAssignUrl = omsExternalURL + 'Crew/' + unAssignCrewId
									var getUnAssignid = getUnAssignResponse.id
									patchUnAssignCall(patchUnAssignUrl, 'PATCH', payload, unAssignCrewId, getUnAssignid);
								}
							} //end for loop
						}
					});
				} else {
					//Make Post call If UnAssigned crewId not found
					logger.debug("Unable to find the crewId details for " + unAssignCrewId + " " + responseStatusCode);
					var unAssignedLength = incomingdata.unassigned.length;
					for (var i = 0; i < unAssignedLength; i++) {
						var unAssigned_crewId = incomingdata.unassigned[i].crewId;
						if (unAssigned_crewId === unAssignCrewId) {
							var fname = incomingdata.unassigned[i].firstName;
							var lname = incomingdata.unassigned[i].lastName;
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							var aorID = ctx.getVar("aorIDArray");
							var crewtype = ctx.getVar("statusfromLookupCrewTypes");
							var customFieldValues = {};
							var payload = {};
							var externalIDcustomFieldValues = {};

							if (aorID != null || aorID != '' || aorID != undefined) {
								payload.aorIDs = aorID;
							}
							if (crewtype != null || crewtype != '' || crewtype != undefined) {
								payload.type = crewtype;
							}

							if (incomingdata.unassigned[i].startTime != null || incomingdata.unassigned[i].startTime != '' || incomingdata.unassigned[i].startTime != undefined) {
								customFieldValues.startTime = incomingdata.unassigned[i].startTime;
							}

							//start

							if (unAssignCrewId != null || unAssignCrewId != '' || unAssignCrewId != undefined) {
								payload.externalID = unAssignCrewId;
							}

							if (incomingdata.unassigned[i].empUserId !== undefined && incomingdata.unassigned[i].empUserId !== undefined && incomingdata.unassigned[i].empUserId !== '') {
								customFieldValues.employeeid = incomingdata.unassigned[i].empUserId;
							}

							if (incomingdata.unassigned[i].crewId != null || incomingdata.unassigned[i].crewId != '' || incomingdata.unassigned[i].crewId != undefined) {
								customFieldValues.CrewID = incomingdata.unassigned[i].crewId;
							}

							//end 

							if (incomingdata.unassigned[i].cellPhone != null || incomingdata.unassigned[i].cellPhone != '' || incomingdata.unassigned[i].cellPhone != undefined) {
								payload.phoneNumber = incomingdata.unassigned[i].cellPhone;
							}
							payload.name = fname + ' ' + lname;


							if (incomingdata.unassigned[i].primaryVehicle !== undefined && incomingdata.unassigned[i].primaryVehicle.name !== undefined && incomingdata.unassigned[i].primaryVehicle.name !== '') {
								customFieldValues.vehiclename = incomingdata.unassigned[i].primaryVehicle.name;
							}

							if (incomingdata.unassigned[i].primaryVehicle !== undefined && incomingdata.unassigned[i].primaryVehicle.radio !== '' && incomingdata.unassigned[i].primaryVehicle.radio !== undefined) {
								customFieldValues.vehicleradio = incomingdata.unassigned[i].primaryVehicle.radio;
							}

							if (incomingdata.unassigned[i].primaryVehicle !== undefined && incomingdata.unassigned[i].primaryVehicle.vehicleId !== '' && incomingdata.unassigned[i].primaryVehicle.vehicleId !== undefined) {
								customFieldValues.vehicleId = incomingdata.unassigned[i].primaryVehicle.vehicleId;
							}

							if (incomingdata.unassigned[i].secondaryVehicle !== undefined && incomingdata.unassigned[i].secondaryVehicle.name !== '' && incomingdata.unassigned[i].secondaryVehicle.name !== undefined) {
								customFieldValues.secondaryVehicleName = incomingdata.unassigned[i].secondaryVehicle.name;
							}
							if (incomingdata.unassigned[i].secondaryVehicle !== undefined && incomingdata.unassigned[i].secondaryVehicle.radio !== '' && incomingdata.unassigned[i].secondaryVehicle.radio !== undefined) {
								customFieldValues.secondaryVehicleRadio = incomingdata.unassigned[i].secondaryVehicle.radio;
							}

							if (incomingdata.unassigned[i].secondaryVehicle !== undefined && incomingdata.unassigned[i].secondaryVehicle.vehicleId !== '' && incomingdata.unassigned[i].secondaryVehicle.vehicleId !== undefined) {
								customFieldValues.secondaryVehicleId = incomingdata.unassigned[i].secondaryVehicle.vehicleId;
							}

							if (incomingdata.unassigned[i].classification != null || incomingdata.unassigned[i].classification != '' || incomingdata.unassigned[i].classification != undefined) {
								customFieldValues.EngineerType = incomingdata.unassigned[i].classification;
							}

							if (incomingdata.unassigned[i].oot != null || incomingdata.unassigned[i].oot != '' || incomingdata.unassigned[i].oot != undefined) {
								customFieldValues.oot = JSON.stringify(incomingdata.unassigned[i].oot);
							}

							if (incomingdata.unassigned[i].phone != null || incomingdata.unassigned[i].phone != '' || incomingdata.unassigned[i].phone != undefined) {
								customFieldValues.secondaryPhoneNumber = incomingdata.unassigned[i].phone;
							}

							if (incomingdata.unassigned[i].rc != null || incomingdata.unassigned[i].rc != '' || incomingdata.unassigned[i].rc != undefined) {
								customFieldValues.rc = incomingdata.unassigned[i].rc;
							}
							if (incomingdata.unassigned[i].rcLeader != null || incomingdata.unassigned[i].rcLeader != '' || incomingdata.unassigned[i].rcLeader != undefined) {
								customFieldValues.rcLeader = incomingdata.unassigned[i].rcLeader;
							}
							if (incomingdata.rosterDate != null || incomingdata.rosterDate != '' || incomingdata.rosterDate != undefined) {
								customFieldValues.rosterDate = incomingdata.rosterDate;
							}
							if (incomingdata.createdTimestamp != null || incomingdata.createdTimestamp != '' || incomingdata.createdTimestamp != undefined) {
								customFieldValues.createdTimeStamp = incomingdata.createdTimestamp;
							}
							if (incomingdata.rosterNotes != null || incomingdata.rosterNotes != '' || incomingdata.rosterNotes != undefined) {
								customFieldValues.rosterNotes = incomingdata.rosterNotes;
							}
							payload.customFieldValues = customFieldValues;
							var postUnAssignUrl = omsExternalURL + 'Crew';
							postUnAssignCall(postUnAssignUrl, 'POST', payload, unAssignCrewId);
						}
					} //end for loop
				}//end else crewId not found
			}
		});

	}
	//End :Make GET,PATCH and POST call to Create/Update the UnAssignedCrewId's



	//Start :Make GET,PATCH and POST call to Create/Update the supervisorsCrewId's
	function getSupervisorCall(url, method, payload, supervisorsCrewId) {
		var getSupervisorAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			}
		};
		var info = " TargetURL: " + getSupervisorAPI.target + "; Method: " + getSupervisorAPI.method + ". ";
		urlopen.open(getSupervisorAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("cms_019:urlopen connect error with getSupervisorAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with getSupervisorAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with getSupervisorAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to getSupervisorAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to getSupervisorAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to getSupervisorAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from getSupervisorAPI for crewId:" + supervisorsCrewId + "" + responseStatusCode);
							var getSupervisorAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("getSupervisorAPIResponse", getSupervisorAPIResponse);

							var supervisorsLength = incomingdata.supervisors.length;
							for (var i = 0; i < supervisorsLength; i++) {
								var supervisors_crewId = incomingdata.supervisors[i].crewId;
								if (supervisors_crewId === supervisorsCrewId) {
									var fname = incomingdata.supervisors[i].firstName;
									var lname = incomingdata.supervisors[i].lastName;
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									//var aorID = ctx.getVar("aorIDArray"); 
									var customFieldValues = {};
									var payload = {};
									var externalIDcustomFieldValues = {};

									/*if(aorID != null || aorID != '' || aorID != undefined){ 
										payload.aorIDs = aorID;
										}*/
									if (incomingdata.supervisors[i].startTime != null || incomingdata.supervisors[i].startTime != '' || incomingdata.supervisors[i].startTime != undefined) {
										customFieldValues.startTime = incomingdata.supervisors[i].startTime;
									}
									//start
									if (supervisorsCrewId != null || supervisorsCrewId != '' || supervisorsCrewId != undefined) {
										payload.externalID = supervisorsCrewId;
									}

									if (incomingdata.supervisors[i].empUserId !== undefined && incomingdata.supervisors[i].empUserId !== undefined && incomingdata.supervisors[i].empUserId !== '') {
										customFieldValues.employeeid = incomingdata.supervisors[i].empUserId;
									}

									if (incomingdata.supervisors[i].crewId != null || incomingdata.supervisors[i].crewId != '' || incomingdata.supervisors[i].crewId != undefined) {
										customFieldValues.CrewID = incomingdata.supervisors[i].crewId;
									}
									//end

									if (incomingdata.supervisors[i].cellPhone != null || incomingdata.supervisors[i].cellPhone != '' || incomingdata.supervisors[i].cellPhone != undefined) {
										payload.phoneNumber = incomingdata.supervisors[i].cellPhone;
									}

									payload.name = fname + ' ' + lname;


									if (incomingdata.supervisors[i].primaryVehicle !== undefined && incomingdata.supervisors[i].primaryVehicle.name !== undefined && incomingdata.supervisors[i].primaryVehicle.name !== '') {
										customFieldValues.vehiclename = incomingdata.supervisors[i].primaryVehicle.name;
									}

									if (incomingdata.supervisors[i].primaryVehicle !== undefined && incomingdata.supervisors[i].primaryVehicle.radio !== '' && incomingdata.supervisors[i].primaryVehicle.radio !== undefined) {
										customFieldValues.vehicleradio = incomingdata.supervisors[i].primaryVehicle.radio;
									}

									if (incomingdata.supervisors[i].primaryVehicle !== undefined && incomingdata.supervisors[i].primaryVehicle.vehicleId !== '' && incomingdata.supervisors[i].primaryVehicle.vehicleId !== undefined) {
										customFieldValues.vehicleId = incomingdata.supervisors[i].primaryVehicle.vehicleId;
									}

									if (incomingdata.supervisors[i].secondaryVehicle !== undefined && incomingdata.supervisors[i].secondaryVehicle.name !== '' && incomingdata.supervisors[i].secondaryVehicle.name !== undefined) {
										customFieldValues.secondaryVehicleName = incomingdata.supervisors[i].secondaryVehicle.name;
									}
									if (incomingdata.supervisors[i].secondaryVehicle !== undefined && incomingdata.supervisors[i].secondaryVehicle.radio !== '' && incomingdata.supervisors[i].secondaryVehicle.radio !== undefined) {
										customFieldValues.secondaryVehicleRadio = incomingdata.supervisors[i].secondaryVehicle.radio;
									}

									if (incomingdata.supervisors[i].secondaryVehicle !== undefined && incomingdata.supervisors[i].secondaryVehicle.vehicleId !== '' && incomingdata.supervisors[i].secondaryVehicle.vehicleId !== undefined) {
										customFieldValues.secondaryVehicleId = incomingdata.supervisors[i].secondaryVehicle.vehicleId;
									}

									if (incomingdata.supervisors[i].classification != null || incomingdata.supervisors[i].classification != '' || incomingdata.supervisors[i].classification != undefined) {
										customFieldValues.EngineerType = incomingdata.supervisors[i].classification;
									}

									if (incomingdata.supervisors[i].oot != null || incomingdata.supervisors[i].oot != '' || incomingdata.supervisors[i].oot != undefined) {
										customFieldValues.oot = JSON.stringify(incomingdata.supervisors[i].oot);
									}

									if (incomingdata.supervisors[i].phone != null || incomingdata.supervisors[i].phone != '' || incomingdata.supervisors[i].phone != undefined) {
										customFieldValues.secondaryPhoneNumber = incomingdata.supervisors[i].phone;
									}

									if (incomingdata.supervisors[i].rc != null || incomingdata.supervisors[i].rc != '' || incomingdata.supervisors[i].rc != undefined) {
										customFieldValues.rc = incomingdata.supervisors[i].rc;
									}
									if (incomingdata.supervisors[i].rcLeader != null || incomingdata.supervisors[i].rcLeader != '' || incomingdata.supervisors[i].rcLeader != undefined) {
										customFieldValues.rcLeader = incomingdata.supervisors[i].rcLeader;
									}
									if (incomingdata.rosterDate != null || incomingdata.rosterDate != '' || incomingdata.rosterDate != undefined) {
										customFieldValues.rosterDate = incomingdata.rosterDate;
									}
									if (incomingdata.createdTimestamp != null || incomingdata.createdTimestamp != '' || incomingdata.createdTimestamp != undefined) {
										customFieldValues.createdTimeStamp = incomingdata.createdTimestamp;
									}
									if (incomingdata.rosterNotes != null || incomingdata.rosterNotes != '' || incomingdata.rosterNotes != undefined) {
										customFieldValues.rosterNotes = incomingdata.rosterNotes;
									}

									customFieldValues.IsSupervisor = "TRUE";
									payload.customFieldValues = customFieldValues;
									var patchSupervisorsUrl = omsExternalURL + 'Crew/' + supervisorsCrewId
									var getSupervisorAPIResponseId = getSupervisorAPIResponse.id
									patchSupervisorsCall(patchSupervisorsUrl, 'PATCH', payload, supervisorsCrewId, getSupervisorAPIResponseId);
								}
							} //end for loop
						}
					});
				} else {
					//start if crewId not found 
					logger.debug("Unable to find the crewId details in getSupervisorsAPI call" + " " + supervisorsCrewId + " " + responseStatusCode);
					var supervisorsLength = incomingdata.supervisors.length;
					for (var i = 0; i < supervisorsLength; i++) {
						var supervisors_crewId = incomingdata.supervisors[i].crewId;
						if (supervisors_crewId === supervisorsCrewId) {
							var fname = incomingdata.supervisors[i].firstName;
							var lname = incomingdata.supervisors[i].lastName;
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							var aorID = ctx.getVar("aorIDArray");
							var crewtype = ctx.getVar("statusfromLookupCrewTypes");
							var customFieldValues = {};
							var payload = {};
							var externalIDcustomFieldValues = {};
							if (aorID != null || aorID != '' || aorID != undefined) {
								payload.aorIDs = aorID;
							}
							if (crewtype != null || crewtype != '' || crewtype != undefined) {
								payload.type = crewtype;
							}

							if (incomingdata.supervisors[i].startTime != null || incomingdata.supervisors[i].startTime != '' || incomingdata.supervisors[i].startTime != undefined) {
								customFieldValues.startTime = incomingdata.supervisors[i].startTime;
							}
							//start

							if (supervisorsCrewId != null || supervisorsCrewId != '' || supervisorsCrewId != undefined) {
								payload.externalID = supervisorsCrewId;
							}
							if (incomingdata.supervisors[i].empUserId !== undefined && incomingdata.supervisors[i].empUserId !== undefined && incomingdata.supervisors[i].empUserId !== '') {
								customFieldValues.employeeid = incomingdata.supervisors[i].empUserId;
							}
							if (incomingdata.supervisors[i].crewId != null || incomingdata.supervisors[i].crewId != '' || incomingdata.supervisors[i].crewId != undefined) {
								customFieldValues.CrewID = incomingdata.supervisors[i].crewId;
							}
							//end 

							if (incomingdata.supervisors[i].cellPhone != null || incomingdata.supervisors[i].cellPhone != '' || incomingdata.supervisors[i].cellPhone != undefined) {
								payload.phoneNumber = incomingdata.supervisors[i].cellPhone;
							}

							payload.name = fname + ' ' + lname;


							if (incomingdata.supervisors[i].primaryVehicle !== undefined && incomingdata.supervisors[i].primaryVehicle.name !== undefined && incomingdata.supervisors[i].primaryVehicle.name !== '') {
								customFieldValues.vehiclename = incomingdata.supervisors[i].primaryVehicle.name;
							}

							if (incomingdata.supervisors[i].primaryVehicle !== undefined && incomingdata.supervisors[i].primaryVehicle.radio !== '' && incomingdata.supervisors[i].primaryVehicle.radio !== undefined) {
								customFieldValues.vehicleradio = incomingdata.supervisors[i].primaryVehicle.radio;
							}

							if (incomingdata.supervisors[i].primaryVehicle !== undefined && incomingdata.supervisors[i].primaryVehicle.vehicleId !== '' && incomingdata.supervisors[i].primaryVehicle.vehicleId !== undefined) {
								customFieldValues.vehicleId = incomingdata.supervisors[i].primaryVehicle.vehicleId;
							}

							if (incomingdata.supervisors[i].secondaryVehicle !== undefined && incomingdata.supervisors[i].secondaryVehicle.name !== '' && incomingdata.supervisors[i].secondaryVehicle.name !== undefined) {
								customFieldValues.secondaryVehicleName = incomingdata.supervisors[i].secondaryVehicle.name;
							}
							if (incomingdata.supervisors[i].secondaryVehicle !== undefined && incomingdata.supervisors[i].secondaryVehicle.radio !== '' && incomingdata.supervisors[i].secondaryVehicle.radio !== undefined) {
								customFieldValues.secondaryVehicleRadio = incomingdata.supervisors[i].secondaryVehicle.radio;
							}

							if (incomingdata.supervisors[i].secondaryVehicle !== undefined && incomingdata.supervisors[i].secondaryVehicle.vehicleId !== '' && incomingdata.supervisors[i].secondaryVehicle.vehicleId !== undefined) {
								customFieldValues.secondaryVehicleId = incomingdata.supervisors[i].secondaryVehicle.vehicleId;
							}

							if (incomingdata.supervisors[i].classification != null || incomingdata.supervisors[i].classification != '' || incomingdata.supervisors[i].classification != undefined) {
								customFieldValues.EngineerType = incomingdata.supervisors[i].classification;
							}

							if (incomingdata.supervisors[i].oot != null || incomingdata.supervisors[i].oot != '' || incomingdata.supervisors[i].oot != undefined) {
								customFieldValues.oot = JSON.stringify(incomingdata.supervisors[i].oot);
							}

							if (incomingdata.supervisors[i].phone != null || incomingdata.supervisors[i].phone != '' || incomingdata.supervisors[i].phone != undefined) {
								customFieldValues.secondaryPhoneNumber = incomingdata.supervisors[i].phone;
							}

							if (incomingdata.supervisors[i].rc != null || incomingdata.supervisors[i].rc != '' || incomingdata.supervisors[i].rc != undefined) {
								customFieldValues.rc = incomingdata.supervisors[i].rc;
							}
							if (incomingdata.supervisors[i].rcLeader != null || incomingdata.supervisors[i].rcLeader != '' || incomingdata.supervisors[i].rcLeader != undefined) {
								customFieldValues.rcLeader = incomingdata.supervisors[i].rcLeader;
							}
							if (incomingdata.rosterDate != null || incomingdata.rosterDate != '' || incomingdata.rosterDate != undefined) {
								customFieldValues.rosterDate = incomingdata.rosterDate;
							}
							if (incomingdata.createdTimestamp != null || incomingdata.createdTimestamp != '' || incomingdata.createdTimestamp != undefined) {
								customFieldValues.createdTimeStamp = incomingdata.createdTimestamp;
							}
							if (incomingdata.rosterNotes != null || incomingdata.rosterNotes != '' || incomingdata.rosterNotes != undefined) {
								customFieldValues.rosterNotes = incomingdata.rosterNotes;
							}

							customFieldValues.IsSupervisor = "TRUE";
							payload.customFieldValues = customFieldValues;
							var postSupervisorsUrl = omsExternalURL + 'Crew'
							postSupervisorsCall(postSupervisorsUrl, 'POST', payload, supervisorsCrewId);
						}
					} //end for loop
				}//end if crewId not found
			}
		});
	}
	//End : Make GET,PATCH and POST call to Create/Update the supervisorsCrewId's


	//Start:UnAssign PATCH call function start to  Update the UnAssignEmpId CustomFields
	function patchUnAssignCall(url, method, payload, unAssignCrewId, getUnAssignid) {
		// logger.info("Inside patchUnAssignCallURL :: url" + url + ', '+ method);
		var patchUnAssignAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		ILSctx.setVariable("exitpayload", JSON.stringify(patchUnAssignAPI.data));
		var info = " TargetURL :" + patchUnAssignAPI.target + "; Method :" + patchUnAssignAPI.method + "; Data :" + JSON.stringify(patchUnAssignAPI.data) + ". ";
		urlopen.open(patchUnAssignAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("urlopen connect error with patchUnAssignAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with patchUnAssignAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with patchUnAssignAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to patchUnAssignAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to patchUnAssignAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to patchUnAssignAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from patchUnAssignAPI for crewId:" + unAssignCrewId + "" + responseStatusCode);
							var patchUnAssignAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("patchUnAssignAPIResponse", patchUnAssignAPIResponse);
							//Make OffShift Call after Updating the UnAssignedEmpId's
							var patchUnAssignOffShiftUrl = omsExternalURL + 'Crew/' + getUnAssignid + '/OffShift';
							var patchUnAssignOffShiftRequest = {
								"shiftOffTime": timestamp
							}
							// ADO146962 commenting the onshift PATCH call
							/*
							var patchUnAssignOffShiftRequest = {
								target: patchUnAssignOffShiftUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: patchUnAssignOffShiftRequest
							};
							ILSctx.setVariable("exitpayload", JSON.stringify(patchUnAssignOffShiftRequest.data));
							var info = " TargetURL :" + patchUnAssignOffShiftRequest.target + "; Method :" + patchUnAssignOffShiftRequest.method + "; Data :" + JSON.stringify(patchUnAssignOffShiftRequest.data) + ". ";
							urlopen.open(patchUnAssignOffShiftRequest, function(error, response) {
								if (error) {
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									ctx.setVariable("retry", 'yes');
									logger.error("urlopen connect error with patchUnAssignOffShiftApi" + JSON.stringify(error));
									var errorinfo = "urlopen connect error with patchUnAssignOffShiftApi, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									var ErrorTxt = "urlopen connect error with patchUnAssignOffShiftApi";
									ctx.setVariable("ErrorTxt", ErrorTxt);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("failure in putting message to patchUnAssignOffShiftApi" + JSON.stringify(error));
												var errorinfo = "failure in putting message to patchUnAssignOffShiftApi, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												session.reject("failure in putting message to patchUnAssignOffShiftApi");
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from patchUnAssignOffShiftApi for unAssignCrewId:" + "" + responseStatusCode);
												var patchUnAssignOffShiftApiResponse = JSON.parse(responseData);
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("patchUnAssignOffShiftApiResponse", patchUnAssignOffShiftApiResponse);
												//console.log("patchUnAssignOffShiftApiResponse----"+JSON.stringify(patchUnAssignOffShiftApiResponse));
											}
										});
									} else {

										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  patchUnAssignOffShiftApiResponse " + " " + JSON.stringify(error));
											} else {
												logger.error("Error response received from patchUnAssignOffShiftApiResponse " + " " + responseData + " " + unAssignCrewId);
											}
										});
										//end
									}
								}
							});
							*/
						}
					});
				}
			}
		});
	}
	//End: UnAssign PATCH call function start to  Update the UnAssignEmpId CustomFields


	//Start: UnAssign POST call function start to  Update the UnAssignEmpId CustomFields 
	function postUnAssignCall(url, method, payload, unAssignCrewId) {
		var postUnAssignAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		ILSctx.setVariable("exitpayload", JSON.stringify(postUnAssignAPI.data));
		var info = " TargetURL :" + postUnAssignAPI.target + "; Method :" + postUnAssignAPI.method + "; Data :" + JSON.stringify(postUnAssignAPI.data) + ". ";
		urlopen.open(postUnAssignAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("urlopen connect error with postUnAssignAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with postUnAssignAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with postUnAssignAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error("failure in putting message to postUnAssignAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to postUnAssignAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to postUnAssignAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from postUnAssignAPI for crewId:" + unAssignCrewId + "" + responseStatusCode);
							var postUnAssignAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("postUnAssignAPIResponse", postUnAssignAPIResponse);
							//console.log("postUnAssignAPIResponse----"+JSON.stringify(postUnAssignAPIResponse));
							//Make OffShift Call after creating the UnAssignedEmpId's
							var postUnAssignAPIResponseId = postUnAssignAPIResponse.id;
							var patchUnAssignOffShiftUrl = omsExternalURL + 'Crew/' + postUnAssignAPIResponseId + '/OffShift';
							var patchUnAssignOffShiftRequest = {
								"shiftOffTime": timestamp
							}
							// ADO146962 commenting the onshift PATCH call
							/*
							var patchUnAssignOffShiftRequest = {
								target: patchUnAssignOffShiftUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: patchUnAssignOffShiftRequest
							};
							ILSctx.setVariable("exitpayload", JSON.stringify(patchUnAssignOffShiftRequest.data));
							var info = " TargetURL :" + patchUnAssignOffShiftRequest.target + "; Method :" + patchUnAssignOffShiftRequest.method + "; Data :" + JSON.stringify(patchUnAssignOffShiftRequest.data) + ". ";
							urlopen.open(patchUnAssignOffShiftRequest, function(error, response) {
								if (error) {
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									ctx.setVariable("retry", 'yes');
									logger.error("urlopen connect error with patchUnAssignOffShiftApi" + JSON.stringify(error));
									var errorinfo = "urlopen connect error with patchUnAssignOffShiftApi, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									var ErrorTxt = "urlopen connect error with patchUnAssignOffShiftApi";
									ctx.setVariable("ErrorTxt", ErrorTxt);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												logger.error("failure in putting message to patchUnAssignOffShift" + JSON.stringify(error));
												var errorinfo = "failure in putting message to patchUnAssignOffShift, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												session.reject("failure in putting message to patchUnAssignOffShift");
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from patchUnAssignOffShift for unAssignCrewId:" + "" + responseStatusCode);
												var patchUnAssignOffShiftApiResponse = JSON.parse(responseData);
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("patchUnAssignOffShiftApiResponse", patchUnAssignOffShiftApiResponse);
												//console.log("patchUnAssignOffShiftApiResponse----"+JSON.stringify(patchUnAssignOffShiftApiResponse));
											}
										});
									} else {
										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  patchUnAssignOffShiftApiResponse " + " " + JSON.stringify(error));
												var errorinfo = "Error response received from  patchUnAssignOffShiftApiResponse, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											} else {
												logger.error("Error response received from patchUnAssignOffShiftApiResponse " + " " + responseData + " " + postUnAssignAPIResponseId);
												var errorinfo = "Error response received from patchUnAssignOffShiftApiResponse, details are : " + info + "; error info :" + responseData + " " + postUnAssignAPIResponseId;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											}
										});
										//end
									}
								}
							});
							*/
						}
					});
				}
			}
		});
	}
	//End: UnAssign PATCH call function start to  Update the UnAssignCrewId CustomFields

	//Start:supervisors PATCH call function start to  Update the supervisorsEmpId CustomFields
	function patchSupervisorsCall(url, method, payload, supervisorsCrewId, getSupervisorAPIResponseId) {
		// logger.info("Inside patchSupervisorsCall :: url" + url + ', '+ method);
		var patchSupervisorAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		ILSctx.setVariable("exitpayload", JSON.stringify(patchSupervisorAPI.data));
		var info = " TargetURL :" + patchSupervisorAPI.target + "; Method :" + patchSupervisorAPI.method + "; Data :" + JSON.stringify(patchSupervisorAPI.data) + ". ";
		urlopen.open(patchSupervisorAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("urlopen connect error with patchSupervisorAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with patchSupervisorAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with patchSupervisorAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to patchSupervisorAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to patchSupervisorAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to patchSupervisorAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from patchSupervisorAPI for crewId:" + supervisorsCrewId + "" + responseStatusCode);
							var patchSupervisorAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("patchSupervisorAPIResponse", patchSupervisorAPIResponse);
							console.log("patchSupervisorAPIResponse----" + JSON.stringify(patchSupervisorAPIResponse));
							//Make OffShift Call after Updating the UnAssignedEmpId's
							// ADO146962 commenting the onshift PATCH call
							/*
							var postSupervisorsOnShiftUrl = omsExternalURL + 'Crew/' + getSupervisorAPIResponseId + '/OnShift';
							var postSupervisorOnShiftRequest = {
								"shiftOnTime": timestamp
							}
							var postSupervisorOnShiftRequest = {
								target: postSupervisorsOnShiftUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'POST',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: postSupervisorOnShiftRequest
							};
							ILSctx.setVariable("exitpayload", JSON.stringify(postSupervisorOnShiftRequest.data));
							var info = " TargetURL :" + postSupervisorOnShiftRequest.target + "; Method :" + postSupervisorOnShiftRequest.method + "; Data :" + JSON.stringify(postSupervisorOnShiftRequest.data) + ". ";
							urlopen.open(postSupervisorOnShiftRequest, function(error, response) {
								if (error) {
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									ctx.setVariable("retry", 'yes');
									logger.error("urlopen connect error with postSupervisorOnShiftAPI" + JSON.stringify(error));
									var errorinfo = "failure in putting message to patchUnAssignOffShift, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									var ErrorTxt = "urlopen connect error with postSupervisorOnShiftAPI";
									ctx.setVariable("ErrorTxt", ErrorTxt);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("failure in putting message to postSupervisorOnShiftAPI" + JSON.stringify(error));
												var errorinfo = "failure in putting message to postSupervisorOnShiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												session.reject("failure in putting message to postSupervisorOnShiftAPI");
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from postSupervisorOnShiftAPIResponse for supervisorsCrewId:" + "" + responseStatusCode);
												var postSupervisorOnShiftAPIResponse = JSON.parse(responseData);
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("postSupervisorOnShiftAPIResponse", postSupervisorOnShiftAPIResponse);
												//console.log("postSupervisorOnShiftAPIResponse----"+JSON.stringify(postSupervisorOnShiftAPIResponse));
											}
										});
									} else {
										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  postSupervisorOnShiftAPIResponse " + " " + JSON.stringify(error));
												var errorinfo = "Error response received from  postSupervisorOnShiftAPIResponse, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											} else {
												logger.error("Error response received from postSupervisorOnShiftAPIResponse " + " " + responseData);
												var errorinfo = "Error response received from postSupervisorOnShiftAPIResponse, details are : " + info + responseData;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											}
										});
										//end
									}
								}
							});
							*/
						}
					});
				}
			}
		});
	}
	//End: SuperVisor PATCH call function start to  Update the supervisorsEmpId CustomFields

	//Start: supervisors POST call function start to  Update the supervisorsEmpId CustomFields 
	function postSupervisorsCall(url, method, payload, supervisorsCrewId) {
		//logger.info("Inside postSupervisorsCall :: url" + url + ', '+ method);
		var postSupervisorsAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		ILSctx.setVariable("exitpayload", JSON.stringify(postSupervisorsAPI.data));
		var info = " TargetURL :" + postSupervisorsAPI.target + "; Method :" + postSupervisorsAPI.method + "; Data :" + JSON.stringify(postSupervisorsAPI.data) + ". ";
		urlopen.open(postSupervisorsAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("urlopen connect error with postSupervisorsAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with postSupervisorsAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with postSupervisorsAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to postSupervisorsAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to postSupervisorsAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to postSupervisorsAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from postSupervisorsAPI for crewId:" + supervisorsCrewId + "" + responseStatusCode);
							var postSupervisorsAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("postSupervisorsAPIResponse", postSupervisorsAPIResponse);
							console.log("postSupervisorsAPIResponse----" + JSON.stringify(postSupervisorsAPIResponse));
							//Make OffShift Call after creating the UnAssignedEmpId's
							var postSupervisorsCallid = postSupervisorsAPIResponse.id
							var postSupervisorsOnShiftUrl = omsExternalURL + 'Crew/' + postSupervisorsCallid + '/OnShift';
							var postSupervisorOnShiftRequest = {
								"shiftOnTime": timestamp
							}
							// ADO146962 commenting the onshift PATCH call
							/*
							var postSupervisorsOnShiftRequest = {
								target: postSupervisorsOnShiftUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'POST',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: postSupervisorOnShiftRequest
							};
							ILSctx.setVariable("exitpayload", JSON.stringify(postSupervisorsOnShiftRequest.data));
							var info = " TargetURL :" + postSupervisorsOnShiftRequest.target + "; Method :" + postSupervisorsOnShiftRequest.method + "; Data :" + JSON.stringify(postSupervisorsOnShiftRequest.data) + ". ";
							urlopen.open(postSupervisorsOnShiftRequest, function(error, response) {
								if (error) {
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									ctx.setVariable("retry", 'yes');
									logger.error("urlopen connect error with postSupervisorsOnShiftAPI" + JSON.stringify(error));
									var errorinfo = "urlopen connect error with postSupervisorsOnShiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									var ErrorTxt = "urlopen connect error with postSupervisorsOnShiftAPI";
									ctx.setVariable("ErrorTxt", ErrorTxt);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												logger.error("failure in putting message to postSupervisorsOnShiftAPI" + JSON.stringify(error));
												var errorinfo = "failure in putting message to postSupervisorsOnShiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												session.reject("failure in putting message to postSupervisorsOnShiftAPI");
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from postSupervisorsOnShiftAPI for supervisorsCrewId:" + "" + responseStatusCode);
												var postSupervisorsOnShiftAPIResponse = JSON.parse(responseData);
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("postSupervisorsOnShiftAPIResponse", postSupervisorsOnShiftAPIResponse);
												//console.log("postSupervisorsOnShiftAPIResponse----"+JSON.stringify(postSupervisorsOnShiftAPIResponse));
											}
										});
									} else {
										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  postSupervisorOnShiftAPIResponse " + " " + JSON.stringify(error));
												var errorinfo = "Error response received from  postSupervisorOnShiftAPIResponse, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											} else {
												logger.error("Error response received from postSupervisorOnShiftAPIResponse " + " " + responseData + " " + postSupervisorsCallid);
												var errorinfo = "Error response received from postSupervisorOnShiftAPIResponse, details are : " + responseData + " " + postSupervisorsCallid;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											}
										});
										//end
									}
								}
							});
							*/
						}
					});
				}
			}
		});
	}
	//End: Supervisor PATCH call function start to  Update the supervisorsCrewId CustomFields

	//Start:CrewMember POST call function start to  Update the Shift CrewMemberEmpId CustomFields
	function postShiftCrewMemberCall(url, method, payload, shiftCrewMemberCrewId) {
		var postShiftCrewMemberAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		ILSctx.setVariable("exitpayload", JSON.stringify(postShiftCrewMemberAPI.data));
		var info = " TargetURL :" + postShiftCrewMemberAPI.target + "; Method :" + postShiftCrewMemberAPI.method + "; Data :" + JSON.stringify(postShiftCrewMemberAPI.data) + ". ";
		urlopen.open(postShiftCrewMemberAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("urlopen connect error with postShiftCrewMemberAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with postShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with postShiftCrewMemberAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to postShiftCrewMemberAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to postShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to postShiftCrewMemberAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from postShiftCrewMemberAPI for crewId:" + shiftCrewMemberCrewId + "" + responseStatusCode);
							var postShiftCrewMemberAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("postShiftCrewMemberAPIResponse", postShiftCrewMemberAPIResponse);
							var postShiftCrewMemberAPIResponseid = postShiftCrewMemberAPIResponse.id
							var postCrewMemberOnShiftApiUrl = omsExternalURL + 'Crew/' + postShiftCrewMemberAPIResponseid + '/OnShift';
							var postCrewMemberOnRequest = {
								"shiftOnTime": timestamp
							}
							// ADO146962 commenting the onshift PATCH call
							/*
							var postCrewMemberOnshiftAPIRequest = {
								target: postCrewMemberOnShiftApiUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'POST',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: postCrewMemberOnRequest
							};
							ILSctx.setVariable("exitpayload", JSON.stringify(postCrewMemberOnshiftAPIRequest.data));
							var info = " TargetURL :" + postCrewMemberOnshiftAPIRequest.target + "; Method :" + postCrewMemberOnshiftAPIRequest.method + "; Data :" + JSON.stringify(postCrewMemberOnshiftAPIRequest.data) + ". ";
							urlopen.open(postCrewMemberOnshiftAPIRequest, function(error, response) {
								if (error) {
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									ctx.setVariable("retry", 'yes');
									logger.error("urlopen connect error with postCrewMemberOnshiftAPI" + JSON.stringify(error));
									var errorinfo = "urlopen connect error with postCrewMemberOnshiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									var ErrorTxt = "urlopen connect error with postCrewMemberOnshiftAPI";
									ctx.setVariable("ErrorTxt", ErrorTxt);

								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("failure in putting message to postCrewMemberOnshiftAPI" + JSON.stringify(error));
												var errorinfo = "failure in putting message to postCrewMemberOnshiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												session.reject("failure in putting message to postCrewMemberOnshiftAPI");
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from postCrewMemberOnshiftAPI for shiftCrewMemberCrewId:" + "" + responseStatusCode);
												var postCrewMemberOnshiftAPIResponse = JSON.parse(responseData);
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("postCrewMemberOnshiftAPIResponse", postCrewMemberOnshiftAPIResponse);
											}
										});
									} else {
										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  postCrewMemberOnshiftAPIResponse " + " " + JSON.stringify(error));
												var errorinfo = "Error response received from  postCrewMemberOnshiftAPIResponse, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											} else {
												logger.error("Error response received from postCrewMemberOnshiftAPIResponse " + " " + responseData + " " + postShiftCrewMemberAPIResponseid);
												var errorinfo = "Error response received from postCrewMemberOnshiftAPIResponse , details are : " + info + responseData + " " + postShiftCrewMemberAPIResponseid;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											}
										});
										//end
									}
								}
							});
							*/

						}
					});
				} else {
					logger.error("Unable to find the empId details in postCrewMemberOnshiftAPI call" + " " + shiftCrewMemberCrewId + " " + responseStatusCode);
					var errorinfo = "Unable to find the empId details in postCrewMemberOnshiftAPI call" + " " + shiftCrewMemberCrewId + " " + responseStatusCode;
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', errorinfo);
				}
			}
		});
	}
	//End:CrewMember POST call function start to  Update the Shift CrewMemberEmpId CustomFields 


	//Start:CrewMember PATCH call function start to  Update the Shift CrewMemberEmpId CustomFields 
	function patchShiftCrewMemberCall(url, method, payload, shiftCrewMemberCrewId, idTopass) {
		var patchShiftCrewMemberAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		ILSctx.setVariable("exitpayload", JSON.stringify(patchShiftCrewMemberAPI.data));
		var info = " TargetURL :" + patchShiftCrewMemberAPI.target + "; Method :" + patchShiftCrewMemberAPI.method + "; Data :" + JSON.stringify(patchShiftCrewMemberAPI.data) + ". ";
		urlopen.open(patchShiftCrewMemberAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("urlopen connect error with patchShiftCrewMemberAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with patchShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with patchShiftCrewMemberAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to patchShiftCrewMemberAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to patchShiftCrewMemberAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to patchShiftCrewMemberAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from patchShiftCrewMemberAPI for empId:" + shiftCrewMemberCrewId + "" + responseStatusCode);
							var patchShiftCrewMemberAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("patchShiftCrewMemberAPIResponse", patchShiftCrewMemberAPIResponse);
							var patchShiftCrewMemberOnShiftAPIUrl = omsExternalURL + 'Crew/' + idTopass + '/OnShift';
							var patchShiftCrewMemberOnShiftPatchRequest = {
								"shiftOnTime": timestamp
							}
							// ADO146962 commenting the onshift PATCH call
							/*
							var patchShiftCrewMemberRequest = {
								target: patchShiftCrewMemberOnShiftAPIUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'POST',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: patchShiftCrewMemberOnShiftPatchRequest
							};
							ILSctx.setVariable("exitpayload", JSON.stringify(patchShiftCrewMemberRequest.data));
							var info = " TargetURL :" + patchShiftCrewMemberRequest.target + "; Method :" + patchShiftCrewMemberRequest.method + "; Data :" + JSON.stringify(patchShiftCrewMemberRequest.data) + ". ";
							urlopen.open(patchShiftCrewMemberRequest, function(error, response) {
								if (error) {
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									ctx.setVariable("retry", 'yes');
									logger.error("urlopen connect error with patchShiftCrewMemberOnShiftPatchAPI" + JSON.stringify(error));
									var errorinfo = "urlopen connect error with patchShiftCrewMemberOnShiftPatchAPI, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									var ErrorTxt = "urlopen connect error with patchShiftCrewMemberOnShiftPatchAPI";
									ctx.setVariable("ErrorTxt", ErrorTxt);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("failure in putting message to patchShiftCrewMemberOnShiftPatchAPI" + JSON.stringify(error));
												var errorinfo = "failure in putting message to patchShiftCrewMemberOnShiftPatchAPI, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												session.reject("failure in putting message to patchShiftCrewMemberOnShiftPatchAPI");
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from patchShiftCrewMemberOnShiftPatchAPI for shiftCrewMemberCrewId:" + "" + responseStatusCode);
												var patchShiftCrewMemberOnShiftPatchAPIResponse = JSON.parse(responseData);
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("patchShiftCrewMemberOnShiftPatchAPIResponse", patchShiftCrewMemberOnShiftPatchAPIResponse);
											}
										});
									} else {
										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  patchShiftCrewMemberOnShiftPatchAPIResponse " + " " + JSON.stringify(error));
												var errorinfo = "Error response received from  patchShiftCrewMemberOnShiftPatchAPIResponse, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											} else {
												logger.error("Error response received from patchShiftCrewMemberOnShiftPatchAPIResponse " + " " + responseData);
												var errorinfo = "Error response received from patchShiftCrewMemberOnShiftPatchAPIResponse " + " " + responseData
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											}
										});
										//end
									}
								}
							});
							*/
						}
					});
				} else {
					logger.error("Unable to find the empId details in patchShiftCrewMemberOnShiftPatchAPI call" + " " + shiftCrewMemberCrewId + " " + responseStatusCode);
					var errorinfo = "Unable to find the empId details in patchShiftCrewMemberOnShiftPatchAPI call" + " " + shiftCrewMemberCrewId + " " + responseStatusCode;
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', errorinfo);
				}
			}
		});
	}
	//End:CrewMember PATCH call function start to  Update the shiftCrewMemberCrewId CustomFields 


	//Start:CrewLeader POST call function start to  Update the shiftCrewLeaderCrewId CustomFields
	function postShiftCrewLeaderCall(url, method, payload, shiftCrewLeaderCrewId) {
		var postShiftCrewLeaderAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		ILSctx.setVariable("exitpayload", JSON.stringify(postShiftCrewLeaderAPI.data));
		var info = " TargetURL :" + postShiftCrewLeaderAPI.target + "; Method :" + postShiftCrewLeaderAPI.method + "; Data :" + JSON.stringify(postShiftCrewLeaderAPI.data) + ". ";
		urlopen.open(postShiftCrewLeaderAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("cms_019:urlopen connect error with postShiftCrewLeaderAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with postShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with postShiftCrewLeaderAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to postShiftCrewLeaderAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to postShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to postShiftCrewLeaderAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from postShiftCrewLeaderAPI for empId:" + shiftCrewLeaderCrewId + "" + responseStatusCode);
							var postShiftCrewLeaderAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("postShiftCrewLeaderAPIResponse", postShiftCrewLeaderAPIResponse);
							var postShiftCrewLeaderAPIResponseid = postShiftCrewLeaderAPIResponse.id
							var postCrewLeaderOnShiftApiUrl = omsExternalURL + 'Crew/' + postShiftCrewLeaderAPIResponseid + '/OnShift';
							var postCrewLeaderOnShiftRequest = {
								"shiftOnTime": timestamp
							}
							// ADO146962 commenting the onshift PATCH call
							/*
							var postCrewLeaderOnshiftAPIRequest = {
								target: postCrewLeaderOnShiftApiUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'POST',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: postCrewLeaderOnShiftRequest
							};
							ILSctx.setVariable("exitpayload", JSON.stringify(postCrewLeaderOnshiftAPIRequest.data));
							var info = " TargetURL :" + postCrewLeaderOnshiftAPIRequest.target + "; Method :" + postCrewLeaderOnshiftAPIRequest.method + "; Data :" + JSON.stringify(postCrewLeaderOnshiftAPIRequest.data) + ". ";
							urlopen.open(postCrewLeaderOnshiftAPIRequest, function(error, response) {
								if (error) {
									var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
									ctx.setVariable("retry", 'yes');
									logger.error("urlopen connect error with postCrewLeaderOnshiftAPI" + JSON.stringify(error));
									var errorinfo = "urlopen connect error with postCrewLeaderOnshiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									var ErrorTxt = "urlopen connect error with postCrewLeaderOnshiftAPI";
									ctx.setVariable("ErrorTxt", ErrorTxt);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("failure in putting message to postCrewLeaderOnshiftAPI" + JSON.stringify(error));
												var errorinfo = "failure in putting message to postCrewLeaderOnshiftAPI, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												session.reject("failure in putting message to postCrewLeaderOnshiftAPI");
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from postCrewLeaderOnshiftAPI for shiftCrewLeaderCrewId:" + "" + responseStatusCode);
												var postCrewLeaderOnshiftAPIResponse = JSON.parse(responseData);
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("postCrewLeaderOnshiftAPIResponse", postCrewLeaderOnshiftAPIResponse);
												console.log("postCrewLeaderOnshiftAPIResponse----" + JSON.stringify(postCrewLeaderOnshiftAPIResponse));
											}
										});
									} else {
										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  postCrewLeaderOnshiftAPIResponse " + " " + JSON.stringify(error));
												var errorinfo = "Error response received from  postCrewLeaderOnshiftAPIResponse, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											} else {
												logger.error("Error response received from postCrewLeaderOnshiftAPIResponse " + " " + responseData);
												var errorinfo = "Error response received from postCrewLeaderOnshiftAPIResponse " + " " + responseData;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											}
										});
										//end
									}
								}
							});
							*/

						}
					});
				} else {
					logger.error("Unable to find the crewId details in postCrewLeaderOnshiftAPIResponse call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode);
					var errorinfo = "Unable to find the crewId details in postCrewLeaderOnshiftAPIResponse call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode;
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', errorinfo);
				}
			}
		});
	}
	//End:CrewLeader POST call function start to  Update the shiftCrewLeaderCrewId CustomFields 

	//Start:CrewLeader PATCH call function start to Update the shiftCrewLeaderCrewId CustomFields 
	function patchShiftCrewLeaderCall(url, method, payload, shiftCrewLeaderCrewId, getShiftCrewLeadId) {
		var patchShiftCrewLeaderAPI = {
			target: url,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: method,
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		ILSctx.setVariable("exitpayload", JSON.stringify(patchShiftCrewLeaderAPI.data));
		var info = " TargetURL :" + patchShiftCrewLeaderAPI.target + "; Method :" + patchShiftCrewLeaderAPI.method + "; Data :" + JSON.stringify(patchShiftCrewLeaderAPI.data) + ". ";
		urlopen.open(patchShiftCrewLeaderAPI, function(error, response) {
			if (error) {
				var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
				ctx.setVariable("retry", 'yes');
				logger.error("urlopen connect error with patchShiftCrewLeaderAPI" + JSON.stringify(error));
				var errorinfo = "urlopen connect error with patchShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				var ErrorTxt = "urlopen connect error with patchShiftCrewLeaderAPI";
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in putting message to patchShiftCrewLeaderAPI" + JSON.stringify(error));
							var errorinfo = "failure in putting message to patchShiftCrewLeaderAPI, details are : " + info + "; error info :" + JSON.stringify(error);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in putting message to patchShiftCrewLeaderAPI");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from patchShiftCrewLeaderAPI for crewId:" + shiftCrewLeaderCrewId + "" + responseStatusCode);
							var patchShiftCrewLeaderAPIResponse = JSON.parse(responseData);
							var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
							ctx.setVariable("patchShiftCrewLeaderAPIResponse", patchShiftCrewLeaderAPIResponse);
							var patchShiftCrewLeaderOnShiftAPIUrl = omsExternalURL + 'Crew/' + getShiftCrewLeadId + '/OnShift';
							var patchShiftCrewLeaderOnShiftPatchRequest = {
								"shiftOnTime": timestamp
							}
							// ADO146962 commenting the onshift PATCH call
							/*
							var patchShiftCrewLeaderRequest = {
								target: patchShiftCrewLeaderOnShiftAPIUrl,
								sslClientProfile: 'omscms_oms_ssl_ClientProfile',
								method: 'POST',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: patchShiftCrewLeaderOnShiftPatchRequest
							};
							ILSctx.setVariable("exitpayload", JSON.stringify(patchShiftCrewLeaderRequest.data));
							var info = " TargetURL :" + patchShiftCrewLeaderRequest.target + "; Method :" + patchShiftCrewLeaderRequest.method + "; Data :" + JSON.stringify(patchShiftCrewLeaderRequest.data) + ". ";
							urlopen.open(patchShiftCrewLeaderRequest, function(error, response) {
								if (error) {
									logger.error("urlopen connect error with patchShiftCrewLeaderOnShiftPatchAPI" + JSON.stringify(error));
									var errorinfo = "urlopen connect error with patchShiftCrewLeaderOnShiftPatchAPI, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									session.reject("urlopen connect error with patchShiftCrewLeaderOnShiftPatchAPI");
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("retry", 'yes');
												logger.error("urlopen connect error with patchShiftCrewLeaderOnShiftPatchAPI" + JSON.stringify(error));
												var errorinfo = "urlopen connect error with patchShiftCrewLeaderOnShiftPatchAPI, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												var ErrorTxt = "urlopen connect error with patchShiftCrewLeaderOnShiftPatchAPI";
												ctx.setVariable("ErrorTxt", ErrorTxt);
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from patchShiftCrewLeaderOnShiftPatchAPI for shiftCrewLeaderCrewId:" + "" + responseStatusCode);
												var patchShiftCrewLeaderOnShiftPatchAPIResponse = JSON.parse(responseData);
												var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
												ctx.setVariable("patchShiftCrewLeaderOnShiftPatchAPIResponse", patchShiftCrewLeaderOnShiftPatchAPIResponse);
											}
										});
									} else {
										//start 
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												logger.error("Error response received from  patchShiftCrewLeaderOnShiftPatchAPIResponse " + " " + JSON.stringify(error));
												var errorinfo = "Error response received from  patchShiftCrewLeaderOnShiftPatchAPIResponse, details are : " + info + "; error info :" + JSON.stringify(error);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											} else {
												logger.error("Error response received from patchShiftCrewLeaderOnShiftPatchAPIResponse " + " " + responseData);
												var errorinfo = "Error response received from patchShiftCrewLeaderOnShiftPatchAPIResponse " + " " + responseData;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
											}
										});
										//end
									}
								}
							});
							*/
						}
					});
				} else {
					logger.error("Unable to find the crewId details in patchShiftCrewLeaderOnShiftPatchAPI call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode);
					var errorinfo = "Unable to find the crewId details in patchShiftCrewLeaderOnShiftPatchAPI call" + " " + shiftCrewLeaderCrewId + " " + responseStatusCode;
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', errorinfo);
				}
			}
		});
	}
	//End:CrewLeader PATCH call function start to  Update the shiftCrewLeaderCrewId CustomFields 

});//End Session
