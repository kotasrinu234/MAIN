var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
var apiToken = ctx.getVar("apiToken");
var omsURL = ctx.getVar("omsURL");
var aorIDArrayfromLookup = ctx.getVar("aorIDArray");
//var IdfromCrewTypesfromLookup= "628b42229f003e33aa8db27c";
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		/*Start Of OMS Call to GetListOfCrews*/
		var GetListOfCrewVariable = session.createContext('CrewRoster1');
		var skip = 0;
		var take = 1000;
		var OMSUrl = omsURL + 'api/ServiceType/Electric/Crew' + '?excludeDeprecated=true&includeFields=type,aorIDs,externalID,id&skip=' + skip + '&take=' + take;
		var resArray = [];
		//Recursive function call
		function getDataFn(OMSUrl) {
			fetchData(OMSUrl, function(error, responseData) {
				if (error) {
				} else {
					var total = responseData.total;
					resArray = [...resArray, ...responseData.data]
					if (total == take) {
						// call the function recursively when total == take
						skip = skip + 1000;
						OMSUrl = omsURL + 'api/ServiceType/Electric/Crew' + '?excludeDeprecated=true&includeFields=type,aorIDs,externalID,id&skip=' + skip + '&take=' + take;
						getDataFn(OMSUrl);
					} else {
						//var crewAPICallArray = [];
						var crewAPICallArray = resArray;
						var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
						//ctx.setVariable('crewAPICallArr', crewAPICallArr);

						/*	var Id;
							var type;
							for(var i=0; i<crewAPICallArr.length;i++){
								var aorLen = crewAPICallArr[i].aorIDs.length;
								var crewAorIdsList = [];
								Id = crewAPICallArr[i].id;
								type = crewAPICallArr[i].type;
								for(var j=0; j<aorLen; j++){
									crewAorIdsList.push(crewAPICallArr[i].aorIDs[j])
								  }
								var crewJsonFilterList ={
										"id" : Id,
										"aorIDs" :   crewAorIdsList,
										"type" :   type
								}
								crewAPICallArray.push(crewJsonFilterList);
							}*/
						ctx.setVariable('crewAPICallArray', crewAPICallArray);

						return resArray;
					}
				}
			});
		}
		getDataFn(OMSUrl);
	}

	function fetchData(OMSUrl, cb) {
		var GetListOfCrews = {
			target: OMSUrl,
			sslClientProfile: 'omscms_oms_ssl_ClientProfile',
			method: 'get',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			}
		};
		var info = " TargetURL: " + GetListOfCrews.target + "; Method: " + GetListOfCrews.method + ". ";
		urlopen.open(GetListOfCrews, function(error, response) {
			if (error) {
				logger.error("urlopen connect error with GetListOfCrews from oms " + JSON.stringify(error));
				var errorinfo = "urlopen connect error with GetListOfCrews from oms, details are : " + info + "; error info :" + error;
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo);
				session.reject("urlopen connect error with GetListOfCrews from oms " + JSON.stringify(error))
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							logger.error("urlopen connect error with oms GetListOfCrewVariable " + JSON.stringify(error));
							var errorinfo = "urlopen connect error with oms GetListOfCrewVariable, details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							cb(error, null);
						} else {
							hm.response.statusCode = '200 Message is received';
							logger.debug("response received from 1st GetListOfCrews OMS call:" + responseData);
							//GetListOfCrewVariable.setVariable("GetListOfCrewVariable", responseData);
							var total = responseData.total;
							GetListOfCrewVariable.setVariable("total", total);
							cb(null, responseData);
						}
					})
				}else if (responseStatusCode == 401 || responseStatusCode == 403) {
					// Handle business error responses (HTTP 401 or 403)
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// Handle error in reading response data
							var errorinfo = "gcc_004: error reading response 'GetListOfCrewVariable Authentication/Authentication Error', details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "gcc_004: error response 'GetListOfCrewVariable Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
					}else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error("failure in reading message from UpdateCrewLocation OMS call " + JSON.stringify(error));
							var errorinfo = "failure in reading message from UpdateCrewLocation OMS call, details are : " + info + "; error info :" + error;
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo);
							session.reject("failure in reading message from UpdateCrewLocation OMS call ");
						} else {
							hm.current.statusCode = responseStatusCode;
							logger.error("Error returned from GetListOfCrews OMS call" + " : with statusCode " + responseStatusCode + " " + responseData);
							var errorinfo = "Error returned from GetListOfCrews OMS call, details are : " + info + "; error info :" + responseData;
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							cb("Error returned from GetListOfCrews OMS call" + " : with statusCode " + responseStatusCode, null);
						}
					});
				}
			}
		}); //URL open closed
	}
});
