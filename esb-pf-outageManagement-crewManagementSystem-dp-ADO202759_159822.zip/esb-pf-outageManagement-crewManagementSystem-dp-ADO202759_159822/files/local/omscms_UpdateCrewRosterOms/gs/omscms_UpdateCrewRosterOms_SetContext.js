var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

var ctx = session.name("CrewRoster")|| session.createContext("CrewRoster");
//set stylesheet parameters to variable
var omsExternalURL = session.parameters.omsExternalURL;
var omsURL = session.parameters.omsurl;
var apiToken = session.parameters.osiApiToken;
var lookupURL =session.parameters.lookupURL;
//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js
ctx.setVariable("omsURL", omsURL);
ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("lookupURL",lookupURL);
}
});
