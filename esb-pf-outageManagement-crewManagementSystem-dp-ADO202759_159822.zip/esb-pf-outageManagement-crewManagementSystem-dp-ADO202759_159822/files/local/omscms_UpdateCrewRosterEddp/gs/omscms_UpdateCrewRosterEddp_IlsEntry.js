var ctx = session.name("omscms") || session.createContext("omscms");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var logger = console.options({
	'category': 'all'
});


session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {

		ctx.setVariable('description', session.parameters.EddpEntryDescription);
		ctx.setVariable("correlationID", incomingData.messageID);
		ctx.setVariable("messageType", 'crewManagementEvent');
		if (!(incomingData.workGroup == undefined) || !(incomingData.workGroup == null) || !(incomingData.workGroup === '')) {
			ctx.setVariable("crewTypeDisplayID", incomingData.workGroup)
		}
		if (!(incomingData.rosterId == undefined) || !(incomingData.rosterId == null) || !(incomingData.rosterId === '')) {
			ctx.setVariable("rosterId", incomingData.rosterId)
		}
		if (!(incomingData.rosterDate == undefined) || !(incomingData.rosterDate == null) || !(incomingData.rosterDate === '')) {
			ctx.setVariable("rosterDate", incomingData.rosterDate)
		}
		if (!(incomingData.serviceCenter == undefined) || !(incomingData.serviceCenter == null) || !(incomingData.serviceCenter === '')) {
			ctx.setVariable("serviceCenter", incomingData.serviceCenter)
		}
		if (!(incomingData.createdTimestamp == undefined) || !(incomingData.createdTimestamp == null) || !(incomingData.createdTimestamp === '')) {
			ctx.setVariable("sourceEventTimestamp", incomingData.createdTimestamp)
		}
		var urlIn = sm.getVar('var://service/URL-in');
		ctx.setVariable('sourceUrl', urlIn)



	}

});