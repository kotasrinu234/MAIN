var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("CrewRoster") || session.createContext("CrewRoster");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var logger = console.options({
	'category': 'all'
});
var eddpurl = session.parameters.EddpURL
var code = session.parameters.code
var apikey = session.parameters.apikey
var url = eddpurl + "?code=" + code
ILSctx.setVariable("exitDestination", url)
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var payload = incomingdata
		var Eddpapi = {
			target: url,
			sslClientProfile: 'EDDP_Client_Profile',
			method: 'POST',
			contentType: 'application/json',
			headers: {
				'x-api-key': apikey
			},
			data: payload
		};
		var info = " TargetURL :" + Eddpapi.target + "; Method :" + Eddpapi.method + "; Data :" + JSON.stringify(Eddpapi.data) + ". ";
		urlopen.open(Eddpapi, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with Eddpapi, details are : " + info + "; error info :" + error
				ILSctx.setVariable('exitStatus', '500');
				ILSctx.setVariable('Exitdescription', errorinfo)
				ctx.setVariable("retry", 'yes');
				logger.error(errorinfo);
				var ErrorTxt = "urlopen connect error with Eddpapi " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt)
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in getting message, details are : " + info + "; error info :" + JSON.stringify(error)
							ILSctx.setVariable('exitStatus', responseStatusCode);
							ILSctx.setVariable('Exitdescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug(" responsedata: " + responseData + "reponse code is  " + responseStatusCode);
							ILSctx.setVariable('exitStatus', "0");
							ILSctx.setVariable('Exitdescription', session.parameters.EddpExitdescription);
						}

					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in getting message, details are : " + info + "; error info :" + JSON.stringify(error)
							ILSctx.setVariable('exitStatus', responseStatusCode);
							ILSctx.setVariable('Exitdescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "response code from EDDP Call : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('exitStatus', responseStatusCode);
							ILSctx.setVariable('Exitdescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		})
	}
});
