# esb-pf-customerInformation-meterExchangeListenerService-dp
interface 4b meterexchange subs
Deployment instructions:

#IIBMQ scripts are uploaded in dteenergy/esb-pf-customerInformation-meterExchangeListenerService-mq.
IIB Retry MQ pipleline needs to be run for retry esb-pf-common-retry-iib

MQCSP details will be given by DTE ESB team.

Password aliases will be created by DTE ESB team.

Private keys and certs need to be provided by DTE ESB team.

Properties file as per env are in the config folder of this repository.

Jenkins file as per env are also uploaded in this repository.
