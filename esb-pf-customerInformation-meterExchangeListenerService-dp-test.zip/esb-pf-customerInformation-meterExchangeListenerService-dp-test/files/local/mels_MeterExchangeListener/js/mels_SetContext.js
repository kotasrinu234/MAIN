//js is used to read stylesheet param and set to context variables 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

var ctx = session.name("mens")|| session.createContext("mens");
//set stylesheet parameters to variable
var omsExternalURL = session.parameters.omsExternalURL;
var osiApiToken = session.parameters.osiApiToken;
var nullCheckRequired = session.parameters.nullCheckRequired;

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("osiApiToken", osiApiToken);
ctx.setVariable("nullCheckRequired", nullCheckRequired);
}
});