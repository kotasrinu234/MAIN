//js is used to perform nullcheck for the input request
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("plopub")|| session.createContext("plopub");
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var ctx = session.name("mens")|| session.createContext("mens");
	var nullCheckRequired = ctx.getVar("nullCheckRequired");
	
	if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		
		if(nullCheckRequired == 'yes'){
			
			
				
				var customFieldValuesExt = incomingdata.data[0].customFieldValuesExt;
				if (customFieldValuesExt == null || customFieldValuesExt == '' || customFieldValuesExt == undefined) {
					logger.error('Exchange_Meter_In is not present in input payload');
					var schemacheck = 'schema failed';
					ctx.setVariable("schemacheck", schemacheck);
		            session.reject('Exchange_Meter_In is not present in input payload');
		        }else{
		        	
		        	var Exchange_Meter_In = incomingdata.data[0].customFieldValuesExt.Exchange_Meter_In;
		        	if (Exchange_Meter_In == null || Exchange_Meter_In == '' || Exchange_Meter_In == undefined) {
						logger.error('Exchange_Meter_In is not present in input payload');
						var schemacheck = 'schema failed';
						ctx.setVariable("schemacheck", schemacheck);
			            session.reject('Exchange_Meter_In is not present in input payload');
			        }
		        }
				
				
				var leadCall = incomingdata.data[0].leadCall;
				if (leadCall == null || leadCall == '' || leadCall == undefined) {
					logger.error('leadCall.externalPremiseID is not present in input payload');
					var schemacheck = 'schema failed';
					ctx.setVariable("schemacheck", schemacheck);
		            session.reject('leadCall.externalPremiseID is not present in input payload');
		        }else{
		        	
		        	var externalPremiseID = incomingdata.data[0].leadCall.externalPremiseID;
		        	if (externalPremiseID == null || externalPremiseID == '' || externalPremiseID == undefined) {
						logger.error('externalPremiseID is not present in input payload');
						var schemacheck = 'schema failed';
						ctx.setVariable("schemacheck", schemacheck);
			            session.reject('externalPremiseID is not present in input payload');
			        }
		        }
				
				
			
		}
	}
	});
