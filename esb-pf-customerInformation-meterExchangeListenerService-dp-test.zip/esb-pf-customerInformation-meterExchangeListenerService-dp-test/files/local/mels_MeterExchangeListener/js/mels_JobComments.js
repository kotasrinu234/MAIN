var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("mens") || session.createContext("mens");
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("mens") || session.createContext("mens");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");

	var apiToken = ctx.getVar("osiApiToken");

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		if (incomingdata.data[0].id != undefined) {
			var jobid = incomingdata.data[0].id;
			var jobapiuri = omsExternalURL + '/oms/external/api/ServiceType/Electric/Job/' + jobid + '/Comment';
			var TokenValue = apiToken;

			var jobapi = {
				target: jobapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
			};
			var info = " TargetURL :" + jobapi.target + "; Method :" + jobapi.method + ". ";
			try {
				urlopen.open(jobapi, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error with GET jobapi with id, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "error message while reading response from jobapi, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									//store status code with response body in context variable

									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from jobapi for jobid:" + jobid + "is :" + responseStatusCode);
									var ctx = session.name("mens") || session.createContext("mens");

									var comments = JSON.parse(responseData);
									//session.output.write(comments[0].comment);
									var jobcommentslength = comments.length;
									var jobcomments;
									var jobcommentsmerged = '';
									for (var i = 0; i < jobcommentslength; i++) {

										jobcomments = comments[i].comment;

										jobcommentsmerged = jobcommentsmerged + ' ' + jobcomments;
									}
									var ctx = session.name("mens") || session.createContext("mens");
									var commentlength = session.parameters.commentlength;
									commentlength = parseInt(commentlength) + 1;

									var finaljobcomments = jobcommentsmerged.slice(1, commentlength);
									logger.debug("finaljobcomments inside is" + jobcommentsmerged);
									ctx.setVariable("finaljobcomments", finaljobcomments);
								}
							});
						} else if (responseStatusCode == 401) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "mels_003: error reading response 'jobapi Authentication Error', details are : " + info + "; error info :" + error;
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "mels_003: error reading response 'jobapi Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						} else if (responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "mels_004: error reading response 'jobapi Authentication/Authroziation Error', details are : " + info + "; error info :" + error;
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "mels_004: error reading response 'jobapi Authentication/Authroziation Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading message from jobapi  for jobid, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode)
									ILSctx.setVariable('ExitDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var responseinfo = "Error returned from jobapi  for jobid : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', responseinfo)
									logger.error(responseinfo);
									session.reject(responseinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "urlopen connect error with GET jobapi with id, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo)
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		} else {
			logger.error(" jobid is not present in input payload");
			session.reject("jobid is not present in input payload");
		}
	}
});
