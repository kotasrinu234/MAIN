var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var ctx = session.name("mens") || session.createContext("mens");
var ILSctx = session.name('ILS') || session.createContext('ILS');
 
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
 
	// getting styleheet params
	var ctx = session.name("mens") || session.createContext("mens");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
 
	var apiToken = ctx.getVar("osiApiToken");
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		if (incomingdata.data[0].leadCall.externalPremiseID != undefined) {
			var externalPremiseID = incomingdata.data[0].leadCall.externalPremiseID;
			//GET /api/Premise/{id}
			var premiseapiuri = omsExternalURL + '/oms/external/api/Premise/' + externalPremiseID;
			var TokenValue = apiToken;
 
			var premiseapi = {
				target: premiseapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
 
			};
 
			var info = " TargetURL :" + premiseapi.target + "; Method :" + premiseapi.method + ". ";
			try {
				urlopen.open(premiseapi, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error with GET premiseapi with externalPremiseID, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "error message while reading response from jobapi, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									//dp:reject stop the transaction and go error rule with error code and description
									//store status code with response body in context variable
									//ILSctx.setVariable('ExitDescription', ExitDescription)
									ILSctx.setVariable('ExitDestination', omsExternalURL)
									//ILSctx.setVariable('omsExternalURL', omsExternalURL)
									ILSctx.setVariable('ExitDescription', session.parameters.PremiseExitDescription)
									ms.callRule('mels_MeterExchangeListener_Exit_rule', null, null, function(error) {
										if (error) {
											logger.error("Error in mels_MeterExchangeListener_Exit_rule	");
										}
									});
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from premiseapi for externalPremiseID:" + externalPremiseID + "is :" + responseStatusCode);
									var ctx = session.name("mens") || session.createContext("mens");
									var premiseresponse = JSON.parse(responseData);
									ctx.setVariable("premiseresponse", premiseresponse);
 
									var streetNumber;
									if (premiseresponse.customFieldValuesExt != undefined || premiseresponse.customFieldValuesExt != null || premiseresponse.customFieldValuesExt != '') {
										if (premiseresponse.customFieldValuesExt.Site_Street_Number != undefined || premiseresponse.customFieldValuesExt.Site_Street_Number != null || premiseresponse.customFieldValuesExt.Site_Street_Number != '') {
											streetNumber = premiseresponse.customFieldValuesExt.Site_Street_Number;
										}
									}
 
									var streetName;
									if (premiseresponse.customFieldValuesExt != undefined || premiseresponse.customFieldValuesExt != null || premiseresponse.customFieldValuesExt != '') {
										if (premiseresponse.customFieldValuesExt.Site_Street_Name != undefined || premiseresponse.customFieldValuesExt.Site_Street_Name != null || premiseresponse.customFieldValuesExt.Site_Street_Name != '') {
											streetName = premiseresponse.customFieldValuesExt.Site_Street_Name;
										}
									}
 
									var streetSuffix;
									if (premiseresponse.customFieldValuesExt != undefined || premiseresponse.customFieldValuesExt != null || premiseresponse.customFieldValuesExt != '') {
										if (premiseresponse.customFieldValuesExt.Site_Street_Suffix != undefined || premiseresponse.customFieldValuesExt.Site_Street_Suffix != null || premiseresponse.customFieldValuesExt.Site_Street_Suffix != '') {
											streetSuffix = premiseresponse.customFieldValuesExt.Site_Street_Suffix;
										}
									}
 
									var city;
									if (premiseresponse.customFieldValuesExt != undefined || premiseresponse.customFieldValuesExt != null || premiseresponse.customFieldValuesExt != '') {
										if (premiseresponse.customFieldValuesExt.Site_City != undefined || premiseresponse.customFieldValuesExt.Site_City != null || premiseresponse.customFieldValuesExt.Site_City != '') {
											city = premiseresponse.customFieldValuesExt.Site_City;
										}
									}
 
									var inMeter;
									if (incomingdata.data[0].customFieldValuesExt != undefined || incomingdata.data[0].customFieldValuesExt != null || incomingdata.data[0].customFieldValuesExt != '') {
										if (incomingdata.data[0].customFieldValuesExt.Exchange_Meter_In != undefined || incomingdata.data[0].customFieldValuesExt.Exchange_Meter_In != null || incomingdata.data[0].customFieldValuesExt.Exchange_Meter_In != '') {
											inMeter = premiseresponse.customFieldValuesExt.Exchange_Meter_In;
										}
									}
 
									var payload = {
										"MeterExchange": {
											"inMeter": {
											},
											"outMeter": {
												"register": {
												}
											}
										}
									}
 
									payload.MeterExchange.fieldRepID = incomingdata.data[0].createdByUserName;
									var ctx = session.name("mens") || session.createContext("mens");
									var jobcomments = ctx.getVar("finaljobcomments");
 
									if (jobcomments.length > 0) {
										payload.MeterExchange.fieldRemarks = jobcomments;
									}
									payload.MeterExchange.fieldCompletionDate = incomingdata.data[0].updatedAt;
									payload.MeterExchange.sendDateTime = incomingdata.data[0].updatedAt;
									payload.MeterExchange.premiseNumber = incomingdata.data[0].leadCall.externalPremiseID;
									payload.MeterExchange.streetNumber = streetNumber;
									payload.MeterExchange.streetName = streetName;
									payload.MeterExchange.streetSuffix = streetSuffix;
									payload.MeterExchange.city = city;
 
									if (incomingdata.data[0].customFieldValuesExt != undefined || incomingdata.data[0].customFieldValuesExt != null || incomingdata.data[0].customFieldValuesExt != '') {
										if (incomingdata.data[0].customFieldValuesExt.Exchange_Meter_In != undefined || incomingdata.data[0].customFieldValuesExt.Exchange_Meter_In != null || incomingdata.data[0].customFieldValuesExt.Exchange_Meter_In != '') {
											payload.MeterExchange.inMeter.meterNumber = incomingdata.data[0].customFieldValuesExt.Exchange_Meter_In;
										}
									}
									if (incomingdata.data[0].customFieldValuesExt != undefined || incomingdata.data[0].customFieldValuesExt != null || incomingdata.data[0].customFieldValuesExt != '') {
										if (incomingdata.data[0].customFieldValuesExt.Exchange_Meter_Out != undefined || incomingdata.data[0].customFieldValuesExt.Exchange_Meter_Out != null || incomingdata.data[0].customFieldValuesExt.Exchange_Meter_Out != '') {
											payload.MeterExchange.outMeter.meterNumber = incomingdata.data[0].customFieldValuesExt.Exchange_Meter_Out;
										} else {
											payload.MeterExchange.outMeter.meterNumber = 'NON';
											payload.MeterExchange.outMeter.register.type = 'NON';
										}
									} else {
										payload.MeterExchange.outMeter.meterNumber = 'NON';
										payload.MeterExchange.outMeter.register.type = 'NON';
									}
									if (incomingdata.data[0].customFieldValuesExt != undefined || incomingdata.data[0].customFieldValuesExt != null || incomingdata.data[0].customFieldValuesExt != '') {
										if (incomingdata.data[0].customFieldValuesExt.Exchange_Meter_Out_Reading != undefined || incomingdata.data[0].customFieldValuesExt.Exchange_Meter_Out_Reading != null || incomingdata.data[0].customFieldValuesExt.Exchange_Meter_Out_Reading != '') {
											payload.MeterExchange.outMeter.register.meterRead = incomingdata.data[0].customFieldValuesExt.Exchange_Meter_Out_Reading;
										}
									}
 
									var ctx = session.name("mens") || session.createContext("mens");
									ctx.setVariable("CRBPayload", payload);
									//session.output.write(payload);
 
									//var payload = incomingdata;
									//	ctx.setVariable("CRB_IncomingData", payload);
 
									//  headers.set('Authorization',Auth);
									//          session.output.write(payload);
 
									var crburi = session.parameters.CRMB_EndpointUrl;
									//ILSctx.setVariable('ExitDestination', crburi)
									var crbcall = {
										target: crburi,
										sslClientProfile: 'mels_MeterExchangeListener_CRB_Client_Profile',
										method: 'POST',
										contentType: 'application/json',
										data: payload
									};
session.output.write(payload)
									var info = " TargetURL :" + crbcall.target + "; Method :" + crbcall.method + "; Data :" + JSON.stringify(crbcall.data) + ". ";
									try {
										urlopen.open(crbcall, function(error, response) {
											if (error) {
												var errorinfo = "mels_002 urlopen connect error with CRB post, details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ExitDescription', errorinfo)
												logger.error(errorinfo);
												var ctx = session.name("mels") || session.createContext("mels");
												ctx.setVariable("retry", 'yes');
												var ErrorTxt = "mels_002 urlopen connect error with crbcall post is " + JSON.stringify(error);
												ctx.setVariable("ErrorTxt", ErrorTxt);
											} else {
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200 || responseStatusCode == 202) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															//dp:reject stop the transaction and go error rule with error code and description
															var errorinfo = "error message while reading from crbcall post call, details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', responseStatusCode);
															ILSctx.setVariable('ExitDescription', errorinfo)
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
 
															hm.response.statusCode = responseStatusCode;
															logger.debug("response code recieved from call crbcall is " + responseStatusCode);
 
														}
													});
												} else {
													var responseinfo = "mels_002 response returned from CR&B post call : " + info + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable('ExitStatus', responseStatusCode);
													ILSctx.setVariable('ExitDescription', responseinfo)
													logger.error(responseinfo);
													var ctx = session.name("mels") || session.createContext("mels");
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = "mels_002 response returned from CR&B post call is " + responseStatusCode;
													ctx.setVariable("ErrorTxt", ErrorTxt);
												}
											}
										});
									} catch (error) {
										var errorinfo = "mels_002 urlopen connect error with CRB post, details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitDescription', errorinfo)
										ILSctx.setVariable('ExitStatus', '500');
										logger.error(errorinfo);
										var ctx = session.name("mels") || session.createContext("mels");
										ctx.setVariable("retry", 'yes');
										var ErrorTxt = "mels_002 urlopen connect error with crbcall post is " + JSON.stringify(error);
										ctx.setVariable("ErrorTxt", ErrorTxt);
									}
									//
								}
 
							});
 
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "failure in reading message from  premise get call, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var responseinfo = "response returned from premise get call for externalpremiseid, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', responseinfo)
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "urlopen connect error with GET premiseapi with externalPremiseID, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		} else {
			logger.error(" externalPremiseID is not  present in input payload");
			session.reject("externalPremiseID is not present in input payload");
		}
	}
 
});
