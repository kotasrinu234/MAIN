var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("mels") || session.createContext("mels");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ILSctx = session.name('ILS') || session.createContext('ILS');
		var retry = ctx.getVariable('retry');
		var ExitStatus = ILSctx.getVariable('ExitStatus');
		var ErrorTxt = ILSctx.getVariable('ExitDescription')		
		var omsExternalURL = session.parameters.CRMB_EndpointUrl;
		if (retry != 'yes') {
			ILSctx.setVariable('ExitStatus', '0');
			ILSctx.setVariable('ExitDestination', omsExternalURL);
			ILSctx.setVariable('ExitDescription', session.parameters.ExitDescription)
		} else {
			ILSctx.setVariable('ExitStatus', ExitStatus);
			ILSctx.setVariable('ExitDescription', ErrorTxt)
		}
	}
});
