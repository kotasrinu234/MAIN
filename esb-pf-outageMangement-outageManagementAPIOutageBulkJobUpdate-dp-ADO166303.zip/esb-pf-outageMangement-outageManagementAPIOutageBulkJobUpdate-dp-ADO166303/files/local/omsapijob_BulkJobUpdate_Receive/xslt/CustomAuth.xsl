<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpconfig="http://www.datapower.com/param/config"
extension-element-prefixes="dp dpconfig"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
exclude-result-prefixes="dp dpconfig">
	<xsl:param name="dpconfig:bulkAPIBindDN" select="''"/>
	<xsl:param name="dpconfig:bulkAPITargetBaseDN" select="''"/>
	<xsl:param name="dpconfig:dailyPlanBindDN" select="''"/>
	<xsl:param name="dpconfig:dailyPlanTargetBaseDN" select="''"/>
	<!-- Get the value-of stylesheet parameter -->
	<xsl:variable name="bulkAPIBindDN" select="$dpconfig:bulkAPIBindDN"/>
	<xsl:variable name="bulkAPITargetBaseDN" select="$dpconfig:bulkAPITargetBaseDN"/>
	<xsl:variable name="dailyPlanBindDN" select="$dpconfig:dailyPlanBindDN"/>
	<xsl:variable name="dailyPlanTargetBaseDN" select="$dpconfig:dailyPlanTargetBaseDN"/>
	<xsl:template match="/">
		<xsl:variable name="TransactionID">
			<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
		</xsl:variable>
		<xsl:variable name="encodedCredential" select="dp:http-request-header('Authorization')"/>
		<xsl:variable name="uname" select="substring-before(dp:decode(substring($encodedCredential,'7'),'base-64'),':')"/>
		<xsl:variable name="bindPWD" select="substring-after(dp:decode(substring($encodedCredential,'7'),'base-64'),':')"/>
		<dp:set-variable name="'var://context/current/user'" value="$uname" />
		<xsl:choose>
			<xsl:when test="($uname='esb-powapp-bju-dev') or ($uname='esb-powapp-bju-test') or ($uname='esb-powapp-bju-prod')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$bulkAPIBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$bulkAPITargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='esb-web-dpl-dev') or ($uname='esb-web-dpl-test') or ($uname='esb-web-dpl-prod')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$dailyPlanBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$dailyPlanTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/current/validUser'" value="'false'" />
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/current/validUser')='true'">
				<xsl:variable name="serverAddress" select="'corpad.dtenet.com'"/>
				<xsl:variable name="portNumber" select="'636'"/>
				<xsl:variable name="bindDN" select="dp:variable('var://context/current/bindDN')"/>
				<xsl:variable name="bindPassword" select="$bindPWD"/>
				<xsl:variable name="targetBaseDN" select="dp:variable('var://context/current/targetBaseDN')"/>
				<xsl:variable name="attributeName" select="'memberOf,dn'"/>
				<xsl:variable name="filter" select="'(|(objectClass=group))'"/>
				<xsl:variable name="sslProxyProfile" select="'client:omsapijob_BulkJobUpdate_Receive_AAA_Client_Profile'"/>
				<xsl:variable name="ldapLBGroup" select="''"/>
				<xsl:variable name="ldapResults" select="dp:ldap-search($serverAddress, $portNumber, $bindDN, $bindPassword, $targetBaseDN, $attributeName, $filter, 'sub', $sslProxyProfile, $ldapLBGroup)"/>
				<dp:set-variable name="'var://context/current/ldapResults'" value="$ldapResults" />
				<!-- <xsl:copy-of select="$ldapResults" /> -->
				<xsl:choose>
					<xsl:when test="$ldapResults/LDAP-search-results/result" >
						<accepted />
					</xsl:when>
					<xsl:otherwise >
						<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Methods'"/>
						<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Headers'"/>
						<dp:set-variable name="'var://context/aaa/customErrorCode'" value="'401'"/>
						<dp:set-variable name="'var://context/aaa/customErrorMessage'" value="'Unauthorized'"/>
						<dp:set-variable name="'var://context/aaa/customReasonMessage'" value="'Unauthorized'"/>
						<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'401'"/>
						<xsl:message dp:type="all" dp:priority="error">omsapijob_001: AAA failure for Bulk Job Upload Application with username:<xsl:value-of select="dp:variable('var://context/current/user')"/>ErrorMessage: Rejected by Policy,TransactionID:<xsl:value-of select="$TransactionID"/></xsl:message>
						<dp:reject>Rejected by Policy </dp:reject>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Methods'"/>
				<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Headers'"/>
				<dp:set-variable name="'var://context/aaa/customErrorCode'" value="'401'"/>
				<dp:set-variable name="'var://context/aaa/customErrorMessage'" value="'Unauthorized'"/>
				<dp:set-variable name="'var://context/aaa/customReasonMessage'" value="'Unauthorized'"/> 
				<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'401'"/>
			 	<xsl:message dp:type="all" dp:priority="error">omsapijob_001: AAA failure for Bulk Job Upload Application with username:<xsl:value-of select="dp:variable('var://context/current/user')"/>ErrorMessage: Rejected by Policy,TransactionID:<xsl:value-of select="$TransactionID"/></xsl:message> 
				<dp:reject>Rejected by Policy </dp:reject>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
