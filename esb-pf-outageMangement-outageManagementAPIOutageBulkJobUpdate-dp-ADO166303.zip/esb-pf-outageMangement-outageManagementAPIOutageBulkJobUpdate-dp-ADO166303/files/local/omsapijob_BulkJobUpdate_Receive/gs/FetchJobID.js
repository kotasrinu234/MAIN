var urlopen = require('urlopen');
var fs = require('fs');
var util = require('util');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('BulkJobUpdate') || session.createContext('BulkJobUpdate');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var bulkType = ctx.getVariable("bulkType");
var userId = ctx.getVariable("userId");
session.input.readAsJSON(async function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {
		for (let i = 0; i < incomingData.jobList.length; i++) {
			if (incomingData.jobList[i].jobId === undefined || incomingData.jobList[i].jobId === null || incomingData.jobList[i].jobId === '') {
				await updateJobId(incomingData);
				incomingData.jobList = incomingData.jobList.filter(isJobIdExist => {
					return (isJobIdExist.jobId && isJobIdExist.jobId != null && isJobIdExist.jobId != undefined)
				});
			}
		}
		session.output.write(incomingData);

	}
})
async function updateJobId(incomingData) {
	var jobDisplayIdList = [];
	var isJobId
	for (let i = 0; i < incomingData.jobList.length; i++) {
		if (incomingData.jobList[i].jobId === undefined || incomingData.jobList[i].jobId === null || incomingData.jobList[i].jobId === '') {
			if ((incomingData.jobList[i].jobDisplayId === undefined) || (incomingData.jobList[i].jobDisplayId === null) || (incomingData.jobList[i].jobDisplayId === '')) {
				// session.reject("jobId or jobDisplayId is a mandatory field ");
			}
			else {
				jobDisplayIdList.push(incomingData.jobList[i].jobDisplayId);

				ctx.setVariable("jobDisplayIdList", jobDisplayIdList);
				//post call to get jobId
				//    var JobId = await fetchJobId(incomingData.jobList[i].jobDisplayId);
				//	incomingData.jobList[i].jobId = JobId;					 
			}
		}

	}
	try {
		var JobIdList = await fetchJobId(jobDisplayIdList);
		var missedJobId = [];
		var errorJobId = [];
		for (let j = 0; j < incomingData.jobList.length; j++) {
			var keyToFind = 'displayID';
			if (incomingData.jobList[j].jobId === undefined || incomingData.jobList[j].jobId === null || incomingData.jobList[j].jobId === '') {
				var foundObject = JobIdList.find(obj => obj[keyToFind] === incomingData.jobList[j].jobDisplayId);
				if (foundObject) {
					incomingData.jobList[j].jobId = foundObject.id;
				}
				else {
					missedJobId.push(incomingData.jobList[j].jobDisplayId);
					ctx.setVariable("MissingJobIDs", missedJobId);
				}
			}
		}
	} catch (err) {
		//errorJobId = incomingData.jobList;
		ctx.setVariable("ErrorJobIDs", err);
		logger.error("Fetch jobid failed:" + JSON.stringify(err));
	}
}
function fetchJobId(displayIDList) {

	//post call to get jobId
	return new Promise((resolve, reject) => {
		let jobDisplayIdList = displayIDList;
		var responseJobid = [];
		var postJobDisplayIdList = jobDisplayIdList;
		var omsURL = session.parameters.omsURL;
		var omsToken;
		if (bulkType !== undefined && bulkType == 1) {
			omsToken = session.parameters.omsDailyPlanToken;
		}
		else {
			omsToken = session.parameters.omsToken;
		}

		var createURL = omsURL + "/oms/external/api/v1/ServiceType/Electric/Job/Query?isInternalIDs=false&includeFields=displayID%2Cid&historical=false";
		var create = {
			target: createURL,
			sslClientProfile: 'omsapi_client_profile',
			method: 'POST',
			contentType: 'application/json',
			data: postJobDisplayIdList,
			headers: {
				'osiApiToken': omsToken
			}
		};
		var info = " TargetURL :" + create.target + "; Method :" + create.method + "; Data :" + JSON.stringify(create.data) + ". ";
		try {
			urlopen.open(create, function(error, response) {
				if (error) {
					var errorinfo = "url connection error of 'jobDisplayIdcreateURL', details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in getting response of 'jobDisplayIdcreateURL', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								resolve(responseData);
							}
						});
					} else if ((responseStatusCode == 401)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapijob_002 : Unauthorized error message while reading response from post call 'jobDisplayIdcreateURL', details are : " + info + "; error info :" + JSON.stringify(error)
								ILSctx.setVariable('ExitStatus',responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								var errorinfo = "omsapijob_002 : Unauthorized error message while reading response from post call 'jobDisplayIdcreateURL' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus',responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							}
							var failedFetchJobId = {
								statusCode: responseStatusCode,
								failedReason: responseData.toString()
							};
							reject(failedFetchJobId);
						});
					} else if ((responseStatusCode == 403)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapijob_003 :Forbidden error message while reading response from post call 'jobDisplayIdcreateURL', details are : " + info + "; error info :" + JSON.stringify(error)
							ILSctx.setVariable('ExitStatus',responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								var errorinfo = "omsapijob_003 :Forbidden error message while reading response from post call 'jobDisplayIdcreateURL', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus',responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							}
							var failedFetchJobId = {
								statusCode: responseStatusCode,
								failedReason: responseData.toString()
							};
							reject(failedFetchJobId);
						});
					}else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in getting response of 'jobDisplayIdcreateURL', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var responseinfo = "Error returned " + ": with statusCode " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								session.reject(responseinfo);
								//session.reject("Error returned " + ": with statusCode " + responseStatusCode + " " + responseData);
							}
							var failedFetchJobId = {
								statusCode: responseStatusCode,
								failedReason: responseData.toString()
							};
							reject(failedFetchJobId);
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "url connection error of 'jobDisplayIdcreateURL', details are : " + info + "; error info :" + error
			ILSctx.setVariable('ExitStatus', '500');
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	})
}
