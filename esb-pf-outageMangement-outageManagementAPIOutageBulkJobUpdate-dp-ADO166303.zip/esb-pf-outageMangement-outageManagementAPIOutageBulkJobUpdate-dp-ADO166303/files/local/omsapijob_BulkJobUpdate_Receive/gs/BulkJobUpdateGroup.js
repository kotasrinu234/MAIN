var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('BulkJobUpdate') || session.createContext('BulkJobUpdate');

function groupBulkJob(jobList) {

	var reducedJobList = jobList.reduce((acc, item) => {

		if (!item.hasOwnProperty('notes')) {
			item.notes = "noNotesKey";
		}
		if (!item.hasOwnProperty('outageSubtypeId')) {
			item.outageSubtypeId = "noOutageSubtypeIdKey";
		}
		if (!item.hasOwnProperty('changeReason')) {
			item.changeReason = "noChangeReasonKey";
		}
		if (!item.hasOwnProperty('etrStatus')) {
			item.etrStatus = "noEtrStatusKey";
		}
		if (!item.hasOwnProperty('etrStatus')) {
			item.etrStatus = "noEtrStatusKey";
		}
		if (!item.hasOwnProperty('publishedEtr')) {
			item.publishedEtr = {};
			item.publishedEtr.overridden = "nooverriddenKey";
			item.publishedEtr.value = "novalueKey";
			item.publishedEtr.estimateDayOfFlag = "noestimateDayOfFlagKey";
			item.publishedEtr.estimateDurationAfterMinutes = "noestimateDurationAfterMinutesKey";
			item.publishedEtr.estimateDurationBeforeMinutes = "noestimateDurationBeforeMinutesKey";
			item.publishedEtr.estimateType = "noestimateTypeKey";
		} else if (!item.publishedEtr.hasOwnProperty('overridden')) {
			item.publishedEtr.overridden = "nooverriddenKey";
		}
		else if (!item.publishedEtr.hasOwnProperty('value')) {
			item.publishedEtr.value = "novalueKey";
		}
		else if (!item.publishedEtr.hasOwnProperty('estimateDayOfFlag')) {
			item.publishedEtr.estimateDayOfFlag = "noestimateDayOfFlagKey";
		}
		else if (!item.publishedEtr.hasOwnProperty('estimateDurationAfterMinutes')) {
			item.publishedEtr.estimateDurationAfterMinutes = "noestimateDurationAfterMinutesKey";
		}
		else if (!item.publishedEtr.hasOwnProperty('estimateDurationBeforeMinutes')) {
			item.publishedEtr.estimateDurationBeforeMinutes = "noestimateDurationBeforeMinutesKey";
		}
		else if (!item.publishedEtr.hasOwnProperty('estimateType')) {
			item.publishedEtr.estimateType = "noestimateTypeKey";
		}
		//ADO 104785 new fields -start
		if (!item.hasOwnProperty('planNotes')) {
			item.planNotes = "noplanNotesKey";
		}
		if (!item.hasOwnProperty('planNextToDispatch')) {
			item.planNextToDispatch = "noplanNextToDispatchKey";
		}
		if (!item.hasOwnProperty('planOutTheDoor')) {
			item.planOutTheDoor = "noplanOutTheDoorKey";
		}
		if (!item.hasOwnProperty('planDate')) {
			item.planDate = "noplanDateKey";
		}
		if (!item.hasOwnProperty('planSequence')) {
			item.planSequence = "noplanSequenceKey";
		}
		//ADO 104785 new fields -end



		let compositeKey = item.notes + '-' + item.outageSubtypeId + "-" + item.publishedEtr.overridden + "-" + item.publishedEtr.value + "-" + item.publishedEtr.estimateDayOfFlag + "-" + item.publishedEtr.estimateDurationAfterMinutes + "-" + item.publishedEtr.estimateDurationBeforeMinutes + "-" + item.publishedEtr.estimateType + "-" + item.changeReason + "-" + item.etrStatus + "-" + item.planNotes + "-" + item.planNextToDispatch + "-" + item.planOutTheDoor + "-" + item.planDate + "-" + item.planSequence;

		if (Object.keys(acc).includes(compositeKey)) return acc;

		acc[compositeKey] = jobList.filter(g => {

			if (!g.hasOwnProperty('notes')) {
				g.notes = 'noNotesKey'
			}

			if (!g.hasOwnProperty('outageSubtypeId')) {
				g.outageSubtypeId = 'noOutageSubtypeIdKey'
			}
			if (!g.hasOwnProperty('changeReason')) {
				g.changeReason = 'noChangeReasonKey'
			}
			if (!g.hasOwnProperty('etrStatus')) {
				g.etrStatus = 'noEtrStatusKey'
			}

			if (!g.hasOwnProperty('publishedEtr')) {

				g.publishedEtr = {};
				g.publishedEtr.overridden = "nooverriddenKey";
				g.publishedEtr.value = "novalueKey";
				g.publishedEtr.estimateDayOfFlag = "noestimateDayOfFlagKey";
				g.publishedEtr.estimateDurationAfterMinutes = "noestimateDurationAfterMinutesKey";
				g.publishedEtr.estimateDurationBeforeMinutes = "noestimateDurationBeforeMinutesKey";
				g.publishedEtr.estimateType = "noestimateTypeKey";

			} else if (!g.publishedEtr.hasOwnProperty('overridden')) {
				g.publishedEtr.overridden = "nooverriddenKey";
			}
			else if (!g.publishedEtr.hasOwnProperty('value')) {
				g.publishedEtr.value = "novalueKey";
			}
			else if (!g.publishedEtr.hasOwnProperty('estimateDayOfFlag')) {
				g.publishedEtr.estimateDayOfFlag = "noestimateDayOfFlagKey";
			}
			else if (!g.publishedEtr.hasOwnProperty('estimateDurationAfterMinutes')) {
				g.publishedEtr.estimateDurationAfterMinutes = "noestimateDurationAfterMinutesKey";
			}
			else if (!g.publishedEtr.hasOwnProperty('estimateDurationBeforeMinutes')) {
				g.publishedEtr.estimateDurationBeforeMinutes = "noestimateDurationBeforeMinutesKey";
			}
			else if (!g.publishedEtr.hasOwnProperty('estimateType')) {
				g.publishedEtr.estimateType = "noestimateTypeKey";
			}
			if (!g.hasOwnProperty('planNotes')) {
				g.planNotes = "noplanNotesKey";
			}
			if (!g.hasOwnProperty('planNextToDispatch')) {
				g.planNextToDispatch = "noplanNextToDispatchKey";
			}
			if (!g.hasOwnProperty('planOutTheDoor')) {
				g.planOutTheDoor = "noplanOutTheDoorKey";
			}
			if (!g.hasOwnProperty('planDate')) {
				g.planDate = "noplanDateKey";
			}
			if (!g.hasOwnProperty('planSequence')) {
				g.planSequence = "noplanSequenceKey";
			}


			return (
				g.notes === item.notes &&
				g.outageSubtypeId === item.outageSubtypeId &&
				g.publishedEtr.overridden === item.publishedEtr.overridden &&
				g.publishedEtr.value === item.publishedEtr.value &&
				g.publishedEtr.estimateDayOfFlag === item.publishedEtr.estimateDayOfFlag &&
				g.publishedEtr.estimateDurationAfterMinutes === item.publishedEtr.estimateDurationAfterMinutes &&
				g.publishedEtr.estimateDurationBeforeMinutes === item.publishedEtr.estimateDurationBeforeMinutes &&
				g.publishedEtr.estimateType === item.publishedEtr.estimateType &&
				g.changeReason === item.changeReason &&
				g.etrStatus === item.etrStatus &&
				g.planNotes === item.planNotes &&
				g.planNextToDispatch === item.planNextToDispatch &&
				g.planOutTheDoor === item.planOutTheDoor &&
				g.planDate === item.planDate &&
				g.planSequence === item.planSequence

			)
		})
		return acc;
	}, {})
	Object.keys(reducedJobList).forEach(objKey => {
		reducedJobList[objKey].map(e => {
			if (e.notes === 'noNotesKey') delete e.notes;
			if (e.outageSubtypeId === 'noOutageSubtypeIdKey') delete e.outageSubtypeId;
			if (e.changeReason === 'noChangeReasonKey') delete e.changeReason;
			if (e.etrStatus === 'noEtrStatusKey') delete e.etrStatus;
			if (e.planNotes === 'noplanNotesKey') delete e.planNotes;
			if (e.planNextToDispatch === 'noplanNextToDispatchKey') delete e.planNextToDispatch;
			if (e.planOutTheDoor === 'noplanOutTheDoorKey') delete e.planOutTheDoor;
			if (e.planDate === 'noplanDateKey') delete e.planDate;
			if (e.planSequence === 'noplanSequenceKey') delete e.planSequence;
			if (e.publishedEtr.overridden === 'nooverriddenKey' && e.publishedEtr.value === 'novalueKey' && e.publishedEtr.estimateDayOfFlag === 'noestimateDayOfFlagKey' && e.publishedEtr.estimateDurationAfterMinutes === 'noestimateDurationAfterMinutesKey' && e.publishedEtr.estimateDurationBeforeMinutes === 'noestimateDurationBeforeMinutesKey' && e.publishedEtr.estimateType === 'noestimateTypeKey') {
				delete e.publishedEtr;
			}
			else {
				if (e.publishedEtr.overridden === 'nooverriddenKey') delete e.publishedEtr.overridden;
				if (e.publishedEtr.value === 'novalueKey') delete e.publishedEtr.value;
				
				if (e.publishedEtr.estimateDayOfFlag === 'noestimateDayOfFlagKey') delete e.publishedEtr.estimateDayOfFlag;
				if (e.publishedEtr.estimateDurationAfterMinutes === 'noestimateDurationAfterMinutesKey') delete e.publishedEtr.estimateDurationAfterMinutes;
				if (e.publishedEtr.estimateDurationBeforeMinutes === 'noestimateDurationBeforeMinutesKey') delete e.publishedEtr.estimateDurationBeforeMinutes;
				if (e.publishedEtr.estimateType === 'noestimateTypeKey') delete e.publishedEtr.estimateType;
				
			}

			return e;
		})
	})
	return reducedJobList;

}
module.exports = groupBulkJob;
