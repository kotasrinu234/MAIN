var urlopen = require('urlopen');
var fs = require('fs');
var groupBulkJob = require('./BulkJobUpdateGroup.js');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('BulkJobUpdate') || session.createContext('BulkJobUpdate');
var bulkType = ctx.getVariable("bulkType");
var ctxILS = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingData_omsResponse) {
	if (readAsJSONError) {
		logger.error("Error in parsing incoming request " + JSON.stringify(readAsJSONError));
		session.reject("Error in parsing incoming request" + JSON.stringify(readAsJSONError));
	}
	else {
		
		//ctx.setVariable('testing', incomingData_omsResponse);
		//var cumulativeOMSResponse= ctx.getVariable("cumulativeOMSResponse");
		var errorCheck = ctx.getVariable("ErrorJobIDs");
		
		var bulkJobUpdateResp = {
			msgId: incomingData_omsResponse.increquest.msgId,
			timesStamp: new Date(),
			bulkType : bulkType,
			jobList: []
		};
		if (!errorCheck) {
			bulkJobUpdateResp = parseOMSResponse(incomingData_omsResponse);
		} else {
			var incomeList = incomingData_omsResponse.increquest.jobList;
			if (incomeList.length > 0) {
				ctxILS.setVariable("omsStatusCode", '0');
				for (let m = 0; m < incomeList.length; m++) {
					var errorJobObject = {
						status: "FAILURE"
					};
					errorJobObject.jobDisplayId = incomeList[m].jobDisplayId;
					errorJobObject.failureReasons = errorCheck.statusCode + ":" + errorCheck.failedReason;
					bulkJobUpdateResp.jobList.push(errorJobObject);
				}
			}
			else {
				ctxILS.setVariable("omsStatusCode", '0');
				var jobDisIdList = ctx.getVariable("jobDisplayIdList");
				logger.error("jobDisIdList " + jobDisIdList);
				for (let j = 0; j < jobDisIdList.length; j++) {
					var errorJobObject = {
						status: "FAILURE"
					};
					errorJobObject.jobDisplayId = jobDisIdList[j];
					errorJobObject.failureReasons = errorCheck.statusCode + ":" + errorCheck.failedReason;
					bulkJobUpdateResp.jobList.push(errorJobObject);
				}

			}
		}
		// Missing JobId array response		 
		var missingJobList = ctx.getVariable("MissingJobIDs");
		if (missingJobList === undefined) {
		}
		else {
			ctxILS.setVariable("omsStatusCode", '0');
			for (let m = 0; m < missingJobList.length; m++) {
				var missedJobObject = {
					status: "FAILURE"
				};
				missedJobObject.jobDisplayId = missingJobList[m];
				missedJobObject.failureReasons = "JOB not found";
				bulkJobUpdateResp.jobList.push(missedJobObject);
			}
		}
		bulkJobUpdateResp.bulkType = bulkType;
		
		session.output.write(bulkJobUpdateResp);
	}
});
function parseOMSResponse(incomingData_omsResponse) {
	var bulkJobRespPayLoad = {
		msgId: incomingData_omsResponse.increquest.msgId,
		timesStamp: new Date(),
		jobList: []
	};
	//var inReqForRespProcess = ctx.getVariable("IncomingPayload");
	var inReqForRespProcess = incomingData_omsResponse.increquest;
	var omsStatusCode = incomingData_omsResponse.omsresponse.find(omsStatus => omsStatus.statusCode == 200);
	//ctxILS.setVariable("omsStatusCode", omsStatusCode.statusCode);
	if (omsStatusCode && omsStatusCode.statusCode == 200) {

		ctxILS.setVariable("omsStatusCode", '0');
		incomingData_omsResponse.omsresponse.forEach(omsdata => {
			if (omsdata.data) {
				omsdata.data.forEach(omsFiledata => {
					var jobListObject = {
						jobId: "",
						jobDisplayId: "",
						status: ""
					};
					if (omsdata.statusCode == 200) {
						if (omsFiledata.status.returnCode == 'SUCCESS') {
							jobListObject.status = omsFiledata.status.returnCode;
							jobListObject.jobId = omsFiledata.modelID;
							jobListObject.jobDisplayId = getJobDisplayId(inReqForRespProcess, omsFiledata.modelID);
						} else if (omsFiledata.status.returnCode == 'FAILURE') {
							jobListObject.status = omsFiledata.status.returnCode;
							jobListObject.jobId = omsFiledata.modelID;
							jobListObject.jobDisplayId = getJobDisplayId(inReqForRespProcess, omsFiledata.modelID);
							jobListObject.failureReasons = omsFiledata.status.failureReasons.perm;
							jobListObject.editViolations = omsFiledata.status.editViolations;
						}
					}
					bulkJobRespPayLoad.jobList.push(jobListObject);
				})
			} else {
				let jobIdChunkList = omsdata.jobIds.split(',');
				jobIdChunkList.forEach(failedJobId => {
					var failedDisplayId = getJobDisplayId(inReqForRespProcess, failedJobId);
					var jobListObject = {
						jobId: "",
						status: "FAILURE"
					};
					if (omsdata.jobDisplayId) {
						jobListObject.jobDisplayId = failedDisplayId;
					}
					jobListObject.jobId = failedJobId;
					jobListObject.failureReasons = omsdata.statusCode + ":" + omsdata.failedReason;
					bulkJobRespPayLoad.jobList.push(jobListObject);
				})
			}
		})
	}
	else {
		ctxILS.setVariable("omsStatusCode", '0');
		if (incomingData_omsResponse.omsresponse != '' && incomingData_omsResponse.omsresponse != undefined && incomingData_omsResponse.omsresponse != null) {
			//bulkJobRespPayLoad.failureReasons = incomingData_omsResponse.omsresponse[0].statusCode+":"+incomingData_omsResponse.omsresponse[0].failedReason;
			bulkJobRespPayLoad.jobList = incomingData_omsResponse.increquest.jobList.map(ele => {
				return {
					"jobDisplayId": ele.jobDisplayId,
					"jobId": ele.jobId,
					"status": "FAILURE",
					"failureReasons": incomingData_omsResponse.omsresponse[0].statusCode + ":" + incomingData_omsResponse.omsresponse[0].failedReason
				}
			});
		}
	}
	return bulkJobRespPayLoad;
}
function getJobDisplayId(incomingreq, modelId) {
	var jobDisplayIdArray = incomingreq.jobList.filter(jobItems => {
		return (jobItems.jobId == modelId)
	});
	var jobDisplayId = jobDisplayIdArray[0].jobDisplayId;
	return jobDisplayId;
}
