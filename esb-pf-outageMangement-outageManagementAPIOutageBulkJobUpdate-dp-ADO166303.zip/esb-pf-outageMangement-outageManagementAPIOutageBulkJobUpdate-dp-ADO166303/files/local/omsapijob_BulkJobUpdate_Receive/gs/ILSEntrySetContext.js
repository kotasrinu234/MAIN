var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var ctx = session.name('ILS')|| session.createContext('ILS');
var messageType = session.parameters.messageType;
ctx.setVariable('messageType',messageType);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
		var correlationID = incomingdata.msgId
		var sourceEventTimestamp = incomingdata.timesStamp
		var jobList = incomingdata.jobList;
var jobDisplayIds = [];
for (var i = 0; i < jobList.length; i++) {
  var job = jobList[i];
//  jobDisplayIds.push(job.jobDisplayId);
  
  if(job.jobId){
	  jobDisplayIds.push(job.jobId);
  }
  else if(job.jobDisplayId){
	   jobDisplayIds.push(job.jobDisplayId);
  }
  else {
  }
  
}
var jobId = jobDisplayIds.join(',');
var sourceUrl = sm.getVar('var://service/URL-in');
ctx.setVariable('sourceUrl',sourceUrl);
ctx.setVariable('correlationID',correlationID);
ctx.setVariable('sourceEventTimestamp',sourceEventTimestamp);
ctx.setVariable('jobId',jobId);
	}
	});
