var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('BulkCSV') || session.createContext('BulkCSV');
session.input.readAsBuffer(function (error, csvData) {
    if (error)
    {
        // handle error
        session.output.write (error.errorMessage);
      } else {
		  
		  ctx.setVariable("csvData",csvData.toString());
      
			  

const jsonData = csvJSONWithRegEx(csvData.toString());
//logger.error("errorJobObject:"+jsonData);
//jsonData = jsonData.pop();
	session.output.write(jsonData);
	  
      }
});

function csvJSONWithRegEx(csvString) {
  var quoteChar = '"';
  var delimiter = ',';
  csvString = csvString.trim();
  var rows = csvString.replace(/\r/g, '').split('\n');
  var headers = rows[0].split(',');

  const regex = new RegExp(`\\s*(${quoteChar})?(.*?)\\1\\s*(?:${delimiter}|$)`, 'gs');

  const match = line =>
    [...line.matchAll(regex)]
      .map(m => m[2])
      .slice(0, -1);

  var lines = csvString.replace(/\r/g, '').split('\n');
  const heads = headers ?? match(lines.shift());
  lines = lines.slice(1);

  return lines.map(line => {
    const values = match(line);
    if (values.length < heads.length) {
      values.push(''); // Add an empty value if the last value is missing
    }
    return values.reduce((acc, cur, i) => {
      // replace blank matches with `null`
      const val = cur.length <= 0 ? '' : Number(cur) || cur;
      const key = heads[i] ?? `{i}`;
      return { ...acc, [key]: val.toString() };
    }, {});
  });
}
