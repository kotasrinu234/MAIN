var urlopen = require('urlopen');
var fs = require('fs');
var groupBulkJob = require('./BulkJobUpdateGroup.js');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});

var ctx = session.name('BulkJobUpdate') || session.createContext('BulkJobUpdate');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var bulkType = ctx.getVariable("bulkType");
var userId = ctx.getVariable("userId");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in parsing incoming request " + JSON.stringify(readAsJSONError));
		session.reject("Error in parsing incoming request" + JSON.stringify(readAsJSONError));
	}
	else {
		if (incomingdata.asyncReplyFlag == 1) {

			var errorCheck = ctx.getVariable("ErrorJobIDs");
			if (!errorCheck) {
				//ctx.setVariable("IncomingPayload", incomingdata);
				let originalObject = incomingdata;
				let clonedIncomingObject = JSON.parse(JSON.stringify(originalObject));
				var groupedObject = groupBulkJob(incomingdata.jobList);
				//ctx.setVariable("groupedObject ", groupedObject );

				var cumulativeOMSResponse = [];
				Object.keys(groupedObject).forEach((listKey, index) => {
					incomingdata.jobList = groupedObject[listKey];
					var groupobj = groupedObject[listKey];
					var jobCount = session.parameters.jobCount;
					if (groupobj.length > jobCount) {
						var subJobList = [];
						var jobCount = session.parameters.jobCount;
						chunkArray(incomingdata.jobList, jobCount, subJobList);

						subJobList.forEach(subList => {
							incomingdata.jobList = subList;
							var omsResponseSub = omsBulkUpdate(incomingdata);
							cumulativeOMSResponse.push(omsResponseSub);
						})
					} else {


						var omsResponse = omsBulkUpdate(incomingdata);
						cumulativeOMSResponse.push(omsResponse);

					}


				});


				Promise.all(cumulativeOMSResponse).then((omsFinalResponse) => {


					const incomingData_omsResponse = {
						increquest: clonedIncomingObject,
						omsresponse: omsFinalResponse
					};

					session.output.write(incomingData_omsResponse);
				}).catch(err => {
					logger.error("groupobj length " + JSON.stringify(err));
				});

			}
			else {

				const incomingData_omsResponse = {
					increquest: incomingdata

				};
				session.output.write(incomingData_omsResponse);
			}
		} else {

			// Async Implementation to be done.

		}

	}


});

function omsBulkUpdate(incomingdata) {

	//post call to get jobId
	return new Promise((resolve, reject) => {


		var omspayload = incomingdata.jobList[0];
		// var omsBulkUpdateData = incomingdata
		var publishEtr;
		if (incomingdata.jobList[0].publishedEtr !== undefined && incomingdata.jobList[0].publishedEtr !== null && incomingdata.jobList[0].publishedEtr !== '') {

			publishEtr = {


				"overridden": omspayload.publishedEtr.overridden,
				"value": omspayload.publishedEtr.value

			}
			if(omspayload.publishedEtr.estimateType !== undefined && omspayload.publishedEtr.estimateType !== null && omspayload.publishedEtr.estimateType !== ''){ var estimateType = omspayload.publishedEtr.estimateType}
			if(omspayload.publishedEtr.estimateDurationBeforeMinutes !== undefined && omspayload.publishedEtr.estimateDurationBeforeMinutes !== null && omspayload.publishedEtr.estimateDurationBeforeMinutes !== ''){var estimateDurationBeforeMinutes = omspayload.publishedEtr.estimateDurationBeforeMinutes}
			if(omspayload.publishedEtr.estimateDurationAfterMinutes !== undefined && omspayload.publishedEtr.estimateDurationAfterMinutes !== null && omspayload.publishedEtr.estimateDurationAfterMinutes !== ''){var estimateDurationAfterMinutes = omspayload.publishedEtr.estimateDurationAfterMinutes}
			if(omspayload.publishedEtr.estimateDayOfFlag !== undefined && omspayload.publishedEtr.estimateDayOfFlag !== null && omspayload.publishedEtr.estimateDayOfFlag !== ''){var estimateDayOfFlag = omspayload.publishedEtr.estimateDayOfFlag}
		}

		var omsBulkUpdateData = {
			"publishedEtr": publishEtr,
			"etrStatus": omspayload.etrStatus,
			"changeReason": omspayload.changeReason,
			"notes": omspayload.notes,
			"outageSubtypeId": omspayload.outageSubtypeId,
			"customFieldValues": {
				"plan_notes": omspayload.planNotes,
				"next_to_dispatch": omspayload.planNextToDispatch,
				"out_the_door": omspayload.planOutTheDoor,
				"plan_date": omspayload.planDate,
				"plan_sequence": omspayload.planSequence,
				"estimate_type": estimateType,
				"estimate_duration_before_minutes": estimateDurationBeforeMinutes,
				"estimate_duration_after_minutes": estimateDurationAfterMinutes,
				"estimate_day_of_flag": estimateDayOfFlag
			}


		}

		var jobIdqueryParamsArr = [];
		incomingdata.jobList.forEach(queryjobIdObj => {
			jobIdqueryParamsArr.push(queryjobIdObj.jobId);
		})
		var jobIdqueryParams = jobIdqueryParamsArr.join(",");


		var omsURL = session.parameters.omsURL;
		var createURL = omsURL + "/oms/external/api/v1/ServiceType/Electric/Job/Bulk?ids=" + jobIdqueryParams;
		var omsToken;

		if (bulkType !== undefined && bulkType == 1) {
			omsToken = session.parameters.omsDailyPlanToken;
		}
		else {
			omsToken = session.parameters.omsToken;
		}



		var create = {
			target: createURL,
			sslClientProfile: 'omsapi_client_profile',
			method: 'PATCH',
			contentType: 'application/json',
			data: omsBulkUpdateData,
			headers: {
				'osiApiToken': omsToken

			}
		};
		var info = " TargetURL :" + create.target + "; Method :" + create.method + "; Data :" + JSON.stringify(create.data) + ". ";
		try {
			urlopen.open(create, function(error, response) {
				if (error) {
					var errorinfo = "url connection error of 'jobIdpatchcreateURL', details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in getting response of 'jobIdpatchcreateURL', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								responseData.statusCode = responseStatusCode;
								resolve(responseData);

							}
						});
					} else if ((responseStatusCode == 401)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapijob_004:Unauthorized error message while reading response from patch call 'jobIdpatchcreateURL', details are : " + info + "; error info :" + JSON.stringify(error)
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								var errorinfo = "omsapijob_004:Unauthorized error message while reading response from patch call 'jobIdpatchcreateURL' , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							}
							var failedResponse = {
								statusCode: responseStatusCode,
								failedReason: responseData.toString(),
								jobIds: jobIdqueryParams,
								jobDisplayId: omspayload.jobDisplayId

							};
							var responseinfo = "Error returned " + ": with statusCode " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							//session.reject(responseinfo);
							resolve(failedResponse);
						});
					} else if ((responseStatusCode == 403)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapijob_005:Forbidden error message while reading response from patch call 'jobIdpatchcreateURL', details are : " + info + "; error info :" + JSON.stringify(error)
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								var errorinfo = "omsapijob_005:Forbidden error message while reading response from patch call 'jobIdpatchcreateURL', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							}
							var failedResponse = {
								statusCode: responseStatusCode,
								failedReason: responseData.toString(),
								jobIds: jobIdqueryParams,
								jobDisplayId: omspayload.jobDisplayId

							};
							var responseinfo = "Error returned " + ": with statusCode " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							//session.reject(responseinfo);
							resolve(failedResponse);
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in getting response of 'jobIdpatchcreateURL', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								var failedResponse = {
									statusCode: responseStatusCode,
									failedReason: responseData.toString(),
									jobIds: jobIdqueryParams,
									jobDisplayId: omspayload.jobDisplayId

								};
								var responseinfo = "Error returned " + ": with statusCode " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								//session.reject(responseinfo);
								resolve(failedResponse);
							}

						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "url connection error of 'jobIdpatchcreateURL', details are : " + info + "; error info :" + error
			ILSctx.setVariable('ExitStatus', '500');
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	})
}

function chunkArray(array, chunk_size, result) {
	while (array.length) {
		result.push(array.splice(0, chunk_size));
	}
	return result;
}
