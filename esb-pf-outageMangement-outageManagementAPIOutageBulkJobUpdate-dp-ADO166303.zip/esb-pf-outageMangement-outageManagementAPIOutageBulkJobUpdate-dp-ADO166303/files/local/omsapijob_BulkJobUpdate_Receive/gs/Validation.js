var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('BulkJobUpdate') || session.createContext('BulkJobUpdate');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in parsing incoming request " + JSON.stringify(readAsJSONError));
        session.reject("Error in parsing incoming request" + JSON.stringify(readAsJSONError));
           }
		   
    if(incomingdata.userId !== undefined && incomingdata.userId !== null && incomingdata.userId !== '')
	{
		ctx.setVariable("userId", incomingdata.userId);
	}
    if(incomingdata.bulkType !== undefined && incomingdata.bulkType == 1)
	{
		ctx.setVariable("bulkType", incomingdata.bulkType);
	}
	else {
	if((incomingdata.msgId=== undefined)||(incomingdata.msgId===null)||(incomingdata.msgId=== '')){
		session.reject("The msgId is a mandatory field ");
	};
	if((incomingdata.userId=== undefined)||(incomingdata.userId===null)||(incomingdata.userId=== '')){
		session.reject("The userId is a mandatory field ");
	};
	if((incomingdata.asyncReplyFlag=== undefined)||(incomingdata.asyncReplyFlag===null)||(incomingdata.asyncReplyFlag=== '')){
		session.reject("The asyncReplyFlag is a mandatory field ");
	};
	if((incomingdata.timesStamp=== undefined)||(incomingdata.timesStamp===null)||(incomingdata.timesStamp=== '')){
		session.reject("The timesStamp is a mandatory field ");
	};
		
	if((incomingdata.jobList[0].publishedEtr === undefined)||(incomingdata.jobList[0].publishedEtr ===null)||(incomingdata.jobList[0].publishedEtr ==='')){
		session.reject("The publishedEtr is a mandatory field ");
	} else {
	if((incomingdata.jobList[0].publishedEtr.overridden=== undefined)||(incomingdata.jobList[0].publishedEtr.overridden===null)||(incomingdata.jobList[0].publishedEtr.overridden==='')){
		session.reject("The publishedEtr.overridden is a mandatory field ");
	};
		if((incomingdata.jobList[0].publishedEtr.value=== undefined)||(incomingdata.jobList[0].publishedEtr.value===null)||(incomingdata.jobList[0].publishedEtr.value==='')){
		session.reject("The publishedEtr.value is a mandatory field ");
	};
	}
	}

	
});
