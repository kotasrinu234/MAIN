# INTERFACE SLOM - StreetLight OutageManagement - OutageJob
** In FileManagement sharedcert path need to update Certificates manually in respective envrionment.
1.sharedcert:///ESOM-WorkOrder-app1.cer, 2.sharedcert:///ESOM-WorkOrder-app2.cer, 3.sharedcert:///ESOM-WorkOrder-app3.cer, 4.sharedcert:///ESOM-WorkOrder-app4.cer

📌  **Post Deployment Steps:**
Need to update passwordAlias for **AAA**-->sots_ReceiveTaggingInfo_AAA_Password_alias,sots_ReceiveWorkOrder_AAA_Password_alias **UserAgent**-> sots_SendWorkOrder_Password_alias, sots_ReceiveTaggingInfo_Password_alias
  
📌 **PACKAGING INSTRUCTIONS**

✅ *Objects need to be selected while taking the export:*

**1. MULTIPROTOCOL GATEWAY:** sots_ReceiveWorkOrder, sots_SendWorkOrder, sots_ReceiveTaggingInfo
**2. AAA:** sots_ReceiveWorkOrder_AAA,sots_ReceiveTaggingInfo_AAA
**3. TLS CLIENT PROFILES:** sots_ReceiveTaggingInfo_AD_Client_Profile, sots_ReceiveWorkOrder_AD_Client_Profile, ESOM_MAXIMO_Client_Profile, MAXIMO_ESOM_Client_Profile
**4. TLS SERVER PROFILES:** sots_ReceiveTaggingInfo_Server_Profile,sots_ReceiveWorkOrder_Server_Profile
**5. HTTPS Handler:** sots_ReceiveWorkOrder_HTTPS_handler, sots_ReceiveTaggingInfo_HTTPS_handler
**6. IBM MQ v9+ QUEUE MANAGERS:** sots_SendWorkOrder_Qmgr, sots_SendWorkOrder_Qmgr_ALT, sots_SendWorkOrder_Retry_Qmgr, sots_SendWorkOrder_Seq_Backend_Qmgr, sots_ReceiveWorkOrder_Seq_Backend_Qmgr, sots_ReceiveTaggingInfo_Seq_Backend_Qmgr
**7. IBM MQ v9+ Handlers:** sots_SendWorkOrder_MQ_FSH, sots_SendWorkOrder_MQ_FSH_ALT, sots_SendWorkOrder_Retry_MQ_FSH

⚠️ **Note::: During deployment, certain stylesheet parameter values spaces were removed in both the baseDeploymentPolicy and export.xml files due to deployment failures. Please review these fields carefully and update them as needed to ensure a smooth and valid deployment process.**
