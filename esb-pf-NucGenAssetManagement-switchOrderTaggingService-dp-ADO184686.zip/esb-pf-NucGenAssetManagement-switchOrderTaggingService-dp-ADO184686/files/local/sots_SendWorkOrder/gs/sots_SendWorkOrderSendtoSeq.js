var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("ESOM") || session.createContext("ESOM");
var checkretry = ctx.getVariable('retry')
if(checkretry !== 'yes'){
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		var dateTime = new Date();
		var seqPayload =
		{
			"messageId": incomingdata.messageId,
			"serviceName": incomingdata.serviceName,
			"eventType": incomingdata.eventType,
			"eventContext": incomingdata.eventContext,
			"EventTimeStamp": incomingdata.EventTimeStamp,
			"sendTimeStamp": dateTime.toISOString(),
			"messageType": incomingdata.messageType,
			"confirmation": "Y"
		}

		var sequenceURL = session.parameters.sequenceURL;
		var sendSeq = {
			target: sequenceURL,
			data: seqPayload
		};
		session.output.write(seqPayload);
		var info = " TargetURL :" + sequenceURL + "; Data :" + JSON.stringify(seqPayload) + ". ";
		try {
			urlopen.open(sendSeq, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					logger.error("SOTS_008: url connection error 'Sequence Request'" + error);
					var errorinfo = "SOTS_008: url connection error 'Sequence Request'" + info + "; error info: " + JSON.stringify(error);
					ILSctx.setVariable("ExitDescription", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					//ctx.setVariable("retry", 'yes');
					session.reject("SOTS_008: url connection error 'Sequence Request'" + error);
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								hm.response.statusCode = 403
								var errorinfo = "SOTS_009: error reading in response from 'Sequence Request'" + info + "; error info: " + readError;
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", "500");
								logger.error("SOTS_009: error reading in response from 'Sequence Request'" + readError);
								session.reject("SOTS_009: error reading in response from 'Sequence Request'" + readError);
							} else {
								ILSctx.setVariable('exitStatus', '0');
								logger.debug("MQResponsecode " + mqrc);
								ctx.setVar("response", responseData);
							}
						});
					} else {
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								logger.error("SOTS_010:error in reading error response 'Sequence Request'" + readError);
								var errorinfo = "SOTS_010:error in reading error response 'Sequence Request'" + info + "; response Info :" + responseData + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", "500");
								session.reject("SOTS_010:error in reading error response 'Sequence Request'" + readError);
							} else {
								logger.error("SOTS_010:error response received from 'Sequence Request'" + readError);
								var errorinfo = "SOTS_010:error response received from 'Sequence Request'" + info + "; response Info :" + responseData + "; error info: " + JSON.stringify(readError);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", "500");
								//ctx.setVariable("retry", 'yes');
								session.reject("SOTS_010:error response received from 'Sequence Request'" + readError);
							}
						});
					}
				}
				//session.output.write(seqPayload);
			});
		} catch (error) {
			logger.error("SOTS_008: url connection error 'Sequence Request'" + error);
			var errorinfo = "SOTS_008: url connection error 'Sequence Request'" + info + "; error info: " + JSON.stringify(error);
			ILSctx.setVariable("ExitDescription", errorinfo);
			ILSctx.setVariable("exitStatus", "500");
			session.reject("SOTS_008: url connection error 'Sequence Request'" + error);
		}
	}
});
}
