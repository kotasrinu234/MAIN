var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("ESOM") || session.createContext("ESOM");
var esomuri = session.parameters.esomuri;
var ExitDescription = session.parameters.ExitDescription;
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		var WONUM = ctx.getVar("WONUM").toUpperCase();
		var DTE_SYSTIE = ctx.getVar("DTE_SYSTIE").toUpperCase();
		var STATUS = ctx.getVar("STATUS").toUpperCase();
		var LOCATION = ctx.getVar("LOCATION").toUpperCase();
		var DTE_JOBTYPE = ctx.getVar("DTE_JOBTYPE").toUpperCase();
		var DTE_STR = ctx.getVar("DTE_CLEARNUM").toUpperCase();
		var Schedstart = ctx.getVar("SCHEDSTART");
		var Schedfinish = ctx.getVar("SCHEDFINISH");
		var DTE_PLANTIMPACT = ctx.getVar("DTE_PLANTIMPACT");
		var DTE_TAGATT = ctx.getVar("DTE_TAGATT");
		var ChangeDate = ctx.getVar("CHANGEDATE");
		var ReportDate = ctx.getVar("REPORTDATE");
		var description = ctx.getVar("DESCRIPTION");
		var PMNUM = ctx.getVar("PMNUM").toUpperCase();
		var description_1 = ctx.getVar("DESCRIPTION_1");
		if (Schedstart.length == 0) {
			var Schedstart = "";
		} else {
			var Schedstart = formatTimestamp(Schedstart);
		}
		if (Schedfinish.length == 0) {
			var Schedfinish = "";
		} else {
			var Schedfinish = formatTimestamp(Schedfinish);
		}
		if (ChangeDate.length == 0) {
			var ChangeDate = "";
		} else {
			var ChangeDate = formatTimestamp(ChangeDate);
		}
		if (ReportDate.length == 0) {
			var ReportDate = "";
		} else {
			var ReportDate = formatTimestamp(ReportDate);
		}

		var payload = {
			"WONUM": WONUM,
			"DESCRIPTION": description,
			"SCHEDSTART": Schedstart,
			"SCHEDFINISH": Schedfinish,
			"DTE_PLANTIMPACT": DTE_PLANTIMPACT,
			"DTE_SYSTIE": DTE_SYSTIE,
			"STATUS": STATUS,
			"LOCATION": LOCATION,
			"DTE_JOBTYPE": DTE_JOBTYPE,
			"PMNUM": PMNUM,
			"DTE_TAGATT": DTE_TAGATT,
			"DTE_STR": DTE_STR,
			"CHANGEDATE": ChangeDate,
			"REPORTDATE": ReportDate,
			"DESCRIPTION_1": description_1
		}

		ctx.setVariable("ResultPayload", payload);
		ILSctx.setVariable("exitDestination", esomuri);
		var Esom = {
			target: esomuri,
			method: 'post',
			sslClientProfile: 'MAXIMO_ESOM_Client_Profile',
			contentType: 'application/json',
			data: payload
		};

		var info = " TargetURL :" + esomuri + "; Method :" + Esom.method + "; Data :" + JSON.stringify(payload) + ". ";
		try {
			urlopen.open(Esom, function(error, response) {
				if (error) {
					logger.error("SOTS_005 sots_SendWorkOrder urlopen connect error with Esom" + JSON.stringify(error));
					var errorinfo = "SOTS_005 sots_SendWorkOrder urlopen connect error with Esom" + info + "; error info: " + JSON.stringify(error);
					ctx.setVariable("retry", 'yes');
					ILSctx.setVariable("ExitDescription", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					//session.reject("urlopen connect error with Esom" + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if ((responseStatusCode == 200) || (responseStatusCode == 201)) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								logger.error("SOTS_006 sots_SendWorkOrder failure in reading message to Esom" + JSON.stringify(error));
								var errorinfo = "SOTS_006 sots_SendWorkOrder failure in reading message to Esom" + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								session.reject("sots_SendWorkOrder failure in reading message to Esom" + JSON.stringify(error));
							} else {
								hm.response.statusCode = '200 Message is received';
								ILSctx.setVariable("exitDestination", esomuri);
								ILSctx.setVariable("ExitDescription", ExitDescription);
								ILSctx.setVariable("exitStatus", "0");
								session.output.write(payload);
							}
						});
					} else if (responseStatusCode == 400) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "Error returned from Esom" +  info + "; error info: " + JSON.stringify(readError);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "Error response received from ESOM: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo)						
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});

				}else {
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								logger.error("SOTS_007 sots_SendWorkOrder Error returned from Esom" + info + "; error info: " + JSON.stringify(readError));
								var errorinfo = "SOTS_007 sots_SendWorkOrder Error returned from Esom" + info + "; error info: " + JSON.stringify(readError);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								session.reject("sots_SendWorkOrder Error returned from Esom" + info + "; error info: " + JSON.stringify(readError));

							} else {
								logger.error("SOTS_007 sots_SendWorkOrder Error returned from Esom" + " ; response info :" + responseData + "with statusCode " + responseStatusCode);
								var errorinfo = "SOTS_007 sots_SendWorkOrder Error returned from Esom" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								session.reject("sots_SendWorkOrder Error returned from Esom" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							}
						});
					}
				}
			});
			session.output.write(payload);
		} catch (error) {
			var errorinfo = "SOTS_005 sots_SendWorkOrder urlopen connect error with Esom', details are : " + info + "; error info :" + error
			ILSctx.setVariable("ExitDescription", errorinfo);
			ILSctx.setVariable("exitStatus", "500")
			logger.error(errorinfo);
			ctx.setVariable("retry", 'yes');
			session.output.write(payload);
			//session.reject(errorinfo);
		}

		function formatTimestamp(timestamp) {
			var date = new Date(timestamp);
			var year = date.getFullYear();
			var month = ('0' + (date.getMonth() + 1)).slice(-2); // Adding 1 to month since getMonth() returns 0-indexed
			var day = ('0' + date.getDate()).slice(-2);
			var hours = ('0' + date.getHours()).slice(-2);
			var minutes = ('0' + date.getMinutes()).slice(-2);
			var seconds = ('0' + date.getSeconds()).slice(-2);
			return year + '/' + month + '/' + day + ' ' + hours + ':' + minutes + ':' + seconds;
		}
	}
});
