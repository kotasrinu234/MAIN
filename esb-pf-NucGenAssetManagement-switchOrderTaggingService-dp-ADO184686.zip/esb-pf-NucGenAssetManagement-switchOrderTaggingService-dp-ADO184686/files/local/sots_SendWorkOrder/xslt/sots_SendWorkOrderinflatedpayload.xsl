<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.ibm.com/maximo" xmlns:date="http://exslt.org/dates-and-times" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
    <xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
    <xsl:output method="xml"/>
    <xsl:template match="@*|node()">
        <xsl:apply-templates select="@*|node()"/>
    </xsl:template>
    <xsl:param name="dpconfig:EntryDescription" select="''"/>
   <!--  <xsl:param name="dpconfig:ExitDescription" select="''"/> -->
    <xsl:param name="dpconfig:messageType" select="''"/>
    <xsl:variable name="EntryDescription" select="$dpconfig:EntryDescription"/>
   <!-- <xsl:variable name="ExitDescription" select="$dpconfig:ExitDescription"/> -->
    <xsl:variable name="messageType" select="$dpconfig:messageType"/>
    <xsl:template match="/">
        <xsl:variable name="IncomingPayload">
            <xsl:copy-of select="."/>
        </xsl:variable>
        <xsl:variable name="inflated" select="dp:inflate(//json:string[@name='payload'])"/>
        <xsl:variable name="parsed" select="dp:parse($inflated)"/>
        <xsl:variable name="WONUM" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM']"/>
        <dp:set-variable name="'var://context/ESOM/WONUM'" value="string($WONUM)"/>
        <dp:set-variable name="'var://context/ILS/workOrderNumber'" value="string($WONUM)"/>
        <xsl:variable name="messageId" select="$parsed/*[local-name()='PublishDTEWOESOM']/@*[local-name()='messageID']"/>
        <dp:set-variable name="'var://context/ILS/correlationID'" value="string($messageId)"/>
        <xsl:variable name="DESCRIPTION" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='DESCRIPTION']"/>
        <dp:set-variable name="'var://context/ESOM/DESCRIPTION'" value="string($DESCRIPTION)"/>
        <xsl:variable name="SCHEDSTART" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='SCHEDSTART']"/>
        <dp:set-variable name="'var://context/ESOM/SCHEDSTART'" value="string($SCHEDSTART)"/>
        <xsl:variable name="SCHEDFINISH" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='SCHEDFINISH']"/>
        <dp:set-variable name="'var://context/ESOM/SCHEDFINISH'" value="string($SCHEDFINISH)"/>
        <xsl:variable name="DTE_PLANTIMPACT" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_PLANTIMPACT']"/>
        <dp:set-variable name="'var://context/ESOM/DTE_PLANTIMPACT'" value="string($DTE_PLANTIMPACT)"/>
        <xsl:variable name="DTE_SYSTIE" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='LOCATIONS']/*[local-name()='DTE_SYSTEM']"/>
        <dp:set-variable name="'var://context/ESOM/DTE_SYSTIE'" value="string($DTE_SYSTIE)"/>
        <xsl:variable name="STATUS" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='STATUS']"/>
        <dp:set-variable name="'var://context/ESOM/STATUS'" value="string($STATUS)"/>
        <xsl:variable name="LOCATION" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='LOCATION']"/>
        <dp:set-variable name="'var://context/ESOM/LOCATION'" value="string($LOCATION)"/>
        <xsl:variable name="DTE_JOBTYPE" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_JOBTYPE']"/>
        <dp:set-variable name="'var://context/ESOM/DTE_JOBTYPE'" value="string($DTE_JOBTYPE)"/>
        <xsl:variable name="PMNUM" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='PMNUM']"/>
        <dp:set-variable name="'var://context/ESOM/PMNUM'" value="string($PMNUM)"/>
        <xsl:variable name="DTE_TAGATT" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_TAGATT']"/>
        <dp:set-variable name="'var://context/ESOM/DTE_TAGATT'" value="string($DTE_TAGATT)"/>
        <xsl:variable name="DTE_CLEARNUM" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_CLEARNUM']"/>
        <dp:set-variable name="'var://context/ESOM/DTE_CLEARNUM'" value="string($DTE_CLEARNUM)"/>
        <xsl:variable name="CHANGEDATE" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='CHANGEDATE']"/>
        <dp:set-variable name="'var://context/ESOM/CHANGEDATE'" value="string($CHANGEDATE)"/>
        <xsl:choose>
            <xsl:when test="string-length($CHANGEDATE)!=0">
                <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="string($CHANGEDATE)"/>
            </xsl:when>
            <xsl:otherwise>
                <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="date:date-time()"/>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:variable name="REPORTDATE" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='REPORTDATE']"/>
        <dp:set-variable name="'var://context/ESOM/REPORTDATE'" value="string($REPORTDATE)"/>
        <xsl:variable name="DESCRIPTION_1" select="$parsed/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='LOCATIONS']/*[local-name()='DESCRIPTION']"/>
        <dp:set-variable name="'var://context/ESOM/DESCRIPTION_1'" value="string($DESCRIPTION_1)"/>
        <dp:set-variable name="'var://context/ILS/EntryDescription'" value="$EntryDescription"/>
     <!--  <dp:set-variable name="'var://context/ILS/ExitDescription'" value="$ExitDescription"/> -->
        <dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)"/>
        <xsl:copy-of select="$parsed"/>
        <dp:set-variable name="'var://context/ESOM/inflated'" value="$inflated"/>
    </xsl:template>
</xsl:stylesheet>
