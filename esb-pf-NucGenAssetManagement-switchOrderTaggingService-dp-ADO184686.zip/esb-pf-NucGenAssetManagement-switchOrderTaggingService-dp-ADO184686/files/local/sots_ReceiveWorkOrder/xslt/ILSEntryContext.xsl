<!-- This xslt is used to invoke job oms api and get the response -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.ibm.com/maximo" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
    <xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
    <xsl:param name="dpconfig:EntryDescription" select="''"/>
   <!--  <xsl:param name="dpconfig:ExitDescription" select="''"/> -->
    <xsl:param name="dpconfig:messageType" select="''"/>
    <xsl:variable name="EntryDescription" select="$dpconfig:EntryDescription"/>
 <!--     <xsl:variable name="ExitDescription" select="$dpconfig:ExitDescription"/> -->
    <xsl:variable name="messageType" select="$dpconfig:messageType"/>
    <xsl:template match="/">
        <xsl:variable name="IncomingPayload">
            <xsl:copy-of select="."/>
        </xsl:variable>
        <xsl:variable name="messageId" select="/*[local-name()='PublishDTEWOESOM']/@*[local-name()='messageID']"/>
        <xsl:variable name="workOrderNumber" select="/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM']"/>
        <xsl:variable name="sourceEventTimestamp" select="/*[local-name()='PublishDTEWOESOM']/*[local-name()='DTEWOESOMSet']/*[local-name()='WORKORDER']/*[local-name()='CHANGEDATE']"/>
    <!--  <xsl:message dp:priority="error">final timestamp+++<xsl:value-of select="$sourceEventTimestamp"/></xsl:message> -->
      
        <xsl:variable name="creationDateTime" select="/*[local-name()='PublishDTEWOESOM']/@creationDateTime"/>
        <dp:set-variable name="'var://context/ILS/messageId'" value="string($messageId)"/>
        <dp:set-variable name="'var://context/ILS/workOrderNumber'" value="string($workOrderNumber)"/>
        <xsl:choose>
            <xsl:when test="string-length($sourceEventTimestamp)!=0">
                <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="string($sourceEventTimestamp)"/>
            </xsl:when>
            <xsl:otherwise>
                <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="date:date-time()"/>
            </xsl:otherwise>
        </xsl:choose>
        <dp:set-variable name="'var://context/ILS/EntryDescription'" value="$EntryDescription"/>
       <!--  <dp:set-variable name="'var://context/ILS/ExitDescription'" value="$ExitDescription"/> -->
        <dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)"/>
        <xsl:variable name="payload">
            <dp:serialize select="." omit-xml-decl="yes"/>
        </xsl:variable>
        <dp:set-variable name="'var://context/sots_ReceiveWorkOrder/encodedPayload'" value="string(dp:deflate($payload))"/>
        <dp:set-variable name="'var://context/sots_ReceiveWorkOrder/creationDateTime'" value="string($creationDateTime)"/>
    </xsl:template>
</xsl:stylesheet>
