var ctx = session.name("followUpOrder") || session.createContext("followUpOrder");
var hm = require('header-metadata');
var ctxILS = session.name("ILS") || session.createContext("ILS");
var sm = require('service-metadata');
var responseStatusCode = ctx.getVariable("responseStatusCode");
var errorCode = sm.getVar('var://service/error-code');
var errorMessage = sm.getVar('var://service/error-message')
var logger = console.options({
	'category': 'all'
});
var WSM = session.name('WSM') || session.createContext('WSM');
var value = WSM.getVar('identity/username');
if (errorMessage === "Rejected by policy.") {
	var errorinfo = `SOTS_001: AAA failure for Fermi Maximo with, Username: ${value}, Errorstring: ${errorCode}, errorMessage: ${errorMessage}`;
	ctxILS.setVariable("ExitDescription", errorinfo);
	ctxILS.setVariable("Exitstatus", '401')
	logger.error(errorinfo);
}
if(errorMessage.includes('Incomplete markup')|| errorCode == '0x00030001'){
	ctxILS.setVariable("ExitDescription", errorMessage);
	ctxILS.setVariable("Exitstatus",'500')
}
else {
	hm.current.statusCode = '500';
}
var obj = {};
obj.errorMessage = sm.getVar('var://service/error-message');
obj.errorCode = sm.getVar('var://service/error-code');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
session.output.write(obj);
