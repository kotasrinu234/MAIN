<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.ibm.com/maximo" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
    <xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
    <xsl:param name="dpconfig:EntryDescription" select="''"/>
   <!-- <xsl:param name="dpconfig:ExitDescription" select="''"/> -->
    <xsl:param name="dpconfig:messageType" select="''"/>
    <xsl:variable name="EntryDescription" select="$dpconfig:EntryDescription"/>
  <!--  <xsl:variable name="ExitDescription" select="$dpconfig:ExitDescription"/> -->
    <xsl:variable name="messageType" select="$dpconfig:messageType"/>
    <xsl:template match="@*|node()">
        <xsl:apply-templates select="@*|node()"/>
    </xsl:template>
    <xsl:template match="/">
		
		<xsl:variable name="lowercase"
			select="'abcdefghijklmnopqrstuvwxyz'" />
		<xsl:variable name="uppercase"
			select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
		
        <xsl:variable name="IncomingPayload">
            <xsl:copy-of select="."/>
        </xsl:variable>
        <xsl:variable name="sourceEventTimestamp" select="string(//json:string[@name='Section_Verif_Date'])"/>
        <dp:set-variable name="'var://context/ILS/correlationID'" value="dp:generate-uuid()"/>
        <dp:set-variable name="'var://context/ILS/messageType'" value="$messageType"/>
        <dp:set-variable name="'var://context/ILS/workOrderNumber'" value="string(//json:string[@name='Work_Order_Number'])"/>
        <xsl:choose>
            <xsl:when test="string-length($sourceEventTimestamp)!=0">
                <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="string($sourceEventTimestamp)"/>
            </xsl:when>
            <xsl:otherwise>
                <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="date:date-time()"/>
            </xsl:otherwise>
        </xsl:choose>
		
		<xsl:variable name="Tagout_Number" select="string(//json:string[@name='Tagout_Number'])"/>
		
		<xsl:variable name="Tagout_Numberuppercase">
		<xsl:value-of
			select="translate($Tagout_Number, $lowercase, $uppercase)" />
	   </xsl:variable>
	   
	   <xsl:variable name="Section_Verif_UserId" select="string(//json:string[@name='Section_Verif_UserId'])"/>
		
		<xsl:variable name="Section_Verif_UserIduppercase">
		<xsl:value-of
			select="translate($Section_Verif_UserId, $lowercase, $uppercase)" />
	   </xsl:variable>
	   
	   <xsl:variable name="Section_Verif_Descr" select="string(//json:string[@name='Section_Verif_Descr'])"/>
		
		<xsl:variable name="Section_Verif_Descruppercase">
		<xsl:value-of
			select="translate($Section_Verif_Descr, $lowercase, $uppercase)" />
	   </xsl:variable>
	   
	   <xsl:variable name="Work_Order_Number" select="string(//json:string[@name='Work_Order_Number'])"/>
		
		<xsl:variable name="Work_Order_Numberuppercase">
		<xsl:value-of
			select="translate($Work_Order_Number, $lowercase, $uppercase)" />
	   </xsl:variable>
		
		<xsl:variable name="Tagout_Type_ID" select="string(//json:string[@name='Tagout_Type_ID'])"/>
		
		<xsl:variable name="Tagout_Type_IDuppercase">
		<xsl:value-of
			select="translate($Tagout_Type_ID, $lowercase, $uppercase)" />
	   </xsl:variable>
		
		<xsl:variable name="Tagout_Section_Number" select="string(//json:string[@name='Tagout_Section_Number'])"/>
		
		<xsl:variable name="Tagout_Section_Numberuppercase">
		<xsl:value-of
			select="translate($Tagout_Section_Number, $lowercase, $uppercase)" />
	   </xsl:variable>
	   
	   <xsl:variable name="Section_Verif_Date" select="string(//json:string[@name='Section_Verif_Date'])"/>
	   <xsl:variable name="Transfer_Action" select="'AddChange'"/>
	   
	   <xsl:variable name="Transfer_Action_ORG" select="string(//json:string[@name='Transfer_Action'])"/>
	   <xsl:choose>
				<xsl:when
					test="$Transfer_Action_ORG ='DELETE'">
					<xsl:variable name="XMLPayload">
		<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:max="http://www.ibm.com/maximo">
          <soapenv:Header/>
          <soapenv:Body>
         <max:SyncDTEWOESOM
	        xmlns:max="http://www.ibm.com/maximo">
	              <max:DTEWOESOMSet>
		             <max:WORKORDER>
					    <xsl:attribute name="action">
							<xsl:value-of select="$Transfer_Action" />
						</xsl:attribute>
						<max:DTE_CLEARNUM><xsl:value-of select="''"/></max:DTE_CLEARNUM>
						<max:WONUM><xsl:value-of select="$Work_Order_Numberuppercase"/></max:WONUM>
						<max:DTE_CLEARSIGNER><xsl:value-of select="''"/></max:DTE_CLEARSIGNER>
						<max:DTE_CLEARSTATUS><xsl:value-of select="''"/></max:DTE_CLEARSTATUS>
						<max:DTE_CLEARTYPE><xsl:value-of select="''"/></max:DTE_CLEARTYPE>
						<max:DTE_CLEARSECTION><xsl:value-of select="''"/></max:DTE_CLEARSECTION>
						<max:DTE_CLEARDATE><xsl:value-of select="''"/></max:DTE_CLEARDATE>
					</max:WORKORDER>
				</max:DTEWOESOMSet>
		</max:SyncDTEWOESOM>
		 </soapenv:Body>

</soapenv:Envelope>
		</xsl:variable>
		<xsl:copy-of select="$XMLPayload"/>
				</xsl:when>
				<xsl:otherwise>
				<xsl:variable name="XMLPayload">
		<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:max="http://www.ibm.com/maximo">
          <soapenv:Header/>
          <soapenv:Body>
         <max:SyncDTEWOESOM
	        xmlns:max="http://www.ibm.com/maximo">
	              <max:DTEWOESOMSet>
		             <max:WORKORDER>
					    <xsl:attribute name="action">
							<xsl:value-of select="$Transfer_Action" />
						</xsl:attribute>
						<max:DTE_CLEARNUM><xsl:value-of select="$Tagout_Numberuppercase"/></max:DTE_CLEARNUM>
						<max:DTE_CLEARSIGNER><xsl:value-of select="$Section_Verif_UserIduppercase"/></max:DTE_CLEARSIGNER>
						<max:DTE_CLEARSTATUS><xsl:value-of select="$Section_Verif_Descruppercase"/></max:DTE_CLEARSTATUS>
						<max:WONUM><xsl:value-of select="$Work_Order_Numberuppercase"/></max:WONUM>
						<max:DTE_CLEARTYPE><xsl:value-of select="$Tagout_Type_IDuppercase"/></max:DTE_CLEARTYPE>
						<max:DTE_CLEARSECTION><xsl:value-of select="$Tagout_Section_Numberuppercase"/></max:DTE_CLEARSECTION>
						<max:DTE_CLEARDATE><xsl:value-of select="$Section_Verif_Date"/></max:DTE_CLEARDATE>
					</max:WORKORDER>
				</max:DTEWOESOMSet>
		</max:SyncDTEWOESOM>
		 </soapenv:Body>

</soapenv:Envelope>
		</xsl:variable>
		<xsl:copy-of select="$XMLPayload"/>
				</xsl:otherwise>
		</xsl:choose>
        <dp:set-variable name="'var://context/ILS/EntryDescription'" value="$EntryDescription"/>
      <!--  <dp:set-variable name="'var://context/ILS/ExitDescription'" value="$ExitDescription"/> -->
        <!--<xsl:variable name="payload">
            <dp:serialize select="." omit-xml-decl="yes"/>
        </xsl:variable>
        <dp:set-variable name="'var://context/sots_SendTaggingInfo/encodedPayload'" value="string(dp:deflate($payload))"/> -->
    </xsl:template>
</xsl:stylesheet>
