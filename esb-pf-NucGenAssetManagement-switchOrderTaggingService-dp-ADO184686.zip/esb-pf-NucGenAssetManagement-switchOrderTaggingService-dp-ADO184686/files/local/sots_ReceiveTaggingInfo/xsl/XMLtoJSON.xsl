<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:template match="/">
	<xsl:variable name="jsonxPayload">
	<json:object
			xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx">
			<xsl:choose>
				<xsl:when
					test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']">
					<json:string name="faultcode">
						<xsl:value-of select="//*[local-name()='faultcode']" />
					</json:string>
					<json:string name="faultstring">
						<xsl:value-of select="//*[local-name()='faultstring']" />
					</json:string>
				</xsl:when>
				<xsl:otherwise />
			</xsl:choose>
		</json:object>
	</xsl:variable>
	<xsl:copy-of select="$jsonxPayload"></xsl:copy-of>
	</xsl:template>
</xsl:stylesheet>
