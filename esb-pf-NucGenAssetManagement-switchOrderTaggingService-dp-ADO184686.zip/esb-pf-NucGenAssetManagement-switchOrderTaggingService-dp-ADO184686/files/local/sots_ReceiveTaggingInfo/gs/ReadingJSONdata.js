var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("Maximo") || session.createContext("Maximo");
session.INPUT.readAsBuffer(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		ctx.setVariable("Payload", incomingdata);
                session.output.write(incomingdata);
	}
});
