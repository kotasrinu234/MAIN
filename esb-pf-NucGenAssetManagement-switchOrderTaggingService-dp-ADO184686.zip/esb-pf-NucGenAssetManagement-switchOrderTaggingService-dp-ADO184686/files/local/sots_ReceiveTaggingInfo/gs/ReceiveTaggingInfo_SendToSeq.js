var ctx = session.name("sots_SendTaggingInfo") || session.createContext("sots_SendTaggingInfo");
var ctxILS = session.name("ILS") || session.createContext("ILS");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');

var logger = console.options({ 'category': 'all' });
var dateTime = new Date();
var currentTime = dateTime.toISOString();
var EventTimeStamp = ctx.getVariable("creationDateTime");
var encodedPayload = ctx.getVariable("encodedPayload");
var ExitDescription	= session.parameters.ExitDescription;
var seqPayload =
{
	"messageId": ctxILS.getVariable("correlationID"),
	"serviceName": "SwitchOrderTaggingService",
	"expiry": session.parameters.expiry,
	"eventType": "eSomTaggingInfoEvent",
	"eventContext": ctxILS.getVariable("workOrderNumber"),
	"payload": encodedPayload,
	"EventTimeStamp": currentTime,
	"sendTimeStamp": currentTime,
	"waitTime": session.parameters.waitTime,
	"messageType": "eSomTaggingInfoEvent",
	"destQueueName": 'SOTS.TAGGING.RECEIVE.SEQ'
}
var sequenceURL = session.parameters.sequenceURL;
var sendSeq = {
	target: sequenceURL,
	data: seqPayload
};
var info = " TargetURL :" + sendSeq.target + "; Data :" + JSON.stringify(sendSeq.data) + ". ";
try {
	urlopen.open(sendSeq, function(error, response) {
		var hm = require('header-metadata');
		if (error) {
			var errorinfo = "SOTS_012 : url connection error 'Sequence Request', details are : " + info + "; error info :" + error
			ctxILS.setVariable("ExitDescription", errorinfo);
			ctxILS.setVariable("Exitstatus", "500")
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var mqrc = response.statusCode;
			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						hm.response.statusCode = 403
						var errorinfo = "SOTS_013: error reading in response from 'Sequence Request', details are : " + info + "; error info :" + readError
						ctxILS.setVariable("ExitDescription", errorinfo);
						ctxILS.setVariable("Exitstatus", mqrc)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						ctxILS.setVariable("Exitstatus", "0")
						ctxILS.setVariable("ExitDestination", sequenceURL)
						ctxILS.setVariable("ExitDescription", ExitDescription);
						logger.debug("MQResponsecode " + mqrc);
						session.output.write(seqPayload);
						ctx.setVar("response", responseData);
					}
				});
			} else {
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						var errorinfo = "SOTS_014:error in reading error response 'Sequence Request', details are : " + info + "; error info :" + readError
						ctxILS.setVariable("ExitDescription", errorinfo);
						ctxILS.setVariable("Exitstatus", mqrc)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "SOTS_014:error in reading error response 'Sequence Request', details are : " + info + ";response Info:" + responseData + "; error info :" + readError
						ctxILS.setVariable("ExitDescription", errorinfo);
						ctxILS.setVariable("Exitstatus", mqrc)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		}
		session.output.write(seqPayload);
	});
} catch (error) {
	var errorinfo = "SOTS_012 : url connection error 'Sequence Request', details are : " + info + "; error info :" + error
	ctxILS.setVariable("ExitDescription", errorinfo);
	ctxILS.setVariable("Exitstatus", "500")
	logger.error(errorinfo);
	session.reject(errorinfo);
}
