var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("Maximo") || session.createContext("Maximo");
var Maximouri = session.parameters.Maximouri;
var ExitDescription = session.parameters.ExitDescription;
var ResultPayload;
session.input.readAsXML(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		ctx.setVariable("Payload", incomingdata);
		ILSctx.setVariable("exitDestination", Maximouri);
		var Maximo = {
			target: Maximouri,
			sslClientProfile: 'ESOM_MAXIMO_Client_Profile',
			method: 'post',
			contentType: 'application/json',
			headers: {
			},
			data: incomingdata
		};
		ResultPayload = XML.stringify(incomingdata);
		session.output.write(ResultPayload);

		var info = " TargetURL :" + Maximo.target + "; Method :" + Maximo.method + "; Data :" + XML.stringify(Maximo.data) + ". ";
		try {
			urlopen.open(Maximo, function(error, response) {
				if (error) {
					logger.error("SOTS_012 urlopen connect error with Maximo" + info + "; error info: " + JSON.stringify(error));
					var errorinfo = "SOTS_012 urlopen connect error with Maximo" + info + "; error info: " + JSON.stringify(error);
					ILSctx.setVariable("ExitDescription", errorinfo);
					ILSctx.setVariable("Exitstatus", "500");
					//ctx.setVariable("retry", 'yes');
					session.reject("urlopen connect error with Maximo" + info + "; error info: " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsXML(function(error, responseData) {
							if (error) {
								logger.error("SOTS_013 failure in reading message to Maximo" + info + "; error info: " + JSON.stringify(error));
								var errorinfo = "SOTS_013 failure in reading message to Maximo" + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("Exitstatus", responseStatusCode);
								session.reject("failure in reading message to Maximo" + info + "; error info: " + JSON.stringify(error));
							} else {
								hm.response.statusCode = '200 Message is received';
								ILSctx.setVariable("ExitDestination", Maximouri);
								ILSctx.setVariable("Exitstatus", "0");
								ILSctx.setVariable("ExitDescription", ExitDescription);
								ctx.setVariable("responseData", responseData);
								ResultPayload = XML.stringify(incomingdata);
								session.output.write(responseData);

							}

						});
					} else if (responseStatusCode == 400) {
						response.readAsXML(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "Error returned from Maximo" + info + "; error info: " + JSON.stringify(readError);
								ILSctx.setVariable('Exitstatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "Error response received from Maximo: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('Exitstatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo)
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});

					}
					else {
						response.readAsXML(function(readError, responseData) {
							if (readError) {
								logger.error("SOTS_014 sots_ReceiveTaggingInfo Error returned from Maximo" + + info + "; error info: " + JSON.stringify(readError));
								var errorinfo = "SOTS_014 sots_ReceiveTaggingInfo Error returned from Maximo" + info + "; error info: " + JSON.stringify(readError);
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("Exitstatus", responseStatusCode);
								//ctx.setVariable("retry", 'yes');
								session.reject("Error returned from Maximo" + info + "; error info: " + JSON.stringify(readError));

							} else {
								logger.error("SOTS_014 Error returned from Maximo" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
								var errorinfo = "SOTS_014 Error returned from Maximo" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("Exitstatus", responseStatusCode);
								//ctx.setVariable("responseData", responseData);
								//ctx.setVariable("retry", 'yes');
								//session.output.write(responseData);
								session.reject("Error returned from Maximo" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							}
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "SOTS_012 urlopen connect error with Maximo', details are : " + info + "; error info :" + error
			ILSctx.setVariable("ExitDescription", errorinfo);
			ILSctx.setVariable("Exitstatus", "500")
			//ctx.setVariable("retry", 'yes');
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	}
	session.output.write(ResultPayload);
});
