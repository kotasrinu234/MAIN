var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var ctx1 = session.name('req') || session.createContext('req');
var entryDescription = session.parameters.reportErrorEntryDescription;
var exitDescription = session.parameters.reportErrorExitDescription;
var messageType = session.parameters.reportErrorMessageType;
var exitDestination = session.parameters.FacadeUrl;
if (exitDestination !== undefined || exitDestination !== null || exitDestination !== '') {
	ctx.setVariable("exitDestination", exitDestination);
}
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx1.setVariable('exitDescription', exitDescription);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.CallBackData.messageID) {
			if (incomingdata.CallBackData.messageID !== undefined || incomingdata.CallBackData.messageID !== null || incomingdata.CallBackData.messageID !== '') {
				ctx.setVariable("correlationID", incomingdata.CallBackData.messageID)
			}
		}
		if (incomingdata.ErrorMessage) {
			if (incomingdata.ErrorMessage !== undefined || incomingdata.ErrorMessage !== null || incomingdata.ErrorMessage !== '') {
				ctx.setVariable("message", incomingdata.ErrorMessage)
			}
		}
		if (incomingdata.CreationTime) {
			if (incomingdata.CreationTime !== undefined || incomingdata.CreationTime !== null || incomingdata.CreationTime !== '') {
				ctx.setVariable("sourceEventTimestamp", incomingdata.CreationTime)
			}
		}
		else{
			ctx.setVariable("sourceEventTimestamp", new Date().toISOString());
		}
	}
});
