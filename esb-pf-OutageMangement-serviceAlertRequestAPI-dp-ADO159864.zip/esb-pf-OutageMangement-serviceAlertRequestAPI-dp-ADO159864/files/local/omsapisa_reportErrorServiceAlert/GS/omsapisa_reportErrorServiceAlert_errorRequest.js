var urlopen = require('urlopen');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("req") || session.createContext("req");
var OMSUrl = session.parameters.OMSUrl;
session.INPUT.readAsJSON(function(error, incomingdata) {

	if (error) {
		logger.error("Error in reading Incoming Data" + JSON.stringify(error));
		session.reject(error);
	} else {
		//var Auth = "Basic "+session.parameters.FSEToken;
		var data = incomingdata;
		data.CallBackData.CallID = ctx.getVariable("displayID");
		data.CallBackData.Number = '0';
		var FSECall = {
			target: session.parameters.FacadeUrl,
			sslClientProfile: 'omsapisa_reportErrorServiceAlert_TLS_ClientProfile',
			method: 'post',
			contentType: 'application/json',
			data: incomingdata
		};
		session.output.write(incomingdata)
		var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";
		try {
			urlopen.open(FSECall, function(error, response) {
				if (error) {
					// an error occurred during request sending or response header parsing
					var errorinfo = "req_004:urlopen connect error while doing Facade Call , details are : " + info + "; error info :" + error;
					ctx.setVariable("exitDescription", errorinfo);
					ctx.setVariable("exitStatus", '500');
					logger.error("req_004:urlopen connect error while doing Facade Call" + JSON.stringify(error));
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = "req_004:urlopen connect error while doing Facade Call" + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
					//session.reject("urlopen connect error while doing facade Call");
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure in reading message from FSECall , details are : " + info + "; error info :" + error;
								ctx.setVariable("errorDescription", errorinfo);
								logger.error(" failure in reading message from FSECall" + JSON.stringify(error));
								session.reject("failure in reading message from FSECall" + JSON.stringify(error));
							}
							else {
								logger.debug("Business error sent to FSE");
								ctx.setVariable("exitStatus", '0');
							}
						})
					}
					else {

						response.readAsBuffer(function(error, responseData) {

							if (error) {
								var errorinfo = "failure in reading response from facade call , details are : " + info + "; error info :" + error;
								ctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading response from facade call " + JSON.stringify(error));
								session.reject("failure in reading response from facade call ");
							} else {
								var errorinfo = "req_005:Error returned from facade call " + ": with statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
								ctx.setVariable("exitDescription", errorinfo);
								ctx.setVariable("exitStatus", responseStatusCode);
								hm.current.statusCode = responseStatusCode;
								logger.error("req_005:Error returned from facade call " + ": with statusCode " + responseStatusCode + " " + responseData);
								ctx.setVariable("retry", 'yes');
								var ErrorTxt = "req_005:Error returned from facade call " + JSON.stringify(error);
								ctx.setVariable("ErrorTxt", ErrorTxt);
								//session.reject("Error returned from NotesMessage " + ": with statusCode " + responseStatusCode + " " + responseData);
							}
						})
					}
				}
			})
		}
		catch (error) {
			var errorinfo = "req_004:urlopen connect error while doing Facade Call , details are : " + info + "; error info :" + error;
			ctx.setVariable("exitDescription", errorinfo);
			ctx.setVariable("exitStatus", '500');
			logger.error("req_004:urlopen connect error while doing Facade Call" + JSON.stringify(error));
			ctx.setVariable("retry", 'yes');
			var ErrorTxt = "req_004:urlopen connect error while doing Facade Call" + JSON.stringify(error);
			ctx.setVariable("ErrorTxt", ErrorTxt);
		}

	}
})
