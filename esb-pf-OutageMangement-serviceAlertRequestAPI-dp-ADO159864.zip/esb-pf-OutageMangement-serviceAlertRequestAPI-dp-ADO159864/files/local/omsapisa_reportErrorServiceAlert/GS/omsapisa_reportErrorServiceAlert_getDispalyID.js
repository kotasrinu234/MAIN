var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("req") || session.createContext("req");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading Incoming Data" + JSON.stringify(error));
		session.reject(readAsJSONError);
	} else {
		var ExternalRefID = incomingdata.CallBackData.ExternalRefID;
		var ExternalRefIDSplit = ExternalRefID.split(":");
		var cAID = ExternalRefIDSplit[1];
		var OMSUrl = session.parameters.OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + cAID + '?includeFields=displayID';
		var Token = session.parameters.OMSToken;
		var GetCAInternalID = {
			target: OMSUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': Token
			}
		};
		var info = " TargetURL :" + GetCAInternalID.target + "; Method :" + GetCAInternalID.method + ". ";
		try {
			urlopen.open(GetCAInternalID, function(error, response) {
				if (error) {
					var errorinfo = "error in oms urlopen GET call , details are : " + info + "; error info :" + error;
					ctx.setVariable("errorDescription", errorinfo);
					logger.error("error in oms urlopen GET call" + JSON.stringify(error));
					session.reject("error in oms urlopen GET call, " + "Errorcode:" + rescode);
				}
				else {
					var rescode = response.statusCode;
					if (rescode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								logger.error("failure in getting response message from omsapi Get calls by job " + JSON.stringify(error));
								var errorinfo = "failure in getting response message from omsapi Get calls by job" + error;
								ctx.setVariable('exitDescription', errorinfo);
							} else {
								hm.response.statusCode = '200 OK';
								logger.debug("response received from OMS Get calls by job:" + JSON.stringify(responseData));
								ctx.setVariable("omsResponse", responseData);
								ctx.setVariable("displayID", responseData.displayID);
							}
						})
					}
					else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "req_006:failure in reading response from fse create call , details are : " + info + "; error info :" + error;
								ctx.setVariable("errorDescription", errorinfo);
								logger.error("req_006:failure in reading response from fse create call " + JSON.stringify(error));
								session.reject("req_006:failure in reading response from fse call ");
							} else {
								var responseStatusCode = response.statusCode;
								var errorinfo = "req_007:unable to get display ID from OMS API" + ": with statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
								ctx.setVariable("errorDescription", errorinfo);
								logger.error("req_007:unable to get display ID from OMS API" + ": with statusCode " + responseStatusCode + " " + responseData);
								session.reject("req_007:unable to get displayID from OMS API" + ": with statusCode " + responseStatusCode + " " + responseData);
							}
						})
					}
				}
			})
		}
		catch (error) {
			var errorinfo = "error in oms urlopen GET call , details are : " + info + "; error info :" + error;
			ctx.setVariable("errorDescription", errorinfo);
			logger.error("error in oms urlopen GET call" + JSON.stringify(error));
			session.reject("error in oms urlopen GET call, " + "Errorcode:" + rescode);
		}
	}
})
