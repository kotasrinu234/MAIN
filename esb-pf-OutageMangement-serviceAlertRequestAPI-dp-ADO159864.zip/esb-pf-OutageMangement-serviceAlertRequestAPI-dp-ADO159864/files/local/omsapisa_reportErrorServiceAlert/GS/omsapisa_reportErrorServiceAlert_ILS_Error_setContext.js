var sm = require('service-metadata');
session.input.readAsBuffer(function(error, buffer) {
	if (error) {
		session.reject("Unexpected error in readAsJSON(): " + error);
		return;
	} else {
		var ctx1 = session.name('ILS') || session.createContext('ILS');
		var ctx = session.name('req') || session.createContext('req');
		ctx.setVar("inputData", buffer.toString());
		var errorDescription = ctx.getVariable('errorDescription');
		if (errorDescription) {
			ctx1.setVariable('errormessage', errorDescription );
		} else {
			var message = sm.getVar('var://service/error-message')
			ctx1.setVariable('errormessage', message);
		}
	}

});
