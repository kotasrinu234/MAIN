var urlopen = require('urlopen');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("req") || session.createContext("req");

session.INPUT.readAsJSON(function(error, incomingData) {
	if (error) {
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {
		var StandaloneMQurl = session.parameters.MQUrl;
		var pushingToQueue = {
			target: StandaloneMQurl,
			data: incomingData
		};
		var info = " TargetURL :" + StandaloneMQurl + "; Method :" + 'POST' + "; Data :" + JSON.stringify( pushingToQueue.data) + ". ";
		try {

			urlopen.open(pushingToQueue, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var ctx = session.name("receivecall") || session.createContext("receivecall");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error("req_001:Error while keeping receivecall message to queue is " + error);
					var errorinfo = "error while keeping message Service Alert omsapisa_receiveServiceAlert to queue, details are : " + info + "; error info :" + "Error returned mq call " + error;
					ctx.setVariable("errormessage", errorinfo);
					session.reject(" error while keeping receivecall message to queue is " + error);
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								hm.response.statusCode = 500
								var errorinfo = "error while keeping message Service Alert omsapisa_receiveServiceAlert to queue, details are : " + info + "; error info :" + "Error returned mq call " + error;
								ctx.setVariable("errormessage", errorinfo);
								session.reject("error while keeping message receivecall to queue is " + error);
							} else {
								logger.debug("MQResponsecode " + mqrc);
							}
						});
					} else {
						var ctx = session.name("foa") || session.createContext("foa");
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						logger.error(" response code receivecall urlopen.open error [MQRC=" + mqrc + "]");
						var errorinfo = "error while keeping message Service Alert omsapisa_receiveServiceAlert to queue, details are : " + info + "; error info :" + "Error returned mq call " + error;
						ctx.setVariable("errormessage", errorinfo);
						session.reject(" response code receivecall is urlopen.open error [MQRC=" + mqrc + "]");

					}
				}
			});
		} catch (err) {
			var errorinfo = "error while keeping message Service Alert omsapisa_receiveServiceAlert to queue , details are : " + info + "; error info :" + "Error returned mq call " + err;
			ctx.setVariable("errormessage", errorinfo);
			session.reject('** Mqurlopen.open error [MQRC=' + err + ']');
		}

	}
});
