var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var urlIn = sm.getVar('var://service/URL-in');
var ctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {

		var correlationID = incomingData.CallBackData.messageID;
		if (correlationID == undefined || correlationID === null || correlationID === '') {
			ctx.setVariable('correlationID', '');
		} else {
			ctx.setVariable('correlationID', correlationID);
		}
		
		var messageType = session.parameters.messageType;
		ctx.setVariable('messageType', messageType);
		
		var crewDisplayID = incomingData.ServiceAlert.CrewID;
		if (crewDisplayID === undefined || crewDisplayID === null || crewDisplayID === '') {
			ctx.setVariable('crewDisplayID', '');
		} else {
			ctx.setVariable('crewDisplayID', crewDisplayID);
		}
		
		var title = incomingData.ServiceAlert.Title;
		if (title === undefined || title === null || title === '') {
			ctx.setVariable('title', '');
		} else {
			ctx.setVariable('title', title);
		}
		
		if (incomingData.ServiceAlert.CreationTime) {
			ctx.setVariable("sourceEventTimestamp", incomingData.ServiceAlert.CreationTime)

		} else {
			var dateTime = new Date();
			var currentTime = dateTime.toISOString();
			ctx.setVariable("sourceEventTimestamp", currentTime);
		}
		
		var description = session.parameters.EntryDescription;
		ctx.setVariable("EntryDescription", description);
		ctx.setVariable("sourceUrl", urlIn);
		
		ctx.setVariable("exitDestination", session.parameters.MQUrl)
		var ExitDescription = session.parameters.ExitDescription;
		ctx.setVariable("ExitDescription", session.parameters.ExitDescription);



	}
})
