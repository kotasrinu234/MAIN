var logger = console.options({
	'category': 'all'
});

var ctx = session.name("req") || session.createContext("req");

session.input.readAsJSON(function(error, incomingData) {


	if (error) {
		logger.error("Error in reading incoming data");
		session.reject(error);
	} else {
                
                ctx.setVariable("incomingData", incomingData);

		var CrewID = incomingData.ServiceAlert.CrewID;

		if (CrewID === null || CrewID === '' || CrewID === undefined) {
			var ctx1 = session.name("receivecall") || session.createContext("receivecall");
			var errorinfo = "CrewID is not present in input  payload";
			ctx1.setVariable("errormessage", errorinfo);
			logger.error('CrewID is not present in input  payload');
			ctx.setVariable("CrewID", CrewID)
			session.reject('CrewID is not present in input  payload');

		}

	}
})
