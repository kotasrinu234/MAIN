var sm = require('service-metadata');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsBuffer(function(error, buffer) {
	if (error) {
		session.reject("Unexpected error in readAsJSON(): " + error);
		return;
	}else{
	var ctx1 = session.name('ILS') || session.createContext('ILS');
	var ctx = session.name('myContext') || session.createContext('myContext');
	ctx.setVar("inputData", buffer.toString());
	var errorDescription = ctx1.getVariable('errormessage');
		if(errorDescription){
			ctx1.setVariable('errormessage', errorDescription);
		}else{
			var message = sm.getVar('var://context/errormessage')
			ctx1.setVariable('errormessage', message);
		}
}
   	
});
