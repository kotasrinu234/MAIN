var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.sendServiceEntryDescription;
var exitDescription = session.parameters.sendServiceSuccessExitDescription;
var messageType = session.parameters.sendServicemessageType;
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.CallBackData.messageID) {
			if (incomingdata.CallBackData.messageID !== undefined || incomingdata.CallBackData.messageID !== null || incomingdata.CallBackData.messageID !== '') {
				ctx.setVariable("correlationID", incomingdata.CallBackData.messageID)
			}
		}
		if (incomingdata.ServiceAlert.CrewID) {
			if (incomingdata.ServiceAlert.CrewID !== undefined || incomingdata.ServiceAlert.CrewID !== null || incomingdata.ServiceAlert.CrewID !== '') {
				ctx.setVariable("crewDisplayID", incomingdata.ServiceAlert.CrewID)
			}
		}
		if (incomingdata.ServiceAlert.Title) {
			if (incomingdata.ServiceAlert.Title !== undefined || incomingdata.ServiceAlert.Title !== null || incomingdata.ServiceAlert.Title !== '') {
				ctx.setVariable("title", incomingdata.ServiceAlert.Title)
			}
		}
		if(incomingdata.ServiceAlert.CreationTime){
			if (incomingdata.ServiceAlert.CreationTime !== undefined || incomingdata.ServiceAlert.CreationTime !== null || incomingdata.ServiceAlert.CreationTime !== ''){
				ctx.setVariable("sourceEventTimestamp", incomingdata.ServiceAlert.CreationTime);
			}
		}
		else{
			ctx.setVariable("sourceEventTimestamp", new Date().toISOString());
		}
		
	}
});
