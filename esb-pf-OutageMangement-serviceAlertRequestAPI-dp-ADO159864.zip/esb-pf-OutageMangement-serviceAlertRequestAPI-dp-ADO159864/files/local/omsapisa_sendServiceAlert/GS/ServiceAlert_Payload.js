var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("req") || session.createContext("req");
var OMSUrl = session.parameters.OMSUrl;
var Token = session.parameters.OMSToken;
var sendServiceFailExitDescription = session.parameters.sendServiceFailExitDescription;
var sendServiceSuccessExitDescription = session.parameters.sendServiceSuccessExitDescription;
session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data ; error info :" + error;
		ctx.setVariable("errorDescription", errorinfo);
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var crewId = incomingData.ServiceAlert.CrewID;
		var Client = incomingData.CallBackData.Client;
		var ServiceName = incomingData.CallBackData.ServiceName;
		var ExternalRefID = incomingData.CallBackData.ExternalRefID;

		if ((OMSUrl == undefined) || (OMSUrl == ' ') || (OMSUrl == null)) {
			var errorinfo = "Error in connection with OMSUrl ; error info :" + error;
			ctx.setVariable("errorDescription", errorinfo);
			logger.error("Error in connection with OMSUrl " + JSON.stringify(readAsJSONError));
			session.reject("Error in connection with OMSUrl " + JSON.stringify(readAsJSONError));
		} else {
			var GetUrgentRequestUrl = OMSUrl + '/api/v1/ServiceType/Electric/Crew/' + crewId + '?includeFields=urgentRequest';
			var GetResponseData = {
				target: GetUrgentRequestUrl,
				sslClientProfile: 'omsapi_client_profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': Token
				}
			};
			var info = " TargetURL :" + GetResponseData.target + "; Method :" + GetResponseData.method + ". ";
			try {
				urlopen.open(GetResponseData, function(error, response) {
					if (error) {
						var errorinfo = "req_002:urlopen connect error while opening the url , details are : " + info + "; error info :" + error;
						ctx.setVariable("exitDescription", errorinfo);
						ctx.setVariable("exitStatus", '500');
						logger.error("urlopen connect error while opening the url " + JSON.stringify(error));
						ctx.setVariable("retry", 'yes');
						var ErrorTxt = "req_002:urlopen connect error while opening the url " + JSON.stringify(error);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						ctx.setVar("exitDescription", sendServiceFailExitDescription);
						//session.reject("urlopen connect error while opening the url " + JSON.stringify(error));
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting response from  the GetResponseData , details are : " + info + "; error info :" + error;
									ctx.setVariable("errorDescription", errorinfo);
									logger.error("Failure in getting response from  the GetResponseData " + JSON.stringify(error));
									session.reject("Failure in getting response from  the GetResponseData " + JSON.stringify(error));
								}
								else {
									hm.response.statusCode = '200 OK';
									logger.debug("response received from GetResponseData :" + JSON.stringify(responseData));
									ctx.setVariable("respo", responseData)
									var urgReq = responseData.urgentRequest;
									if (urgReq == false) {
										var urgReqFPayload = {
											"urgentRequest": true
										};
										var urgReqOMSURL = OMSUrl + '/api/v1/ServiceType/Electric/Crew/' + crewId;
										var urgReqFPayloadPost = {
											target: urgReqOMSURL,
											sslClientProfile: 'omsapi_client_profile',
											method: 'PATCH',
											contentType: 'application/json',
											data: urgReqFPayload,
											headers: {
												'osiApiToken': Token
											}
										};
										var info = " TargetURL :" + urgReqFPayloadPost.target + "; Method :" + urgReqFPayloadPost.method + "; Data :" + JSON.stringify(urgReqFPayloadPost.data) + ". ";
										try {
											urlopen.open(urgReqFPayloadPost, function(error, response) {
												if (error) {
													var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
													ctx.setVariable("exitDescription", errorinfo);
													ctx.setVariable("exitStatus", '500');
													logger.error("url open cannot connect while sending urgent request" + JSON.stringify(error));
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ctx.setVar("exitDescription", sendServiceFailExitDescription);
													//session.reject("url open cannot connect while sending urgent request" + JSON.stringify(error));
												}
												else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "Unable to get response from urgentRequest data , details are : " + info + "; error info :" + error;
																ctx.setVariable("errorDescription", errorinfo);
																logger.error("Unable to get response from urgentRequest data" + JSON.stringify(error));
																session.reject("Unable to get response from urgentRequest data");
															}
															else {
																hm.response.statusCode = '200 OK';
																logger.debug("Message received from urgentRequest data is " + JSON.stringify(responseData));
																ctx.setVar("exitDescription", sendServiceSuccessExitDescription);
																ctx.setVariable("exitStatus", '0');
															}
														});
													}
													else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading response from urgentRequest Data , details are : " + info + "; error info :" + error;
																ctx.setVariable("errorDescription", errorinfo);
																logger.error("failure in reading response from urgentRequest Data " + JSON.stringify(error));
																session.reject("failure in reading response from urgentRequest Data ");
															}
															else {
																ctx.setVar("exitDescription", sendServiceFailExitDescription);
																ctx.setVar("exitDescription", sendServiceFailExitDescription);
																var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
																ctx.setVariable("exitDescription", errorinfo);
																ctx.setVariable("exitStatus", responseStatusCode);
																hm.current.statusCode = responseStatusCode;
																logger.error("Error returned from GetResponseData " + ": with statusCode " + responseStatusCode + " " + responseData);
																ctx.setVariable("retry", 'yes');
																var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
																ctx.setVariable("ErrorTxt", ErrorTxt);
															}
														});
													}
												}
											});
										}
										catch (error) {
											ctx.setVar("exitDescription", sendServiceFailExitDescription);
											var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
											ctx.setVariable("exitDescription", errorinfo);
											ctx.setVariable("exitStatus", '500');
											logger.error("url open cannot connect while sending urgent request" + JSON.stringify(error));
											ctx.setVariable("retry", 'yes');
											var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
											ctx.setVariable("ErrorTxt", ErrorTxt);
										}
									}
									else if (urgReq == true) {
										var urgReqTFPayload = {
											"urgentRequest": false
										};
										var urgReqOMSURL = OMSUrl + '/api/v1/ServiceType/Electric/Crew/' + crewId;
										var urgReqTFPayloadPost = {

											target: urgReqOMSURL,
											sslClientProfile: 'omsapi_client_profile',
											method: 'PATCH',
											contentType: 'application/json',
											data: urgReqTFPayload,
											headers: {
												'osiApiToken': Token
											}
										};
										var info = " TargetURL :" + urgReqTFPayloadPost.target + "; Method :" + urgReqTFPayloadPost.method + "; Data :" + JSON.stringify(urgReqTFPayloadPost.data) + ". ";
										try {
											urlopen.open(urgReqTFPayloadPost, function(error, response) {
												if (error) {
													ctx.setVar("exitDescription", sendServiceFailExitDescription);
													var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
													ctx.setVariable("exitDescription", errorinfo);
													ctx.setVariable("exitStatus", '500');
													logger.error("url open cannot connect while sending urgent request" + JSON.stringify(error));
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													//session.reject("url open cannot connect while sending urgent request" + JSON.stringify(error));
												}
												else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "Unable to get response from urgentRequest data , details are : " + info + "; error info :" + error;
																ctx.setVariable("errorDescription", errorinfo);
																logger.error("Unable to get response from urgentRequest data" + JSON.stringify(error));
																session.reject("Unable to get response from urgentRequest data" + JSON.stringify(error))
															}
															else {
																hm.response.statusCode = '200 OK';
																logger.debug("Message received from urgentRequest data is " + JSON.stringify(responseData));
																var urgReqTTPayload = {
																	"urgentRequest": true
																};
																var urgReqOMSURL = OMSUrl + '/api/v1/ServiceType/Electric/Crew/' + crewId;
																var urgReqTTPayloadPost = {

																	target: urgReqOMSURL,
																	sslClientProfile: 'omsapi_client_profile',
																	method: 'PATCH',
																	contentType: 'application/json',
																	data: urgReqTTPayload,
																	headers: {
																		'osiApiToken': Token
																	}
																};
																var info = " TargetURL :" + urgReqTTPayloadPost.target + "; Method :" + urgReqTTPayloadPost.method + "; Data :" + JSON.stringify(urgReqTTPayloadPost.data) + ". ";
																try {
																	urlopen.open(urgReqTTPayloadPost, function(error, response) {
																		if (error) {
																			ctx.setVar("exitDescription", sendServiceFailExitDescription);
																			var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
																			ctx.setVariable("exitDescription", errorinfo);
																			ctx.setVariable("exitStatus", '500');
																			logger.error("url open cannot connect while sending urgent request" + JSON.stringify(error));
																			ctx.setVariable("retry", 'yes');
																			var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																			//session.reject("url open cannot connect while sending urgent request" + JSON.stringify(error));
																		}
																		else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsJSON(function(error, responseData) {
																					if (error) {
																						var errorinfo = "Unable to get response from urgentRequest data , details are : " + info + "; error info :" + error;
																						ctx.setVariable("errorDescription", errorinfo);
																						logger.error("Unable to get response from urgentRequest data" + JSON.stringify(error));
																						session.reject("Unable to get response from urgentRequest data" + JSON.stringify(error));
																					}
																					else {
																						ctx.setVar("exitDescription", sendServiceSuccessExitDescription);
																						hm.response.statusCode = '200 OK';
																						logger.debug("Message received from urgentRequest data is " + JSON.stringify(responseData));
																						ctx.setVariable("exitStatus", '0');
																					}
																				});
																			}
																			else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "failure in reading response from urgentRequest Data , details are : " + info + "; error info :" + error;
																						ctx.setVariable("errorDescription", errorinfo);
																						logger.error("failure in reading response from urgentRequest Data " + JSON.stringify(error));
																						session.reject("failure in reading response from urgentRequest Data ");
																					}
																					else {
																						ctx.setVar("exitDescription", sendServiceFailExitDescription);
																						var errorinfo = "Error returned from GetResponseData " + ": with statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
																						ctx.setVariable("exitDescription", errorinfo);
																						ctx.setVariable("exitStatus", responseStatusCode);
																						hm.current.statusCode = responseStatusCode;
																						logger.error("Error returned from GetResponseData " + ": with statusCode " + responseStatusCode + " " + responseData);
																						ctx.setVariable("retry", 'yes');
																						var ErrorTxt = " Error returned from GetResponseData " + ": with statusCode " + responseStatusCode + " " + responseData;
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																					}
																				});
																			}
																		}
																	});
																}
																catch (error) {
																	ctx.setVar("exitDescription", sendServiceFailExitDescription);
																	var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
																	ctx.setVariable("exitDescription", errorinfo);
																	ctx.setVariable("exitStatus", '500');
																	logger.error("url open cannot connect while sending urgent request" + JSON.stringify(error));
																	ctx.setVariable("retry", 'yes');
																	var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
																	ctx.setVariable("ErrorTxt", ErrorTxt);
																}
															}
														});
													}
													else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading response from urgentRequest Data , details are : " + info + "; error info :" + error;
																ctx.setVariable("errorDescription", errorinfo);
																logger.error("failure in reading response from urgentRequest Data " + JSON.stringify(error));
																session.reject("failure in reading response from urgentRequest Data ");
															}
															else {
																ctx.setVar("exitDescription", sendServiceFailExitDescription);
																var errorinfo = "Error returned from GetResponseData " + ": with statusCode " + responseStatusCode + " , details are : " + info + "; resposne info :" + responseData;
																ctx.setVariable("exitDescription", errorinfo);
																ctx.setVariable("exitStatus", '500');
																hm.current.statusCode = responseStatusCode;
																logger.error("Error returned from GetResponseData " + ": with statusCode " + responseStatusCode + " " + responseData);
																ctx.setVariable("retry", 'yes');
																var ErrorTxt = " Error returned from GetResponseData " + ": with statusCode " + responseStatusCode + " " + responseData;
																ctx.setVariable("ErrorTxt", ErrorTxt);
															}
														});
													}
												}
											});
										}
										catch (error) {
											ctx.setVar("exitDescription", sendServiceFailExitDescription);
											var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
											ctx.setVariable("exitDescription", errorinfo);
											ctx.setVariable("exitStatus", '500');
											logger.error("url open cannot connect while sending urgent request" + JSON.stringify(error));
											ctx.setVariable("retry", 'yes');
											var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
											ctx.setVariable("ErrorTxt", ErrorTxt);
										}
									}
								}
							});
						}
						else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading the response data from serviceAlert , details are : " + info + "; error info :" + error;
									ctx.setVariable("errorDescription", errorinfo);
									logger.error("Failure in reading the response data from serviceAlert" + JSON.stringify(error));
									session.reject("Failure in reading the response data from serviceAlert");
								}
								else {
									hm.current.statusCode = responseStatusCode;
									ctx.setVariable("run", 'yes');
									var res = responseData.toString();
									var QueueMessage = {
										"CallBackData": {
											"messageID" : incomingData.CallBackData.messageID,
											"Client": Client,
											"ServiceName": incomingData.CallBackData.ServiceName,
											"ExternalRefID": ExternalRefID
										},
										"ErrorMessage": res,
										"CreationTime" : incomingData.ServiceAlert.CreationTime
										

									}
								};
								var targetQueue = session.parameters.Queue;
								var options = {
									target: targetQueue,
									data: QueueMessage
								};
								var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
								try {
									urlopen.open(options, function(error, response) {
										var hm = require('header-metadata');
										if (error) {
											ctx.setVar("exitDescription", sendServiceFailExitDescription);
											var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
											ctx.setVariable("exitDescription", errorinfo);
											ctx.setVariable("exitStatus", '500');
											logger.error(' Mqurlopen.open error');
											ctx.setVariable("retry", 'yes');
											var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
											ctx.setVariable("ErrorTxt", ErrorTxt);
											ctx.setVariable("run", 'yes');
											//session.reject('** Mqurlopen.open error');
											hm.response.statusCode = 500;
										} else {
											var mqrc = response.statusCode;
											if (mqrc == 0) {
												response.readAsBuffer(function(readError, responseData) {
													if (readError) {
														hm.response.statusCode = 500
													} else {
														console.log("MQResponseData " + responseData);
														ctx.setVar("exitDescription", sendServiceFailExitDescription);
														ctx.setVariable("exitStatus", '404');
														ctx.setVariable("exitDestination", targetQueue);
													}
												});
											} else {
												var errorinfo = " ** Mqurlopen.open error [MQRC=" + mqrc + " , details are : " + info + "; error info :" + error;
												ctx.setVariable("exitDescription", errorinfo);
												ctx.setVariable("exitStatus", '500');
												logger.error(' ** Mqurlopen.open error [MQRC=' + mqrc + ']');
												ctx.setVariable("retry", 'yes');
												ctx.setVariable("run", 'yes');
												var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
												ctx.setVariable("ErrorTxt", ErrorTxt);
												//session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
												hm.response.statusCode = 500
												ctx.setVar("exitDescription", sendServiceFailExitDescription);
											}
										}
									})
								}
								catch (error) {
									ctx.setVar("exitDescription", sendServiceFailExitDescription);
									var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
									ctx.setVariable("exitDescription", errorinfo);
									ctx.setVariable("exitStatus", '500');
									logger.error(' Mqurlopen.open error');
									ctx.setVariable("retry", 'yes');
									var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ctx.setVariable("run", 'yes');
									//session.reject('** Mqurlopen.open error');
									hm.response.statusCode = 500;
								}
								//session.reject("Bad Request Error from serviceAlert:" + JSON.stringify(error));
							})
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading response from serviceAlert , details are : " + info + "; error info :" + error;
									ctx.setVariable("errorDescription", errorinfo);
									logger.error("failure in reading response from serviceAlert " + JSON.stringify(error));
									session.reject("failure in reading response from serviceAlert ");
								} else {
									ctx.setVar("exitDescription", sendServiceFailExitDescription);
									var errorinfo = "req_003:Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " , details are : " + info + "; error info :" + error;
									ctx.setVariable("exitDescription", errorinfo);
									ctx.setVariable("exitStatus", responseStatusCode);
									hm.current.statusCode = responseStatusCode;
									logger.error("req_003:Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " " + responseData);
									ctx.setVariable("retry", 'yes');
									var ErrorTxt = "req_003:Error returned from CrewAssignment " + JSON.stringify(error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
								}
							});
						}
					}

				});
			}
			catch (error) {
				ctx.setVar("exitDescription", sendServiceFailExitDescription);
				var errorinfo = "req_002:urlopen connect error while opening the url , details are : " + info + "; error info :" + error;
				ctx.setVariable("exitDescription", errorinfo);
				ctx.setVariable("exitStatus", '500');
				logger.error("urlopen connect error while opening the url " + JSON.stringify(error));
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "req_002:urlopen connect error while opening the url " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
			}
		}
	}
});
