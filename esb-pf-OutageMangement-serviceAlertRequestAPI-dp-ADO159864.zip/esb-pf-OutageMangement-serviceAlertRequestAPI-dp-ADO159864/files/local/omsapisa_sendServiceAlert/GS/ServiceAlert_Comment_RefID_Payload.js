var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("req") || session.createContext("req");
var OMSUrl = session.parameters.OMSUrl;
var Token = session.parameters.OMSToken;
var sendServiceFailExitDescription = session.parameters.sendServiceFailExitDescription;
var sendServiceSuccessExitDescription = session.parameters.sendServiceSuccessExitDescription;
var checkretry = ctx.getVariable("retry");
var checkrun = ctx.getVariable("run");
if ((checkretry !== 'yes') && (checkrun !== 'yes')) {
	session.INPUT.readAsJSON(function(error, incomingData) {
		if (error) {
			var errorinfo = "Error in reading incoming data ; error info :" + error;
			ctx.setVariable("errorDescription", errorinfo);
			logger.error("Error in reading incoming data" + JSON.stringify(error));
			session.reject(error);
		}
		else {
			var crewId = incomingData.ServiceAlert.CrewID;
			var Client = incomingData.CallBackData.Client;
			var ServiceName = incomingData.CallBackData.ServiceName;
			var ExternalRefID = incomingData.CallBackData.ExternalRefID;
			if ((ExternalRefID !== '') && (ExternalRefID !== undefined) && (ExternalRefID !== null)) {
				ExternalRefID = incomingData.CallBackData.ExternalRefID;
				var ExternalRefIDSplit = ExternalRefID.split(":");
				var JobIDGUID = ExternalRefIDSplit[0];
				var Desc = incomingData.ServiceAlert.Description;
				var jobIDPayload = {
					"comment": crewId + ':' + Desc
				};
				var url = OMSUrl + '/api/ServiceType/Electric/Job/' + JobIDGUID + '/Comment';
				var jobIDPayloadPost = {

					target: url,
					sslClientProfile: 'omsapi_client_profile',
					method: 'POST',
					contentType: 'application/json',
					data: jobIDPayload,
					headers: {
						'osiApiToken': Token
					}

				};
				var info = " TargetURL :" + jobIDPayloadPost.target + "; Method :" + jobIDPayloadPost.method + "; Data :" + JSON.stringify(jobIDPayloadPost.data) + ". ";
				try {
					urlopen.open(jobIDPayloadPost, function(error, response) {
						if (error) {
							ctx.setVar("exitDescription", sendServiceFailExitDescription);
							var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
							ctx.setVariable("exitDescription", errorinfo);
							ctx.setVariable("exitStatus", '500');
							logger.error("url open cannot connect while sending comment" + JSON.stringify(error));
							ctx.setVariable("retry", 'yes');
							var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
							ctx.setVariable("ErrorTxt", ErrorTxt);
							//session.reject("url open cannot connect while sending comment" + JSON.stringify(error));
						}
						else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "Unable to get response while sending comment , details are : " + info + "; error info :" + error;
										ctx.setVariable("errorDescription", errorinfo);
										logger.error("Unable to get response while sending comment" + JSON.stringify(error));
										session.reject("Unable to get response while sending comment ");
									}
									else {
										hm.response.statusCode = '200 OK';
										logger.debug("Message received while sending comment is " + JSON.stringify(responseData));
										ctx.setVariable("responseData", responseData);
										ctx.setVariable("exitStatus", '0');
										ctx.setVar("exitDescription", sendServiceSuccessExitDescription);
									}
								});
							}
							else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure in reading response while sending comment , details are : " + info + "; error info :" + error;
										ctx.setVariable("errorDescription", errorinfo);
										logger.error("failure in reading response while sending comment " + JSON.stringify(error));
										session.reject("failure in reading response while sending comment ");
									}
									else {
										var errorinfo = "Error returned from serviceAlert " + ": with statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
										ctx.setVariable("errorDescription", errorinfo);
										hm.current.statusCode = responseStatusCode;
										logger.error("Error returned from serviceAlert " + ": with statusCode " + responseStatusCode + " " + responseData);
										session.reject("Error returned from serviceAlert " + ": with statusCode " + responseStatusCode + " " + responseData);
									}
								});
							}
						}
					});
				}
				catch (error) {
					ctx.setVar("exitDescription", sendServiceFailExitDescription);
					var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
					ctx.setVariable("exitDescription", errorinfo);
					ctx.setVariable("exitStatus", '500');
					logger.error("url open cannot connect while sending comment" + JSON.stringify(error));
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
				}
			}
		}
	});
}
