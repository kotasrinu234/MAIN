var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("req") || session.createContext("req");
var OMSUrl = session.parameters.OMSUrl;
var Token = session.parameters.OMSToken;
var sendServiceFailExitDescription = session.parameters.sendServiceFailExitDescription;
var sendServiceSuccessExitDescription = session.parameters.sendServiceSuccessExitDescription;
var checkretry = ctx.getVariable("retry");
var checkrun = ctx.getVariable("run");
if ((checkretry === 'yes') || (checkrun === 'yes')) {
} else {
	session.INPUT.readAsJSON(function(error, incomingData) {
		if (error) {
			logger.error("Error in reading incoming data" + JSON.stringify(error));
			session.reject(error);
		}
		else {
			var jobId = incomingData.ServiceAlert.JobId;
			if ((jobId !== '') && (jobId !== undefined) && (jobId !== null)) {
				var Client = incomingData.CallBackData.Client;
				var ServiceName = incomingData.CallBackData.ServiceName;
				var ExternalRefID = incomingData.CallBackData.ExternalRefID;
				var url = OMSUrl + '/api/ServiceType/Electric/Job/' + jobId + '/Comment';
				var comm = incomingData.ServiceAlert.JobComments;
				var commentPayload = {
					"comment": comm
				};
				var commentPayloadPost = {
					target: url,
					sslClientProfile: 'omsapi_client_profile',
					method: 'POST',
					contentType: 'application/json',
					data: commentPayload,
					headers: {
						'osiApiToken': Token
					}
				};
				var info = " TargetURL :" + commentPayloadPost.target + "; Method :" + commentPayloadPost.method + "; Data :" + JSON.stringify(commentPayloadPost.data) + ". ";
				try {
					urlopen.open(commentPayloadPost, function(error, response) {
						if (error) {
							ctx.setVar("exitDescription", sendServiceFailExitDescription);
							var errorinfo = "url open cannot connect while sending comment , details are : " + info + "; error info :" + error;
							ctx.setVariable("exitDescription", errorinfo);
							ctx.setVariable("exitStatus", '500');
							logger.error("url open cannot connect while sending comment" + JSON.stringify(error));
							ctx.setVariable("retry", 'yes');
							var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
							ctx.setVariable("ErrorTxt", ErrorTxt);
							//session.reject("url open cannot connect while sending comment" + JSON.stringify(error));
						}
						else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "Unable to get response while sending comment , details are : " + info + "; error info :" + error;
										ctx.setVariable("errorDescription", errorinfo);
										logger.error("Unable to get response while sending comment" + JSON.stringify(error));
										session.reject("Unable to get response while sending comment ");
									}
									else {
										hm.response.statusCode = '200 OK';
										logger.debug("Message received while sending comment is " + JSON.stringify(responseData));
										ctx.setVariable("exitStatus", '0');
										ctx.setVar("exitDescription", sendServiceSuccessExitDescription);
									}
								});
							}
							else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure in reading response while sending comment JobId , details are : " + info + "; error info :" + error;
										ctx.setVariable("errorDescription", errorinfo);
										logger.error("failure in reading response while sending comment JobId " + JSON.stringify(error));
										session.reject("failure in reading response while sending comment JobId ");
									}
									else {
										hm.current.statusCode = responseStatusCode;
										logger.error("Error returned while sending comment JobId " + ": with statusCode " + responseStatusCode + " " + responseData);
										var getUrl = OMSUrl + '/api/ServiceType/Electric/Job/Query?isInternalIDs=false&includeFields=id';
										var jobId = incomingData.ServiceAlert.JobId;
										var getUrlPayload = [
											jobId
										];
										var getUrlPayloadPost = {

											target: getUrl,
											sslClientProfile: 'omsapi_client_profile',
											method: 'POST',
											contentType: 'application/json',
											data: getUrlPayload,
											headers: {
												'osiApiToken': Token
											}

										};
										var info = " TargetURL :" + getUrlPayloadPost.target + "; Method :" + getUrlPayloadPost.method + "; Data :" + JSON.stringify(getUrlPayloadPost.data) + ". ";
										try {
											urlopen.open(getUrlPayloadPost, function(error, response) {
												if (error) {
													ctx.setVar("exitDescription", sendServiceFailExitDescription);
													var errorinfo = "urlopen connect error while opening the url , details are : " + info + "; error info :" + error;
													ctx.setVariable("exitDescription", errorinfo);
													ctx.setVariable("exitStatus", '500');
													logger.error("urlopen connect error while opening the url " + JSON.stringify(error));
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													//session.reject("urlopen connect error while opening the url " + JSON.stringify(error));
												}
												else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "Unable to get response while sending comment JobId , details are : " + info + "; error info :" + error;
																ctx.setVariable("errorDescription", errorinfo);
																logger.error("Unable to get response while sending comment JobId" + JSON.stringify(error));
																session.reject("Unable to get response while sending comment JobId");
															}
															else {
																hm.response.statusCode = '200 OK';
																logger.debug("Message received while sending comment JobId is " + JSON.stringify(responseData));
																ctx.setVariable("respoJobID", responseData)
																var intJobId = responseData[0].id;
																var postUrl = OMSUrl + '/api/ServiceType/Electric/Job/' + intJobId + '/Comment';
																var comment = incomingData.ServiceAlert.JobComments;
																var commentIntrnlIdPayload = {
																	"comment": comment
																};
																var commentIntrnlIdPayloadPost = {

																	target: postUrl,
																	sslClientProfile: 'omsapi_client_profile',
																	method: 'POST',
																	contentType: 'application/json',
																	data: commentIntrnlIdPayload,
																	headers: {
																		'osiApiToken': Token
																	}
																};
																var info = " TargetURL :" + commentIntrnlIdPayloadPost.target + "; Method :" + commentIntrnlIdPayloadPost.method + "; Data :" + JSON.stringify(commentIntrnlIdPayloadPost.data) + ". ";
																try {
																	urlopen.open(commentIntrnlIdPayloadPost, function(error, response) {
																		if (error) {
																			ctx.setVar("exitDescription", sendServiceFailExitDescription);
																			var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
																			ctx.setVariable("exitDescription", errorinfo);
																			ctx.setVariable("exitStatus", '500');
																			logger.error("urlopen connect error while opening the url " + JSON.stringify(error));
																			ctx.setVariable("retry", 'yes');
																			var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																			//session.reject("urlopen connect error while opening the url " + JSON.stringify(error));
																		}
																		else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsJSON(function(error, responseData) {
																					if (error) {
																						var errorinfo = "Unable to get response while sending comment JobId , details are : " + info + "; error info :" + error;
																						ctx.setVariable("errorDescription", errorinfo);
																						logger.error("Unable to get response while sending comment JobId" + JSON.stringify(error));
																						session.reject("Unable to get response while sending comment JobId ");
																					}
																					else {
																						hm.response.statusCode = '200 OK';
																						logger.debug("Message received while sending comment JobId is " + JSON.stringify(responseData));
																						ctx.setVar("exitDescription", sendServiceSuccessExitDescription);
																					}
																				});
																			}
																			else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "failure in reading response while sending comment JobId , details are : " + info + "; error info :" + error;
																						ctx.setVariable("errorDescription", errorinfo);
																						logger.error("failure in reading response while sending comment JobId " + JSON.stringify(error));
																						session.reject("failure in reading response while sending comment JobId ");
																					}
																					else {
																						hm.current.statusCode = responseStatusCode;
																						var errorinfo = "Error returned while sending comment JobId " + ": with statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
																						ctx.setVariable("errorDescription", errorinfo);
																						logger.error("Error returned while sending comment JobId " + ": with statusCode " + responseStatusCode + " " + responseData);
																						session.reject("Error returned while sending comment JobId " + ": with statusCode " + responseStatusCode + " " + responseData);
																					}
																				});
																			}
																		}
																	});
																}
																catch (error) {
																	ctx.setVar("exitDescription", sendServiceFailExitDescription);
																	var errorinfo = "urlopen connect error with POST call for OMS api , details are : " + info + "; error info :" + error;
																	ctx.setVariable("exitDescription", errorinfo);
																	ctx.setVariable("exitStatus", '500');
																	logger.error("urlopen connect error while opening the url " + JSON.stringify(error));
																	ctx.setVariable("retry", 'yes');
																	var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
																	ctx.setVariable("ErrorTxt", ErrorTxt);
																}
															}
														});
													}
													else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading response while sending comment JobId , details are : " + info + "; error info :" + error;
																ctx.setVariable("errorDescription", errorinfo);
																logger.error("failure in reading response while sending comment JobId " + JSON.stringify(error));
																session.reject("failure in reading response while sending comment JobId ");
															}
															else {
																hm.current.statusCode = responseStatusCode;
																var errorinfo = "Error returned while sending comment JobId " + ": with statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
																ctx.setVariable("errorDescription", errorinfo);
																logger.error("Error returned while sending comment JobId " + ": with statusCode " + responseStatusCode + " " + responseData);
																session.reject("Error returned while sending comment JobId " + ": with statusCode " + responseStatusCode + " " + responseData);
															}
														});
													}
												}
											});
										} catch (error) {
											ctx.setVar("exitDescription", sendServiceFailExitDescription);
											var errorinfo = "urlopen connect error while opening the url , details are : " + info + "; error info :" + error;
											ctx.setVariable("exitDescription", errorinfo);
											ctx.setVariable("exitStatus", '500');
											logger.error("urlopen connect error while opening the url " + JSON.stringify(error));
											ctx.setVariable("retry", 'yes');
											var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
											ctx.setVariable("ErrorTxt", ErrorTxt);
										}
									}
								});
							}
						}
					});
				}
				catch (error) {
					ctx.setVar("exitDescription", sendServiceFailExitDescription);
					var errorinfo = "url open cannot connect while sending comment , details are : " + info + "; error info :" + error;
					ctx.setVariable("exitDescription", errorinfo);
					ctx.setVariable("exitStatus", '500');
					logger.error("url open cannot connect while sending comment" + JSON.stringify(error));
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
				}
			}
		}
	});
}
