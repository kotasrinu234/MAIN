<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1" extension-element-prefixes="dp" xmlns:dp="http://www.datapower.com/extensions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="no"/>
   <xsl:strip-space elements="*"/>
   <xsl:variable name="Header" select="dp:variable('var://context/receiveVoltageReadResponse/Header')"/>
   <xsl:template match="/">
   <xsl:if test="dp:variable('var://context/mycontext/process') = 'true'">
   <!--This xslt is used to handle exceptions specific to datapower-->
      <xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
      <xsl:variable name="dpErrorMessage" select="dp:variable('var://service/error-message')"/>
      <xsl:variable name="customErrorCode" select="dp:variable('var://context/error/customErrorCode')"/>
      <xsl:variable name="customErrorMessage" select="dp:variable('var://context/error/customErrorMessage')"/>
      <soapenv:Envelope xmlns:v1="http://esm.dteco.com/common/v1">
         <soapenv:Header/>
         <soapenv:Body>
		    <NS1:AcknowledgementMessage xmlns:NS1="http://esm.dteco.com/common/v1">
               <xsl:copy-of select="$Header"/>			   
			   <NS1:Reply>
						<NS1:ReplyCode>FAILURE</NS1:ReplyCode>
						<NS1:Error>
							<NS1:level>FATAL</NS1:level>
							<xsl:choose>
								<xsl:when test="$customErrorCode and $customErrorCode !=''">
									<NS1:code>
										<xsl:value-of select="$customErrorCode" />
									</NS1:code>
									<NS1:details>
										<xsl:value-of select="$customErrorMessage" />
									</NS1:details>
								</xsl:when>
								<xsl:otherwise>
									<NS1:code>
										<xsl:value-of select="$systemErrorCode" />
									</NS1:code>
									<NS1:details>
										<xsl:value-of select="$dpErrorMessage" />
									</NS1:details>
								</xsl:otherwise>
							</xsl:choose>
						</NS1:Error>
					</NS1:Reply>
			 </NS1:AcknowledgementMessage>
         </soapenv:Body>
      </soapenv:Envelope>
	  
	    <xsl:choose>
								<xsl:when test="$customErrorMessage!=''">
									<xsl:message dp:type="all" dp:priority="error">id=mread_rvrr01|errorString:<xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage)"/>
										</xsl:message>
								</xsl:when>
								<xsl:otherwise>
								<xsl:message dp:type="all" dp:priority="error">id=mread_rvrr01|errorString:<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage)"/>
										</xsl:message>
										</xsl:otherwise>
										</xsl:choose>
	  </xsl:if>
   </xsl:template>
</xsl:stylesheet>