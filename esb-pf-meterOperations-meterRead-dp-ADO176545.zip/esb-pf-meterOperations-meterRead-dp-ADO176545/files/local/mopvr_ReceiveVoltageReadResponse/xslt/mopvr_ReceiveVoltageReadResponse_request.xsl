<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver v1" extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1" xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request" xmlns:exslt="http://exslt.org/common" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
    <xsl:strip-space elements="*"/>
    <xsl:template match="/">
	<xsl:if test="dp:variable('var://context/mycontext/process') = 'true'">
        <!-- This xslt is used to put incoming data from Voltage Read into Q2(MPVR.REPLY.FROM.VOLTAGE.READ) -->
        <xsl:variable name="queueManager" select="dp:variable('var://context/receiveVoltageReadResponse/queueManager')"/>
        <xsl:variable name="destQueue" select="dp:variable('var://context/receiveVoltageReadResponse/destQueue')"/>
        <xsl:variable name="target-url" select="concat('dpmq://', $queueManager,'/?RequestQueue=',$destQueue)"/>
        <xsl:variable name="CallApi">
            <dp:url-open target="{$target-url}" response="responsecode-binary">
                <xsl:copy-of select="dp:variable('var://context/INPUT')"/>
            </dp:url-open>
        </xsl:variable>
        <xsl:variable name="responseCode">
            <xsl:value-of select="$CallApi/result/responsecode"/>
        </xsl:variable>
        <dp:set-variable name="'var://context/CallAPIResponseCode'" value="$responseCode"/>
        <xsl:choose>
            <xsl:when
                test="$responseCode=0"><!-- <xsl:message dp:type="all" dp:priority="error">mopver_005 :<xsl:value-of select="$target-url"/> 
                                </xsl:message> -->
            </xsl:when>
            <xsl:otherwise>
                <xsl:choose>
                    <xsl:when test="string-length(normalize-space($responseCode))&gt; 0">
                        <xsl:variable name="CallApiResponse">
                            <xsl:copy-of select="(dp:decode(dp:binary-encode($CallApi/result/binary/node()),'base-64'))" disable-output-escaping="yes"/>
                        </xsl:variable>
                        <xsl:message dp:type="all" dp:priority="error">mopvr_001 TransactionID :<xsl:value-of select="$target-url"/>
                            Call API Response code :
                            <xsl:value-of select="$responseCode"/>
                            and reason :
                            <xsl:value-of select="$CallApiResponse"/>
                        </xsl:message>
<dp:set-variable name="'var://context/ILS/CustomErrorMsg'" value="concat('Failure in putting message to Queue with the status code: ', $responseCode, ' and the Error message: ', $target-url)"/>
                           <dp:set-variable name="'var://context/ILS/exitStatus'" value="$responseCode"/>
                       
                      <dp:reject>
    Failure in putting message to Queue with the status code:
    <xsl:value-of select="$responseCode"/>
    and the Error message :
    <xsl:value-of select="$target-url"/>
</dp:reject>
                       
                        
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:variable name="errorstatuscode">
                            <xsl:value-of select="$CallApi/result/errorstatuscode"/>
                        </xsl:variable>
                        <xsl:variable name="errorstring">
                            <xsl:value-of select="$CallApi/result/errorstring"/>
                        </xsl:variable>
                        <xsl:message dp:type="all" dp:priority="error">mopver_002 :<xsl:value-of select="$target-url"/>
                            Call API Response failed with error code
                            <xsl:value-of select="$errorstatuscode"/>
                            and with error string as
                            <xsl:value-of select="$errorstring"/></xsl:message>
                            
<dp:set-variable name="'var://context/ILS/CustomErrorMsg'" value="concat('unable to place message in meter read queue with responseCode as: ', $errorstatuscode, ' and the Error message: ', $target-url)"/>
                           <dp:set-variable name="'var://context/ILS/exitStatus'" value="'500'"/>
                            
                        <dp:reject>
                            unable to place message in meter read queue with responseCode as
                            <xsl:value-of select="$target-url"/>
                            with error code
                            <xsl:value-of select="$errorstatuscode"/>
                            and with error string as
                            <xsl:value-of select="$errorstring"/></dp:reject>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:otherwise>
        </xsl:choose>
		</xsl:if>
    </xsl:template>
</xsl:stylesheet>
