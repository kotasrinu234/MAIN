<xsl:stylesheet version="1.0" extension-element-prefixes="dp soap dpconfig ver" exclude-result-prefixes="dp dpconfig  soapenv  date"
	xmlns:met="http://iec.ch/TC57/2009/MeterReadings#"
	xmlns:v11="http://esm.dteco.com/common/v1"
	xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:ns4="http://contingencyreadservice.esm.dteco.com/v1/request"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release"
	xmlns:ns0="http://www.multispeak.org/Version_4.1_Release"
	xmlns:date="http://exslt.org/dates-and-times">
	<xsl:include href="local://util/error-util.xslt" />
<xsl:variable name="config" select="document('local://mopvr_ReceiveVoltageReadResponse/xml/mopvr_ReceiveVoltageReadResponse_readmeter_config.xml')" />
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes" />
	<xsl:param name="dpconfig:messageType" select="''" />
	<xsl:param name="dpconfig:exitDescription" select="''" />
	<xsl:param name="dpconfig:entryDescription" select="''" />

	<xsl:param name="dpconfig:flag" select="''" />
	<xsl:variable name="flag" select="$dpconfig:flag" />

	<xsl:variable name="messageType" select="$dpconfig:messageType" />
	<xsl:variable name="exitDescription" select="$dpconfig:exitDescription" />
	<xsl:variable name="entryDescription" select="$dpconfig:entryDescription" />
	<xsl:variable name="correlationID" select="dp:generate-uuid ()" />
	<xsl:variable name="sourceEventTimestamp" select="date:date-time()" />
	<xsl:variable name="queueManager" select="$config/config/ReadMeter/queueManager" />
	<xsl:variable name="destQueue" select="$config/config/ReadMeter/destQueue" />


	<xsl:template match="/">
		<!--This xslt is used to set context variables which are being used in 
			sending successful/unsuccessful acknowledgement -->
		<xsl:apply-templates select="soapenv:Envelope" />
	</xsl:template>
	
	<xsl:template match="soapenv:Envelope">
		<xsl:apply-templates select="soapenv:Body" />
	</xsl:template>
	
	<xsl:template match="soapenv:Body">
	<!-- <xsl:if test= "flag = 'ALL' or (flag = 'NO' and contains(/*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='CorrelationID'], 'mopvr') ) " > -->
	
<!-- 	<dp:set-variable name="'var://context/check/check'" value="'yes'" />
 -->	
	<!-- <xsl:if test= "$flag = 'ON' or ($flag = 'OFF' and contains(v1:replyReadMeter/v11:Header/v11:CorrelationID, 'mopvr') and not(contains(v1:replyReadMeter/v11:Header/v11:CorrelationID, 'mopvr-mq')))" > -->
	<xsl:if test= "$flag = 'ON' or ($flag = 'OFF' and contains(v1:replyReadMeter/v11:Header/v11:CorrelationID, 'mopvr'))" >
	
	
	<xsl:variable name="mRIDValue" select="v1:replyReadMeter/met:MeterReadings/met:MeterReading/met:MeterAsset/met:mRID" />
	<!-- below line add a check as no for header respons if control comes here -->
	<!-- <dp:set-variable name="'var://context/check/check'" value="'no'" /> -->
	
	<dp:set-variable name= "'var://context/mycontext/process'" value = "'true'" />
	<!-- <xsl:if test="dp:variable('var://context/mycontext/process') = 'true'">
	
	</xsl:if> -->
		<dp:set-variable name="'var://context/ILS/messageType'" value="$messageType" />
		<dp:set-variable name="'var://context/ILS/exitDescription'" value="$exitDescription" />
		<dp:set-variable name="'var://context/ILS/entryDescription'" value="$entryDescription" />
		<dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'" />
		<dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID" />
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$sourceEventTimestamp" />
<dp:set-variable name="'var://context/ILS/exitDestination'" value="$destQueue" />

</xsl:if>
		<xsl:choose>
			<xsl:when test="v1:replyReadMeter">
				<xsl:variable name="mRIDValue" select="v1:replyReadMeter/met:MeterReadings/met:MeterReading/met:MeterAsset/met:mRID" />
					
					<xsl:variable name="correlationIDValue" select="v1:replyReadMeter/v11:Header/v11:CorrelationID" />
<!--  <xsl:if test="contains($correlationIDValue, ':')">
  <xsl:variable name="afterFirstColon" select="substring-after($correlationIDValue, ':')" />
  <xsl:variable name="extractedPart" select="substring-before($afterFirstColon, ':')" />
  <dp:set-variable name="'var://context/ILS/transactionID'" value="$extractedPart" />
</xsl:if> -->
					

<xsl:choose>
  <!-- Case: Contains a colon -->
  <xsl:when test="contains($correlationIDValue, ':')">
    <xsl:variable name="afterFirstColon" select="substring-after($correlationIDValue, ':')" />
    <xsl:variable name="extractedPart" select="substring-before($afterFirstColon, ':')" />
    <!-- Now, $extractedPart will contain the desired value -->
    <dp:set-variable name="'var://context/ILS/transactionID'" value="$extractedPart" />
  </xsl:when>
  <!-- Case: Does not contain a colon -->
  <xsl:otherwise>
    <!-- Use the entire CorrelationID value -->
    <dp:set-variable name="'var://context/ILS/transactionID'" value="$correlationIDValue" />
  </xsl:otherwise>
</xsl:choose>
				<dp:set-variable name="'var://context/ILS/meterIds'" value="$mRIDValue" />
			</xsl:when>

			<xsl:when test="ns0:ReadingChangedNotification">
			<xsl:variable name="meterIDValue" select="ns0:ReadingChangedNotification/ns0:changedMeterReads/ns0:meterReading/ns0:meterID" />
	<xsl:variable name="transactionIDValue"	select="ns0:ReadingChangedNotification/ns0:changedMeterReads/ns0:transactionID" />
				<dp:set-variable name="'var://context/ILS/transactionID'" value="$meterIDValue" />
				<dp:set-variable name="'var://context/ILS/meterIds'" value="$transactionIDValue" />
			</xsl:when>
		</xsl:choose>

		<xsl:variable name="inVerb"	select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='Verb']" />
		<xsl:variable name="inNoun"	select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='Noun']" />
		<dp:set-variable name="'var://context/mycontext/Inverb'" value="$inVerb" />
		<xsl:if test="$inVerb= ''">
			<dp:set-variable name="'var://context/mycontext/errorMessage'" value="'Verb Missing'" />
		</xsl:if>
		<xsl:if test="$inNoun= ''">
			<dp:set-variable name="'var://context/mycontext/errorMessage'" value="'Noun Missing'" />
		</xsl:if>

		<xsl:if test="$inVerb=''">
			<xsl:call-template name="reject">
				<xsl:with-param name="errorCode" select="'0x00d30003'" />
				<xsl:with-param name="errorMessage"	select="dp:variable('var://context/mycontext/errorMessage')" />
			</xsl:call-template>
		</xsl:if>

		<xsl:if test="$inNoun=''">
			<xsl:call-template name="reject">
				<xsl:with-param name="errorCode" select="'0x00d30003'" />
				<xsl:with-param name="errorMessage" select="dp:variable('var://context/mycontext/errorMessage')" />
			</xsl:call-template>
		</xsl:if>

		<xsl:variable name="Header">
			<NS2:Header xmlns:NS2="http://esm.dteco.com/common/v1">
				<NS2:Verb>
					<xsl:value-of select="$config/config/Header/Verb" />
				</NS2:Verb>
				<NS2:Noun>
					<xsl:value-of select="$config/config/Header/Noun" />
				</NS2:Noun>
				<NS2:Timestamp>
					<xsl:variable name="timestamp"	select="date:date-time()" />
					<xsl:variable name="ZuluTime" select="date:add($timestamp,'PT0H')" />
					<xsl:variable name="ms"	select="substring(dp:time-value(),11,3)" />
					<xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')" />
				</NS2:Timestamp>
				<NS2:Source>
					<xsl:value-of select="$config/config/Header/Source" />
				</NS2:Source>
				<NS2:ReplyAddress>
					<xsl:value-of select="$config/config/Header/ReplyAddress" />
				</NS2:ReplyAddress>
				<NS2:MessageID>
					<xsl:value-of select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='MessageID']" />
				</NS2:MessageID>
				<NS2:CorrelationID>
					<xsl:value-of select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='CorrelationID']" />
				</NS2:CorrelationID>
			</NS2:Header>
		</xsl:variable>
		<dp:set-variable name="'var://context/receiveVoltageReadResponse/Header'" value="$Header" />
		<dp:set-variable name="'var://context/receiveVoltageReadResponse/queueManager'" value="$queueManager" />
		<dp:set-variable name="'var://context/receiveVoltageReadResponse/destQueue'" value="$destQueue" />
	
	<!-- <xsl:if test="dp:variable('var://context/check/check') != 'no'">
	<xsl:variable name="Header">
			<NS2:Header xmlns:NS2="http://esm.dteco.com/common/v1">
				<NS2:Verb>
					<xsl:value-of select="$config/config/Header/Verb" />
				</NS2:Verb>
				<NS2:Noun>
					<xsl:value-of select="$config/config/Header/Noun" />
				</NS2:Noun>
				<NS2:Timestamp>
					<xsl:variable name="timestamp"	select="date:date-time()" />
					<xsl:variable name="ZuluTime" select="date:add($timestamp,'PT0H')" />
					<xsl:variable name="ms"	select="substring(dp:time-value(),11,3)" />
					<xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')" />
				</NS2:Timestamp>
				<NS2:Source>
					<xsl:value-of select="$config/config/Header/Source" />
				</NS2:Source>
				<NS2:ReplyAddress>
					<xsl:value-of select="$config/config/Header/ReplyAddress" />
				</NS2:ReplyAddress>
				<NS2:MessageID>
					<xsl:value-of select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='MessageID']" />
				</NS2:MessageID>
				<NS2:CorrelationID>
					<xsl:value-of select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='CorrelationID']" />
				</NS2:CorrelationID>
			</NS2:Header>
		</xsl:variable>
		<dp:set-variable name="'var://context/receiveVoltageReadResponse/Header'" value="$Header" />
		<dp:set-variable name= "'var://context/mycontext/checkprocess'" value = "'true'" />
	</xsl:if> -->
	<xsl:choose>
	<xsl:when test="dp:variable('var://context/mycontext/process') = 'true'">
            <dp:set-variable name="'var://context/mycontext/rule'" value="'mopvr_ReceiveVoltageReadResponse_Policy_request_rule'" />
	</xsl:when>
	<xsl:otherwise>
            <dp:set-variable name="'var://context/mycontext/rule'" value="'mopvr_ReceiveVoltageReadResponse_Policy_unsol_request_rule'" />
	</xsl:otherwise>
	</xsl:choose>
	
	
	</xsl:template>
</xsl:stylesheet>
