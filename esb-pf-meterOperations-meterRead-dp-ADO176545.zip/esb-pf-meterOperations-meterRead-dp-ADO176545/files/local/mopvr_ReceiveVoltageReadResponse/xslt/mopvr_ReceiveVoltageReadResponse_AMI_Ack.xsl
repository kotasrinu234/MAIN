<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver v1" extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1" xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request" xmlns:exslt="http://exslt.org/common" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
   <xsl:strip-space elements="*"/>
   <!--This xslt is used inorder to send acknowledgement to Voltage Read-->
   <xsl:variable name="Header" select="dp:variable('var://context/receiveVoltageReadResponse/Header')"/>
   <xsl:template match="/">
  <!--  <xsl:if test="dp:variable('var://context/mycontext/process') = 'true' or (dp:variable('var://context/mycontext/checkprocess') = 'true')"> -->
      <soapenv:Envelope>
         <soapenv:Body>
            <NS1:AcknowledgementMessage xmlns:NS1="http://esm.dteco.com/common/v1">
               <xsl:copy-of select="$Header"/>
               <NS1:Reply>
                  <NS1:ReplyCode>SUCCESS</NS1:ReplyCode>
               </NS1:Reply>
            </NS1:AcknowledgementMessage>
         </soapenv:Body>
      </soapenv:Envelope>
	<!--   </xsl:if> -->
   </xsl:template>
</xsl:stylesheet>