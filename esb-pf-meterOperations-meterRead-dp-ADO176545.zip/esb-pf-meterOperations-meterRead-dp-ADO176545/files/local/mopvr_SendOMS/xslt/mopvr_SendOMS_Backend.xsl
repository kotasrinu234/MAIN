	<xsl:stylesheet version="1.0" exclude-result-prefixes="dp" extension-element-prefixes="dp dpconfig" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config">
    <xsl:output method="xml" version="2.0" encoding="UTF-8" indent="yes"/>
    <xsl:strip-space elements="*"/>
    <xsl:param name="dpconfig:OMSBackend"/>
    <xsl:param name="dpconfig:MQBackend"/>
    <xsl:param name="dpconfig:QueueSuccessfulExitDescription" select="''"/>
    <xsl:param name="dpconfig:QueueUnsuccessfulExitDescription" select="''"/>
    <xsl:variable name="QueueSuccessfulExitDescription" select="$dpconfig:QueueSuccessfulExitDescription"/>
    <xsl:variable name="QueueUnsuccessfulExitDescription" select="$dpconfig:QueueUnsuccessfulExitDescription"/>
    <xsl:param name="dpconfig:SuccessfulexitDescription" select="''"/>
    <xsl:param name="dpconfig:unsuccessfulexitDescription" select="''"/>
    <xsl:variable name="SuccessfulexitDescription" select="$dpconfig:SuccessfulexitDescription"/>
    <xsl:variable name="unsuccessfulexitDescription" select="$dpconfig:unsuccessfulexitDescription"/>
    <xsl:param name="dpconfig:flag" select="''" />
	<xsl:variable name="flag" select="$dpconfig:flag" />
    <xsl:template match="/">
        <xsl:variable name="IncomingPayload">
            <xsl:copy-of select="."/>
        </xsl:variable>
<xsl:if test="($flag = 'OFF' and (dp:variable('var://context/mopvr_SendOMS/MQbackend') or  
                                  dp:variable('var://context/mopvr_SendOMS/RequestQueuebackend'))) 
              or 
              ($flag = 'ON' and (dp:variable('var://context/mopvr_SendOMS/MQbackend') or  
                                 dp:variable('var://context/mopvr_SendOMS/RequestQueuebackend')))">
           <xsl:if test="not (dp:variable('var://context/mopvr_SendOMS/processessedToQueue') = 'Yes')">
                <xsl:variable name="target-url" select="concat($dpconfig:MQBackend, dp:variable('var://context/mopvr_SendOMS/ReplyToQueue'))"/>
                <xsl:variable name="response">
                    <!-- Queue URL OPEN -->
                    <dp:url-open target="{$target-url}" response="responsecode-ignore">
                        <xsl:copy-of select="dp:variable('var://context/SendOMSResponse')"/>
                    </dp:url-open>
                </xsl:variable>
                <xsl:variable name="responseCode">
                    <xsl:value-of select="$response/url-open/responsecode" />
                </xsl:variable>
                <xsl:choose>
                    <xsl:when test="$responseCode='0'">
                        <!-- Queue URL OPEN Success-->
                        <xsl:message dp:type="all" dp:priority="debug">Successfully Inserted the message into  queue</xsl:message>
                        <dp:set-variable name="'var://context/ILS/Exitstatus'" value="'0'"/>
                        
                         <xsl:variable name="OMSCallSuccess" select="dp:variable('var://context/mread/OMSCallSuccess')"/>
                        <xsl:variable name="OMSCallFailure" select="dp:variable('var://context/mread/OMSCallFailure')"/>

<xsl:choose>
    <!-- If OMSCallSuccess is set, print the success message -->
    <xsl:when test="$OMSCallSuccess = 'SUCCESS'">
        <dp:set-variable name="'var://context/ILS/exitdescription'" value="$QueueSuccessfulExitDescription"/>
        <dp:set-variable name="'var://context/ILS/Exitdestination'" value="$target-url"/>
    </xsl:when>

    <!-- If OMSCallFailure is set, print the failure message -->
    <xsl:when test="$OMSCallFailure = 'FAILURE'">
        <dp:set-variable name="'var://context/ILS/exitdescription'" value="$QueueUnsuccessfulExitDescription"/>
        <dp:set-variable name="'var://context/ILS/Exitdestination'" value="$target-url"/>
    </xsl:when>
</xsl:choose>
                        
                        <!--  <dp:set-variable name="'var://context/ILS/Exitdestination'" value="$target-url"/>
                        <dp:set-variable name="'var://context/ILS/exitdescription'" value="$QueueSuccessfulExitDescription"/> -->
                        <dp:set-variable name="'var://context/mread/callOMS'" value="'Yes'"/>
                        <dp:set-variable name="'var://context/mread/processessedToQueue'" value="'yes'"/>
                        <dp:set-variable name="'var://context/mread/MQQueue'" value="'yes'"/>
                        <xsl:variable name="QueueExit">
                            <!-- Conditional acceptance payload for step exit -->
                            <ProcessessedToQueue>Yes</ProcessessedToQueue>
                        </xsl:variable>
                        <xsl:copy-of select="$QueueExit"/>
                    </xsl:when>
                    <xsl:otherwise>
                        <!-- Queue URL OPEN ERROR and Retry (Direct exit for ILS as no OMS call happened) -->
                        <xsl:message dp:type="all" dp:priority="error">unable to place messsage queue</xsl:message>
                        <dp:set-variable name="'var://context/mread/retry'" value="'yes'"/>
                        <dp:set-variable name="'var://context/mread/ErrorTxt'" value="'unable to place messsage queue'"/>
                        <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'500'"/>
                        <dp:set-variable name="'var://context/ILS/exitDescription'" value="'unable to place messsage queue'"/>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:if>
            
            <dp:set-variable name="'var://context/sendoms/responseFromMQ'" value="$response"/>
            <dp:set-variable name="'var://context/sendoms/routing-url-mq'" value="concat($dpconfig:MQBackend, dp:variable('var://context/mopvr_SendOMS/ReplyToQueue'))"/>
        </xsl:if>
   <!--       <xsl:if test="dp:variable('var://context/mread/callOMS') = 'Yes' or dp:variable('var://context/mopvr_SendOMS/processessedToQueue') = 'Yes'"> -->
      
                           
               <xsl:if test="($flag = 'ON' and 
              (dp:variable('var://context/mopvr_SendOMS/RequestQueuebackend') and dp:variable('var://context/mread/MQQueue'))
               or dp:variable('var://context/mopvr_SendOMS/MQbackend') 
               or dp:variable('var://context/mopvr_SendOMS/mopvrbackend') 
               or dp:variable('var://context/mread/backend'))
              or ($flag = 'OFF' and dp:variable('var://context/mopvr_SendOMS/mopvrbackend') and not(dp:variable('var://context/mread/backend') = 'yes'))">          
                <xsl:variable name="OMSBackendCall">
                    <!-- OMS URL OPEN -->
                    <dp:url-open target="{$dpconfig:OMSBackend}" ssl-proxy="client:mopvr_SendOMS_ClientProfile" http-headers="$headerValues" http-method="post" response="responsecode-binary">
                        <xsl:copy-of select="$IncomingPayload"/>
                    </dp:url-open>
                </xsl:variable>
                <xsl:variable name="responseCode">
                    <xsl:value-of select="$OMSBackendCall/result/responsecode"/>
                </xsl:variable>
                <dp:set-variable name="'var://context/mread/OMSBackendCallResponseCode'" value="$responseCode"/>
                <xsl:choose>
                    <xsl:when test="$responseCode='200'">
                        <!-- OMS URL OPEN Success -->
                        <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'0'"/>
                        <xsl:variable name="OMSBackendCallResponse">
                            <xsl:copy-of select="(dp:decode(dp:binary-encode($OMSBackendCall/result/binary/node()),'base-64'))"/>
                        </xsl:variable>
                          
                        <xsl:variable name="OMSCallSuccess" select="dp:variable('var://context/mread/OMSCallSuccess')"/>
                        <xsl:variable name="OMSCallFailure" select="dp:variable('var://context/mread/OMSCallFailure')"/>

<xsl:choose>
    <!-- If OMSCallSuccess is set, print the success message -->
    <xsl:when test="$OMSCallSuccess = 'SUCCESS'">
        <dp:set-variable name="'var://context/ILS/exitDescription'" value="$SuccessfulexitDescription"/>
<dp:set-variable name="'var://context/ILS/ExitDestination'" value="concat($dpconfig:OMSBackend)"/>
    </xsl:when>

    <!-- If OMSCallFailure is set, print the failure message -->
    <xsl:when test="$OMSCallFailure = 'FAILURE'">
        <dp:set-variable name="'var://context/ILS/exitDescription'" value="$unsuccessfulexitDescription"/>
<dp:set-variable name="'var://context/ILS/ExitDestination'" value="concat($dpconfig:OMSBackend)"/>
    </xsl:when>
</xsl:choose>   
                    </xsl:when>
                    <xsl:otherwise>
                        <!-- OMS URL OPEN ERROR and Retry -->
                        <xsl:message dp:priority="error">
                            <xsl:value-of select="' mopvr:001: Error encountered while attempting to establish a connection with the OMS URL '"/>
                            <xsl:value-of select="$dpconfig:OMSBackend"/>
                        </xsl:message>
                        <xsl:variable name="ErrorTxt">
                            <xsl:copy-of select="'mopvr:001 : Error encountered while attempting to establish a connection with the OMS URL '"/>
                            <xsl:value-of select="$dpconfig:OMSBackend"/>
                        </xsl:variable>
                        <dp:set-variable name="'var://context/mread/ErrorTxt'" value="string($ErrorTxt)"/>
                        <dp:set-variable name="'var://context/mread/retry'" value="'yes'"/>
                        <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'500'"/>
                        <dp:set-variable name="'var://context/ILS/exitDescription'" value="$ErrorTxt"/>
                        
                    </xsl:otherwise>
                </xsl:choose>
                </xsl:if>
                
         <!--  </xsl:if>-->
        <!--  <dp:set-variable name="'var://service/routing-url-sslprofile'" value="'client:mopvr_SendOMS_ClientProfile'"/> -->
        <!--  <dp:set-variable name="'var://service/routing-url'" value="concat($dpconfig:OMSBackend, ';transactional=true')"/> -->
    
    </xsl:template>
</xsl:stylesheet>
