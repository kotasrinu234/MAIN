<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1" extension-element-prefixes="dp" xmlns:dp="http://www.datapower.com/extensions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="no"/>
   <xsl:strip-space elements="*"/>
   <xsl:variable name="transactionID" select="dp:variable('var://context/mopvr_SendOMS/context')/context/transactionID"/>
   <xsl:template match="/">
      <xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
      <xsl:variable name="dpErrorMessage" select="dp:variable('var://service/error-message')"/>
      <xsl:variable name="customErrorCode" select="dp:variable('var://context/error/customErrorCode')"/>
      <xsl:variable name="customErrorMessage" select="dp:variable('var://context/error/customErrorMessage')"/>
          <xsl:variable name="Routingurl" select="dp:variable('var://service/routing-url')"/>
      
      <dp:set-variable name="'var://context/ILS/exitStatus'" value="'500'"/>
     <dp:set-variable name="'var://context/ILS/CustomErrorMsg'" value="concat('Error opening in OMSBackend url: ', $Routingurl)"/>  
      <xsl:choose>
						<xsl:when test="$customErrorCode and $customErrorCode !=''">
							<xsl:message dp:type="all" dp:priority="error">id=mread_so01|ErrorCode:<xsl:value-of select="$customErrorCode" /> ErrorMessage: <xsl:value-of select="concat('transactionID:',$transactionID,',',$customErrorMessage)" />
							</xsl:message>
						</xsl:when>
						<xsl:otherwise>
							<xsl:message dp:type="all" dp:priority="error">id=mread_so01|ErrorCode:<xsl:value-of select="$systemErrorCode" /> ErrorMessage: <xsl:value-of select="concat('transactionID:',$transactionID,',',$dpErrorMessage)" />
								</xsl:message>
						</xsl:otherwise>
					</xsl:choose>
   </xsl:template>
</xsl:stylesheet>
