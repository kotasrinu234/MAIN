<xsl:stylesheet version="1.0" exclude-result-prefixes="dp  get ns0 v1 " extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ns0="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1" xmlns:v11="http://esm.dteco.com/common/v1" xmlns:met="http://iec.ch/TC57/2009/MeterReadings#" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
    <xsl:output method="xml" indent="yes" omit-xml-declaration="no"/>
    <xsl:param name="dpconfig:messageType" select="''"/>
    <xsl:param name="dpconfig:entryDescription" select="''"/>
    <xsl:variable name="messageType" select="$dpconfig:messageType"/>
    <xsl:variable name="entryDescription" select="$dpconfig:entryDescription"/>
    <xsl:variable name="correlationID" select="dp:generate-uuid ()"/>
    <xsl:variable name="sourceEventTimestamp" select="date:date-time()"/>
    <xsl:variable name="configurationProperties">
        <xsl:copy-of select="document('local:///OMS_ConfigurationProperties/XML/Configuration.xml')"/>
    </xsl:variable>
    <xsl:variable name="passwordProperties">
        <xsl:copy-of select="document('local:///OMS_ConfigurationProperties/XML/Password.xml')"/>
    </xsl:variable>
    <xsl:variable name="company" select="$configurationProperties/Configuration/System/Interface/Company/text()"/>
    <xsl:variable name="algorithm" select="$configurationProperties/Configuration/System/Interface/Algorithm/text()"/>
    <xsl:variable name="key" select="$configurationProperties/Configuration/System/Interface/Key/text()"/>
    <xsl:variable name="userId" select="$configurationProperties/Configuration/System/Interface/UserID/text()"/>
    <xsl:variable name="buildString" select="$configurationProperties/Configuration/System/Interface/BuildString/text()"/>
    <xsl:variable name="build" select="$configurationProperties/Configuration/System/Interface/Build/text()"/>
    <xsl:variable name="minorVersion" select="$configurationProperties/Configuration/System/Interface/MinorVersion/text()"/>
    <xsl:variable name="majorVersion" select="$configurationProperties/Configuration/System/Interface/MajorVersion/text()"/>
    <xsl:variable name="encryptedPassword" select="$passwordProperties"/>
    <xsl:template match="/">
        <dp:set-variable name="'var://context/ILS/messageType'" value="$messageType"/>
        <dp:set-variable name="'var://context/ILS/entryDescription'" value="$entryDescription"/>
        <dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'"/>
        <dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID"/>
        <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$sourceEventTimestamp"/>
        <dp:set-variable name="'var://context/mopvr_SendOMS/originalRequest'" value="."/>
        <!--Fetching the MQMD headers -->
        <xsl:variable name="entriesMQMD" select="dp:request-header('MQMD')"/>
        <xsl:variable
        name="entriesMQRFH2" select="dp:request-header('MQRFH2')"/>
        <!--Parsing the string MQMD headers to XML format -->
        <xsl:if test="($entriesMQMD !='' and $entriesMQMD !=null)">
            <xsl:variable name="mqmd-headers" select="dp:parse($entriesMQMD)"/>
        </xsl:if>
        <xsl:if test="($entriesMQRFH2 !='' and $entriesMQRFH2 !=null)">
            <xsl:variable name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)"/>
        </xsl:if>
        <xsl:message dp:priority="debug">
            <xsl:value-of select="concat('The Request MQMD : ', $entriesMQMD)"/>
        </xsl:message>
        <xsl:message dp:priority="debug">
            <xsl:value-of select="concat('The Request MQRFH2 : ', $entriesMQRFH2)"/>
        </xsl:message>
        <!--Placing the MQMD headers in the context variables -->
        <dp:set-variable name="'var://context/MQMD/MQMDRequestHeaders'" value="$mqmd-headers"/>
        <dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value="$mqrfh2-headers"/>
        <xsl:variable name="omsHeader">
            <ns0:MultiSpeakMsgHeader>
                <xsl:attribute name="Company">
                    <xsl:value-of select="$company"/>
                </xsl:attribute>
                <xsl:attribute name="Pwd">
                    <xsl:value-of select="dp:decrypt-data($algorithm,$key,$encryptedPassword)"/>
                </xsl:attribute>
                <xsl:attribute name="UserID">
                    <xsl:value-of select="$userId"/>
                </xsl:attribute>
                <xsl:attribute name="BuildString">
                    <xsl:value-of select="$buildString"/>
                </xsl:attribute>
                <xsl:attribute name="Build">
                    <xsl:value-of select="$build"/>
                </xsl:attribute>
                <xsl:attribute name="MinorVersion">
                    <xsl:value-of select="$minorVersion"/>
                </xsl:attribute>
                <xsl:attribute name="MajorVersion">
                    <xsl:value-of select="$majorVersion"/>
                </xsl:attribute>
            </ns0:MultiSpeakMsgHeader>
        </xsl:variable>
        <dp:set-variable name="'var://context/mopvr_SendOMS/header'" value="$omsHeader"/>
        <xsl:apply-templates select="soapenv:Envelope"/>
    </xsl:template>
    <xsl:template match="soapenv:Envelope">
        <xsl:apply-templates select="soapenv:Body"/>
    </xsl:template>
    <xsl:template match="soapenv:Body">
        <xsl:apply-templates select="v1:replyReadMeter"/>
    </xsl:template>
    <!--Set necessary details in the context variable for further ussages -->
    <xsl:template match="v1:replyReadMeter">
    <xsl:variable name="CorrelationID">
        <xsl:value-of select="v11:Header/v11:CorrelationID"/>
    </xsl:variable>
    <xsl:variable name="UUID">
        <xsl:choose>
            <xsl:when test="contains($CorrelationID, 'mopvr-mq:')">
                <xsl:value-of select="substring-before(substring-after($CorrelationID, 'mopvr-mq:'), ':RQ:')"/>
            </xsl:when>
            <xsl:when test="contains($CorrelationID, 'mopvr-mq-uuid:')">
                <xsl:value-of select="substring-after($CorrelationID, 'mopvr-mq-uuid:')"/>
            </xsl:when>
            <xsl:when test="contains($CorrelationID, 'mopvr:')">
			<xsl:value-of select="substring-after($CorrelationID, 'mopvr:')"/>
			</xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$CorrelationID"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:variable>
    <dp:set-variable name="'var://context/ILS/transactionID'" value="$UUID"/>
        <xsl:variable name="MessageID">
            <xsl:value-of select="v11:Header/v11:MessageID"/>
        </xsl:variable>
       
        <xsl:variable name="meterIDValue" select="met:MeterReadings/met:MeterReading/met:MeterAsset/met:mRID"/>
        <dp:set-variable name="'var://context/ILS/meterIds'" value="$meterIDValue"/>
        <xsl:variable name="context">
            <context>
                <meterID>
                    <xsl:value-of select="met:MeterReadings/met:MeterReading/met:MeterAsset/met:mRID"/>
                </meterID>
                <replyCode>
                    <xsl:value-of select="v11:Reply/v11:ReplyCode"/>
                </replyCode>
                <intervalBlocksValue>
                    <xsl:value-of select="met:MeterReadings/met:MeterReading/met:IntervalBlocks/met:IntervalReadings/met:value"/>
                </intervalBlocksValue>
                <intervalBlocksTime>
                    <xsl:value-of select="met:MeterReadings/met:MeterReading/met:IntervalBlocks/met:IntervalReadings/met:timeStamp"/>
                </intervalBlocksTime>
             <!--   <xsl:choose>
                    <xsl:when test="contains($CorrelationID,'mopvr-mq:')">
                        <dp:set-variable name="'var://context/mopvr_SendOMS/backend'" value="'MQ1'"/>
                        <dp:set-variable name="'var://context/mopvr_SendOMS/ReplyToQueue'" value="substring-after($CorrelationID, ':RQ:')"/>
                        <transactionID>
                            <xsl:value-of select="substring-before(substring-after($CorrelationID, 'mopvr-mq:'), ':RQ:')"/>
                        </transactionID>
                    </xsl:when>
                    <xsl:when test="contains($CorrelationID,'mopvr-mq-uuid:')">
                        <dp:set-variable name="'var://context/mopvr_SendOMS/backend'" value="'MQ2'"/>
                        <dp:set-variable name="'var://context/mopvr_SendOMS/ReplyToQueue'" value="substring-after($CorrelationID, ':RQ:')"/>
                    </xsl:when>
                    <xsl:when test="contains($CorrelationID,'mopvr:')">
					<transactionID>
                            <xsl:value-of select="substring-after($CorrelationID, 'mopvr:')"/>
                        </transactionID>
					
					</xsl:when>
                    <xsl:otherwise>
                        <transactionID>
                            <xsl:value-of select="$CorrelationID"/>
                        </transactionID>
                    </xsl:otherwise>
                </xsl:choose> -->
				
				<xsl:choose>
    <!-- Case 1: Correlation ID contains 'mopvr-mq:' and also contains ':RQ:' -->
    <xsl:when test="contains($CorrelationID, 'mopvr-mq:') and contains($CorrelationID, ':RQ:')">
        <dp:set-variable name="'var://context/mopvr_SendOMS/RequestQueuebackend'" value="'yes'"/>
        <dp:set-variable name="'var://context/mopvr_SendOMS/ReplyToQueue'" value="substring-after($CorrelationID, ':RQ:')"/>
        <transactionID>
            <xsl:value-of select="substring-before(substring-after($CorrelationID, 'mopvr-mq:'), ':RQ:')"/>
        </transactionID>
    </xsl:when>

    <!-- Case 2: Correlation ID contains 'mopvr-mq:' but does not have ':RQ:' -->
    <xsl:when test="contains($CorrelationID, 'mopvr-mq:')">
        <dp:set-variable name="'var://context/mopvr_SendOMS/MQbackend'" value="'yes'"/>
        <transactionID>
            <xsl:value-of select="substring-after($CorrelationID, 'mopvr-mq:')"/>
        </transactionID>
    </xsl:when>

    <!-- Case 3: Correlation ID contains 'mopvr:' -->
    <xsl:when test="contains($CorrelationID, 'mopvr:')">
	<dp:set-variable name="'var://context/mopvr_SendOMS/mopvrbackend'" value="'yes'"/>
        <transactionID>
            <xsl:value-of select="substring-after($CorrelationID, 'mopvr:')"/>
        </transactionID>
    </xsl:when>

    <!-- Default Case: If it doesn't match any of the above conditions -->
    <xsl:otherwise>
	<dp:set-variable name="'var://context/mread/backend'" value="'yes'"/>
        <transactionID>
            <xsl:value-of select="$CorrelationID"/>
        </transactionID>
    </xsl:otherwise>
</xsl:choose>
				
            </context>
        </xsl:variable>
        <dp:set-variable name="'var://context/mopvr_SendOMS/context'" value="$context"/>
    </xsl:template>
</xsl:stylesheet>
