<xsl:stylesheet version="1.0" exclude-result-prefixes="dp  get ns0 v1 " extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ns0="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1" xmlns:v11="http://esm.dteco.com/common/v1" xmlns:met="http://iec.ch/TC57/2009/MeterReadings#" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <xsl:output method="xml" version="2.0" encoding="UTF-8" indent="yes"/>
    <xsl:strip-space elements="*"/>
  <!--    <xsl:param name="dpconfig:SuccessfulexitDescription" select="''"/>
    <xsl:param name="dpconfig:unsuccessfulexitDescription" select="''"/>
    <xsl:variable name="SuccessfulexitDescription" select="$dpconfig:SuccessfulexitDescription"/>
    <xsl:variable name="unsuccessfulexitDescription" select="$dpconfig:unsuccessfulexitDescription"/> -->
    <xsl:variable name="events" select="document('local:///mopvr_SendOMS/xml/mopvr_SendOMS_Config.xml')"/>
    <xsl:variable name="context" select="dp:variable('var://context/mopvr_SendOMS/context')"/>
    <xsl:variable name="environmentSpecificProperties">
        <xsl:copy-of select="document('local:///mopvr_SendOMS/xml/EnvironmentSpecific.xml')"/>
    </xsl:variable>
    <xsl:template
        match="/">
        <!--This xslt is used to send Successful/unsuccessful Acknowledgement to 
        			OMS -->
        <dp:set-http-request-header name="'SOAPAction'" value="$environmentSpecificProperties/EnvironmentSpecific/OMSSOAPAction/text()"/>
        <dp:remove-http-request-header name="MQMD"/>
        <soap:Envelope>
            <soap:Header>
                <xsl:copy-of select="dp:variable('var://context/mopvr_SendOMS/header')"/>
            </soap:Header>
            <soap:Body>
                <xsl:apply-templates select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='replyReadMeter']/*[local-name()='MeterReadings']/*[local-name()='MeterReading']/*[local-name()='IntervalBlocks']"/>
                <xsl:apply-templates select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='replyReadMeter']"/>
            </soap:Body>
        </soap:Envelope>
    </xsl:template>
    <xsl:template match="*[local-name()='IntervalBlocks']">
        <!-- <xsl:variable name="reason" select="../met:MeterAsset/met:status/met:reason"/> -->
        <!--R -->
        <!--<xsl:variable name="value" select="../met:MeterAsset/met:status/met:value"/> -->
        <!--1st V -->
            <xsl:if test="*[local-name()='ReadingType' and @*[local-name()='ref' and normalize-space(.) = 'Vh(a)']]"> <dp:set-variable name="'var://context/sendoms/first'" value="string(met:IntervalReadings[1]/met:value)"/>
            <dp:set-variable name="'var://context/sendoms/second'" value="string(met:IntervalReadings[2]/met:value)"/>
            <dp:set-variable
            name="'var://context/sendoms/third'" value="string(met:IntervalReadings[3]/met:value)"/>
        <!-- <dp:set-variable name="'var://context/sendoms/reason'" value="string(../met:MeterAsset/met:status/met:reason)" 
        				/> <dp:set-variable name="'var://context/sendoms/value'" value="string(../met:MeterAsset/met:status/met:value)" 
        				/> -->
        </xsl:if>
    </xsl:template>
    <xsl:template match="v1:replyReadMeter">
        <xsl:variable
        name="reason" select="met:MeterReadings/met:MeterReading/met:MeterAsset/met:status/met:reason"/>
        <!--R -->
        <xsl:variable
        name="value" select="met:MeterReadings/met:MeterReading/met:MeterAsset/met:status/met:value"/>
        <!--1st V -->
        <xsl:variable
        name="Readingvalue-first" select="dp:variable('var://context/sendoms/first')"/>
        <!--2nd V -->
        <xsl:variable
        name="Readingvalue-second" select="dp:variable('var://context/sendoms/second')"/>
        <!--3rd V -->
        <xsl:variable name="Readingvalue-third" select="dp:variable('var://context/sendoms/third')"/>
        <xsl:variable name="X-first" select="(60 div $value) * $Readingvalue-first"/>
        <xsl:variable name="X-second" select="(60 div $value) * $Readingvalue-second"/>
        <xsl:variable name="X-third" select="(60 div $value) * $Readingvalue-third"/>
        <xsl:variable name="firstblock-mins" select="2 *  $value"/>
        <xsl:variable name="timedecrease-firstblock" select="concat('-P0Y0M0DT0H', $firstblock-mins, 'M')"/>
        <xsl:variable name="timedecrease-secondblock" select="concat('-P0Y0M0DT0H', $value, 'M')"/>
        <xsl:variable name="timestamp" select="met:MeterReadings/met:MeterReading/met:IntervalBlocks/met:IntervalReadings/met:timeStamp"/>
        <xsl:variable name="timestamp-firstblock" select="date:add($timestamp, $timedecrease-firstblock)"/>
        <xsl:variable name="timestamp-secondblock" select="date:add($timestamp, $timedecrease-secondblock)"/>
        <xsl:variable name="lowercase" select="'abcdefghijklmnopqrstuvwxyz'"/>
        <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
        <xsl:variable name="reason-uppercase" select="translate($reason, $lowercase, $uppercase)"/>
        <xsl:variable name= "payload">
        <ns0:ReadingChangedNotification>
            <ns0:changedMeterReads>
                <xsl:if test="*[local-name()='Reply']/*[local-name()='ReplyCode'] = 'SUCCESS'">
                   <!--  <dp:set-variable name="'var://context/ILS/exitDescription'" value="$SuccessfulexitDescription"/> -->
                   <dp:set-variable name="'var://context/mread/OMSCallSuccess'" value="'SUCCESS'"/>
                    <xsl:element name="ns0:meterReading">
                        <xsl:attribute name="verb">
                            <xsl:value-of select="'Change'"/>
                        </xsl:attribute>
                        <ns0:meterID>
                            <xsl:value-of select="dp:variable('var://context/mopvr_SendOMS/context')/context/meterID"/>
                        </ns0:meterID>
                        <ns0:readingValues>
                            <xsl:for-each select="met:MeterReadings/met:MeterReading/met:IntervalBlocks">
                                <xsl:if test="met:ReadingType[@ref = 'Vh(a)']">
                                    <xsl:variable name="Count_IntervalReadings">
                                        <xsl:value-of select="count(met:IntervalReadings)"/>
                                    </xsl:variable>
                                    <xsl:if test="$Count_IntervalReadings = '3'">
                                        <xsl:if
                                            test="met:IntervalReadings[1]">
                                            <!--first -->
                                            <ns0:readingValue>
                                                <ns0:units>
                                                    <xsl:value-of select="'V'"/>
                                                </ns0:units>
                                                <ns0:value>
                                                    <xsl:value-of select="$X-first"/>
                                                </ns0:value>
                                                <ns0:fieldName>
                                                    <xsl:value-of select="'Voltage Average 1'"/>
                                                </ns0:fieldName>
                                                <ns0:timeStamp>
                                                    <xsl:value-of select="$timestamp-firstblock"/>
                                                </ns0:timeStamp>
                                            </ns0:readingValue>
                                        </xsl:if>
                                        <!--second -->
                                        <xsl:if test="met:IntervalReadings[2]">
                                            <ns0:readingValue>
                                                <ns0:units>
                                                    <xsl:value-of select="'V'"/>
                                                </ns0:units>
                                                <ns0:value>
                                                    <xsl:value-of select="$X-second"/>
                                                </ns0:value>
                                                <ns0:fieldName>
                                                    <xsl:value-of select="'Voltage Average 2'"/>
                                                </ns0:fieldName>
                                                <ns0:timeStamp>
                                                    <xsl:value-of select="$timestamp-secondblock"/>
                                                </ns0:timeStamp>
                                            </ns0:readingValue>
                                        </xsl:if>
                                        <!--third -->
                                        <xsl:if test="met:IntervalReadings[3]">
                                            <ns0:readingValue>
                                                <ns0:units>
                                                    <xsl:value-of select="'V'"/>
                                                </ns0:units>
                                                <ns0:value>
                                                    <xsl:value-of select="$X-third"/>
                                                </ns0:value>
                                                <ns0:fieldName>
                                                    <xsl:value-of select="'Voltage Average 3'"/>
                                                </ns0:fieldName>
                                                <ns0:timeStamp>
                                                    <xsl:value-of select="$timestamp"/>
                                                </ns0:timeStamp>
                                            </ns0:readingValue>
                                        </xsl:if>
                                    </xsl:if>
                                    <xsl:if test="$Count_IntervalReadings = '2'">
                                        <xsl:if
                                            test="met:IntervalReadings[1]">
                                            <!--first -->
                                            <ns0:readingValue>
                                                <ns0:units>
                                                    <xsl:value-of select="'V'"/>
                                                </ns0:units>
                                                <ns0:value>
                                                    <xsl:value-of select="$X-first"/>
                                                </ns0:value>
                                                <ns0:fieldName>
                                                    <xsl:value-of select="'Voltage Average 1'"/>
                                                </ns0:fieldName>
                                                <ns0:timeStamp>
                                                    <xsl:value-of select="$timestamp-secondblock"/>
                                                </ns0:timeStamp>
                                            </ns0:readingValue>
                                        </xsl:if>
                                        <!--second -->
                                        <xsl:if test="met:IntervalReadings[2]">
                                            <ns0:readingValue>
                                                <ns0:units>
                                                    <xsl:value-of select="'V'"/>
                                                </ns0:units>
                                                <ns0:value>
                                                    <xsl:value-of select="$X-second"/>
                                                </ns0:value>
                                                <ns0:fieldName>
                                                    <xsl:value-of select="'Voltage Average 2'"/>
                                                </ns0:fieldName>
                                                <ns0:timeStamp>
                                                    <xsl:value-of select="$timestamp"/>
                                                </ns0:timeStamp>
                                            </ns0:readingValue>
                                        </xsl:if>
                                    </xsl:if>
                                    <xsl:if test="$Count_IntervalReadings = '1'">
                                        <xsl:if
                                            test="met:IntervalReadings[1]">
                                            <!--first -->
                                            <ns0:readingValue>
                                                <ns0:units>
                                                    <xsl:value-of select="'V'"/>
                                                </ns0:units>
                                                <ns0:value>
                                                    <xsl:value-of select="$X-first"/>
                                                </ns0:value>
                                                <ns0:fieldName>
                                                    <xsl:value-of select="'Voltage Average 1'"/>
                                                </ns0:fieldName>
                                                <ns0:timeStamp>
                                                    <xsl:value-of select="$timestamp"/>
                                                </ns0:timeStamp>
                                            </ns0:readingValue>
                                        </xsl:if>
                                    </xsl:if>
                                </xsl:if>
                            </xsl:for-each>
                            <xsl:if test="$reason-uppercase = 'INTERVALLENGTH'">
                                <ns0:readingValue>
                                    <ns0:units>
                                        <xsl:value-of select="'Interval timer'"/>
                                    </ns0:units>
                                    <ns0:value>
                                        <xsl:value-of select="$value"/>
                                    </ns0:value>
                                    <ns0:fieldName>
                                        <xsl:value-of select="'IntervalLength'"/>
                                    </ns0:fieldName>
                                    <ns0:timeStamp></ns0:timeStamp>
                                </ns0:readingValue>
                            </xsl:if>
                            <xsl:for-each select="met:MeterReadings/met:MeterReading/met:Readings">
                                <xsl:if test="met:ReadingType[@ref = 'Number of minutes on battery carryover']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Minutes on battery'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Number of minutes on battery carryover'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'Number of Inversion Tampers']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Nbr of inversion'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Number of Inversion Tampers'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'Number of Removal Tampers']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Nbr of removal'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Number of Removal Tampers'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'ins V(a)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'V'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'ins V(a)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'Instantaneous Watts Delivered Phase A']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'W'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Instantaneous Watts Delivered Phase A'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'Instantaneous Watts Received Phase A']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'W'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Instantaneous Watts Received Phase A'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <!--new change for 3 phase meters start -->
                                <xsl:if test="met:ReadingType[@ref = 'Temperature']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'deg F'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Temperature'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <!-- <xsl:if test="met:ReadingType[@ref = 'Service Type']"> <ns0:readingValue> 
                                									<ns0:units> <xsl:value-of select="'Service Type'"/> </ns0:units> <ns0:value> 
                                									<xsl:value-of select="met:value"/> </ns0:value> <ns0:fieldName> <xsl:value-of 
                                									select="'Service Type'"/> </ns0:fieldName> <ns0:timeStamp> <xsl:value-of 
                                									select="met:timeStamp"/> </ns0:timeStamp> </ns0:readingValue> </xsl:if> -->
                                <xsl:if test="met:ReadingType[@ref = 'V(a)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'V'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'V(a)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'V(b)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'V'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'V(b)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'V(c)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'V'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'V(c)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'I(a)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Amps'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'I(a)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'I(b)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Amps'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'I(b)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'I(c)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Amps'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'I(c)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'V Angle(a)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Voltage phase angle'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'V Angle(a)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'V Angle(b)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Voltage phase angle'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'V Angle(b)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'V Angle(c)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Voltage phase angle'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'V Angle(c)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'I Angle(a)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Current phase angle'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'I Angle(a)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'I Angle(b)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Current phase angle'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'I Angle(b)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'I Angle(c)']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Current phase angle'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'I Angle(c)'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'Ins kVar']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'kW'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Ins kVar'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'Ins kVA']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'kVA'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Ins kVA'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <xsl:if test="met:ReadingType[@ref = 'Ins PF']">
                                    <ns0:readingValue>
                                        <ns0:units>
                                            <xsl:value-of select="'Power factor'"/>
                                        </ns0:units>
                                        <ns0:value>
                                            <xsl:value-of select="met:value"/>
                                        </ns0:value>
                                        <ns0:fieldName>
                                            <xsl:value-of select="'Ins PF'"/>
                                        </ns0:fieldName>
                                        <ns0:timeStamp>
                                            <xsl:value-of select="met:timeStamp"/>
                                        </ns0:timeStamp>
                                    </ns0:readingValue>
                                </xsl:if>
                                <!--new change for 3 phase meters end -->
                            </xsl:for-each>
                        </ns0:readingValues>
                    </xsl:element>
                </xsl:if>
                <xsl:if test="*[local-name()='Reply']/*[local-name()='ReplyCode'] = 'FAILURE'">
                 <!--     <dp:set-variable name="'var://context/ILS/exitDescription'" value="$unsuccessfulexitDescription"/> -->
                                    <dp:set-variable name="'var://context/mread/OMSCallFailure'" value="'FAILURE'"/>
                 
                    <xsl:element name="ns0:meterReading">
                        <xsl:attribute name="objectID"/>
                        <xsl:attribute name="verb">
                            <xsl:value-of select="'Change'"/>
                        </xsl:attribute>
                        <xsl:if test="*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='level']">
                            <dp:set-variable name="'var://context/mopvr_SendOMS/errorlevel'" value="*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='level']/text()"/>
                        </xsl:if>
                        <xsl:if test="*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='code']">
                            <dp:set-variable name="'var://context/mopvr_SendOMS/errorcode'" value="*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='code']/text()"/>
                        </xsl:if>
                        <xsl:if test="*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='details']">
                            <dp:set-variable name="'var://context/mopvr_SendOMS/errordetails'" value="*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='details']/text()"/>
                        </xsl:if>
                        <xsl:attribute name="errorString">
                            <xsl:value-of select="concat(dp:variable('var://context/mopvr_SendOMS/errorlevel'),':', dp:variable('var://context/mopvr_SendOMS/errorcode'),':', dp:variable('var://context/mopvr_SendOMS/errordetails'))"/>
                        </xsl:attribute>
                        <xsl:attribute name="replaceID"/>
                        <xsl:attribute name="utility"/>
                        <ns0:meterID>
                            <xsl:value-of select="dp:variable('var://context/mopvr_SendOMS/context')/context/meterID"/>
                        </ns0:meterID>
                    </xsl:element>
                </xsl:if>
            </ns0:changedMeterReads>
            <ns0:transactionID>
                <xsl:value-of select="dp:variable('var://context/mopvr_SendOMS/context')/context/transactionID"/>
            </ns0:transactionID>
        </ns0:ReadingChangedNotification>
        </xsl:variable>
               <xsl:copy-of select="$payload"></xsl:copy-of>
    </xsl:template>
</xsl:stylesheet>
