<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1" extension-element-prefixes="dp date" xmlns:dp="http://www.datapower.com/extensions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:date="http://exslt.org/dates-and-times" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope">
   <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="no"/>
   <xsl:strip-space elements="*"/>
   <xsl:include href="local://util/error-util.xsl"/>
   <!--This xslt is used to throw an error when Q1(MOPVR.REQUEST.FOR.VOLTAGE.READ) is down-->
   <xsl:template match="/">
    <xsl:variable name="customErrorMsg" select="dp:variable('var://context/ILS/CustomMQErrorMsg')"/>
      <xsl:variable name="errorCode" select="url-open/statuscode"/>
       <xsl:variable name="responseCode" select="url-open/responsecode"/>
      <xsl:variable name="errorMessage" select="concat($customErrorMsg,' Error Message : ',url-open/errorstring)"/>
       <xsl:variable name="customErrorMsg" select="dp:variable('var://context/ILS/CustomMQErrorMsg')"/>
      <xsl:if test="url-open/statuscode !=0">
      <dp:set-variable name="'var://context/ILS/exitStatus'" value="$responseCode" />
         <xsl:call-template name="reject">
            <xsl:with-param name="errorCode" select="$errorCode"/>
            <xsl:with-param name="errorMessage" select="$errorMessage"/>
         </xsl:call-template>
      </xsl:if>
   </xsl:template>
</xsl:stylesheet>
