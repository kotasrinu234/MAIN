<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get v1" extension-element-prefixes="dp soapenv date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1" xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request"  xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope">
   <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
   <xsl:strip-space elements="*"/>
   <!--This xslt is used inorder to send incoming data from OMS to Q1(MOPVR.REQUEST.FOR.VOLTAGE.READ)-->
   <xsl:template match="/">
 
      <xsl:variable name="queueManager" select="dp:variable('var://context/mopvr_ReceiveVoltageRead/queueManager')"/>
      <xsl:variable name="destQueue" select="dp:variable('var://context/mopvr_ReceiveVoltageRead/destQueue')"/>
      <xsl:variable name="target-url" select="concat('dpmq://', $queueManager,'/?RequestQueue=',$destQueue,';Sync=true')"/>
	  <dp:set-variable
			name="'var://context/ILS/exitDestination'" value="$destQueue" />
	  	  <xsl:variable name="MQMDStr">
			<MQMD>
				<Format>
					<xsl:value-of select="'MQHRF2'"/>
				</Format>
			</MQMD>
		</xsl:variable>

		

		<xsl:variable name="MQRFH2Request">
		<xsl:choose>
		<xsl:when test="contains(dp:variable('var://service/URL-in'), 'MOPVR.INT.REQUEST.FOR.VOLTAGE.READ')">
		<dp:set-variable name="'var://context/mopvr_ReceiveVoltageRead/FrontEnd'" value="'MQ'"/>
			<MQRFH2>
				<StrucId>RFH</StrucId>
				<Version>2</Version>
				<Format>MQSTR</Format>
				<CodedCharSetId>819</CodedCharSetId>
				<Flags>0</Flags>
				<NameValueCCSID>1208</NameValueCCSID>
				<NameValueData>
					<NameValue>
						<usr>
							<Authorization>
								<xsl:value-of select="dp:http-request-header('Authorization')"/>
							</Authorization>
							<FrontEnd>MQFSH</FrontEnd>
							<RQ><xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/ReplyToQ')"/></RQ>
						</usr>
					</NameValue>
				</NameValueData>
			</MQRFH2>
			</xsl:when>
		<xsl:when test="contains(dp:variable('var://service/URL-in'), 'http://')">
			<MQRFH2>
				<StrucId>RFH</StrucId>
				<Version>2</Version>
				<Format>MQSTR</Format>
				<CodedCharSetId>819</CodedCharSetId>
				<Flags>0</Flags>
				<NameValueCCSID>1208</NameValueCCSID>
				<NameValueData>
					<NameValue>
						<usr>
							<Authorization>
								<xsl:value-of select="dp:http-request-header('Authorization')"/>
							</Authorization>
							
						</usr>
					</NameValue>
				</NameValueData>
			</MQRFH2>
		</xsl:when>
		<xsl:otherwise>
		</xsl:otherwise>
		</xsl:choose>
		</xsl:variable>
			<xsl:variable name="serializedMQRFH2Request">
			<dp:serialize select="$MQRFH2Request" omit-xml-decl="yes"/>
		</xsl:variable>

		<xsl:variable name="MQMDStr2">
			<dp:serialize select="$MQMDStr" omit-xml-decl="yes"/>
		</xsl:variable>
	  
	  	<xsl:variable name="headerValues">
			<header name="MQMD">
				<xsl:copy-of select="$MQMDStr2"/>
			</header>
			<header name="MQRFH2">
				<xsl:copy-of select="$serializedMQRFH2Request"/>
			</header>
		</xsl:variable>
	
		<xsl:variable name="headers">
			<header name="MQMD">
				<xsl:copy-of select="$MQMDStr2"/>
			</header>
			<header name="MQRFH2">
				<xsl:copy-of select="$serializedMQRFH2Request"/>
			</header>
		</xsl:variable>

		<xsl:variable name="result">
			<dp:url-open http-headers="$headers" response="responsecode-ignore" target="{$target-url}">
				<xsl:copy-of select="dp:variable('var://context/INPUT')" />
			</dp:url-open>
		</xsl:variable>
		
		<dp:set-variable name="'var://context/ILS/CustomMQErrorMsg'" value="concat('Error openinig MQ URL :',$target-url)"/>

	<!-- 	<xsl:message dp:priority="error">
                       url-open():::::<xsl:copy-of select="$result"/>
		</xsl:message>  -->
		<dp:set-variable name="'var://context/RTQ/MQRFH2Headers'" value="$headers"/>
		<dp:set-variable name="'var://context/RTQ/RetryQueueResult'" value="$result"/>


		<dp:set-request-header name="'MQMD'" value="$MQMDStr2"/>
		<dp:set-request-header name="'MQRFH2'" value="$serializedMQRFH2Request"/>

		<xsl:copy-of select="$result"/>
		

   </xsl:template>
</xsl:stylesheet>
