<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get v1" extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1" xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request" xmlns:exslt="http://exslt.org/common" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope">
   <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
   <xsl:strip-space elements="*"/>
   <xsl:template match="/">
   <!--This xslt is used to send an unsuccessful acknowledgement to OMS-->
      <xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
      <xsl:variable name="dpErrorMessage" select="dp:variable('var://service/error-message')"/>
      <xsl:variable name="customErrorCode" select="dp:variable('var://context/error/customErrorCode')"/>
      <xsl:variable name="customErrorMessage" select="dp:variable('var://context/error/customErrorMessage')"/>
      <xsl:variable name="context" select="dp:variable('var://context/mopvr_ReceiveVoltageRead/context')/context"/>
      <xsl:variable name="objectIDs" select="$context/objectIDs"/>
      <xsl:variable name="timestamp" select="date:date-time()"/>
      <xsl:variable name="ZuluTime" select="date:add($timestamp,'PT0H')"/>
      <xsl:variable name="ms" select="substring(dp:time-value(),11,3)"/>
      <soapenv:Envelope>
         <soapenv:Header>
            <ver:MultiSpeakMsgHeader>
               <xsl:attribute name="MajorVersion">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@MajorVersion"/>
               </xsl:attribute>
               <xsl:attribute name="MinorVersion">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@MinorVersion"/>
               </xsl:attribute>
               <xsl:attribute name="Build">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@Build"/>
               </xsl:attribute>
               <xsl:attribute name="BuildString">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@BuildString"/>
               </xsl:attribute>
               <xsl:attribute name="UserID">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@UserID"/>
               </xsl:attribute>
               <xsl:attribute name="Pwd">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@Pwd"/>
               </xsl:attribute>
               <xsl:attribute name="Company">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@Company"/>
               </xsl:attribute>
               <xsl:attribute name="TimeStamp">
                  <xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')"/>
               </xsl:attribute>
            </ver:MultiSpeakMsgHeader>
         </soapenv:Header>
         <soapenv:Body>
            <ver:InitiateMeterReadingsByMeterIDResponse>
               <ver:InitiateMeterReadingsByMeterIDResult>
                  <ver:errorObject>
                     <xsl:choose>
                        <xsl:when test="$customErrorMessage!=''">
                           <xsl:attribute name="objectID">
                              <xsl:value-of select="$context/objectIDs/objectId"/>
                           </xsl:attribute>
                           <xsl:attribute name="errorString">
                              <xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage)"/>
                           </xsl:attribute>
                           <xsl:attribute name="nounType"></xsl:attribute>
                           <xsl:attribute name="eventTime">
                              <xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')"/>
                           </xsl:attribute>
						   </xsl:when>
                        <xsl:otherwise>
                           <xsl:attribute name="objectID">
                              <xsl:value-of select="$context/objectIDs/objectId"/>
                           </xsl:attribute>
                           <xsl:attribute name="errorString">
                              <xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage)"/>
                           </xsl:attribute>
                           <xsl:attribute name="nounType"></xsl:attribute>
                           <xsl:attribute name="eventTime">
                              <xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')"/>
                           </xsl:attribute>
                        </xsl:otherwise>
                     </xsl:choose>
                  </ver:errorObject>
               </ver:InitiateMeterReadingsByMeterIDResult>
            </ver:InitiateMeterReadingsByMeterIDResponse>
         </soapenv:Body>
      </soapenv:Envelope>
	  <xsl:choose>
								<xsl:when test="$customErrorMessage!=''">
									<xsl:message dp:type="all" dp:priority="error">id=mread_rvr01|errorString:<xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage)"/>
										</xsl:message>
								</xsl:when>
								<xsl:otherwise>
								<xsl:message dp:type="all" dp:priority="error">id=mread_rvr01|errorString:<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage)"/>
										</xsl:message>
										</xsl:otherwise>
										</xsl:choose>
	  
   </xsl:template>
</xsl:stylesheet>