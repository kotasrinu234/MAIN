<xsl:stylesheet version="1.0"
	exclude-result-prefixes="dp dpconfig req get v1"
	extension-element-prefixes="dp dpconfig date soapenv"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release"
	xmlns:v1="http://esm.dteco.com/common/v1"
	xmlns:exslt="http://exslt.org/common"
	xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#"
	xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request"
	xmlns:ns1="http://www.multispeak.org/Version_4.1_Release"
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
		xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
	<xsl:strip-space elements="*" />




	<xsl:param name="dpconfig:messageType" select="''" />
	<xsl:param name="dpconfig:exitDescription" select="''" />
	<xsl:param name="dpconfig:entryDescription" select="''" />
	<xsl:param name="dpconfig:sourceUrl" select="''" />

	<xsl:variable name="messageType"
		select="$dpconfig:messageType" />
	<xsl:variable name="exitDescription"
		select="$dpconfig:exitDescription" />
	<xsl:variable name="entryDescription"
		select="$dpconfig:entryDescription" />
	<xsl:variable name="sourceUrl"
		select="$dpconfig:sourceUrl" />
	<xsl:variable name="correlationID"
		select="dp:generate-uuid ()" />
	<xsl:variable name="sourceEventTimestamp"
		select="date:date-time()" />

	<xsl:template match="/">

        <xsl:variable name="meterIDsString">
		<xsl:for-each select="*/*/ns1:InitiateMeterReadingsByMeterID/ns1:meterIDs/ns1:meterID">
		  <xsl:value-of select="@meterNo" />
		  <xsl:if test="position() != last()"> 
		    <xsl:text>,</xsl:text>
		  </xsl:if>
		</xsl:for-each>
		</xsl:variable>
		<dp:set-variable
			name="'var://context/ILS/meterIds'" value="$meterIDsString" />
   <!-- <xsl:message dp:type="all" dp:priority="error">MeterIDsstring ++ : <xsl:value-of select ="$meterIDsString"/></xsl:message> --> 

		<dp:set-variable
			name="'var://context/ILS/messageType'" value="$messageType" />
		<dp:set-variable
			name="'var://context/ILS/exitDescription'" value="$exitDescription" />
		<dp:set-variable
			name="'var://context/ILS/entryDescription'" value="$entryDescription" />
		<dp:set-variable name="'var://context/ILS/sourceUrl'"
			value="$sourceUrl" />
		<dp:set-variable name="'var://context/ILS/exitStatus'"
			value="'0'" />
		<dp:set-variable
			name="'var://context/ILS/correlationID'" value="$correlationID" />
		<dp:set-variable
			name="'var://context/ILS/sourceEventTimestamp'"
			value="$sourceEventTimestamp" />
		
		<!--This xslt is used to set different context variables using incoming 
			data, the context variables are used in sending success/unsuccessful acknowledgement -->
		<xsl:variable name="config"
			select="document('local://mopvr_ReceiveVoltageRead/xml/mopvr_ReceiveVoltageRead_config.xml')" />
		<xsl:variable name="queueManager"
			select="$config/config/ReceiveVoltageRead/queueManager" />
		<xsl:variable name="destQueue"
			select="$config/config/ReceiveVoltageRead/destQueue" />
		<xsl:variable name="mqmd-header"
			select="dp:request-header('MQMD')" />
		<xsl:if test="normalize-space($mqmd-header)!=''">
			<xsl:variable name="mqmdHeader"
				select="dp:parse($mqmd-header)" />
			<dp:set-variable
				name="'var://context/mopvr_ReceiveVoltageRead/mqmdheaderstore'"
				value="$mqmdHeader" />
			<dp:set-variable
				name="'var://context/mopvr_ReceiveVoltageRead/ReplyToQ'"
				value="string($mqmdHeader/MQMD/ReplyToQ)" />
		</xsl:if>

		<!--adding below response headers to surpress the reply message. As this 
			service is expected to respond back asynchronous after getting response from 
			AMI -->
		<dp:set-response-header name="'ReplyToQ'"
			value="' '" />
		<dp:set-response-header name="'ReplyToQM'"
			value="' '" />
		<xsl:variable name="IncomingtransactionID">
			<transactionID>
				<xsl:choose>
					<xsl:when
						test="*/*/ns1:InitiateMeterReadingsByMeterID/ns1:transactionID">
						<xsl:value-of
							select="*/*/ns1:InitiateMeterReadingsByMeterID/ns1:transactionID" />
						<dp:set-variable
							name="'var://context/ILS/transactionID'"
							value="string(*/*/ns1:InitiateMeterReadingsByMeterID/ns1:transactionID)" />
					</xsl:when>
					<xsl:otherwise>
<xsl:variable name='transId' select="concat('moppng-',dp:generate-uuid())" />
						<!-- <xsl:value-of select="concat('moppng-',dp:generate-uuid())"/> -->
						<xsl:value-of select="$transId" />
<dp:set-variable name="'var://context/ILS/transactionID'" value="string($transId)" />
					</xsl:otherwise>
				</xsl:choose>
			</transactionID>
		</xsl:variable>
		<xsl:variable name="Header">
			<v1:Header>
				<v1:Timestamp>
					<xsl:value-of
						select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')" />
				</v1:Timestamp>
				<v1:CorrelationID>
					<xsl:value-of
						select="$IncomingtransactionID/transactionID" />
				</v1:CorrelationID>
			</v1:Header>
		</xsl:variable>

		<xsl:variable name="MultiSpeakMsgHeader">
			<xsl:copy-of select="*/*/ns1:MultiSpeakMsgHeader" />
		</xsl:variable>
		<dp:set-variable
			name="'var://context/mopvr_ReceiveVoltageRequest/Header'"
			value="$Header" />
		<dp:set-variable
			name="'var://context/mopvr_ReceiveVoltageRead/queueManager'"
			value="$queueManager" />
		<dp:set-variable
			name="'var://context/mopvr_ReceiveVoltageRead/destQueue'"
			value="$destQueue" />
		<dp:set-variable
			name="'var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader'"
			value="$MultiSpeakMsgHeader" />

		<xsl:apply-templates select="soap:Envelope" />
	</xsl:template>

	<xsl:template match="soap:Envelope">
		<xsl:apply-templates select="soap:Header" />
		<xsl:apply-templates select="soap:Body" />
	</xsl:template>
	<xsl:template match="soap:Body">
		<xsl:apply-templates
			select="ns1:InitiateMeterReadingsByMeterID" />
	</xsl:template>

	<xsl:template match="ns1:InitiateMeterReadingsByMeterID">
		<xsl:variable name="context">
			<context>
				<objectIDs>
					<xsl:apply-templates
						select="ns1:meterIDs/ns1:meterID" />
						
				</objectIDs>
			</context>
		</xsl:variable>
		<dp:set-variable
			name="'var://context/mopvr_ReceiveVoltageRead/context'"
			value="$context" />
	</xsl:template>
    
	<xsl:template match="ns1:meterID">
		<objectId>
			<xsl:value-of select="@objectID" />
		</objectId>
	</xsl:template>
</xsl:stylesheet>	
