<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ns1 v1" extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ver="http://www.multispeak.org/Version_4.1_Release" 
xmlns:exslt="http://exslt.org/common"
xmlns:v1="http://esm.dteco.com/common/v1" xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope">
   <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
   <xsl:strip-space elements="*"/>
     <!--This stylesheet will send success Ackowledgement to OMS-->
   <xsl:template match="/">
   <xsl:choose>
   <xsl:when test="not(dp:variable('var://context/mopvr_ReceiveVoltageRead/FrontEnd'))">
      <xsl:variable name="timestamp" select="date:date-time()"/>
      <xsl:variable name="ZuluTime" select="date:add($timestamp,'PT0H')"/>
      <xsl:variable name="ms" select="substring(dp:time-value(),11,3)"/>
	    <dp:remove-http-request-header name="MQMD" />
        <dp:remove-http-request-header name="MQRFH2" />	
      <soapenv:Envelope>
         <soapenv:Header>
            <ver:MultiSpeakMsgHeader>
			  <!--Incoming MultiSpeakMsgHeader will be send back to OMS-->
               <xsl:attribute name="MajorVersion">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@MajorVersion"/>
               </xsl:attribute>
               <xsl:attribute name="MinorVersion">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@MinorVersion"/>
               </xsl:attribute>
               <xsl:attribute name="Build">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRequest/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@Build"/>
               </xsl:attribute>
               <xsl:attribute name="BuildString">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@BuildString"/>
               </xsl:attribute>
               <xsl:attribute name="UserID">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@UserID"/>
               </xsl:attribute>
               <xsl:attribute name="Pwd">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@Pwd"/>
               </xsl:attribute>
               <xsl:attribute name="Company">
                  <xsl:value-of select="dp:variable('var://context/mopvr_ReceiveVoltageRead/MultiSpeakMsgHeader')/*[local-name()='MultiSpeakMsgHeader']/@Company"/>
               </xsl:attribute>
               <xsl:attribute name="TimeStamp">
                  <xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')"/>
               </xsl:attribute>
            </ver:MultiSpeakMsgHeader>
         </soapenv:Header>
         <soapenv:Body>
		   <!--The body structure sent to OMS as acknowlegement-->
            <ver:InitiateMeterReadingsByMeterIDResponse>
               <ver:InitiateMeterReadingsByMeterIDResult/>
            </ver:InitiateMeterReadingsByMeterIDResponse>
         </soapenv:Body>
      </soapenv:Envelope>
	  </xsl:when>
	  <xsl:otherwise>
	  </xsl:otherwise>
	  </xsl:choose>
   </xsl:template>
</xsl:stylesheet>