<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1"
	extension-element-prefixes="dp" xmlns:dp="http://www.datapower.com/extensions" 
	 xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="no" />
	<xsl:strip-space elements="*" />

	  <xsl:variable name="transactionID">
	  
	  <xsl:value-of select="dp:variable('var://context/mopvr_SendVoltageRequest/Header')/*[local-name()='Header']/*[local-name()='MessageID']"/>

	  </xsl:variable>
	
	<xsl:template match="/">
		<xsl:variable name="systemErrorCode"
			select="dp:variable('var://service/error-code')" />
		<xsl:variable name="dpErrorMessage"
			select="dp:variable('var://service/error-message')" />

		<xsl:variable name="customErrorCode"
			select="dp:variable('var://context/error/customErrorCode')" />
		<xsl:variable name="customErrorMessage"
			select="dp:variable('var://context/error/customErrorMessage')" />

					<xsl:choose>
						<xsl:when test="$customErrorCode and $customErrorCode !=''">
						
							<xsl:message dp:type="all" dp:priority="error">id=mread_svr01|ErrorCode:<xsl:value-of select="$customErrorCode" /> ErrorMessage: <xsl:value-of select="concat('transactionID:',$transactionID,',',$customErrorMessage)" />
							</xsl:message>
							<dp:set-variable name="'var://context/ILS/CustomMQErrorMsg'" value="concat('id=mread_svr01|ErrorCode:',$customErrorCode,' ErrorMessage: ','transactionID:',$transactionID,',',$customErrorMessage)"/>
						</xsl:when>
						<xsl:otherwise>
							<xsl:message dp:type="all" dp:priority="error">id=mread_svr01|ErrorCode:<xsl:value-of select="$systemErrorCode" /> ErrorMessage: <xsl:value-of select="concat('transactionID:',$transactionID,',',$dpErrorMessage)" />
								</xsl:message>
								<dp:set-variable name="'var://context/ILS/CustomMQErrorMsg'" value="concat('id=mread_svr01|ErrorCode:',$systemErrorCode,' ErrorMessage: ','transactionID:',$transactionID,',',$dpErrorMessage)"/>
						</xsl:otherwise>
					</xsl:choose>
		
	</xsl:template>
</xsl:stylesheet>
