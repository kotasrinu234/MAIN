<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver v1 "
	extension-element-prefixes="dp date"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:dp="http://www.datapower.com/extensions">
    <xsl:output method="xml" version="1.0" encoding="UTF-8"	indent="yes" />
    <xsl:strip-space elements="*" />
	 <xsl:template match="/">
	<xsl:variable name="singlephasepayload" select="dp:variable('var://context/ILS/checksinglePhaseRequest')" />
	<xsl:copy-of select="$singlephasepayload"/>
	</xsl:template>
	</xsl:stylesheet>
