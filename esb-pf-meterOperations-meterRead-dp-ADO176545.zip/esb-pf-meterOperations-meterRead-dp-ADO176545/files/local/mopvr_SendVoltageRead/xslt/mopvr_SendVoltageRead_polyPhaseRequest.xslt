<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver v1 "
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
	xmlns:ns1="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1"
	xmlns:ns2="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request"
	xmlns:ns3="http://interrogatebyendpoints.esm.dteco.com/v1/request"
	xmlns="http://esm.dteco.com/common/v1" xmlns:dpconfig="http://www.datapower.com/param/config" 
	xmlns:exslt="http://exslt.org/common" 
	xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
<xsl:output method="xml" version="1.0" encoding="UTF-8"	indent="yes" />
<xsl:strip-space elements="*" />
<xsl:param name="dpconfig:amiUrl" select="''" />
<xsl:param name="dpconfig:backendUri" select="''" />
<xsl:variable name="amiUrl" select="$dpconfig:amiUrl" />
<xsl:variable name="backendUri" select="$dpconfig:backendUri" />
<xsl:variable name="pphase" select="dp:variable('var://context/mread/polyPhaseMeterIdsStr')" />
<xsl:variable name="sphase" select="dp:variable('var://context/mread/singlePhaseMeterIdsStr')" />
<!-- 	<dp:set-variable name = "'var://context/mread/pphaselength'" value = "string-length($pphase)"/>
-->	
 
		<xsl:variable name="environmentSpecificProperties">
<xsl:copy-of select="document('local:///mopvr_SendVoltageRead/xml/EnvironmentSpecific.xml')"/>
</xsl:variable>
<xsl:variable select="concat('https://',$amiUrl,':',$backendUri)" name="target-url"/>
<xsl:template match="/">
<!-- <dp:set-http-request-header name="'Authorization'" value="dp:variable('var://context/mopvr_SendVoltageRead/authorization')"/> -->
<dp:set-http-request-header name="'SOAPAction'" value="$environmentSpecificProperties/EnvironmentSpecific/AMISOAPAction/text()"/>		
 
<dp:remove-http-request-header name="MQMD" />
<dp:remove-http-request-header name="MQRFH2" />
 
<xsl:variable name = "amirequest">
<soapenv:Envelope>
<soapenv:Body>
<!--<xsl:apply-templates select="soap:Envelope/soap:Body/ns1:InitiateMeterReadingsByMeterID"/> -->
<req:InterrogateByEndpointsRequest>
<xsl:copy-of select="dp:variable('var://context/mopvr_SendVoltageRequest/Header')"/>
<req:Payload>
<xsl:copy-of select="MeterIds/polyPhase/child::*" />
 
            <!-- <xsl:copy-of select="$parsedXml/meterIds"/>
 
 
							<xsl:for-each select="exslt:node-set($polyPhaseXMLStr)/meterIds/meterId">
<dp:set-variable name= "'var://context/mread/test6'" value ="'test6'" />
<xsl:call-template name="polyPhase">
<dp:set-variable name= "'var://context/mread/test5'" value ="'test5'" />
<xsl:with-param name="meterId" select="." />
</xsl:call-template>
</xsl:for-each> -->
<ns2:ReadingType>
<ns2:name>POLYPHASE</ns2:name>
</ns2:ReadingType>
</req:Payload>			
</req:InterrogateByEndpointsRequest>
</soapenv:Body>
</soapenv:Envelope>
</xsl:variable>
<xsl:variable name="result">
 
<xsl:if test = "not(normalize-space($pphase)='')">
<dp:url-open target="{$target-url}" response="responsecode" ssl-proxy="client:mopvr_SendVoltageRead_ClientProfile">
 
<xsl:copy-of select="$amirequest"/>
 
 
</dp:url-open>
</xsl:if>
 
</xsl:variable>
<xsl:if test = "(normalize-space($sphase)='')">
<dp:set-variable name = "'var://service/mpgw/skip-backside'" value = '1'/>
<!--<xsl:copy-of select = '$result/url-open/response' /> -->
<dp:set-variable name = "'var://context/mread/uor'" value = '$result/url-open/response'/>
</xsl:if>
 
<xsl:if test = "not(normalize-space($pphase)='')">
<xsl:variable name="responseCode">
<xsl:value-of select="$result/url-open/responsecode" />
</xsl:variable>
 
<xsl:choose>
<xsl:when test="$responseCode='200'">
<xsl:copy-of select="$amirequest"/>
</xsl:when>
<xsl:otherwise>
 
<xsl:choose>
<xsl:when test="contains($result/url-open/response, 'The mRID element in the provided EndDeviceAsset object was duplicated.')">
        <!-- Do NOT reject — you can log and continue -->
        <xsl:message dp:type="all" dp:priority="warn">
          Warning: Duplicate mRID found in EndDeviceAsset continuing without rejection.
        </xsl:message>
        <!-- You could optionally set a context variable if needed -->
        <dp:set-variable name="'var://context/mread/duplicateMRIDWarning'" value="'true'"/>
      </xsl:when>
<xsl:when test="string-length(normalize-space($responseCode))&gt; 0">
<dp:reject> <xsl:value-of select="$result/url-open/response"/>	</dp:reject>			
</xsl:when>
<xsl:otherwise>
<xsl:variable name="errorstatuscode">
<xsl:value-of select="$result/url-open/statuscode" />
</xsl:variable>
<xsl:variable name="errorstring">
<xsl:value-of select="$result/url-open/errorstring" />
</xsl:variable>
 
 
<dp:set-variable name="'var://context/ILS/CustomMQErrorMsg'" value="concat('API Call Response failed with error code ', $errorstatuscode,'and with error string as',$errorstring,' for target url',$target-url)" />
<xsl:message dp:type="all" dp:priority="error">API Call Response failed  with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></xsl:message>
<dp:reject>API Call Response  with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></dp:reject>
</xsl:otherwise>			   
</xsl:choose>
</xsl:otherwise>			
</xsl:choose>	
</xsl:if>	
</xsl:template>
 
	<xsl:template name="polyPhase">
<xsl:param name="meterId" />
<ns2:EndDeviceAsset>
<ns2:mRID>
<xsl:value-of select="$meterId" />
</ns2:mRID>
</ns2:EndDeviceAsset>
</xsl:template> 
</xsl:stylesheet>

