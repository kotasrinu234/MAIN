<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:v1="http://esm.dteco.com/common/v1" xmlns:ns1="http://www.multispeak.org/Version_4.1_Release" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request" xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" version="1.0" exclude-result-prefixes="dp ver" extension-element-prefixes="dp date soap">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" omit-xml-declaration="no"/>
<xsl:strip-space elements="*"/>
<xsl:param name="dpconfig:messageType" select="''"/>
<xsl:param name="dpconfig:exitDescription" select="''"/>
<xsl:param name="dpconfig:entryDescription" select="''"/>
<xsl:param name="dpconfig:exitDestination" select="''"/>
<xsl:param name="dpconfig:phaseUrl" select="''"/>
<xsl:param name="dpconfig:phasePort" select="''"/>
<xsl:param name="dpconfig:GetMeterInfoService" select="''"/>
<xsl:variable name="messageType" select="$dpconfig:messageType"/>
<xsl:variable name="exitDescription" select="$dpconfig:exitDescription"/>
<xsl:variable name="entryDescription" select="$dpconfig:entryDescription"/>
<xsl:variable name="exitDestination" select="$dpconfig:exitDestination"/>
<xsl:variable name="correlationID" select="dp:generate-uuid ()"/>
<xsl:variable name="sourceEventTimestamp" select="date:date-time()"/>
<xsl:variable name="phaseUrl" select="$dpconfig:phaseUrl"/>
<xsl:variable name="phasePort" select="$dpconfig:phasePort"/>
<xsl:variable name="GetMeterInfoService" select="$dpconfig:GetMeterInfoService"/>
<!--   http://esb{env}.serv.dteco.com:1223/GetMeterInfo/v1?messageID=ÃƒÂ¢Ã¢â€šÂ¬Ã‚ÂABEFÃƒÂ¢Ã¢â€šÂ¬Ã‚Â,meterID=12345,recentVoltageNeeded=ÃƒÂ¢Ã¢â€šÂ¬Ã‚ÂNÃƒÂ¢Ã¢â€šÂ¬Ã‚Â
   -->
<xsl:variable name="AIM_Header" select="document('local:///mopvr_SendVoltageRead/xml/mopvr_SendVoltageRead_header_configuration.xml')"/>
<xsl:variable name="Env_Specific" select="document('local:/mopvr_SendVoltageRead/xml/EnvironmentSpecific.xml')"/>
<xsl:template match="req:InterrogateByEndpointsRequest">
<xsl:variable name="mRIDList">
<xsl:for-each select="req:Payload/get:EndDeviceAsset/get:mRID">
<xsl:value-of select="."/>
<xsl:if test="position() != last()"> ; </xsl:if>
</xsl:for-each>
</xsl:variable>
<xsl:variable name="correlationID" select="v1:Header/v1:CorrelationID"/>
<dp:set-variable name="'var://context/ILS/transactionID'" value="$correlationID"/>
<dp:set-variable name="'var://context/ILS/meterIds'" value="$mRIDList"/>
</xsl:template>
<xsl:template match="ns1:InitiateMeterReadingsByMeterID">
<dp:set-variable name="'var://context/mread/meterIdList'" value="''"/>
<xsl:variable name="transId" select="ns1:transactionID"/>
<dp:set-variable name="'var://context/mread/transId'" value="$transId"/>
<xsl:variable name="meterIDsString">
<xsl:for-each select="ns1:meterIDs/ns1:meterID">
<dp:set-variable name="'var://context/mread/test'" value="'one'"/>
<!--   <dp:set-variable name = "'var://context/mread/meterIdList'" value ="concat(dp:variable('var://context/mread/meterIdList'),'http://', $phaseUrl,':',$phasePort,'/GetMeterInfo/v1?messageID&#61;',$transId,'&amp;meterID&#61;',@meterNo ,'&amp;recentVoltageNeeded&#61;N','_',@meterNo, ',')" />   -->
<dp:set-variable name="'var://context/mread/meterIdList'" value="concat(dp:variable('var://context/mread/meterIdList'),$GetMeterInfoService,'_',string(@meterNo), ',')"/>
<xsl:value-of select="string(@meterNo)"/>
<dp:set-variable name="'var://context/mread/test2'" value="string(@meterNo)"/>
<xsl:if test="position() != last()">
<xsl:text>,</xsl:text>
</xsl:if>
</xsl:for-each>
</xsl:variable>
<dp:set-variable name="'var://context/ILS/meterIds'" value="string($meterIDsString)"/>
<dp:set-variable name="'var://context/ILS/messageType'" value="$messageType"/>
<dp:set-variable name="'var://context/ILS/exitDescription'" value="$exitDescription"/>
<dp:set-variable name="'var://context/ILS/entryDescription'" value="$entryDescription"/>
<dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'"/>
<dp:set-variable name="'var://context/ILS/exitDestination'" value="$exitDestination"/>
<dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID"/>
<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$sourceEventTimestamp"/>
<!--  This xslt is used to set different context variables using incoming 
			data, the context variables are used in request processing   -->
<xsl:variable name="timestamp" select="date:date-time()"/>
<xsl:variable name="ZuluTime" select="date:add($timestamp,'PT0H')"/>
<xsl:variable name="ms" select="substring(dp:time-value(),11,3)"/>
<xsl:variable name="entriesMQMD" select="dp:request-header('MQMD')"/>
<xsl:variable name="entriesMQRFH2" select="dp:request-header('MQRFH2')"/>
<!--  Extraction of username and password sent to AMI   -->
<!--   <xsl:variable name="username" select="$Env_Specific/EnvironmentSpecific/backend_Credentials/userID"/> 
			<xsl:variable name="password" select="$Env_Specific/EnvironmentSpecific/backend_Credentials/password" 
			/> <xsl:variable name="userpass" select="concat($username,':',$password)" 
			/> <xsl:variable name="encodedUserpass" select="dp:encode($userpass,'base-64')"/> 
			<xsl:variable name="Authorization" select="concat('Basic ',$encodedUserpass)" 
			/> <dp:set-variable name="'var://context/mopvr_SendVoltageRead/authorization'" 
			value="normalize-space($Authorization)" />   -->
<!--  Parsing the string MQMD headers to XML format   -->
<!--   <xsl:if test="normalize-space($entriesMQMD !='')">   -->
<xsl:variable name="mqmd-headers" select="dp:parse($entriesMQMD)"/>
<!--   </xsl:if>   -->
<!--   <xsl:if test="normalize-space($entriesMQRFH2 !='')">   -->
<xsl:variable name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)"/>
<!--   </xsl:if>   -->
<xsl:message dp:priority="debug">
<xsl:value-of select="concat('The Request MQMD : ', $entriesMQMD)"/>
</xsl:message>
<xsl:message dp:priority="debug">
<xsl:value-of select="concat('The Request MQRFH2 : ', $entriesMQRFH2)"/>
</xsl:message>
<!--  Placing the MQMD headers in the context variables   -->
<dp:set-variable name="'var://context/MQMD/MQMDRequestHeaders'" value="$mqmd-headers"/>
<dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value="$mqrfh2-headers"/>
<!--   <dp:set-http-request-header name="'Authorization'" value="dp:variable('var://context/mopvr_SendVoltageRead/authorization')"/>   -->
<xsl:variable name="objectID">
<objectID>
<xsl:apply-templates select="ns1:meterIDs/ns1:meterID/@objectID"/>
</objectID>
</xsl:variable>
<dp:set-variable name="'var://context/mopvr_SendVoltageRequest/objectID'" value="$objectID"/>
<xsl:variable name="IncomingtransactionID">
<transactionID>
<xsl:if test="$mqrfh2-headers/MQRFH2/NameValueData/NameValue/usr/FrontEnd">
<dp:set-variable name="'var://context/mopvr_SendVoltageRead/FrontEnd'" value="'MQ'"/>
<xsl:choose>
<xsl:when test="ns1:transactionID !=''">
<xsl:value-of select="concat('mopvr-mq:',ns1:transactionID, ':RQ:', $mqrfh2-headers/MQRFH2//RQ)"/>
<dp:set-variable name="'var://context/ILS/transactionID'" value="string(ns1:transactionID)"/>
</xsl:when>
<xsl:otherwise>
<xsl:variable name="transId" select="concat('mopvr-mq-uuid:',dp:generate-uuid(), ':RQ:', $mqrfh2-headers/MQRFH2//RQ)"/>
<xsl:value-of select="$transId"/>
<dp:set-variable name="'var://context/ILS/transactionID'" value="string($transId)"/>
</xsl:otherwise>
</xsl:choose>
</xsl:if>
<xsl:if test="not($mqrfh2-headers/MQRFH2/NameValueData/NameValue/usr/FrontEnd)">
<xsl:choose>
<xsl:when test="ns1:transactionID !=''">
<xsl:value-of select="concat('mopvr:',ns1:transactionID)"/>
<dp:set-variable name="'var://context/ILS/transactionID'" value="string(ns1:transactionID)"/>
</xsl:when>
<xsl:otherwise>
<xsl:value-of select="concat('mopvr:',dp:generate-uuid())"/>
<dp:set-variable name="'var://context/ILS/transactionID'" value="string(ns1:transactionID)"/>
</xsl:otherwise>
</xsl:choose>
</xsl:if>
</transactionID>
</xsl:variable>
<xsl:variable name="Header">
<v1:Header>
<v1:Verb>
<xsl:value-of select="$AIM_Header/config/Header/Verb"/>
</v1:Verb>
<v1:Noun>
<xsl:value-of select="$AIM_Header/config/Header/Noun"/>
</v1:Noun>
<v1:Timestamp>
<xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')"/>
</v1:Timestamp>
<v1:Source>
<xsl:value-of select="$AIM_Header/config/Header/Source"/>
</v1:Source>
<v1:ReplyAddress>
<xsl:value-of select="$AIM_Header/config/Header/ReplyAddress"/>
</v1:ReplyAddress>
<v1:AckRequired>
<xsl:value-of select="$AIM_Header/config/Header/AckRequired"/>
</v1:AckRequired>
<v1:MessageID>
<xsl:value-of select="dp:generate-uuid()"/>
</v1:MessageID>
<v1:CorrelationID>
<xsl:value-of select="$IncomingtransactionID/transactionID"/>
</v1:CorrelationID>
</v1:Header>
</xsl:variable>
<dp:set-variable name="'var://context/mopvr_SendVoltageRequest/Header'" value="$Header"/>
</xsl:template>
</xsl:stylesheet>
