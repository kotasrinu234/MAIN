<xsl:stylesheet version="1.0"
 xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
 xmlns:dp="http://www.datapower.com/extensions"
 xmlns:dpconfig="http://www.datapower.com/param/config"	
 xmlns:ns2="http://iec.ch/TC57/2009/GetMeterReadings#"
exclude-result-prefixes="dp dpconfig">
 <xsl:output omit-xml-declaration="yes" indent="yes"/>
 <xsl:strip-space elements="*"/>

<xsl:template match="/">
	<xsl:variable name = "singlePhaseCSV">
		<input>
			<xsl:value-of  select ="dp:variable('var://context/mread/singlePhaseMeterIdsStr')" />
<!-- <xsl:value-of  select ="'abc,def'" /> -->		
	</input>
	</xsl:variable>
	<xsl:variable name = "polyPhaseCSV">
		<input>
<xsl:value-of  select ="dp:variable('var://context/mread/polyPhaseMeterIdsStr')" />
			<!-- <xsl:value-of  select ="'ghi,jkl'" /> -->

		</input>
	</xsl:variable>	
 <MeterIds>
 <singlePhase>
    <xsl:apply-templates select ="$singlePhaseCSV/input"/>
  </singlePhase>
 <polyPhase>
    <xsl:apply-templates select ="$polyPhaseCSV/input"/>
  </polyPhase>
</MeterIds>
</xsl:template>

 <xsl:template match="text()" name="split">
  <xsl:param name="pText" select="."/>
  <xsl:param name="pItemElementName" select="'ns2:mRID'"/>

    <xsl:if test="string-length($pText) > 0">
     <xsl:variable name="vNextItem" select=
      "substring-before(concat($pText, ','), ',')"/>
	<ns2:EndDeviceAsset>
		  <xsl:element name="{$pItemElementName}">
			<xsl:value-of select="$vNextItem"/>
		  </xsl:element>
	</ns2:EndDeviceAsset>
                 

      <xsl:call-template name="split">
        <xsl:with-param name="pText" select=
                       "substring-after($pText, ',')"/>
        <xsl:with-param name="pItemElementName" select="$pItemElementName"/>
        
      </xsl:call-template>
    </xsl:if>
 </xsl:template>
</xsl:stylesheet>
