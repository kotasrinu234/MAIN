<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver v1 "
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
	xmlns:exslt="http://exslt.org/common"
	xmlns:ns1="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1"
	xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request"
	xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
		
	<xsl:strip-space elements="*" />

		<xsl:variable name="environmentSpecificProperties">
		<xsl:copy-of select="document('local:///mopvr_SendVoltageRead/xml/EnvironmentSpecific.xml')"/>
	</xsl:variable>
	
	<xsl:variable name="sphase" select="dp:variable('var://context/mread/singlePhaseMeterIdsStr')" />
	
	
   <xsl:template match="/">
   	<!-- <dp:set-http-request-header name="'Authorization'" value="dp:variable('var://context/mopvr_SendVoltageRead/authorization')"/> -->
	
	<xsl:if test = "not(normalize-space($sphase)='')">
   	<dp:set-http-request-header name="'SOAPAction'" value="$environmentSpecificProperties/EnvironmentSpecific/AMISOAPAction/text()"/>		
	<xsl:variable name="singlePhaseXMLStr" select="dp:variable('singlePhaseMeterIdsXMLStr')" />

<dp:remove-http-request-header name="MQMD" />
<dp:remove-http-request-header name="MQRFH2" />
<xsl:variable name="singlePhaseRequest">
		<soapenv:Envelope>
			<soapenv:Body>
				<!--<xsl:apply-templates select="soap:Envelope/soap:Body/ns1:InitiateMeterReadingsByMeterID"/> -->
				<req:InterrogateByEndpointsRequest>
				  <xsl:copy-of select="dp:variable('var://context/mopvr_SendVoltageRequest/Header')"/>
					<req:Payload>
						 <xsl:copy-of select="MeterIds/singlePhase/child::*" />

					<!-- 		<xsl:for-each select="exslt:node-set($singlePhaseMeterIdsXMLStr)/meterIds/meterId">
									<xsl:call-template name="singlePhase">
										<xsl:with-param name="meterId" select="." />
									</xsl:call-template>
							</xsl:for-each>
 -->				</req:Payload>
				</req:InterrogateByEndpointsRequest>
			</soapenv:Body>
		</soapenv:Envelope>
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/checksinglePhaseRequest'" value="$singlePhaseRequest"/>
			<xsl:copy-of select="$singlePhaseRequest"/>	
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>
