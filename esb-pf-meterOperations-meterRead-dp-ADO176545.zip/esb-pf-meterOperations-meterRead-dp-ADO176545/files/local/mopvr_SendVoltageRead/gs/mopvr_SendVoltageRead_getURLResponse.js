var ctx = session.name("mread") || session.createContext("mread");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });


var ILSctx = session.name('ILS') || session.createContext('ILS');
function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}

function callURL(url, method, myctx) {
	var options = {
		target: url+'?messageID='+uuidv4()+'&meterID='+myctx+'&recentVoltageNeeded=N',
		method: method,
		/* headers: {
			'Authorization': Auth
		}, */
		contentType: "application/json",
		/* sslClientProfile: "FSE_Client_Profile" */
	};
	

	var info = " TargetURL :" + options.target + "; Method :" + options.method ;
try{
	urlopen.open(options, function(error, response) {
		if (error) {
			var ctx = session.name("mread") || session.createContext("mread");
			// an error occurred during reading the file
			var errorinfo = "urlopen error of 'callURL', details are : " + info + "; error info :" + error
			logger.error(errorinfo);
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo)
			ctx.setVariable("customErrorCode", '500');
			ctx.setVariable("customErrorMessage", errorinfo);
			//throw error;
		} else {
			var responseStatusCode = response.statusCode;
			var ctx = session.name("mread") || session.createContext("mread");
			ctx.setVariable(myctx + "_responseStatusCode", responseStatusCode);
			ctx.setVariable(myctx + "_response", response);

			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, data) {
					if (error) {
						var errorinfo = "Error in reading 'callURL' response data, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ExitDescription', responseStatusCode)
						ctx.setVariable("customErrorCode", '500');
						ctx.setVariable("customErrorMessage", errorinfo)
						logger.error(errorinfo);
						logger.error("Error in reading response data");
						throw error;
					} else {
						

 try {
	var data= JSON.parse(data)
 					var ctx = session.name("mread") || session.createContext("mread");
					ctx.setVariable(myctx + '_response', data);
}catch (e) {
       var ctx = session.name("mread") || session.createContext("mread");
	ctx.setVariable(myctx + '_response', JSON.stringify(data));	
    }
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "failure in reading message 'callURL', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						ctx.setVariable("customErrorCode", '500');
						ctx.setVariable("customErrorMessage", errorinfo);
						logger.error(errorinfo);
					} else {
						var ctx = session.name("mread") || session.createContext("mread");
						ctx.setVariable(myctx + '_buffer_response', "" + responseData);
						logger.error("response received with responseStatusCode " + responseStatusCode + " " + responseData);
						var responseDataStr = "" + responseData;
						ctx.setVariable(myctx + '_buffer_response2', responseDataStr);
						if (responseStatusCode == 400 && responseDataStr !== 'No updates') {
							var responseinfo = "Bad Request response received from callURL, details are : " + info + "; response info :" + responseDataStr + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', responseinfo)
							ctx.setVariable("customErrorCode", '400');
							ctx.setVariable("customErrorMessage", responseinfo);
							ctx.setVariable("customReasonMessage", 'Bad Request');
							session.reject("Bad Request");
						}
					}
				});


				if (responseStatusCode == 403) {
					var responseinfo = "ffs_011:Forbidden response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', responseinfo)
					ctx.setVariable("customErrorCode", '403');
					ctx.setVariable("customErrorMessage", responseinfo);
					ctx.setVariable("customReasonMessage", 'Forbidden');
					session.reject("Forbidden");
				} else if (responseStatusCode == 401) {
					var responseinfo = "ffs_012:Unauthorized response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', responseinfo)
					ctx.setVariable("customErrorCode", '401');
					ctx.setVariable("customErrorMessage", responseinfo);
					ctx.setVariable("customReasonMessage", 'Unauthorized');
					session.reject("Unauthorized");
				} else if (responseStatusCode == 404) {
					var responseinfo = "No Records Found response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', responseinfo)
					ctx.setVariable("customErrorCode", '404');
					ctx.setVariable("customErrorMessage", responseinfo);
					ctx.setVariable("customReasonMessage", 'No Records Found');
					session.reject("No Records Found");
				} else if (responseStatusCode == 500) {
					var responseinfo = "Server Error response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', responseinfo)
					ctx.setVariable("customErrorCode", '500');
					ctx.setVariable("customErrorMessage", responseinfo);
					ctx.setVariable("customReasonMessage", 'Server Error');
					
					// session.reject("Server Error");
				}
			}
		}
	});
} catch (error) {
	var errorinfo = "URL connection error with 'getMeterInfo', details: " + info + "; Error: " + error;
	ILSctx.setVariable('ExitStatus', '500');
	ILSctx.setVariable('Exitdescription', errorinfo);
	logger.error(errorinfo);
}	
}
module.exports = callURL;
