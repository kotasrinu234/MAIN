	var ils = session.name("ILS") || session.createContext("ILS");
	var ctx = session.name("mread") || session.createContext("mread");

	var meterIds = ils.getVariable('meterIds');

	var meterIdArr = meterIds.split(',');
	ctx.setVariable('meterIdArr', meterIdArr);

	var polyPhaseArr = new Array();
	var singlePhaseArr = new Array();

	for(var i=0; i< meterIdArr.length; i++){

	var obj = ctx.getVariable(meterIdArr[i]+"_response");
		if(!(obj == undefined)){
			if(obj.meterPhase == 'POLYPHASE'){
	
	  polyPhaseArr.push(meterIdArr[i]);	
	}
	else {
	singlePhaseArr.push(meterIdArr[i]);
}
			
		}else {
	singlePhaseArr.push(meterIdArr[i]);
}
	
	}
	var polyPhaseStr = polyPhaseArr.join(",");
	var singlePhaseStr = singlePhaseArr.join(",");

	ctx.setVariable('singlePhaseMeterIdsStr', singlePhaseStr);
	ctx.setVariable('polyPhaseMeterIdsStr', polyPhaseStr);
