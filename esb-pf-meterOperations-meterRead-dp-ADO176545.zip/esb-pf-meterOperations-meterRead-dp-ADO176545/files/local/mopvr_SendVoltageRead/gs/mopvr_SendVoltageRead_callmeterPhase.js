var ctx = session.name("mread") || session.createContext("mread");
var urlopen = require('urlopen');
var callURL = require('./mopvr_SendVoltageRead_getURLResponse.js');

var logger = console.options({ 'category': 'all' });

var urlListString = ctx.getVariable('meterIdList');
var urlEntries = urlListString.split(',');

for(var i=0; i< urlEntries.length-1; i++){
	var urlEntry = urlEntries[i].split("_");
	var url = urlEntry[0];
	var meterId = urlEntry[1];
		callURL(url,'GET',meterId);
}
