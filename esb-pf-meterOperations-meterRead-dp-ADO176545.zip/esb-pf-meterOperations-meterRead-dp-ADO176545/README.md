## esb-pf-meterOperations-meterRead-dp

Deployment instructions

============================
1.	Creation of queues 
Please refer to location GIT repository: 
dteenergy/esb-pf-meterOperations-meterRead-mq/DP-MQcommands.txt

2.	Upload of certificates in Datapower in MeterOperations{env} domain (File Management->cert directory). DTE ESB team will share the cert.

3.	Creation of password alias map in Datapower in MeterOperations{env} domain.

4.	Jenkins pipeline: 

INT : esb-pf-meterOperations-meterRead-dp-int
ST  : esb-pf-meterOperations-meterRead-dp-st
ACC : TBC
============================
