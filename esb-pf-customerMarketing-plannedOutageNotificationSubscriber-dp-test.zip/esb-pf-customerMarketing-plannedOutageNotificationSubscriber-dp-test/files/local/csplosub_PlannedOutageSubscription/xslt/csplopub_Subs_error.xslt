<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

<xsl:variable name="TransactionID">
	<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
			
</xsl:variable>
<xsl:variable name="test">
      <xsl:value-of select="dp:http-response-header('x-dp-response-code')"/>
</xsl:variable>


<xsl:variable name="url">
<xsl:value-of select="dp:variable('var://service/routing-url')"/>
</xsl:variable>

<xsl:if test= "contains($test,'401' )">

<xsl:message dp:type="all" dp:priority="error">csplosub_004 TransactionID:<xsl:value-of select="$TransactionID"/> Errormessage: <xsl:value-of select="$test"/> when connection to url <xsl:value-of select="$url"/>
</xsl:message>
</xsl:if>

<xsl:choose>
<xsl:when test="contains(dp:variable('var://service/error-message'),'Failed to establish a backside connection' )">

<xsl:message dp:type="all" dp:priority="error">csplosub_004 TransactionID:<xsl:value-of select="$TransactionID"/> Errormessage: <xsl:value-of select="dp:variable('var://service/error-message')"/> when connection to url <xsl:value-of select="$url"/></xsl:message>
</xsl:when>
</xsl:choose>		
	</xsl:template>
</xsl:stylesheet>
