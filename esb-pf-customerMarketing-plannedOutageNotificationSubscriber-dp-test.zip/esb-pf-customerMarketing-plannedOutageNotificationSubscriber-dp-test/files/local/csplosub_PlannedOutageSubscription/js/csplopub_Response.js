var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
    'category': 'all'
});
var p = 0;
var TokenValue = session.parameters.TokenValue;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
    	
    	var level;
    	var incominglevel = incomingdata.response.level;
    	
    	if(incominglevel == 'S'){
    		level = 'Success';
    	}else if(incominglevel == 'E'){
    		level = 'Error';
    	}else if(incominglevel == 'W'){
    		level = 'Warning';
    	}else if(incominglevel == 'I'){
    		level = 'Info';
    	}
    	
    	var payload1 = {
    			
    			"response": {
    			      "level": level,
    			      "_class": incomingdata.response._class,
    			      "code": incomingdata.response.code,
    			      "details": incomingdata.response.details
    			    }
    	}
    	
    	var payload = JSON.stringify(payload1);
        var ctx = session.name("plopub")|| session.createContext("plopub");
        ctx.setVariable("CRB_Response_payload", payload);
    	session.output.write(payload);
    	logger.debug("response payload from CR&B is " +payload);
    	if(incominglevel == 'E'){
    	logger.error("csplosub_003 response payload from CR&B is " +payload);
    		
    }
    }
});

  
