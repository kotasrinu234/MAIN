//js is used to perform nullcheck for the input request
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var ctx = session.name("plopub")|| session.createContext("plopub");
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
		if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		
		var payload = incomingdata;
		ctx.setVariable("CRB_IncomingData", payload);
	    	headers.remove('MQMD');
	        session.output.write(payload);
	}
	});
