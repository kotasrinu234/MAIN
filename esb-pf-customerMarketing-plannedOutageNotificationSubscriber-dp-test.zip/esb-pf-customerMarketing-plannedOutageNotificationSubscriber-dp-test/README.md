# esb-pf-customerMarketing-plannedOutageNotificationSubscriber-dp
plannedOutageNotificationSubscriber
Interface 43 plannedOutageNotificationSubscriber Deployment instructions:

Standlaone MQ scripts are uploaded in dteenergy/esb-pf-customerMarketing-plannedOutageNotificationSubscriber-mq repository. 

MQCSP details will be given by DTE ESB team.

Password aliases will be created by DTE ESB team.

Private keys and certs need to be provided by DTE ESB team.

Properties file as per env are in the config folder of this repository.

Jenkins file as per env are also uploaded in this repository.
