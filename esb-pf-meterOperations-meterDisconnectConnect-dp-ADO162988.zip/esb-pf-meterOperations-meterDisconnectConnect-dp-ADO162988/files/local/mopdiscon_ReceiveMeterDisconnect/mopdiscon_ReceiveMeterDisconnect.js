var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var apiToken = ctx.getVariable("apiToken");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var lookupURL = ctx.getVariable("lookupURL");
var targetQueue = session.parameters.queueName;
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		// uncatched error will stop the processing and the error will be logged
		var errorinfo = "mopdiscon_001 Error in reading incoming data , error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("mopdiscon_001 Error in reading incoming data");
		session.reject("Error in reading incoming data")
	} else {
		/* validation of input data*/
		var nullcheck = session.parameters.nullcheck;
		if (nullcheck == 'yes') {
			var leadCall = json.data[0].leadCall;
			var id = json.data[0].id;
			var status = json.data[0].status;
			if (leadCall === null || leadCall === '' || leadCall === undefined) {
				var errorinfo = "mopdiscon_002 leadCall not found.";
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("mopdiscon_002 leadCall not found.");
				session.reject('leadCall not found.');
			} else {
				var premiseID = json.data[0].leadCall.premiseID;
				if (premiseID === null || premiseID === '' || premiseID === undefined) {
					var errorinfo = "mopdiscon_003 premiseID not found.";
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error("mopdiscon_003 premiseID not found.");
					session.reject('premiseID not found.');
				}
				logger.debug("premiseID" + premiseID);
			}
			var jobTypeID = json.data[0].jobTypeID;
			if (jobTypeID === null || jobTypeID === '' || jobTypeID === undefined) {
				var errorinfo = "mopdiscon_004 jobTypeID not found.";
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("mopdiscon_004 jobTypeID not found.");
				session.reject('jobTypeID not found.');
			} else {
				ctx.setVariable("jobTypeID", jobTypeID);
			}
			var meterId = json.data[0].leadCall.meterID;
			if (meterId === null || meterId === '' || meterId === undefined) {
				var errorinfo = "mopdiscon_044 meterId not found.";
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("mopdiscon_044 meterId not found.");
				session.reject('meterId not found.');
			} else {
				ctx.setVariable("meterId", meterId);
			}
		}
		var PremiseUri = omsExternalURL + '/api/v1/ServiceType/Electric/Premise/' + premiseID;
		var PremiseGetApi = {
			target: PremiseUri,
			sslClientProfile: 'mopdiscon_SSL_Client_Profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
		};
		var info = " TargetURL :" + PremiseGetApi.target + "; Method :" + PremiseGetApi.method;
		try {
			urlopen.open(PremiseGetApi, function(error, response) {
				if (error) {
					var errorinfo = "mopdiscon_005 urlopen connect error with Get PremiseGetApi for premiseID " + premiseID + " , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("exitStatus", '500');
					logger.error("mopdiscon_005 urlopen connect error with Get PremiseGetApi for premiseID " + premiseID + " with error as " + JSON.stringify(error));
					session.reject("urlopen connect error with Get PremiseGetApi for premiseID " + premiseID + " with error as " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message from PremiseGetApi , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("exitStatus", '500');
								logger.error("failure in reading message from PremiseGetApi" + JSON.stringify(error));
								session.reject(" failure in reading message from PremiseGetApi" + JSON.stringify(error));
							} else {
								ctx.setVariable("PremiseResponse", responseData);
								var premiseServiceType = responseData.premiseServiceType;
								var customer = responseData.customer;
								if (premiseServiceType === null || premiseServiceType === '' || premiseServiceType === undefined) {
									var Flag = 'True';
								} else {
									var customFieldValuesExt = premiseServiceType.customFieldValuesExt;
									if (customFieldValuesExt === null || customFieldValuesExt === '' || customFieldValuesExt === undefined) {
										var Flag = 'True';
									} else {
										var AMI_Enabled = customFieldValuesExt.ami_enabled;
										if (AMI_Enabled === null || AMI_Enabled === '' || AMI_Enabled === undefined) {
											var Flag = 'True';
										} else {
											var UP_AMI_Enabled = AMI_Enabled.toUpperCase();
											var Flag = 'False';
											ctx.setVariable("AMI_Enabled", AMI_Enabled);
										}
									}
								}
								if (customer === null || customer === '' || customer === undefined) {
									var Flag = 'True';
								} else {
									var customFieldValuesExt = customer.customFieldValuesExt;
									if (customFieldValuesExt === null || customFieldValuesExt === '' || customFieldValuesExt === undefined) {
										var Flag = 'True';
									} else {
										var Ami_Opt_Out = customFieldValuesExt["Ami_Opt-Out"];
										if (Ami_Opt_Out === null || Ami_Opt_Out === '' || Ami_Opt_Out === undefined) {
											var Flag = 'True';
										} else {
											var UP_Ami_Opt_Out = Ami_Opt_Out.toUpperCase();
											var Flag = 'False';
											ctx.setVariable("Ami_Opt_Out", Ami_Opt_Out);
										}
									}
								}
								if (UP_AMI_Enabled == 'N' || UP_Ami_Opt_Out == 'TRUE') {
									var lookupMessage = {
										"lookupReq": {
											"type": [{
												"name": "jobTypes.workflows",
												"id": jobTypeID,
												"status": status
											}]
										}
									}
									var LookupServiceResponse = {
										target: lookupURL,
										method: 'POST',
										contentType: 'application/json',
										data: lookupMessage
									};
									var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
									try {
										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												var errorinfo = "mopdiscon_006 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
												ilsctx.setVariable("errorDescription", errorinfo);
												logger.error("mopdiscon_006 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
												session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
											} else {
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsJSON(function(error, responseData) {
														if (error) {
															// error while reading response or transferring data to Buffer
															var errorinfo = "failure in reading message from LookupServiceResponse , details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
															session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));

														} else {
															hm.response.statusCode = responseStatusCode;
															if (responseData.lookupRep.type[0].result == 0) {
																var label = responseData.lookupRep.type[0].label;
																ctx.setVariable("label", label);
																if (label == 'Re-Connect') {
																	var Action = 'RE-CONNECT';
																	var AMI_label = 'Re-Connect Failed';
																} else {
																	var Action = 'DISCONNECT';
																	var AMI_label = 'Disconnect Failed';
																}
																logger.debug("AMI_label" + AMI_label);
																var lookupMessage = {
																	"lookupReq": {
																		"type": [{
																			"name": "jobTypes.workflows",
																			"id": jobTypeID,
																			"label": AMI_label
																		}]
																	}
																}
																var LookupServiceResponse = {
																	target: lookupURL,
																	method: 'POST',
																	contentType: 'application/json',
																	data: lookupMessage
																};
																var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + "POST" + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																urlopen.open(LookupServiceResponse, function(error, response) {
																	if (error) {
																		var errorinfo = "mopdiscon_008 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
																		ilsctx.setVariable("errorDescription", errorinfo);
																		logger.error("mopdiscon_008 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
																		session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200) {
																			response.readAsJSON(function(error, responseData) {
																				if (error) {
																					// error while reading response or transferring data to Buffer
																					var errorinfo = "failure in reading message from LookupServiceResponse , details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
																					session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));

																				} else {
																					hm.response.statusCode = responseStatusCode;
																					if (responseData.lookupRep.type[0].result == 0) {
																						var status = responseData.lookupRep.type[0].status;
																						var workFlowUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/WorkFlow';

																						var workflowApi = {
																							target: workFlowUri,
																							sslClientProfile: 'mopdiscon_SSL_Client_Profile',
																							method: 'POST',
																							contentType: 'application/json',
																							headers: {
																								'osiApiToken': apiToken
																							},
																							data: status
																						}
																						var info = " TargetURL :" + workflowApi.target + "; Method :" + workflowApi.method + "; Data :" + JSON.stringify(workflowApi.data) + ". ";
																						try {
																							urlopen.open(workflowApi, function(error, response) {
																								if (error) {
																									var errorinfo = "mopdiscon_009 urlopen connect error with Get workflowApi for Inp_crewId " + id + " , details are : " + info + "; error info :" + error;
																									ilsctx.setVariable("errorDescription", errorinfo);
																									logger.error("mopdiscon_009 urlopen connect error with Get workflowApi for Inp_crewId " + id + " with error as " + JSON.stringify(error));
																									session.reject("urlopen connect error with Get workflowApi for Inp_crewId " + id + " with error as " + JSON.stringify(error));
																								} else {
																									var responseStatusCode = response.statusCode;
																									if (responseStatusCode == 200) {
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												var errorinfo = "failure in reading message from workflowApi , details are : " + info + "; error info :" + error;
																												ilsctx.setVariable("errorDescription", errorinfo);
																												logger.error("failure in reading message from workflowApi" + JSON.stringify(error));
																												session.reject(" failure in reading message from workflowApi" + JSON.stringify(error));
																											} else {
																												var commentUri = omsExternalURL + '/api/ServiceType/Electric/Job/' + id + '/Comment';
																												var comment = 'FAILED TO ' + Action + ' SINCE METER ' + meterId + ' ' + 'IS NON-AMI.';
																												var payload = {
																													"comment": comment
																												}
																												var commentApi = {
																													target: commentUri,
																													sslClientProfile: 'mopdiscon_SSL_Client_Profile',
																													method: 'POST',
																													contentType: 'application/json',
																													headers: {
																														'osiApiToken': apiToken
																													},
																													data: payload
																												};
																												session.output.write(payload);
																												var info = " TargetURL :" + commentApi.target + "; Method :" + commentApi.method + "; Data :" + JSON.stringify(commentApi.data) + ". ";
																												try {
																													urlopen.open(commentApi, function(error, response) {
																														if (error) {
																															var errorinfo = "mopdiscon_007 urlopen connect error with Get commentApi for crewId " + id + " , details are : " + info + "; error info :" + error;
																															ilsctx.setVariable("errorDescription", errorinfo);
																															logger.error("mopdiscon_007 urlopen connect error with Get commentApi for crewId " + id + " with error as " + JSON.stringify(error));
																															session.reject("urlopen connect error with Get commentApi for crewId " + id + " with error as " + JSON.stringify(error));
																														} else {
																															var responseStatusCode = response.statusCode;
																															if (responseStatusCode == 200) {
																																response.readAsBuffer(function(error, responseData) {
																																	if (error) {
																																		var errorinfo = "failure in reading message from commentApi , details are : " + info + "; error info :" + error;
																																		ilsctx.setVariable("errorDescription", errorinfo);
																																		logger.error("failure in reading message from commentApi" + JSON.stringify(error));
																																		session.reject(" failure in reading message from commentApi" + JSON.stringify(error));
																																	} else { }
																																})
																															} else {
																																response.readAsBuffer(function(error, responseData) {
																																	if (error) {
																																		//dp:reject stop the transaction and go error rule with error code and description
																																		var errorinfo = "failure in reading message from commentApi for  id: " + id + " , details are : " + info + "; error info :" + error;
																																		ilsctx.setVariable("errorDescription", errorinfo);
																																		logger.error("failure in reading message from commentApi for  id: " + id + " " + JSON.stringify(error));
																																		session.reject("failure in reading message from commentApi for  id: " + id + '' + JSON.stringify(error));
																																	} else {
																																		var errorinfo = "commentApi response for  id: " + id + " statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
																																		ilsctx.setVariable("errorDescription", errorinfo);
																																		logger.error("commentApi response for  id: " + id + " statusCode " + responseStatusCode + " " + responseData);
																																		session.reject("Error code returned from commentApi for  id: " + id + " statusCode " + responseStatusCode + " " + responseData);
																																	}
																																});
																															}
																														}
																													});
																												}
																												catch (error) {
																													var errorinfo = "mopdiscon_007 urlopen connect error with Get commentApi for crewId " + id + " , details are : " + info + "; error info :" + error;
																													ilsctx.setVariable("errorDescription", errorinfo);
																													logger.error("mopdiscon_007 urlopen connect error with Get commentApi for crewId " + id + " with error as " + JSON.stringify(error));
																													session.reject("urlopen connect error with Get commentApi for crewId " + id + " with error as " + JSON.stringify(error));
																												}
																												logger.debug("job status updated to OMS");
																											}
																										})
																									} else {
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												//dp:reject stop the transaction and go error rule with error code and description
																												var errorinfo = "failure in reading message from workflowApi for  id: " + id + " , details are : " + info + "; error info :" + error;
																												ilsctx.setVariable("errorDescription", errorinfo);
																												logger.error("failure in reading message from workflowApi for  id: " + id + '' + JSON.stringify(error));
																												session.reject("failure in reading message from workflowApi for  id: " + id + " " + JSON.stringify(error));
																											} else {
																												var errorinfo = "mopdiscon_010 workflowApi response for  id: " + id + " statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
																												ilsctx.setVariable("errorDescription", errorinfo);
																												logger.error("mopdiscon_010 workflowApi response for  id: " + id + " statusCode " + responseStatusCode + " " + responseData);
																												session.reject("Error code returned from workflowApi for  id: " + id + " statusCode " + responseStatusCode + " " + responseData);
																											}
																										});
																									}
																								}
																							});
																						}
																						catch (error) {
																							var errorinfo = "mopdiscon_009 urlopen connect error with Get workflowApi for Inp_crewId " + id + " , details are : " + info + "; error info :" + error;
																							ilsctx.setVariable("errorDescription", errorinfo);
																							logger.error("mopdiscon_009 urlopen connect error with Get workflowApi for Inp_crewId " + id + " with error as " + JSON.stringify(error));
																							session.reject("urlopen connect error with Get workflowApi for Inp_crewId " + id + " with error as " + JSON.stringify(error));
																						}
																					} else {
																						var errorinfo = "mopdiscon_011 lookup result is not 0 , details are : " + info + "; error info :" + error;
																						ilsctx.setVariable("errorDescription", errorinfo);
																						logger.error("mopdiscon_011 lookup result is not 0");
																						session.reject("lookup result is not 0");
																					}
																				}
																			});
																		} else {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					//dp:reject stop the transaction and go error rule with error code and description
																					var errorinfo = "failure in reading message from lookupresponse , details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error("failure in reading message from lookupresponse" + JSON.stringify(error));
																					session.reject("failure in reading message from lookupresponse");
																				} else {
																					var errorinfo = "lookup response is  " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error("lookup response is  " + responseStatusCode + " " + responseData);
																					session.reject("lookup response is " + responseStatusCode + " " + responseData);
																				}
																			});
																		}
																	}
																});

															} else {
																var errorinfo = "mopdiscon_012 lookup result is not 0 , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("mopdiscon_012 lookup result is not 0");
																session.reject("lookup result is not 0");
															}
														}
													});
												} else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															//dp:reject stop the transaction and go error rule with error code and description
															var errorinfo = "failure in reading message from lookupresponse , details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error("failure in reading message from lookupresponse" + JSON.stringify(error));
															session.reject("failure in reading message from lookupresponse");
														} else {
															var errorinfo = "lookup response is  " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error("lookup response is  " + responseStatusCode + " " + responseData);
															session.reject("lookup response is " + responseStatusCode + " " + responseData);
														}
													});
												}
											}
										});
									}
									catch (error) {
										var errorinfo = "mopdiscon_006 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										logger.error("mopdiscon_006 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
										session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
									}
								} else {
									var Flag = 'True';
								}
								ctx.setVariable("Flag", Flag);
								if (Flag == 'True') {
									var options = {
										target: targetQueue,
										data: json,
									};
									session.output.write(json)
									var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
									try {
										urlopen.open(options, function(error, response) {
											var hm = require('header-metadata');
											if (error) {
												var errorinfo = "mopdiscon_013 Error in connecting to target queue" + info + error;
												ilsctx.setVariable("errorDescription", errorinfo);
												ilsctx.setVariable("exitStatus", '500');
												logger.error("mopdiscon_013 Error in connecting to target queue");
												session.reject("Error in connecting to target queue");
												hm.response.statusCode = 500
											} else {
												var mqrc = response.statusCode;
												if (mqrc == 0) {
													response.readAsBuffer(function(readError, responseData) {
														if (readError) {
															hm.response.statusCode = 500
															var errorinfo = "Error while keeping receivecall message to queue is , details are : " + info + "; error info :" + readError;
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error(errorinfo)
															session.reject(errorinfo)
														} else {
															console.log("MQResponseData" + responseData);
														}
													});
												} else {
													logger.error('**mopdiscon_014 urlopen.open error [MQRC=' + mqrc + ']');
													console.log('**urlopen.open error [MQRC=' + mqrc + ']');
													var errorinfo = "mopdiscon_014 urlopen.open error [MQRC=" + mqrc + "] , details are : " + info;
													ilsctx.setVariable("errorDescription", errorinfo);
													session.reject(errorinfo)
													hm.response.statusCode = 500
												}
											}
										});
									}
									catch (error) {
										var errorinfo = "mopdiscon_013 Error in connecting to target queue" + info + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										logger.error("mopdiscon_013 Error in connecting to target queue");
										session.reject("Error in connecting to target queue");
										hm.response.statusCode = 500
									}
								} else {
									ctx.setVariable("AMI", 'False');
								}
							}
						})
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from workflowApi for  premiseID: " + premiseID + " , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from workflowApi for  premiseID: " + premiseID + " " + JSON.stringify(error));
								session.reject("failure in reading message from workflowApi for  premiseID: " + premiseID + " " + JSON.stringify(error));
							} else {
								var errorinfo = "mopdiscon_015 workflowApi response for  premiseID: " + premiseID + " statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("mopdiscon_015 workflowApi response for  premiseID: " + premiseID + " statusCode " + responseStatusCode + " " + responseData);
								session.reject("Error code returned from workflowApi for  premiseID: " + premiseID + " statusCode " + responseStatusCode + " " + responseData);
							}
						});
					}
				}
			});
		}
		catch (error) {
			var errorinfo = "mopdiscon_005 urlopen connect error with Get PremiseGetApi for premiseID " + premiseID + " , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("exitStatus", '500');
			logger.error("mopdiscon_005 urlopen connect error with Get PremiseGetApi for premiseID " + premiseID + " with error as " + JSON.stringify(error));
			session.reject("urlopen connect error with Get PremiseGetApi for premiseID " + premiseID + " with error as " + JSON.stringify(error));
		}
	}
})
