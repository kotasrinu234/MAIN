var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var errorDescription = ilsctx.getVar("errorDescription");
var hm = require('header-metadata');
var sm = require('service-metadata');
var responseStatusCode = ctx.getVariable("responseStatusCode");
var errorCode = sm.getVar('var://service/error-code');
var errMsg = sm.getVar('var://service/error-message');
var logger = console.options({
	'category': 'all'
});
if ((errorCode == '0x00d30003') || (responseStatusCode == '400')) {
	hm.current.statusCode = '400';
}
else {
	hm.current.statusCode = '500';
}
var obj = {};
obj.errorMessage = sm.getVar('var://service/error-message');
obj.errorCode = sm.getVar('var://service/error-code');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
session.output.write(obj);
if(errorDescription){
	ilsctx.setVar("errorDescription", errorDescription);
}
else{
	ilsctx.setVar("errorDescription", errMsg);
}
