var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.receiveMeterDisconnectEntryDescription;
var exitDescription = session.parameters.receiveMeterDisconnectExitDescription;
var exitDestination = session.parameters.queueName;
var messageType  = session.parameters.messageType ;
if (messageType  !== undefined || messageType  !== null || messageType  !== '') {
	ctx.setVariable("messageType ", messageType );
}
if (exitDestination !== undefined || exitDestination !== null || exitDestination !== '') {
	ctx.setVariable("exitDestination", exitDestination);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		ctx.setVariable("correlationID", incomingdata.data[0].leadCall.externalPremiseID + ":" + incomingdata.data[0].leadCall.jobID);
		if (incomingdata.data[0].leadCall.meterID) {
			if (incomingdata.data[0].leadCall.meterID !== undefined || incomingdata.data[0].leadCall.meterID !== null || incomingdata.data[0].leadCall.meterID !== '') {
				ctx.setVariable("meterID", incomingdata.data[0].leadCall.meterID);
			}
		}
		if (incomingdata.data[0].leadCall.externalPremiseID) {
			if (incomingdata.data[0].leadCall.externalPremiseID !== undefined || incomingdata.data[0].leadCall.externalPremiseID !== null || incomingdata.data[0].leadCall.externalPremiseID !== '') {
				ctx.setVariable("premiseID", incomingdata.data[0].leadCall.externalPremiseID);
			}
		}
		if (incomingdata.data[0].leadCall.jobID) {
			if (incomingdata.data[0].leadCall.jobID !== undefined || incomingdata.data[0].leadCall.jobID !== null || incomingdata.data[0].leadCall.jobID !== '') {
				ctx.setVariable("jobID", incomingdata.data[0].leadCall.jobID);
			}
		}
		if (incomingdata.data[0].updatedAt) {
			if (incomingdata.data[0].updatedAt !== undefined || incomingdata.data[0].updatedAt !== null || incomingdata.data[0].updatedAt !== '') {
				ctx.setVariable("sourceEventTimestamp", incomingdata.data[0].updatedAt);
			}
		}
	}
});
