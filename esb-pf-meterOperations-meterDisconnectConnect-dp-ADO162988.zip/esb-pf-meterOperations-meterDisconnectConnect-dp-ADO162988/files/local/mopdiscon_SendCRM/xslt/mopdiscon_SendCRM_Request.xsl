<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/json"
extension-element-prefixes="dp" exclude-result-prefixes="dp">
	<xsl:output method="xml" />
	
	<xsl:template match="/">
		<xsl:choose>		
			<xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']">
				<xsl:variable name="code" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='code'])"/>
				<xsl:variable name="details" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='details'])"/>
				<xsl:variable name="CorrelationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[ local-name()='Header']/*[local-name()='CorrelationID']/text())"/>
				<xsl:variable name="mRID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='Assets']/*[local-name()='mRID']/text())"/>
				<xsl:variable name="dateTime" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']/text())"/>
				<xsl:variable name="action" select="'02'"/>
				<xsl:variable name="reason" select="'04'"/>
				<xsl:variable name="finalnote">
					<xsl:value-of select="concat($code,$details)"/>
				</xsl:variable>
				<dp:set-variable name="'var://context/Meter_Disconnect/code'" value="$code" />
				<dp:set-variable name="'var://context/Meter_Disconnect/details'" value="$details" />
				<dp:set-variable name="'var://context/Meter_Disconnect/mRID'" value="$mRID" />
				<dp:set-variable name="'var://context/Meter_Disconnect/dateTime'" value="$dateTime" />
				<dp:set-variable name="'var://context/Meter_Disconnect/CorrelationID'" value="$CorrelationID" />
				<dp:set-variable name="'var://context/Meter_Disconnect/notes'" value="string($finalnote)" />
				<dp:set-variable name="'var://context/Meter_Disconnect/Meter'" value="'MeterDisconnect'"/>
				<dp:set-variable name="'var://context/Meter_Disconnect/action'" value="$action" />
				<dp:set-variable name="'var://context/Meter_Disconnect/reason'" value="$reason" />
				<dp:set-variable name="'var://context/Meter_Disconnect/finalnote'" value="$finalnote" />
				<!-- <xsl:message dp:type="all" dp:priority="error">Inside ReplyDisconnectMeter ReplyCode message failure++++++++</xsl:message> -->
			</xsl:when>
			<xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']">
				<xsl:variable name="code" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='code']/text())"/>
				<xsl:variable name="details" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='details']/text())"/>
				<xsl:variable name="CorrelationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[ local-name()='Header']/*[local-name()='CorrelationID']/text())"/>
				<xsl:variable name="mRID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='Assets']/*[local-name()='mRID']/text())"/>
				<xsl:variable name="dateTime" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']/text())"/>
				<xsl:variable name="action" select="'04'"/>
				<xsl:variable name="reason" select="'04'"/>
				<xsl:variable name="finalnote">
					<xsl:value-of select="concat($code,$details)"/>
				</xsl:variable>
				<xsl:variable name="timeStamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']/text())"/>
				<dp:set-variable name="'var://context/Meter_Disconnect/code'" value="$code" />
				<dp:set-variable name="'var://context/Meter_Disconnect/details'" value="$details" />
				<dp:set-variable name="'var://context/Meter_Disconnect/mRID'" value="$mRID" />
				<dp:set-variable name="'var://context/Meter_Disconnect/dateTime'" value="$dateTime" />
				<dp:set-variable name="'var://context/Meter_Disconnect/CorrelationID'" value="$CorrelationID" />
				<dp:set-variable name="'var://context/Meter_Disconnect/notes'" value="string($finalnote)" />
				<dp:set-variable name="'var://context/Meter_Disconnect/Meter'" value="'MeterReconnect'" />
				<dp:set-variable name="'var://context/Meter_Disconnect/action'" value="$action" />
				<dp:set-variable name="'var://context/Meter_Disconnect/reason'" value="$reason" />
				<dp:set-variable name="'var://context/Meter_Disconnect/finalnote'" value="$finalnote" />
				<!-- <xsl:message dp:type="all" dp:priority="error">Inside ReplyReconnectMeter ReplyCode message failure++++++++</xsl:message> -->
			</xsl:when>
			<xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']">
				<xsl:variable name="ReplyCode" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='ReplyCode']/text())"/>
				<xsl:variable name="CorrelationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[ local-name()='Header']/*[local-name()='CorrelationID']/text())"/>
				<xsl:variable name="mRID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='Assets']/*[local-name()='mRID']/text())"/>
				<xsl:variable name="dateTime" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']/text())"/>
				<xsl:variable name="action" select="'01'"/>
				<xsl:variable name="reason" select="'04'"/>
				<xsl:variable name="timeStamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='ReplyDisconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']/text())"/>
				<dp:set-variable name="'var://context/Meter_Disconnect/mRID'" value="$mRID" />
				<dp:set-variable name="'var://context/Meter_Disconnect/dateTime'" value="$dateTime" />
				<dp:set-variable name="'var://context/Meter_Disconnect/CorrelationID'" value="$CorrelationID" />
				<dp:set-variable name="'var://context/Meter_Disconnect/Meter'" value="'MeterDisconnect'"/>
				<dp:set-variable name="'var://context/Meter_Disconnect/ReplyCode'" value="$ReplyCode" />
				<dp:set-variable name="'var://context/Meter_Disconnect/action'" value="$action" />
				<dp:set-variable name="'var://context/Meter_Disconnect/reason'" value="$reason" />
				<!-- <xsl:message dp:type="all" dp:priority="error">Inside ReplyDisconnectMeter ReplyCode message success++++++++</xsl:message> -->
			</xsl:when>
			<xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']">
				<xsl:variable name="ReplyCode" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='ReplyCode']/text())"/>
				<xsl:variable name="CorrelationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[ local-name()='Header']/*[local-name()='CorrelationID']/text())"/>
				<xsl:variable name="mRID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='Assets']/*[local-name()='mRID']/text())"/>
				<xsl:variable name="dateTime" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']/text())"/>
				<xsl:variable name="action" select="'03'"/>
				<xsl:variable name="reason" select="'04'"/>
				<xsl:variable name="timeStamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']/text())"/>
				<dp:set-variable name="'var://context/Meter_Disconnect/Meter'" value="'MeterReconnect'" />
				<dp:set-variable name="'var://context/Meter_Disconnect/ReplyCode'" value="$ReplyCode" />
				<dp:set-variable name="'var://context/Meter_Disconnect/mRID'" value="$mRID" />
				<dp:set-variable name="'var://context/Meter_Disconnect/dateTime'" value="$dateTime" />
				<dp:set-variable name="'var://context/Meter_Disconnect/CorrelationID'" value="$CorrelationID" />
				<dp:set-variable name="'var://context/Meter_Disconnect/action'" value="$action" />
				<dp:set-variable name="'var://context/Meter_Disconnect/reason'" value="$reason" />
				<!-- <xsl:message dp:type="all" dp:priority="error">Inside ReplyReconnectMeter ReplyCode message success++++++++</xsl:message> -->
			</xsl:when>
			
			<xsl:otherwise>
			It is neither Reconnect nor Disconnect 
			<dp:set-variable name="'var://context/Meter_Disconnect/finalnote'" value="'It is neither Reconnect nor Disconnect'" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
