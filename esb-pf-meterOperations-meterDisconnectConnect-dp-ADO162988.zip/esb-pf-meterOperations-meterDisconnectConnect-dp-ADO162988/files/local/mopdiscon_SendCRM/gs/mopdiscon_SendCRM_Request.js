var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookupURL;
var CorrelationID = ctx.getVariable("CorrelationID");
var timeStamp = ctx.getVariable("dateTime");
var meterId = ctx.getVariable("mRID");
var Meter = ctx.getVariable("Meter");
var ReplyCode = ctx.getVariable("ReplyCode");
var action = ctx.getVar("action");
var reason = ctx.getVar("reason");
var notes = ctx.getVar("notes");
var code = ctx.getVariable("code");
var details = ctx.getVariable("details");
//var timeStamp = ctx.getVar("timeStamp");
//var jobID = CorrelationID.substring(CorrelationID.indexOf(":") + 1);
var externalPermiseID = CorrelationID.split(':').shift();
var logger = console.options({
    'category': 'all'
});
     if ((Meter == 'MeterDisconnect') && (ReplyCode == 'SUCCESS')) {
    	    logger.info("MeterDisconnect SUCCESS");
    	    var flag = 'True';
    	    var payload={
    				"MeterStatusADMS": {
    				          "premiseId": externalPermiseID,
    				          "meterId": meterId,
    				          "action": action,
    				          "reason": reason,
    				          "actionTimeStamp": timeStamp
    				          //"notes": notes
    				    }
    				 }
    	} else if ((Meter == 'MeterDisconnect') && (ReplyCode == 'FAILURE')) {
    		 logger.info("MeterDisconnect FAILURE");
    		 var payload={
    					"MeterStatusADMS": {
    					          "premiseId": externalPermiseID,
    					          "meterId": meterId,
    					          "action": action,
    					          "reason": reason,
    					          "actionTimeStamp": timeStamp,
    					          "notes": notes
    					    }
    					 }
    	} else if ((Meter == 'MeterReconnect') && (ReplyCode == 'SUCCESS')) {
    		logger.info("MeterReconnect SUCCESS");
    	    var flag = 'True';
    	    var payload={
    				"MeterStatusADMS": {
    				          "premiseId": externalPermiseID,
    				          "meterId": meterId,
    				          "action": action,
    				          "reason": reason,
    				          "actionTimeStamp": timeStamp
    				          //"notes": notes
    				    }
    				 }
    	} else {
    		logger.info("MeterReconnect FAILURE");
    		 var payload={
    					"MeterStatusADMS": {
    					          "premiseId": externalPermiseID,
    					          "meterId": meterId,
    					          "action": action,
    					          "reason": reason,
    					          "actionTimeStamp": timeStamp,
    					          "notes": notes
    					    }
    					 }
    	}
  
   if (flag == 'True') {
	   var ctx = session.name("mopdiscon") || session.createContext("mopdiscon");
		 ctx.setVariable("CRB_IncomingData", payload);
	     session.output.write(payload);
   } else {
	   var ctx = session.name("mopdiscon") || session.createContext("mopdiscon");
		 ctx.setVariable("CRB_IncomingData", payload);
	     session.output.write(payload);
   }
