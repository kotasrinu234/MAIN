var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
    'category': 'all'
});
var p = 0;
var TokenValue = session.parameters.TokenValue;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
    	//console.error("inside CRM response---"+JSON.stringify(incomingdata));
    	var incominglevel = incomingdata.Response.level;
    	var level;
    	if(incominglevel == 'S'){
    		level = 'Success';
    	}else if(incominglevel == 'E'){
    		level = 'Error';
    	}else if(incominglevel == 'W'){
    		level = 'Warning';
    	}else if(incominglevel == 'I'){
    		level = 'Info';
    	}
    	
var payload1 = {
				  "messageReply": {
				    "replyCode": "",
				    "error": {
				      "level": level,
				      "class": incomingdata.Response.class,
				      "code": incomingdata.Response.code,
				      "details": incomingdata.Response.details
				    }
				  }
    	}
    	
		var payload = JSON.stringify(payload1);
		var ctx = session.name("mopdiscon") || session.createContext("mopdiscon");
		ctx.setVariable("CRB_Response_payload", payload);
		session.output.write(payload);
    }
});
