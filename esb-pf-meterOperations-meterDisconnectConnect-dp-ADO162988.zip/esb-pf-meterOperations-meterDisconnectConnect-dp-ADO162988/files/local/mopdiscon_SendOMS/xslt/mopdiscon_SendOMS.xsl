<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:dp="http://www.datapower.com/extensions" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:json="http://www.ibm.com/xmlns/prod/2009/json"
	xmlns:date="http://exslt.org/dates-and-times"
extension-element-prefixes="dp" exclude-result-prefixes="dp">
    <xsl:output method="xml" />
    <xsl:template match="/">
        <xsl:choose>
            <xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']">
                <xsl:variable name="ReplyCode" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*
			[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='ReplyCode']/text())"/>
                <dp:set-variable name="'var://context/Meter_Disconnect/Meter'" value="'MeterDisconnect'"/>
                <dp:set-variable name="'var://context/Meter_Disconnect/ReplyCode'" value="$ReplyCode" />
                <xsl:variable name="CorrelationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*
		[local-name()='ReplyDisconnectMeter']/*[local-name()='Header']/*[local-name()='CorrelationID']/text())"/>
                <xsl:variable name="mRID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='Assets']/*[local-name()='mRID']/text())"/>
				<xsl:variable name="dateTime" select="date:seconds(date:date-time())"/>
                <dp:set-variable name="'var://context/Meter_Disconnect/mRID'" value="$mRID" />
                <dp:set-variable name="'var://context/Meter_Disconnect/dateTime'" value="$dateTime" />
                <dp:set-variable name="'var://context/Meter_Disconnect/CorrelationID'" value="$CorrelationID" />
            </xsl:when>
            <xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']">
                <xsl:variable name="ReplyCode" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*
			[local-name()='ReplyReconnectMeter']/*[local-name()='Reply']/*[local-name()='ReplyCode']/text())"/>
                <dp:set-variable name="'var://context/Meter_Disconnect/Meter'" value="'MeterReconnect'" />
                <dp:set-variable name="'var://context/Meter_Disconnect/ReplyCode'" value="$ReplyCode" />
                <xsl:variable name="CorrelationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*
		[local-name()='ReplyReconnectMeter']/*[local-name()='Header']/*[local-name()='CorrelationID']/text())"/>
                <xsl:variable name="mRID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='Assets']/*[local-name()='mRID']/text())"/>
				<xsl:variable name="dateTime" select="date:seconds(date:date-time())"/>
                <dp:set-variable name="'var://context/Meter_Disconnect/mRID'" value="$mRID" />
                <dp:set-variable name="'var://context/Meter_Disconnect/dateTime'" value="$dateTime" />
                <dp:set-variable name="'var://context/Meter_Disconnect/CorrelationID'" value="$CorrelationID" />
            </xsl:when>
            <xsl:otherwise><xsl:message dp:type="all" dp:priority="error">mopdiscon_024 Request is neither Reconnect nor Disconnect  </xsl:message>	</xsl:otherwise>
        </xsl:choose>
		<xsl:choose>
		 <xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*
			[local-name()='ReplyReconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']">
		 <xsl:variable name="code" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*
			[local-name()='ReplyReconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='code']/text())"/>
                <xsl:variable name="details" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*
			[local-name()='ReplyReconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='details']/text())"/>
                <dp:set-variable name="'var://context/Meter_Disconnect/code'" value="$code" />
                <dp:set-variable name="'var://context/Meter_Disconnect/details'" value="$details" />
		</xsl:when>	
				 <xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*
			[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']">
		 <xsl:variable name="code" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*
			[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='code']/text())"/>
                <xsl:variable name="details" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*
			[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='Error']/*[local-name()='details']/text())"/>
                <dp:set-variable name="'var://context/Meter_Disconnect/code'" value="$code" />
                <dp:set-variable name="'var://context/Meter_Disconnect/details'" value="$details" />
		</xsl:when>
		</xsl:choose>
    </xsl:template>
</xsl:stylesheet>



