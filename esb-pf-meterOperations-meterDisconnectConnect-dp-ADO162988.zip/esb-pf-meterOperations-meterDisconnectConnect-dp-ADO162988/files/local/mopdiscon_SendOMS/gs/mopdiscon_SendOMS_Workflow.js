var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var Meter = ctx.getVariable("Meter");
var ReplyCode = ctx.getVariable("ReplyCode");
var CorrelationID = ctx.getVariable("CorrelationID");
var jobTypeID = ctx.getVariable("jobTypeID");
var lookupURL = session.parameters.lookupURL
var jobID = CorrelationID.substring(CorrelationID.indexOf(":") + 1);
var externalPermiseID = CorrelationID.split(':').shift();
var logger = console.options({
	'category': 'all'
});
var flag = ctx.getVariable("flag");
var GetCallstatus = ctx.getVariable("GetCallstatus");
var CompletedLookupStatus = ctx.getVariable("CompletedLookupStatus");
var LookuplabelStatus = ctx.getVariable("LookuplabelStatus");

if (GetCallstatus !== LookuplabelStatus && GetCallstatus !== CompletedLookupStatus) {
	var WorkFlowUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobID + '/WorkFlow';
	var WorkFlowApi = {
		target: WorkFlowUri,
		sslClientProfile: 'mopdiscon_SSL_Client_Profile',
		method: 'POST',
		contentType: 'application/text',
		headers: {
			'osiApiToken': apiToken
		},
		data: LookuplabelStatus
	};
	var info = " TargetURL :" + WorkFlowApi.target + "; Method :" + "POST" + "; Data :" + JSON.stringify(WorkFlowApi.data) + ". ";
	try {
		urlopen.open(WorkFlowApi, function(error, response) {
			if (error) {
				var errorinfo = "mopdiscon_029 urlopen connect error with workflowApi for jobID , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("mopdiscon_029 urlopen connect error with workflowApi for jobID  with error as " + JSON.stringify(error));
				session.reject("urlopen connect error with workflowApi for jobID  with error as " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message from workflowApi , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from workflowApi" + JSON.stringify(error));
							session.reject(" failure in reading message from workflowApi" + JSON.stringify(error));
						} else {
							logger.debug("job status updated to OMS");
							ilsctx.setVar("exitDestination", omsExternalURL);
						}
					})
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from workflowApi for jobID: " + jobID + " , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from workflowApi for jobID: " + jobID + " " + JSON.stringify(error));
							session.reject("failure in reading message from workflowApi for jobID: " + jobID + " " + JSON.stringify(error));
						} else {
							var errorinfo = "mopdiscon_030 workflowApi response for jobID: " + jobID + " statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("mopdiscon_030 workflowApi response for jobID: " + jobID + " statusCode " + responseStatusCode + " " + responseData);
							session.reject("mopdiscon_030:Error code returned from workflowApi for jobID: " + jobID + " statusCode " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "mopdiscon_029 urlopen connect error with workflowApi for jobID , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("mopdiscon_029 urlopen connect error with workflowApi for jobID  with error as " + JSON.stringify(error));
		session.reject("urlopen connect error with workflowApi for jobID  with error as " + JSON.stringify(error));
	}
}
if (flag == 'True') {
if (GetCallstatus !== CompletedLookupStatus) {
	var WorkFlowUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobID + '/WorkFlow';
	var WorkFlowApi = {
		target: WorkFlowUri,
		sslClientProfile: 'mopdiscon_SSL_Client_Profile',
		method: 'POST',
		contentType: 'application/text',
		headers: {
			'osiApiToken': apiToken
		},
		data: CompletedLookupStatus
	};
	var info = " TargetURL :" + WorkFlowApi.target + "; Method :" + WorkFlowApi.method + "; Data :" + JSON.stringify(WorkFlowApi.data) + ". ";
	//logger.error("entering second workflow API")
	try {
		urlopen.open(WorkFlowApi, function(error, response) {
			if (error) {
				var errorinfo = "mopdiscon_035 urlopen connect error with Get workflowApi for jobID , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("mopdiscon_035 urlopen connect error with Get workflowApi for jobID with error as " + JSON.stringify(error));
				session.reject("urlopen connect error with Get workflowApi for jobID  with error as " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message from workflowApi , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from workflowApi" + JSON.stringify(error));
							session.reject(" failure in reading message from workflowApi" + JSON.stringify(error));
						} else {
							logger.debug("job status updated to OMS");
						}
					})
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from workflowApi for jobID: " + jobID + " , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from workflowApi for jobID: " + jobID + " " + JSON.stringify(error));
							session.reject("failure in reading message from workflowApi for jobID: " + jobID + " " + JSON.stringify(error));
						} else {
							var errorinfo = "mopdiscon_036 workflowApi response for jobID: " + jobID + " statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("mopdiscon_036 workflowApi response for jobID: " + jobID + " statusCode " + responseStatusCode + " " + responseData);
							session.reject("mopdiscon_036:Error code returned from workflowApi for jobID: " + jobID + " statusCode " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "mopdiscon_035 urlopen connect error with Get workflowApi for jobID , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("mopdiscon_035 urlopen connect error with Get workflowApi for jobID with error as " + JSON.stringify(error));
		session.reject("urlopen connect error with Get workflowApi for jobID  with error as " + JSON.stringify(error));
	}
	}
}
