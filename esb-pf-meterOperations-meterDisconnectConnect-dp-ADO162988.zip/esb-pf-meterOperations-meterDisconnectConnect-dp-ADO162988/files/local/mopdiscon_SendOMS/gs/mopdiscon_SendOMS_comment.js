var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var Meter = ctx.getVariable("Meter");
var ReplyCode = ctx.getVariable("ReplyCode");
var mRID = ctx.getVariable("mRID");
var code = ctx.getVariable("code");
var details = ctx.getVariable("details");
var CorrelationID = ctx.getVariable("CorrelationID");
var jobID = CorrelationID.substring(CorrelationID.indexOf(":") + 1);
var dateTime = ctx.getVariable("dateTime");
var logger = console.options({
	'category': 'all'
});
var now = new Date();
var year = now.getFullYear();

var month = now.getMonth() + 1;
var month1 = month.toString();
var strmonthlength = month1.length;
var todaymonth;
if (strmonthlength == 1) {
	todaymonth = '0' + month;
} else {
	todaymonth = month;
}

var day = now.getDate();
var day1 = day.toString();
var strdaylength = day1.length;
var todaydate;
if (strdaylength == 1) {
	todaydate = '0' + day;
} else {
	todaydate = day;
}

var hour = now.getHours();
var todayhour = hour.toString();
var strhourlength = todayhour.length;
var todayhour;
if (strhourlength == 1) {
	todayhour = '0' + hour;
} else {
	todayhour = hour;
}

var minute = now.getMinutes();
var todayminute = minute.toString();
var strminutelength = todayminute.length;
var todayminute;
if (strminutelength == 1) {
	todayminute = '0' + minute;
} else {
	todayminute = minute;
}

var second = now.getSeconds();
var todaysecond = second.toString();
var strsecondlength = todaysecond.length;
var todaysecond;
if (strsecondlength == 1) {
	todaysecond = '0' + todaysecond;
} else {
	todaysecond = todaysecond;
}
var nowdate = todaymonth + '/' + todaydate + '/' + year
var nowtime = todayhour + ':' + todayminute
var currentTimestamp = nowdate + ' ' + nowtime

if ((Meter == 'MeterDisconnect') && (ReplyCode == 'SUCCESS')) {
	var JobPayload = {
		"comment": 'ESB: meter ' + mRID + ' disconnected successfully ' + currentTimestamp
	}
} else if ((Meter == 'MeterDisconnect') && (ReplyCode == 'FAILURE')) {
	var JobPayload = {
		"comment": 'ESB: meter ' + mRID + ' disconnected failed ' + currentTimestamp + ' ' +
			'Reason:  ' + code + ': ' + details + '.'

	}
} else if ((Meter == 'MeterReconnect') && (ReplyCode == 'SUCCESS')) {
	var JobPayload = {
		"comment": 'ESB: meter ' + mRID + ' connected successfully ' + currentTimestamp
	}
} else {
	var JobPayload = {
		"comment": 'ESB: meter ' + mRID + ' connection failed  ' + currentTimestamp + ' ' +
			'Reason:  ' + code + ': ' + details + '.'

	}
}
var commentUri = omsExternalURL + '/api/ServiceType/Electric/Job/' + jobID + '/Comment';
var commentapi = {
	target: commentUri,
	sslClientProfile: 'mopdiscon_SSL_Client_Profile',
	method: 'POST',
	contentType: 'application/json',
	headers: {
		'osiApiToken': apiToken
	},
	data: JobPayload
};
session.output.write(JobPayload)
var info = " TargetURL :" + commentapi.target + "; Method :" + commentapi.method + "; Data :" + JSON.stringify(commentapi.data) + ". ";
try {
	urlopen.open(commentapi, function(error, response) {
		if (error) {
			// an error occurred during reading the file
			var errorinfo = "mopdiscon_039 urlopen connect error with Get commentUri for jobID , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("mopdiscon_039 urlopen connect error with Get commentUri for jobID  with error as " + JSON.stringify(error));
			session.reject("urlopen connect error with Get commentUri for jobID  with error as " + JSON.stringify(error))
		} else {
			var responseStatusCode = response.statusCode;
			ctx.setVariable("responseStatusCode", responseStatusCode);
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						// error while reading response or transferring data to Buffer
						var errorinfo = "failure in reading message from commentUri , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("commentUri readAsJSON error: " + JSON.stringify(error));
						session.reject("commentUri readAsJSON error: " + JSON.stringify(error));
					} else {
						logger.debug("commentapi is successful");
					}
				})

			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from commentApi for  jobID: " + jobID + " , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("failure in reading message from commentApi for  jobID: " + jobID + " " + JSON.stringify(error));
						session.reject("failure in reading message from commentApi for  jobID: " + jobID + '' + JSON.stringify(error));
					} else {
						var errorinfo = "mopdiscon_040 commentApi response for  jobID: " + jobID + " statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("mopdiscon_040 commentApi response for  jobID: " + jobID + " statusCode " + responseStatusCode + " " + responseData);
						session.reject("Error code returned from commentApi for  jobID: " + jobID + " statusCode " + responseStatusCode + " " + responseData);
					}
				});
			}
		}
	});
}
catch (error) {
	var errorinfo = "mopdiscon_039 urlopen connect error with Get commentUri for jobID , details are : " + info + "; error info :" + error;
	ilsctx.setVariable("errorDescription", errorinfo);
	logger.error("mopdiscon_039 urlopen connect error with Get commentUri for jobID  with error as " + JSON.stringify(error));
	session.reject("urlopen connect error with Get commentUri for jobID  with error as " + JSON.stringify(error))
}
