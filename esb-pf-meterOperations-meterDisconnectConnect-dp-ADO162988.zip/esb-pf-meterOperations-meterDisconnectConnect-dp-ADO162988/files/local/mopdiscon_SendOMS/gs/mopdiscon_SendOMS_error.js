var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var hm = require('header-metadata');
var sm = require('service-metadata');
var responseStatusCode = ctx.getVariable("responseStatusCode");
var errorCode = sm.getVar('var://service/error-code');
var ilsctx = session.name("ILS") || session.createContext("ILS");
var errorDescription = ilsctx.getVar("errorDescription");
var errMsg = sm.getVar('var://service/error-message');
var logger = console.options({
	'category': 'all'
});
if (errorCode == '0x00d30003') {
	if (responseStatusCode == '400') {
		hm.current.statusCode = '400';
	}
	else if (responseStatusCode == '404') {
		hm.current.statusCode = '404';
	}
	else {
		hm.current.statusCode = '500';
	}
}
var obj = {};
obj.errorMessage = sm.getVar('var://service/error-message');
obj.errorCode = sm.getVar('var://service/error-code');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
session.output.write(obj);
if(errorDescription){
	ilsctx.setVar("errorDescription", errorDescription);
}
else{
	ilsctx.setVar("errorDescription", errMsg);
}
