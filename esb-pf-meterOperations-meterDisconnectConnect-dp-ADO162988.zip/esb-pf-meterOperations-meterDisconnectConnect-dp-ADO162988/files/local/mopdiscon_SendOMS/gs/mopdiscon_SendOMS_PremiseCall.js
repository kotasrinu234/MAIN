var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var Meter = ctx.getVariable("Meter");
var ReplyCode = ctx.getVariable("ReplyCode");
var CorrelationID = ctx.getVariable("CorrelationID");
var externalPermiseID = CorrelationID.split(':').shift();
var date = new Date();
var currentTimestamp = date.toISOString();
ctx.setVariable("currentTimestamp", currentTimestamp);
var logger = console.options({
	'category': 'all'
});
if ((Meter == 'MeterDisconnect') && (ReplyCode == 'SUCCESS')) {
	var flag = 'True';
	var PremisePayload = {
		"connected": "false"
	}
} else if ((Meter == 'MeterReconnect') && (ReplyCode == 'SUCCESS')) {
	var flag = 'True';
	var PremisePayload = {
		"connected": "True"
	}
}
if (flag == 'True') {
	var PremisePatchUri = omsExternalURL + '/api/Premise/service/Electric/' + externalPermiseID;
	var PremisePatchapi = {
		target: PremisePatchUri,
		sslClientProfile: 'mopdiscon_SSL_Client_Profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: PremisePayload
	};
	var info = " TargetURL :" + PremisePatchapi.target + "; Method :" + PremisePatchapi.method + "; Data :" + JSON.stringify(PremisePatchapi.data) + ". ";
	try {
		urlopen.open(PremisePatchapi, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				var errorinfo = "mopdiscon_025 urlopen connect error with Get PremisePatchapi for premiseID " + externalPermiseID + " , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("mopdiscon_025 urlopen connect error with Get PremisePatchapi for premiseID " + externalPermiseID + " with error as " + JSON.stringify(error));
				session.reject("urlopen connect error with Get PremisePatchapi for premiseID " + externalPermiseID + " with error as " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					logger.debug("PremisePatchapi is successful");
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from PremisePatchapi for  premiseID: " + externalPermiseID + " , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from PremisePatchapi for  premiseID: " + externalPermiseID + " " + JSON.stringify(error));
							session.reject("failure in reading message from PremisePatchapi for  premiseID: " + externalPermiseID + " " + JSON.stringify(error));
						} else {
							var errorinfo = "mopdiscon_026 PremisePatchapi response for  premiseID: " + externalPermiseID + " statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("mopdiscon_026 PremisePatchapi response for  premiseID: " + externalPermiseID + " statusCode " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from PremisePatchapi for  premiseID: " + externalPermiseID + " statusCode " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "mopdiscon_025 urlopen connect error with Get PremisePatchapi for premiseID " + externalPermiseID + " , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("mopdiscon_025 urlopen connect error with Get PremisePatchapi for premiseID " + externalPermiseID + " with error as " + JSON.stringify(error));
		session.reject("urlopen connect error with Get PremisePatchapi for premiseID " + externalPermiseID + " with error as " + JSON.stringify(error));
	}
}
