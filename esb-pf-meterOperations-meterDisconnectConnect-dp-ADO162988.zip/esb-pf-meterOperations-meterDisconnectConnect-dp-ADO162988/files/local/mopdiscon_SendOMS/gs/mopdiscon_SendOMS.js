var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookupURL;
var CorrelationID = ctx.getVariable("CorrelationID");
var Meter = ctx.getVariable("Meter");
var ReplyCode = ctx.getVariable("ReplyCode");
var jobID = CorrelationID.substring(CorrelationID.indexOf(":") + 1);
var logger = console.options({
	'category': 'all'
});
if ((Meter == 'MeterDisconnect') && (ReplyCode == 'SUCCESS')) {
	var flag = 'True';
	var Lookuplabel = 'Disconnect Successful';
} else if ((Meter == 'MeterDisconnect') && (ReplyCode == 'FAILURE')) {
	var Lookuplabel = 'Disconnect Failed';
} else if ((Meter == 'MeterReconnect') && (ReplyCode == 'SUCCESS')) {
	var flag = 'True';
	var Lookuplabel = 'Re-Connect Successful';
} else {
	Lookuplabel = 'Re-Connect Failed';
}
if ((Meter == 'MeterDisconnect') && (ReplyCode == 'SUCCESS')) {
	var flag = "True"
	var Label = 'Completed';
	ctx.setVariable("flag", flag);

} else if ((Meter == 'MeterReconnect') && (ReplyCode == 'SUCCESS')) {
	var flag = 'True'
	var Label = 'Completed';
	ctx.setVariable("flag", flag);
}
var GetJobUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobID;
var GetJobAPI = {
	target: GetJobUri,
	sslClientProfile: 'mopdiscon_SSL_Client_Profile',
	method: 'GET',
	contentType: 'application/json',
	headers: {
		'osiApiToken': apiToken
	},
};
var info = " TargetURL :" + GetJobAPI.target + "; Method :" + GetJobAPI.method;
try {
	urlopen.open(GetJobAPI, function(error, response) {
		if (error) {
			// an error occurred during reading the file
			var errorinfo = "mopdiscon_027 urlopen connect error with Get GetJobUri for jobID " + jobID + " , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("mopdiscon_027 urlopen connect error with Get GetJobUri for jobID " + jobID + " with error as " + JSON.stringify(error));
			session.reject("urlopen connect error with Get GetJobUri for jobID " + jobID + " with error as " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			ctx.setVariable("responseStatusCode", responseStatusCode);
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						// error while reading response or transferring data to 
						var errorinfo = "failure in reading message from GetJobAPI , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("GetJobAPI readAsJSON error: " + JSON.stringify(error));
						session.reject("GetJobAPI readAsJSON error: " + JSON.stringify(error));
					} else {
						ctx.setVariable("Jobresponse", responseData);
						var jobTypeID = responseData.jobTypeID;
						ctx.setVariable("jobTypeID", jobTypeID);
						var GetCallstatus = responseData.status;
						ctx.setVariable("GetCallstatus", GetCallstatus);
						var lookupMessage = {
							"lookupReq": {
								"type": [{
									"name": "jobTypes.workflows",
									"id": jobTypeID,
									"label": Lookuplabel
								}]
							}
						}
						var LookupServiceResponse = {
							target: lookupURL,
							method: 'POST',
							contentType: 'application/json',
							data: lookupMessage
						};
						var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + "POST" + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
						try {
							urlopen.open(LookupServiceResponse, function(error, response) {
								if (error) {
									var errorinfo = "mopdiscon_028 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("mopdiscon_028 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
									session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
								} else {
									// read response data
									// get the response status code
									var responseStatusCode = response.statusCode;
									ctx.setVariable("responseStatusCode", responseStatusCode);
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												// error while reading response or transferring data to Buffer
												var errorinfo = "failure in reading message from LookupServiceResponse , details are : " + info + "; error info :" + error;
												ilsctx.setVariable("errorDescription", errorinfo);
												logger.error("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
												session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));

											} else {
												if (responseData.lookupRep.type[0].result == 0) {
													var Status = responseData.lookupRep.type[0].status;
													ctx.setVariable("LookuplabelStatus", Status);
													if (flag == 'True') {
														var lookupMessage = {
															"lookupReq": {
																"type": [{
																	"name": "jobTypes.workflows",
																	"id": jobTypeID,
																	"label": Label
																}]
															}
														}
														var LookupServiceResponse = {
															target: lookupURL,
															method: 'POST',
															contentType: 'application/json',
															data: lookupMessage
														};
														var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
														try {
															urlopen.open(LookupServiceResponse, function(error, response) {
																if (error) {
																	var errorinfo = "mopdiscon_034 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
																	ilsctx.setVariable("errorDescription", errorinfo);
																	logger.error("mopdiscon_034 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
																	session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
																} else {
																	// read response data
																	// get the response status code
																	var responseStatusCode = response.statusCode;
																	ctx.setVariable("responseStatusCode", responseStatusCode);
																	if (responseStatusCode == 200) {
																		response.readAsJSON(function(error, responseData) {
																			if (error) {
																				// error while reading response or transferring data to Buffer
																				var errorinfo = "failure in reading message from LookupServiceResponse , details are : " + info + "; error info :" + error;
																				ilsctx.setVariable("errorDescription", errorinfo);
																				logger.error("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
																				session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));

																			} else {
																				if (responseData.lookupRep.type[0].result == 0) {
																					var status = responseData.lookupRep.type[0].status;
																					ctx.setVariable("CompletedLookupStatus", status);
																				} else {
																					var errorinfo = "mopdiscon_037 Lookup response result is 1 , details are : " + info;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error("mopdiscon_037 Lookup response result is 1");
																					session.reject("Lookup response result is 1");
																				}

																			}
																		});
																	} else {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				//dp:reject stop the transaction and go error rule with error code and description
																				var errorinfo = "failure in reading message from lookupresponse , details are : " + info + "; error info :" + error;
																				ilsctx.setVariable("errorDescription", errorinfo);
																				logger.error("failure in reading message from lookupresponse" + JSON.stringify(error));
																				session.reject("failure in reading message from lookupresponse");
																			} else {
																				var errorinfo = "mopdiscon_038 lookup response is  " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
																				ilsctx.setVariable("errorDescription", errorinfo);
																				logger.error("mopdiscon_038 lookup response is  " + responseStatusCode + " " + responseData);
																				session.reject("lookup response is " + responseStatusCode + " " + responseData);
																			}
																		});
																	}
																}
															});
														}
														catch (error) {
															var errorinfo = "mopdiscon_034 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error("mopdiscon_034 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
															session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
														}
													}
												} else {
													var errorinfo = "mopdiscon_031 Lookup response result is not 0";
													ilsctx.setVariable("errorDescription", errorinfo);
													logger.error("mopdiscon_031 Lookup response result is not 0");
													session.reject("Lookup response result is not 0");
												}
											}
										});
									} else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												var errorinfo = "failure in reading message from lookupresponse , details are : " + info + "; error info :" + error;
												ilsctx.setVariable("errorDescription", errorinfo);
												logger.error("failure in reading message from lookupresponse" + JSON.stringify(error));
												session.reject("failure in reading message from lookupresponse");
											} else {
												var errorinfo = "mopdiscon_032 lookup response is  " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
												ilsctx.setVariable("errorDescription", errorinfo);
												logger.error("mopdiscon_032 lookup response is  " + responseStatusCode + " " + responseData);
												session.reject("lookup response is " + responseStatusCode + " " + responseData);
											}
										});
									}
								}
							});
						}
						catch (error) {
							var errorinfo = "mopdiscon_028 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("mopdiscon_028 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
							session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
						}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from GetJobAPI for jobID: " + jobID + " , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("failure in reading message from GetJobAPI for jobID: " + jobID + " " + JSON.stringify(error));
						session.reject("failure in reading message from GetJobAPI for jobID: " + jobID + " " + JSON.stringify(error));
					} else {
						var errorinfo = "mopdiscon_033 GetJobAPI response for jobID: " + jobID + " statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("mopdiscon_033 GetJobAPI response for jobID: " + jobID + " statusCode " + responseStatusCode + " " + responseData);
						session.reject("Error code returned from GetJobAPI for jobID: " + jobID + " statusCode " + responseStatusCode + " " + responseData);
					}
				});
			}
		}
	});
}
catch (error) {
	var errorinfo = "mopdiscon_027 urlopen connect error with Get GetJobUri for jobID " + jobID + " , details are : " + info + "; error info :" + error;
	ilsctx.setVariable("errorDescription", errorinfo);
	logger.error("mopdiscon_027 urlopen connect error with Get GetJobUri for jobID " + jobID + " with error as " + JSON.stringify(error));
	session.reject("urlopen connect error with Get GetJobUri for jobID " + jobID + " with error as " + JSON.stringify(error));
}
