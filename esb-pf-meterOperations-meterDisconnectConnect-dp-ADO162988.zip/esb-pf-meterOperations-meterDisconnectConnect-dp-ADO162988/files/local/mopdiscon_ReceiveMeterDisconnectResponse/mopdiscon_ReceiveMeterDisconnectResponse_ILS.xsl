<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:uuid="java:java.util.UUID"
	extension-element-prefixes="dp dpconfig"
	exclude-result-prefixes="dp da com max sr soapenv dpconfig">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" omit-xml-declaration="no" />
	<xsl:strip-space elements="*" />
	<xsl:param name="dpconfig:reconnectEntryDescription"
		select="''" />
	<xsl:param name="dpconfig:disconnectEntryDescription"
		select="''" />
	<xsl:param name="dpconfig:reconnectSExitDescription"
		select="''" />
	<xsl:param name="dpconfig:disconnectSExitDescription"
		select="''" />
	<xsl:param name="dpconfig:reconnectFExitDescription"
		select="''" />
	<xsl:param name="dpconfig:disconnectFExitDescription"
		select="''" />
	<xsl:param name="dpconfig:messageType" select="''" />
	<xsl:template match="/">
		<xsl:variable name="messageType">
			<xsl:value-of select="$dpconfig:messageType" />
		</xsl:variable>
		<xsl:variable name="reconnectSExitDescription">
			<xsl:value-of
				select="$dpconfig:reconnectSExitDescription" />
		</xsl:variable>
		<xsl:variable name="disconnectSExitDescription">
			<xsl:value-of
				select="$dpconfig:disconnectSExitDescription" />
		</xsl:variable>
		<xsl:variable name="reconnectFExitDescription">
			<xsl:value-of
				select="$dpconfig:reconnectFExitDescription" />
		</xsl:variable>
		<xsl:variable name="disconnectFExitDescription">
			<xsl:value-of
				select="$dpconfig:disconnectFExitDescription" />
		</xsl:variable>
		<xsl:variable name="reconnectEntryDescription">
			<xsl:value-of
				select="$dpconfig:reconnectEntryDescription" />
		</xsl:variable>
		<xsl:variable name="disconnectEntryDescription">
			<xsl:value-of
				select="$dpconfig:disconnectEntryDescription" />
		</xsl:variable>
		<xsl:variable name="status">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Reply']/*[local-name()='ReplyCode']"></xsl:value-of>
				</xsl:when>
				<xsl:when
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Reply']/*[local-name()='ReplyCode']"></xsl:value-of>
				</xsl:when>
			</xsl:choose>
		</xsl:variable>
		<xsl:choose>
			<xsl:when
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']">
				<dp:set-variable
					name="'var://context/ILS/description'"
					value="string($disconnectEntryDescription)" />
				<xsl:choose>
					<xsl:when test=" $status = 'SUCCESS' ">
						<dp:set-variable
							name="'var://context/ILS/exitdescription'"
							value="string($disconnectSExitDescription)" />
					</xsl:when>
					<xsl:otherwise>
						<dp:set-variable
							name="'var://context/ILS/exitdescription'"
							value="string($disconnectFExitDescription)" />
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:when
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']">
				<dp:set-variable
					name="'var://context/ILS/description'"
					value="string($reconnectEntryDescription)" />
				<xsl:choose>
					<xsl:when test=" $status = 'SUCCESS' ">
						<dp:set-variable
							name="'var://context/ILS/exitdescription'"
							value="string($reconnectSExitDescription)" />
					</xsl:when>
					<xsl:otherwise>
						<dp:set-variable
							name="'var://context/ILS/exitdescription'"
							value="string($reconnectFExitDescription)" />
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
		</xsl:choose>
		<xsl:variable name="correlationID">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Header']/*[local-name()='CorrelationID']/text()"></xsl:value-of>
				</xsl:when>
				<xsl:when
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Header']/*[local-name()='CorrelationID']/text()"></xsl:value-of>
				</xsl:when>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="jobID">
			<xsl:value-of
				select="substring-after($correlationID, ':')" />
		</xsl:variable>
		<xsl:variable name="premiseID">
			<xsl:value-of
				select="substring-before($correlationID, ':')" />
		</xsl:variable>
		<xsl:variable name="meterID">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='Assets']/*[local-name()='mRID']/text()"></xsl:value-of>
				</xsl:when>
				<xsl:when
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='Assets']/*[local-name()='mRID']/text()"></xsl:value-of>
				</xsl:when>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="sourceEventTimestamp">
			<xsl:choose>
				<xsl:when
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyDisconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']"></xsl:value-of>
				</xsl:when>
				<xsl:when
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReplyReconnectMeter']/*[local-name()='Payload']/*[local-name()='EndDeviceEvent']/*[local-name()='status']/*[local-name()='dateTime']"></xsl:value-of>
				</xsl:when>
			</xsl:choose>
		</xsl:variable>
		<xsl:if test="$correlationID">
			<dp:set-variable
				name="'var://context/ILS/CorrelationID'" value="$correlationID" />
		</xsl:if>
		<dp:set-variable
			name="'var://context/ILS/messageType'" value="string($messageType)" />
		<xsl:if test="$jobID">
			<dp:set-variable name="'var://context/ILS/jobID'"
				value="string($jobID)" />
		</xsl:if>
		<xsl:if test="$meterID">
			<dp:set-variable name="'var://context/ILS/meterID'"
				value="string($meterID)" />
		</xsl:if>
		<xsl:if test="$premiseID">
			<dp:set-variable name="'var://context/ILS/premiseID'"
				value="string($premiseID)" />
		</xsl:if>
		<xsl:if test="$sourceEventTimestamp">
			<dp:set-variable
				name="'var://context/ILS/sourceEventTimestamp'"
				value="string($sourceEventTimestamp)" />
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>
