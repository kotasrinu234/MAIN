<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:v1="http://reconnectmeter.esm.dteco.com/v1"
    xmlns:v11="http://esm.dteco.com/common/v1"
    xmlns:req="http://reconnect.meteroperations.esm.dteco.com/v1/request"
    xmlns:end="http://iec.ch/TC57/2009/EndDeviceControls#"
    xmlns:dp="http://www.datapower.com/extensions" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:dpfunc="http://www.datapower.com/extensions/functions"
    xmlns:date="http://exslt.org/dates-and-times"
    xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
	extension-element-prefixes="dp" exclude-result-prefixes="dp date dpfunc">
    <xsl:include href="store:///utilities.xsl" />
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" />
    <xsl:strip-space elements="*" />
	<xsl:variable name="Noun">
         <xsl:value-of select="dp:variable('var://context/Meter_Disconnect/Noun')"/>
    </xsl:variable>
    <xsl:template match="/">
        <soapenv:Envelope>
            <soapenv:Header/>
            <soapenv:Body>
                <xsl:choose>
                    <xsl:when test="contains($Noun,'MeterReconnect')">
                        <v1:ReconnectMeter>
                            <xsl:call-template name="Meter_Request"/>
                        </v1:ReconnectMeter>
                    </xsl:when>
                    <xsl:otherwise>
                        <v1:disconnectMeter>
                            <xsl:call-template name="Meter_Request"/>
                        </v1:disconnectMeter>
                    </xsl:otherwise>
                </xsl:choose>
            </soapenv:Body>
        </soapenv:Envelope>
    </xsl:template>
    <xsl:template name="Meter_Request">
        <v11:Header>
            <v11:Verb>
                <xsl:value-of select="'create'"/>
            </v11:Verb>
            <v11:Noun>
                <xsl:value-of select="dp:variable('var://context/Meter_Disconnect/Noun')"/>
            </v11:Noun>
            <xsl:variable name="rightNow" select="date:seconds(date:date-time())"/>
            <xsl:variable name="convertTime" select="dpfunc:zulu-time($rightNow, 'on')"/>
            <xsl:variable name="Result">
                <xsl:value-of select="concat(substring-before($convertTime,'.'),'Z')"/>
            </xsl:variable>
            <v11:Timestamp>
                <xsl:value-of  select="$Result"/>
            </v11:Timestamp>
            <xsl:choose>
                <xsl:when test="contains($Noun,'MeterReconnect')">
                    <v11:Source>
                        <xsl:value-of select="'OMSMETERRECONNECT'"/>
                    </v11:Source>
                    <v11:ReplyAddress>
                        <xsl:value-of select="'METERRECONNECT'"/>
                    </v11:ReplyAddress>
                </xsl:when>
                <xsl:otherwise>
                    <v11:Source>
                        <xsl:value-of select="'OMSMETERDISCONNECT'"/>
                    </v11:Source>
                    <v11:ReplyAddress>
                        <xsl:value-of select="'METERDISCONNECT'"/>
                    </v11:ReplyAddress>
			<v11:AckRequired>
				<xsl:value-of select="'TRUE'"/>
			</v11:AckRequired>
                </xsl:otherwise>
			</xsl:choose>
                <v11:MessageID>
                    <xsl:value-of select="dp:generate-uuid()"/>
                </v11:MessageID>
                <v11:CorrelationID>
                    <xsl:value-of select="dp:variable('var://context/Meter_Disconnect/CorrelationID')"/>
                </v11:CorrelationID>
            </v11:Header>
            <req:Payload>
                <end:EndDeviceControl>
                    <end:type>
                        <xsl:value-of select="dp:variable('var://context/Meter_Disconnect/type')"/>
                    </end:type>
                    <end:EndDeviceAsset>
                        <end:mRID>
                            <xsl:value-of select="dp:variable('var://context/Meter_Disconnect/meterID')"/>
                        </end:mRID>
                    </end:EndDeviceAsset>
                </end:EndDeviceControl>
            </req:Payload>
        </xsl:template>
    </xsl:stylesheet>
