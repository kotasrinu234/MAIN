<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:dp="http://www.datapower.com/extensions"
    xmlns:date="http://exslt.org/dates-and-times"
    xmlns:dpconfig="http://www.datapower.com/param/config"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
    <xsl:output method="text" omit-xml-declaration="yes"/>
    <xsl:param name="dpconfig:MeterReconnectURL"/>
    <xsl:param name="dpconfig:disconnectMeterURL"/>

    <xsl:template match="/">
        <xsl:variable name="InputRequest">
            <xsl:copy-of select="."/>
        </xsl:variable>
        <xsl:variable name="MeterReconnectURL">
            <xsl:value-of select="$dpconfig:MeterReconnectURL" />
        </xsl:variable>
        <xsl:variable name="disconnectMeterURL">
            <xsl:value-of select="$dpconfig:disconnectMeterURL" />
        </xsl:variable>
      
  
        <xsl:variable name="Noun">
            <xsl:value-of select="dp:variable('var://context/Meter_Disconnect/Noun')"/>
        </xsl:variable>
        
        <xsl:variable name="headerValues">
            
        </xsl:variable>
        <xsl:choose>
            <xsl:when test="$Noun='MeterReconnect'">
                <xsl:variable name="AMIResult">
                    <dp:url-open target="{$MeterReconnectURL}" response="responsecode-binary" http-method="post" content-type="application/xml" http-headers="$headerValues" >
                        <xsl:copy-of select="$InputRequest"/>
                    </dp:url-open>
                </xsl:variable>
                <xsl:variable name="responseCode">
                    <xsl:value-of select="$AMIResult/result/responsecode" />
                </xsl:variable>
                <dp:set-variable name="'var://context/Meter_Disconnect/AMIResultResponseCode'" value="string($responseCode)" />
                <xsl:choose>
                    <xsl:when test="$responseCode='200'">
                        <xsl:variable name="AMIAckResponse">
                            <xsl:copy-of
						select="(dp:decode(dp:binary-encode($AMIResult/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
                        </xsl:variable>
                        <dp:set-variable name="'var://context/Meter_Disconnect/AMIAckResponse'" value="string($AMIAckResponse)" />
                         <dp:set-variable name="'var://context/ILS/exitDestination'" value="$MeterReconnectURL" />
                        <xsl:copy-of select="$AMIAckResponse" />
                    </xsl:when>
                    <xsl:otherwise>
						<xsl:message dp:type="all" dp:priority="error">mopdiscon_022 unable to connect to AMI  </xsl:message>
                        <dp:reject> unable to connect to AMI </dp:reject>
                        <xsl:variable name="errorDescription" select="concat($responseCode, $MeterReconnectURL, 'mopdiscon_022 unable to connect to AMI')"/>
                        <dp:set-variable name="'var://context/ILS/errorDescription'" value="$errorDescription" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="$Noun='MeterDisconnect'">
                <xsl:variable name="AMIResult">
                    <dp:url-open target="{$disconnectMeterURL}" response="responsecode-binary" http-method="post" content-type="application/xml" http-headers="$headerValues"  ssl-proxy="client:AMI_Client_Profile" >
                        <xsl:copy-of select="$InputRequest"/>
                    </dp:url-open>
                </xsl:variable>
                <xsl:variable name="responseCode">
                    <xsl:value-of select="$AMIResult/result/responsecode" />
                </xsl:variable>
                <dp:set-variable name="'var://context/Meter_Disconnect/AMIResultResponseCode'" value="string($responseCode)" />
                 <dp:set-variable name="'var://context/ILS/exitDestination'" value="$disconnectMeterURL" />
                <xsl:choose>
                    <xsl:when test="$responseCode='200'">
                        <xsl:variable name="AMIAckResponse">
                            <xsl:copy-of
						select="(dp:decode(dp:binary-encode($AMIResult/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
                        </xsl:variable>
                        <dp:set-variable name="'var://context/Meter_Disconnect/AMIAckResponse'" value="string($AMIAckResponse)" />
                        <xsl:copy-of select="$AMIAckResponse" />
                    </xsl:when>
                    <xsl:otherwise>
						<xsl:message dp:type="all" dp:priority="error">mopdiscon_023 unable to connect to AMI  </xsl:message>
                        <dp:reject> unable to connect to AMI </dp:reject>
                        <xsl:variable name="errorDescription" select="concat($responseCode, $disconnectMeterURL, 'mopdiscon_023 unable to connect to AMI')"/>
                        <dp:set-variable name="'var://context/ILS/errorDescription'" value="$errorDescription" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
        </xsl:choose>
    </xsl:template>
</xsl:stylesheet>
