var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var lookupURL = session.parameters.lookupURL;
var MeterReconnect_type = session.parameters.MeterReconnect_type;
var MeterDisconnect_type = session.parameters.MeterDisconnect_type;
var targetQueue = session.parameters.queueName;
var ilsctx = session.name('ILS') || session.createContext('ILS');
var disexitDescription = session.parameters.sendMeterDisconnectExitDescription;
var reexitDescription = session.parameters.sendMeterReconnectExitDescription;
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		// uncatched error will stop the processing and the error will be logged
		var errorinfo = "mopdiscon_016 Error in reading incoming data ; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("mopdiscon_016 Error in reading incoming data");
		session.reject("Error in reading incoming data")
	} else {
		var status = json.data[0].status;
		var jobTypeID = json.data[0].jobTypeID;
		var externalPremiseID = json.data[0].leadCall.externalPremiseID;
		if (externalPremiseID === null || externalPremiseID === '' || externalPremiseID === undefined) {
			var errorinfo = "mopdiscon_017 externalPremiseID not found.";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("mopdiscon_017 externalPremiseID not found.");
			session.reject('externalPremiseID not found.');
		} else {
			ctx.setVariable("externalPremiseID", externalPremiseID);
		}
		var jobID = json.data[0].leadCall.jobID;
		if (jobID === null || jobID === '' || jobID === undefined) {
			var errorinfo = "mopdiscon_018 jobID not found.";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("mopdiscon_018 jobID not found.");
			session.reject('jobID not found.');
		} else {
			ctx.setVariable("jobID", jobID);
		}
		var CorrelationID = externalPremiseID + ':' + jobID;
		ctx.setVariable("CorrelationID", CorrelationID);
		var meterID = json.data[0].leadCall.meterID;
		if (meterID === null || meterID === '' || meterID === undefined) {
			var errorinfo = "mopdiscon_019 meterID not found.";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("mopdiscon_019 meterID not found.");
			session.reject('meterID not found.');
		} else {
			ctx.setVariable("meterID", meterID);
		}
		var lookupMessage = {
			"lookupReq": {
				"type": [{
					"name": "jobTypes.workflows",
					"id": jobTypeID,
					"status": status
				}]
			}
		}
		var LookupService = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		var info = " TargetURL :" + LookupService.target + "; Method :" + LookupService.method + "; Data :" + JSON.stringify(LookupService.data) + ". ";
		try {
			urlopen.open(LookupService, function(error, response) {
				if (error) {
					var errorinfo = "mopdiscon_020 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error("mopdiscon_020 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
					session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure in reading message from LookupServiceResponse , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
								session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								if (responseData.lookupRep.type[0].result == 0) {
									var label = responseData.lookupRep.type[0].label;
									if (label == 'Re-Connect') {
										var Noun = 'MeterReconnect';
										var type = MeterReconnect_type;
										ctx.setVariable("Noun", Noun);
										ctx.setVariable("type", type);
										ilsctx.setVariable('exitDescription', reexitDescription);
									} else if (label == 'Disconnect') {
										var Noun = 'MeterDisconnect';
										var type = MeterDisconnect_type;
										ctx.setVariable("Noun", Noun);
										ctx.setVariable("type", type);
										ilsctx.setVariable('exitDescription', disexitDescription);
									} else {
										var errorinfo = "mopdiscon_021 Lookup response is neither Re-Connect nor Disconnect , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										logger.error("mopdiscon_021 Lookup response is neither Re-Connect nor Disconnect")
										session.reject("Lookup response is neither Re-Connect nor Disconnect");
									}
								}
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from lookupresponse , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from lookupresponse" + JSON.stringify(error));
								session.reject("failure in reading message from lookupresponse");
							} else {
								var errorinfo = "lookup response is  " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("lookup response is  " + responseStatusCode + " " + responseData);
								session.reject("lookup response is " + responseStatusCode + " " + responseData);
							}
						});
					}
				}
			});
		}
		catch (error) {
			var errorinfo = "mopdiscon_020 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("mopdiscon_020 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
			session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
		}
	}
});
