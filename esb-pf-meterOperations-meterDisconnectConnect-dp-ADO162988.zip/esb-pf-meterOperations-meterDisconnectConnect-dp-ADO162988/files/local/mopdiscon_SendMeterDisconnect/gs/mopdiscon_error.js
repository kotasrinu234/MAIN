var ctx = session.name("Meter_Disconnect") || session.createContext("Meter_Disconnect");
var hm = require('header-metadata');
var sm = require('service-metadata');
var responseStatusCode = ctx.getVariable("responseStatusCode");
var errorCode = sm.getVar('var://service/error-code');
var ilsctx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var errorDescription = ilsctx.getVar("errorDescription");
var errorMessage = sm.getVar('var://service/error-message');
if ((errorCode == '0x00d30003') && (responseStatusCode == '400')) {
	hm.current.statusCode = '400';
}
else {
	hm.current.statusCode = '500';
}
if(errorDescription){
	ilsctx.setVar("errorDescription", errorDescription);
}
else{
	ilsctx.setVar("errorDescription", errorMessage);
}
var obj = {};
obj.errorMessage = sm.getVar('var://service/error-message');
obj.errorCode = sm.getVar('var://service/error-code');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
session.output.write(obj);
