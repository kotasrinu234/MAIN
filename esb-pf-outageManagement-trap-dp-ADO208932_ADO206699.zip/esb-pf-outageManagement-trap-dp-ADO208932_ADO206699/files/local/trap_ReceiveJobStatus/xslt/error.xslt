<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

		<xsl:variable name="TransactionID">
			<xsl:copy-of
				select="dp:variable('var://service/global-transaction-id')" />

		</xsl:variable>
		<xsl:choose>
		<xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
			<xsl:message dp:type="all" dp:priority="error">
				trap_042: AAA failure for OMS username:
				<xsl:value-of
					select="dp:variable('var://context/WSM/identity/username')" />
				ErrorMessage:
				<xsl:value-of
					select="dp:variable('var://service/error-message')" />
				TransactionID:
				<xsl:value-of select="$TransactionID" />
			</xsl:message>
			<xsl:variable name="errorMessage"
				select="concat('trap_042: AAA failure for OMS username:',dp:variable('var://context/WSM/identity/username'),'ErrorMessage: ',dp:variable('var://service/error-message'),' TransactionID: ',$TransactionID)" />
			<dp:set-variable
				name="'var://context/ILS/StepExiterrorinfo'" value="$errorMessage" />
			<dp:set-variable
				name="'var://context/ILS/exitStatus'" value="'401'" />
			<dp:set-variable
				name="'var://service/error-protocol-response'" value="'401'" />
			<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'" />
		</xsl:when>
		
		 <xsl:when test="contains(dp:variable('var://service/error-message'),'Invalid array syntax') or contains(dp:variable('var://service/error-message'),'Invalid JSON format')">
                <xsl:message dp:type="all" dp:priority="error"> trap_043:<xsl:value-of select="dp:variable('var://service/error-message')"/> TransactionID:<xsl:value-of select="$TransactionID"/>
                </xsl:message>
<xsl:variable name="errorMessage" select="concat('trap_043:',dp:variable('var://service/error-message'),'TransactionID: ', $TransactionID)" />

                <dp:set-variable name="'var://context/ILS/StepExiterrorinfo'" value="$errorMessage" />
                
                <dp:set-variable name="'var://context/ILS/exitStatus'" value="'400'"/>
                <dp:set-variable name="'var://service/error-protocol-response'" value="'400'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')"/>
            </xsl:when>
            
            <xsl:when test="contains(dp:variable('var://service/error-message'),'Unable to parse JSON')">
                <xsl:message dp:type="all" dp:priority="error"> trap_043:
                    <xsl:value-of select="dp:variable('var://service/error-message')"/> TransactionID:<xsl:value-of select="$TransactionID"/>
                </xsl:message>
<xsl:variable name="errorMessage" select="concat('trap_043:',dp:variable('var://service/error-message'), 'TransactionID: ', $TransactionID)" />

                <dp:set-variable name="'var://context/ILS/StepExiterrorinfo'" value="$errorMessage" />
                
                <dp:set-variable name="'var://context/ILS/exitStatus'" value="'500'"/>
                <dp:set-variable name="'var://service/error-protocol-response'" value="'500'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')"/>
            </xsl:when>
            
			<xsl:when
				test="contains(dp:variable('var://service/error-code'),'0x01130006' )">

				<xsl:message dp:type="all" dp:priority="error">
					TransactionID:
					<xsl:value-of select="$TransactionID" />
					trap_014 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
					streams ErrorCode:
					<xsl:value-of
						select="dp:variable('var://service/error-headers')" />
				</xsl:message>
			</xsl:when>
			<xsl:otherwise>

				<xsl:message dp:type="all" dp:priority="error">
					TransactionID:
					<xsl:value-of select="$TransactionID" />
					ErrorCode:
					<xsl:value-of
						select="dp:variable('var://service/error-headers')" />
					ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
			</xsl:otherwise>
		</xsl:choose>

		<dp:set-variable
			name="'var://service/error-protocol-reason-phrase'"
			value="concat('TransactionID: ',$TransactionID,' ',dp:variable('var://service/error-message'))" />


	</xsl:template>
</xsl:stylesheet>