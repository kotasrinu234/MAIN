<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:output method="text" omit-xml-declaration="yes" />
	<xsl:param name="dpconfig:meterReadMqUrl" />
	<xsl:param name="dpconfig:meterReadReplyToQ" />
	<xsl:template match="/">
		<xsl:variable name="PresentVoltage">
			<xsl:value-of
				select="dp:variable('var://context/trap/PresentVoltage')" />
		</xsl:variable>
		<xsl:variable name="sourceUrl" select="normalize-space(dp:variable('var://service/URL-in'))" />

		<xsl:choose>
    <xsl:when test="contains($sourceUrl, 'Create')">
<xsl:choose>

			<xsl:when test="$PresentVoltage='yes'"></xsl:when>
			<xsl:otherwise>
				<xsl:variable name="execute">
					<xsl:value-of
						select="dp:variable('var://context/trap/execute')" />
				</xsl:variable>
				<xsl:if test="$execute='yes'">
					<xsl:variable name="odmresponse">
						<xsl:value-of
							select="dp:variable('var://context/trap/odmresponseStatus')" />
					</xsl:variable>
					<xsl:message>
						odmresponsestatus :::

						<xsl:value-of select="$odmresponse" />
					</xsl:message>
					<xsl:if test="$odmresponse='true'">
						<xsl:variable name="displayid">
							<xsl:value-of
								select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='id']/text()" />
						</xsl:variable>
						<xsl:variable name="meterid">
							<xsl:choose>
								<xsl:when
									test="string-length(normalize-space(/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='leadCall']/*[local-name()='string'][@name='meterID']/text()))&gt; 0">
									<xsl:value-of
										select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='leadCall']/*[local-name()='string'][@name='meterID']/text()" />
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of
										select="dp:variable('var://context/trap/meterID')" />
								</xsl:otherwise>
							</xsl:choose>
						</xsl:variable>
						<xsl:variable name="Payload">
							<soapenv:Envelope
								xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope">
								<soapenv:Header>
									<ns1:MultiSpeakMsgHeader
										xmlns:ns1="http://www.multispeak.org/Version_4.1_Release"
										xmlns:mustUnderstand="http://www.w3.org/2003/05/soap-envelope"
										mustUnderstand:mustUnderstand="false" MajorVersion="4"
										MinorVersion="1" Build="3" BuildString="Release" UserID=""
										Pwd="" Company="ESB" />
								</soapenv:Header>
								<soapenv:Body>
									<ns1:InitiateMeterReadingsByMeterID
										xmlns:ns1="http://www.multispeak.org/Version_4.1_Release">
										<ns1:meterIDs>
											<ns1:meterID>
												<xsl:attribute name="meterNo">
														<xsl:value-of select="$meterid" />
													</xsl:attribute>
												<xsl:attribute name="objectID">
														<xsl:value-of select="$meterid" />
													</xsl:attribute>
												<xsl:value-of select="$meterid" />
											</ns1:meterID>
										</ns1:meterIDs>
										<ns1:transactionID>
											<xsl:value-of select="$displayid" />
										</ns1:transactionID>
									</ns1:InitiateMeterReadingsByMeterID>
								</soapenv:Body>
							</soapenv:Envelope>
						</xsl:variable>
						<xsl:variable name="url">
							<xsl:value-of select="$dpconfig:meterReadMqUrl" />
						</xsl:variable>
						<xsl:variable name="MQMDStr">
							<MQMD>
								<ReplyToQ>
									<xsl:value-of select="$dpconfig:meterReadReplyToQ" />
								</ReplyToQ>
							</MQMD>
						</xsl:variable>
						<xsl:variable name="MQMDStr2">
							<dp:serialize select="$MQMDStr" omit-xml-decl="yes" />
						</xsl:variable>
						<xsl:variable name="headers">
							<header name="MQMD">
								<xsl:copy-of select="$MQMDStr2" />
							</header>
						</xsl:variable>
						<xsl:message dp:type="all" dp:priority="debug">
							headers++

							<xsl:value-of select="$headers" />
						</xsl:message>
						<xsl:variable name="datapayload">
							<dp:serialize select="$Payload" />
						</xsl:variable>


						<xsl:variable name="info">
							<xsl:text>TargetURL:</xsl:text>
							<xsl:value-of select="$url" />
							<xsl:text>___Data:</xsl:text>
							<xsl:copy-of select="$datapayload" />
							<xsl:text>.</xsl:text>
						</xsl:variable>
						<xsl:variable name="CallApi">
							<dp:url-open target="{$url}" http-headers="$headers"
								response="responsecode-binary">
								<xsl:copy-of select="$Payload" />
							</dp:url-open>
						</xsl:variable>
						<xsl:variable name="responseCode">
							<xsl:value-of select="$CallApi/result/responsecode" />
						</xsl:variable>
						<dp:set-variable
							name="'var://context/CallAPIResponseCode'" value="$responseCode" />
						<xsl:choose>
							<xsl:when test="$responseCode='0'">
								<dp:set-variable
									name="'var://context/ILS/callcheck'" value="'METERCALL'" />
								<dp:set-variable
									name="'var://context/ILS/MeterPayload'" value="$Payload" />
								<dp:set-variable
									name="'var://context/ILS/MeterUrl'" value="string($url)" />
								<xsl:copy-of select="$Payload" />
							</xsl:when>
							<xsl:otherwise>
								<xsl:variable name="errorstatuscode">
									<xsl:value-of
										select="$CallApi/result/errorstatuscode" />
								</xsl:variable>
								<xsl:variable name="errorstring">
									<xsl:value-of select="$CallApi/result/errorstring" />
								</xsl:variable>
								<xsl:choose>
									<xsl:when
										test="string-length(normalize-space($errorstatuscode))&gt; 0">
										<xsl:message dp:type="all" dp:priority="error">
											trap_030: unable to place message in meter read queue with
											responseCode as

											<xsl:value-of select="$errorstatuscode" />
										</xsl:message>
										<xsl:variable name="errorinfo">
											<xsl:value-of
												select="concat('trap_030: unable to place the message in meter read queue with responseCode as:','500','errorinfo:',$info)" />
										</xsl:variable>
										<dp:set-variable
											name="'var://context/ILS/exitStatus'" value="'500'" />
										<dp:set-variable
											name="'var://context/ILS/StepExiterrorinfo'"
											value="string($errorinfo)" />
										<dp:set-variable
											name="'var://context/ILS/errorMeterPayload'" value="$Payload" />
										<dp:reject>
											<xsl:value-of select="$errorinfo" />
										</dp:reject>
									</xsl:when>
									<xsl:otherwise>
										<xsl:message dp:type="all" dp:priority="error">
											trap_030 unable to place message in meter read queue with
											responseCode as
											<xsl:value-of select="$responseCode" />
										</xsl:message>
										<xsl:variable name="errorinfo">
											<xsl:value-of
												select="concat('trap_030:unable to place message in meter read queue with responseCode as:','500','errorinfo:',$info)" />
										</xsl:variable>
										<dp:set-variable
											name="'var://context/ILS/exitStatus'" value="'500'" />
										<dp:set-variable
											name="'var://context/ILS/StepExiterrorinfo'"
											value="string($errorinfo)" />
										<dp:set-variable
											name="'var://context/ILS/errorMeterPayload'" value="$Payload" />
										<dp:reject>
											<xsl:value-of select="$errorinfo" />
										</dp:reject>
									</xsl:otherwise>
								</xsl:choose>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:if>
				</xsl:if>
			</xsl:otherwise>
			</xsl:choose>

			</xsl:when>
			<xsl:otherwise>
        <xsl:message dp:type="info">SourceUrl is not 'Create'. No action taken.</xsl:message>
    </xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
