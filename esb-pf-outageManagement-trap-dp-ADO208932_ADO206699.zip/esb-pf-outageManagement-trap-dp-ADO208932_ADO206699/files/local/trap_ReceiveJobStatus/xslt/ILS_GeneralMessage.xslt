<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:fo="http://www.w3.org/1999/XSL/Format"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dpconfig="http://www.datapower.com/param/config"
		xmlns:dyn="http://exslt.org/dynamic"
	extension-element-prefixes="dp" exclude-result-prefixes="dp">
	<xsl:output method="xml" encoding="UTF-8" indent="yes"
		cdata-section-elements="v1:RawData"
		xmlns:v1="http://servicelogentry.esm.dteco.com/v1" />
		<xsl:param name="dpconfig:ILSServerUrl"/>	
        <xsl:param name="dpconfig:ILSServerlogging"/>
	<xsl:template match="/">
	<xsl:if test="contains($dpconfig:ILSServerlogging,'yes')">
		<xsl:variable name="ilsprocess">
	<xsl:value-of
				select="dp:variable('var://context/trap/ILSPRROCESS')" />
	</xsl:variable>
	<xsl:message dp:type="all" dp:priority="debug">
	+++<xsl:value-of select="$ilsprocess"/>
	</xsl:message>
	<xsl:if test="contains($ilsprocess,'yes')">
		<xsl:variable name="delimiter" select="'_'" />
		<xsl:variable name="notSetValue" select="'NOT-SET'" />
		<xsl:variable name="MsgIDUnique"
			select="dp:generate-uuid()" />
		<xsl:variable name="SoapMessage">
			<soapenv:Envelope
				xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
				xmlns:v1="http://servicelogentry.esm.dteco.com/v1">
				<soapenv:Header />
				<soapenv:Body>
					<v1:ServiceLogEntry>
						<v1:MessageId>
							<xsl:choose>
								<xsl:when
									test="dp:variable('var://context/ServiceLog/MessageId') = '' or not(dp:variable('var://context/ServiceLog/MessageId'))">
									<xsl:value-of
										select="concat($notSetValue,$delimiter,$MsgIDUnique)" />
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of
										select="dp:variable('var://context/ServiceLog/MessageId')" />
								</xsl:otherwise>
							</xsl:choose>
						</v1:MessageId>
						<v1:LogMsgTimestamp>
							<xsl:choose>
								<xsl:when
									test="dp:variable('var://context/TimeStamp') = '' or not(dp:variable('var://context/TimeStamp'))">
									<xsl:value-of select="date:date-time()" />
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of
										select="dp:variable('var://context/TimeStamp')" />
								</xsl:otherwise>
							</xsl:choose>
						</v1:LogMsgTimestamp>
						<v1:Type>
							<xsl:choose>
								<xsl:when
									test="dp:variable('var://context/ServiceLog/Type') = '' or not(dp:variable('var://context/ServiceLog/Type'))">
									<xsl:value-of select="$notSetValue" />
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of
										select="dp:variable('var://context/ServiceLog/Type')" />
								</xsl:otherwise>
							</xsl:choose>
						</v1:Type>
						<v1:Application>
							<xsl:choose>
								<xsl:when
									test="dp:variable('var://context/ServiceLog/Application') = '' or not(dp:variable('var://context/ServiceLog/Application'))">
									<xsl:value-of select="$notSetValue" />
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of
										select="dp:variable('var://context/ServiceLog/Application')" />
								</xsl:otherwise>
							</xsl:choose>
						</v1:Application>
						<v1:ServiceName>
							<xsl:choose>
								<xsl:when
									test="dp:variable('var://context/ServiceLog/ServiceName') = '' or not(dp:variable('var://context/ServiceLog/ServiceName'))">
									<xsl:value-of
										select="dp:variable('var://service/processor-name')" />
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of
										select="dp:variable('var://context/ServiceLog/ServiceName')" />
								</xsl:otherwise>
							</xsl:choose>
						</v1:ServiceName>
						<v1:System>
							<xsl:choose>
								<xsl:when
									test="dp:variable('var://context/ServiceLog/System') = '' or not(dp:variable('var://context/ServiceLog/System'))">
									<xsl:value-of
										select="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))" />
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of
										select="dp:variable('var://context/ServiceLog/System')" />
								</xsl:otherwise>
							</xsl:choose>
						</v1:System>
						<v1:User>
							<xsl:choose>
								<xsl:when
									test="dp:variable('var://context/ServiceLog/User') = '' or not(dp:variable('var://context/ServiceLog/User'))">
									<xsl:value-of select="$notSetValue" />
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of
										select="dp:variable('var://context/ServiceLog/User')" />
								</xsl:otherwise>
							</xsl:choose>
						</v1:User>
						<v1:Context>
						<xsl:if
							test="dp:variable('var://context/ServiceLog/ContextElement1') != ''">

								<xsl:value-of
									select="dp:variable('var://context/ServiceLog/ContextElement1')" />
						</xsl:if>
							</v1:Context>

							<v1:Context>
						<xsl:if
							test="dp:variable('var://context/ServiceLog/ContextElement2') != ''">

								<xsl:value-of
									select="dp:variable('var://context/ServiceLog/ContextElement2')" />
						</xsl:if>
							</v1:Context>
						
						<v1:Context>
							<xsl:if
								test="dp:variable('var://context/ServiceLog/ContextElement3') != ''">

								<xsl:value-of
									select="dp:variable('var://context/ServiceLog/ContextElement3')" />
								</xsl:if>
						</v1:Context>
							
						<v1:Context>						
					<xsl:if
								test="dp:variable('var://context/ServiceLog/ContextElement4') != ''">

								<xsl:value-of
									select="dp:variable('var://context/ServiceLog/ContextElement4')" />
								</xsl:if>
								</v1:Context>
					
						<v1:Context>																
							<xsl:if
								test="dp:variable('var://context/ServiceLog/ContextElement5') != ''">
								<xsl:value-of
									select="dp:variable('var://context/ServiceLog/ContextElement5')" />
							</xsl:if>
						</v1:Context>
					<v1:RawData>
							<xsl:if test="dp:variable('var://context/ServiceLog/RawData') != ''">
								<xsl:value-of select="dp:variable('var://context/ServiceLog/RawData')"/>
							</xsl:if>
					</v1:RawData>
					

					</v1:ServiceLogEntry>
				</soapenv:Body>
			</soapenv:Envelope>
		</xsl:variable>
		<xsl:variable name="url">
			<xsl:value-of select="$dpconfig:ILSServerUrl" />
		</xsl:variable>
		<xsl:variable name="headerValues">
			<header name="Content-Type">text/xml</header>
		</xsl:variable>

		<xsl:variable name="ILS_Logging_Response">
			<dp:url-open target="{$url}" ssl-proxy=""
				http-headers="$headerValues" http-method="post"
				response="responsecode-binary">
				<xsl:copy-of select="$SoapMessage" />
			</dp:url-open>
		</xsl:variable>
<xsl:variable name="ILSApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($ILS_Logging_Response/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
		<dp:set-variable name="'var://context/ILSAPIResponseCode'" value="$ILSApiResponse" />
		</xsl:if>
		</xsl:if>
			</xsl:template>
</xsl:stylesheet>
