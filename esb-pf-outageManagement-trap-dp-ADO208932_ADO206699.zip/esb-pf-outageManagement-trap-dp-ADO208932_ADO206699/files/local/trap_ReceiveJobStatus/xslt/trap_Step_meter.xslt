<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:output method="text" omit-xml-declaration="yes"/>
	<xsl:param name="dpconfig:BackoutQueueUrlMeterReadService"/>
	<xsl:template match="/">
		<xsl:variable name="callcheck">
			<xsl:copy-of select="dp:variable('var://context/ILS/callcheck')"/>
		</xsl:variable>
		<xsl:if test="contains($callcheck, 'ODMCALL')">
		
		<xsl:variable name="ODMPayload">
				<xsl:copy-of select="."/>
		</xsl:variable>
		
		<xsl:copy-of select="$ODMPayload"/>
		
		</xsl:if>
		
		<xsl:if test="contains($callcheck, 'METERCALL')">
		<xsl:variable name="MeterPayload"
				select="dp:variable('var://context/ILS/MeterPayload')" />
				
		<xsl:variable name="StepexitDestination">
			<xsl:copy-of select="dp:variable('var://context/ILS/MeterUrl')"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/StepexitDestination'" value="string($StepexitDestination)"/>
		
		<xsl:variable name="meterdescription">
			<xsl:copy-of select="dp:variable('var://context/ILS/MeterStepExitDescription')"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/description'" value="string($meterdescription)"/>

		<xsl:copy-of select="dp:variable('var://context/ILS/MeterPayload')"/>
		
		</xsl:if>
		
		
		<xsl:if test="contains($callcheck, 'GetToken')">
		
		<xsl:variable name="GetToken">
				<xsl:copy-of select="."/>
		</xsl:variable>
		
		<xsl:copy-of select="$GetToken"/>
		
		</xsl:if>
		
		
		<xsl:if test="contains($callcheck, 'MeterInfo')">
		
		<xsl:variable name="MeterInfo">
				<xsl:copy-of select="."/>
		</xsl:variable>
		
		<xsl:copy-of select="$MeterInfo"/>
		
		</xsl:if>
		
		<xsl:if test="contains($callcheck, 'ODMNotOkToProceed')">
		
		<xsl:variable name="ODMNotOkToProceed">
				<xsl:copy-of select="."/>
		</xsl:variable>
		
		<xsl:copy-of select="$ODMNotOkToProceed"/>
		
		</xsl:if>
		<xsl:if test="contains($callcheck, 'JobNoLonger')">
		
		<xsl:variable name="JobNoLonger">
				<xsl:copy-of select="."/>
		</xsl:variable>
		
		<xsl:copy-of select="$JobNoLonger"/>
		
		</xsl:if>
		
	</xsl:template>
</xsl:stylesheet>
