var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("trap") || session.createContext("trap");
	var Premisephasescheck = ctx.getVar("Premisephasescheck");
	var ctx = session.name("trap") || session.createContext("trap");
	var ILSctx = session.name("ILS") || session.createContext("ILS");
	var sourceUrl = sm.getVar('var://service/URL-in');
	var execute = ctx.getVar("execute");

	var lookupRequired = sourceUrl.includes("NoLongerSingleJob");

	if (lookupRequired) {
		// Job status lookup start

		var ctx = session.name("trap") || session.createContext("trap");
		var lookupURL = ctx.getVar("lookupURL");
		var omsExternalURL = ctx.getVar("omsExternalURL");
		var apiToken = ctx.getVar("apiToken");

		if (readAsJSONError) {
			logger.error("Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {

			// jobTypeID && status Lookup Start
			var jobTypeID = incomingdata.data[0].jobTypeID;
			var status = incomingdata.data[0].status;
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "jobTypes.workflows",
						"id": jobTypeID,
						"status": status
					}]
				}
			}
			var url = lookupURL;
			var LookupServiceResponse = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};

			var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "trap_023: urlopen connect error with LookupServiceResponse for jobtypeid, details are: " + info + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500")
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading error message from with LookupServiceResponse for jobtypeid, details are: " + info + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from LookupServiceResponse " + responseStatusCode);
								var lookupResponse = JSON.parse(responseData)

								//	logger.error("response"+LookupServiceResponse);		
								var ctx = session.name("trap") || session.createContext("trap");
								if (lookupResponse.lookupRep.type[0].result == 0) {
									var label = lookupResponse.lookupRep.type[0].label;
									ctx.setVariable("label", label);
								} else {
									var label = "";
									ctx.setVariable("label", label);
									var errorinfo = "trap_024: lookupresponse for jobTypeID doesn't have a return label ,result =1 details are" + info
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", "400");
									logger.error(errorinfo);
									session.reject(errorinfo);
								} // lookup end;

								// outagesubtypeID lookup Start

								if (incomingdata.data[0].outageSubtypeID == undefined || incomingdata.data[0].outageSubtypeID == null || incomingdata.data[0].outageSubtypeID == '') {
									var errorinfo = "outageSubtypeID is not present in input job payload details are" + info
									//ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									//ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									//session.reject(errorinfo);
								} else {
									var outageSubtypeID = incomingdata.data[0].outageSubtypeID;
									logger.debug("outage id is +++" + outageSubtypeID);

									var lookupMessage = {
										"lookupReq": {
											"type": [{
												"name": "outageSubtypes",
												"id": outageSubtypeID
											}]
										}
									}
									var url = lookupURL;
									//invoking lookup service and storing response in a var
									var LookupServiceResponse = {
										target: url,
										method: 'POST',
										contentType: 'application/json',
										data: lookupMessage
									};
									var info = " TargetURL :" + url + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";
									urlopen.open(LookupServiceResponse, function(error, response) {
										if (error) {
											var errorinfo = "trap_022: urlopen connect error with LookupServiceResponse for outageSubtypeID details are ," + info + "error info :" + JSON.stringify(error)
											ILSctx.setVariable("StepExiterrorinfo", errorinfo);
											ILSctx.setVariable("exitStatus", "500");
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											// read response data
											// get the response status code
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														// error while reading response or transferring data to Buffer
														var errorinfo = "Failure in reading error message from LookupServiceResponse for outageSubtypeID details are ," + info + "error info :" + JSON.stringify(error)
														ILSctx.setVariable("StepExiterrorinfo", errorinfo);
														ILSctx.setVariable("exitStatus", responseStatusCode);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														hm.response.statusCode = responseStatusCode;
														logger.debug("response code received from trap_ReceiveJobStatus outageSubtypes LookupServiceResponse " + responseStatusCode);
														//session.output.write(JSON.parse(responseData));
														var lookupResponse = JSON.parse(responseData)
														var outageSubtypeIDlabel;
														if (lookupResponse.lookupRep.type[0].result == '0') {
															outageSubtypeIDlabel = lookupResponse.lookupRep.type[0].label;
															var ctx = session.name("trap") || session.createContext("trap");
															ctx.setVariable("outageSubtypeIDlabel", outageSubtypeIDlabel);
														} else {
															var errorinfo = "trap_025: outageSubtypes lookupresponse doesn't have a return label ,result =1 details are" + info
															ILSctx.setVariable("StepExiterrorinfo", errorinfo);
															ILSctx.setVariable("exitStatus", "400");
															session.reject("outageSubtypes lookupresponse doesn't have a return label ,result =1");
														}
													}
												});
											} else {
												var errorinfo = "trap_026:Error response from LookupService for outageSubtypeID, details are: " + info + "ResponseStatusCode : " + responseStatusCode
												ILSctx.setVariable("StepExiterrorinfo", errorinfo);
												ILSctx.setVariable("exitStatus", "400");
												logger.error(errorinfo);
												session.reject(errorinfo);
											}

										}
									});   								//outagesubtypeIdD lookup end	
								}
							}
						});

					} else {
						var errorinfo = "trap_027:Error response from LookupService for jobtypeid, details are: " + info + "ResponseStatusCode : " + responseStatusCode
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "400");
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				}
			});    			// jobTypeID && status Lookup End
		}
	}
	if (sourceUrl.includes("Update") || sourceUrl.includes("NoLongerSingleJob")) {
		// GET Token START

		var GetTokenExitDescription = session.parameters.GetTokenStepExitDescription
		var GetTokenUrl = session.parameters.GetTokenUrl
		var Options = {
			target: GetTokenUrl,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'GET',
			contentType: 'application/json'
		};

		var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
		urlopen.open(Options, function(error, response) {
			if (error) {
				var errorinfo = "trap_028: urlopen connect error of GetTokenURL, details are: " + info + JSON.stringify(error)
				ILSctx.setVariable("exitStatus", "500");
				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "Failure in reading response of GetTokenURL, details are: " + info + JSON.stringify(error)
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = '200 OK';
							ctx.setVariable("Responseget", responseData);
							var AccessToken = responseData.access_token;
							logger.debug("response received :" + JSON.stringify(responseData));
							if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
								logger.error("Invalid token response  " + JSON.stringify(responseData));
							} else {
								var AccessToken = responseData.access_token;
								var TokenType = responseData.token_type;
								ctx.setVariable("ResponseGET", responseData);
								ILSctx.setVariable("callcheck", "GetToken");
								ILSctx.setVariable("GetTokenurl", GetTokenUrl);
								ILSctx.setVariable("GetTokenPayload", responseData);
								ILSctx.setVariable("GetTokenStepExitDescription", GetTokenExitDescription);
								ms.callRule('trap_ReceiveJobStatus_policy_STEP_EXIT_ILS', null, null, function(error) {
									if (error) {
										logger.error("Error trap_ReceiveJobStatus_policy_STEP_EXIT_ILS");
									}
								});
								var Auth = TokenType + ' ' + AccessToken;
								ctx.setVariable("Auth", Auth);
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "Error response received from GetTokenURL, details are: " + info + JSON.stringify(error)
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.current.statusCode = responseStatusCode;
							var errorinfo = "trap_029: Error returned from GetTokenURL, details are: " + info + ": with statusCode " + responseStatusCode + " " + responseData
							logger.error(errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		});

		// GET Token END
	}
});
