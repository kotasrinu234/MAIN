var fs = require('fs');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("trap") || session.createContext("trap");
		var lookupURL = session.parameters.lookUpURL;
		var omsExternalURL = session.parameters.omsExternalURL;
		var omsExternalURLV1 = session.parameters.omsExternalURLV1;
		var apiToken = session.parameters.osiApiToken;
		var ODMEndpoint = session.parameters.ODMEndpoint;
		var ODMCredentials = session.parameters.ODMCredentials;
		var StreamuriNEW = session.parameters.StreamuriNEW;
		var StreamuriUPD = session.parameters.StreamuriUPD;
		var ILSServerUrl = session.parameters.ILSServerUrl;
		var ILSServerlogging = session.parameters.ILSServerlogging;
		ctx.setVariable("lookupURL", lookupURL);
		ctx.setVariable("omsExternalURL", omsExternalURL);
		ctx.setVariable("omsExternalURLV1", omsExternalURLV1);
		ctx.setVariable("apiToken", apiToken);
		ctx.setVariable("ODMEndpoint", ODMEndpoint);
		ctx.setVariable("ODMCredentials", ODMCredentials);
		ctx.setVariable("StreamuriNEW", StreamuriNEW);
		ctx.setVariable("StreamuriUPD", StreamuriUPD);
		ctx.setVariable("ILSServerUrl", ILSServerUrl);
		ctx.setVariable("ILSServerlogging", ILSServerlogging);
		
		var correlationID = incomingdata.data[0].id;
		var messageType = session.parameters.messageType;
		var jobDisplayID
		if (!(incomingdata.data[0].displayID == null || incomingdata.data[0].displayID == undefined)) {
			jobDisplayID = incomingdata.data[0].displayID;
			ILSctx.setVariable("jobDisplayID", jobDisplayID);
		}

		var jobID;
		if (!(incomingdata.data[0].id == null || incomingdata.data[0].id == undefined)) {
			jobID = incomingdata.data[0].id;
			ILSctx.setVariable("jobID", jobID);
		}
		var meterID;
		var premiseID;
		var externalCallCodeID;
		if (!(incomingdata.data[0].leadCall == null || incomingdata.data[0].leadCall == undefined)) {
			if (!(incomingdata.data[0].leadCall.meterID == null || incomingdata.data[0].leadCall.meterID == undefined)) {
				meterID = incomingdata.data[0].leadCall.meterID;
				ILSctx.setVariable("meterID", meterID);
			}
			if (!(incomingdata.data[0].leadCall.externalPremiseID == null || incomingdata.data[0].leadCall.externalPremiseID == undefined)) {
				premiseID = incomingdata.data[0].leadCall.externalPremiseID;
				ILSctx.setVariable("premiseID", premiseID);
			}
			if (!(incomingdata.data[0].leadCall.externalCallCodeID == null || incomingdata.data[0].leadCall.externalCallCodeID == undefined || incomingdata.data[0].leadCall.externalCallCodeID == '')) {
				externalCallCodeID = incomingdata.data[0].leadCall.externalCallCodeID;
				ILSctx.setVariable("callCode", externalCallCodeID);
			}

		}
		var sourceEventTimestamp;
		if (!(incomingdata.data[0].updatedAt == null || incomingdata.data[0].updatedAt == undefined || incomingdata.data[0].createdAt == '')) {
			sourceEventTimestamp = incomingdata.data[0].updatedAt
			ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		else {
			if (!(incomingdata.data[0].createdAt == null || incomingdata.data[0].createdAt == undefined || incomingdata.data[0].createdAt == '')) {
				sourceEventTimestamp = incomingdata.data[0].createdAt
				ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
			}
		}
		var sourceUrl = sm.getVar('var://service/URL-in');
		var EntryDescription = session.parameters.EntryDescription;
		var JobUpdateEntryDescription = session.parameters.JobUpdateEntryDescription;
		var JobNoLongerEntryDescription = session.parameters.JobNoLongerEntryDescription;
		var OdmStepExitDescription = session.parameters.OdmStepExitDescription;
		var MeterStepExitDescription = session.parameters.MeterStepExitDescription;
		ILSctx.setVariable("correlationID", correlationID);
		ILSctx.setVariable("messageType", messageType);
		ILSctx.setVariable("sourceUrl", sourceUrl);
		if (sourceUrl.includes('NoLongerSingleJob')) {
			ILSctx.setVariable("EntryDescription", JobNoLongerEntryDescription);
		} else if (sourceUrl.includes('Update')) {
			ILSctx.setVariable("EntryDescription", JobUpdateEntryDescription);
		} else {
			ILSctx.setVariable("EntryDescription", EntryDescription);
		}
		ILSctx.setVariable("OdmStepExitDescription", OdmStepExitDescription);
		ILSctx.setVariable("MeterStepExitDescription", MeterStepExitDescription);
	}
});
