//js is used to perform streams call
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var util = require('util');
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("trap") || session.createContext("trap");
var eventHubURL = "https://" + session.parameters.Hub_NameSpace + ".servicebus.windows.net/" + session.parameters.eventHub + "/messages";
var Auth = ctx.getVar("Auth");
session.input.readAsJSON(async function(readAsJSONError, incomingdata) {
	var ctx = session.name("trap") || session.createContext("trap");
	var apiToken = session.parameters.osiApiToken;
	var eventTimeStamp = new Date().toISOString();
	var execute = ctx.getVar("execute");
	var CEP = ctx.getVar("CepCall");
	var meterID = ctx.getVar("meterID");
	var StreamuriNEW = ctx.getVar("StreamuriNEW");

	//reading the premisid and  externalCallCodeID value from ctx
	var externalCallCodeID = ctx.getVar("externalCallCodeID");
	var premiseId = ctx.getVar("premiseId");
	var UpdateMeterID = ctx.getVar("UpdateMeterID");
	var sourceUrl = sm.getVar('var://service/URL-in');
	if (sourceUrl.includes('Create')) {
		if (CEP == "no") {
			if (execute == 'yes') {
				if (incomingdata.data[0].leadCall != undefined) {
					if (incomingdata.data[0].leadCall.meterID != undefined) {
						var meterId = incomingdata.data[0].leadCall.meterID;
					} else {
						//reading from ctx variable meterid from call api repsonse
						var meterId = meterID;

					}
				} else {
					//reading from ctx variable meterid from call api repsonse
					var meterId = meterID;
				}

				var jobCreatedTS = incomingdata.data[0].createdAt;
				var MSGTYPE = "JobData";
				var JOBID = incomingdata.data[0].id;
				var outageSubtypeslabel = ctx.getVar("outageSubtypeslabel");
				var jobSubType = outageSubtypeslabel;
				var jobStatus = "New";

				var MeterData = ctx.getVar("GetMeterInfo");
				var Phase = MeterData.meterPhase;
				var odmresponse = ctx.getVar("odmresponse");
				var odmresponsestatus = ctx.getVar("odmresponseStatus");
				if (Phase == "SINGLEPHASE") {

					var nomva = MeterData.nominalVoltageA;
					var payload = {
						"msgType": MSGTYPE,
						"jobId": JOBID,
						"jobType": externalCallCodeID,
						"jobSubType": jobSubType,
						"jobStatus": jobStatus,
						"premiseId": premiseId,
						"meterId": meterId,
						"nomVa": nomva,
						"jobCreatedTS": jobCreatedTS,
						"eventTimeStamp":eventTimeStamp

					};

					if (odmresponse.response.inEfoOfficeHours === true) {
						payload.inOfficeHrs = "Y";
					} else {
						payload.inOfficeHrs = "N";
					}
					if (odmresponse.autoCloseAndDispatchParameters.autoDispatchEnabled === true) {
						payload.AutoDispFSA = "Y";
					} else {
						payload.AutoDispFSA = "N";
					}

					payload.autoCloseStdDuration = odmresponse.autoCloseAndDispatchParameters.autoCloseTimeWindow;

					payload.maxPercentageVolatageDiff = odmresponse.autoCloseAndDispatchParameters.maxPercentageVoltageDiff;

					if ((MeterData.voltageReadResult == undefined) || (MeterData.voltageReadResult == '') || (MeterData.voltageReadResult == null)) {
						payload.meterReadTS = "";
					} else {
						if ((MeterData.voltageReadResult.meterReadintTS == undefined) || (MeterData.voltageReadResult.meterReadintTS == '') || (MeterData.voltageReadResult.meterReadintTS == null)) {
							payload.meterReadTS = "";
						} else {
							payload.meterReadTS = meterReadintTS;
						}
					}

					var arr = [{
						"originalExemptJobType": "",
						"resultingChangeToJobType": ""
					}];

					arr[0].originalExemptJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].originalExemptCallCode;
					arr[0].resultingChangeToJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].resultingChangeToCallCode;

					payload.exemptJobAutoChangeParameters = arr;
				} else {
					var nomva = MeterData.nominalVoltageA;
					var nomvb = MeterData.nominalVoltageB;
					var nomvc = MeterData.nominalVoltageC;

					var payload = {
						"msgType": MSGTYPE,
						"jobId": JOBID,
						"jobType": externalCallCodeID,
						"jobSubType": jobSubType,
						"jobStatus": jobStatus,
						"premiseId": premiseId,
						"meterId": meterId,
						"nomVa": nomva,
						"nomVb": nomvb,
						"nomVc": nomvc,
						"jobCreatedTS": jobCreatedTS,
						"eventTimeStamp":eventTimeStamp

					};

					if (odmresponse.response.inEfoOfficeHours === true) {
						payload.inOfficeHrs = "Y";
					} else {
						payload.inOfficeHrs = "N";
					}
					if (odmresponse.autoCloseAndDispatchParameters.autoDispatchEnabled === true) {
						payload.AutoDispFSA = "Y";
					} else {
						payload.AutoDispFSA = "N";
					}

					payload.autoCloseStdDuration = odmresponse.autoCloseAndDispatchParameters.autoCloseTimeWindow;

					payload.maxPercentageVolatageDiff = odmresponse.autoCloseAndDispatchParameters.maxPercentageVoltageDiff;

					if ((MeterData.voltageReadResult == undefined) || (MeterData.voltageReadResult == '') || (MeterData.voltageReadResult == null)) {
						payload.meterReadTS = "";
					} else {
						if ((MeterData.voltageReadResult.meterReadintTS == undefined) || (MeterData.voltageReadResult.meterReadintTS == '') || (MeterData.voltageReadResult.meterReadintTS == null)) {
							payload.meterReadTS = "";
						} else {
							payload.meterReadTS = meterReadintTS;
						}
					}

					var arr = [{
						"originalExemptJobType": "",
						"resultingChangeToJobType": ""
					}];

					arr[0].originalExemptJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].originalExemptCallCode;
					arr[0].resultingChangeToJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].resultingChangeToCallCode;

					payload.exemptJobAutoChangeParameters = arr;
				};

				var eventHubCall = {
					target: eventHubURL,
					sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
					method: 'POST',
					headers: {
						'Authorization': Auth,
					},
					contentType: 'application/json',
					data: payload
				};

				CepCall(eventHubCall, payload, eventHubURL);
				ILSctx.setVariable("exitDestination", eventHubURL);
				ILSctx.setVariable("exitStatus", "0");
				var ExitDescription = session.parameters.ExitDescription;
				ILSctx.setVariable("ExitDescription", ExitDescription);
				session.output.write(payload);
			}
		} else {
			if (execute == 'yes') {
				// getting styleheet params
				var ctx = session.name("trap") || session.createContext("trap");
				var lookupURL = ctx.getVar("lookupURL");
				var omsExternalURL = ctx.getVar("omsExternalURL");
				var apiToken = ctx.getVar("apiToken");
				var odmresponse = ctx.getVar("odmresponse");
				var odmresponsestatus = ctx.getVar("odmresponseStatus");
				var StreamuriNEW = ctx.getVar("StreamuriNEW");
				var StreamuriUPD = ctx.getVar("StreamuriUPD");
				var meterID = ctx.getVar("meterID");
				var lookuplabel = ctx.getVar("lookuplabel");
				if (odmresponsestatus == true) {
					var JOBID = incomingdata.data[0].id;
					var externalCallCodeID = externalCallCodeID;
					var ctx = session.name("trap") || session.createContext("trap");
					var outageSubtypeslabel = ctx.getVar("outageSubtypeslabel");
					var jobSubType = outageSubtypeslabel;

					var jobStatus = "New";
					var MSGTYPE = "JobData";

					if (incomingdata.data[0].leadCall != undefined) {
						if (incomingdata.data[0].leadCall.meterID != undefined) {
							var meterId = incomingdata.data[0].leadCall.meterID;
						} else {
							//reading from ctx variable meterid from call api repsonse
							var meterId = meterID;

						}
					} else {
						//reading from ctx variable meterid from call api repsonse
						var meterId = meterID;
					}

					var jobCreatedTS = incomingdata.data[0].createdAt;
					if ((externalCallCodeID == undefined) || (externalCallCodeID == '') || (externalCallCodeID == null)) {
						externalCallCodeID = '';
					} else {
						externalCallCodeID = externalCallCodeID;
					}

					var MeterData = ctx.getVar("GetMeterInfo");
					var Phase = MeterData.meterPhase;
					if (Phase == "SINGLEPHASE") {
						var nomva = MeterData.nominalVoltageA;
						var payload = {
							"msgType": MSGTYPE,
							"jobId": JOBID,
							"jobType": externalCallCodeID,
							"jobSubType": jobSubType,
							"jobStatus": jobStatus,
							"meterId": meterId,
							"premiseId": premiseId,
							//"AutoDispFSA": "Y",
							"nomVa": nomva,
							"jobCreatedTS": jobCreatedTS,
							"eventTimeStamp":eventTimeStamp

						};
						var MeterReadingInstA = MeterData.voltageReadResult.meterVoltageReadingInstA;
						if ((MeterReadingInstA == undefined) || (MeterReadingInstA == '') || (MeterReadingInstA == null)) {
							payload.meterVa = "";
						} else {
							payload.meterVa = MeterReadingInstA;
						}

						if (odmresponse.response.inEfoOfficeHours === true) {
							payload.inOfficeHrs = "Y";
						} else {
							payload.inOfficeHrs = "N";
						}
						if (odmresponse.autoCloseAndDispatchParameters.autoDispatchEnabled === true) {
							payload.AutoDispFSA = "Y";
						} else {
							payload.AutoDispFSA = "N";
						}

						payload.autoCloseStdDuration = odmresponse.autoCloseAndDispatchParameters.autoCloseTimeWindow;

						payload.maxPercentageVolatageDiff = odmresponse.autoCloseAndDispatchParameters.maxPercentageVoltageDiff;

						if ((MeterData.voltageReadResult == undefined) || (MeterData.voltageReadResult == '') || (MeterData.voltageReadResult == null)) {
							payload.meterReadTS = "";
						} else {
							if ((MeterData.voltageReadResult.meterReadintTS == undefined) || (MeterData.voltageReadResult.meterReadintTS == '') || (MeterData.voltageReadResult.meterReadintTS == null)) {
								payload.meterReadTS = "";
							} else {
								payload.meterReadTS = meterReadintTS;
							}
						}

						var arr = [{
							"originalExemptJobType": "",
							"resultingChangeToJobType": ""
						}];

						arr[0].originalExemptJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].originalExemptCallCode;
						arr[0].resultingChangeToJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].resultingChangeToCallCode;

						payload.exemptJobAutoChangeParameters = arr;

					} else {
						var nomva = MeterData.nominalVoltageA;
						var nomvb = MeterData.nominalVoltageB;
						var nomvc = MeterData.nominalVoltageC;

						var payload = {
							"msgType": MSGTYPE,
							"jobId": JOBID,
							"jobType": externalCallCodeID,
							"jobSubType": jobSubType,
							"jobStatus": jobStatus,
							"meterId": meterId,
							"premiseId": premiseId,
							//"AutoDispFSA": "Y",
							"nomVa": nomva,
							"nomVb": nomvb,
							"nomVc": nomvc,
							"jobCreatedTS": jobCreatedTS,
							"eventTimeStamp":eventTimeStamp

						}

						var MeterReadingInstA = MeterData.voltageReadResult.meterVoltageReadingInstA;
						if ((MeterReadingInstA == undefined) || (MeterReadingInstA == '') || (MeterReadingInstA == null)) {
							payload.meterVa = "0";
						} else {
							payload.meterVa = MeterReadingInstA;
						}

						var MeterReadingInstB = MeterData.voltageReadResult.meterVoltageReadingInstB;
						if ((MeterReadingInstB == undefined) || (MeterReadingInstB == '') || (MeterReadingInstB == null)) {
							payload.meterVb = "0";
						} else {
							payload.meterVb = MeterReadingInstB;
						}

						var MeterReadingInstC = MeterData.voltageReadResult.meterVoltageReadingInstC;
						if ((MeterReadingInstC == undefined) || (MeterReadingInstC == '') || (MeterReadingInstC == null)) {
							payload.meterVc = "0";
						} else {
							payload.meterVc = MeterReadingInstC;
						}

						if (odmresponse.response.inEfoOfficeHours === true) {
							payload.inOfficeHrs = "Y";
						} else {
							payload.inOfficeHrs = "N";
						}
						if (odmresponse.autoCloseAndDispatchParameters.autoDispatchEnabled === true) {
							payload.AutoDispFSA = "Y";
						} else {
							payload.AutoDispFSA = "N";
						}

						payload.autoCloseStdDuration = odmresponse.autoCloseAndDispatchParameters.autoCloseTimeWindow;

						payload.maxPercentageVolatageDiff = odmresponse.autoCloseAndDispatchParameters.maxPercentageVoltageDiff;

						var meterReadintTS = MeterData.voltageReadResult.meterReadintTS;
						if ((meterReadintTS == undefined) || (meterReadintTS == '') || (meterReadintTS == null)) {
							payload.meterReadTS = "";
						} else {
							payload.meterReadTS = meterReadintTS;
						}

						var arr = [{
							"originalExemptJobType": "",
							"resultingChangeToJobType": ""
						}];

						arr[0].originalExemptJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].originalExemptCallCode;
						arr[0].resultingChangeToJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].resultingChangeToCallCode;

						payload.exemptJobAutoChangeParameters = arr;
					}
					var eventHubCall = {
						target: eventHubURL,
						sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
						method: 'POST',
						headers: {
							'Authorization': Auth,
						},
						contentType: 'application/json',
						data: payload
					};

					CepCall(eventHubCall, payload, eventHubURL);
					ILSctx.setVariable("exitDestination", eventHubURL);
					ILSctx.setVariable("exitStatus", "0");
					var ExitDescription = session.parameters.ExitDescription;
					ILSctx.setVariable("ExitDescription", ExitDescription);
					session.output.write(payload);

				} else {
					session.output.write(incomingdata);
					logger.debug("odmresponsestatus status is not true");

				}
			} // execute is not true 

		}
	}
	//Create END 
	else {
		var ctx = session.name("trap") || session.createContext("trap");
		var streamuri = ctx.getVar("streamuri");
		var meterID = ctx.getVar("meterID");
		var CrewLookuplabel = ctx.getVar("CrewLookuplabel");
		var label = ctx.getVar("label");
		var JOBID = incomingdata.data[0].id;
		var ctx = session.name("trap") || session.createContext("trap");
		var outageSubtypeIDlabel = ctx.getVar("outageSubtypeIDlabel");
		var jobSubType = outageSubtypeIDlabel;
		if (jobSubType == undefined || jobSubType == null || jobSubType == '') {
			jobSubType = '';
		} else {
			jobSubType = jobSubType;
		}
		var jobStatus = label;
		var crewStatus = CrewLookuplabel;

		if (incomingdata.data[0].leadCall != undefined) {
			if (incomingdata.data[0].leadCall.meterID != undefined) {
				var meterId = incomingdata.data[0].leadCall.meterID;
			} else {
				//reading from ctx variable
				var meterId = meterID;
			}
		} else {
			//reading from ctx variable
			var meterId = meterID;
		}
		
		if ((incomingdata.eventTime === undefined) || (incomingdata.eventTime === null) || (incomingdata.eventTime === '')){
			
			if ((incomingdata.data[0].updatedAt === undefined) || (incomingdata.data[0].updatedAt === null) || (incomingdata.data[0].updatedAt === '')){
				var jobUpdatedTS = incomingdata.data[0].createdAt;
			}else {
				var jobUpdatedTS = incomingdata.data[0].updatedAt;
			}
		}else{
			var jobUpdatedTS = incomingdata.eventTime;
		}
		
		var payload;

		var sourceUrl = sm.getVar('var://service/URL-in');
		if (sourceUrl.includes('NoLongerSingleJob')) {
        var GetCallByJobRequest = ctx.getVar("GetCallByJobRequest");
        var premiseIdList = GetCallByJobRequest.map(item => item.externalPremiseID);
        // var premiseIdList = GetCallByJobRequest[0].externalPremiseID;
			var payload = {
				"msgType": "JobNoLongerSingle",
				"jobId": JOBID,
				"jobType": externalCallCodeID,
				"jobSubType": jobSubType,
				"jobStatus": jobStatus,
				"meterId": UpdateMeterID,
				"premiseId": premiseId,
				"jobUpdatedTS": jobUpdatedTS,
				"premiseIdList":premiseIdList

			}

			var ctx = session.name("trap") || session.createContext("trap");
			var StreamuriUPD = ctx.getVar("StreamuriUPD");

			var eventHubCall = {
				target: eventHubURL,
				sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
				method: 'POST',
				headers: {
					'Authorization': Auth,
				},
				contentType: 'application/json',
				data: payload
			};

			CepCall(eventHubCall, payload, eventHubURL);
			var JobNoLongerExitDescription = session.parameters.JobNoLongerStepExitDescription;
			ILSctx.setVariable("callcheck", "JobNoLonger");
			ILSctx.setVariable("eventHubURL", eventHubURL);
			ILSctx.setVariable("JobNoLongerStepExitDescription", JobNoLongerExitDescription);
			ILSctx.setVariable("JobNoLongerpPayload", payload);
			ms.callRule('trap_ReceiveJobStatus_policy_STEP_EXIT_ILS', null, null, function(error) {
				if (error) {
					logger.error("Error trap_ReceiveJobStatus_policy_STEP_EXIT_ILS");
				}
			});

			var omsExternalURL = session.parameters.omsExternalURL;
			ILSctx.setVariable("exitDestination", omsExternalURL);
			ILSctx.setVariable("exitStatus", "0");

			var jobid = incomingdata.data[0].id;
			var jobapiuri = omsExternalURL + 'Job/' + jobid;
			var validationStatusInterrupt = session.parameters.ValidationStatusInterrupt;
			// lookuos call for Patch call 
			var lookupURL = ctx.getVar("lookupURL");
			//lookup call
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "jobCustomFields.voltagevalidationstatus",
						"label": validationStatusInterrupt
					}]
				}
			};
			var LookupResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + LookupResponse.target + "; Method :" + LookupResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";

			try {
				var Lookupcall = await LookupCall(LookupResponse);
			} catch (error) {
				logger.error("error in lookup response call");
				session.reject("error in lookup response call")
			}

			var PatchPayload = {
				"customFieldValues": {
					"voltage_validation_status": Lookupcall
				}
			};
			// Prepare job API call details
			var jobapi = {
				target: jobapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'PATCH',
				contentType: 'application/json',
				headers: {
					'osiApiToken': apiToken
				},
				data: PatchPayload
			};
			var info = " TargetURL :" + jobapi.target + "; Method :" + jobapi.method + "; Data :" + JSON.stringify(PatchPayload) + ". ";

			urlopen.open(jobapi, function(error, response) {
				if (error) {
					var errorinfo = "trap_035: urlopen connect error while sending patch call request for voltagevalidationstatus 'Interrupt', details are: " + info + " ; error info: " + JSON.stringify(error);
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if ((responseStatusCode === 200) || (responseStatusCode === 400)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message to jobapi" + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								//main exit
								ILSctx.setVariable("exitDestination", jobapiuri);
								ILSctx.setVariable("exitStatus", "0");
								var ExitDescription = session.parameters.JobNoLongerExitDescription;
								ILSctx.setVariable("ExitDescription", ExitDescription);
								session.output.write(PatchPayload);
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error in reading message from jobapi Patch operation for jobid " + info + " ; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								//session.reject(errorinfo);
								//session.reject("urlopen connect error " + JSON.stringify(error));
							} else {
								var errorinfo = "trap_036:Error response received from jobapi Patch call request for voltagevalidationstatus 'Interrupt', details are: " + info + "ResponseStausCode: " + responseStatusCode + "Response Info :" + responseData
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								//session.reject("urlopen connect error " + JSON.stringify(error));
							}
						});
					}
				}
			});
			session.output.write(payload);

		} else {
			var sourceUrl = sm.getVar('var://service/URL-in');
			var jobSubType = ctx.getVar("outageSubtypeslabel");
			var jobStatus = ctx.getVar("lookuplabel");
			if ((incomingdata.eventTime === undefined) || (incomingdata.eventTime === null) || (incomingdata.eventTime === '')){
			
			if ((incomingdata.data[0].updatedAt === undefined) || (incomingdata.data[0].updatedAt === null) || (incomingdata.data[0].updatedAt === '')){
				var jobUpdatedTS = incomingdata.data[0].createdAt;
			}else {
				var jobUpdatedTS = incomingdata.data[0].updatedAt;
			}
		}else{
			var jobUpdatedTS = incomingdata.eventTime;
		}
			if (sourceUrl.includes('Update')) {
				var GetCallByJobRequest = ctx.getVar("GetCallByJobRequest");
				var premiseIdList = GetCallByJobRequest.map(item => item.externalPremiseID);
				var odmresponse = ctx.getVar("odmresponse");
				var okToProceed = odmresponse.response.okToProceed;
				if (okToProceed) {
					var payload = {
						"msgType": "JobUpdate",
						"jobId": JOBID,
						"jobType": externalCallCodeID,
						"jobSubType": jobSubType,
						"jobStatus": jobStatus,
						"meterId": UpdateMeterID,
						"premiseId": premiseId,
						"jobUpdatedTS": jobUpdatedTS

					}

					var ctx = session.name("trap") || session.createContext("trap");
					var StreamuriUPD = ctx.getVar("StreamuriUPD");

					var eventHubCall = {
						target: eventHubURL,
						sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
						method: 'POST',
						headers: {
							'Authorization': Auth,
						},
						contentType: 'application/json',
						data: payload
					};

					CepCall(eventHubCall, payload, eventHubURL);
					ILSctx.setVariable("exitDestination", eventHubURL);
					ILSctx.setVariable("exitStatus", "0");
					var ExitDescription = session.parameters.JobUpdateExitDescription;
					ILSctx.setVariable("ExitDescription", ExitDescription);
					session.output.write(payload);
				}
				else {
					if ((incomingdata.eventTime === undefined) || (incomingdata.eventTime === null) || (incomingdata.eventTime === '')){
			
			if ((incomingdata.data[0].updatedAt === undefined) || (incomingdata.data[0].updatedAt === null) || (incomingdata.data[0].updatedAt === '')){
				var jobUpdatedTS = incomingdata.data[0].createdAt;
			}else {
				var jobUpdatedTS = incomingdata.data[0].updatedAt;
			}
		}else{
			var jobUpdatedTS = incomingdata.eventTime;
		}
					var payload = {
						"msgType": "JobIneligible",
						"jobId": JOBID,
						"jobType": externalCallCodeID,
						"jobSubType": jobSubType,
						"jobStatus": jobStatus,
						"meterId": UpdateMeterID,
						"premiseId": premiseId,
						"jobUpdatedTS": jobUpdatedTS,
						"premiseIdList":premiseIdList

					}

					var ctx = session.name("trap") || session.createContext("trap");
					var StreamuriUPD = ctx.getVar("StreamuriUPD");

					var eventHubCall = {
						target: eventHubURL,
						sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
						method: 'POST',
						headers: {
							'Authorization': Auth,
						},
						contentType: 'application/json',
						data: payload
					};

					CepCall(eventHubCall, payload, eventHubURL);
					ILSctx.setVariable("exitDestination", eventHubURL);
					ILSctx.setVariable("exitStatus", "0");
					var ExitDescription = session.parameters.JobUpdateNotOKtoProceed;
					ILSctx.setVariable("ExitDescription", ExitDescription);
					session.output.write(payload);
				}
			}

		}
	}

	function CepCall(eventHubCall, payload, eventHubURL) {
		var info = " TargetURL :" + eventHubCall.target + "; Method :" + eventHubCall.method + "; Data :" + JSON.stringify(payload) + ". ";
		try {
			urlopen.open(eventHubCall, function(error, response) {
				if (error) {
					var errorinfo = "trap_037: urlopen connect error of 'eventHubURL',details are: " + info + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500")
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if ((responseStatusCode == 200) || (responseStatusCode == 201)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in reading response of 'eventHubURL',details are: " + info + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;

							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error in reading message of 'eventHubURL',details are: " + info + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "trap_038: error response returned from 'eventHubURL', details are: " + info + "with status code :" + responseStatusCode + "Responseinfo: " + responseData
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});

					}
				}
			});
		} catch (error) {
			var errorinfo = "trap_037: urlopen connect error of 'eventHubURL',details are: " + info + JSON.stringify(error)
			ILSctx.setVariable("StepExiterrorinfo", errorinfo);
			ILSctx.setVariable("exitStatus", "500")
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	};

	//lookup function
	function LookupCall(LookupResponse) {
		return new Promise((resolve, reject) => {
			urlopen.open(LookupResponse, (error, response) => {
				if (error) {
					var errorinfo = "trap_039: urlopen connect error from LookupServiceResponse for voltagevalidationstatus 'Interrupt',details are: " + info + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500")
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
				var responseStatusCode = response.statusCode;
				if (responseStatusCode === 200) {
					response.readAsBuffer((error, responseData) => {
						if (error) {
							var errorinfo = "Failure in reading message from LookupServiceResponse for voltagevalidationstatus 'Interrupt', details are: " + info + JSON.stringify(error)
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
						hm.response.statusCode = responseStatusCode;
						logger.debug("Response received from OmsCall", responseStatusCode);
						var lookupResponse = JSON.parse(responseData)
						if (lookupResponse.lookupRep.type[0].result == '0') {
							var Identifier = lookupResponse.lookupRep.type[0].status;
							resolve(Identifier);
						} else {
							var errorinfo = "trap_040: lookupresponse doesn't have a return label ,result =1 for voltagevalidationstatus 'Interrupt', details are: " + info + JSON.stringify(error)
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				} else {
					var errorinfo = "trap_041:Error response received from LookupServiceResponse for voltagevalidationstatus 'Interrupt', details are: " + info + "responsestatuscode:", responseStatusCode
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", responseStatusCode)
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			});
		});
	}
});
