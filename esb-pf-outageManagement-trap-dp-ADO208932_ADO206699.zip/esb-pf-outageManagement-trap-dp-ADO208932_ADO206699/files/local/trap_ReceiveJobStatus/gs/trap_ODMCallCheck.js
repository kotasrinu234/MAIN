//js is used to perfomr odm call 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("trap") || session.createContext("trap");
	var execute = ctx.getVar("execute");
	var Premisephasescheck = ctx.getVar("Premisephasescheck");
	if (Premisephasescheck == "yes") {
		session.output.write(incomingdata);
	} else {
		var sourceUrl = sm.getVar('var://service/URL-in');
		if (sourceUrl.includes('Create') || sourceUrl.includes('Update')) {
			var ctx = session.name("trap") || session.createContext("trap");
			var ODMEndpoint = ctx.getVar("ODMEndpoint");

			if (readAsJSONError) {
				logger.error("Error in reading incoming data");
				session.reject(readAsJSONError);
			} else {
				//checking displayid as null
				if (incomingdata.data[0].id != undefined) {
					var displayID = incomingdata.data[0].id;
					var CallCodeID = incomingdata.data[0].leadCall.externalCallCodeID
					ctx.setVariable("displayID", displayID);

					if ((CallCodeID === undefined) || (CallCodeID === '') || (CallCodeID === null)) {
						var CallCodeID = "";
						ctx.setVariable("CallCodeID", CallCodeID);
					} else {
						var CallCodeID = CallCodeID;
						ctx.setVariable("CallCodeID", CallCodeID);
					}
					//framing timestamp MM/DD/YYYY HH24:MI:SS
					var now = new Date();
					var year = now.getUTCFullYear();

					var month = now.getUTCMonth() + 1;
					var month1 = month.toString();
					var strmonthlength = month1.length;
					var todaymonth;
					if (strmonthlength == 1) {
						todaymonth = '0' + month;
					} else {
						todaymonth = month;
					}

					var day = now.getUTCDate();
					var day1 = day.toString();
					var strdaylength = day1.length;
					var todaydate;
					if (strdaylength == 1) {
						todaydate = '0' + day;
					} else {
						todaydate = day;
					}

					var hour = now.getUTCHours();
					var todayhour = hour.toString();
					var strhourlength = todayhour.length;
					var todayhour;
					if (strhourlength == 1) {
						todayhour = '0' + hour;
					} else {
						todayhour = hour;
					}

					var minute = now.getUTCMinutes();
					var todayminute = minute.toString();
					var strminutelength = todayminute.length;
					var todayminute;
					if (strminutelength == 1) {
						todayminute = '0' + minute;
					} else {
						todayminute = minute;
					}

					var second = now.getUTCSeconds();
					var todaysecond = second.toString();
					var strsecondlength = todaysecond.length;
					var todaysecond;
					if (strsecondlength == 1) {
						todaysecond = '0' + todaysecond;
					} else {
						todaysecond = todaysecond;
					}
					//	logger.error("todaysecond++"+todaysecond);
					var timestampframed = year + '-' + todaymonth + '-' + todaydate + 'T' + todayhour + ':' + todayminute + ':' + todaysecond + '.000+0000';
					var ctx = session.name("trap") || session.createContext("trap");
					var lookuplabel = ctx.getVar("lookuplabel");
					var jobSubType = ctx.getVar("outageSubtypeslabel");
					//			if (lookuplabel == 'New'){
					//				lookuplabel = 'NEW';
					//				
					//			}
					var payload = {
						"__DecisionID__": displayID,
						"inputTimeUTC": {
							"inputDatetime": timestampframed
						},
						"jobDetails": {
							"jobStatus": lookuplabel,
							"callCode": CallCodeID,
							"jobSubType":jobSubType
						}
					}

					//https://dte-odmoc.bpm.ibmcloud.com/odm/dev/DecisionService/rest/v1/AutoCloseAndDispatch/1.0/AutoCloseAndDispatchCheck

					var odmuri = ODMEndpoint;
					//dte_odm_esb_adms_dev.fid@t1189:T2Bd2RjgA1qdALamr5AJcEB9FD7j4gFqwR2FH72r
					//		var ODMCredentials = ODMCredentials;
					//		var ctx = session.name("trap")|| session.createContext("trap");
					//	var ODMCredentials =ctx.getVar("ODMCredentials");
					//		var ODMEncodedCred = 'Basic '+new Buffer(ODMCredentials).toString('base64');

					var odmapi = {
						target: odmuri,
						sslClientProfile: 'ODM_Client_Profile',
						method: 'post',
						contentType: 'application/json',
						headers: {
							// Authorization : ODMEncodedCred
						},
						data: payload
					};
					var info = " TargetURL :" + odmuri + "; Method :" + odmapi.method + "; Data :" + JSON.stringify(payload) + ". ";
					urlopen.open(odmapi, function(error, response) {
						if (error) {
							// an error occurred during request sending or response header parsing
							var errorinfo = "trap_006: urlopen connect error with odmapi : " + info + "; error info: " + JSON.stringify(error);
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", "500");
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										var errorinfo = "failure in reading message from odmapi : " + info + "; error info: " + JSON.stringify(error);
										ILSctx.setVariable("StepExiterrorinfo", errorinfo);
										ILSctx.setVariable("exitStatus", responseStatusCode);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										hm.response.statusCode = '200 Message is received';
										//	session.output.write(responseData);
										logger.debug("response code received from  trap_ReceiveJobStatus odmuri call: " + responseStatusCode);
										var odmresponse = responseData;
										var odmresponseStatus = responseData.response.okToProceed;
										var ctx = session.name("trap") || session.createContext("trap");
										ctx.setVariable("odmresponse", odmresponse);
										ctx.setVariable("odmresponseStatus", odmresponseStatus);
										if(odmresponseStatus){
										ILSctx.setVariable("callcheck", "ODMCALL");
										ILSctx.setVariable("OdmStepexitDestination", odmuri);
										ILSctx.setVariable("odmStepExitPayload", payload);
										STEP_rule();
										}else{
											ILSctx.setVariable("odmExitPayload", odmresponse);
										}
									}
								});
							} else {
								var errorinfo = "trap_007:Error response recived from trap_ReceiveJobStatus odmuri: " + info + "responseStatusCode : " + responseStatusCode
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						}
						//odm end				
					});
				}
			}
		} //execute yes closing
	}
});

function STEP_rule() {
	ms.callRule('trap_ReceiveJobStatus_policy_STEP_EXIT_ILS', null, null, function(error) {
		if (error) {
			logger.error("Error in trap_ReceiveJobStatus_policy_STEP_EXIT_ILS");
		}
	});
}
