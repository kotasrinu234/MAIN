var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var util = require('util');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ms = require('multistep');

function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0,
			v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
session.input.readAsJSON(async function(readAsJSONError, incomingdata) {
	var ctx = session.name("trap") || session.createContext("trap");
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var odmresponse = ctx.getVar("odmresponse");
		var okToProceed = odmresponse.response.okToProceed;
		var omsExternalURL = session.parameters.omsExternalURL;
		var apiToken = session.parameters.osiApiToken;
		var jobid = ctx.getVar("displayID");
		var jobapiuri = omsExternalURL + 'Job/' + jobid;
		var validationStatusProceed = session.parameters.ValidationStatusProceed;
		var MeterInfoStepExitDescription = session.parameters.MeterInfoStepExitDescription;

		var execute = ctx.getVar("execute");
		var sourceUrl = sm.getVar('var://service/URL-in');
		var ODMEndpoint = ctx.getVar("ODMEndpoint");
		if (okToProceed) {
			if (sourceUrl.includes('Create')) {
				//lookup call for PATCH call 
				var lookupURL = ctx.getVar("lookupURL");
				//lookup call
				var lookupMessage = {
					"lookupReq": {
						"type": [{
							"name": "jobCustomFields.voltagevalidationstatus",
							"label": validationStatusProceed
						}]
					}
				};
				var LookupResponse = {
					target: lookupURL,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				var info = " TargetURL: " + LookupResponse.target + "; Method: " + LookupResponse.method + "; Data: " + JSON.stringify(lookupMessage) + ". ";


				try {
					var Lookupcall = await LookupCall(LookupResponse);
				} catch (error) {
					logger.error("error in lookup response call");
					session.reject("error in lookup response call")
				}
				var payload = {
					"customFieldValues": {
						"voltage_validation_status": Lookupcall
					}
				};
				// Prepare job API call details
				var jobapi = {
					target: jobapiuri,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'PATCH',
					contentType: 'application/json',
					headers: {
						'osiApiToken': apiToken
					},
					data: payload
				};

				var info = " TargetURL: " + jobapi.target + "; Method: " + jobapi.method + "; Data: " + JSON.stringify(payload) + ". ";
				urlopen.open(jobapi, function(error, response) {
					if (error) {
						var errorinfo = "trap_008: urlopen connect error with jobapi Patch operation for jobid " + info + " ; error info: " + JSON.stringify(error);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						// Read response data
						var responseStatusCode = response.statusCode;
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message to jobapi" + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								// Check the response status code and response data
								if ((responseStatusCode == 200) || (responseStatusCode == 400 && responseData == 'No updates')) {
									// Proceed if response is valid and okToProceed is true
									var ILSctx = session.name("ILS") || session.createContext("ILS");
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from jobapi for jobid: " + info + " with Status Code : " + responseStatusCode);

									var getMeterInfoUrl = session.parameters.getMeterInfoUrl;
									var correlationID = uuidv4();
									var meterID = incomingdata.data[0].leadCall.meterID;
									//var MeterPhase = incomingdata.data[0].leadCall.MeterPhase;
									//var Type = incomingdata.data[0].leadCall.Type;
									// if new job then do adls call
									var execute = ctx.getVar("execute");
									if (execute == "yes") {
										var getUrl = getMeterInfoUrl + '/GetMeterInfo/v1?messageID=' + correlationID + '&meterID=' + meterID + '&recentVoltageNeeded=Y';
										var getMeterInfo = {
											target: getUrl,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'GET',
											contentType: 'application/json',
											headers: {
												"osiApiToken": apiToken
											},
										};
										var info = " TargetURL :" + getMeterInfo.target + "; Method :" + getMeterInfo.method + ". ";
										try {
											urlopen.open(getMeterInfo, function(error, response) {
												if (error) {
													var errorinfo = "trap_009: URL connection error with 'getMeterInfo', details: " + info + "; error info: " + JSON.stringify(error);
													ILSctx.setVar('StepExiterrorinfo', errorinfo);
													ILSctx.setVariable("exitStatus", "500");
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "Error reading response from 'getMeterInfo', details: " + info + "; error info: " + JSON.stringify(error);
																ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																ILSctx.setVariable("exitStatus", responseStatusCode);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var ctx = session.name("trap") || session.createContext("trap");
																if ('voltageReadResult' in responseData) {
																	var meterReadintTS = responseData.voltageReadResult.meterReadintTS;
																	var meterVoltageReadingInstA = responseData.voltageReadResult.meterVoltageReadingInstA;
																	var responseData = responseData;
																	shouldReadVoltage(meterReadintTS, meterVoltageReadingInstA, responseData);
																	ILSctx.setVariable("callcheck", "MeterInfo");
																	ILSctx.setVariable("MeterInfoStepexitDestination", getUrl);
																	ILSctx.setVariable("MeterInfoPayload", responseData);
																	ILSctx.setVariable("MeterInfoStepExitDescription", MeterInfoStepExitDescription);
																	STEP_rule();
																} else if ('error' in responseData) {
																	var ctx = session.name("trap") || session.createContext("trap");
																	var omsExternalURL = session.parameters.omsExternalURL;
																	var jobid = ctx.getVar("displayID");
																	logger.error("jobid", jobid)
																	var patchUrl = omsExternalURL + 'Job/' + jobid;
																	var validationStatusInterrupt = session.parameters.ValidationStatusInterrupt;

																	//lookup call
																	var lookupURL = ctx.getVar("lookupURL");
																	var lookupMessage = {
																		"lookupReq": {
																			"type": [{
																				"name": "jobCustomFields.voltagevalidationstatus",
																				"label": validationStatusInterrupt
																			}]
																		}
																	};
																	var LookupResponse = {
																		target: lookupURL,
																		method: 'POST',
																		contentType: 'application/json',
																		data: lookupMessage
																	};

																	var info = " TargetURL: " + LookupResponse.target + "; Method: " + LookupResponse.method + "; Data: " + LookupResponse.lookupMessage + ". ";

																	urlopen.open(LookupResponse, function(error, response) {
																		if (error) {
																			var errorinfo = "trap_010: urlopen connect error with lookupURL, details are: " + info + JSON.stringify(error)
																			ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																			ILSctx.setVariable("exitStatus", "500");
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsJSON(function(error, responseData) {
																					if (error) {
																						var errorinfo = "Failure in getting response from 'lookupURL', details: " + info + "; error info: " + JSON.stringify(error);
																						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																						ILSctx.setVariable("exitStatus", responseStatusCode);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						if (responseData.lookupRep.type[0].result == '0') {
																							var Identifier = responseData.lookupRep.type[0].status;
																							var patchData = {
																								"customFieldValues": {
																									"voltage_validation_status": Identifier
																								}
																							};
																							var patchRequest = {
																								target: patchUrl,
																								method: 'PATCH',
																								contentType: 'application/json',
																								sslClientProfile: 'OMS_Client_Profile',
																								headers: {
																									"osiApiToken": apiToken
																								},
																								data: patchData
																							};
																							var info = " TargetURL: " + patchRequest.target + "; Method: " + patchRequest.method + "; Data: " + JSON.stringify(patchRequest.data) + ". ";

																							try {
																								urlopen.open(patchRequest, function(error, response) {
																									if (error) {
																										var errorinfo = "trap_011: urlopen connect error while sending PATCH call request,details are: " + info + ": " + JSON.stringify(error);
																										ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																										ILSctx.setVariable("exitStatus", "500");
																										logger.error(errorinfo);
																										session.reject(errorinfo);

																									} else {
																										var responseStatusCode = response.statusCode;
																										if (responseStatusCode == 200) {
																											var errorinfo = "Invalid meterID detected while sending PATCH call request,details are: " + info
																											ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																											ILSctx.setVariable("exitStatus", responseStatusCode);
																											logger.info(errorinfo);
																											session.reject(errorinfo);
																										} else {
																											var errorinfo = "Error response from PATCH call request,details are: " + info + " with Status Code: " + responseStatusCode
																											ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																											ILSctx.setVariable("exitStatus", responseStatusCode);
																											logger.info(errorinfo);
																											session.reject(errorinfo);
																										}
																									}
																								});
																							} catch (error) {
																								var errorinfo = "trap_010: urlopen connect error while sending PATCH call request,details are: " + info + ": " + JSON.stringify(error);
																								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																								ILSctx.setVariable("exitStatus", "500");
																								logger.error(errorinfo);
																								session.reject(errorinfo);
																							}

																						} else {
																							var errorinfo = "trap_012: lookupresponse doesn't have a return label ,result =1, details are: " + info
																							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																							ILSctx.setVariable("exitStatus", "500");
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						}
																					}
																				});
																			} else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "failure in reading response from 'lookupURL', details are: " + info + JSON.stringify(error)
																						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																						ILSctx.setVariable("exitStatus", responseStatusCode);
																						logger.info(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "Error response received from 'lookupURL',details are: " + info + " with Status Code: " + responseStatusCode + "response info: " + responseData
																						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																						ILSctx.setVariable("exitStatus", responseStatusCode);
																						logger.info(errorinfo);
																						session.reject(errorinfo);
																					}
																				});
																			}
																		}
																	});
																} else {
																	ctx.setVariable("GetMeterInfo", responseData);
																	ctx.setVariable("PresentVoltage", "No");
																	ctx.setVariable("CepCall", "no");
																	ILSctx.setVariable("callcheck", "MeterInfowithoutVR");
																	ILSctx.setVariable("MeterInfoStepexitDestination", getUrl);
																	ILSctx.setVariable("MeterInfowithoutVRPayload", responseData);
																	ILSctx.setVariable("MeterInfoStepExitDescription", MeterInfoStepExitDescription);
																	STEP_rule();
																}
															}
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "Error reading response from 'getMeterInfo', details: " + info + "; error info : " + JSON.stringify(error);
																ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																ILSctx.setVariable("exitStatus", responseStatusCode);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var errorinfo = "trap_013: Unexpected error from 'getMeterInfo' with Status Code: " + responseStatusCode + info + "; Response Data: " + responseData;
																ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																ILSctx.setVariable("exitStatus", responseStatusCode);
																logger.error(errorinfo);
																session.reject(errorinfo);
															}
														});
													}
												}
											});
										} catch (error) {
											var errorinfo = "trap_009: URL connection error with 'getMeterInfo', details: " + info + "; error info: " + JSON.stringify(error);
											ILSctx.setVar('StepExiterrorinfo', errorinfo);
											ILSctx.setVariable("exitStatus", "500");
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									}
								} else {
									// Handle other errors
									var errorinfo = "trap_014: Error returned from jobapi Patch call request for voltagevalidationstatus 'In Progress',details are: " + info + " with statusCode: " + responseStatusCode + " and response: " + responseData;
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							}
						});
					}
				});

				function shouldReadVoltage(meterReadintTS, meterVoltageReadingInstA, responseData) {
					//	logger.error("insidefunction" + meterReadintTS);
					//	logger.error("insidefunction" + meterVoltageReadingInstA);
					var meterReadintTS = meterReadintTS;
					var meterVoltageReadingInstA = meterVoltageReadingInstA;
					var responseData = responseData;
					if (meterReadintTS) {

						var currentTime = Date.now(); // Current time in milliseconds
						//var currentTime1 = '2024-10-25 12:45:00+00:00';
						//var currentTime1 = session.parameters.currentTime;
						//var currentTime = new Date(currentTime1).getTime();
						var Timer = session.parameters.Timer;
						var meterTimestamp = new Date(meterReadintTS).getTime(); // Convert meter reading timestamp to milliseconds
						var differenceInSeconds = (currentTime - meterTimestamp) / 1000; // Calculate the difference in seconds
						ctx.setVariable("meterTimestamp", meterTimestamp);
						ctx.setVariable("currentTime", currentTime);
						ctx.setVariable("Timer", Timer);
						// Check if the difference is less than or equal to 60 seconds
						if (differenceInSeconds <= Timer) {
							ctx.setVariable("CepCall", "yes");
							ctx.setVariable("GetMeterInfo", responseData);
							ctx.setVariable("PresentVoltage", "yes");
							return
						} else {
							ctx.setVariable("GetMeterInfo", responseData);
							ctx.setVariable("PresentVoltage", "No");
							ctx.setVariable("CepCall", "no");
							return
						}
					}
				}
			}// Create Scenario End

			//if ODM response == false
		} else {
			var lookuplabel = ctx.getVar("lookuplabel");

			var sourceUrl = sm.getVar('var://service/URL-in');
			var ILSctx = session.name("ILS") || session.createContext("ILS");
			var ctx = session.name("trap") || session.createContext("trap");
			var omsExternalURL = session.parameters.omsExternalURL;
			var apiToken = session.parameters.osiApiToken;
			var jobid = ctx.getVar("displayID");
			var jobapiuri = omsExternalURL + 'Job/' + jobid;
			var ODMEndpoint = ctx.getVar("ODMEndpoint");

			var ValidationStatusIneligible = session.parameters.ValidationStatusIneligible;
			if (sourceUrl.includes('Update') && (lookuplabel !== 'Archived' && lookuplabel !== 'Canceled')) {

				var lookupURL = ctx.getVar("lookupURL");
				var lookupMessage = {
					"lookupReq": {
						"type": [{
							"name": "jobCustomFields.voltagevalidationstatus",
							"label": ValidationStatusIneligible
						}]
					}
				};
				var LookupResponse = {
					target: lookupURL,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				var info = " TargetURL: " + LookupResponse.target + "; Method: " + LookupResponse.method + "; Data: " + JSON.stringify(lookupMessage) + ". ";
				try {
					var Lookupcall = await LookupCall(LookupResponse);
					var NoTOkToProceedDescription = session.parameters.OdmExitDescription;
						ILSctx.setVariable("callcheck", "ODMNotOkToProceed");
						ILSctx.setVariable("NotOkToProceedDestination", ODMEndpoint);
						ILSctx.setVariable("exitStatus", "0");
						ILSctx.setVariable("NoTOkToProceedDescription", NoTOkToProceedDescription);
						var odmExitPayload = ILSctx.getVar("odmExitPayload");
						ILSctx.setVariable("NotOkToProceedPayload", odmExitPayload);

						ms.callRule('trap_ReceiveJobStatus_policy_STEP_EXIT_ILS', null, null, function(error) {
							if (error) {
								logger.error("Error trap_ReceiveJobStatus_policy_STEP_EXIT_ILS");
							}
						});
					
				} catch (error) {
					logger.error("error in lookup response call");
					session.reject("error in lookup response call")
				}
				var payload = {
					"customFieldValues": {
						"voltage_validation_status": Lookupcall
					}
				};

				var jobapi = {
					target: jobapiuri,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'PATCH',
					contentType: 'application/json',
					headers: {
						'osiApiToken': apiToken
					},
					data: payload
				};
				var info = " TargetURL :" + jobapi.target + "; Method :" + jobapi.method + "; Data :" + JSON.stringify(payload) + ". ";

				urlopen.open(jobapi, function(error, response) {
					if (error) {
						var errorinfo = "trap_015: urlopen connect error while sending Job Update patch call request for voltagevalidationstatus 'Ineligible', details are: " + info + " ; error info: " + JSON.stringify(error);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if ((responseStatusCode === 200) || (responseStatusCode === 400)) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading message to jobapi" + info + "; error info: " + JSON.stringify(error);
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									//main exit

								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error in reading message from jobapi Patch operation for jobid " + info + " ; error info: " + JSON.stringify(error);
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									//session.reject(errorinfo);
									//session.reject("urlopen connect error " + JSON.stringify(error));
								} else {
									var errorinfo = "trap_016:Error response received from job Update patch call request for voltagevalidationstatus 'Ineligible', details are: " + info + "ResponseStausCode: " + responseStatusCode + "Response Info :" + responseData
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									//session.reject("urlopen connect error " + JSON.stringify(error));
								}
							});
						}
					}
				});
			}
			if (sourceUrl.includes('Create')) {

				var lookupURL = ctx.getVar("lookupURL");
				var lookupMessage = {
					"lookupReq": {
						"type": [{
							"name": "jobCustomFields.voltagevalidationstatus",
							"label": ValidationStatusIneligible
						}]
					}
				};
				var LookupResponse = {
					target: lookupURL,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				var info = " TargetURL: " + LookupResponse.target + "; Method: " + LookupResponse.method + "; Data: " + JSON.stringify(lookupMessage) + ". ";
				try {
					var Lookupcall = await LookupCall(LookupResponse);
						ILSctx.setVariable("exitDestination", ODMEndpoint);
						ILSctx.setVariable("exitStatus", "0");
						var ExitDescription = session.parameters.OdmExitDescription;
						ILSctx.setVariable("ExitDescription", ExitDescription);
						var payload = ctx.getVar("odmExitPayload");
						session.output.write(payload);
					
				} catch (error) {
					logger.error("error in lookup response call");
					session.reject("error in lookup response call")
				}
				var payload = {
					"customFieldValues": {
						"voltage_validation_status": Lookupcall
					}
				};

				var jobapi = {
					target: jobapiuri,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'PATCH',
					contentType: 'application/json',
					headers: {
						'osiApiToken': apiToken
					},
					data: payload
				};
				var info = " TargetURL :" + jobapi.target + "; Method :" + jobapi.method + "; Data :" + JSON.stringify(payload) + ". ";

				urlopen.open(jobapi, function(error, response) {
					if (error) {
						var errorinfo = "trap_017: urlopen connect error while sending patch call request for Job Create with voltagevalidationstatus 'Ineligible', details are: " + info + " ; error info: " + JSON.stringify(error);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if ((responseStatusCode === 200) || (responseStatusCode === 400)) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading message to jobapi" + info + "; error info: " + JSON.stringify(error);
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									//main exit

								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error in reading message from jobapi Patch operation for jobid " + info + " ; error info: " + JSON.stringify(error);
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									//session.reject(errorinfo);
									//session.reject("urlopen connect error " + JSON.stringify(error));
								} else {
									var errorinfo = "trap_018:Error response received from patch call request for Job Create with voltagevalidationstatus 'Ineligible', details are: " + info + "ResponseStausCode: " + responseStatusCode + "Response Info :" + responseData
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									//session.reject("urlopen connect error " + JSON.stringify(error));
								}
							});
						}
					}
				});
			}
			
		}
		//lookup function
		function LookupCall(LookupResponse) {
			return new Promise((resolve, reject) => {
				urlopen.open(LookupResponse, (error, response) => {
					if (error) {
						var errorinfo = "trap_019: urlopen connect error with 'lookupURL',details are: " + info + JSON.stringify(error);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
					var responseStatusCode = response.statusCode;
					if (responseStatusCode === 200) {
						response.readAsBuffer((error, responseData) => {
							if (error) {
								var errorinfo = "Failure in reading message from 'lookupURL',details are: " + info + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
							hm.response.statusCode = responseStatusCode;
							logger.debug("Response received from OmsCall", responseStatusCode);
							var lookupResponse = JSON.parse(responseData)
							if (lookupResponse.lookupRep.type[0].result == '0') {
								var Identifier = lookupResponse.lookupRep.type[0].status;
								resolve(Identifier);
							} else {
								var errorinfo = "trap_020: lookupresponse doesn't have a return label ,result =1, details are: " + info + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					} else {
						var errorinfo = "trap_021: label lookupURL response is not 200,details are: " + info + JSON.stringify(error); +
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			});
		}
		//}
	}
});

function STEP_rule() {
	ms.callRule('trap_ReceiveJobStatus_policy_STEP_EXIT_ILS', null, null, function(error) {
		if (error) {
			logger.error("Error in trap_ReceiveJobStatus_policy_STEP_EXIT_ILS");
		}
	});
}
