//js is used to check if job is new or not and premisecall
var urlopen = require('urlopen');
var fs = require('fs');
var ms = require('multistep');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	// getting styleheet params
	var ILSctx = session.name("ILS") || session.createContext("ILS");
	var ctx = session.name("trap") || session.createContext("trap");
	var lookupURL = ctx.getVar("lookupURL");
	var ctx = session.name("trap") || session.createContext("trap");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
	var apiToken = ctx.getVar("apiToken");
	var externalCallCodeID = ctx.getVar("externalCallCodeID");
	var externalCallCodeID = externalCallCodeID;

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		// doing lookup and deciding label is new or not
		var sourceUrl = sm.getVar('var://service/URL-in');
		if (sourceUrl.includes('Create') || sourceUrl.includes('Update')) {

			var jobTypeID = incomingdata.data[0].jobTypeID;
			var Status = incomingdata.data[0].status;
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "jobTypes.workflows",
						"id": jobTypeID,
						"status": Status
					}]
				}
			}
			var url = lookupURL;
			//invoking lookup service and storing response in a var
			var LookupServiceResponse = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + url + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "trap_001: urlopen connect error for jobTypeID LookupServiceResponse" + info + "errorinfo :" + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure in getting message from LookupServiceResponse jobTypeID " + info + "errorinfo :" + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response code received from trap_ReceiveJobStatus LookupServiceResponse " + responseStatusCode);
								//session.output.write(JSON.parse(responseData));
								var lookupResponse = JSON.parse(responseData)
								var lookuplabel;
								if (lookupResponse.lookupRep.type[0].result == '0') {
									lookuplabel = lookupResponse.lookupRep.type[0].label;
									var ctx = session.name("trap") || session.createContext("trap");
									ctx.setVariable("lookuplabel", lookuplabel);
								} else {
									var errorinfo = "trap_002: lookupresponse doesn't have a return label ,result =1 details are" + info
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", "400");
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								if (lookupResponse.lookupRep.type[0].label == 'New') {
									var jobStatus = "New";
								} else {
									var jobStatus = "NOT_NEW";
								}
								logger.debug("jobStatus is" + jobStatus);
							//	if (jobStatus == 'New') {
									if (incomingdata.data[0].outageSubtypeID == undefined || incomingdata.data[0].outageSubtypeID == null || incomingdata.data[0].outageSubtypeID == '') {
										var errorinfo = "outageSubtypeID is not present in input job payload details are" + info
										//ILSctx.setVariable("StepExiterrorinfo", errorinfo);
										//ILSctx.setVariable("exitStatus", responseStatusCode);
										logger.error(errorinfo);
										//session.reject(errorinfo);
									} else {
										var outageSubtypeID = incomingdata.data[0].outageSubtypeID;
										logger.debug("outage id is +++" + outageSubtypeID);

										var lookupMessage = {
											"lookupReq": {
												"type": [{
													"name": "outageSubtypes",
													"id": outageSubtypeID
												}]
											}
										}
										var url = lookupURL;
										//invoking lookup service and storing response in a var
										var LookupServiceResponse = {
											target: url,
											method: 'POST',
											contentType: 'application/json',
											data: lookupMessage
										};
										var info = " TargetURL :" + url + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";
										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												var errorinfo = "trap_003: urlopen connect error with outageSubtypes LookupServiceResponse details are ," + info + "error info :" + JSON.stringify(error)
												ILSctx.setVariable("StepExiterrorinfo", errorinfo);
												ILSctx.setVariable("exitStatus", "500");
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															// error while reading response or transferring data to Buffer
															var errorinfo = "failure in getting message from outageSubtypes LookupServiceResponse details are ," + info + "error info :" + JSON.stringify(error)
															ILSctx.setVariable("StepExiterrorinfo", errorinfo);
															ILSctx.setVariable("exitStatus", responseStatusCode);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response code received from trap_ReceiveJobStatus outageSubtypes LookupServiceResponse " + responseStatusCode);
															//session.output.write(JSON.parse(responseData));
															var lookupResponse = JSON.parse(responseData)
															var outageSubtypeslabel;
															if (lookupResponse.lookupRep.type[0].result == '0') {
																outageSubtypeslabel = lookupResponse.lookupRep.type[0].label;
																var ctx = session.name("trap") || session.createContext("trap");
																ctx.setVariable("outageSubtypeslabel", outageSubtypeslabel);
															} else {
																var errorinfo = "trap_004: outageSubtypes lookupresponse doesn't have a return label ,result =1 details are ," + info + "error info :" + JSON.stringify(error)
																ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																ILSctx.setVariable("exitStatus", "400");
																session.reject("outageSubtypes lookupresponse doesn't have a return label ,result =1");
															}
															var ctx = session.name("trap") || session.createContext("trap");
															var execute = "yes";
															ctx.setVariable("execute", execute);
														}
													});
												}
											}
										});
									}
								//} // jobnew ends
								//else {
									//keep some check condition here and make sure it is used in other js files to avoid executing 
									//var ctx = session.name("trap") || session.createContext("trap");
									//var execute = "no";
									//ctx.setVariable("execute", execute);
								//}
							}
						});
					} // 200
					else {
						logger.error("trap_005: lookup repsonse is not 200");
						var errorinfo = "trap_005: lookup repsonse is not 200 details are ," + info;
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "500");
						session.reject("lookup repsonse is not 200");
					}
				}
			});
		}     ///////
	}
});
