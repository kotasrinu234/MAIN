session.input.readAsBuffer(function (error, buffer) {
    if (error) {
        session.reject("Unexpected error in readAsJSON(): " + error);
        return;
    }

    var ctx = session.name('myContext') || session.createContext('myContext');
    ctx.setVar("inputData", buffer.toString());
	var ILSctx = session.name("ILS") || session.createContext("ILS");
    var ctx = session.name("trap") || session.createContext("trap");
	var errorinfo = ILSctx.getVar("StepExiterrorinfo");
	session.output.write(errorinfo);

});
