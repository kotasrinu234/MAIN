var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("trap") || session.createContext("trap");
var callcheck = ILSctx.getVar("callcheck");
if (callcheck == "ODMCALL") {
	var odmstepPayload = ILSctx.getVar("odmStepExitPayload");
	var OdmStepexitDestination = ILSctx.getVar("OdmStepexitDestination");
	var OdmStepExitDescription = ILSctx.getVar("OdmStepExitDescription");
	ILSctx.setVariable("description", OdmStepExitDescription);
	ILSctx.setVariable("StepexitDestination", OdmStepexitDestination);
	session.output.write(odmstepPayload);
}
else if (callcheck == "MeterInfo") {
	var MeterInfoStepexitDestination = ILSctx.getVar("MeterInfoStepexitDestination");
	var MeterInfoStepExitDescription = ILSctx.getVar("MeterInfoStepExitDescription");
	var MeterInfoStepexitPayload = ILSctx.getVar("MeterInfoPayload");
	ILSctx.setVariable("description", MeterInfoStepExitDescription);
	ILSctx.setVariable("StepexitDestination", MeterInfoStepexitDestination);
	session.output.write(MeterInfoStepexitPayload);
}
else if (callcheck == "MeterInfowithoutVR") {
	var MeterInfoStepexitDestination = ILSctx.getVar("MeterInfoStepexitDestination");
	var MeterInfoStepExitDescription = ILSctx.getVar("MeterInfoStepExitDescription");
	var MeterInfowithoutVRPayloadStepexitPayload = ILSctx.getVar("MeterInfowithoutVRPayload");
	ILSctx.setVariable("description", MeterInfoStepExitDescription);
	ILSctx.setVariable("StepexitDestination", MeterInfoStepexitDestination);
	session.output.write(MeterInfowithoutVRPayloadStepexitPayload);
} else if (callcheck == "GetToken") {
	var GetTokenurl = ILSctx.getVar("GetTokenurl");
	var GetTokenPayload = ILSctx.getVar("GetTokenPayload");
	var GetTokenStepExitDescription = ILSctx.getVar("GetTokenStepExitDescription");
	ILSctx.setVariable("description", GetTokenStepExitDescription);
	ILSctx.setVariable("StepexitDestination", GetTokenurl);
	session.output.write(GetTokenPayload);

} else if (callcheck == "JobNoLonger") {
	var eventHubURL = ILSctx.getVar("eventHubURL");
	var JobNoLongerpPayload = ILSctx.getVar("JobNoLongerpPayload");
	var JobNoLongerStepExitDescription = ILSctx.getVar("JobNoLongerStepExitDescription");
	ILSctx.setVariable("description", JobNoLongerStepExitDescription);
	ILSctx.setVariable("StepexitDestination", eventHubURL);
	session.output.write(JobNoLongerpPayload);
}else if (callcheck == "ODMNotOkToProceed") {
	var NotOkToProceedDestination = ILSctx.getVar("NotOkToProceedDestination");
	var NotOkToProceedPayload = ILSctx.getVar("NotOkToProceedPayload");
	var NoTOkToProceedDescription = ILSctx.getVar("NoTOkToProceedDescription");
	ILSctx.setVariable("description", NoTOkToProceedDescription);
	ILSctx.setVariable("StepexitDestination", NotOkToProceedDestination);
	session.output.write(NotOkToProceedPayload);
}

else {
	var Payload = {};
	session.output.write(Payload);
}
