var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("trap") || session.createContext("trap");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("trap") || session.createContext("trap");
	if (readAsJSONError) {
		logger.error("reading input JSON payload");
	} else {
		var sourceUrl = sm.getVar('var://service/URL-in');
		var jobid = incomingdata.data[0].id;
		var apiToken = ctx.getVar("apiToken");
		var omsExternalURL = ctx.getVar("omsExternalURL");
		if (sourceUrl.includes('Create')) {
			var odmresponse = ctx.getVar("odmresponse");
			var okToProceed = odmresponse.response.okToProceed;
			if (okToProceed) {
				var MeterCheck = ILSctx.getVar("callcheck");
				if (MeterCheck == "METERCALL") {
					ms.callRule('trap_ReceiveJobStatus_policy_STEP_EXIT_ILS', null, null, function(error) {
						if (error) {
							logger.error("Error trap_ReceiveJobStatus_policy_STEP_EXIT_ILS");
						}
					});
				}
				var GetTokenExitDescription = session.parameters.GetTokenStepExitDescription
				var GetTokenUrl = session.parameters.GetTokenUrl
				var Options = {
					target: GetTokenUrl,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'GET',
					contentType: 'application/json'
				};

				var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
				urlopen.open(Options, function(error, response) {
					if (error) {
						var errorinfo = "trap_031: urlopen connect error of GetTokenURL, details are: " + info + JSON.stringify(error)
						ILSctx.setVariable("exitStatus", "500");
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading response of GetTokenURL, details are: " + info + JSON.stringify(error)
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = '200 OK';
									ctx.setVariable("Responseget", responseData);
									var AccessToken = responseData.access_token;
									logger.debug("response received :" + JSON.stringify(responseData));
									if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
										logger.error("Invalid token response  " + JSON.stringify(responseData));
									} else {
										var AccessToken = responseData.access_token;
										var TokenType = responseData.token_type;
										ctx.setVariable("ResponseGET", responseData);
										ILSctx.setVariable("callcheck", "GetToken");
										ILSctx.setVariable("GetTokenurl", GetTokenUrl);
										ILSctx.setVariable("GetTokenPayload", responseData);
										ILSctx.setVariable("GetTokenStepExitDescription", GetTokenExitDescription);
										ms.callRule('trap_ReceiveJobStatus_policy_STEP_EXIT_ILS', null, null, function(error) {
											if (error) {
												logger.error("Error trap_ReceiveJobStatus_policy_STEP_EXIT_ILS");
											}
										});
										var Auth = TokenType + ' ' + AccessToken;
										ctx.setVariable("Auth", Auth);
									}
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Error response received from GetTokenURL, details are: " + info + JSON.stringify(error)
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									var errorinfo = "trap_032: Error returned from GetTokenURL, details are: " + info + ": with statusCode " + responseStatusCode + " " + responseData
									logger.error(errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			}
		}
		// function for premiseId and externalCallCodeID  
		//var apiToken = ctx.getVar("apiToken");
		var leadCallID = incomingdata.data[0].leadCallID;
		//var omsExternalURL = ctx.getVar("omsExternalURL");
		var Callapiuri = omsExternalURL + 'Call/' + leadCallID + '?includeFields=externalCallCodeID,externalPremiseID,meterID';
		var Callapi = {
			target: Callapiuri,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},

		};
		if ((incomingdata.data[0].leadCall == undefined) || (incomingdata.data[0].leadCall == '') || (incomingdata.data[0].leadCall == null)) {
			var externalCallCodeID = OmsGetCall(Callapi);
		} else {
			if (((incomingdata.data[0].leadCall.externalCallCodeID == undefined) || (incomingdata.data[0].leadCall.externalCallCodeID == '') || (incomingdata.data[0].leadCall.externalCallCodeID == null)) || ((incomingdata.data[0].leadCall.externalPremiseID == undefined) || (incomingdata.data[0].leadCall.externalPremiseID == '') || (incomingdata.data[0].leadCall.externalPremiseID == null)) || ((incomingdata.data[0].leadCall.meterID == undefined) || (incomingdata.data[0].leadCall.meterID == '') || (incomingdata.data[0].leadCall.meterID == null))) {
				var externalCallCodeID = OmsGetCall(Callapi);
			} else {
				var externalCallCodeID = incomingdata.data[0].leadCall.externalCallCodeID;
				ctx.setVariable("externalCallCodeID", externalCallCodeID);
				var premiseId = incomingdata.data[0].leadCall.externalPremiseID;
				ctx.setVariable("premiseId", premiseId);
				var meterID = incomingdata.data[0].leadCall.meterID;
				ctx.setVariable("UpdateMeterID", meterID);
			}
		}


		//function for OMS call to get the premiseId and externalCallCodeID
		function OmsGetCall(Callapi) {
			var info = " TargetURL :" + Callapi.target + "; Method :" + Callapi.method;
			urlopen.open(Callapi, function(error, response) {
				if (error) {
					var errorinfo = "trap_033: urlopen connect error with GET Callapi for 'leadCallID', details are :" + info + " error info :" + JSON.stringify(error);
					ILSctx.setVariable("ExitDescription", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					//session.reject("urlopen connect error with GET Callapi with id as " + leadCallID + " " + JSON.stringify(error));
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "error message while reading response from GET Callapi 'leadCallID', details are :" + info + " error info :" + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								//store status code with response body in context variable
								hm.response.statusCode = responseStatusCode;
								//logger.debug("response received from Callapi for leadCallID:" + leadCallID + "is :" + responseStatusCode);
								ctx.setVariable("OMSDATA", JSON.parse(responseData));
								var externalCallCodeID = JSON.parse(responseData).externalCallCodeID;
								ctx.setVariable("externalCallCodeID", externalCallCodeID);
								var premiseId = JSON.parse(responseData).externalPremiseID;
								ctx.setVariable("premiseId", premiseId);
								var meterID = JSON.parse(responseData).meterID;
								ctx.setVariable("UpdateMeterID", meterID);

							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from GET Callapi for 'leadCallID', details are :  " + info + "error info :" + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "trap_034: Error returned from GET Callapi for 'leadCallID', details are :" + info + " with statusCode " + responseStatusCode + " " + responseData
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
		};
		if (sourceUrl.includes('Update') || sourceUrl.includes("NoLongerSingleJob")) {

		//GetCallByJobRequest (ADO163094)
		var jobApiUri = omsExternalURL + 'Job/' + jobid + '/Call' + '?includeFields=createdAt,externalPremiseID,meterID,externalCallCodeID';
		var jobApi = {
			target: jobApiUri,
			method: 'GET',
			sslClientProfile: 'OMS_Client_Profile',
			headers: {
				'osiApiToken': apiToken
			},
			contentType: 'application/json'
		};
		var info = " TargetURL :" + jobApi.target + "; Method :" + jobApi.method + ". ";
		// Make the GET request
		urlopen.open(jobApi, function(error, response) {
			if (error) {
				var errorinfo = "url open connect error for OMS GetCallByJobRequest, details are: " + info + JSON.stringify(error)
				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
				ILSctx.setVariable("exitStatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "Failure in reading message from OMS GetCallByJobRequest, details are: " + info + JSON.stringify(error)
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							logger.debug("GetCallByJobRequest details received: " + JSON.stringify(responseData));
							ctx.setVariable("GetCallByJobRequest", responseData);
							hm.response.statusCode = '200';
							session.output.write(responseData);
						}
					});
				} else {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "Error reading response from OMS GetCallByJobRequest, details are: " + info + JSON.stringify(readError);
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "Error response from OMS GetCallByJobRequest, details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		});
		}
	}
});
