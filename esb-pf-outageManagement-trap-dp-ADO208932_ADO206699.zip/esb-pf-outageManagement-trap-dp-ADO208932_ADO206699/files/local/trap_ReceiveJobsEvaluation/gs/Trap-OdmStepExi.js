var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ms = require('multistep');
		var StepPayload = ILSctx.getVar("odmStepExitPayload");
		ILSctx.setVariable("StepPayload", StepPayload);
		session.output.write(StepPayload);
