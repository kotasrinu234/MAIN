var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("trap") || session.createContext("trap");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var omsExternalURL = ctx.getVar("omsExternalURL");
var ms = require('multistep');

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("trap") || session.createContext("trap");
		var omsExternalURL = ctx.getVar("omsExternalURL");
		var jobid = incomingdata.jobId;
		var Jobapiuri = omsExternalURL + 'Job/' + jobid;
		var TokenValue = ctx.getVar("apiToken");

		var jobaction = incomingdata.jobAction;
		if (jobaction == "AutoChange") {
			var lookupURL = ctx.getVar("lookupURL");
			var jobid = incomingdata.jobType;
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "callCodes",
						"label": jobid
					}]
				}
			}

			var url = lookupURL;
			var LookupServiceResponse = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};

			var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";

			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "trap_071: urlopen connect error in 'LookupServiceResponse' for jobID in 'AutoChange' , details are: " + info + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500")
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message 'LookupServiceResponse' for job ID in 'AutoChange', details are: " + info + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from autochange LookupServiceResponse " + responseData);
								var lookupResponse = JSON.parse(responseData)

								logger.debug("response" + LookupServiceResponse);
								var ctx = session.name("trap") || session.createContext("trap");
								var autochangeLookupID;
								if (lookupResponse.lookupRep.type[0].result == 0) {
									autochangeLookupID = lookupResponse.lookupRep.type[0].id;
									ctx.setVariable("autochangeLookupID", autochangeLookupID);
								}
							}
						});

					} else {
						var errorinfo = "trap_072:Error response received from 'LookupServiceResponse' for job ID in 'AutoChange', details are: " + info + "with status code : " + responseStatusCode
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				}
			});

		}
		if (jobaction == "BadVoltage") {
			// "Get outage subtype, by doing a lookup on label 'AMI-CONF' and get <id>
			var lookupURL = ctx.getVar("lookupURL");

			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "outageSubtypes",
						"label": "AMI-CONF"
					}]
				}
			};

			// invoking lookup service and getting outage subtype and id
			var LookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var lookupInfo = " TargetURL :" + lookupURL + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "trap_073: urlopen connect error with label AMI-CONF LookupServiceResponse, details are: " + lookupInfo + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500")
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message label AMI-CONF LookupServiceResponse, details are: " + lookupInfo + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from LookupServiceResponse " + responseData);
								var lookupResponse = JSON.parse(responseData);
								if (lookupResponse.lookupRep.type[0].result == '0') {
									var outageSubtypeID = lookupResponse.lookupRep.type[0].id;
									ctx.setVariable("BadVoltageoutageSubtypeID", outageSubtypeID);
								} else {
									var outageSubtypeID = "";
									ctx.setVariable("BadVoltageoutageSubtypeID", outageSubtypeID);
								}
							}
						});
					}
				}
			});
		}

		if (jobaction == "AutoClose" || jobaction == "AutoChange") {

			// GET Call Start

			var Jobapi = {
				target: Jobapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
			};

			var info = " TargetURL :" + Jobapiuri + "; Method :" + Jobapi.method + ". ";
			urlopen.open(Jobapi, function(error, response) {
				if (error) {
					var errorinfo = "trap_074: urlopen connect error with GET Jobapi with jobid,details are: " + info + "; error info: " + JSON.stringify(error);
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message of GET Jobapi with jobid, details are : " + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from jobapi for jobid:" + jobid + "" + responseStatusCode);
								var ctx = session.name("trap") || session.createContext("trap");
								var jobtypeID = JSON.parse(responseData).jobTypeID;
								var jobpayload = JSON.parse(responseData);
								ctx.setVariable("jobpayload", jobpayload);

							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "Error in reading message from GET Jobapi with jobid, details are: " + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var customErrorMessage = "Error returned from GET call Jobapi with jobid, details are: " + info + " with statusCode " + responseStatusCode + "response info : " + responseData;
								var ctx = session.name("trap") || session.createContext("trap");
								ctx.setVariable("customErrorMessage", customErrorMessage);
								var errorinfo = "Error returned from GET call Jobapi with jobid, details are: " + info + " with statusCode " + responseStatusCode + "response info : " + responseData;
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});

			// GET Call End

			// ODM Call Start

			var ODMEndpoint = session.parameters.ODMEndpoint;
			var outageSubtypeIDlabel = ctx.getVar("outageSubtypeIDlabel");
			var label = ctx.getVar("label");
			var CallcodeIDlabel = ctx.getVar("CallcodeIDlabel");

			//framing timestamp MM/DD/YYYY HH24:MI:SS
			var now = new Date();
			var year = now.getUTCFullYear();
			var month = now.getUTCMonth() + 1;
			var month1 = month.toString();
			var strmonthlength = month1.length;
			var todaymonth;
			if (strmonthlength == 1) {
				todaymonth = '0' + month;
			} else {
				todaymonth = month;
			}
			var day = now.getUTCDate();
			var day1 = day.toString();
			var strdaylength = day1.length;
			var todaydate;
			if (strdaylength == 1) {
				todaydate = '0' + day;
			} else {
				todaydate = day;
			}
			var hour = now.getUTCHours();
			var todayhour = hour.toString();
			var strhourlength = todayhour.length;
			var todayhour;
			if (strhourlength == 1) {
				todayhour = '0' + hour;
			} else {
				todayhour = hour;
			}
			var minute = now.getUTCMinutes();
			var todayminute = minute.toString();
			var strminutelength = todayminute.length;
			var todayminute;
			if (strminutelength == 1) {
				todayminute = '0' + minute;
			} else {
				todayminute = minute;
			}
			var second = now.getUTCSeconds();
			var todaysecond = second.toString();
			var strsecondlength = todaysecond.length;
			var todaysecond;
			if (strsecondlength == 1) {
				todaysecond = '0' + todaysecond;
			} else {
				todaysecond = todaysecond;
			}
			var timestampframed = year + '-' + todaymonth + '-' + todaydate + 'T' + todayhour + ':' + todayminute + ':' + todaysecond + '.000+0000';
			var ctx = session.name("trap") || session.createContext("trap");
			var payload = {
				"__DecisionID__": incomingdata.jobId,
				"inputTimeUTC": {
					"inputDatetime": timestampframed
				},
				"jobDetails": {
					"jobStatus": label,
					"callCode": CallcodeIDlabel,
					"jobSubType": outageSubtypeIDlabel
				}
			}
			//https://dte-odmoc.bpm.ibmcloud.com/odm/dev/DecisionService/rest/v1/AutoCloseAndDispatch/1.0/AutoCloseAndDispatchCheck	

			var ODMEndpoint = session.parameters.ODMEndpoint;
			var odmuri = ODMEndpoint;
			var odmapi = {
				target: odmuri,
				sslClientProfile: 'ODM_Client_Profile',
				method: 'post',
				contentType: 'application/json',
				headers: {
				},
				data: payload
			};

			var info = " TargetURL :" + odmuri + "; Method :" + odmapi.method + "; Data :" + JSON.stringify(payload) + ". ";
			urlopen.open(odmapi, function(error, response) {
				if (error) {
					var errorinfo = "trap_075: urlopen connect error with odmapi, details are: " + info + "; error info: " + JSON.stringify(error);
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo)
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message to odmapi" + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo)
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = '200 Message is received';
								logger.debug("response received from odmuri call: " + responseStatusCode);
								var odmresponse = responseData;
								var ctx = session.name("trap") || session.createContext("trap");
								var okToProceed = responseData.response.okToProceed;
								ctx.setVariable("odmresponse", odmresponse);
								ctx.setVariable("odmokToProceed", okToProceed);
								if (okToProceed) {
									var description = session.parameters.StepExitDescription;
									ILSctx.setVariable("odmStepExitPayload", payload);
									ILSctx.setVariable("exitStatus", '0');
									ILSctx.setVariable("StepExitDescription", description);
									ILSctx.setVariable("StepexitDestination", ODMEndpoint);
									STEP_rule();
								}
							}
						});
					} else {
						var errorinfo = "trap_075:Error response received from odmuri, details are : " + info + "responseStatusCode : " + responseStatusCode
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode);
						logger.error(errorinfo)
						session.reject(errorinfo);
					}
				}
			});   // ODM Call End
		}
	}
});

function STEP_rule() {
	ms.callRule('trap_ReceiveJobsEvaluation_STEP_EXIT_rule', null, null, function(error) {
		if (error) {
			logger.error("Error in trap_ReceiveJobsEvaluation_STEP_EXIT_rule");
		}
	});
}
