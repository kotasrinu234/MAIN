//js is used to set context variables

var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
var ILSctx = session.name("ILS") || session.createContext("ILS");

		var ctx = session.name("trap") || session.createContext("trap");
		//set stylesheet parameters to variable
		var lookupURL = session.parameters.lookUpURL;
		var omsExternalURL = session.parameters.omsExternalURL;
		var apiToken = session.parameters.osiApiToken;
		var omsExternalURLV1 = session.parameters.omsExternalURLV1;

		//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js
		ctx.setVariable("lookupURL", lookupURL);
		ctx.setVariable("omsExternalURL", omsExternalURL);
		ctx.setVariable("apiToken", apiToken);
		ctx.setVariable("omsExternalURLV1", omsExternalURLV1);
		var jobAction = incomingdata.jobAction;

		if (jobAction == "AutoClose" || jobAction == "AutoChange") {
			var lookupURL = session.parameters.lookUpURL;
			var omsExternalURL = session.parameters.omsExternalURL;
			var apiToken = session.parameters.osiApiToken;
			var outageSubtypeID = ctx.getVar("outageSubtypeID");
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "outageSubtypes",
						"id": outageSubtypeID
					}]
				}
			}
			var url = lookupURL;
			var LookupServiceResponse = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};

			var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "trap_068: urlopen connect error with LookupServiceResponse for outageSubtypeID, details are : " + info + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500")
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in reading error message from LookupServiceResponse for outageSubtypeID" + info + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from LookupServiceResponse for outageSubtypeID " + responseStatusCode);
								var lookupResponse = JSON.parse(responseData)

								var ctx = session.name("trap") || session.createContext("trap");
								if (lookupResponse.lookupRep.type[0].result == 0) {
									var outageSubtypeIDlabel = lookupResponse.lookupRep.type[0].label;
									ctx.setVariable("outageSubtypeIDlabel", outageSubtypeIDlabel);

									// getting styleheet params
									var ctx = session.name("trap") || session.createContext("trap");
									//var lookupURL = ctx.getVar("lookupURL");
									var omsExternalURL = ctx.getVar("omsExternalURL");
									var apiToken = ctx.getVar("apiToken");

									if (readAsJSONError) {
										logger.error("Error in reading incoming data");
										session.reject(readAsJSONError);
									} else {
										var jobTypeID = ctx.getVar("jobtypeID");
										var status = ctx.getVar("status");
										var lookupMessage = {
											"lookupReq": {
												"type": [{
													"name": "jobTypes.workflows",
													"id": jobTypeID,
													"status": status
												}]
											}
										}
										var url = lookupURL;
										var LookupServiceResponse = {
											target: url,
											method: 'POST',
											contentType: 'application/json',
											data: lookupMessage
										};
										var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												var errorinfo = "trap_069: urlopen connect error with LookupServiceResponse for jobtypeid, details are : " + info + JSON.stringify(error)
												ILSctx.setVariable("StepExiterrorinfo", errorinfo);
												ILSctx.setVariable("exitStatus", "500")
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "Failure in error message from LookupServiceResponse for jobtypeid, details are : " + info + JSON.stringify(error)
															ILSctx.setVariable("StepExiterrorinfo", errorinfo);
															ILSctx.setVariable("exitStatus", responseStatusCode)
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response received from LookupServiceResponse " + responseStatusCode);
															var lookupResponse = JSON.parse(responseData)

															var ctx = session.name("trap") || session.createContext("trap");
															if (lookupResponse.lookupRep.type[0].result == 0) {
																var label = lookupResponse.lookupRep.type[0].label;
																ctx.setVariable("label", label);

																var leadCallCodeID = ctx.getVar("leadCallCodeID");
																var lookupMessage = {
																	"lookupReq": {
																		"type": [{
																			"name": "callCodes",
																			"id": leadCallCodeID
																		}]
																	}
																}
																var url = lookupURL;
																var LookupServiceResponse = {
																	target: url,
																	method: 'POST',
																	contentType: 'application/json',
																	data: lookupMessage
																};

																var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																urlopen.open(LookupServiceResponse, function(error, response) {
																	if (error) {
																		var errorinfo = "trap_070: urlopen connect error with LookupServiceResponse for leadCallCodeID, details are : " + info + JSON.stringify(error)
																		ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																		ILSctx.setVariable("exitStatus", "500")
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "failure in error message from LookupServiceResponse for leadCallCodeID, details are :" + info + JSON.stringify(error)
																					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																					ILSctx.setVariable("exitStatus", responseStatusCode)
																					logger.error(errorinfo);
																					session.reject(errorinfo);
																				} else {
																					hm.response.statusCode = responseStatusCode;
																					logger.debug("response received from LookupServiceResponse " + responseStatusCode);
																					var lookupResponse = JSON.parse(responseData)

																					var ctx = session.name("trap") || session.createContext("trap");
																					if (lookupResponse.lookupRep.type[0].result == 0) {
																						var CallcodeIDlabel = lookupResponse.lookupRep.type[0].label;
																						ctx.setVariable("CallcodeIDlabel", CallcodeIDlabel);
																					} else {
																						var CallcodeIDlabel = "";
																						ctx.setVariable("CallcodeIDlabel", CallcodeIDlabel);

																					} // lookup end;
																				}
																			});

																		} else {
																			var errorinfo = "lookup service responsecode for leadCallCodeID" + info + JSON.stringify(error)
																			ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																			ILSctx.setVariable("exitStatus", responseStatusCode)
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}
																	}
																});

															} else {
																var label = "";
																ctx.setVariable("label", label);
															} // lookup end;
														}
													});

												} else {
													var errorinfo = "lookup service responsecode for jobtypeid, details are : " + info + JSON.stringify(error)
													ILSctx.setVariable("StepExiterrorinfo", errorinfo);
													ILSctx.setVariable("exitStatus", responseStatusCode)
													logger.error(errorinfo);
													session.reject(errorinfo);
												}
											}
										});

									} // main if end here

								} else {
									var errorinfo = "result value is not 0 from outageSubtypeIDlabel lookup"
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} // lookup end;						
							}
						});

					} else {
						var errorinfo = "Error reponse from LookupService for outageSubtypeID, details are : " + info + "; response info :" + response + "; ResponseStatusCode :" + responseStatusCode
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				}
			});

		}
	}
});
