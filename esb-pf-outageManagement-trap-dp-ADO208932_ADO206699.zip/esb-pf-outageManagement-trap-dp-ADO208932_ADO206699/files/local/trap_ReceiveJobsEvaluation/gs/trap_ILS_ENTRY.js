var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("trap") || session.createContext("trap");
var ILSctx = session.name("ILS") || session.createContext("ILS");
function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("reading input JSON payload");
	} else {
		var ctx = session.name("trap") || session.createContext("trap");
		var jobAction = incomingdata.jobAction;
		if (jobAction == "AutoClose" || jobAction == "AutoChange") {
			var ctx = session.name("trap") || session.createContext("trap");
			var jobid = incomingdata.jobId;
			var omsExternalURL = session.parameters.omsExternalURL;
			var TokenValue = session.parameters.osiApiToken;

			var Jobapiuri = omsExternalURL + 'Job/' + jobid + '?includeFields=status,outageSubtypeID,leadCallCodeID,id,jobTypeID';

			var Jobapi = {
				target: Jobapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
			};

			var info = " TargetURL :" + Jobapiuri + "; Method :" + Jobapi.method + ". ";
			urlopen.open(Jobapi, function(error, response) {
				if (error) {
					var errorinfo = "trap_067: urlopen connect error with GET Jobapi with jobid,details are: " + info + "; error info: " + JSON.stringify(error);
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message of GET Jobapi with jobid, details are : " + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from jobapi for jobid:" + jobid + "" + responseStatusCode);
								var ctx = session.name("trap") || session.createContext("trap");
								var JobPayload = JSON.parse(responseData);
								ctx.setVariable("JobPayload", JobPayload);
								

								var status = JobPayload.status;
								var outageSubtypeID = JobPayload.outageSubtypeID;
								var jobtypeID = JobPayload.jobTypeID;
								var leadCallCodeID = JobPayload.leadCallCodeID;
								if (!(leadCallCodeID == undefined || leadCallCodeID == '' || leadCallCodeID == null)) {
									ctx.setVariable("leadCallCodeID", leadCallCodeID);
								}

								ctx.setVariable("status", status);
								ctx.setVariable("outageSubtypeID", outageSubtypeID);
								ctx.setVariable("jobtypeID", jobtypeID);
								//ctx.setVariable("leadCallCodeID", leadCallCodeID);

							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "Error in reading message from GET Jobapi with jobid, details are: " + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var customErrorMessage = "Error returned from GET call Jobapi with jobid, details are: " + info + " with statusCode " + responseStatusCode + "response info : " + responseData;
								var ctx = session.name("trap") || session.createContext("trap");
								ctx.setVariable("customErrorMessage", customErrorMessage);
								var errorinfo = "Error returned from GET call Jobapi with jobid, details are: " + info + " with statusCode " + responseStatusCode + "response info : " + responseData;
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});

		}
		var ILSctx = session.name("ILS") || session.createContext("ILS");
		var sourceEventTimestamp = new Date().toISOString();
		var correlationID = incomingdata.jobId;
		var messageType = session.parameters.messageType;
		var StepExitDescription = session.parameters.StepExitDescription;

		ILSctx.setVariable("Payload", incomingdata);
		ILSctx.setVariable("correlationID", correlationID);
		ILSctx.setVariable("messageType", messageType);
		ILSctx.setVariable("StepExitDescription", StepExitDescription);


		if ((incomingdata.jobId == undefined) || (incomingdata.jobId == null) || (incomingdata.jobId == "")) {
			ILSctx.setVariable("jobID", '');
		} else {
			var jobId = incomingdata.jobId;
			ILSctx.setVariable("jobID", jobId);
		}
		if ((incomingdata.meterId == undefined) || (incomingdata.meterId == null) || (incomingdata.meterId == "")) {
			ILSctx.setVariable("meterID", '');
		} else {
			var meterId = incomingdata.meterId;
			ILSctx.setVariable("meterID", meterId);
		}
		if ((incomingdata.jobAction == undefined) || (incomingdata.jobAction == null) || (incomingdata.jobAction == "")) {
			ILSctx.setVariable("status", '');
		} else {
			var jobAction = incomingdata.jobAction;
			ILSctx.setVariable("status", jobAction);
		}
		if ((incomingdata.jobUpdatedTS == undefined) || (incomingdata.jobUpdatedTS == null) || (incomingdata.jobUpdatedTS == "")) {
			ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		} else {
			var jobUpdatedTS = incomingdata.jobUpdatedTS;
			ILSctx.setVariable("sourceEventTimestamp", jobUpdatedTS);
		}
		var jobAction = incomingdata.jobAction;
		var VoltagereadEntryDescription = session.parameters.VoltagereadEntryDescription;
		var EntryDescription = session.parameters.EntryDescription;
		var VoltagereadExitDescription = session.parameters.VoltagereadExitDescription;
		var ExitDescription = session.parameters.ExitDescription;

		if (jobAction === 'VoltageRead') {
			ILSctx.setVariable("EntryDescription", VoltagereadEntryDescription);
			ILSctx.setVariable("ExitDescription", VoltagereadExitDescription);
		} else {
			ILSctx.setVariable("EntryDescription", EntryDescription);
			ILSctx.setVariable("ExitDescription", ExitDescription);
		}
	}
});
