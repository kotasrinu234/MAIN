var urlopen = require('urlopen');
var fs = require('fs');
var util = require('util');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("trap") || session.createContext("trap");
var odmokToProceed = ctx.getVar("odmokToProceed");
var StandaloneMQurl = session.parameters.MQUrl;
var queuereportingCount = session.parameters.queuereportingCount;
session.input.readAsJSON(async function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		return session.reject(readAsJSONError);
	}
	var reportingCount = incomingdata.reportingCount;
	var ctx = session.name("trap") || session.createContext("trap");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	ILSctx.setVariable("ExitDestination", omsExternalURL);
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
	var apiToken = ctx.getVar("apiToken");
	var LookupURL = ctx.getVar("lookupURL");
	var LookupReqMsg = {
		"lookupReq": {
			"type": [{
				"name": "jobCustomFields.voltagevalidationstatus",
				"label": ""
			}]
		}
	};
	if (incomingdata.jobAction === 'BadVoltage') {
		LookupReqMsg.lookupReq.type[0].label = session.parameters.ValidationStatusBadVoltage;
		await handleBadVoltage(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg);
		var description = session.parameters.BadVoltageStepExitDescription;
		ILSctx.setVariable("exitStatus", '0');
		ILSctx.setVariable("StepExitDescription", description);
		ILSctx.setVariable("StepexitDestination", omsExternalURL);
		STEP_rule();
	} else if (incomingdata.jobAction === 'AutoClose') {
		LookupReqMsg.lookupReq.type[0].label = session.parameters.ValidationStatusGoodVoltage;
		await handleAutoClose(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg);

	} else if (incomingdata.jobAction === 'AutoChange') {
		LookupReqMsg.lookupReq.type[0].label = session.parameters.GoodVoltageValidationStatusCallcode;
		await handleAutoChange(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg);

	} else if (incomingdata.jobAction === 'VoltageRead') {
		ctx.setVar("AMICALLCHECK", "yes");
		ILSctx.setVariable("exitStatus", '0');
	} else if (incomingdata.jobAction === 'ReportingAgain') {
		if (reportingCount >= queuereportingCount) {
				QueueCall(StandaloneMQurl, incomingdata);
			}else{
				LookupReqMsg.lookupReq.type[0].label = session.parameters.ValidationStatusReportingAgain;
			}
		await handleJobOpen(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg);
		/*var description = session.parameters.ReportingAgainStepExitDescription;
		ILSctx.setVariable("exitStatus", '0');
		ILSctx.setVariable("StepExitDescription", description);
		ILSctx.setVariable("StepexitDestination", omsExternalURL);
		STEP_rule();*/
	}
	else if (incomingdata.jobAction === 'NoVoltageRead') {
		LookupReqMsg.lookupReq.type[0].label = session.parameters.ValidationStatusInconclusive;
		await handleNoVoltageRead(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg);
		var description = session.parameters.NoVoltageReadStepExitDescription;
		ILSctx.setVariable("exitStatus", '0');
		ILSctx.setVariable("StepExitDescription", description);
		ILSctx.setVariable("StepexitDestination", omsExternalURL);
		STEP_rule();
	}
	session.output.write(incomingdata);
});
async function handleBadVoltage(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg) {
	var jobId = incomingdata.jobId;
	var url = `${omsExternalURL}Job/${jobId}`;
	//lookup call BadVoltage
	var LookupResponse = {
		target: LookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: LookupReqMsg
	};
	try {
		var BadVoltageLookupCall = await LookupCall(LookupResponse);
	} catch (error) {
		logger.error("Error in handling Bad Voltage lookup call:", error);
	}

	var customFieldValues = {
		"customFieldValues": {
			"voltage_validation_status": BadVoltageLookupCall
		}
	};
	var OmsCall = {
		target: url,
		sslClientProfile: 'OMS_Client_Profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: customFieldValues
	};
	try {
		var BadVoltagePatch1 = await OMSCallAutoClose(OmsCall);
		if (BadVoltagePatch1 === "ok") {
			var outageSubtypeID = ctx.getVar("BadVoltageoutageSubtypeID");
			var outageID = {
				"outageSubtypeID": outageSubtypeID
			};
			var OmsCall = {
				target: url,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'PATCH',
				contentType: 'application/json',
				headers: {
					'osiApiToken': apiToken
				},
				data: outageID
			};
			try {
				var BadVoltagePatch2 = await OMSCallAutoClose(OmsCall);
				if (BadVoltagePatch2 === "ok") {
					var VoltsB = incomingdata.meterVb;
					var VoltsC = incomingdata.meterVc;
					var meterID = incomingdata.meterId;
					var VoltsA = incomingdata.meterVa;
					var premiseID = incomingdata.premiseId;
					var CommentOMSurl = omsExternalURL + 'Job/' + jobId + '/Comment';
					if (VoltsA !== undefined && VoltsB !== undefined && VoltsC !== undefined) {
						var polyPhaseComment = session.parameters.PolyPhaseComment + " " + "V(a): " + VoltsA + "V, " + "V(b): " + VoltsB + "V, " + "V(c): " + VoltsC + "V, V Meter: " + meterID + " Premise: " + premiseID;
						var updateComment = {
							"comment": polyPhaseComment
						};
					} else if (VoltsA !== undefined) {
						var singlePhaseComment = session.parameters.SinglePhaseComment + " " + VoltsA + " volts Meter No : " + meterID + " Premise: " + premiseID;
						var updateComment = {
							"comment": singlePhaseComment
						};
					}
					var OmsCall = {
						target: CommentOMSurl,
						sslClientProfile: 'OMS_Client_Profile',
						method: 'POST',
						contentType: 'application/json',
						headers: {
							'osiApiToken': apiToken
						},
						data: updateComment
					};
					try {
						var BadVoltagePost1 = await OMSCallJobUpdate(OmsCall);
						ctx.setVar("BadVoltagePost1", BadVoltagePost1);
					} catch (error) {
						logger.error("Error in handling Bad Voltage:", error);
					}
				} else {
					logger.debug("Error in OMS job Update call");
				}
			} catch (error) {
				logger.error("Error in handling Bad Voltage:", error);
			}

		} else {
			logger.debug("Error in OMS job Update call");
		}
	} catch (error) {
		logger.error("Error in handling Bad Voltage:", error);
	}
}
async function handleAutoClose(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg) {
	var odmokToProceed = ctx.getVar("odmokToProceed");
	if (odmokToProceed) {

		var jobpayload = ctx.getVar("jobpayload");
		var leadCallID = jobpayload.leadCallID;
		var AutoCloseurl = `${omsExternalURLV1}Call/${leadCallID}`;
		var payload = {
			"customFieldValues": {
				"CancelDueToGoodVoltage": true
			}
		};
		var OmsCall = {
			target: AutoCloseurl,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'PATCH',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		try {
			//patch call 1
			var AutoclosePatch1 = await OMSCallAutoClose(OmsCall);
			if (AutoclosePatch1 === "ok") {
				// post call 
				var jobpayload = ctx.getVar("jobpayload");
				var jobid = jobpayload.id;
				var joburl = omsExternalURL + 'Job/' + jobid + '/Comment';
				var TokenValue = apiToken;
				var meterV = incomingdata.meterVa;
				var meterId = incomingdata.meterId;
				var premiseId = incomingdata.premiseId;
				var message = 'Auto Closed: due to good voltage retuned by AMI ' + meterV + ' volts Meter No : ' + meterId + ' Premise No: ' + premiseId;
				var payload = {
					"comment": message
				}
				var OmsCall = {
					target: joburl,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: payload
				};
				try {
					var AutoclosePost1 = await OMSCallJobUpdate(OmsCall);
					var description = session.parameters.AutocloseStepExitDescription;
					ILSctx.setVariable("exitStatus", '0');
					ILSctx.setVariable("StepExitDescription", description);
					ILSctx.setVariable("StepexitDestination", omsExternalURL);
					STEP_rule();
					if (AutoclosePost1 === "ok") {
						ctx.setVar("AutoclosePost1", AutoclosePost1);
						//patch call 2
						var jobpayload = ctx.getVar("jobpayload");
						var jobid = jobpayload.id;
						var jobapiuri = omsExternalURLV1 + 'Job/' + jobid;
						var payload = {
							"customFieldValues": {
								"isAutoClosed": true
							}
						};
						var OmsCall = {
							target: jobapiuri,
							sslClientProfile: 'OMS_Client_Profile',
							method: 'PATCH',
							contentType: 'application/json',
							headers: {
								'osiApiToken': TokenValue
							},
							data: payload
						};
						try {
							var AutoclosePatch2 = await OMSCallAutoClose(OmsCall);
							if (AutoclosePatch2 === "ok") {
								//Patch call 3 
								//lookup call for autoclose patch call
								var LookupResponse = {
									target: LookupURL,
									method: 'POST',
									contentType: 'application/json',
									data: LookupReqMsg
								};
								try {
									var AutocloseLookupCall = await LookupCall(LookupResponse);
								} catch (error) {
									logger.error("Error in handling Bad Voltage lookup call:", error);
								}

								var jobpayload = ctx.getVar("jobpayload");
								var jobid = jobpayload.id;
								var jobapiuri = omsExternalURL + 'Job/' + jobid;

								var customFieldValues = {
									"customFieldValues": {
										"voltage_validation_status": AutocloseLookupCall
									}
								};
								var OmsCall = {
									target: jobapiuri,
									sslClientProfile: 'OMS_Client_Profile',
									method: 'PATCH',
									contentType: 'application/json',
									headers: {
										'osiApiToken': apiToken
									},
									data: customFieldValues
								};
								try {
									var AutoclosePatch3 = await OMSCallAutoClose(OmsCall);
									if (AutoclosePatch3 === "ok") {
										//2 post call 
										var jobpayload = ctx.getVar("jobpayload");
										var leadCallID = jobpayload.leadCallID;
										var callstatusapi = omsExternalURLV1 + 'Call/' + leadCallID + "/Status";
										var payload = "2";
										var OmsCall = {
											target: callstatusapi,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'POST',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										try {
											var AutoclosePost2 = await OMSCallJobUpdate(OmsCall);

										} catch (error) {
											logger.error("Error in handling Auto Close:", error);
										}
									} else {

									}
								} catch (error) {
									logger.error("Error in handling Auto Close:", error);
								}
							} else {
								logger.debug("Response not ok");
							}
						} catch (error) {
							logger.error("Error in handling Auto Close:", error);
						}
					} else {
						logger.debug("Response not ok");
					}

				} catch (error) {
					logger.error("Error in handling Auto Close:", error);
				}
			} else {
				logger.debug("Response not ok");
			}
		} catch (error) {
			logger.error("Error in handling Auto Close:", error);
		}

	} else {

		var LookupReqMsg = {
			"lookupReq": {
				"type": [{
					"name": "jobCustomFields.voltagevalidationstatus",
					"label": ""
				}]
			}
		};
		LookupReqMsg.lookupReq.type[0].label = session.parameters.ValidationStatusIneligible;
		var LookupResponse = {
			target: LookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: LookupReqMsg
		};
		try {
			var AutocloseLookupCall = await LookupCall(LookupResponse);
			var description = session.parameters.OdmExitDescription;
			var ODMEndpoint = session.parameters.ODMEndpoint;
			ILSctx.setVariable("exitStatus", '0');
			ILSctx.setVariable("ExitDescription", description);
			ILSctx.setVariable("ExitDestination", ODMEndpoint);
		} catch (error) {
			logger.error("Error in handling Bad Voltage lookup call:", error);
		}

		var jobpayload = ctx.getVar("jobpayload");
		var jobid = jobpayload.id;
		var jobapiuri = omsExternalURL + 'Job/' + jobid;

		var customFieldValues = {
			"customFieldValues": {
				"voltage_validation_status": AutocloseLookupCall
			}
		};
		var OmsCall = {
			target: jobapiuri,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'PATCH',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: customFieldValues
		};
		try {
			var AutoclosePatch = await OMSCallAutoClose(OmsCall);
		} catch (error) {
			logger.error("Error in handling autoclose call:", error);
		}
	}
}
async function handleAutoChange(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg) {
	var odmokToProceed = ctx.getVar("odmokToProceed");
	if (odmokToProceed) {
		var jobpayload = ctx.getVar("jobpayload");
		var leadCallID = jobpayload.leadCallID;
		var Callapiuri = omsExternalURLV1 + 'Call/' + leadCallID;
		var TokenValue = apiToken;
		var OmsCall = {
			target: Callapiuri,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},

		};
		//Get call 1
		var payload = ""
		try {
			var AutoChangeGet1 = await OMSGetAutoChange(OmsCall);
			var externalCallCodeID = JSON.parse(AutoChangeGet1).externalCallCodeID;
			ctx.setVar("AutoChangeGexternalCallCodeIDet1", externalCallCodeID);
			if (externalCallCodeID) {
				var jobpayload = ctx.getVar("jobpayload");
				var jobID = jobpayload.id;
				var Callapiuri = omsExternalURL + 'Job/' + jobID + '/Comment';
				var TokenValue = apiToken;
				var jobType = incomingdata.jobType;
				var meterV = incomingdata.meterVa;
				var meterId = incomingdata.meterId;
				var premiseId = incomingdata.premiseId;
				var message = 'Auto Changed: ' + externalCallCodeID + ' to ' + jobType + ' due to good voltage returned by AMI. ' + meterV + ' volts  Meter No :' + meterId + ' Premise No: ' + premiseId;
				var payload = {
					"comment": message
				}
				var OmsCall = {
					target: Callapiuri,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: payload
				}
				//lookup
				try {
					var AutoChangelookup = await OMSGetAutoChange(OmsCall);
					var jobID = jobpayload.id;
					var Callapiuri = omsExternalURL + 'Job/' + jobID;
					var LookupResponse = {
						target: LookupURL,
						method: 'POST',
						contentType: 'application/json',
						data: LookupReqMsg
					};
					try {
						var AutochangeLookupCall = await LookupCall(LookupResponse);
					} catch (error) {
						logger.error("Error in handling AutochangeLookupCall:", error);
					}

					var jobpayload = ctx.getVar("jobpayload");
					var jobid = jobpayload.id;
					var Callapiuri = omsExternalURL + 'Job/' + jobid;
					var customFieldValues = {
						"customFieldValues": {
							"voltage_validation_status": AutochangeLookupCall
						}
					};
					var OmsCall = {
						target: Callapiuri,
						sslClientProfile: 'OMS_Client_Profile',
						method: 'PATCH',
						contentType: 'application/json',
						headers: {
							'osiApiToken': apiToken
						},
						data: customFieldValues
					};
					try {
						var description = session.parameters.AutoChangeStepExitDescription;
						ILSctx.setVariable("exitStatus", '0');
						ILSctx.setVariable("StepExitDescription", description);
						ILSctx.setVariable("StepexitDestination", omsExternalURL);
						STEP_rule();
						var AutoChangePost1 = await OMSCallJobUpdate(OmsCall);
						if (AutoChangePost1 === "ok") {
							//3rd auto change patch call
							var jobpayload = ctx.getVar("jobpayload");
							var jobid = jobpayload.id;
							var jobapiuri = omsExternalURLV1 + 'Job/' + jobid;
							var TokenValue = apiToken;
							var payload = {
								"customFieldValues": {
									"isAutoClosed": false
								}
							}
							var OmsCall = {
								target: jobapiuri,
								sslClientProfile: 'OMS_Client_Profile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': TokenValue
								},
								data: payload
							};
							try {
								var AutoChangePatch3 = await OMSCallAutoClose(OmsCall);

								//auto change patch call 1
								var jobpayload = ctx.getVar("jobpayload");
								var autochangeLookupID = ctx.getVar("autochangeLookupID");
								var leadCallID = jobpayload.leadCallID;
								var Callapiuri = omsExternalURLV1 + 'Call/' + leadCallID;
								var TokenValue = apiToken;
								var payload = {
									"callCodeID": autochangeLookupID
								}
								var OmsCall = {
									target: Callapiuri,
									sslClientProfile: 'OMS_Client_Profile',
									method: 'PATCH',
									contentType: 'application/json',
									headers: {
										'osiApiToken': TokenValue
									},
									data: payload
								};
								try {
									var AutoChangePatch1 = await OMSGetAutoChange(OmsCall);
									var PatchCallJobID = JSON.parse(AutoChangePatch1).jobID;
									ctx.setVar("PatchCallJobID", PatchCallJobID);
									//auto change patch call 2 
									if (PatchCallJobID) {
										var jobpayload = ctx.getVar("jobpayload");
										var outageSubtypeID = jobpayload.outageSubtypeID;
										var Callapiuri = omsExternalURLV1 + 'Job/' + PatchCallJobID;
										var TokenValue = apiToken;
										var payload = {
											"outageSubtypeID": outageSubtypeID
										}
										var OmsCall = {
											target: Callapiuri,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'PATCH',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										try {
											var AutoChangePatch2 = await OMSGetAutoChange(OmsCall);
											ctx.setVar("AutoChangePatch2", AutoChangePatch2);
											/*if (AutoChangePatch2 === "ok") {
												//auto change post call 1
								11
											} else {
												logger.debug("Response not ok");
											}*/
										} catch (error) {
											logger.error("Error in handling Auto Close:", error);
										}
									} else {
										logger.debug("Response not ok");
									}
								} catch (error) {
									logger.error("Error in handling Auto Close:", error);
								}
							} catch (error) {
								logger.error("Error in handling Auto Close:", error);
							}
						} else {
							logger.debug("Response not ok");
						}
					} catch (error) {
						logger.error("Error in handling Auto Close:", error);
					}
				} catch (error) {
					logger.error("Error in handling AutochangeLookupCall:", error);
				}
			} else {
				logger.debug("Response not ok");
			}

		} catch (error) {
			logger.error("Error in handling Auto Close:", error);
		}


	} else {
		var LookupReqMsg = {
			"lookupReq": {
				"type": [{
					"name": "jobCustomFields.voltagevalidationstatus",
					"label": ""
				}]
			}
		};
		LookupReqMsg.lookupReq.type[0].label = session.parameters.ValidationStatusIneligible;
		var LookupResponse = {
			target: LookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: LookupReqMsg
		};
		try {
			var AutocloseLookupCall = await LookupCall(LookupResponse);
			var description = session.parameters.OdmExitDescription;
			var ODMEndpoint = session.parameters.ODMEndpoint;
			ILSctx.setVariable("exitStatus", '0');
			ILSctx.setVariable("ExitDescription", description);
			ILSctx.setVariable("ExitDestination", ODMEndpoint);
		} catch (error) {
			logger.error("Error in handling Bad Voltage lookup call:", error);
		}
		var jobpayload = ctx.getVar("jobpayload");
		var jobid = jobpayload.id;
		var jobapiuri = omsExternalURL + 'Job/' + jobid;

		var customFieldValues = {
			"customFieldValues": {
				"voltage_validation_status": AutocloseLookupCall
			}
		};
		var OmsCall = {
			target: jobapiuri,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'PATCH',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: customFieldValues
		};
		try {
			var AutoclosePatch = await OMSCallAutoClose(OmsCall);
		} catch (error) {
			logger.error("Error in handling autoclose call:", error);
		}
	}
}
async function handleJobOpen(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg) {
	var jobId = incomingdata.jobId;
	var reportingCount = incomingdata.reportingCount;
	var url = `${omsExternalURL}Job/${jobId}`;
	if (reportingCount < queuereportingCount){
	//lookup call for job open 
	var LookupResponse = {
		target: LookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: LookupReqMsg
	};
	try {
		var JobOpenLookupCall = await LookupCall(LookupResponse);
	} catch (error) {
		logger.error("Error in handling Bad Voltage lookup call:", error);
	}
	var customFieldValues = {
		"customFieldValues": {
			"voltage_validation_status": JobOpenLookupCall
		}
	};
	var OmsCall = {
		target: url,
		sslClientProfile: 'OMS_Client_Profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: customFieldValues
	};

	try {
		var JobOpenPatch1 = await OMSCallAutoClose(OmsCall);
		
		if (JobOpenPatch1 === "ok") {
			//post call 1
			var CommentOMSurl = omsExternalURL + 'Job/' + jobId + '/Comment';
			var JobOpenPostComment;
			 JobOpenPostComment = "Customer has been reporting issue " + reportingCount + " time within 24hrs threshold"
				var updateComment = {
					"comment": JobOpenPostComment
				};
				var OmsCall = {
					target: CommentOMSurl,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'osiApiToken': apiToken
					},
					data: updateComment
				};
				try {
					var JobOpenPost1 = await OMSCallJobUpdate(OmsCall);
					var description = session.parameters.ReportingAgainStepExitDescription;
					ILSctx.setVariable("exitStatus", '0');
					ILSctx.setVariable("StepExitDescription", description);
					ILSctx.setVariable("StepexitDestination", omsExternalURL);
					STEP_rule();
				} catch (error) {
					logger.error("Error in handling JobOpen:", error);
				}
		}
		
		else {
			logger.debug("Error in OMS job Update call");
		}
	} catch (error) {
		logger.error("Error in handling JobOpen:", error);
	}
	}
}

async function handleNoVoltageRead(incomingdata, ctx, omsExternalURL, omsExternalURLV1, apiToken, LookupURL, LookupReqMsg) {
	var jobId = incomingdata.jobId;
	var url = `${omsExternalURL}Job/${jobId}`;
	//lookup call for job open 
	var LookupResponse = {
		target: LookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: LookupReqMsg
	};
	try {
		var NoVoltageReadLookupCall = await LookupCall(LookupResponse);
	} catch (error) {
		logger.error("Error in handling NoVoltageRead lookup call:", error);
	}
	var customFieldValues = {
		"customFieldValues": {
			"voltage_validation_status": NoVoltageReadLookupCall
		}
	};
	var OmsCall = {
		target: url,
		sslClientProfile: 'OMS_Client_Profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: customFieldValues
	};

	try {
		var NoVoltageReadPatchCall = await OMSCallAutoClose(OmsCall);
		ctx.setVar("NoVoltageReadPatchCall", NoVoltageReadPatchCall);
	} catch (error) {
		logger.error("Error in handling NoVoltageRead:", error);
	}
}

function OMSCallJobUpdate(OmsCall) {
	return new Promise((resolve, reject) => {
		var info = `TargetURL: ${OmsCall.target}; Method: ${OmsCall.method}; Data: ${JSON.stringify(OmsCall.data)}.`;
		urlopen.open(OmsCall, (error, response) => {
			if (error) {
				var errorinfo = "trap_077: urlopen connect error with OmsCall, details are: " + info + JSON.stringify(error)
				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
				ILSctx.setVariable("exitStatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsBuffer((error, responseData) => {
					if (error) {
						var errorinfo = "Failure in reading message from OmsCall" + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
					var responseData = response;
					hm.response.statusCode = responseStatusCode;
					logger.debug("Response received from OmsCall", responseStatusCode);
					session.output.write(responseData);
					resolve("ok");
				});
			} else if (responseStatusCode == 400) {
				response.readAsBuffer(function(error, responseData) {
					var responseStr = responseData.toString();
					ctx.setVariable("responseStr", responseStr);

					if (error) {
						var errorinfo = "Error response from OMSCallJobUpdate" + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else if (responseStr === "No updates") {
						var errorinfo = "Error response received from OMSCallJobUpdate, details are:" + info + " with status code: " + responseStatusCode + "response info:" + responseData
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						var responseData = response;
						hm.response.statusCode = "200";
						logger.debug("Response received from OmsCall", responseStatusCode);
						session.output.write(responseData);
						resolve("ok");
					}
					else {
						var errorinfo = "Error response received from OMSCallJobUpdate, details are:" + info + " with status code: " + responseStatusCode + "response info:" + responseData
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Error response from OMSCallJobUpdate" + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response received from OMSCallJobUpdate, details are:" + info + " with status code: " + responseStatusCode + "response info:" + responseData
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);

					}
				});
			}
		});
	});
}

function OMSCallAutoClose(OmsCall) {
	return new Promise((resolve, reject) => {
		var info = `TargetURL: ${OmsCall.target}; Method: ${OmsCall.method}; Data: ${JSON.stringify(OmsCall.data)}.`;
		urlopen.open(OmsCall, (error, response) => {
			if (error) {
				var errorinfo = "trap_078: urlopen connect error with OmsCall, details are: " + info + JSON.stringify(error)
				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
				ILSctx.setVariable("exitStatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
			var responseStatusCode = response.statusCode;
			if (responseStatusCode === 200) {
				response.readAsBuffer((error, responseData) => {
					if (error) {
						var errorinfo = "Failure in reading message from OmsCall, details are: " + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
					hm.response.statusCode = '200';
					logger.debug("Response received from OmsCall", responseStatusCode);
					resolve("ok");
				});
			} else if (responseStatusCode === 400) {
				response.readAsBuffer((error, responseData) => {
					var responseStr = responseData.toString();
					ctx.setVariable("responseStr", responseStr);
					if (error) {
						var errorinfo = "Failure in reading message from OmsCall, details are: " + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else if (responseStr === "No updates") {
						hm.response.statusCode = "200";
						logger.debug("Response received from OmsCall", responseStatusCode);
						var responseData = response;
						//hm.response.statusCode = responseStatusCode;
						logger.debug("Response received from OmsCall", responseStatusCode);
						session.output.write(responseData);
						resolve("ok");
					} else {
						hm.response.statusCode = responseStatusCode;
						logger.debug("Response received from OmsCall", responseStatusCode);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			} else {
				//logger.error("Error reading response from OmsCall", responseStatusCode);
				//session.reject(`Error returned with statusCode ${responseStatusCode}`);
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Error response from OMSCall, details are :" + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response received from OMSCall, details are:" + info + "with status code:" + responseStatusCode + "response info :" + responseData
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		});
	});
}

function OMSGetAutoChange(OmsCall) {
	return new Promise((resolve, reject) => {
		var info = `TargetURL: ${OmsCall.target}; Method: ${OmsCall.method}; Data: ${JSON.stringify(OmsCall.data)}.`;
		urlopen.open(OmsCall, (error, response) => {
			if (error) {
				var errorinfo = "trap_079: urlopen connect error with OmsCall, details are:" + info + JSON.stringify(error)
				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
				ILSctx.setVariable("exitStatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
			var responseStatusCode = response.statusCode;
			if (responseStatusCode === 200) {
				response.readAsBuffer((error, responseData) => {
					if (error) {
						var errorinfo = "Failure in reading message from OmsCall, details are: " + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
					}
					hm.response.statusCode = "200";
					logger.debug("Response received from OmsCall", responseStatusCode);
					resolve(responseData);
				});
			} else if (responseStatusCode === 400) {
				response.readAsBuffer((error, responseData) => {
					var responseStr = responseData.toString();
					ctx.setVariable("responseStr", responseStr);
					if (responseStr === "No updates") {
						hm.response.statusCode = "200";
						logger.debug("Response received from OmsCall", responseStatusCode);
						var responseData = response;
						logger.debug("Response received from OmsCall", responseStatusCode);
						session.output.write(responseData);
						resolve("ok");
					}
					else {
						if (error) {
							var errorinfo = "Failure in reading message from OmsCall, details are: " + info + JSON.stringify(error)
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
						}
						else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("Response received from OmsCall", responseStatusCode);
							//resolve(responseData);
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							session.reject(errorinfo);
						}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Error response from OMSCallAutoChange, details are: " + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response received from OMSCallAutoChange, details are : " + info + "with status code : " + responseStatusCode + "response info :" + responseData
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}

		});
	});
}

function LookupCall(LookupResponse) {
	return new Promise((resolve, reject) => {
		//var info = `TargetURL: ${OmsCall.target}; Method: ${OmsCall.method}; Data: ${JSON.stringify(OmsCall.data)}.`;
		urlopen.open(LookupResponse, (error, response) => {
			if (error) {
				var errorinfo = "trap_080: urlopen connect error of LookupCall for voltagevalidationstatus" + JSON.stringify(error)
				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
				ILSctx.setVariable("exitStatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
			var responseStatusCode = response.statusCode;
			if (responseStatusCode === 200) {
				response.readAsBuffer((error, responseData) => {
					if (error) {
						var errorinfo = "Failure in reading message LookupCall for voltagevalidationstatus, details are: " + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
					hm.response.statusCode = responseStatusCode;
					logger.debug("Response received from OmsCall", responseStatusCode);
					var lookupResponse = JSON.parse(responseData)
					if (lookupResponse.lookupRep.type[0].result == '0') {
						var Identifier = lookupResponse.lookupRep.type[0].status;
						session.output.write(lookupResponse);
						resolve(Identifier);
					} else {
						var errorinfo = "lookupresponse of voltagevalidationstatus doesn't have a return label ,result =1"
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
			else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Error response LookupCall for voltagevalidationstatus" + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response received LookupCall for voltagevalidationstatus " + ";" + "with status code :" + responseStatusCode + "response info :" + responseData
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		});
	});
}
var description = session.parameters.AutoDispatchStepExitDescription;
var StepExitStatus = session.parameters.StepExitStatus;
function QueueCall(StandaloneMQurl, incomingdata) {
	var pushingToQueue = {
		target: StandaloneMQurl,
		data: incomingdata
	};
	var info = " TargetURL :" + pushingToQueue.target + "; Data :" + pushingToQueue.data + ". ";
	try {
		urlopen.open(pushingToQueue, function(error, response) {
			if (error) {
				var errorinfo = "trap_084:url connection error 'TRAP.AUTO.DISPATCH.CHECK Queue', details are : " + info + "; error info :" + error
				ILSctx.setVariable('exitStatus', '500');
				ILSctx.setVariable('StepExiterrorinfo', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							var errorinfo = "Error reading the response , details are : " + info + "; error info :" + readError
							ILSctx.setVariable('exitStatus', mqrc);
							ILSctx.setVariable('StepExiterrorinfo', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							ILSctx.setVariable('exitStatus', '0');
							ILSctx.setVariable('StepExitDescription', description)
							ILSctx.setVariable('StepexitDestination', StandaloneMQurl);
							ILSctx.setVariable("status", StepExitStatus);
							logger.debug("MQResponsecode " + mqrc);
							session.output.write(incomingdata);
							STEP_rule();
						}
					});
				} else {
					var errorinfo = "trap_085:Error received from the response of TRAP.AUTO.DISPATCH.CHECK Queue, details are : " + info + "; response info :" + response + "; ResponseStatusCode :" + response.statusCode
					ILSctx.setVariable('exitStatus', mqrc);
					ILSctx.setVariable('StepExiterrorinfo', errorinfo)
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			}
		});
	} catch (err) {
		var errorinfo = "trap_084:url connection error 'TRAP.AUTO.DISPATCH.CHECK Queue', details are : " + info + "; error info :" + err
		ILSctx.setVariable('exitStatus', '500');
		ILSctx.setVariable('StepExiterrorinfo', errorinfo)
		logger.error(errorinfo);
		session.reject(errorinfo);
	}
}

function STEP_rule() {
	ms.callRule('trap_ReceiveJobsEvaluation_STEP_EXIT_rule', null, null, function(error) {
		if (error) {
			logger.error("Error in trap_ReceiveJobsEvaluation_STEP_EXIT_rule");
		}
	});
}
