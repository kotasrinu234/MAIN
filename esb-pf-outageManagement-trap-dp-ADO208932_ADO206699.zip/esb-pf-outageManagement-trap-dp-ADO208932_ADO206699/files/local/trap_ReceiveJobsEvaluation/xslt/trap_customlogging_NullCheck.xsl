<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpquery="http://www.datapower.com/param/query"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:regexp="http://exslt.org/regular-expressions"
	extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ser="http://dteco.com/DeviceManagement/ServiceOrder"
	version="1.0">
	<xsl:variable name="Delimiter" select="'_'" />
		<xsl:param name="dpconfig:NullcheckRequired"/>
	<xsl:template match="/">
	
	<xsl:variable name="TransactoinID">
	<xsl:copy-of
					select="dp:variable('var://service/global-transaction-id')" />
	</xsl:variable>
		<xsl:variable name="TimeStamp">
			<xsl:value-of select="date:date-time()"/>
		</xsl:variable>

<xsl:variable name="jobId">
<xsl:value-of select="/*[local-name()='object']/*[local-name()='string'][@name='jobId']/text()"/>
</xsl:variable>

<!-- jobTypeID is used in lookup call file -->
<xsl:variable name="jobAction">
<xsl:value-of select="/*[local-name()='object']/*[local-name()='string'][@name='jobAction']/text()"/>
</xsl:variable>


<!-- null check and custom logging -->
<xsl:message dp:type="all" dp:priority="debug">trap_132 CEP REQUEST: <xsl:value-of select="concat('TransactoinID:',$TransactoinID,' jobId:',$jobId,' jobAction:',$jobAction,' TimeStamp:',$TimeStamp )"/></xsl:message>
	<xsl:if test="$dpconfig:NullcheckRequired ='true'">	
<xsl:choose>
	<xsl:when test="string-length(normalize-space($jobId))&gt; 0">
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error">trap_133 TransactionID :<xsl:value-of select="$TransactoinID"/> jobId is missing in CEP request</xsl:message>				
	<dp:reject>displayID is missing in oms request</dp:reject>
	</xsl:otherwise>
	</xsl:choose>
	
	<xsl:choose>
	<xsl:when test="string-length(normalize-space($jobAction))&gt; 0">
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error">trap_133 TransactionID :<xsl:value-of select="$TransactoinID"/> jobAction is missing in CEP request</xsl:message>				
		<dp:reject>jobTypeID is missing in oms request</dp:reject>
	</xsl:otherwise>
	</xsl:choose>
	
	</xsl:if>		
	<!-- null check end -->	

<!-- null check and logging end -->

		
		<xsl:call-template name="set_ILS_Context">
			<xsl:with-param name="jobId" select="$jobId" />
						<xsl:with-param name="jobAction" select="$jobAction" />
			<xsl:with-param name="TimeStamp" select="$TimeStamp" />
			</xsl:call-template>
	</xsl:template>

	<xsl:template name="set_ILS_Context">
		<xsl:param name="jobId" />
		<xsl:param name="jobAction" />
		<xsl:param name="TimeStamp" />

		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()"/>
		<dp:set-variable name="'var://context/TimeStamp'" value="$TimeStamp" />
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'RECEIVED'"/>
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'CEP'"/>
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')"/>
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))"/>
		<dp:set-variable name="'var://context/ServiceLog/User'" value="' '"/>
		
		
		<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="string($jobId)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="string($jobAction)"/>
		
		
	</xsl:template>
</xsl:stylesheet>
