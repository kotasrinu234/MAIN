<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

<xsl:variable name="TransactionID">
	<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
			
</xsl:variable>

<xsl:choose>
		<xsl:when
    test="contains(dp:variable('var://service/error-message'), 'Unable to parse JSON') 
          or contains(dp:variable('var://service/error-message'), 'Invalid JSON format')">
<xsl:variable name="errorMessage" select="concat('trap_065: ', 'ErrorMessage: ', dp:variable('var://service/error-message'), ' ', 'TransactionID: ', $TransactionID)" />
				<xsl:message dp:type="all" dp:priority="error">
					trap_065 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'500'" />
			    <dp:set-variable name="'var://context/ILS/StepExiterrorinfo'" value="$errorMessage" />
			    <dp:set-variable name="'var://context/ILS/exitStatus'" value="'500'"/>
					
			</xsl:when>
		</xsl:choose>

<xsl:message dp:type="all" dp:priority="error">trap_065:TransactionID:<xsl:value-of select="$TransactionID"/> ErrorCode:<xsl:value-of select="dp:variable('var://service/error-headers')"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>	

<dp:set-variable name="'var://service/error-protocol-response'" value="dp:variable('var://service/error-headers')" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="concat('TransactionID: ',$TransactionID,' ',dp:variable('var://service/error-message'))" />

<dp:set-http-response-header
		name="'Content-Type'" value="'application/json'" />		
	</xsl:template>
</xsl:stylesheet>
