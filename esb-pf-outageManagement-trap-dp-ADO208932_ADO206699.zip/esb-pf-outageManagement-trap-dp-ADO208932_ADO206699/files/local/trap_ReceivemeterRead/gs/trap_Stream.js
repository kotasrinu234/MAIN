var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("trap") || session.createContext("trap");
	var BackoutMessage = ctx.getVar("BackoutMessage");
	var errorStringpayload = ctx.getVar("BackoutMessageData");//errorpayload
var eventHubURL = "https://" + session.parameters.Hub_NameSpace + ".servicebus.windows.net/" + session.parameters.eventHub + "/messages";
ctx.setVariable("eventHubURL", eventHubURL);
		var Auth = ctx.getVar("Auth");
	session.output.write(incomingdata)
	    var OmsGetCallResponse = ctx.getVar("OmsGetCallResponse");
		var externalCallCodeID = ctx.getVar("externalCallCodeID");
		var MeterId = ctx.getVar("meterReadingmeterID");
		var premiseID = ctx.getVar("premiseID");
		var jobId = OmsGetCallResponse.id;
		var jobSubType = ctx.getVar("outageSubtypeslabel");
		var jobStatus = ctx.getVar("JOBStatuslable");
		var jobCreatedTS = OmsGetCallResponse.createdAt;
		var meterId = ctx.getVar("meterID");
		var eventTimeStamp = new Date().toISOString();

		var AdlsResponse = ctx.getVar("responseDataMeter");
		var odmresponse = ctx.getVar("odmresponse");
			var ILSctx = session.name("ILS") || session.createContext("ILS");

	// if no voltage read data 
	var ErrorString = ctx.getVar("ErrorString");
	if (ErrorString !== 'yes') {
		// CEP Call
		var odmresponsestatus = odmresponse.response.okToProceed;
		if (odmresponsestatus) {
			var AutoDispFSA = odmresponse.autoCloseAndDispatchParameters.autoDispatchEnabled;
			if (AutoDispFSA) {
				var AutoDispFSA1 = "Y";
			} else {
				var AutoDispFSA1 = "N";
			}

			var inOfficeHrs = odmresponse.response.inEfoOfficeHours;
			if (inOfficeHrs) {
				var inOfficeHrs1 = "Y";
			} else {
				var inOfficeHrs1 = "N";
			}

			var autoCloseStdDuration = odmresponse.autoCloseAndDispatchParameters.autoCloseTimeWindow;
			var maxPercentageVolatageDiff = odmresponse.autoCloseAndDispatchParameters.maxPercentageVoltageDiff;

			if (readAsJSONError) {
				logger.error("Error in reading incoming data");
				session.reject("Error in reading incoming data");
			} else {
				var phase = AdlsResponse.meterPhase;
				if (phase == "SINGLEPHASE") {
					var meterVa = ctx.getVar("readingValueValueVA1");
					var nomVa = AdlsResponse.nominalVoltageA;
					var meterReadTS = ctx.getVar("readingValuetimeStampVA1");
					var payload = {
						"msgType": "JobData",
						"jobId": jobId,
						"jobType": externalCallCodeID,
						"jobSubType": jobSubType,
						"jobStatus": jobStatus,
						"premiseId": premiseID,
						"meterId": MeterId,
						"meterVa": meterVa,
						"nomVa": nomVa,
						"AutoDispFSA": AutoDispFSA1,
						"inOfficeHrs": inOfficeHrs1,
						"autoCloseStdDuration": autoCloseStdDuration,
						"maxPercentageVolatageDiff": maxPercentageVolatageDiff,
						"meterReadTS": meterReadTS,
						"jobCreatedTS": jobCreatedTS,
						"eventTimeStamp":eventTimeStamp
					};
					var arr = [{
						"originalExemptJobType": "",
						"resultingChangeToJobType": ""
					}];

					arr[0].originalExemptJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].originalExemptCallCode;
					arr[0].resultingChangeToJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].resultingChangeToCallCode;

					payload.exemptJobAutoChangeParameters = arr;

					ctx.setVariable("CepPayload", payload);
					var StreamDescription = session.parameters.StreamDescription;
					var eventHubCall = {
						target: eventHubURL,
						sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
						method: 'POST',
						headers: {
							'Authorization': Auth,
						},
						contentType: 'application/json',
						data: payload
					};

					CepCall(eventHubCall, payload, eventHubURL);
					ILSctx.setVariable("exitStatus", "0");
					ILSctx.setVariable("exitDestination", eventHubURL);
					ILSctx.setVariable("description", StreamDescription);
					session.output.write(payload);

				} else {
					var meterVa = ctx.getVar("readingValueValueVA");
					var meterVb = ctx.getVar("readingValueValueVB");
					var meterVc = ctx.getVar("readingValueValueVC");

					var nomVa = AdlsResponse.nominalVoltageA;
					var nomVb = AdlsResponse.nominalVoltageB;
					var nomVc = AdlsResponse.nominalVoltageC;

					var payload = {
						"msgType": "JobData",
						"jobId": jobId,
						"jobType": externalCallCodeID,
						"jobSubType": jobSubType,
						"jobStatus": jobStatus,
						"premiseId": premiseID,
						"meterId": MeterId,
						"meterVa": meterVa,
						"meterVb": meterVb,
						"meterVc": meterVc,
						"nomVa": nomVa,
						"nomVb": nomVb,
						"nomVc": nomVc,
						"AutoDispFSA": AutoDispFSA1,
						"inOfficeHrs": inOfficeHrs1,
						"autoCloseStdDuration": autoCloseStdDuration,
						"maxPercentageVolatageDiff": maxPercentageVolatageDiff,
						"meterReadTS": meterReadTS,
						"jobCreatedTS": jobCreatedTS,
						"eventTimeStamp":eventTimeStamp
					};
					var arr = [{
						"originalExemptJobType": "",
						"resultingChangeToJobType": ""
					}];

					arr[0].originalExemptJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].originalExemptCallCode;
					arr[0].resultingChangeToJobType = odmresponse.autoCloseAndDispatchParameters.exemptJobAutoChangeParameters[0].resultingChangeToCallCode;

					payload.exemptJobAutoChangeParameters = arr;
					ctx.setVariable("CepPayload", payload);
					var StreamDescription = session.parameters.StreamDescription;
					var eventHubCall = {
						target: eventHubURL,
						sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
						method: 'POST',
						headers: {
							'Authorization': Auth,
						},
						contentType: 'application/json',
						data: payload
					};
					CepCall(eventHubCall, payload, eventHubURL);
					ILSctx.setVariable("exitStatus", "0");
					ILSctx.setVariable("exitDestination", eventHubURL);
					ILSctx.setVariable("description", StreamDescription);
					session.output.write(payload);
				}
			}
		} else {
			var NotOKtoProceedExitDescription = session.parameters.NotOKtoProceed;
			var GetCallByJobRequest = ctx.getVar("GetCallByJobRequest");
			var premiseIdList = GetCallByJobRequest.map(item => item.externalPremiseID);
			//var premiseIdList = GetCallByJobRequest[0].externalPremiseID;
			var payload = {
				"msgType": "JobIneligible",
				"jobId": jobId,
				"jobType": externalCallCodeID,
				"jobSubType": jobSubType,
				"jobStatus": jobStatus,
				"premiseId": premiseID,
				"meterId": meterId,
				"jobUpdatedTS": jobCreatedTS,
				"premiseIdList":premiseIdList
			}
			var eventHubCall = {
				target: eventHubURL,
				sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
				method: 'POST',
				headers: {
					'Authorization': Auth,
				},
				contentType: 'application/json',
				data: payload
			};

			CepCall(eventHubCall, payload, eventHubURL);
			ILSctx.setVariable("callcheck", "JobIneligible");
			ILSctx.setVariable("exitStatus", "0");
			ILSctx.setVariable("exitDestination", eventHubURL);
			ILSctx.setVariable("description", NotOKtoProceedExitDescription);
			//logger.error(payload)
			session.output.write(payload)
		}
	}
	else {
		if (ErrorString === 'yes' && errorStringpayload && errorStringpayload.includes("TargetNotFound")) {
			var GetCallByJobRequest = ctx.getVar("GetCallByJobRequest");
			var premiseIdList = GetCallByJobRequest.map(item => item.externalPremiseID);
			//var premiseIdList = GetCallByJobRequest[0].externalPremiseID;
			var payload = {
				"msgType": "InvalidMeter",
				"jobId": jobId,
				"jobType": externalCallCodeID,
				"jobSubType": jobSubType,
				"jobStatus": jobStatus,
				"meterId": meterId,
				"premiseId": premiseID,
				"jobUpdatedTS": jobCreatedTS,
				"premiseIdList":premiseIdList
			}

			{

				var eventHubCall = {
					target: eventHubURL,
					sslClientProfile: 'trap_GetToken_SSL_ClientProfile',
					method: 'POST',
					headers: {
						'Authorization': Auth,
					},
					contentType: 'application/json',
					data: payload
				};

				CepCall(eventHubCall, payload, eventHubURL);
				ILSctx.setVariable("ILSvariable", "yes");
				//logger.error(payload)
				session.output.write(payload)


			}
		}
	}
	// CEP Call

	//function for CEP call			
	function CepCall(eventHubCall, payload, eventHubURL) {
		var info = " TargetURL :" + eventHubCall.target + "; Method :" + eventHubCall.method + "; Data :" + JSON.stringify(payload) + ". ";
		try {
			urlopen.open(eventHubCall, function(error, response) {
				if (error) {
					var errorinfo = "trap_062: urlopen connect error of 'eventHubURL',details are: " + info + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500")
					ctx.setVariable("retry", 'yes');
					logger.error(errorinfo);
					ctx.setVariable("ErrorTxt", errorinfo);
					//session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if ((responseStatusCode == 200) || (responseStatusCode == 201)) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in reading response of 'eventHubURL',details are: " + info + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error in reading message of 'eventHubURL',details are: " + info + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "trap_063: error response returned from 'eventHubURL', details are: " + info + "with status code :" + responseStatusCode + "Responseinfo: " + responseData
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								ctx.setVariable("retry", 'yes');
								logger.error(errorinfo);
								ctx.setVariable("ErrorTxt", errorinfo);
								//session.reject(errorinfo);
							}
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "trap_062: urlopen connect error of 'eventHubURL',details are: " + info + JSON.stringify(error)
			ILSctx.setVariable("StepExiterrorinfo", errorinfo);
			ILSctx.setVariable("exitStatus", "500")
			ctx.setVariable("retry", 'yes');
			ctx.setVariable("ErrorTxt", errorinfo);
			logger.error(errorinfo);
			//session.reject(errorinfo);
		}
	};

});
