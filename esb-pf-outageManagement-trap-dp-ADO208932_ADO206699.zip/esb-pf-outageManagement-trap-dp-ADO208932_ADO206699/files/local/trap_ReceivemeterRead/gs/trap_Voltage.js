//this js is used for interacting with voltage read service
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	function uuidv4() {
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
			var r = Math.random() * 16 | 0,
				v = c == 'x' ? r : (r & 0x3 | 0x8);
			return v.toString(16);
		});
	}

	var ctx = session.name("trap") || session.createContext("trap");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	//var odmresponseValue = ctx.getVar("odmresponse");
	//var odmresponsestatus = odmresponseValue.response.okToProceed;
	var OmsGetCallResponse = ctx.getVar("OmsGetCallResponse");
	var jobId = OmsGetCallResponse.id;
	var ErrorString = ctx.getVar("ErrorString");
	if (ErrorString !== 'yes') {
		var ctx = session.name("trap") || session.createContext("trap");
		/*if (ErrorString === 'yes') {
			session.output.write(incomingdata);
		} else {*/
		var ctx = session.name("trap") || session.createContext("trap");
		//var apiToken = ctx.getVar("apiToken");
		var odmresponseValue = ctx.getVar("odmresponse");
		var odmresponsestatus = odmresponseValue.response.okToProceed;
		var MeterId = ctx.getVar("meterReadingmeterID");
		var getMeterInfoUrl = session.parameters.getMeterInfoUrl;
		var correlationID1 = uuidv4();

		if (odmresponsestatus == true) {
			if (readAsJSONError) {
				logger.error("Error in reading incoming data");
				session.reject("Error in reading incoming data");
			} else {
				var getUrl = getMeterInfoUrl + '/GetMeterInfo/v1?messageID=' + correlationID1 + '&meterID=' + MeterId + '&recentVoltageNeeded=N';
				var getMeterInfo = {
					target: getUrl,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'GET',
					contentType: 'application/json',
					headers: {
						"osiApiToken": apiToken
					},
				};
				var info = " TargetURL :" + getMeterInfo.target + "; Method :" + getMeterInfo.method + ". ";
				try {
					urlopen.open(getMeterInfo, function(error, response) {
						if (error) {
							var errorinfo = "trap_054: URL connection error with 'getMeterInfo', details are: " + info + "; Error: " + error;
							ILSctx.setVar('StepExiterrorinfo', errorinfo);
							ILSctx.setVariable("exitStatus", "500");
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "Failure in reading response from 'getMeterInfo', details: " + info + "; Error: " + error;
										ILSctx.setVar('StepExiterrorinfo', errorinfo);
										ILSctx.setVariable("exitStatus", responseStatusCode);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										ctx.setVariable("responseDataMeter", responseData);
										ILSctx.setVariable("callcheck", "MeterInfo");
										ILSctx.setVariable("MeterInfoStepexitDestination", getUrl);
										ILSctx.setVariable("MeterInfoStepExitPayload", responseData);
										STEP_rule();
									}
								});
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "Error reading response from 'getMeterInfo', details: " + info + "; Error: " + error;
										ILSctx.setVar('StepExiterrorinfo', errorinfo);
										ILSctx.setVariable("exitStatus", responseStatusCode);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var errorinfo = "trap_055: Unexpected error from 'getMeterInfo', details are: " + info + "with Status code: " + responseStatusCode + "; Response: " + responseData;
										ILSctx.setVar('StepExiterrorinfo', errorinfo);
										ILSctx.setVariable("exitStatus", responseStatusCode);
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
								});
							}
						}
					});
				} catch (error) {
					var errorinfo = "trap_054: URL connection error with 'getMeterInfo', details are: " + info + "; Error: " + error;
					ILSctx.setVar('StepExiterrorinfo', errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			}
		} else {
			var Transactionid = ctx.getVar("Transactionid");
			var jobid = Transactionid;
			var omsExternalURL = ctx.getVar("omsExternalURL");
			var ODMEndpoint = ctx.getVar("ODMEndpoint");
			var jobapiuri = omsExternalURL + 'Job/' + jobid;
			var ValidationStatusIneligible = session.parameters.ValidationStatusIneligible;
			var odmresponse = ctx.getVar("odmresponse");
			ILSctx.setVariable("callcheck", "ODMNotOkToProceed");
			ILSctx.setVariable("odmStepexitDestination", ODMEndpoint);
			ILSctx.setVariable("odmExitPayload", odmresponse);
			STEP_rule();
			// lookuos call for Patch call 
			var lookupURL = ctx.getVar("lookupURL");
			//lookup call
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "jobCustomFields.voltagevalidationstatus",
						"label": ValidationStatusIneligible
					}]
				}
			};
			var LookupResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + lookupURL + "; Method :" + LookupResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";
			urlopen.open(LookupResponse, function(error, response) {
				if (error) {
					var errorinfo = "trap_056: urlopen connect error from LookupServiceResponse for voltagevalidationstatus 'Ineligible', details are ," + info + "error info :" + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "Failure in reading error message from LookupServiceResponse for outageSubtypeID details are ," + info + "error info :" + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response code received from trap_ReceiveJobStatus outageSubtypes LookupServiceResponse " + responseStatusCode);
								//session.output.write(JSON.parse(responseData));
								var lookupResponse = JSON.parse(responseData)
								//logger.error("lookupResponse" + lookupResponse)
								if (lookupResponse.lookupRep.type[0].result == '0') {
									var Identifier = lookupResponse.lookupRep.type[0].status;
									//logger.error("Identifier" + Identifier)
									//session.output.write(lookupResponse);

									var PatchPayload = {
										"customFieldValues": {
											"voltage_validation_status": Identifier
										}
									};
									// Prepare job API call details
									var jobapi = {
										target: jobapiuri,
										sslClientProfile: 'OMS_Client_Profile',
										method: 'PATCH',
										contentType: 'application/json',
										headers: {
											'osiApiToken': apiToken
										},
										data: PatchPayload
									};
									var info = " TargetURL :" + jobapi.target + "; Method :" + jobapi.method + "; Data :" + JSON.stringify(PatchPayload) + ". ";

									urlopen.open(jobapi, function(error, response) {
										if (error) {
											var errorinfo = "trap_057: urlopen connect error while sending patch call request for voltagevalidationstatus 'Ineligible', details are: " + info + " ; error info: " + JSON.stringify(error);
											ILSctx.setVariable("StepExiterrorinfo", errorinfo);
											ILSctx.setVariable("exitStatus", "500");
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var responseStatusCode = response.statusCode;
											if ((responseStatusCode === 200) || (responseStatusCode === 400)) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "failure in reading message to jobapi" + info + "; error info: " + JSON.stringify(error);
														ILSctx.setVariable("StepExiterrorinfo", errorinfo);
														ILSctx.setVariable("exitStatus", responseStatusCode);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														hm.response.statusCode = responseStatusCode;
														//main exit
														ILSctx.setVariable("exitDestination", ODMEndpoint);
														ILSctx.setVariable("exitStatus", "0");
														var ExitDescription = session.parameters.OdmExitDescription;
														ILSctx.setVariable("description", ExitDescription);
														session.output.write(PatchPayload);
													}
												});
											} else {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "error in reading message from jobapi Patch operation for jobid " + info + " ; error info: " + JSON.stringify(error);
														ILSctx.setVariable("StepExiterrorinfo", errorinfo);
														ILSctx.setVariable("exitStatus", responseStatusCode);
														logger.error(errorinfo);
														//session.reject(errorinfo);
														//session.reject("urlopen connect error " + JSON.stringify(error));
													} else {
														var errorinfo = "trap_058:Error response received from patch call request for voltagevalidationstatus 'Ineligible', details are: " + info + "ResponseStausCode: " + responseStatusCode + "Response Info :" + responseData
														ILSctx.setVariable("StepExiterrorinfo", errorinfo);
														ILSctx.setVariable("exitStatus", responseStatusCode);
														logger.error(errorinfo);
														//session.reject("urlopen connect error " + JSON.stringify(error));
													}
												});
											}
										}
									});
								} else {
									var errorinfo = "trap_059: lookupresponse doesn't have a return label ,result =1 for voltagevalidationstatus 'Ineligible', details are: " + info + " error info :" + JSON.stringify(error);
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", "400");
									session.reject("outageSubtypes lookupresponse doesn't have a return label ,result =1");
								}
							}
						});
					}
				}
			});
			
				// GetCallByJobRequest (ADO163094)

			var jobApiUri = omsExternalURL + 'Job/' + jobId + '/Call' + '?includeFields=createdAt,externalPremiseID,meterID,externalCallCodeID';
		var jobApi = {
			target: jobApiUri,
			method: 'GET',
			sslClientProfile: 'OMS_Client_Profile',
			headers: {
				'osiApiToken': apiToken
			},
			contentType: 'application/json'
		};
		var info = " TargetURL :" + jobApi.target + "; Method :" + jobApi.method + ". ";
		// Make the GET request
		urlopen.open(jobApi, function(error, response) {
			if (error) {
				var errorinfo = "url open connect error for OMS GetCallByJobRequest, details are: " + info + JSON.stringify(error)
				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
				ILSctx.setVariable("exitStatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "Failure in reading message from OMS GetCallByJobRequest, details are: " + info + JSON.stringify(error)
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							logger.debug("GetCallByJobRequest details received: " + JSON.stringify(responseData));
							ctx.setVariable("GetCallByJobRequest", responseData);
							hm.response.statusCode = '200';
							session.output.write(responseData);
						}
					});
				} else {
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "Error reading response from OMS GetCallByJobRequest, details are: " + info + JSON.stringify(readError);
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "Error response from OMS GetCallByJobRequest, details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		});
		}
		//}	
	}

	// Get token call 
	var GetTokenUrl = session.parameters.GetTokenUrl
	var Options = {
		target: GetTokenUrl,
		sslClientProfile: 'OMS_Client_Profile',
		method: 'GET',
		contentType: 'application/json'
	};
	var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";

	urlopen.open(Options, function(error, response) {
		if (error) {
			var errorinfo = "trap_060: urlopen connect error of GetTokenURL, details are: " + info + JSON.stringify(error)
			ILSctx.setVariable("exitStatus", "500");
			ILSctx.setVariable("StepExiterrorinfo", errorinfo);
			ctx.setVariable("retry", 'yes');
			logger.error(errorinfo);
			ctx.setVariable("ErrorTxt", errorinfo);
			//session.reject(errorinfo);
			//session.reject("urlopen connect error " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "Failure in getting response of GetTokenURL, details are: " + info + JSON.stringify(error)
						ILSctx.setVariable("exitStatus", responseStatusCode);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						hm.response.statusCode = '200 OK';
						ctx.setVariable("Responseget", responseData);
						var AccessToken = responseData.access_token;
						logger.debug("response received :" + JSON.stringify(responseData));
						if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
							var errorinfo = "Invalid token revieved in trap_ReceivemeterRead Service, details are : " + info
							ILSctx.setVariable("description", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							ILSctx.setVariable("exitDestination", GetTokenUrl);
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
						} else {
							var AccessToken = responseData.access_token;
							var TokenType = responseData.token_type;
							ctx.setVariable("ResponseGET", responseData);
							var Auth = TokenType + ' ' + AccessToken;
							ctx.setVariable("Auth", Auth);
							ILSctx.setVariable("callcheck", "GetToken");
							ILSctx.setVariable("GetTokenUrlStepexitDestination", GetTokenUrl);
							ILSctx.setVariable("GetTokenUrlStepExitPayload", responseData);
							STEP_rule();
						}

					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Error in reading response from GetTokenURL, details are: " + info + JSON.stringify(error)
						ILSctx.setVariable("exitStatus", responseStatusCode);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						hm.current.statusCode = responseStatusCode;
						var errorinfo = "trap_061: Error response received from GetTokenURL, details are: " + "with statusCode: " + responseStatusCode + "response info:" + responseData
						ILSctx.setVariable("exitStatus", responseStatusCode);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ctx.setVariable("retry", 'yes');
						logger.error(errorinfo);
						ctx.setVariable("ErrorTxt", errorinfo);
						//session.reject(errorinfo);
					}
				});
			}
		}
	});

	function STEP_rule() {
		ms.callRule('trap_ReceivemeterRead_Processing_Policy_ILS_StepExit', null, null, function(error) {
			if (error) {
				logger.error("Error in trap_ReceivemeterRead_Processing_Policy_ILS_StepExit");
			}
		});
	}
});
