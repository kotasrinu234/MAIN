// This js is used to make odm and check the response status of odm 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("trap") || session.createContext("trap");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	//var externalCallCodeID;
	var ODMEndpoint = ctx.getVar("ODMEndpoint");
	var externalCallCodeID = ctx.getVar("externalCallCodeID");
	var externalCallCodeID = externalCallCodeID;
	var ErrorString = ctx.getVar("ErrorString");
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		//if (ErrorString !== 'yes') {
			//checking displayid as null
			if (incomingdata.id != undefined) {
				var displayID = incomingdata.id;
				//var jobSubType = incomingdata.customFieldValuesExt.SubType;
				var workTypeID = incomingdata.jobTypeID;
				var Status = incomingdata.status;
				var lookupMessage = {
					"lookupReq": {
						"type": [{
							"name": "jobTypes.workflows",
							"id": workTypeID,
							"status": Status,
						}]
					}
				}
				var url = lookupURL;
				logger.debug("lookupMessage" + lookupMessage);
				var LookupServiceResponse = {
					target: url,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				var info = " TargetURL :" + url + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";

				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "trap_049:urlopen connect error for jobTypeID LookupServiceResponse, details are :" + info + " error info :" + JSON.stringify(error);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "failure in reading message for jobTypeID LookupServiceResponse, details are :" + info + " error info :" + JSON.stringify(error);
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from LookupServiceResponse " + responseStatusCode);
									//session.output.write(JSON.parse(responseData));
									var lookupResponse = JSON.parse(responseData)
									var lookupLabel;
									if (lookupResponse.lookupRep.type[0].result == 0) {
										lookupLabel = lookupResponse.lookupRep.type[0].label;
										ctx.setVariable("JOBStatuslable", lookupLabel);
									} else {
										lookupLabel = '';
										ctx.setVariable("JOBStatuslable", lookupLabel);
									} //lookup end
									//	if (lookupLabel=='New'){
									if (incomingdata.outageSubtypeID == undefined || incomingdata.outageSubtypeID == null || incomingdata.outageSubtypeID == '') {
										var errorinfo = "outageSubtypeID is not present job payload"
										ILSctx.setVariable("StepExiterrorinfo", errorinfo);
										ILSctx.setVariable("exitStatus", "500");
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var outageSubtypeID = incomingdata.outageSubtypeID;
										var lookupMessage = {
											"lookupReq": {
												"type": [{
													"name": "outageSubtypes",
													"id": outageSubtypeID
												}]
											}
										}
										var url = lookupURL;
										//invoking lookup service and storing response in a var
										var LookupServiceResponse = {
											target: url,
											method: 'POST',
											contentType: 'application/json',
											data: lookupMessage
										};
										var info = " TargetURL :" + url + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";

										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												var errorinfo = "trap_050:urlopen connect error with outageSubtypes LookupServiceResponse, details are :" + info + " error info :" + JSON.stringify(error);
												ILSctx.setVariable("StepExiterrorinfo", errorinfo);
												ILSctx.setVariable("exitStatus", "500");
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															// error while reading response or transferring data to Buffer
															var errorinfo = "failure in getting message from outageSubtypes LookupServiceResponse, details are :" + info + " error info :" + JSON.stringify(error);
															ILSctx.setVariable("StepExiterrorinfo", errorinfo);
															ILSctx.setVariable("exitStatus", responseStatusCode);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response code received from trap_ReceiveJobStatus outageSubtypes LookupServiceResponse " + responseStatusCode);
															//session.output.write(JSON.parse(responseData));
															var lookupResponse = JSON.parse(responseData)
															if (lookupResponse.lookupRep.type[0].result == '0') {
																var outageSubtypeslabel = lookupResponse.lookupRep.type[0].label;
																var ctx = session.name("trap") || session.createContext("trap");
																ctx.setVariable("outageSubtypeslabel", outageSubtypeslabel);
																//if no voltage data then dont do the ODM call 
																//var ErrorString = ctx.getVar("ErrorString");
																/*if (ErrorString === 'yes') {
	
																	ctx.setVariable("ErrorString123", "ErrorResponseInAMI");
																} else {*/


																//odm call starts
																//lookupLabel = "NEW";
																if (ErrorString !== 'yes') {
																var externalCallCodeID = ctx.getVar("externalCallCodeID");
																//framing timestamp MM/DD/YYYY HH24:MI:SS
																var now = new Date();
																var year = now.getUTCFullYear();

																var month = now.getUTCMonth() + 1;
																var month1 = month.toString();
																var strmonthlength = month1.length;
																var todaymonth;
																if (strmonthlength == 1) {
																	todaymonth = '0' + month;
																} else {
																	todaymonth = month;
																}

																var day = now.getUTCDate();
																var day1 = day.toString();
																var strdaylength = day1.length;
																var todaydate;
																if (strdaylength == 1) {
																	todaydate = '0' + day;
																} else {
																	todaydate = day;
																}

																var hour = now.getUTCHours();
																var todayhour = hour.toString();
																var strhourlength = todayhour.length;
																var todayhour;
																if (strhourlength == 1) {
																	todayhour = '0' + hour;
																} else {
																	todayhour = hour;
																}
																var minute = now.getUTCMinutes();
																var todayminute = minute.toString();
																var strminutelength = todayminute.length;
																var todayminute;
																if (strminutelength == 1) {
																	todayminute = '0' + minute;
																} else {
																	todayminute = minute;
																}
																var second = now.getUTCSeconds();
																var todaysecond = second.toString();
																var strsecondlength = todaysecond.length;
																var todaysecond;
																if (strsecondlength == 1) {
																	todaysecond = '0' + todaysecond;
																} else {
																	todaysecond = todaysecond;
																}
																var timestampframed = year + '-' + todaymonth + '-' + todaydate + 'T' + todayhour + ':' + todayminute + ':' + todaysecond + '.000+0000';
																var payload = {
																	"__DecisionID__": displayID,
																	"inputTimeUTC": {
																		"inputDatetime": timestampframed
																	},
																	"jobDetails": {
																		"jobStatus": lookupLabel,
																		"callCode": externalCallCodeID,
																		"jobSubType": outageSubtypeslabel
																	}
																}
																var odmuri = ODMEndpoint;
																var ODMEndpoint = ctx.getVar("ODMEndpoint");
																var odmuri = ODMEndpoint;
																var odmapi = {
																	target: odmuri,
																	sslClientProfile: 'ODM_Client_Profile',
																	method: 'post',
																	contentType: 'application/json',
																	headers: {
																		//Authorization : ODMEncodedCred
																	},
																	data: payload
																};
																var info = " TargetURL :" + odmuri + "; Method :" + odmapi.method + "; Data :" + JSON.stringify(payload) + ". ";
																urlopen.open(odmapi, function(error, response) {
																	if (error) {
																		var errorinfo = "trap_051: urlopen connect error with odmapi,details are : " + info + "; error info: " + JSON.stringify(error);
																		ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																		ILSctx.setVariable("exitStatus", "500");
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200) {
																			response.readAsJSON(function(error, responseData) {
																				if (error) {
																					var errorinfo = "failure in reading message from odmapi : " + info + "; error info: " + JSON.stringify(error);
																					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																					ILSctx.setVariable("exitStatus", responseStatusCode);
																					logger.error(errorinfo);
																					session.reject(errorinfo);
																				} else {
																					hm.response.statusCode = '200 Message is received';
																					logger.debug("response received from odmuri call: " + responseStatusCode);
																					var odmresponse = responseData;
																					var ctx = session.name("trap") || session.createContext("trap");
																					ctx.setVariable("odmresponse", odmresponse);
																					var okToProceed = responseData.response.okToProceed;
																					ctx.setVariable("odmokToProceed", okToProceed);
																					if (okToProceed) {
																						ILSctx.setVariable("callcheck", "ODMCALL");
																						ILSctx.setVariable("odmStepexitDestination", odmuri);
																						ILSctx.setVariable("odmStepExitPayload", payload);
																						STEP_rule();
																					} 
																				}
																			});
																		} else {
																			var errorinfo = "trap_052: Error response returned from odmuri: " + info + "; error info: " + JSON.stringify(error);
																			ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																			ILSctx.setVariable("exitStatus", responseStatusCode);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}
																	}
																	//odm end
																});
																}
																//odm call ends		

																// end the odm call if no voltage data 

																//}
															} else {
																var errorinfo = "trap_053: outageSubtypeID lookupresponse doesn't have a return label ,result =1"
																ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																ILSctx.setVariable("exitStatus", "400");
																logger.error(errorinfo);
																session.reject(errorinfo);
															}
														}
													});
												}
											}
										});
									}
								}
							});
						} // 200
					}

				});
			}
			//else for displayid 	 
			else {
				var errorinfo = "displayid is not passed in oms ipnut data"
				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
				ILSctx.setVariable("exitStatus", "400");
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		//}
	}
});

function STEP_rule() {
	ms.callRule('trap_ReceivemeterRead_Processing_Policy_ILS_StepExit', null, null, function(error) {
		if (error) {
			logger.error("Error in trap_ReceivemeterRead_Processing_Policy_ILS_StepExit");
		}
	});
}
