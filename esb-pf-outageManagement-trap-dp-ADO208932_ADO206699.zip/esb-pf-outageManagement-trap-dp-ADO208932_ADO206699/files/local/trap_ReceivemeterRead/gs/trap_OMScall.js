var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("trap") || session.createContext("trap");
	var ILSctx = session.name("ILS") || session.createContext("ILS");
	var lookupURL = ctx.getVar("lookupURL");
	var BackoutMessage = ctx.getVar("BackoutMessage");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	var ErrorString = ctx.getVar("ErrorString");
	var OmsGetCallResponse = ctx.getVar("OmsGetCallResponse");
	var jobId = OmsGetCallResponse.id;
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//if (ErrorString !== 'yes') {
		//checking displayid as null
		if (incomingdata.leadCallID != undefined) {

			//var displayID = incomingdata.data[0].displayID;
			//var jobSubType = incomingdata.data[0].customFieldValuesExt.SubType;
			// externalCallCodeID GET /api/ServiceType/Electric/Call/{id} starts

			var leadCallID = incomingdata.leadCallID;
			//var Callapiuri = omsExternalURL + 'Call/' + leadCallID;
			var Callapiuri = omsExternalURL + 'Call/' + leadCallID + '?includeFields=externalCallCodeID,meterID,externalPremiseID';
			var TokenValue = apiToken;
			var Callapi = {
				target: Callapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},

			};

			var info = " TargetURL :" + Callapiuri + "; Method :" + Callapi.method;
			urlopen.open(Callapi, function(error, response) {
				if (error) {
					var errorinfo = "trap_048: urlopen connect error with GET Callapi details are :" + info + " error info :" + JSON.stringify(error);
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message to GET Callapi details are :" + info + " error info :" + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								//store status code with response body in context variable
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from Callapi for leadCallID:" + leadCallID + " " + responseStatusCode);
								var ctx = session.name("trap") || session.createContext("trap");
								//var Callapiresponse = JSON.parse(Callapiresponse);

								var externalCallCodeID = JSON.parse(responseData).externalCallCodeID;
								var meterID = JSON.parse(responseData).meterID;
								var premiseID = JSON.parse(responseData).externalPremiseID;
								ctx.setVariable("externalCallCodeID", externalCallCodeID);
								ctx.setVariable("meterID", meterID);
								ctx.setVariable("premiseID", premiseID);
								// logger.error("externalCallCodeID++"+externalCallCodeID);
								//session.output.write(Callapiresponse);
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "Error in reading message from GET Callapi details are :" + info + " error info :" + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "Error returned from GET Callapi, details are: " + info + "with statusCode " + responseStatusCode + "response info: " + responseData
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
		}

		//else for leadcallid 
		else {
			var errorinfo = "leadCallID is not passed in oms input data"
			//ILSctx.setVariable("StepExiterrorinfo", errorinfo);
			//ILSctx.setVariable("exitStatus", "500");
			logger.error(errorinfo);
			//session.reject(errorinfo);
		}
		//	}
		//GetCallByJobRequest (ADO163094)
		if (ErrorString === 'yes') {
			var jobApiUri = omsExternalURL + 'Job/' + jobId + '/Call' + '?includeFields=createdAt,externalPremiseID,meterID,externalCallCodeID';
			var jobApi = {
				target: jobApiUri,
				method: 'GET',
				sslClientProfile: 'OMS_Client_Profile',
				headers: {
					'osiApiToken': apiToken
				},
				contentType: 'application/json'
			};
			var info = " TargetURL :" + jobApi.target + "; Method :" + jobApi.method + ". ";
			// Make the GET request
			urlopen.open(jobApi, function(error, response) {
				if (error) {
					var errorinfo = "url open connect error for OMS GetCallByJobRequest, details are: " + info + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", "500")
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in reading message from OMS GetCallByJobRequest, details are: " + info + JSON.stringify(error)
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								logger.debug("GetCallByJobRequest details received: " + JSON.stringify(responseData));
								ctx.setVariable("GetCallByJobRequest", responseData);
								hm.response.statusCode = '200';
								session.output.write(responseData);
							}
						});
					} else {
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								var errorinfo = "Error reading response from OMS GetCallByJobRequest, details are: " + info + JSON.stringify(readError);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "Error response from OMS GetCallByJobRequest, details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
		}
	}
});
