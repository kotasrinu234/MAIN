var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

// Get transactionID from the input or context
var ctx = session.name("trap") || session.createContext("trap");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.osiApiToken;
var Transactionid = ctx.getVar("Transactionid");
var ErrorString = ctx.getVar("ErrorString");

// If ErrorString is not 'yes', only make the GET request
// Create the GET request URL
//if (ErrorString !== 'yes'){
var jobApiUri = omsExternalURL + 'Job/' + Transactionid + '?includeFields=id,createdAt,status,jobTypeID,outageSubtypeID,leadCallID,displayID,leadCall';
var jobApi = {
	target: jobApiUri,
	method: 'GET',
	sslClientProfile: 'OMS_Client_Profile',
	headers: {
		'osiApiToken': apiToken
	},
	contentType: 'application/json'
};
var info = " TargetURL :" + jobApi.target + "; Method :" + jobApi.method + ". ";

// Make the GET request
urlopen.open(jobApi, function(error, response) {
	if (error) {
		var errorinfo = "trap_044: url open connect error for OMS Job API request, details are: " + info + JSON.stringify(error)
		ILSctx.setVariable("StepExiterrorinfo", errorinfo);
		ILSctx.setVariable("exitStatus", "500")
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {
		var responseStatusCode = response.statusCode;
		if (responseStatusCode == 200) {
			response.readAsJSON(function(error, responseData) {
				if (error) {
					var errorinfo = "Failure in reading message from OMS Job API request, details are: " + info + JSON.stringify(error)
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", responseStatusCode)
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					// Success: Write the response data (Job details)
					logger.debug("Job details received: " + JSON.stringify(responseData));
					ctx.setVariable("OmsGetCallResponse", responseData);
					hm.response.statusCode = '200';
					session.output.write(responseData);
				}
			});
		} else {
			response.readAsBuffer(function(readError, responseData) {
				if (readError) {
					var errorinfo = "Error reading response from OMS Job API request, details are: " + info + JSON.stringify(readError);
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", responseStatusCode)
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var errorinfo = "Error response from OMS Job API request, details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
					ILSctx.setVariable("exitStatus", responseStatusCode)
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			});
		}
	}
});
//}

// If ErrorString is 'yes', only make the PATCH call
if (ErrorString === 'yes') {
	var lookupURL = ctx.getVar("lookupURL");
	var validationStatusInterrupt = session.parameters.ValidationStatusInterrupt;
	var lookupMessage = {
		"lookupReq": {
			"type": [{
				"name": "jobCustomFields.voltagevalidationstatus",
				"label": validationStatusInterrupt
			}]
		}
	}
	var LookupResponse = {
		target: lookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: lookupMessage
	};

	var info = " TargetURL :" + LookupResponse.target + "; Method :" + LookupResponse.method + "; Data :" + lookupMessage + ". ";
	urlopen.open(LookupResponse, function(error, response) {
		if (error) {
			var errorinfo = "trap_045: urlopen connect error of LookupServiceResponse for 'voltagevalidationstatus Interrupt', details are: " + info + JSON.stringify(error)
			ILSctx.setVariable("StepExiterrorinfo", errorinfo);
			ILSctx.setVariable("exitStatus", "500")
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "Failure in getting response of LookupServiceResponse for 'voltagevalidationstatus Interrupt', details are:" + info + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						if (responseData.lookupRep.type[0].result == '0') {
							var Identifier = responseData.lookupRep.type[0].status;

							// Initiate PATCH request logic
							var patchApiUri = omsExternalURL + 'Job/' + Transactionid;
							var patchData = {
								"customFieldValues": {
									"voltage_validation_status": Identifier
								}
							};

							var patchApi = {
								target: patchApiUri,
								sslClientProfile: 'OMS_Client_Profile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: patchData
							};

							var patchInfo = " TargetURL :" + patchApiUri + "; Method :" + patchApi.method + "; Data :" + patchData + ". ";

							// Make the PATCH request
							urlopen.open(patchApi, function(error, patchResponse) {
								if (error) {
									var errorinfo = "trap_046: url open connect error for PATCH call request,details are : " + patchInfo + " error Info :" + JSON.stringify(error);
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", "500");
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var patchResponseStatusCode = patchResponse.statusCode;
									if (patchResponseStatusCode == 200) {
										patchResponse.readAsJSON(function(error, patchResponseData) {
											if (error) {
												var errorinfo = "Failure in reading PATCH response: " + patchInfo + " error info :" + JSON.stringify(error);
												ILSctx.setVariable("StepExiterrorinfo", errorinfo);
												ILSctx.setVariable("exitStatus", responseStatusCode);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												logger.debug("PATCH request successful with response code: " + patchResponse.statusCode);
												hm.response.statusCode = '200 Message is received';
												ctx.setVariable("exitStatus", "0");
												//session.reject(patchResponseData);
											}
										});
									} else {
										patchResponse.readAsBuffer(function(readError, responseData) {
											if (readError) {
												var errorinfo = "Error reading from PATCH call request,details are " + JSON.stringify(readError);
												ILSctx.setVariable("description", errorinfo);
												ILSctx.setVariable("exitStatus", responseStatusCode);
												logger.error(errorinfo);
												//session.reject(errorinfo);
											} else {
												var errorinfo = "Error respone from PATCH call request, details are: " + "with status code: " + patchResponseStatusCode + "; response info :" + responseData;
												ILSctx.setVariable("exitStatus", responseStatusCode);
												ILSctx.setVariable("description", errorinfo);
												logger.error(errorinfo);
												//session.reject(errorinfo);
											}
										});
									}
								}
							});
						} else {
							var errorinfo = "trap_047: lookupresponse doesn't have a return label ,result =1" + info + " error info :" + JSON.stringify(error);
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", "400");
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Error reading response 'LookupServiceResponse' for 'voltagevalidationstatus Interrupt', details are:" + info + " error info :" + JSON.stringify(error);
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response from 'LookupService' for 'voltagevalidationstatus Interrupt', details are:" + info + ": with statusCode " + responseStatusCode + "response info : " + responseData
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		}
	});
}
