var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});



var ctx = session.name("trap")|| session.createContext("trap");
//set stylesheet parameters to variable
var lookupURL = session.parameters.lookUpURL;
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.osiApiToken;
var ODMEndpoint =session.parameters.ODMEndpoint;
var ODMCredentials =session.parameters.ODMCredentials;
var Voltageuri = session.parameters.Voltageuri;
var streamuri =session.parameters.streamuri;
//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("ODMEndpoint", ODMEndpoint);
ctx.setVariable("ODMCredentials", ODMCredentials);
ctx.setVariable("Voltageuri", Voltageuri);
ctx.setVariable("streamuri",streamuri);
var responseData = {"responseData":"Data"};
session.output.write(responseData);
