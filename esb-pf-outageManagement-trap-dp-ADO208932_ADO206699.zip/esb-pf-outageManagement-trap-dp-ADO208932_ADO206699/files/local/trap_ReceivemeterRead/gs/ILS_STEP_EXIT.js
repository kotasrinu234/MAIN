var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
		var CallCheck = ILSctx.getVar("callcheck");
		if (CallCheck == "ODMCALL"){
			var description = session.parameters.ODMdescription;
			ILSctx.setVariable("description", description);
			var StepexitDestination = ILSctx.getVar("odmStepexitDestination");
			ILSctx.setVariable("StepexitDestination", StepexitDestination);
			var odmpayload = ILSctx.getVar("odmStepExitPayload");
			session.output.write(odmpayload)
		}else if(CallCheck == "VOLTAGECALL"){
			var description = session.parameters.Voltagedescription;
			var StepexitDestination = ILSctx.getVar("VoltageStepexitDestination");
			ILSctx.setVariable("StepexitDestination", StepexitDestination);
			ILSctx.setVariable("description", description);
			var ILSctx = session.name("ILS") || session.createContext("ILS");
			var payload = ILSctx.getVar("VoltageStepExitPayload");
			session.output.write(payload)
		}
		
		else if(CallCheck == "MeterInfo"){
			var description = session.parameters.MeterInfoStepExitDescription;
			var StepexitDestination = ILSctx.getVar("MeterInfoStepexitDestination");
			ILSctx.setVariable("StepexitDestination", StepexitDestination);
			ILSctx.setVariable("description", description);
			var ILSctx = session.name("ILS") || session.createContext("ILS");
			var payload = ILSctx.getVar("MeterInfoStepExitPayload");
			session.output.write(payload)
		}
		
		else if(CallCheck == "GetToken"){
			var description = session.parameters.GetTokenStepExitDescription;
			var StepexitDestination = ILSctx.getVar("GetTokenUrlStepexitDestination");
			ILSctx.setVariable("StepexitDestination", StepexitDestination);
			ILSctx.setVariable("description", description);
			var ILSctx = session.name("ILS") || session.createContext("ILS");
			var payload = ILSctx.getVar("GetTokenUrlStepExitPayload");
			session.output.write(payload)
		}
		else if(CallCheck == "ODMNotOkToProceed"){
			var description = session.parameters.OdmExitDescription;
			var StepexitDestination = ILSctx.getVar("odmStepexitDestination");
			ILSctx.setVariable("StepexitDestination", StepexitDestination);
			ILSctx.setVariable("description", description);
			var ILSctx = session.name("ILS") || session.createContext("ILS");
			var payload = ILSctx.getVar("odmExitPayload");
			session.output.write(payload)
		}
