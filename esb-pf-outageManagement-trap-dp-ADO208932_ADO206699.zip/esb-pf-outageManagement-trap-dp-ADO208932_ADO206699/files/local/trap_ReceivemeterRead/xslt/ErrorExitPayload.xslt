<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:output method="text" omit-xml-declaration="yes"/>
	<xsl:param name="dpconfig:BackoutQueueUrlMeterReadService"/>
	<xsl:param name="dpconfig:omsExternalURL"/>
	<xsl:param name="dpconfig:AMIExitDescription"/>
	<xsl:param name="dpconfig:AMIMeterNotFoundExitDescription"/>
	<xsl:template match="/">
		<xsl:variable name="BackoutMessage">
			<xsl:copy-of select="dp:variable('var://context/trap/BackoutMessage')"/>
		</xsl:variable>
		<xsl:if test="contains($BackoutMessage, 'no')">
		
		<xsl:variable name="Payload">
				<xsl:copy-of select="."/>
		</xsl:variable>
		
		<xsl:copy-of select="$Payload"/>
		
		</xsl:if>
		
		<xsl:if test="contains($BackoutMessage, 'yes')">
		<dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'"/>
		<dp:set-variable name="'var://context/ILS/exitDestination'" value="string($dpconfig:omsExternalURL)"/>
		<dp:set-variable name="'var://context/ILS/description'" value="string($dpconfig:AMIExitDescription)"/>
   		<xsl:variable name="Payload">
			<xsl:copy-of select="dp:variable('var://context/trap/BackoutMessageData')"/>
		</xsl:variable>

		<xsl:copy-of select="$Payload"/>
		
		</xsl:if>
		
		<xsl:if test="contains($callcheck, 'JobIneligible')">
		
		<xsl:variable name="JobIneligiblePayload">
				<xsl:copy-of select="."/>
		</xsl:variable>
		
		<xsl:copy-of select="$JobIneligible"/>
		
		</xsl:if>
		
		<xsl:if test="contains($callcheck, 'NotOkToProceed')">
		
		<xsl:variable name="NotOkToProceed">
				<xsl:copy-of select="."/>
		</xsl:variable>
		
		<xsl:copy-of select="$NotOkToProceed"/>
		
		</xsl:if>
		
		<xsl:variable name="ILSvariable">
			<xsl:copy-of select="dp:variable('var://context/ILS/ILSvariable')"/>
		</xsl:variable>
		<xsl:variable name="CepURL">
			<xsl:copy-of select="dp:variable('var://context/trap/eventHubURL')"/>
		</xsl:variable>
		
		<xsl:if test="contains($ILSvariable, 'yes')">
		<dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'"/>
		<dp:set-variable name="'var://context/ILS/exitDestination'" value="$CepURL"/>
		<dp:set-variable name="'var://context/ILS/description'" value="string($dpconfig:AMIMeterNotFoundExitDescription)"/>
   		<xsl:variable name="Payload">
			<xsl:copy-of select="dp:variable('var://context/ILS/ILSvariable')"/>
		</xsl:variable>

		<xsl:copy-of select="$Payload"/>
		
		</xsl:if>
				
	</xsl:template>
</xsl:stylesheet>
