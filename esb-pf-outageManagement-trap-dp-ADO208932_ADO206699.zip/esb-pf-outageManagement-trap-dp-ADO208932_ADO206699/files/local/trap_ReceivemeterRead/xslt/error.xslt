<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

<xsl:variable name="TransactionID">
	<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
			
</xsl:variable>
		<xsl:choose>
		<xsl:when
				test="contains(dp:variable('var://service/error-message'),'Incomplete markup or missing document' )">
<xsl:variable name="errorMessage" select="concat('trap_064:', 'ErrorMessage: ', dp:variable('var://service/error-message'), ' ', 'TransactionID: ', $TransactionID)" />
				<xsl:message dp:type="all" dp:priority="error">
					trap_064: ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'500'" />
			    <dp:set-variable name="'var://context/ILS/StepExiterrorinfo'" value="$errorMessage" />
					                 <dp:set-variable name="'var://context/ILS/exitStatus'" value="'500'"/>
					
			</xsl:when>
		</xsl:choose>

<xsl:message dp:type="all" dp:priority="error">trap_064:TransactionID:<xsl:value-of select="$TransactionID"/> ErrorCode:<xsl:value-of select="dp:variable('var://service/error-headers')"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>			
	</xsl:template>
</xsl:stylesheet>