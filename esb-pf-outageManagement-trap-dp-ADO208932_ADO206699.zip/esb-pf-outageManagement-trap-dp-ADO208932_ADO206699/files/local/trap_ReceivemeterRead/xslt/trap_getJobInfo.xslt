<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
    <xsl:output method="text" omit-xml-declaration="yes"/>
    <xsl:param name="dpconfig:osiApiToken"/>
    <xsl:param name="dpconfig:omsExternalURL"/>
    <xsl:template match="/">
        <xsl:variable name="TransactoinID">
            <xsl:copy-of select="dp:variable('var://service/global-transaction-id')"/>
        </xsl:variable>
        <xsl:choose>
            <xsl:when test="string-length(normalize-space(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/@errorString))&gt; 0">
                <xsl:variable name="Transactionid">
                    <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='transactionID']/text()"/>
                </xsl:variable>
				<dp:set-variable name="'var://context/trap/Transactionid'" value="string($Transactionid)"/>
                <dp:set-variable name="'var://context/trap/ErrorString'" value="'yes'"/>
              <!--  <xsl:message dp:type="all" dp:priority="error">TransactionID:<xsl:value-of select="$TransactoinID"/>
                    error message present in meterid request message with transaction id
                    <xsl:value-of select="$Transactionid"/>
                    and error message
                    <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/@errorString"/></xsl:message> -->
                <!-- 	<dp:reject>rejected</dp:reject> -->
                <xsl:variable name="ErrorPayload">
                    <xsl:copy-of select="."/>
                </xsl:variable>
                <dp:set-variable name="'var://context/trap/BackoutMessage'" value="'yes'"/>
                <dp:set-variable name="'var://context/trap/BackoutMessageData'" value="$ErrorPayload"/>
                <dp:set-variable name="'var://context/trap/BackoutMessagerequired'" value="'not'"/>
                <xsl:copy-of select="'{ }'"/>
            </xsl:when>
            <xsl:otherwise>
                <dp:set-variable name="'var://context/trap/BackoutMessage'" value="'no'"/>
                <dp:set-variable name="'var://context/trap/meterReadingmeterID'" value="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/*[local-name()='meterID']/text())"/>
                <xsl:for-each select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/*[local-name()='readingValues']/*[local-name()='readingValue']">
                    <xsl:variable name="testvara">
                        <xsl:value-of select="'V(a)'"/>
                    </xsl:variable>
					
					<xsl:variable name="testvarb">
                        <xsl:value-of select="'V(b)'"/>
                    </xsl:variable>
					
					<xsl:variable name="testvarc">
                        <xsl:value-of select="'V(c)'"/>
                    </xsl:variable>
					
					<xsl:variable name="testvar">
                        <xsl:value-of select="'ins V(a)'"/>
                    </xsl:variable>
					
					<xsl:if test="*[local-name()='fieldName'] = $testvar">
                        <dp:set-variable name="'var://context/trap/readingValueValueVA1'" value="string(./*[local-name()='value']/text())"/>
                        <xsl:variable name="readingValuetimeStampinput">
                            <xsl:value-of select="./*[local-name()='timeStamp']/text()"/>
                        </xsl:variable>
                        <xsl:variable name="readingValuetimeStampwithoutZ">
                            <xsl:value-of select="substring-before($readingValuetimeStampinput,'Z' )"/>
                        </xsl:variable>
                        <xsl:variable name="readingValuetimeStamp">
                            <xsl:value-of select="concat($readingValuetimeStampwithoutZ,'.000Z' )"/>
                        </xsl:variable>
                        <dp:set-variable name="'var://context/trap/readingValuetimeStampVA1'" value="string($readingValuetimeStamp)"/>
                    </xsl:if>
					
                    <xsl:if test="*[local-name()='fieldName'] = $testvara">
                        <dp:set-variable name="'var://context/trap/readingValueValueVA'" value="string(./*[local-name()='value']/text())"/>
                        <xsl:variable name="readingValuetimeStampinput">
                            <xsl:value-of select="./*[local-name()='timeStamp']/text()"/>
                        </xsl:variable>
                        <xsl:variable name="readingValuetimeStampwithoutZ">
                            <xsl:value-of select="substring-before($readingValuetimeStampinput,'Z' )"/>
                        </xsl:variable>
                        <xsl:variable name="readingValuetimeStamp">
                            <xsl:value-of select="concat($readingValuetimeStampwithoutZ,'.000Z' )"/>
                        </xsl:variable>
                        <dp:set-variable name="'var://context/trap/readingValuetimeStampVA'" value="string($readingValuetimeStamp)"/>
                    </xsl:if>
					
					<xsl:if test="*[local-name()='fieldName'] = $testvarb">
                        <dp:set-variable name="'var://context/trap/readingValueValueVB'" value="string(./*[local-name()='value']/text())"/>
                        <xsl:variable name="readingValuetimeStampinput">
                            <xsl:value-of select="./*[local-name()='timeStamp']/text()"/>
                        </xsl:variable>
                        <xsl:variable name="readingValuetimeStampwithoutZ">
                            <xsl:value-of select="substring-before($readingValuetimeStampinput,'Z' )"/>
                        </xsl:variable>
                        <xsl:variable name="readingValuetimeStamp">
                            <xsl:value-of select="concat($readingValuetimeStampwithoutZ,'.000Z' )"/>
                        </xsl:variable>
                        <dp:set-variable name="'var://context/trap/readingValuetimeStampVB'" value="string($readingValuetimeStamp)"/>
                    </xsl:if>
					
					<xsl:if test="*[local-name()='fieldName'] = $testvarc">
                        <dp:set-variable name="'var://context/trap/readingValueValueVC'" value="string(./*[local-name()='value']/text())"/>
                        <xsl:variable name="readingValuetimeStampinput">
                            <xsl:value-of select="./*[local-name()='timeStamp']/text()"/>
                        </xsl:variable>
                        <xsl:variable name="readingValuetimeStampwithoutZ">
                            <xsl:value-of select="substring-before($readingValuetimeStampinput,'Z' )"/>
                        </xsl:variable>
                        <xsl:variable name="readingValuetimeStamp">
                            <xsl:value-of select="concat($readingValuetimeStampwithoutZ,'.000Z' )"/>
                        </xsl:variable>
                        <dp:set-variable name="'var://context/trap/readingValuetimeStampVC'" value="string($readingValuetimeStamp)"/>
                    </xsl:if>				
                </xsl:for-each>
				
                <xsl:variable name="Transactionid">
                    <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='transactionID']/text()"/>
                </xsl:variable>
				<dp:set-variable name="'var://context/trap/Transactionid'" value="string($Transactionid)"/>
				
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
</xsl:stylesheet>
