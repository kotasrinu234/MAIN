<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
<xsl:output method="text" omit-xml-declaration="yes"/>
<xsl:param name="dpconfig:BackoutQueueUrlMeterReadService"/>
<xsl:template match="/">
<xsl:variable name="BackoutMessage">
<xsl:copy-of select="dp:variable('var://context/trap/BackoutMessage')"/>
</xsl:variable>
<xsl:variable name="BackoutMessagerequired">
<xsl:copy-of select="dp:variable('var://context/trap/BackoutMessagerequired')"/>
</xsl:variable>
<xsl:if test="contains($BackoutMessagerequired, 'yes')">
<xsl:variable name="Payload">
<xsl:copy-of select="."/>
</xsl:variable>
<xsl:variable name="url">
<xsl:value-of select="$dpconfig:BackoutQueueUrlMeterReadService"/>
</xsl:variable>
<xsl:variable name="CallApi">
<dp:url-open target="{$url}" response="responsecode-binary">
<xsl:copy-of select="$Payload"/>
</dp:url-open>
</xsl:variable>
<xsl:variable name="responseCode">
<xsl:value-of select="$CallApi/result/responsecode"/>
</xsl:variable>
<dp:set-variable name="'var://context/CallAPIResponseCode'" value="$responseCode"/>
<xsl:choose>
<xsl:when test="$responseCode='0'"> </xsl:when>
<xsl:otherwise>
<dp:reject>
<xsl:message dp:type="all" dp:priority="debug">unable to place message in backout queue</xsl:message>
</dp:reject>
</xsl:otherwise>
</xsl:choose>
</xsl:if>
<xsl:if test="$BackoutMessage!='yes'">
<dp:set-variable name="'var://context/trap/ILSPRROCESS'" value="'no'"/>
</xsl:if>
</xsl:template>
</xsl:stylesheet>
