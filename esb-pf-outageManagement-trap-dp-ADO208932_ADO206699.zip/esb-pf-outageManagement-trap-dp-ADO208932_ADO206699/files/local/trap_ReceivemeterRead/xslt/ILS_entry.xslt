<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions"
xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig">
<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
<xsl:param name="dpconfig:messageType"/>	
<xsl:param name="dpconfig:interfaceName"/>
<xsl:param name="dpconfig:description"/>
  <xsl:template match="/">
  <xsl:variable name="generatedUUID" select="dp:generate-uuid()" />
  <xsl:value-of select="$generatedUUID" />
  <xsl:variable name="messageType">
		<xsl:value-of select="$dpconfig:messageType" />
  </xsl:variable>
  <dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)"/>
  <xsl:variable name="description">
		<xsl:value-of select="$dpconfig:description" />
  </xsl:variable>
  <dp:set-variable name="'var://context/ILS/description'" value="string($description)"/>
  <xsl:variable name="interfaceName">
		<xsl:value-of select="$dpconfig:interfaceName" />
  </xsl:variable>
  <dp:set-variable name="'var://context/ILS/interfaceName'" value="string($interfaceName)"/>
  <xsl:variable name="jobID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='transactionID'])"/>
  <dp:set-variable name="'var://context/ILS/jobID'" value="string($jobID)"/>
  <dp:set-variable name="'var://context/ILS/correlationID'" value="string($jobID)"/>
  <xsl:variable name="meterID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/*[local-name()='meterID'])"/>
  <dp:set-variable name="'var://context/ILS/meterID'" value="string($meterID)"/>
  
<xsl:choose>
    <!-- If condition to check if sourceEventTimestamp exists -->
    <xsl:when test="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/*[local-name()='readingValues']/*[local-name()='readingValue']/*[local-name()='timeStamp'])">
        <!-- Set sourceEventTimestamp with the provided timestamp -->
        <dp:set-variable 
            name="'var://context/ILS/sourceEventTimestamp'" 
            value="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/*[local-name()='readingValues']/*[local-name()='readingValue']/*[local-name()='timeStamp'])" />
    </xsl:when>
    
    <!-- Else condition to set sourceEventTimestamp to the current timestamp -->
    <xsl:otherwise>
        <!-- Use DataPower current timestamp variable -->
        <dp:set-variable 
            name="'var://context/ILS/sourceEventTimestamp'" 
            value="date:date-time()" />
    </xsl:otherwise>
</xsl:choose>

  
    <xsl:apply-templates select="node()|@*" />
  </xsl:template>
</xsl:stylesheet>
