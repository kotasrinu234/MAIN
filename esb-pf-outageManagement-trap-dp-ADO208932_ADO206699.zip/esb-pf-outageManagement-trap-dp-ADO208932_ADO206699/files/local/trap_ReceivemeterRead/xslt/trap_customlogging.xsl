<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpquery="http://www.datapower.com/param/query"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:regexp="http://exslt.org/regular-expressions"
	extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ser="http://dteco.com/DeviceManagement/ServiceOrder"
	version="1.0">
	<xsl:variable name="Delimiter" select="'_'" />
	<xsl:param name="dpconfig:NullcheckRequired"/>
	<xsl:template match="/">
	
	<xsl:variable name="TransactoinID">
	<xsl:copy-of
					select="dp:variable('var://service/global-transaction-id')" />
	</xsl:variable>
		<xsl:variable name="TimeStamp">
			<xsl:value-of select="date:date-time()"/>
		</xsl:variable>

<xsl:variable name="transactionID">
<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='transactionID']/text()"/>
</xsl:variable>

<!-- jobTypeID is used in lookup call file -->
<xsl:variable name="meterID">
<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/*[local-name()='meterID']/text()"/>
</xsl:variable>


<!-- null check and custom logging -->
<xsl:message dp:type="all" dp:priority="debug">trap_088 Meter Read REQUEST: <xsl:value-of select="concat('TransactoinID:',$TransactoinID,' transactionID:',$transactionID,' meterID:',$meterID,' TimeStamp:',$TimeStamp )"/></xsl:message>
	
<xsl:if test="$dpconfig:NullcheckRequired ='true'">	
<xsl:choose>
	<xsl:when test="string-length(normalize-space($transactionID))&gt; 0">
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error">trap_087 TransactionID :<xsl:value-of select="$TransactoinID"/> transactionID is missing in meter read request</xsl:message>				
<!-- 	<dp:reject>transactionID is missing in meter read request</dp:reject> -->
<dp:set-variable name="'var://context/trap/BackoutMessage'" value="'yes'"/>
	</xsl:otherwise>
	</xsl:choose>
	
	<xsl:choose>
	<xsl:when test="string-length(normalize-space($meterID))&gt; 0">
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error">trap_087 TransactionID :<xsl:value-of select="$TransactoinID"/> meterID is missing in meter read request</xsl:message>				
<!-- 		<dp:reject>meterID is missing in meter read request</dp:reject> -->
<dp:set-variable name="'var://context/trap/BackoutMessage'" value="'yes'"/>
	</xsl:otherwise>
	</xsl:choose>
	
</xsl:if>		
	<!-- null check end -->	
<dp:set-variable name="'var://context/trap/ILSPRROCESS'" value="'yes'"/>
<!-- null check and logging end -->

		
		<xsl:call-template name="set_ILS_Context">
			<xsl:with-param name="transactionID" select="$transactionID" />
			<xsl:with-param name="meterID" select="$meterID" />
						<xsl:with-param name="TimeStamp" select="$TimeStamp" />
			</xsl:call-template>
	</xsl:template>

	<xsl:template name="set_ILS_Context">
		<xsl:param name="transactionID" />
		<xsl:param name="meterID" />
		<xsl:param name="TimeStamp" />

		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()"/>
		<dp:set-variable name="'var://context/TimeStamp'" value="$TimeStamp" />
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'RECEIVED'"/>
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'MeterRead'"/>
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')"/>
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))"/>
		<dp:set-variable name="'var://context/ServiceLog/User'" value="' '"/>
		
		
		<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="string($transactionID)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="string($meterID)"/>
		
		
	</xsl:template>
</xsl:stylesheet>
