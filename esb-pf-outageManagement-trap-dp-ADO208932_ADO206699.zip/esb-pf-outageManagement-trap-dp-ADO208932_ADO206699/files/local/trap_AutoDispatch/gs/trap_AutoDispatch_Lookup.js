//js file is used for lookup service call for autoclose autodispatch and autochange
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("trap") || session.createContext("trap");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	// getting styleheet params
	var ctx = session.name("trap") || session.createContext("trap");
	var lookupURL = session.parameters.lookUpURL;
	var omsExternalURL = session.parameters.omsExternalURL;
	var TokenValue = session.parameters.osiApiToken;
	var labelname = session.parameters.worktypeidlabel;

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//if (incomingdata.jobAction == 'AutoDispatch') {
		var odmresponseStatus = ctx.getVar("ODMresponseStatus");
		if (odmresponseStatus !== "NotOkay") {
			var jobid = incomingdata.jobId;
			var Jobapiuri = omsExternalURL + 'Job/' + jobid;
			// step 1 calling job api
			var Jobapi = {
				target: Jobapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},

			};
			var info = " TargetURL :" + Jobapiuri + "; Method :" + Jobapi.method + ". ";
			urlopen.open(Jobapi, function(error, response) {
				if (error) {
					var errorinfo = "trap_089 urlopen connect error with GET Jobapi with jobid,details are: " + info + "; error info: " + JSON.stringify(error);
					ILSctx.setVariable("ExitDescription", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("ErrorTxt", errorinfo);
					//session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "trap_090 failure in reading message to Jobapi,details are: " + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from jobapi for jobid:" + jobid + "" + responseStatusCode);
								var ctx = session.name("trap") || session.createContext("trap");

								var jobtypeID = JSON.parse(responseData).jobTypeID;
								var jobpayload = JSON.parse(responseData);
								ctx.setVariable("jobpayload", jobpayload);
								var jobpayload_DisplayId = JSON.parse(responseData).displayID
								ctx.setVariable("jobpayload_DisplayId", jobpayload_DisplayId);

								//lookup starts- Using "jobTypeID" do a lookup and get "outageType".

								var lookupMessage = {
									"lookupReq": {
										"type": [
											{
												"name": "jobOutageTypes",
												"id": jobtypeID
											}
										]
									}
								}
								var LookupServiceResponse = {
									target: lookupURL,
									method: 'POST',
									contentType: 'application/json',
									data: lookupMessage
								};

								var info = " TargetURL :" + lookupURL + "; Data :" + JSON.stringify(lookupMessage) + ". ";

								urlopen.open(LookupServiceResponse, function(error, response) {
									if (error) {
										var errorinfo = "trap_94 urlopen connect error for outageType LookupServiceResponse,details are :" + info + "error info :" + JSON.stringify(error)
										ILSctx.setVariable("StepExiterrorinfo", errorinfo);
										ILSctx.setVariable("exitStatus", "500");
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode == 200) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "trap_95 failure in reading message to outageType LookupServiceResponse details are :" + info + "error info :" + JSON.stringify(error)
													ILSctx.setVariable("StepExiterrorinfo", errorinfo);
													ILSctx.setVariable("exitStatus", responseStatusCode);
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													hm.response.statusCode = responseStatusCode;
													logger.debug("response received from outageType LookupServiceResponse " + responseData);
													var lookupResponse = JSON.parse(responseData)
													var ctx = session.name("trap") || session.createContext("trap");
													if (lookupResponse.lookupRep.type[0].result == 0) {
														var outageType = lookupResponse.lookupRep.type[0].label;
														ctx.setVariable("outageType", outageType);
														//If outageType = "UNPLANNED_OUTAGE" then it is outage. Otherwise it is non-outage.							
														if (outageType === "UNPLANNED_OUTAGE") {
															if(odmresponseStatus === "Okay"){
															
															//Only auto dispatch if an outage job.
															//execute flow 
															// step 2 & 3 calling lookup service with crew type as efo start  

															var lookupMessage = {
																"lookupReq": {
																	"type": [
																		{
																			"name": "crewTypes",
																			"label": labelname
																		}
																	]
																}
															}
															var LookupServiceResponse = {
																target: lookupURL,
																method: 'POST',
																contentType: 'application/json',
																data: lookupMessage
															};
															var info = " TargetURL :" + lookupURL + "; Data :" + JSON.stringify(lookupMessage) + ". ";
															urlopen.open(LookupServiceResponse, function(error, response) {
																if (error) {
																	var errorinfo = "trap_91 urlopen connect error for crewTypes with label EFO LookupServiceResponse details are :" + info + "error info :" + JSON.stringify(error)
																	ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																	ILSctx.setVariable("exitStatus", "500");
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var responseStatusCode = response.statusCode;
																	if (responseStatusCode == 200) {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var errorinfo = "trap_92 failure in reading message to CrewType LookupServiceResponse details are :" + info + "error info :" + JSON.stringify(error)
																				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																				ILSctx.setVariable("exitStatus", responseStatusCode);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				hm.response.statusCode = responseStatusCode;
																				logger.debug("response received from CrewType LookupServiceResponse " + responseData);
																				var lookupResponse = JSON.parse(responseData)
																				logger.debug("response" + LookupServiceResponse);
																				var ctx = session.name("trap") || session.createContext("trap");
																				if (lookupResponse.lookupRep.type[0].result == 0) {
																					var crewTypestatus = lookupResponse.lookupRep.type[0].status;
																					ctx.setVariable("crewTypestatus", crewTypestatus);
																				} else {
																					var crewTypestatus = '';
																					ctx.setVariable("crewTypestatus", crewTypestatus);
																				}// lookup end;
																			}
																		});
																	} else {
																		var errorinfo = "trap_93 CrewType lookup service responsecode is " + responseStatusCode + "details are :" + info;
																		ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																		ILSctx.setVariable("exitStatus", responseStatusCode);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																}
															});
															//  step 2 & 3 calling lookup service with work type as efo end

															//Get worktypeid based on jobtypeID lookup start

															var lookupMessage = {
																"lookupReq": {
																	"type": [
																		{
																			"name": "workTypes",
																			"label": labelname
																		}
																	]
																}
															}
															var LookupServiceResponse = {
																target: lookupURL,
																method: 'POST',
																contentType: 'application/json',
																data: lookupMessage
															};
															var info = " TargetURL :" + lookupURL + "; Data :" + JSON.stringify(lookupMessage) + ". ";
															urlopen.open(LookupServiceResponse, function(error, response) {
																if (error) {
																	var errorinfo = "trap_94 urlopen connect error for worktypeid LookupServiceResponse,details are :" + info + "error info :" + JSON.stringify(error)
																	ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																	ILSctx.setVariable("exitStatus", "500");
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var responseStatusCode = response.statusCode;
																	if (responseStatusCode == 200) {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var errorinfo = "trap_95 failure in reading message to worktypeid LookupServiceResponse details are :" + info + "error info :" + JSON.stringify(error)
																				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																				ILSctx.setVariable("exitStatus", responseStatusCode);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				hm.response.statusCode = responseStatusCode;
																				logger.debug("response received from worktypeid LookupServiceResponse " + responseData);
																				var lookupResponse = JSON.parse(responseData)
																				var ctx = session.name("trap") || session.createContext("trap");
																				if (lookupResponse.lookupRep.type[0].result == 0) {
																					var worktypeidlabel = lookupResponse.lookupRep.type[0].id;
																					ctx.setVariable("worktypeidlabel", worktypeidlabel);
																				} else {
																					var worktypeidlabel = '';
																					ctx.setVariable("worktypeidlabel", worktypeidlabel);
																				}// lookup end;
																			}
																		});

																	} else {
																		var errorinfo = "trap_96 worktypeid lookup service responsecode is details are :" + info + "responseStatusCode" + responseStatusCode;
																		ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																		ILSctx.setVariable("exitStatus", responseStatusCode);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																}
															});
															//Get worktypeid based on jobtypeID lookup end
														}
													}
													} else {
														var outageType = '';
														ctx.setVariable("outageType", outageType);
													}
												}
											});

										} else {
											var errorinfo = "trap_96 outageType lookup service responsecode is details are :" + info + "responseStatusCode" + responseStatusCode;
											ILSctx.setVariable("StepExiterrorinfo", errorinfo);
											ILSctx.setVariable("exitStatus", responseStatusCode);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									}
								});//lookup end 


							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from GET Jobapi autodispatach with jobid, details are: " + info + "; error info: " + JSON.stringify(error);
								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "trap_97 Error returned from Jobapi autodispatach with jobid,detalils are: " + info + "with statusCode" + responseStatusCode + "; Response info: " + responseData;
								ILSctx.setVariable("ExitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								logger.error(errorinfo);
								ctx.setVariable("retry", 'yes');
								ctx.setVariable("ErrorTxt", errorinfo);
								//session.reject(errorinfo);
							}
						});
					}
				}
			});
		}
		/*} else {
			var errorinfo = "Job action didnt match to AutoDispatchCheck";
			ctx.setVariable("customErrorMessage", errorinfo);
			logger.error(errorinfo);
			session.reject(errorinfo);
		}*/
	}
});
