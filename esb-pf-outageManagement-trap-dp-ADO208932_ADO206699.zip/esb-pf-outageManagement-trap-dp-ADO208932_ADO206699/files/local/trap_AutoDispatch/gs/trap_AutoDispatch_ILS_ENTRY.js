var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading input JSON payload");
	} else {
		ILSctx.setVariable("Payload", incomingdata);
		var correlationID = incomingdata.jobId;
		var messageType = session.parameters.messageType;
		var EntryDescription = session.parameters.EntryDescription;
		var EntryStatus = session.parameters.EntryStatus;

		ILSctx.setVariable("correlationID", correlationID);
		ILSctx.setVariable("messageType", messageType);
		ILSctx.setVariable("EntryDescription", EntryDescription);
		ILSctx.setVariable("status", EntryStatus);

		if ((incomingdata.jobId == undefined) || (incomingdata.jobId == null) || (incomingdata.jobId == "")) {
			logger.error("Missing incoming JobID");
		} else {
			var jobId = incomingdata.jobId;
			ILSctx.setVariable("jobID", jobId);
		}
		if ((incomingdata.meterId == undefined) || (incomingdata.meterId == null) || (incomingdata.meterId == "")) {
			logger.error("Missing incoming meterID");
		} else {
			var meterId = incomingdata.meterId;
			ILSctx.setVariable("meterID", meterId);
		}
		/*if ((incomingdata.jobAction == undefined) || (incomingdata.jobAction == null) || (incomingdata.jobAction == "")) {
			logger.error("Missing incoming jobAction");
		} else {
			var jobAction = incomingdata.jobAction;
			ILSctx.setVariable("status", jobAction);
		}*/
		if ((incomingdata.jobUpdatedTS == undefined) || (incomingdata.jobUpdatedTS == null) || (incomingdata.jobUpdatedTS == "")) {
			logger.error("Missing incoming jobUpdatedTS");
		} else {
			var jobUpdatedTS = incomingdata.jobUpdatedTS;
			ILSctx.setVariable("sourceEventTimestamp", jobUpdatedTS);
		}
	}
});
