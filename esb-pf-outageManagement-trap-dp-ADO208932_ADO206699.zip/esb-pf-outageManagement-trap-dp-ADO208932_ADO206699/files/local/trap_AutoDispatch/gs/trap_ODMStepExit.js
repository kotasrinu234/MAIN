var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("trap") || session.createContext("trap");
var ms = require('multistep');
var callcheck = ILSctx.getVar("callcheck");
if (callcheck == "ODMCALL") {
	var ODMDescription = session.parameters.OdmstepExitDescription;
	var EntryStatus = session.parameters.EntryStatus;
	var OdmStepexitDestination = ILSctx.getVar("OdmStepexitDestination");
	ILSctx.setVariable("stepExitdescription", ODMDescription);
	ILSctx.setVariable("StepexitDestination", OdmStepexitDestination);
	ILSctx.setVariable("exitStatus", "0");
	ILSctx.setVariable("stepExitstatus", EntryStatus);
	var StepPayload = ctx.getVar("odmresponse");
	ILSctx.setVariable("StepPayload", StepPayload);
	session.output.write(StepPayload);
}
