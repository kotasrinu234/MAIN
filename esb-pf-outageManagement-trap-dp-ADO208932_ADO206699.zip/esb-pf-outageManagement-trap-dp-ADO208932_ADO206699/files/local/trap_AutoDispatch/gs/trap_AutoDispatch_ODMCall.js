// This js is used to make odm and check the response status of odm 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("trap") || session.createContext("trap");
var ODMEndpoint = session.parameters.ODMEndpoint;
var TokenValue = session.parameters.osiApiToken;
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	//if (incomingdata.jobAction == 'AutoDispatch') {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		//framing timestamp MM/DD/YYYY HH24:MI:SS
		var now = new Date();
		var year = now.getUTCFullYear();
		var month = now.getUTCMonth() + 1;
		var month1 = month.toString();
		var strmonthlength = month1.length;
		var todaymonth;
		if (strmonthlength == 1) {
			todaymonth = '0' + month;
		} else {
			todaymonth = month;
		}
		var day = now.getUTCDate();
		var day1 = day.toString();
		var strdaylength = day1.length;
		var todaydate;
		if (strdaylength == 1) {
			todaydate = '0' + day;
		} else {
			todaydate = day;
		}
		var hour = now.getUTCHours();
		var todayhour = hour.toString();
		var strhourlength = todayhour.length;
		var todayhour;
		if (strhourlength == 1) {
			todayhour = '0' + hour;
		} else {
			todayhour = hour;
		}
		var minute = now.getUTCMinutes();
		var todayminute = minute.toString();
		var strminutelength = todayminute.length;
		var todayminute;
		if (strminutelength == 1) {
			todayminute = '0' + minute;
		} else {
			todayminute = minute;
		}
		var second = now.getUTCSeconds();
		var todaysecond = second.toString();
		var strsecondlength = todaysecond.length;
		var todaysecond;
		if (strsecondlength == 1) {
			todaysecond = '0' + todaysecond;
		} else {
			todaysecond = todaysecond;
		}
			var timestampframed = year + '-' + todaymonth + '-' + todaydate + 'T' + todayhour + ':' + todayminute + ':' + todaysecond + '.000+0000';
        //var timestampframed = "2025-03-24T15:12:57.000+0000"
		var payload = {
			"inputTimeUTC": {
				"inputDatetime":timestampframed
			},
			"__DecisionID__": incomingdata.jobId,
			"jobDetails": {
				"jobStatus": incomingdata.jobStatus,
				"callCode": incomingdata.jobType,
				"jobSubType": incomingdata.jobSubType
			}
		}

		var odmuri = ODMEndpoint;
		var odmapi = {
			target: odmuri,
			sslClientProfile: 'ODM_Client_Profile',
			method: 'post',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},
			data: payload
		};

		var info = " TargetURL :" + odmuri + "; Method :" + odmapi.method + "; Data :" + JSON.stringify(payload) + ". ";
		urlopen.open(odmapi, function(error, response) {
			if (error) {
				var errorinfo = "trap_086 trap_AutoDispatch urlopen connect error with odmapi" + info + "; error info: " + JSON.stringify(error);
				ILSctx.setVariable("ExitDescription", errorinfo);
				ILSctx.setVariable("exitStatus", "500");
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", errorinfo);
				//session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "trap_087 trap_AutoDispatch failure in reading message to odmapi" + info + "; error info: " + JSON.stringify(error);
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = '200 Message is received';
							logger.debug("response received from odmuri call: " + responseStatusCode);
							var odmresponse = responseData;
							var odmresponseStatus;
							var ctx = session.name("trap") || session.createContext("trap");
							var okToProceed = responseData.response.okToProceed;
							var inEfoOfficeHours = responseData.response.inEfoOfficeHours;
							if (okToProceed == true && inEfoOfficeHours == true) {
								odmresponseStatus = "Okay";
								ILSctx.setVariable("callcheck", "ODMCALL");
								ILSctx.setVariable("OdmStepexitDestination", odmuri);
								STEP_rule();
							} 
							else if (okToProceed == true && inEfoOfficeHours == false) {
							odmresponseStatus = "partiallyOkay";
								ILSctx.setVariable("callcheck", "ODMCALL");
								ILSctx.setVariable("OdmStepexitDestination", odmuri);
								STEP_rule();
							}
							else {
								odmresponseStatus = "NotOkay";
							}
							var ctx = session.name("trap") || session.createContext("trap");
							ctx.setVariable("odmresponse", odmresponse);
							ctx.setVariable("ODMresponseStatus", odmresponseStatus);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "trap_088 trap_AutoDispatch Error returned from odmuri" + info + "; error info: " + JSON.stringify(error);
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "trap_088 trap_AutoDispatch Error returned from odmuri, details are: " + info + "with status code :" + responseStatusCode + "Responseinfo: " + responseData
							ILSctx.setVariable("ExitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode)
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
							logger.error(errorinfo);
							//session.reject(errorinfo);
						}
					});
				}
			}
		});

	}
	//}
});

function STEP_rule() {
	ms.callRule('trap_AutoDispatch_STEP_EXIT_rule', null, null, function(error) {
		if (error) {
			logger.error("Error in trap_AutoDispatch_STEP_EXIT_rule");
		}
	});
}
