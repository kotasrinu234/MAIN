//js file is used for lookup service call for autoclose autodispatch and autochange
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	// getting styleheet params
	var ctx = session.name("trap") || session.createContext("trap");
	var lookupURL = session.parameters.lookUpURL;
	var omsExternalURL = session.parameters.omsExternalURL;
	var omsExternalURLV1 = session.parameters.omsExternalURLV1;
	var TokenValue = session.parameters.osiApiToken;
	var AutoDispatchExitDesciption = session.parameters.ExitDescription;
	var AutoCloseExitDesciption = session.parameters.AutoCloseExitDescription;
	var jobid = incomingdata.jobId;

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var outageType = ctx.getVar("outageType");
		session.output.write(incomingdata);
		var odmresponseStatus = ctx.getVar("ODMresponseStatus");
		if (odmresponseStatus === "Okay") {
			if (outageType === "UNPLANNED_OUTAGE") {
				//step 5  OutageSubType lookup  on label "METER" and get <id>
				var lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "outageSubtypes",
								"label": "METER"
							}
						]
					}
				}
				var LookupServiceResponse = {
					target: lookupURL,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				var info = " TargetURL :" + lookupURL + "; Data :" + JSON.stringify(lookupMessage) + ". ";
				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "trap_98 urlopen connect error for OutageSubTypeLookupServiceResponse with label METER,details are: " + info + "error info :" + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "trap_99 failure in reading message to OutageSubType LookupServiceResponse details are :" + info + "error info :" + JSON.stringify(error)
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									var lookupResponse = JSON.parse(responseData)
									var ctx = session.name("trap") || session.createContext("trap");
									if (lookupResponse.lookupRep.type[0].result == 0) {
										var NewoutageSubtypeID = lookupResponse.lookupRep.type[0].id;
										ctx.setVariable("NewoutageSubtypeID", NewoutageSubtypeID);
										var Jobapiuri = omsExternalURLV1 + 'Job/' + jobid;
										var payload = {
											"outageSubtypeID": NewoutageSubtypeID
										}
										var Jobapi = {
											target: Jobapiuri,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'PATCH',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};

										var info = " TargetURL :" + Jobapiuri + "; Method :" + Jobapi.method + ". ";
										urlopen.open(Jobapi, function(error, response) {
											if (error) {
												var errorinfo = "trap_100 urlopen connect error with NewoutageSubtypeID,details are:" + info + "; error info: " + JSON.stringify(error);
												ILSctx.setVariable("ExitDescription", errorinfo);
												ILSctx.setVariable("exitStatus", "500");
												logger.error(errorinfo);
												ctx.setVariable("retry", 'yes');
												ctx.setVariable("ErrorTxt", errorinfo);
												//session.reject(errorinfo);
											}
											else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsJSON(function(error, responseData) {
														if (error) {
															var errorinfo = "trap_101:failure in reading message to NewoutageSubtypeID,details are:" + info + "; error info: " + JSON.stringify(error);
															ILSctx.setVariable("StepExiterrorinfo", errorinfo);
															ILSctx.setVariable("exitStatus", responseStatusCode);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = responseStatusCode;
															//step 6
															var jobpayload = ctx.getVar("jobpayload");
															var jobid = jobpayload.id;

															///api/ServiceType/Electric/CrewAssignment
															var CrewAssignmenturl = omsExternalURL + 'CrewAssignment?jobIDs=' + jobid;
															//var TokenValue = apiToken;
															var worktypeidlabel = ctx.getVar("worktypeidlabel");
															var crewTypestatus = ctx.getVar("crewTypestatus");
															var payload = {
																"workTypeID": worktypeidlabel,
																"requestedCrewType": crewTypestatus,
																"status": -1
															}
															var CrewAssignmentapi = {
																target: CrewAssignmenturl,
																sslClientProfile: 'OMS_Client_Profile',
																method: 'POST',
																contentType: 'application/json',
																headers: {
																	'osiApiToken': TokenValue
																},
																data: payload
															};
															var info = " TargetURL :" + CrewAssignmenturl + "; Method :" + CrewAssignmentapi.method + "; Data :" + JSON.stringify(payload) + ". ";
															urlopen.open(CrewAssignmentapi, function(error, response) {
																if (error) {
																	var errorinfo = "trap_112 urlopen connect error with CrewAssignmentapi for post operation with jobid as " + jobid + " and " + info + "; error info: " + JSON.stringify(error);
																	ILSctx.setVariable("ExitDescription", errorinfo);
																	ILSctx.setVariable("exitStatus", "500");
																	logger.error(errorinfo);
																	ctx.setVariable("retry", 'yes');
																	ctx.setVariable("ErrorTxt", errorinfo);
																	//session.reject(errorinfo);
																} else {
																	// read response data
																	// get the response status code
																	var responseStatusCode = response.statusCode;
																	if (responseStatusCode == 200) {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				//dp:reject stop the transaction and go error rule with error code and description
																				var errorinfo = "trap_113 failure in reading message to CrewAssignmentapi" + info + "; error info: " + JSON.stringify(error);
																				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																				ILSctx.setVariable("exitStatus", responseStatusCode);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var sucessCheck = JSON.parse(responseData).data[0].status.success;
																				//var failuremessage = JSON.parse(responseData).data[0].status.message;
																				if (sucessCheck == true) {
																					//store status code with response body in context variable
																					hm.response.statusCode = responseStatusCode;
																					var modelID = JSON.parse(responseData).data[0].model.id;
																					if (modelID == undefined || modelID == null || modelID == '') {
																						var errorinfo = "model id is not present in crew post call response" + info + "; error info: " + JSON.stringify(error);
																						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																						ILSctx.setVariable("exitStatus", responseStatusCode);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						//start comments
																						var ctx = session.name("trap") || session.createContext("trap");
																						var CrewAssignPostPAyload = JSON.parse(responseData);
																						ctx.setVariable("CrewAssignPostPAyload", CrewAssignPostPAyload);
																						//var jobpayload = ctx.getVar("jobpayload");

																						//var aorID = jobpayload.aorID;
																						//calling lookup service for voltagevalidationstatus
																						var label = session.parameters.ReportingCountGreaterThanorEqualToFour;
																						var lookupMessage = {
																							"lookupReq": {
																								"type": [{
																									"name": "jobCustomFields.voltagevalidationstatus",
																									"label": label
																								}]
																							}
																						};
																						var ctx = session.name("trap") || session.createContext("trap");
																						//var lookupURL = ctx.getVar("lookupURL");
																						var url = lookupURL;
																						var LookupServiceResponse = {
																							target: url,
																							method: 'POST',
																							contentType: 'application/json',
																							data: lookupMessage
																						};
																						var info = " TargetURL :" + url + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";
																						urlopen.open(LookupServiceResponse, function(error, response) {
																							if (error) {
																								var errorinfo = "trap_114: urlopen connect error for voltagevalidationstatus LookupServiceResponse, details are:" + info + JSON.stringify(error);
																								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																								ILSctx.setVariable("exitStatus", "500");
																								logger.error(errorinfo);
																								session.reject(errorinfo);
																							} else {
																								var responseStatusCode = response.statusCode;
																								if (responseStatusCode == 200) {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											var errorinfo = "trap_115 failure in reading message to  LookupServiceResponse, details are:" + info + JSON.stringify(error);
																											ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																											ILSctx.setVariable("exitStatus", responseStatusCode);
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										} else {
																											hm.response.statusCode = responseStatusCode;
																											var lookupResponse = JSON.parse(responseData);
																											if (lookupResponse.lookupRep.type[0].result == 0) {

																												var Identifier = lookupResponse.lookupRep.type[0].status;
																												ctx.setVariable("Identifier", Identifier);
																												// patch call /api/ServiceType/Electric/Job/<id>
                                                                                                               var jobid = incomingdata.jobId;
																												var Jobapiuri = omsExternalURL + 'Job/' + jobid;
																												var customFieldValues = {
																													"customFieldValues": {
																														"voltage_validation_status": Identifier
																													}
																												};
																												var Jobapi = {
																													target: Jobapiuri,
																													sslClientProfile: 'OMS_Client_Profile',
																													method: 'PATCH',
																													contentType: 'application/json',
																													headers: {
																														'osiApiToken': TokenValue
																													},
																													data: customFieldValues
																												};
																												var info = " TargetURL :" + Jobapiuri + "; Method :" + Jobapi.method + ". ";

																												urlopen.open(Jobapi, function(error, response) {

																													if (error) {
																														var errorinfo = "trap_100 urlopen connect error for Jobapiuri  customFieldValues call are:" + info + "; error info: " + JSON.stringify(error);
																														ILSctx.setVariable("ExitDescription", errorinfo);
																														ILSctx.setVariable("exitStatus", "500");
																														logger.error(errorinfo);
																														ctx.setVariable("retry", 'yes');
																														ctx.setVariable("ErrorTxt", errorinfo);
																														//session.reject(errorinfo);
																													}
																													else {
																														var responseStatusCode = response.statusCode;
																														if (responseStatusCode == 200) {
																															response.readAsJSON(function(error, responseData) {
																																if (error) {
																																	var errorinfo = "trap_101:failure in reading message toJobapiuri details are:" + info + "; error info: " + JSON.stringify(error);
																																	ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																																	ILSctx.setVariable("exitStatus", responseStatusCode);
																																	logger.error(errorinfo);
																																	session.reject(errorinfo);
																																} else {
																																	hm.response.statusCode = responseStatusCode;

																																	//calling comment api start			
																																	////api/ServiceType/Electric/CrewAssignment/{id}/Comment

																																	var CrewAssignmenturl = omsExternalURL + 'CrewAssignment/' + modelID + '/Comment';
																																	//var TokenValue = apiToken;

																																	//framing timestamp MM/DD/YYYY HH24:MI:SS
																																	var now = new Date();
																																	var year = now.getFullYear();
																																	var month = now.getMonth() + 1;
																																	var month1 = month.toString();
																																	var strmonthlength = month1.length;
																																	var todaymonth;
																																	if (strmonthlength == 1) {
																																		todaymonth = '0' + month;
																																	} else {
																																		todaymonth = month;
																																	}
																																	var day = now.getDate();
																																	var day1 = day.toString();
																																	var strdaylength = day1.length;
																																	var todaydate;
																																	if (strdaylength == 1) {
																																		todaydate = '0' + day;
																																	} else {
																																		todaydate = day;
																																	}
																																	var hour = now.getHours();
																																	var todayhour = hour.toString();
																																	var strhourlength = todayhour.length;
																																	var todayhour;
																																	if (strhourlength == 1) {
																																		todayhour = '0' + hour;
																																	} else {
																																		todayhour = hour;
																																	}
																																	var minute = now.getMinutes();
																																	var todayminute = minute.toString();
																																	var strminutelength = todayminute.length;
																																	var todayminute;
																																	if (strminutelength == 1) {
																																		todayminute = '0' + minute;
																																	} else {
																																		todayminute = minute;
																																	}
																																	var second = now.getSeconds();
																																	var todaysecond = second.toString();
																																	var strsecondlength = todaysecond.length;
																																	var todaysecond;
																																	if (strsecondlength == 1) {
																																		todaysecond = '0' + todaysecond;
																																	} else {
																																		todaysecond = todaysecond;
																																	}
																																	var timestampframed = todaymonth + '/' + todaydate + '/' + year + ' ' + todayhour + ':' + todayminute + ':' + todaysecond;
																																	//Auto Requesting: Job# <jobnumber> to <AOR> at <datetime  MM/DD/YYYY HH24:MI:SS '' >
																																	var jobpayload_DisplayId = ctx.getVar("jobpayload_DisplayId");
																																	//var message = 'Auto Requesting: Job# ' + jobpayload_DisplayId + ' to ' + aorlabel + ' at ' + timestampframed;
																																	var voltageRead = incomingdata.meterVa;
																																	var reportingCount = incomingdata.reportingCount;
																																	//var reportingCount = (reportingCount - 1);		
																																	var message = "Customer has been reporting issue for "+reportingCount+" times within 24 hour threshold with good voltage " + voltageRead + "\n" +
																																		"Changing Subtype to METER\n" +
																																		"Auto Requesting EFO at " + timestampframed;
																																	var payload = {
																																		"comment": message
																																	}

																																	var CrewAssignmentapi = {
																																		target: CrewAssignmenturl,
																																		sslClientProfile: 'OMS_Client_Profile',
																																		method: 'POST',
																																		contentType: 'application/json',
																																		headers: {
																																			'osiApiToken': TokenValue
																																		},
																																		data: payload
																																	};
																																	var info = " TargetURL :" + CrewAssignmenturl + "; Method :" + CrewAssignmentapi.method + "; Data :" + JSON.stringify(payload) + ". ";
																																	urlopen.open(CrewAssignmentapi, function(error, response) {
																																		if (error) {
																																			var errorinfo = "trap_116 urlopen connect error with CrewAssignmentapi comment" + info + "; error info: " + JSON.stringify(error);
																																			ILSctx.setVariable("ExitDescription", errorinfo);
																																			ILSctx.setVariable("exitStatus", "500");
																																			logger.error(errorinfo);
																																			ctx.setVariable("retry", 'yes');
																																			ctx.setVariable("ErrorTxt", errorinfo);
																																			//session.reject(errorinfo);
																																		} else {
																																			// read response data
																																			// get the response status code
																																			var responseStatusCode = response.statusCode;
																																			if (responseStatusCode == 200) {
																																				response.readAsBuffer(function(error, responseData) {
																																					if (error) {
																																						//dp:reject stop the transaction and go error rule with error code and description
																																						var errorinfo = "trap_117 failure in reading message to CrewAssignmentapi comments" + info + "; error info: " + JSON.stringify(error);
																																						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																																						ILSctx.setVariable("exitStatus", responseStatusCode);
																																						logger.error(errorinfo);
																																						session.reject(errorinfo);
																																					} else {
																																						//store status code with response body in context variable
																																						hm.response.statusCode = responseStatusCode;
																																						var Payload = responseData;
																																						ctx.setVariable("AutodispatchResponseData", Payload);
																																						var Exitstatus = session.parameters.Exitstatus;
																																						ILSctx.setVariable("exitStatus", "0");
																																						ILSctx.setVariable("ExitDescription", AutoDispatchExitDesciption);
																																						ILSctx.setVariable("status", Exitstatus);
																																						ILSctx.setVariable("ExitDestination", omsExternalURL);
																																						session.output.write(Payload);
																																					}
																																				});
																																			} else {
																																				response.readAsBuffer(function(error, responseData) {
																																					if (error) {
																																						//dp:reject stop the transaction and go error rule with error code and description
																																						var errorinfo = "failure in reading message from CrewAssignmentapicoments is  " + info + "; error info: " + JSON.stringify(error);
																																						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																																						ILSctx.setVariable("exitStatus", responseStatusCode);
																																						logger.error(errorinfo);
																																						session.reject(errorinfo);
																																					} else {
																																						var errorinfo = "trap_118 Error returned from CrewAssignmentapicoments with statusCode " + responseStatusCode + " and " + info + "; Response info: " + responseData;
																																						ILSctx.setVariable("ExitDescription", errorinfo);
																																						ILSctx.setVariable("exitStatus", responseStatusCode);
																																						logger.error(errorinfo);
																																						ctx.setVariable("retry", 'yes');
																																						ctx.setVariable("ErrorTxt", errorinfo);
																																						//session.reject(errorinfo);
																																					}
																																				});
																																			}
																																		}
																																	});
																																	//calling comment api end
																																}
																															});
																														}
																													}
																												});
																											} else {
																												var Identifier = '';
																												ctx.setVariable("Identifier", Identifier);
																											} // lookup end;

																										}
																									});
																								} else {
																									var errorinfo = "trap_119  voltagevalidationstatus lookup service responsecode is " + responseStatusCode
																									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																									ILSctx.setVariable("exitStatus", responseStatusCode);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								}
																							}
																						});
																					}
																				} else {
																					var errorinfo = "trap_120 crew post api call response is false with message as " + info + "; error info: " + JSON.stringify(error);
																					ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																					ILSctx.setVariable("exitStatus", responseStatusCode);
																					logger.error(errorinfo);
																					session.reject(errorinfo);
																				}
																				// calling lookup service with crew type as efo end				
																			}
																		});
																	} else {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				//dp:reject stop the transaction and go error rule with error code and description
																				var errorinfo = "failure in reading message from CrewAssignmentapi is  " + info + "; error info: " + JSON.stringify(error);
																				ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																				ILSctx.setVariable("exitStatus", responseStatusCode);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var errorinfo = "trap_121 Error returned from CrewAssignmentapi with statusCode " + responseStatusCode + " " + info + "; Response info: " + responseData;
																				ILSctx.setVariable("ExitDescription", errorinfo);
																				ILSctx.setVariable("exitStatus", responseStatusCode);
																				logger.error(errorinfo);
																				ctx.setVariable("retry", 'yes');
																				ctx.setVariable("ErrorTxt", errorinfo);
																				//session.reject(errorinfo);
																			}
																		});
																	}
																}
															});
														}
													});
												} else {
													var errorinfo = "trap_122: Error returned from NewoutageSubtypeID,details are:" + info + "; error info: " + JSON.stringify(error);
													ILSctx.setVariable("ExitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", responseStatusCode);
													logger.error(errorinfo);
													ctx.setVariable("retry", 'yes');
													ctx.setVariable("ErrorTxt", errorinfo);
													//session.reject(errorinfo);
												}
											}
										});
									} else {
										var NewoutageSubtypeID = '';
										ctx.setVariable("NewoutageSubtypeID", NewoutageSubtypeID);
									}// lookup end;
								}
							});
						} else {
							var errorinfo = "trap_123 OutageSubType lookup service responsecode is details are :" + info + "responseStatusCode" + responseStatusCode;
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					}
				});
			} else {
				logger.error(errorinfo);
				var errorinfo = "trap_124 non-outage";
				var ctx = session.name("trap") || session.createContext("trap");
				ctx.setVariable("errorinfo", errorinfo);
				var EntryStatus = session.parameters.EntryStatus;
				var NonOutageExitDescription = session.parameters.NonOutageExitDescription;
				ILSctx.setVariable("exitStatus", "0");
				ILSctx.setVariable("ExitDescription", NonOutageExitDescription);
				ILSctx.setVariable("status", EntryStatus);
				ILSctx.setVariable("ExitDestination", omsExternalURL);
				//session.reject(" non-outage ");
			}
		} 
		else if (odmresponseStatus === "partiallyOkay") {
			if (outageType === "UNPLANNED_OUTAGE") {
				//step 5  OutageSubType lookup  on label "METER" and get <id>
				var lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "outageSubtypes",
								"label": "METER"
							}
						]
					}
				}
				var LookupServiceResponse = {
					target: lookupURL,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				var info = " TargetURL :" + lookupURL + "; Data :" + JSON.stringify(lookupMessage) + ". ";
				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "trap_98 urlopen connect error for OutageSubTypeLookupServiceResponse with label METER,details are: " + info + "error info :" + JSON.stringify(error)
						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
						ILSctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "trap_99 failure in reading message to OutageSubType LookupServiceResponse details are :" + info + "error info :" + JSON.stringify(error)
									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
									ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									var lookupResponse = JSON.parse(responseData)
									var ctx = session.name("trap") || session.createContext("trap");
									if (lookupResponse.lookupRep.type[0].result == 0) {
										var NewoutageSubtypeID = lookupResponse.lookupRep.type[0].id;
										ctx.setVariable("NewoutageSubtypeID", NewoutageSubtypeID);
										var Jobapiuri = omsExternalURLV1 + 'Job/' + jobid;
										var payload = {
											"outageSubtypeID": NewoutageSubtypeID
										}
										var Jobapi = {
											target: Jobapiuri,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'PATCH',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};

										var info = " TargetURL :" + Jobapiuri + "; Method :" + Jobapi.method + ". ";
										urlopen.open(Jobapi, function(error, response) {
											if (error) {
												var errorinfo = "trap_100 urlopen connect error with NewoutageSubtypeID,details are:" + info + "; error info: " + JSON.stringify(error);
												ILSctx.setVariable("ExitDescription", errorinfo);
												ILSctx.setVariable("exitStatus", "500");
												logger.error(errorinfo);
												ctx.setVariable("retry", 'yes');
												ctx.setVariable("ErrorTxt", errorinfo);
												//session.reject(errorinfo);
											}
											else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsJSON(function(error, responseData) {
														if (error) {
															var errorinfo = "trap_101:failure in reading message to NewoutageSubtypeID,details are:" + info + "; error info: " + JSON.stringify(error);
															ILSctx.setVariable("StepExiterrorinfo", errorinfo);
															ILSctx.setVariable("exitStatus", responseStatusCode);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = responseStatusCode;
																	//calling lookup service for voltagevalidationstatus
																						var label = session.parameters.ReportingCountGreaterThanorEqualToFour;
																						var lookupMessage = {
																							"lookupReq": {
																								"type": [{
																									"name": "jobCustomFields.voltagevalidationstatus",
																									"label": label
																								}]
																							}
																						};
																						var ctx = session.name("trap") || session.createContext("trap");
																						//var lookupURL = ctx.getVar("lookupURL");
																						var url = lookupURL;
																						var LookupServiceResponse = {
																							target: url,
																							method: 'POST',
																							contentType: 'application/json',
																							data: lookupMessage
																						};
																						var info = " TargetURL :" + url + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(lookupMessage) + ". ";
																						urlopen.open(LookupServiceResponse, function(error, response) {
																							if (error) {
																								var errorinfo = "trap_114: urlopen connect error for voltagevalidationstatus LookupServiceResponse, details are:" + info + JSON.stringify(error);
																								ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																								ILSctx.setVariable("exitStatus", "500");
																								logger.error(errorinfo);
																								session.reject(errorinfo);
																							} else {
																								var responseStatusCode = response.statusCode;
																								if (responseStatusCode == 200) {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											var errorinfo = "trap_115 failure in reading message to  LookupServiceResponse, details are:" + info + JSON.stringify(error);
																											ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																											ILSctx.setVariable("exitStatus", responseStatusCode);
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										} else {
																											hm.response.statusCode = responseStatusCode;
																											var lookupResponse = JSON.parse(responseData);

																											if (lookupResponse.lookupRep.type[0].result == 0) {

																												var Identifier = lookupResponse.lookupRep.type[0].status;
																												ctx.setVariable("Identifier", Identifier);
																												// patch call /api/ServiceType/Electric/Job/<id>
                                                                                                               var jobid = incomingdata.jobId;
																												var Jobapiuri = omsExternalURL + 'Job/' + jobid;
																												var customFieldValues = {
																													"customFieldValues": {
																														"voltage_validation_status": Identifier
																													}
																												};
																												var Jobapi = {
																													target: Jobapiuri,
																													sslClientProfile: 'OMS_Client_Profile',
																													method: 'PATCH',
																													contentType: 'application/json',
																													headers: {
																														'osiApiToken': TokenValue
																													},
																													data: customFieldValues
																												};
																												var info = " TargetURL :" + Jobapiuri + "; Method :" + Jobapi.method + ". ";

																												urlopen.open(Jobapi, function(error, response) {

																													if (error) {
																														var errorinfo = "trap_100 urlopen connect error for Jobapiuri  customFieldValues call are:" + info + "; error info: " + JSON.stringify(error);
																														ILSctx.setVariable("ExitDescription", errorinfo);
																														ILSctx.setVariable("exitStatus", "500");
																														logger.error(errorinfo);
																														ctx.setVariable("retry", 'yes');
																														ctx.setVariable("ErrorTxt", errorinfo);
																														//session.reject(errorinfo);
																													}
																													else {
																														var responseStatusCode = response.statusCode;
																														if (responseStatusCode == 200) {
																															response.readAsJSON(function(error, responseData) {
																																if (error) {
																																	var errorinfo = "trap_101:failure in reading message to Jobapiuri details are:" + info + "; error info: " + JSON.stringify(error);
																																	ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																																	ILSctx.setVariable("exitStatus", responseStatusCode);
																																	logger.error(errorinfo);
																																	session.reject(errorinfo);
																																} else {
																																	hm.response.statusCode = responseStatusCode;
																																	
																																	//calling comment api start			
																																	//api/ServiceType/Electric/Job/{id}/Comment

																																	var Joburl = omsExternalURL + 'Job/' + jobid + '/Comment';
																																	var jobpayload_DisplayId = ctx.getVar("jobpayload_DisplayId");
																																	
																																	var voltageRead = incomingdata.meterVa;
																																	var reportingCount = incomingdata.reportingCount;
																																	//var reportingCount = (reportingCount - 1);
																																	var message = "Customer has been reporting issue for "+reportingCount+" times within 24 hour threshold with good voltage " + voltageRead + "\n" +
																																		"Changing Subtype to METER";
																																	var payload = {
																																		"comment": message
																																	}

																																	var Jobapi = {
																																		target: Joburl,
																																		sslClientProfile: 'OMS_Client_Profile',
																																		method: 'POST',
																																		contentType: 'application/json',
																																		headers: {
																																			'osiApiToken': TokenValue
																																		},
																																		data: payload
																																	};
																																	var info = " TargetURL :" + Joburl + "; Method :" + Jobapi.method + "; Data :" + JSON.stringify(payload) + ". ";
																																	urlopen.open(Jobapi, function(error, response) {
																																		if (error) {
																																			var errorinfo = "trap_116 urlopen connect error with Jobapi comment" + info + "; error info: " + JSON.stringify(error);
																																			ILSctx.setVariable("ExitDescription", errorinfo);
																																			ILSctx.setVariable("exitStatus", "500");
																																			logger.error(errorinfo);
																																			ctx.setVariable("retry", 'yes');
																																			ctx.setVariable("ErrorTxt", errorinfo);
																																			//session.reject(errorinfo);
																																		} else {
																																			// read response data
																																			// get the response status code
																																			var responseStatusCode = response.statusCode;
																																			if (responseStatusCode == 200) {
																																				response.readAsBuffer(function(error, responseData) {
																																					if (error) {
																																						//dp:reject stop the transaction and go error rule with error code and description
																																						var errorinfo = "trap_117 failure in reading message to Jobapi comments" + info + "; error info: " + JSON.stringify(error);
																																						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																																						ILSctx.setVariable("exitStatus", responseStatusCode);
																																						logger.error(errorinfo);
																																						session.reject(errorinfo);
																																					} else {
																																						//store status code with response body in context variable
																																						hm.response.statusCode = responseStatusCode;
																																						var Payload = responseData;
																																						ctx.setVariable("AutodispatchResponseData", Payload);
																																						var Exitstatus = session.parameters.Exitstatus;
																																						ILSctx.setVariable("exitStatus", "0");
																																						ILSctx.setVariable("ExitDescription", AutoDispatchExitDesciption);
																																						ILSctx.setVariable("status", Exitstatus);
																																						ILSctx.setVariable("ExitDestination", omsExternalURL);
																																						session.output.write(Payload);
																																					}
																																				});
																																			} else {
																																				response.readAsBuffer(function(error, responseData) {
																																					if (error) {
																																						//dp:reject stop the transaction and go error rule with error code and description
																																						var errorinfo = "failure in reading message from Jobapi comments is  " + info + "; error info: " + JSON.stringify(error);
																																						ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																																						ILSctx.setVariable("exitStatus", responseStatusCode);
																																						logger.error(errorinfo);
																																						session.reject(errorinfo);
																																					} else {
																																						var errorinfo = "trap_118 Error returned from Jobapi comments with statusCode " + responseStatusCode + " and " + info + "; Response info: " + responseData;
																																						ILSctx.setVariable("ExitDescription", errorinfo);
																																						ILSctx.setVariable("exitStatus", responseStatusCode);
																																						logger.error(errorinfo);
																																						ctx.setVariable("retry", 'yes');
																																						ctx.setVariable("ErrorTxt", errorinfo);
																																						//session.reject(errorinfo);
																																					}
																																				});
																																			}
																																		}
																																	});
																																	//calling comment api end
																																}
																															});
																														}
																													}
																												});
																											} else {
																												var Identifier = '';
																												ctx.setVariable("Identifier", Identifier);
																											} // lookup end;

																										}
																									});
																								} else {
																									var errorinfo = "trap_119  voltagevalidationstatus lookup service responsecode is " + responseStatusCode
																									ILSctx.setVariable("StepExiterrorinfo", errorinfo);
																									ILSctx.setVariable("exitStatus", responseStatusCode);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								}
																							}
																						});
																	
															
														}
													});
												} else {
													var errorinfo = "trap_122: Error returned from NewoutageSubtypeID,details are:" + info + "; error info: " + JSON.stringify(error);
													ILSctx.setVariable("ExitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", responseStatusCode);
													logger.error(errorinfo);
													ctx.setVariable("retry", 'yes');
													ctx.setVariable("ErrorTxt", errorinfo);
													//session.reject(errorinfo);
												}
											}
										});
									} else {
										var NewoutageSubtypeID = '';
										ctx.setVariable("NewoutageSubtypeID", NewoutageSubtypeID);
									}// lookup end;
								}
							});
						} else {
							var errorinfo = "trap_123 OutageSubType lookup service responsecode is details are :" + info + "responseStatusCode" + responseStatusCode;
							ILSctx.setVariable("StepExiterrorinfo", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					}
				});
			} else {
				logger.error(errorinfo);
				var errorinfo = "trap_124 non-outage";
				var ctx = session.name("trap") || session.createContext("trap");
				ctx.setVariable("errorinfo", errorinfo);
				var EntryStatus = session.parameters.EntryStatus;
				var NonOutageExitDescription = session.parameters.NonOutageExitDescription;
				ILSctx.setVariable("exitStatus", "0");
				ILSctx.setVariable("ExitDescription", NonOutageExitDescription);
				ILSctx.setVariable("status", EntryStatus);
				ILSctx.setVariable("ExitDestination", omsExternalURL);
				//session.reject(" non-outage ");
			}
		} 	
		else if (odmresponseStatus === "NotOkay") {
			var EntryStatus = session.parameters.EntryStatus;
			var ODMEndpoint = session.parameters.ODMEndpoint;
			var Payload = ctx.getVar("odmresponse");
			ILSctx.setVariable("exitStatus", "0");
			ILSctx.setVariable("ExitDescription", AutoCloseExitDesciption);
			ILSctx.setVariable("status", EntryStatus);
			ILSctx.setVariable("ExitDestination", ODMEndpoint);
			session.output.write(Payload);
		}
	}
});
