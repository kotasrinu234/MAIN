//js is used to perform ADLS call
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("trap") || session.createContext("trap");
var ILSctx = session.name("ILS") || session.createContext("ILS");

var sourceUrl = sm.getVar('var://service/URL-in');
ctx.setVariable("Sourc URL", sourceUrl);
var Exitdescription = session.parameters.Exitdescription;

var meterID = ctx.getVar("meterID");
var messageID = ctx.getVar("messageID");
var value = ctx.getVar("valueid");
var DestinationURL = session.parameters.DestinationURL;
var apiToken = session.parameters.osiApiToken;

if (value == 'N') {
	var meterID = ctx.getVar("meterID");
	var getUrl = DestinationURL + '?meter_number=' + meterID + '&read_required=false';
	ILSctx.setVariable('exitDestination', getUrl);
} else {
	var meterID = ctx.getVar("meterID");
	var getUrl = DestinationURL + '?meter_number=' + meterID + '&read_required=true';
	ILSctx.setVariable('exitDestination', getUrl);
}

var getMeterInfo = {
	target: getUrl,
	sslClientProfile: 'trap_ADLS_Client_Profile',
	method: 'GET',
	contentType: 'application/json',
	headers: {
		//"osiApiToken": apiToken
	}
};
var info = " TargetURL :" + getMeterInfo.target + "; Method :" + getMeterInfo.method + ". ";
try {
	urlopen.open(getMeterInfo, function(error, response) {
		if (error) {
			var errorinfo = "trap_081: URL connection error with 'getMeterInfo', details: " + info + "; Error: " + error;
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('Exitdescription', errorinfo);
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "Error reading response from 'getMeterInfo', details: " + info + "; Error: " + error;
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('Exitdescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var ctx = session.name("trap") || session.createContext("trap");
						hm.response.statusCode = '200 OK';
						ctx.setVariable("responseData", responseData)
						ILSctx.setVariable('ExitStatus', '0');
						ILSctx.setVariable('Exitdescription', Exitdescription);
						var Phase = responseData.phase;

						if (Phase == 1) {
							var nominalV = responseData.nominal_voltage[0].volt_a;
							if ((nominalV == undefined) || (nominalV == '') || (nominalV == null)) {
								var errorres = "Nominal voltage not found  from EDA API";
								session.output.write(errorres);
							} else {
								if (('voltage_reads' in responseData) && (responseData.voltage_reads.length != 0)) {

									var singlePhase = {
										"messageID": "",
										"meterID": "",
										"meterPhase": "SINGLEPHASE",
										"nominalVoltageA": "",
										"voltageReadResult":
										{
											"meterReadintTS": "",
											"meterVoltageReadingInstA": ""
										}
									};

									singlePhase.messageID = messageID;
									singlePhase.meterID = responseData.meter_number;
									singlePhase.nominalVoltageA = responseData.nominal_voltage[0].volt_a;
									singlePhase.voltageReadResult.meterReadintTS = responseData.voltage_reads[0].read_time;
									singlePhase.voltageReadResult.meterVoltageReadingInstA = responseData.voltage_reads[0].read_value;
									ctx.setVariable("singlePhaseResponseData", singlePhase);
									session.output.write(singlePhase);

								} else {
									var singlePhase = {
										"messageID": "",
										"meterID": "",
										"meterPhase": "SINGLEPHASE",
										"nominalVoltageA": ""
									};

									singlePhase.messageID = messageID;
									singlePhase.meterID = responseData.meter_number;
									singlePhase.nominalVoltageA = responseData.nominal_voltage[0].volt_a;
									session.output.write(singlePhase);
								}
							}
						} else if (Phase == 3) {
							var nominalVa = responseData.nominal_voltage[0].volt_a;
							var nominalVb = responseData.nominal_voltage[1].volt_b;
							var nominalVc = responseData.nominal_voltage[2].volt_c;

							if (((nominalVa == undefined) || (nominalVa == '') || (nominalVa == null)) || ((nominalVb == undefined) || (nominalVb == '') || (nominalVb == null)) || ((nominalVc == undefined) || (nominalVc == '') || (nominalVc == null))) {
								var errorres = "Nominal voltage not found  from EDA API";
								session.output.write(errorres);
							} else {
								if (('voltage_reads' in responseData) && (responseData.voltage_reads.length != 0)) {
									var polyPhase = {
										"messageID": "",
										"meterID": "",
										"meterPhase": "POLYPHASE",
										"nominalVoltageA": "",
										"nominalVoltageB": "",
										"nominalVoltageC": "",
										"voltageReadResult":
										{
											"meterReadintTS": "",
											"meterVoltageReadingInstA": "",
											"meterVoltageReadingInstB": "",
											"meterVoltageReadingInstC": ""
										}
									};
									polyPhase.messageID = messageID;
									polyPhase.meterID = responseData.meter_number;
									polyPhase.nominalVoltageA = responseData.nominal_voltage[0].volt_a;
									polyPhase.nominalVoltageB = responseData.nominal_voltage[1].volt_b;
									polyPhase.nominalVoltageC = responseData.nominal_voltage[2].volt_c;
									if ((responseData.voltage_reads[0].read_time == undefined) || (responseData.voltage_reads[0].read_time == '') || (responseData.voltage_reads[0].read_time == null)) {
										polyPhase.voltageReadResult.meterReadintTS = "";
									} else {
										polyPhase.voltageReadResult.meterReadintTS = responseData.voltage_reads[0].read_time;
									}
									if ((responseData.voltage_reads[0].read_value == undefined) || (responseData.voltage_reads[0].read_value == '') || (responseData.voltage_reads[0].read_value == null)) {
										polyPhase.voltageReadResult.meterVoltageReadingInstA = "";
									} else {
										polyPhase.voltageReadResult.meterVoltageReadingInstA = responseData.voltage_reads[0].read_value;
									}
									if ((responseData.voltage_reads[1] == undefined) || (responseData.voltage_reads[1] == '') || (responseData.voltage_reads[1] == null)) {
										polyPhase.voltageReadResult.meterVoltageReadingInstB = "";
									} else {
										polyPhase.voltageReadResult.meterVoltageReadingInstB = responseData.voltage_reads[1].read_value;
									}
									if ((responseData.voltage_reads[2] == undefined) || (responseData.voltage_reads[2] == '') || (responseData.voltage_reads[2] == null)) {
										polyPhase.voltageReadResult.meterVoltageReadingInstC = "";
									} else {
										polyPhase.voltageReadResult.meterVoltageReadingInstC = responseData.voltage_reads[2].read_value;
									}
									session.output.write(polyPhase);

								} else {
									var polyPhase = {
										"messageID": "",
										"meterID": "",
										"meterPhase": "POLYPHASE",
										"nominalVoltageA": "",
										"nominalVoltageB": "",
										"nominalVoltageC": ""
									};

									polyPhase.messageID = messageID;
									polyPhase.meterID = responseData.meter_number;
									polyPhase.nominalVoltageA = responseData.nominal_voltage[0].volt_a;
									polyPhase.nominalVoltageB = responseData.nominal_voltage[1].volt_b;
									polyPhase.nominalVoltageC = responseData.nominal_voltage[2].volt_c;

									session.output.write(polyPhase);
								}
							}

						} else {
							var ErrorRes = "Invalid phase returned from EDA API";
							session.output.write(ErrorRes);
						}
					}
				});
			} else if (responseStatusCode == 404) {
				// read the response when we receive the status code 404
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Failure in reading response from 'getMeterInfo', details: " + info + "; Error: " + error;
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('Exitdescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "trap_083:Error reading response from 'getMeterInfo', details: " + info + "; with status code: " + responseStatusCode + "response info :" + responseData
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('Exitdescription', errorinfo);
						logger.error(errorinfo);
						session.output.write(responseData);

						//session.reject(errorinfo);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Error reading response from 'getMeterInfo', details: " + info + "; Error: " + error;
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('Exitdescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "trap_082: Unexpected error from 'getMeterInfo', Details are: " + info + "with Status code : " + responseStatusCode + "; Response info : " + JSON.stringify(responseData);
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('Exitdescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		}
	});
} catch (error) {
	var errorinfo = "trap_081: URL connection error with 'getMeterInfo', details: " + info + "; Error: " + error;
	ILSctx.setVariable('ExitStatus', '500');
	ILSctx.setVariable('Exitdescription', errorinfo);
	logger.error(errorinfo);
	session.reject(errorinfo);
}
