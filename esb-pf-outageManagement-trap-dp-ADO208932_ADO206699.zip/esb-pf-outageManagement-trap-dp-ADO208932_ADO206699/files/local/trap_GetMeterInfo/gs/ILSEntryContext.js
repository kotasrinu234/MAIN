var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("trap") || session.createContext("trap");
var ILSctx = session.name("ILS") || session.createContext("ILS");

		var sourceUrl = sm.getVar('var://service/URL-in');
		ctx.setVariable("Sourc URL", sourceUrl);
		function getParamValue(url, param) {
			var paramString = param + '=';
			var startIndex = url.indexOf(paramString);

			if (startIndex !== -1) {
				var startValueIndex = startIndex + paramString.length;
				var endIndex = url.indexOf('&', startValueIndex);

				if (endIndex === -1) {
					endIndex = url.length;
				}

				var paramValue = url.substring(startValueIndex, endIndex);
				return paramValue.replace(/"/g, '');
			}
			return null;
		}

		var meterID = getParamValue(sourceUrl, 'meterID');
		var messageID = getParamValue(sourceUrl, 'messageID');
		var value = getParamValue(sourceUrl, 'recentVoltageNeeded');
		ctx.setVariable("meterID", meterID);
		ctx.setVariable("messageID", messageID);
		ctx.setVariable("valueid", value);

		var messageType = session.parameters.messageType;
		var sourceEventTimestamp = new Date().toISOString();
		var Entrydescription = session.parameters.Entrydescription;


		if (messageID === undefined || messageID === null || messageID === '') {
			ILSctx.setVariable('correlationID', '');
		} else {
			ILSctx.setVariable("correlationID", messageID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ILSctx.setVariable('messageType', ' ');
		} else {
			ILSctx.setVariable('messageType', messageType);
		}
		if (meterID === undefined || meterID === null || meterID === '') {
			ILSctx.setVariable('meterID', ' ');
		} else {
			ILSctx.setVariable('meterID', meterID);
		}
		if (sourceEventTimestamp === undefined || sourceEventTimestamp === null || sourceEventTimestamp === '') {
			ILSctx.setVariable('sourceEventTimestamp', ' ');
		} else {
			ILSctx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
		}
		if (Entrydescription === undefined || Entrydescription === null || Entrydescription === '') {
			ILSctx.setVariable('Entrydescription', ' ');
		} else {
			ILSctx.setVariable('Entrydescription', Entrydescription);
		}
		if (sourceUrl === undefined || sourceUrl === null || sourceUrl === '') {
			ILSctx.setVariable('sourceUrl', ' ');
		} else {
			ILSctx.setVariable('sourceUrl', sourceUrl);
		}
