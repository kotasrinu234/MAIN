var sm = require ('service-metadata');
var TransactionRuleType = sm.getVar('var://service/transaction-rule-type');
var RoutingURL = sm.getVar('var://service/routing-url');
var d = new Date();
console.log('##'+TransactionRuleType+'##')


//Request//
if(TransactionRuleType=='request'){
	
	var DI = getRequestDetails();
var domTree = undefined;
try {
    // use XML.parse() to parse the xmlString into a DOM tree structure
    domTree = XML.parse(DI);
} catch (error) {
    // there was an error while parsing the XML string
   session.output.write(error);
}
var transform = require('transform');
transform.xpath('/identification/device-name/text()', domTree, function(error, titleNodeList) {
    if (error) {
        throw error;
    } else {
var requestInEvent = getRequestInTime() + '|0|0|Success|'  + sm.getVar('var://service/mpgw/request-size')+'|'+ titleNodeList.item(0).textContent+'|destURL='+ RoutingURL+'|DetailedEP('+RoutingURL+')';
var ModifiedRIE = '#####' + requestInEvent+ '####';
console.debug(ModifiedRIE);
console.log(ModifiedRIE);
}		
});
}

//Response//
if(TransactionRuleType=='response'){
	var requestOutTime = getRequestOutTime();
	var requestOutSize = sm.getVar('var://service/mpgw/request-size');
	var responseSize = sm.getVar('var://service/mpgw/response-size');
	 <!-- Request out DTE log -->
	 console.log('****'+requestOutTime+'|0|1|Success|'+requestOutSize+'****');
	 <!-- Response in DTE log -->
	 console.log('****'+d.getTime()+'|1|0|Success|'+responseSize+'****');
}

function getRequestInTime(){
var timeElapsed = sm.getVar('var://service/time-elapsed');
var requestOutTime = d.getTime() - timeElapsed;
 return requestOutTime;
}

function getRequestOutTime(){
var timeElapsed = sm.getVar('var://service/time-elapsed');
var timeForward = sm.getVar('var://service/time-forwarded');
var requestOutTime = d.getTime() - timeElapsed + timeForward;
 return requestOutTime;
}

function getRequestDetails(){
	var datapowerInfo = sm.getVar('var://service/system/ident');
	
	return datapowerInfo;
	}