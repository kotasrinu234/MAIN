*Domain*: OutageManagement04     
==============================================================
*Ports* : trap_GetMeterInfo - 1223
          trap_ReceiveJobsEvaluation - 1222
          trap_ReceiveJobStatus - 1401
===============================================================    
*Jenkins pipeline*:                                              
ST:  esb-pf-outageManagement-trap-dp-ST                                    
DEV: esb-pf-outageManagement-trap-dp-dev                       
INT: esb-pf-outageManagement-trap-dp-Int                       
LOAD: esb-pf-outageManagement-trap-dp-Load
PROD: esb-pf-outageManagement-trap-dp-prod  
=================================================================

*ODM UserName*:  Environment      UserName 
                    ST           esbdp_trrpt_dev.fid@t1189                           
                   LOAD          esbdp_trap_test.fid@t1189
                   PROD          esbdp_trap_prd.fid@t1189
=================================================================
*ADLS/EDA UserName*:  Environment        UserName
                         ST/LOAD/PROD        douser
=================================================================
*Tokens/Parameter value to be updated(In Stylesheet)*
Service Names:
Tokens:                                                   Paramater value:
trap_ReceiveJobStatus - osiApiToken                       trap_ReceiveJobStatus - ValidationStatusIneligible
trap_ReceivemeterRead - osiApiToken                       trap_ReceivemeterRead - ValidationStatusIneligible
trap_ReceiveJobsEvaluation -osiApiToken                   trap_ReceiveJobsEvaluation -ValidationStatusIneligible
trap_AutoDispatch-osiApiToken
==============================================================================================================
**OMS will also be the producer and  consumer of the service**
**AAA will be OMS basic auth**
============================================================================================================
*Autoclose objects*:
MPG:
1.trap_GetMeterInfo  
2.trap_ReceiveJobsEvaluation
3.trap_ReceiveJobStatus
4.trap_ReceivemeterRead
5.trap_AutoDispatch

AAA
1.trap_AAA_Policy
2.trap_ReceiveJobStatus_AAA
 
TLS client profile:
1.ODM_Client_Profile
2.OMS_Client_Profile
3.TRAP_AD_AAA_Client_Profile
4.trap_GetToken_SSL_ClientProfile
5.trap_ReceiveJobStatus_AD_AAA_client_Proifle
 
TLS server profile:
1.trap_ReceiveJobsEvaluation_FSH_Server_Profile
2.trap_ReceiveJobStatus_FSH_Server_Profile
 
MQ handler(v9+)
1.trap_ReceivemeterRead_v9_MQFSH
2.trap_ReceivemeterRead_v9_MQFSH_ALT
3.trap_ReceivemeterRead_v9_MQFSH_ALT_Retry
4.trap_ReceivemeterRead_v9_MQFSH_Retry
5.trap_AutoDispatch_v9_MQFSH	
6.trap_AutoDispatch_v9_MQFSH_ALT	
7.trap_AutoDispatch_v9_MQFSH_ALT_Retry	
8.trap_AutoDispatch_v9_MQFSH_Retry	
 
Queue manager(v9+)
1.trap_ReceiveJobStatus_CEP_Qmgr
2.trap_ReceiveJobStatus_Qmgr
3.trap_ReceivemeterRead_CEP_Qmgr
4.trap_ReceivemeterRead_v9_Qmgr
5.trap_ReceivemeterRead_v9_Qmgr_ALT
6.trap_ReceivemeterRead_v9_Qmgr_ALT_Retry
7.trap_ReceivemeterRead_v9_Qmgr_Retry
8.trap_AutoDispatch_QM	
9.trap_AutoDispatch_v9_Qmgr	
10.trap_AutoDispatch_v9_Qmgr_ALT	
11.trap_AutoDispatch_v9_Qmgr_ALT_Retry	
12.trap_AutoDispatch_v9_Qmgr_Retry	
 
https handler:
1.trap_ReceiveJobStatus_HTTPS_Handler
2.trap_ReceiveJobsEvaluation_HTTPS_FSH
 
HTTP handler
1.trap_GetMeterInfo_HTTP_Handler
