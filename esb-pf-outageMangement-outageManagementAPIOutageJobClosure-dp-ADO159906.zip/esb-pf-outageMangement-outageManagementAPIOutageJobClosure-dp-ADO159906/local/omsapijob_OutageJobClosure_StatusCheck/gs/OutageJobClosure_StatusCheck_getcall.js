var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var jobId =incomingdata.jobId;
		var Url = session.parameters.OMSurl;
		//GET /api/ServiceType/Electric/Job/{jobId}/RequestStatus/{statusId}    --- "statusId" from the request payload (it is an integer)
		var status= parseInt(incomingdata.statusId)
		var OMSGeturl = Url+'/oms/external/api/ServiceType/Electric/Job/'+jobId+'/RequestStatus/'+status;
		var apiToken = session.parameters.osiApiToken;
		//   headers.remove('MQMD');
 var JobGetapi = {
				target: OMSGeturl,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',				
				headers: {
						'osiApiToken': apiToken,
					},
			};
			urlopen.open(JobGetapi, function(error, response) {
				if (error) {
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from JobGetapi for job id "+jobId+" is " + JSON.stringify(error));
					var ErrorTxt = (" OutageJobClosure_005 urlopen connect error from  omsapijob_OutageJobClosure_StatusCheck Getapi for job id "+jobId+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202 )  {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error(" error message while reading response from omsapijob_OutageJobClosure_StatusCheck Getapi for job id "+jobId+" is " + JSON.stringify(error));
								session.reject(" error message while reading response from omsapijob_OutageJobClosure_StatusCheck  get id "+jobId+" is " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
								var JobGetapiResponse = JSON.parse(responseData);
								var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
			                	ctx.setVariable("JobGetapiResponse", JobGetapiResponse);
												
					}
			});	
			}else if(responseStatusCode == 401){
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from omsapijob_OutageJobClosure_StatusCheck JobGetapi for job id "+jobId+" and status "+status+" is " + JSON.stringify(error));
					var ErrorTxt = ("OutageJobClosure_006 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck Getapi for job id "+jobId+" and status "+status+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
					session.output.write(incomingdata);
					}else{
				var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
				ctx.setVariable("FailureCalled", 'yes');
				// framing failure message start
						var Failure_payload = {		
										"msgId" :incomingdata.msgId,
										"serviceName" : incomingdata.serviceName,
										"jobId" : incomingdata.jobId,
										"status" : responseStatusCode,
										"message" :  response.reasonPhrase,
										"timesStamp" : new Date().toISOString()
			}
			//start calling queue api
        							var Queueurl = session.parameters.StatusCheckMQURL;
        							var test = PushingToQcall(Queueurl, Failure_payload);
								   session.output.write(Failure_payload);
        		  					//end calling queue api
	}
	}
	})
});

function PushingToQcall(url, Data) {
	var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
	var StandaloneMQurl= url;
				var payload = Data;
				var PushingToQueue = {
					target: StandaloneMQurl,
					data:payload
				};
				urlopen.open(PushingToQueue, function(error, response) {
					  var hm = require('header-metadata');
		              if (error) {
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									ctx.setVariable("retry", 'yes');
									logger.debug("error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue "+StandaloneMQurl+" is "+error);
									var ErrorTxt = ("OutageJobClosure_007 error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue "+StandaloneMQurl+" is "+error);
									ctx.setVariable("ErrorTxt", ErrorTxt);

		              } else {
		                  var mqrc = response.statusCode;
		                  if (mqrc == 0) {
		                      var replyMQMD = response.get({
		                          type: 'mq'
		                      }, 'MQMD');
		                      var replyMQRFH2 = response.get({
		                          type: 'mq'
		                      }, 'MQRFH2');
		                      response.readAsBuffer(function(readError, responseData) {
		                          if (readError) {
		                              hm.response.statusCode = 500
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									ctx.setVariable("retry", 'yes');
									logger.debug("error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue is "+error);
									var ErrorTxt = ("OutageJobClosure_007 error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue is "+error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
		                          } else {
		                              logger.debug("MQResponsecode " + mqrc);
		                          }
		                      });
		                  } else {
		                		var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
							ctx.setVariable("retry", 'yes');
							logger.debug("response code for omsapijob_OutageJobClosure_StatusCheck "+StandaloneMQurl+" urlopen.open error [MQRC=" + mqrc + "]");
							var ErrorTxt = ("OutageJobClosure_007 response code for omsapijob_OutageJobClosure_StatusCheck "+StandaloneMQurl+" urlopen.open error [MQRC=" + mqrc + "]");
							ctx.setVariable("ErrorTxt", ErrorTxt);             
		                  }
		              }
				});
}