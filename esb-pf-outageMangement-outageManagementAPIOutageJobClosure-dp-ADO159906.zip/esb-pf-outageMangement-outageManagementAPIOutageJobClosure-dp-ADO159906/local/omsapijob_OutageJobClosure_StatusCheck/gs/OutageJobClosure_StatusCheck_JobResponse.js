var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");	
	var FailureCalled = ctx.getVariable("FailureCalled");
	var Url = session.parameters.OMSurl;
	if(FailureCalled != 'yes'){
		var jobId =incomingdata.jobId;
		var statusId= parseInt(incomingdata.status)
	var jobpayload = ctx.getVariable("JobGetapiResponse");
	logger.error("jobpayload "+JSON.stringify(jobpayload))
	var jobpayload_Result = jobpayload.result;
	if(jobpayload_Result == 'PENDING'){
				var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("pendingValue", 'pending');
				logger.debug(" result from JobGetapi for job id "+jobId+" is pending");
				var ErrorTxt = (" result from JobGetapiResponse for job id "+jobId+" is pending");
				ctx.setVariable("ErrorTxt", ErrorTxt);
				session.output.write(incomingdata);	
	}else if(jobpayload_Result == 'SUCCESS'){
     	//1.CALL GET /api/ServiceType/Electric/Job/{jobId}?includeFields=id,jobTypeID	
		var jobId =incomingdata.jobId;
		var OMSGeturl = Url+'/oms/external/api/ServiceType/Electric/Job/'+jobId+'?includeFields=id,jobTypeID';
		var apiToken = session.parameters.osiApiToken;
		 //  headers.remove('MQMD');
		var JobGetapi = {
				target: OMSGeturl,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',				
				headers: {
						'osiApiToken': apiToken,
					},
			};
			urlopen.open(JobGetapi, function(error, response) {
				if (error) {
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from JobGetapi for job id "+jobId+" is " + JSON.stringify(error));
					var ErrorTxt = (" OutageJobClosure_008 urlopen connect error from  omsapijob_OutageJobClosure_StatusCheck Getapi for job id "+jobId+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202 )  {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error(" error message while reading response from omsapijob_OutageJobClosure_StatusCheck Getapi for job id "+jobId+" is " + JSON.stringify(error));
								session.reject(" error message while reading response from omsapijob_OutageJobClosure_StatusCheck  get id "+jobId+" is " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
								var JobapiResponse = JSON.parse(responseData);
								var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
			                	ctx.setVariable("JobGetapiResponse", JobapiResponse);
								var JobapiResponseID = JobapiResponse.id;
								var JobapiResponseIDjobTypeID = JobapiResponse.jobTypeID;
								//2.call PATCH /api/ServiceType/Electric/Job/{jobId} start
						var JobPATCH_url = Url+'/oms/external/api/ServiceType/Electric/Job/'+jobId
								var TokenValue = apiToken;
								var payload = { "customFieldValues": {"completed_by_field":  true} }
								var JobPATCHCall = {
								target: JobPATCH_url,
									sslClientProfile: 'OMS_Client_Profile',
									method: 'PATCH',
									contentType: 'application/json',
									headers: {
									'osiApiToken': TokenValue
									},
									data: payload
										};		
								urlopen.open(JobPATCHCall, function(error, response) {
				if (error) {
	//retry shoud be done
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from omsapijob_RestoreVerify_CheckStatus StatusJobGetapi for job id "+jobId+" is " + JSON.stringify(error));
					var ErrorTxt = ("OutageJobClosure_006 urlopen connect error from omsapijob_RestoreVerify_CheckStatus StatusJobGetapi for job id "+jobId+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
					session.output.write(incomingdata);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202){
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error(" error message while reading response from PATCH for job id "+jobId+" is " + JSON.stringify(error));
								session.reject(" error message while reading response from omsapijob_RestoreVerify_CheckStatus job id "+jobId+" is " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
       				        	var JobGetapiResponse = JSON.parse(responseData);
								var lookupURL = session.parameters.lookupURL;
							var lookupMessage= 	{
												  "lookupReq": {
				   									 "type": [
				    										   {
				      											"name": "jobTypes.workflows",
				        										 "id": JobapiResponseIDjobTypeID,
				        										 "label" :"Completed"
				      											}      
				      										 ]
			  			  										}
												}
					//lookup call start
					var LookupServiceResponse = {
								target: lookupURL,
								method: 'POST',
								contentType: 'application/json',
								data:lookupMessage
								};
	urlopen.open(LookupServiceResponse, function(error, response) {
		if (error) {
			logger.error(" urlopen connect error with mjcs LookupServiceResponse for jobtypeID "+JobapiResponseIDjobTypeID+ " is " + JSON.stringify(error));
			session.reject(" urlopen connect error with mjcs LookupServiceResponse for jobtypeID " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200 )  {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						logger.error(" failure in getting message from mjcs LookupServiceResponse for jobtypeID " + JSON.stringify(error));
						session.reject(" failure in getting message from mjcs LookupServiceResponse for jobtypeID " + JSON.stringify(error));
					} else {
						hm.response.statusCode = responseStatusCode;
						var lookupResponse = JSON.parse(responseData)
	 var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");	
	 var lookupstatus;
	if(lookupResponse.lookupRep.type[0].result==0){
		lookupstatus= lookupResponse.lookupRep.type[0].status;
		ctx.setVariable("lookupstatus",lookupstatus);
	//5.start Call POST  /api/v1/ServiceType/Electric/Job/{jobId}/WorkFlow {for example if the status is 8}
		var JobWorkflow_url = Url+'/oms/external/api/v1/ServiceType/Electric/Job/'+jobId+'/WorkFlow'
								var TokenValue = apiToken;
								var payload = lookupstatus 
							//	var payload1 = {lookupstatus}
								//logger.error("payload1 "+JSON.stringify())
				var JobWorkflow_Call = {
									target: JobWorkflow_url,
									sslClientProfile: 'OMS_Client_Profile',
									method: 'POST',
									contentType: 'application/json',
									headers: {
									'osiApiToken': TokenValue
									},
									data: payload
										};		
	urlopen.open(JobWorkflow_Call, function(error, response) {
				if (error) {
	//retry shoud be done
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from omsapijob_RestoreVerify_CheckStatus JobWorkflow_Call for job id "+jobId+" is " + JSON.stringify(error));
					var ErrorTxt = ("OutageJobClosure_006 urlopen connect error from omsapijob_RestoreVerify_CheckStatus JobWorkflow_Call for job id "+jobId+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
					session.output.write(incomingdata);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202){
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error(" error message while reading response from POST jobworkflow for job id "+jobId+" is " + JSON.stringify(error));
								session.reject(" error message while reading response from omsapijob_RestoreVerify_CheckStatus job id "+jobId+" is " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
       				        	var JobGetapiResponse = JSON.parse(responseData);
							var payload = {		
										"msgId" :incomingdata.msgId,
										"serviceName" : incomingdata.serviceName,
										"jobId" : incomingdata.jobId,
										"status" : "200",
										"message" :  "Outage job close sucessfully.",
										"timesStamp" : new Date().toISOString()
										}
									//start calling queue api
        							var Queueurl = session.parameters.StatusCheckMQURL;
        							var test = PushingToQcall(Queueurl, payload);
								 //  session.output.write(task_payload);
        		  					//end calling queue api
	}
	})
	}else if(responseStatusCode == 401 ){
	var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id "+jobId+" is " + JSON.stringify(error));
					var ErrorTxt = ("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id "+jobId+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
					session.output.write(incomingdata);
}else{
	// framing failure message start
						var Failure_payload = {		
										"msgId" :incomingdata.msgId,
										"serviceName" : incomingdata.serviceName,
										"jobId" : incomingdata.jobId,
										"status" : responseStatusCode,
										"message" :  response.reasonPhrase,
										"timesStamp" : new Date().toISOString()
			}
			//start calling queue api
        							var Queueurl = session.parameters.StatusCheckMQURL;
        							var test = PushingToQcall(Queueurl, Failure_payload);
								  // session.output.write(task_payload);
        		  					//end calling queue api
}
}
})
	
	
     	// 5 end
		
	}else{
		logger.error(" lookup service result code for mjcs LookupServiceResponse for jobtypeID  "+JobapiResponseIDjobTypeID+ " is "+lookupResponse.lookupRep.type[0].result);
		session.reject (" lookup service result code for mjcs LookupServiceResponse for jobtypeID  "+JobapiResponseIDjobTypeID+ " is "+lookupResponse.lookupRep.type[0].result);
	}// lookup end;
	
					}
				});
				
			}else {
				
				logger.error(" lookup service from mjcs LookupServiceResponse for jobtypeID responsecode "+JobapiResponseIDjobTypeID+ " is "+responseStatusCode);
				session.reject ("lookup service from mjcs LookupServiceResponse for jobtypeID responsecode "+JobapiResponseIDjobTypeID+ " is "+responseStatusCode);
			}
		}
			});
					//lookup call end							
												
}
});
}else if(responseStatusCode == 401 ){
	var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from omsapijob_OutageJobClosure_StatusCheck PATCH for job id "+jobId+" is " + JSON.stringify(error));
					var ErrorTxt = ("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck PATCH for job id "+jobId+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
					session.output.write(incomingdata);
}else{
	// framing failure message start
						var Failure_payload = {		
										"msgId" :incomingdata.msgId,
										"serviceName" : incomingdata.serviceName,
										"jobId" : incomingdata.jobId,
										"status" : responseStatusCode,
										"message" :  response.reasonPhrase,
										"timesStamp" : new Date().toISOString()
			}
			//start calling queue api
        							var Queueurl = session.parameters.StatusCheckMQURL;
        							var test = PushingToQcall(Queueurl, Failure_payload);
								  // session.output.write(task_payload);
        		  					//end calling queue api
}
}
})
								//2.call PATCH /api/ServiceType/Electric/Job/{jobId} end
					
					}
			});	
			}else if(responseStatusCode == 401){
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from omsapijob_OutageJobClosure_StatusCheck JobGetapi for job id "+jobId+" and status "+status+" is " + JSON.stringify(error));
					var ErrorTxt = ("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck Getapi for job id "+jobId+" and status "+status+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
					session.output.write(incomingdata);
					}else{
				// framing failure message start
						var Failure_payload = {		
										"msgId" :incomingdata.msgId,
										"serviceName" : incomingdata.serviceName,
										"jobId" : incomingdata.jobId,
										"status" : responseStatusCode,
										"message" :  response.reasonPhrase,
										"timesStamp" : new Date().toISOString()
			}
			//start calling queue api
        							var Queueurl = session.parameters.StatusCheckMQURL;
        							var test = PushingToQcall(Queueurl, Failure_payload);
								 //  session.output.write(task_payload);
        		  					//end calling queue api
	}
	}
	})			
	}//success close
	else if(jobpayload_Result =="INCONCLUSIVE"){
					var payload = {		
										"msgId" :incomingdata.msgId,
										"serviceName" : incomingdata.serviceName,
										"jobId" : incomingdata.jobId,
										"status" : "0001",
										"message" :  "Result: INCONCLUSIVE",
										"timesStamp" : new Date().toISOString()
			}
			//start calling queue api
        							var Queueurl = session.parameters.StatusCheckMQURL;
        							var test = PushingToQcall(Queueurl, payload);
								  // session.output.write(task_payload);
        		  					//end calling queue api
	}//INCONCLUSIVE close
	else if(jobpayload_Result == "FAILURE"){
			  fs.readAsJSON("local:/omsapijob_OutageJobClosure_StatusCheck/gs/OutageJobClosure_failureReason.json", function(readAsJSONError, failureReason) {
				if (readAsJSONError) {
						session.reject(readAsJSONError);
					} else {
			var jobpayload_Result_Reason = jobpayload.failureReason;
			//var obj = {};
			var failureReasonCheck = false ;
						for (var i=0 ;i <failureReason.FAILURE.length; i++){
											if(jobpayload_Result_Reason == failureReason.FAILURE[i].name){
												failureReasonCheck = true;
												}
							}
							if(failureReasonCheck == true){
								//set retry on
			var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
			    ctx.setVariable("retry", 'yes');
				var ErrorTxt = ("job failure  for jobid "+jobId+" with reason "+jobpayload_Result_Reason);
				ctx.setVariable("ErrorTxt", ErrorTxt);						
							}else{
								//push to queue
							var payload = {		
										"msgId" :incomingdata.msgId,
										"serviceName" : incomingdata.serviceName,
										"jobId" : incomingdata.jobId,
										"status" : "0001",
										"message" :  "jobpayload_Result_Reason",
										"timesStamp" : new Date().toISOString()
			}
			//start calling queue api
        							var Queueurl = session.parameters.StatusCheckMQURL;
        							var test = PushingToQcall(Queueurl, payload);
								 //  session.output.write(task_payload);
        		  					//end calling queue api		
								
							}
				
				}
				
				})

	}//FAILURE close
}	
});

function PushingToQcall(url, Data) {
	var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
	var StandaloneMQurl= url;
				var payload = Data;
				var PushingToQueue = {
					target: StandaloneMQurl,
					data:payload
				};
				urlopen.open(PushingToQueue, function(error, response) {
					  var hm = require('header-metadata');
		              if (error) {
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									ctx.setVariable("retry", 'yes');
									logger.debug("error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue "+StandaloneMQurl+" is "+error);
									var ErrorTxt = ("OutageJobClosure_009 error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue "+StandaloneMQurl+" is "+error);
									ctx.setVariable("ErrorTxt", ErrorTxt);

		              } else {
		                  var mqrc = response.statusCode;
		                  if (mqrc == 0) {
		                      var replyMQMD = response.get({
		                          type: 'mq'
		                      }, 'MQMD');
		                      var replyMQRFH2 = response.get({
		                          type: 'mq'
		                      }, 'MQRFH2');
		                      response.readAsBuffer(function(readError, responseData) {
		                          if (readError) {
		                              hm.response.statusCode = 500
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									ctx.setVariable("retry", 'yes');
									logger.debug("error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue is "+error);
									var ErrorTxt = ("OutageJobClosure_009 error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue is "+error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
		                          } else {
		                              logger.debug("MQResponsecode " + mqrc);
		                          }
		                      });
		                  } else {
		                		var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
							ctx.setVariable("retry", 'yes');
							logger.debug("response code for omsapijob_OutageJobClosure_StatusCheck "+StandaloneMQurl+" urlopen.open error [MQRC=" + mqrc + "]");
							var ErrorTxt = ("OutageJobClosure_009 response code for omsapijob_OutageJobClosure_StatusCheck "+StandaloneMQurl+" urlopen.open error [MQRC=" + mqrc + "]");
							ctx.setVariable("ErrorTxt", ErrorTxt);             
		                  }
		              }
				});
}
