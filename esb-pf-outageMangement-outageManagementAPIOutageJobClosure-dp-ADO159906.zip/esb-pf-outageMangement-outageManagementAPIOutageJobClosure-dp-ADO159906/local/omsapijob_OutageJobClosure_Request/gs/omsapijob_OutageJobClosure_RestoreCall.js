var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if(readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
		
		var jobId =incomingdata.jobId;
		var Url = session.parameters.OMSurl;
		//Call GET /api/ServiceType/Electric/Job/{jobId} with includeFields=networkModelID,networkModelType,currentAffected,phases,energizationStatus
		var OMSGeturl = Url+'/oms/external/api/ServiceType/Electric/Job/'+jobId+'?includeFields=networkModelID,networkModelType,currentAffected,phases,energizationStatus';
		var apiToken = session.parameters.osiApiToken;
		   headers.remove('MQMD');
 var JobGetapi = {
				target: OMSGeturl,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',				
				headers: {
						'osiApiToken': apiToken,
					},
			};
			
			urlopen.open(JobGetapi, function(error, response) {
				if (error) {
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error from JobGetapi for job id "+jobId+" is " + JSON.stringify(error));
					var ErrorTxt = (" OutageJobClosure_001 urlopen connect error from  omsapijob_OutageJobClosure_Request JobGetapi for job id "+jobId+" is " + JSON.stringify(error));
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202 )  {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error(" error message while reading response from omsapijob_OutageJobClosure_Request JobGetapi for job id "+jobId+" is " + JSON.stringify(error));
								session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request  job id "+jobId+" is " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
       							var JobGetapiResponse = JSON.parse(responseData);
					            var networkModelType = JobGetapiResponse.networkModelType;
							    var energizationStatus = JobGetapiResponse.energizationStatus;
									var finalutcDate = new Date().toISOString();
									var	epochTime = Math.floor(new Date(finalutcDate) / 1000);
									epochTime = epochTime+'000'
									logger.error("epochtime "+epochTime)
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									ctx.setVariable("epochTime",epochTime);
									//adding values to above payload start									
									var payload ={
						                                 	}
							 if(JobGetapiResponse.networkModelID !=undefined){
							payload.networkModelID = JobGetapiResponse.networkModelID;
							}
							if(JobGetapiResponse.networkModelType !=undefined){
							payload.networkModelType = JobGetapiResponse.networkModelType;
							}
							if(JobGetapiResponse.phases !=undefined){
							payload.phases = JobGetapiResponse.phases;
							}
							if(JobGetapiResponse.currentAffected !=undefined){
							payload.currentAffected = JobGetapiResponse.currentAffected;
							}
							if((networkModelType == 0 ||networkModelType == 1) && energizationStatus == 'VERIFIED'){
								//Call  POST /api/ServiceType/Electric/Job/{jobId}/RestorePremises?time=10
								var RestorePremises_url = Url+'/oms/external/api/ServiceType/Electric/Job/'+jobId+'/RestorePremises?time='+epochTime
								var TokenValue = apiToken;
								var RestorePremises = {
								target: RestorePremises_url,
									sslClientProfile: 'OMS_Client_Profile',
									method: 'POST',
									contentType: 'application/json',
									headers: {
									'osiApiToken': TokenValue
									},
									data: payload
										};
					urlopen.open(RestorePremises, function(error, response) {
					if (error) {
						var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
						ctx.setVariable("retry", 'yes');
						logger.debug("OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid "+jobId +" is " + JSON.stringify(error));
						var ErrorTxt = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid "+jobId +" is " + JSON.stringify(error);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						//session.output.write(incomingdata);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200 || responseStatusCode == 202 )  {
							response.readAsBuffer(function(error, responseData) {
							if (error) {
										logger.error(" error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid "+jobId +" is " +JSON.stringify(error));
										session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePremises post jobid "+jobId +" is " +JSON.stringify(error));
										} 
							else {
										hm.response.statusCode = responseStatusCode;
									    var RestorePremises_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
										var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
										ctx.setVariable("RestorePremises_ResponseData", RestorePremises_ResponseData);
										//stack payload start
										var StatusCheck_payload =
											{
													"msgId": incomingdata.msgId,
													"jobId": incomingdata.jobId,
													"serviceName" : incomingdata.serviceName,
													"status" : 200,
													"statusId" : RestorePremises_ResponseData,
													"timesStamp" : new Date().toISOString()
											}
									//start calling queue api
        							var Queueurl = session.parameters.CheckMQurl;
        							var test = PushingToQcall(Queueurl, StatusCheck_payload);
									session.output.write(StatusCheck_payload);
        		  					//end calling queue api 	
									}
						});
					}else{
						response.readAsBuffer(function(error, responseData) {
							if (error) {
										logger.error("failure in reading message from omsapijob_OutageJobClosure_Request RestorePremises post call is  " + JSON.stringify(error));
										session.reject("failure in reading message from omsapijob_OutageJobClosure_Request RestorePremises post call is "+ JSON.stringify(error));
							} else {
			   						logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is "+responseStatusCode+" "+ responseData);
								
									var RestorePremises_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									var task_payload = {
										"msgId": incomingdata.msgId,
													"jobId": incomingdata.jobId,
													"serviceName" : incomingdata.serviceName,
													"status" : responseStatusCode,
													"message" : RestorePremises_ResponseData_Failure,
												    "timesStamp" : new Date().toISOString()								
														}
									ctx.setVariable("RestorePremises_ResponseData_Failure", task_payload);
									//start calling queue api
        							var Queueurl = session.parameters.FailureMQURL;
        							var test = PushingToQcall(Queueurl, task_payload);
									session.output.write(task_payload);
        		  					//end calling queue api 
					               }
						});
					}
				}
			});										
								}else if(energizationStatus == 'PREDICTED'){
									//POST /api/ServiceType/Electric/Job/{jobId}/RestorePredicted?time=10
							var RestorePredicted_url = Url+'/oms/external/api/ServiceType/Electric/Job/'+jobId+'/RestorePredicted?time='+epochTime
							var TokenValue = apiToken;
							var RestorePredicted = {
							target: RestorePredicted_url,
							sslClientProfile: 'OMS_Client_Profile',
							method: 'POST',
							contentType: 'application/json',
							headers: {
								'osiApiToken': TokenValue
							},
							data: payload
							};
				urlopen.open(RestorePredicted, function(error, response) {
					if (error) {
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid "+jobId +" is " + JSON.stringify(error));
					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid "+jobId +" is " + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
					 session.output.write(incomingdata);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202 )  {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error(" error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid "+jobId +" is" +JSON.stringify(error));
								session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid "+jobId +" is" +JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response code recieved from call RestorePredicted is "+responseStatusCode);
								var RestorePredicted_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
								var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
								var StatusCheck_payload =
											{
													"msgId": incomingdata.msgId,
													"jobId": incomingdata.jobId,
													"serviceName" : incomingdata.serviceName,
													"status" : 200,
													"statusId" : RestorePredicted_ResponseData,
													"timesStamp" : new Date().toISOString()
											}
								ctx.setVariable("RestorePredicted_payload", StatusCheck_payload);
									//start calling queue api
        							var Queueurl = session.parameters.CheckMQurl;
        							var test = PushingToQcall(Queueurl, StatusCheck_payload);
									session.output.write(StatusCheck_payload);
        		  					//end calling queue api 
							}
						});
					}else{
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request RestorePredicted post jobid "+jobId +" is " + JSON.stringify(error));
								session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request RestorePredicted post jobid "+jobId +" is "+ JSON.stringify(error));
							} else {
								logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is "+responseStatusCode+" "+ responseData);
									var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									var task_payload = {
										"msgId": incomingdata.msgId,
													"jobId": incomingdata.jobId,
													"serviceName" : incomingdata.serviceName,
													"status" : responseStatusCode,
													"message" : RestorePredicted_ResponseData_Failure,
												    "timesStamp" : new Date().toISOString()								
														}
									ctx.setVariable("RestorePredicted_Failure", task_payload);
									//start calling queue api
        							var Queueurl = session.parameters.FailureMQURL;
        							var test = PushingToQcall(Queueurl, task_payload);
									session.output.write(task_payload);
        		  					//end calling queue api 
					}
						});
						
					}
				}
			});
			//call end							
								}else if(energizationStatus == 'VERIFIED'){
									//POST /api/ServiceType/Electric/Job/{jobId}/RestoreDevice?time=10
									var RestoreDevice_VERIFIED_url = Url+'/oms/external/api/ServiceType/Electric/Job/'+jobId+'/RestoreDevice?time='+epochTime
							var TokenValue = apiToken;
							var RestoreDevice_VERIFIED = {
							target: RestoreDevice_VERIFIED_url,
							sslClientProfile: 'OMS_Client_Profile',
							method: 'POST',
							contentType: 'application/json',
							headers: {
								'osiApiToken': TokenValue
							},
							data: payload
							};
						urlopen.open(RestoreDevice_VERIFIED, function(error, response) {
					if (error) {
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post is " + JSON.stringify(error));
					var ErrorTxt = "omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid "+jobId +" is " + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
					 session.output.write(incomingdata);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202 )  {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error(" error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid "+jobId +" is " +JSON.stringify(error));
								session.reject("error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid "+jobId +" is " +JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response code recieved from call Restore_VERIFIED is "+responseStatusCode);
								var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
								var Restore_VERIFIED_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
								ctx.setVariable("Restore_VERIFIED_ResponseData", Restore_VERIFIED_ResponseData);
								var StatusCheck_payload =
											{
													"msgId": incomingdata.msgId,
													"jobId": incomingdata.jobId,
													"serviceName" : incomingdata.serviceName,
													"status" : 200,
													"statusId" : Restore_VERIFIED_ResponseData,
													"timesStamp" : new Date().toISOString()
											}
								ctx.setVariable("Restore_VERIFIED_payload", StatusCheck_payload);
									//start calling queue api
        							var Queueurl = session.parameters.CheckMQurl;
        							var test = PushingToQcall(Queueurl, StatusCheck_payload);
									session.output.write(StatusCheck_payload);
        		  					//end calling queue api 						
							}
						});
					}else{
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("failure in reading message from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid "+jobId +" is " + JSON.stringify(error));
								session.reject("failure in reading message from omsapijob_OutageJobClosure_Request Restore_VERIFIED post call is "+ JSON.stringify(error));
							} else {
								logger.debug(" response returned from Restore_VERIFIED post call is "+responseStatusCode+" "+ responseData);
								var Restore_VERIFIED_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
            					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");	                        
  								ctx.setVariable("Restore_VERIFIED_ResponseData_Failure", Restore_VERIFIED_ResponseData_Failure);
									var task_payload = {
										"msgId": incomingdata.msgId,
													"jobId": incomingdata.jobId,
													"serviceName" : incomingdata.serviceName,
													"status" : responseStatusCode,
													"message" : Restore_VERIFIED_ResponseData_Failure,
												    "timesStamp" : new Date().toISOString()								
														}						
								 ctx.setVariable("Restore_VERIFIED_Failure", task_payload);
									//start calling queue api
        							var Queueurl = session.parameters.FailureMQURL;
        							var test = PushingToQcall(Queueurl, task_payload);
									session.output.write(task_payload);
        		  					//end calling queue api
					}
						});
						
					}
				}
			});
								}else{
									var task_payload = {
										"msgId": incomingdata.msgId,
													"jobId": incomingdata.jobId,
													"serviceName" : incomingdata.serviceName,
													"status" : 'ESB0001',
													"message" : 'Invalid energization status.',
												    "timesStamp" : new Date().toISOString()								
														}						
								 ctx.setVariable("Restore_VERIFIED_Failure", task_payload);
									//start calling queue api
        							var Queueurl = session.parameters.FailureMQURL;
        							var test = PushingToQcall(Queueurl, task_payload);
									session.output.write(task_payload);
        		  					//end calling queue api

									
								}
}})
}else if(responseStatusCode == 401){
						//retry shoud be done
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("retry", 'yes');
					logger.debug(" urlopen connect error with OUGRestore_VERIFIED post is " + JSON.stringify(error));
					var ErrorTxt = "OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request JobGetapi for job id "+jobId+" is " + + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
					}else{
						// framing business failure message start
						var Failure_payload = {
							"serviceName" : "Interface47",
							"message" : response.reasonPhrase,
							"timesStamp" : new Date().toISOString(),
							"status" : responseStatusCode
						}
						if(incomingdata.msgId !=undefined){Failure_payload.msgId =incomingdata.msgId}
						if(incomingdata.jobId !=undefined){Failure_payload.jobId =incomingdata.jobId}
						var Queueurl = session.parameters.FailureMQURL;
        				var test = PushingToQcall(Queueurl, Failure_payload);
					}
					}
					});
}})

function PushingToQcall(url, Data) {
	var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
	var StandaloneMQurl= url;
				var payload = Data;
				var PushingToQueue = {
					target: StandaloneMQurl,
					data:payload
				};
				urlopen.open(PushingToQueue, function(error, response) {
					  var hm = require('header-metadata');
		              if (error) {
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									ctx.setVariable("retry", 'yes');
									logger.debug("error omsapijob_OutageJobClosure_Request while keeping message to queue "+StandaloneMQurl+" is "+error);
									var ErrorTxt = ("OutageJobClosure_003 error omsapijob_OutageJobClosure_Request while keeping message to queue "+StandaloneMQurl+" is "+error);
									ctx.setVariable("ErrorTxt", ErrorTxt);

		              } else {
		                  var mqrc = response.statusCode;
		                  if (mqrc == 0) {
		                      var replyMQMD = response.get({
		                          type: 'mq'
		                      }, 'MQMD');
		                      var replyMQRFH2 = response.get({
		                          type: 'mq'
		                      }, 'MQRFH2');
		                      response.readAsBuffer(function(readError, responseData) {
		                          if (readError) {
		                              hm.response.statusCode = 500
									var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
									ctx.setVariable("retry", 'yes');
									logger.debug("error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue is "+error);
									var ErrorTxt = ("OutageJobClosure_003 error omsapijob_OutageJobClosure_Request while keeping message to queue is "+error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
		                          } else {
		                              logger.debug("MQResponsecode " + mqrc);
		                          }
		                      });
		                  } else {
		                		var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
							ctx.setVariable("retry", 'yes');
							logger.debug("response code for omsapijob_OutageJobClosure_Request "+StandaloneMQurl+" urlopen.open error [MQRC=" + mqrc + "]");
							var ErrorTxt = ("OutageJobClosure_005 response code for omsapijob_OutageJobClosure_Request "+StandaloneMQurl+" urlopen.open error [MQRC=" + mqrc + "]");
							ctx.setVariable("ErrorTxt", ErrorTxt);             
		                  }
		              }
				});
}