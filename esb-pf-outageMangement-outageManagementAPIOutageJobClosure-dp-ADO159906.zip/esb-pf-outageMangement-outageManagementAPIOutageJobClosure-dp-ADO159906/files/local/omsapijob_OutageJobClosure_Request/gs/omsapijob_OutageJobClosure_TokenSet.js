//lookup service for non-fcc payload
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
			
			  fs.readAsJSON("local:/omsapijob_OutageJobClosure_Request/gs/OutageJobClosure_Token.json", function(readAsJSONError, jsonInternal) {
				  if (readAsJSONError) {
						session.reject(readAsJSONError);
					} else {
			//local:/csyn_UpdateCrewAvalibility/gs/csyn_aorIDs.json
	
			var name = incomingdata.userId;
		
			//var obj = {};
			for (var i=0 ;i <jsonInternal.Tokens.length; i++){		
				if(name == jsonInternal.Tokens[i].name){
					var ctx = session.name("OutageJobClosure")|| session.createContext("OutageJobClosure");
					ctx.setVariable("osiApiToken",jsonInternal.Tokens[i].token);
					
				}		
					}}

				});	
		}
});