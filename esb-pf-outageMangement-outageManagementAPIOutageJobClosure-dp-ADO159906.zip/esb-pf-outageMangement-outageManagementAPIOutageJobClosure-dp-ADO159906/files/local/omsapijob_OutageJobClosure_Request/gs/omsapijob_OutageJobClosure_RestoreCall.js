var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name('ILSExit') || session.createContext('ILSExit');
var ctx = session.name("OutageJobClosure") || session.createContext("OutageJobClosure");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {

		var jobId = incomingdata.jobId;
		var apiToken = ctx.getVar("osiApiToken");
		if (jobId == null || jobId == undefined || jobId == '') {
			var errorinfo = "Jobid is not present in input payload ";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("Jobid is not present in input payload")
			session.reject("JobID is not present in input payload")
		} else {
			var Url = session.parameters.OMSurl;
			//Call GET /api/ServiceType/Electric/Job/{jobId} with includeFields=networkModelID,networkModelType,currentAffected,phases,energizationStatus
			var OMSGeturl = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId + '?includeFields=networkModelID,networkModelType,currentAffected,phases,energizationStatus';
			var apiToken = ctx.getVar("osiApiToken");
			headers.remove('MQMD');
			var JobGetapi = {
				target: OMSGeturl,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				headers: {
					'osiApiToken': apiToken,
				},
			};
			var info = " TargetURL :" + JobGetapi.target + "; Method :" + JobGetapi.method + ". ";
			try {
				urlopen.open(JobGetapi, function(error, response) {
					if (error) {
						var errorinfo = "OutageJobClosure_001 urlopen connect error from  omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + ", details are : " + info + "; error info :" + error
						ctx.setVariable("retry", 'yes');
						logger.debug(" urlopen connect error from JobGetapi for job id " + jobId + " is " + JSON.stringify(errorinfo));
						var ErrorTxt = (" OutageJobClosure_001 urlopen connect error from  omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + " is " + JSON.stringify(errorinfo));
						ctx.setVariable("ErrorTxt", ErrorTxt);
						ilsctx.setVariable("exitDescription", errorinfo);
						ilsctx.setVariable("exitStatus", "500");
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200 || responseStatusCode == 202) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error message while reading response from omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + ", details are : " + info + "; error info :" + error
									ilsctx.setVariable("errorStatus", "500");
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error(" error message while reading response from omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + " is " + JSON.stringify(errorinfo));
									session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request  job id " + jobId + " is " + JSON.stringify(errorinfo));

								} else {
									ilsctx.setVariable("exitStatus", "0");
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									var jobId = incomingdata.jobId;
									var apiToken = ctx.getVar("osiApiToken");
									var JobGetapiResponse = JSON.parse(responseData);
									var networkModelType = JobGetapiResponse.networkModelType;
									var energizationStatus = JobGetapiResponse.energizationStatus;
									var finalutcDate = new Date().toISOString();
									var epochTime = Math.floor(new Date(finalutcDate) / 1000);
									epochTime = epochTime + '000'
									ctx.setVariable("epochTime", epochTime);
									//adding values to above payload start									
									var payload = {
									}
									if (JobGetapiResponse.networkModelID != undefined) {
										payload.networkModelID = JobGetapiResponse.networkModelID;
									}
									if (JobGetapiResponse.networkModelType != undefined) {
										payload.networkModelType = JobGetapiResponse.networkModelType;
									}
									if (JobGetapiResponse.phases != undefined) {
										payload.phases = JobGetapiResponse.phases;
									}
									if (JobGetapiResponse.currentAffected != undefined) {
										payload.currentAffected = JobGetapiResponse.currentAffected;
									}
									if ((networkModelType == 0 || networkModelType == 1) && energizationStatus == 'VERIFIED') {
										//Call  POST /api/ServiceType/Electric/Job/{jobId}/RestorePremises?time=10
										ilsctx.setVariable('status', "RestorePremises");
										var RestorePremises_url = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId + '/RestorePremises?time=' + epochTime
										var TokenValue = apiToken;
										var RestorePremises = {
											target: RestorePremises_url,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'POST',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										var RestorePremisesinfo = " TargetURL :" + RestorePremises.target + "; Method :" + RestorePremises.method + "; Data :" + JSON.stringify(RestorePremises.data) + ". ";
										try {
											urlopen.open(RestorePremises, function(error, response) {
												if (error) {
													var errorinfo = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error
													ctx.setVariable("retry", 'yes');
													logger.debug("OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(errorinfo));
													var ErrorTxt = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(errorinfo);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ilsctx.setVariable("exitDescription", errorinfo);
													ilsctx.setVariable("exitStatus", "500");
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200 || responseStatusCode == 202) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error;
																ilsctx.setVariable("errorStatus", "500");
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															}
															else {
																// started
																ilsctx.setVariable("exitStatus", "0");
																hm.response.statusCode = responseStatusCode;
																var RestorePremises_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																ctx.setVariable("RestorePremises_ResponseData", RestorePremises_ResponseData);
																ilsctx.setVariable("statusId", RestorePremises_ResponseData);
																ilsctx.setVariable("status", "RestorePremises");
																//stack payload start
																var JobPATCH_url = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId
																var TokenValue = apiToken;
																var payload = { "customFieldValues": { "completed_by_field": true } }
																var JobPATCHCall = {
																	target: JobPATCH_url,
																	sslClientProfile: 'OMS_Client_Profile',
																	method: 'PATCH',
																	contentType: 'application/json',
																	headers: {
																		'osiApiToken': TokenValue
																	},
																	data: payload
																};
																var JobPATCHCallinfo = " TargetURL :" + JobPATCHCall.target + "; Method :" + JobPATCHCall.method + "; Data :" + JSON.stringify(JobPATCHCall.data) + ". ";
																urlopen.open(JobPATCHCall, function(error, response) {
																	if (error) {
																		var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error
																		ctx.setVariable("retry", 'yes');
																		logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																		var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo);
																		ctx.setVariable("ErrorTxt", ErrorTxt);
																		session.output.write(incomingdata);
																		ilsctx.setVariable("exitDescription", errorinfo);
																		ilsctx.setVariable("exitStatus", "500");
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200 || responseStatusCode == 202) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error
																					ilsctx.setVariable("errorStatus", "500");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					hm.response.statusCode = responseStatusCode;
																					logger.debug("response code recieved from call JobPATCHCall is " + responseStatusCode);
																					var RestorePredicted_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																					var StatusCheck_payload =
																					{
																						"msgId": incomingdata.msgId,
																						"jobId": incomingdata.jobId,
																						"serviceName": incomingdata.serviceName,
																						"status": 200,
																						"statusId": RestorePredicted_ResponseData,
																						"timesStamp": new Date().toISOString(),
																						"userId": incomingdata.userId
																					}
																					ctx.setVariable("RestorePredicted_payload", StatusCheck_payload);
																					//start calling queue api
																					ilsctx.setVariable("exitStatus", "0");
																					ilsctx.setVariable("exitDescription", session.parameters.ReceiveSuccessExitDescription);
																					session.output.write(StatusCheck_payload);
																					//end calling queue api 
																				}
																			});
																		} else if (responseStatusCode == 409) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "409");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error
																					ctx.setVariable("retry", 'yes');
																					logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "409");
																				}
																			})
																		} else if (responseStatusCode == 401) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "401");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error;
																					ctx.setVariable("retry", 'yes');
																					logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "401");

																				}
																			})
																		} else if (responseStatusCode == 403) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "403");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " , details are : " + JobPATCHCallinfo + "; error info :" + error
																					ctx.setVariable("retry", 'yes');
																					logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "403");
																				}
																			})
																		} else if (responseStatusCode == 400) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "400");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																					session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																				} else {
																					if (responseData == 'No updates') {
																					}
																					else {
																						logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																						var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																						var task_payload = {
																							"msgId": incomingdata.msgId,
																							"jobId": incomingdata.jobId,
																							"serviceName": incomingdata.serviceName,
																							"status": responseStatusCode,
																							"message": RestorePredicted_ResponseData_Failure,
																							"timesStamp": new Date().toISOString()
																						}
																						ctx.setVariable("RestorePredicted_Failure", task_payload);
																						//start calling queue api
																						ilsctx.setVariable("exitStatus", responseStatusCode);
																						ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																						ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																						var Queueurl = session.parameters.FailureMQURL;
																						var test = PushingToQcall(Queueurl, task_payload);
																						session.output.write(task_payload);
																						//end calling queue api 
																					}
																				}
																			});

																		} else {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + JobPATCHCallinfo + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "500");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																					session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																				} else {
																					logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																					var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																					var task_payload = {
																						"msgId": incomingdata.msgId,
																						"jobId": incomingdata.jobId,
																						"serviceName": incomingdata.serviceName,
																						"status": responseStatusCode,
																						"message": RestorePredicted_ResponseData_Failure,
																						"timesStamp": new Date().toISOString()
																					}
																					ctx.setVariable("RestorePredicted_Failure", task_payload);
																					//start calling queue api
																					ilsctx.setVariable("exitStatus", responseStatusCode);
																					ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																					ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																					var Queueurl = session.parameters.FailureMQURL;
																					var test = PushingToQcall(Queueurl, task_payload);
																					session.output.write(task_payload);
																					//end calling queue api 
																				}
																			});

																		}
																	}
																});
																ilsctx.setVariable("exitDescription", session.parameters.ReceiveSuccessExitDescription);
																session.output.write(StatusCheck_payload);
																//end calling queue api 	
															}
														});
													} else if (responseStatusCode == 409) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error;
																ilsctx.setVariable("errorStatus", "409");
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															}
															else {
																var errorinfo = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error
																ctx.setVariable("retry", 'yes');
																logger.debug("OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(responseData));
																var ErrorTxt = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																ilsctx.setVariable("exitDescription", errorinfo);
																ilsctx.setVariable("exitStatus", "409");
															}
														})
													} else if (responseStatusCode == 401) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "401");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															}
															else {
																var errorinfo = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid 401 " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error
																ctx.setVariable("retry", 'yes');
																logger.error("OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid 401 " + jobId + " is " + JSON.stringify(responseData));
																var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid 401 " + jobId + " is " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																ilsctx.setVariable("exitStatus", "401");
																ilsctx.setVariable("exitDescription", errorinfo);
															}
														})
													} else if (responseStatusCode == 403) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "403");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request omsapijob_OutageJobClosure_Request post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															}
															else {
																var errorinfo = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error
																ctx.setVariable("retry", 'yes');
																logger.error("OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(responseData));
																var ErrorTxt = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																ilsctx.setVariable("exitDescription", errorinfo);
																ilsctx.setVariable("exitStatus", "403");
															}
														})
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading message from omsapijob_OutageJobClosure_Request RestorePremises post call is, details are : " + RestorePremisesinfo + "; error info :" + error;
																ilsctx.setVariable("errorStatus", "500");
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("failure in reading message from omsapijob_OutageJobClosure_Request RestorePremises post call is  " + JSON.stringify(errorinfo));
																session.reject("failure in reading message from omsapijob_OutageJobClosure_Request RestorePremises post call is " + JSON.stringify(errorinfo));
															} else {
																logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																ilsctx.setVariable("exitStatus", responseStatusCode);
																ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																var RestorePremises_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																var task_payload = {
																	"msgId": incomingdata.msgId,
																	"jobId": incomingdata.jobId,
																	"serviceName": incomingdata.serviceName,
																	"status": responseStatusCode,
																	"message": RestorePremises_ResponseData_Failure,
																	"timesStamp": new Date().toISOString()
																}
																ctx.setVariable("RestorePremises_ResponseData_Failure", task_payload);
																//start calling queue api
																ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																var Queueurl = session.parameters.FailureMQURL;
																var test = PushingToQcall(Queueurl, task_payload);
																session.output.write(task_payload);
																//end calling queue api 
															}
														});
													}
												}
											});
										} catch (error) {
											var errorinfo = "OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + ", details are : " + RestorePremisesinfo + "; error info :" + error;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", "500");
											logger.error("OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(errorinfo));
											session.reject("OutageJobClosure_004 urlopen connect error with omsapijob_OutageJobClosure_Request RestorePremises post jobid " + jobId + " is " + JSON.stringify(errorinfo));
										}
									} else if (energizationStatus == 'PREDICTED') {
										//POST /api/ServiceType/Electric/Job/{jobId}/RestorePredicted?time=10
										var RestorePredicted_url = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId + '/RestorePredicted?time=' + epochTime
										var TokenValue = apiToken;
										var RestorePredicted = {
											target: RestorePredicted_url,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'POST',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										var RestorePredictedinfo = " TargetURL :" + RestorePredicted.target + "; Method :" + RestorePredicted.method + "; Data :" + JSON.stringify(RestorePredicted.data) + ". ";

										try {
											urlopen.open(RestorePredicted, function(error, response) {
												if (error) {
													var errorinfo = "OutageJobClosure_004:urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error
													ctx.setVariable("retry", 'yes');
													logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(errorinfo));
													var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(errorinfo);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													session.output.write(incomingdata);
													ilsctx.setVariable("exitDescription", errorinfo);
													ilsctx.setVariable("exitStatus", "500");
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200 || responseStatusCode == 202) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "500");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is" + JSON.stringify(errorinfo));
															} else {
																hm.response.statusCode = responseStatusCode;
																logger.debug("response code recieved from call RestorePredicted is " + responseStatusCode);
																var RestorePredicted_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																ilsctx.setVariable("statusId", RestorePredicted_ResponseData);
																ilsctx.setVariable("status", "RestorePredicted");
																var JobPATCH_url = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId
																var TokenValue = apiToken;
																var payload = { "customFieldValues": { "completed_by_field": true } }
																var JobPATCHCall = {
																	target: JobPATCH_url,
																	sslClientProfile: 'OMS_Client_Profile',
																	method: 'PATCH',
																	contentType: 'application/json',
																	headers: {
																		'osiApiToken': TokenValue
																	},
																	data: payload
																};
																var info = " TargetURL :" + JobPATCHCall.target + "; Method :" + JobPATCHCall.method + "; Data :" + JSON.stringify(JobPATCHCall.data) + ". ";
																urlopen.open(JobPATCHCall, function(error, response) {
																	if (error) {
																		var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error
																		ctx.setVariable("retry", 'yes');
																		logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																		var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo);
																		ctx.setVariable("ErrorTxt", ErrorTxt);
																		session.output.write(incomingdata);
																		ilsctx.setVariable("exitDescription", errorinfo);
																		ilsctx.setVariable("exitStatus", "500");
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200 || responseStatusCode == 202) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "500");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					hm.response.statusCode = responseStatusCode;
																					logger.debug("response code recieved from call JobPATCHCall is " + responseStatusCode);
																					var RestorePredicted_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																					var StatusCheck_payload =
																					{
																						"msgId": incomingdata.msgId,
																						"jobId": incomingdata.jobId,
																						"serviceName": incomingdata.serviceName,
																						"status": 200,
																						"statusId": RestorePredicted_ResponseData,
																						"timesStamp": new Date().toISOString(),
																						"userId": incomingdata.userId
																					}
																					ctx.setVariable("RestorePredicted_payload", StatusCheck_payload);
																					//start calling queue api
																					ilsctx.setVariable("exitStatus", "0");
																					ilsctx.setVariable("exitDescription", session.parameters.ReceiveSuccessExitDescription);
																					session.output.write(StatusCheck_payload);
																					//end calling queue api 
																				}
																			});
																		} else if (responseStatusCode == 400) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "400");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																					session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																				} else {
																					if (responseData == 'No updates') {
																					}
																					else {
																						logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																						var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																						var task_payload = {
																							"msgId": incomingdata.msgId,
																							"jobId": incomingdata.jobId,
																							"serviceName": incomingdata.serviceName,
																							"status": responseStatusCode,
																							"message": RestorePredicted_ResponseData_Failure,
																							"timesStamp": new Date().toISOString()
																						}
																						ctx.setVariable("RestorePredicted_Failure", task_payload);
																						//start calling queue api
																						ilsctx.setVariable("exitStatus", responseStatusCode);
																						ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																						ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																						var Queueurl = session.parameters.FailureMQURL;
																						var test = PushingToQcall(Queueurl, task_payload);
																						session.output.write(task_payload);
																						//end calling queue api 
																					}
																				}
																			});

																		} else if (responseStatusCode == 409) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "409");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "error  response 'errorinfo', details are : " + info + "; error info :" + error
																					ctx.setVariable("retry", 'yes');
																					logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "409");
																				}
																			})
																		} else if (responseStatusCode == 401) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "401");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + ", details are : " + info + "; error info :" + error
																					ctx.setVariable("retry", 'yes');
																					logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "401");
																				}
																			})
																		} else if (responseStatusCode == 403) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "403");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "error  response 'errorinfo', details are : " + info + "; error info :" + error
																					ctx.setVariable("retry", 'yes');
																					logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "403");
																				}
																			})
																		} else {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					ilsctx.setVariable("errorStatus", "500");
																					logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																					session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																				} else {
																					logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																					var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																					var task_payload = {
																						"msgId": incomingdata.msgId,
																						"jobId": incomingdata.jobId,
																						"serviceName": incomingdata.serviceName,
																						"status": responseStatusCode,
																						"message": RestorePredicted_ResponseData_Failure,
																						"timesStamp": new Date().toISOString()
																					}
																					ctx.setVariable("RestorePredicted_Failure", task_payload);
																					//start calling queue api
																					ilsctx.setVariable("exitStatus", responseStatusCode);
																					ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																					ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																					var Queueurl = session.parameters.FailureMQURL;
																					var test = PushingToQcall(Queueurl, task_payload);
																					session.output.write(task_payload);
																					//end calling queue api 
																				}
																			});

																		}
																	}
																});
																//start calling queue api
																ilsctx.setVariable("exitStatus", "0");
																ilsctx.setVariable("exitDescription", session.parameters.ReceiveSuccessExitDescription);
																//end calling queue api 
															}
														});
													} else if (responseStatusCode == 409) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error;
																ilsctx.setVariable("errorStatus", "409");
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is" + JSON.stringify(errorinfo));
															} else {
																var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error
																ctx.setVariable("retry", 'yes');
																logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(responseData));
																var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																session.output.write(incomingdata);
																ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																ilsctx.setVariable("exitStatus", "409");

															}
														})
													} else if (responseStatusCode == 401) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "409");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is" + JSON.stringify(errorinfo));
															} else {
																var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid 401 " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error
																ctx.setVariable("retry", 'yes');
																logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid 401 " + jobId + " is " + JSON.stringify(responseData));
																var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid 401 " + jobId + " is " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																session.output.write(incomingdata);
																ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																ilsctx.setVariable("exitStatus", "401");
															}
														})
													} else if (responseStatusCode == 403) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "403");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is" + JSON.stringify(errorinfo));
															} else {
																var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error
																ctx.setVariable("retry", 'yes');
																logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(responseData));
																var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																session.output.write(incomingdata);
																ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																ilsctx.setVariable("exitStatus", "403");
															}
														})
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure reading the error response  'RestorePredicted', details are : " + RestorePredictedinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "500");
																logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															} else {
																logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																var task_payload = {
																	"msgId": incomingdata.msgId,
																	"jobId": incomingdata.jobId,
																	"serviceName": incomingdata.serviceName,
																	"status": responseStatusCode,
																	"message": RestorePredicted_ResponseData_Failure,
																	"timesStamp": new Date().toISOString()
																}
																ctx.setVariable("RestorePredicted_Failure", task_payload);
																//start calling queue api
																ilsctx.setVariable("exitStatus", responseStatusCode);
																ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																var Queueurl = session.parameters.FailureMQURL;
																var test = PushingToQcall(Queueurl, task_payload);
																session.output.write(task_payload);
																//end calling queue api 
															}
														});

													}
												}
											});
										} catch (error) {
											var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + ", details are : " + RestorePredictedinfo + "; error info :" + error;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", "500");
											logger.error("urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(errorinfo));
											session.reject("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request RestorePredicted post jobid " + jobId + " is " + JSON.stringify(errorinfo));
										}
										//call end							
									} else if (energizationStatus == 'VERIFIED') {
										ilsctx.setVariable("status", "Completed");
										//var jobId= incomingdata.jobId
										//POST /api/ServiceType/Electric/Job/{jobId}/RestoreDevice?time=10
										var RestoreDevice_VERIFIED_url = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId + '/RestoreDevice?time=' + epochTime
										var TokenValue = apiToken;
										var RestoreDevice_VERIFIED = {
											target: RestoreDevice_VERIFIED_url,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'POST',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										var RestoreDevice_VERIFIEDinfo = " TargetURL :" + RestoreDevice_VERIFIED.target + "; Method :" + RestoreDevice_VERIFIED.method + ". ";
										try {
											urlopen.open(RestoreDevice_VERIFIED, function(error, response) {
												if (error) {
													var errorinfo = "omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + ", details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + error
													ctx.setVariable("retry", 'yes');
													logger.debug(" omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " " + JSON.stringify(errorinfo));
													var ErrorTxt = "omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													session.output.write(incomingdata);
													ilsctx.setVariable("exitDescription", ErrorTxt);
													ilsctx.setVariable("exitStatus", "500");
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200 || responseStatusCode == 202) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + ", details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "500");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															} else {
																hm.response.statusCode = responseStatusCode;
																logger.debug("response code recieved from call Restore_VERIFIED is " + responseStatusCode);
																var Restore_VERIFIED_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																ctx.setVariable("Restore_VERIFIED_ResponseData", Restore_VERIFIED_ResponseData);
																ilsctx.setVariable("statusId", Restore_VERIFIED_ResponseData);
																ilsctx.setVariable("status", "RestoreDevice");
																//start calling queue api
																var JobPATCH_url = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId
																var TokenValue = apiToken;
																var payload = { "customFieldValues": { "completed_by_field": true } }
																var JobPATCHCall = {
																	target: JobPATCH_url,
																	sslClientProfile: 'OMS_Client_Profile',
																	method: 'PATCH',
																	contentType: 'application/json',
																	headers: {
																		'osiApiToken': TokenValue
																	},
																	data: payload
																};
																var info = " TargetURL :" + JobPATCHCall.target + "; Method :" + JobPATCHCall.method + "; Data :" + JSON.stringify(JobPATCHCall.data) + ". ";
																urlopen.open(JobPATCHCall, function(error, response) {
																	if (error) {
																		var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error
																		ctx.setVariable("retry", 'yes');
																		logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																		var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo);
																		ctx.setVariable("ErrorTxt", ErrorTxt);
																		session.output.write(incomingdata);
																		ilsctx.setVariable("exitDescription", errorinfo);
																		ilsctx.setVariable("exitStatus", "500");
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200 || responseStatusCode == 202) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					ilsctx.setVariable("errorStatus", "500");
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					hm.response.statusCode = responseStatusCode;
																					logger.debug("response code recieved from call JobPATCHCall is " + responseStatusCode);
																					var RestorePredicted_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
																					var StatusCheck_payload =
																					{
																						"msgId": incomingdata.msgId,
																						"jobId": incomingdata.jobId,
																						"serviceName": incomingdata.serviceName,
																						"status": 200,
																						"statusId": RestorePredicted_ResponseData,
																						"timesStamp": new Date().toISOString(),
																						"userId": incomingdata.userId
																					}
																					ctx.setVariable("RestorePredicted_payload", StatusCheck_payload);
																					//start calling queue api
																					ilsctx.setVariable("exitStatus", "0");
																					ilsctx.setVariable("exitDescription", session.parameters.ReceiveSuccessExitDescription);
																					session.output.write(StatusCheck_payload);
																					//end calling queue api 
																				}
																			});
																		} else if (responseStatusCode == 400) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					ilsctx.setVariable("errorStatus", "400");
																					logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																					session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																				} else {
																					if (responseData == 'No updates') {
																					}
																					else {
																						logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																						var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																						var task_payload = {
																							"msgId": incomingdata.msgId,
																							"jobId": incomingdata.jobId,
																							"serviceName": incomingdata.serviceName,
																							"status": responseStatusCode,
																							"message": RestorePredicted_ResponseData_Failure,
																							"timesStamp": new Date().toISOString()
																						}
																						ctx.setVariable("RestorePredicted_Failure", task_payload);
																						//start calling queue api
																						ilsctx.setVariable("exitStatus", responseStatusCode);
																						ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																						ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																						var Queueurl = session.parameters.FailureMQURL;
																						var test = PushingToQcall(Queueurl, task_payload);
																						session.output.write(task_payload);
																						//end calling queue api 
																					}
																				}
																			});

																		} else if (responseStatusCode == 409) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "409");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ctx.setVariable("retry", 'yes');
																					logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "409");
																				}
																			})
																		} else if (responseStatusCode == 401) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorStatus", "401");
																					ilsctx.setVariable("errorDescription", errorinfo);
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "error  response 'errorinfo', details are : " + info + "; error info :" + error

																					ctx.setVariable("retry", 'yes');
																					logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "401");

																				}
																			})
																		} else if (responseStatusCode == 403) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					ilsctx.setVariable("errorStatus", "403");
																					logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																					session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
																				} else {
																					var errorinfo = "error  response 'errorinfo', details are : " + info + "; error info :" + error

																					ctx.setVariable("retry", 'yes');
																					logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData));
																					var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																					session.output.write(incomingdata);
																					ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																					ilsctx.setVariable("exitStatus", "403");

																				}
																			})
																		} else {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					var errorinfo = "failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
																					ilsctx.setVariable("errorDescription", errorinfo);
																					ilsctx.setVariable("errorStatus", "401");
																					logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																					session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																				} else {
																					logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																					var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																					var task_payload = {
																						"msgId": incomingdata.msgId,
																						"jobId": incomingdata.jobId,
																						"serviceName": incomingdata.serviceName,
																						"status": responseStatusCode,
																						"message": RestorePredicted_ResponseData_Failure,
																						"timesStamp": new Date().toISOString()
																					}
																					ctx.setVariable("RestorePredicted_Failure", task_payload);
																					//start calling queue api
																					ilsctx.setVariable("exitStatus", responseStatusCode);
																					ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																					ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																					var Queueurl = session.parameters.FailureMQURL;
																					var test = PushingToQcall(Queueurl, task_payload);
																					session.output.write(task_payload);
																					//end calling queue api 
																				}
																			});

																		}
																	}
																});
																ilsctx.setVariable("exitStatus", "0");
																ilsctx.setVariable("exitDescription", session.parameters.ReceiveSuccessExitDescription);
																//end calling queue api 						
															}
														});
													} else if (responseStatusCode == 409) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + ", details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "409");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															} else {
																var errorinfo = "failure reading the error response  'RestoreDevice_VERIFIED', details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + responseData
																ctx.setVariable("retry", 'yes');
																logger.debug(" urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post is " + JSON.stringify(responseData));
																var ErrorTxt = "omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																session.output.write(incomingdata);
																ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																ilsctx.setVariable("exitStatus", "409");
															}
														})
													} else if (responseStatusCode == 401) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + ", details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "401");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															} else {
																var errorinfo = "failure reading the error response  'RestoreDevice_VERIFIED', details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + responseData
																ctx.setVariable("retry", 'yes');
																logger.error("omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post is 401 " + JSON.stringify(responseData));
																var ErrorTxt = "omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post is 401 " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																session.output.write(incomingdata);
																ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																ilsctx.setVariable("exitStatus", "401");
															}
														})
													} else if (responseStatusCode == 403) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + ", details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "403");
																logger.error(" error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("error message while reading from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															} else {
																var errorinfo = "failure reading the error response  'RestoreDevice_VERIFIED', details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + responseData
																ctx.setVariable("retry", 'yes');
																logger.error("omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post is " + JSON.stringify(responseData));
																var ErrorTxt = "omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(responseData);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																session.output.write(incomingdata);
																ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
																ilsctx.setVariable("exitStatus", "403");
															}
														})
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading message from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + ", details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "500");
																logger.error("failure in reading message from omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject("failure in reading message from omsapijob_OutageJobClosure_Request Restore_VERIFIED post call is " + JSON.stringify(errorinfo));
															} else {
																logger.debug(" response returned from Restore_VERIFIED post call is " + responseStatusCode + " " + responseData);
																var Restore_VERIFIED_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																ctx.setVariable("Restore_VERIFIED_ResponseData_Failure", Restore_VERIFIED_ResponseData_Failure);
																var task_payload = {
																	"msgId": incomingdata.msgId,
																	"jobId": incomingdata.jobId,
																	"serviceName": incomingdata.serviceName,
																	"status": responseStatusCode,
																	"message": Restore_VERIFIED_ResponseData_Failure,
																	"timesStamp": new Date().toISOString()
																}
																ctx.setVariable("Restore_VERIFIED_Failure", task_payload);
																//start calling queue api
																var Queueurl = session.parameters.FailureMQURL;
																ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																ilsctx.setVariable("exitStatus", responseStatusCode);
																var test = PushingToQcall(Queueurl, task_payload);
																session.output.write(task_payload);
																//end calling queue api
															}
														});

													}
												}
											});
										} catch (error) {
											var errorinfo = "omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + ", details are : " + RestoreDevice_VERIFIEDinfo + "; error info :" + error;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", "500");
											logger.error(" urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post is " + JSON.stringify(error));
											session.reject("omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(error));
										}
									} else if (energizationStatus == 'RESTORED') {
										//1.CALL GET /api/ServiceType/Electric/Job/{jobId}?includeFields=id,jobTypeID	
										var jobId = incomingdata.jobId;
										var OMSGeturl = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId + '?includeFields=id,jobTypeID';

										var apiToken = ctx.getVar("osiApiToken");
										//  headers.remove('MQMD');
										var JobGetapi = {
											target: OMSGeturl,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'GET',
											headers: {
												'osiApiToken': apiToken,
											},
										};
										var JobGetapiinfo = " TargetURL :" + JobGetapi.target + "; Method :" + JobGetapi.method + ". ";
										try {
											urlopen.open(JobGetapi, function(error, response) {
												if (error) {
													var errorinfo = "url connection error 'JobGetapi', details are : " + JobGetapiinfo + "; error info :" + error
													ctx.setVariable("retry", 'yes');
													logger.debug(" urlopen connect error from JobGetapi for job id " + jobId + " is " + JSON.stringify(JobGetapi));
													var ErrorTxt = (" OutageJobClosure_012 urlopen connect error from  omsapijob_OutageJobClosure_Request Getapi for job id " + jobId + " is " + JSON.stringify(JobGetapi));
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ilsctx.setVariable("exitDescription", errorinfo);
													ilsctx.setVariable("exitStatus", "500");
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200 || responseStatusCode == 202) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error message while reading response from omsapijob_OutageJobClosure_Request Getapi for job id " + jobId + ", details are : " + JobGetapiinfo + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "500");
																logger.error(" error message while reading response from omsapijob_OutageJobClosure_Request Getapi for job id " + jobId + " is " + JSON.stringify(errorinfo));
																session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request  get id " + jobId + " is " + JSON.stringify(errorinfo));
															} else {
																hm.response.statusCode = responseStatusCode;
																hm.response.statusCode = responseStatusCode;
																var JobapiResponse = JSON.parse(responseData);
																ctx.setVariable("JobGetapiResponse", JobapiResponse);
																var JobapiResponseID = JobapiResponse.id;
																var JobapiResponseIDjobTypeID = JobapiResponse.jobTypeID;
																//2.call PATCH /api/ServiceType/Electric/Job/{jobId} start
																var JobPATCH_url = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId
																var TokenValue = apiToken;
																var payload = { "customFieldValues": { "completed_by_field": true } }
																var JobPATCHCall = {
																	target: JobPATCH_url,
																	sslClientProfile: 'OMS_Client_Profile',
																	method: 'PATCH',
																	contentType: 'application/json',
																	headers: {
																		'osiApiToken': TokenValue
																	},
																	data: payload
																};
																var info = " TargetURL :" + JobPATCHCall.target + "; Method :" + JobPATCHCall.method + "; Data :" + JSON.stringify(JobPATCHCall.data) + ". ";
																try {
																	urlopen.open(JobPATCHCall, function(error, response) {
																		if (error) {
																			//retry shoud be done
																			var errorinfo = "error reading response 'JobPATCHCall', details are : " + info + "; error info :" + error
																			ctx.setVariable("retry", 'yes');
																			logger.debug(" urlopen connect error from omsapijob_OutageJobClosure_Request PATCH api  for job id " + jobId + " is " + JSON.stringify(errorinfo));
																			var ErrorTxt = ("OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH api for job id " + jobId + " is " + JSON.stringify(errorinfo));
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																			session.output.write(incomingdata);
																			ilsctx.setVariable("exitDescription", errorinfo);
																			ilsctx.setVariable("exitStatus", "500");
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200 || responseStatusCode == 202) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error message while reading response from PATCH for job id " + jobId + ", details are : " + info + "; error info :" + error;
																						ilsctx.setVariable("errorDescription", errorinfo);
																						ilsctx.setVariable("errorStatus", "500");
																						logger.error(" error message while reading response from PATCH for job id " + jobId + " is " + JSON.stringify(errorinfo));
																						session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request job id " + jobId + " is " + JSON.stringify(errorinfo));
																					} else {
																						hm.response.statusCode = responseStatusCode;
																						hm.response.statusCode = responseStatusCode;
																						var JobGetapiResponse = JSON.parse(responseData);
																						var lookupURL = session.parameters.lookupURL;
																						var lookupMessage = {
																							"lookupReq": {
																								"type": [
																									{
																										"name": "jobTypes.workflows",
																										"id": JobapiResponseIDjobTypeID,
																										"label": "Completed"
																									}
																								]
																							}
																						}
																						//lookup call start
																						var LookupServiceResponse = {
																							target: lookupURL,
																							method: 'POST',
																							contentType: 'application/json',
																							data: lookupMessage
																						};
																						var Lookupinfo = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																						try {
																							urlopen.open(LookupServiceResponse, function(error, response) {
																								if (error) {
																									var errorinfo = "urlopen connect error with  LookupServiceResponse for jobtypeID " + JobapiResponseIDjobTypeID + ", details are : " + Lookupinfo + "; error info :" + error;
																									ilsctx.setVariable("errorDescription", errorinfo);
																									ilsctx.setVariable("errorStatus", "500");
																									logger.error(" urlopen connect error with  LookupServiceResponse for jobtypeID " + JobapiResponseIDjobTypeID + " is " + JSON.stringify(errorinfo));
																									session.reject(" urlopen connect error with  LookupServiceResponse for jobtypeID " + JSON.stringify(errorinfo));
																								} else {
																									var responseStatusCode = response.statusCode;
																									if (responseStatusCode == 200) {
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												var errorinfo = "failure in getting message from  LookupServiceResponse for jobtypeID, details are : " + Lookupinfo + "; error info :" + error;
																												ilsctx.setVariable("errorDescription", errorinfo);
																												logger.error(" failure in getting message from  LookupServiceResponse for jobtypeID " + JSON.stringify(errorinfo));
																												session.reject(" failure in getting message from  LookupServiceResponse for jobtypeID " + JSON.stringify(errorinfo));
																											} else {
																												hm.response.statusCode = responseStatusCode;
																												var lookupResponse = JSON.parse(responseData)
																												var lookupstatus;
																												if (lookupResponse.lookupRep.type[0].result == 0) {
																													lookupstatus = lookupResponse.lookupRep.type[0].status;
																													ctx.setVariable("lookupstatus", lookupstatus);
																													//5.start Call POST  /api/v1/ServiceType/Electric/Job/{jobId}/WorkFlow {for example if the status is 8}
																													var JobWorkflow_url = Url + '/oms/external/api/v1/ServiceType/Electric/Job/' + jobId + '/WorkFlow'
																													var TokenValue = apiToken;
																													var payload = lookupstatus
																													//	var payload1 = {lookupstatus}
																													//logger.error("payload1 "+JSON.stringify())
																													var JobWorkflow_Call = {
																														target: JobWorkflow_url,
																														sslClientProfile: 'OMS_Client_Profile',
																														method: 'POST',
																														contentType: 'application/json',
																														headers: {
																															'osiApiToken': TokenValue
																														},
																														data: payload
																													};
																													var JobWorkflow_Callinfo = " TargetURL :" + JobWorkflow_Call.target + "; Method :" + JobWorkflow_Call.method + "; Data :" + JSON.stringify(JobWorkflow_Call.data) + ". ";

																													try {
																														urlopen.open(JobWorkflow_Call, function(error, response) {
																															if (error) {
																																//retry shoud be done
																																var errorinfo = "OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + ", details are : " + JobWorkflow_Callinfo + "; error info :" + error
																																ctx.setVariable("retry", 'yes');
																																logger.debug(" urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + " is " + JSON.stringify(errorinfo));
																																var ErrorTxt = ("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + " is " + JSON.stringify(errorinfo));
																																ctx.setVariable("ErrorTxt", ErrorTxt);
																																ilsctx.setVariable("exitDescription", errorinfo);
																																ilsctx.setVariable("exitStatus", "500");
																																session.output.write(incomingdata);
																															} else {
																																var responseStatusCode = response.statusCode;
																																if (responseStatusCode == 200 || responseStatusCode == 202) {
																																	response.readAsBuffer(function(error, responseData) {
																																		if (error) {
																																			var errorinfo = "error message while reading response from POST jobworkflow for job id " + jobId + ", details are : " + JobWorkflow_Callinfo + "; error info :" + error;
																																			ilsctx.setVariable("errorStatus", "500");
																																			ilsctx.setVariable("errorDescription", errorinfo);
																																			logger.error(" error message while reading response from POST jobworkflow for job id " + jobId + " is " + JSON.stringify(errorinfo));
																																			session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request job id " + jobId + " is " + JSON.stringify(errorinfo));
																																		} else {
																																			hm.response.statusCode = responseStatusCode;
																																			hm.response.statusCode = responseStatusCode;
																																			var JobGetapiResponse = JSON.parse(responseData);
																																			ilsctx.setVariable("status", "Completed");
																																			ilsctx.setVariable("statusId", "");
																																			var payload = {
																																				"msgId": incomingdata.msgId,
																																				"serviceName": incomingdata.serviceName,
																																				"jobId": incomingdata.jobId,
																																				"status": "200",
																																				"message": "Outage job close sucessfully.",
																																				"timesStamp": new Date().toISOString(),
																																				"userId": incomingdata.userId
																																			}
																																			//start calling queue api StatusCheckMQURL
																																			ilsctx.setVariable("exitStatus", "0");
																																			ilsctx.setVariable("exitDescription", session.parameters.ReceiveCloseExitDescription);
																																			ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																																			var Queueurl = session.parameters.FailureMQURL;
																																			var test = PushingToQcall(Queueurl, payload);
																																			//  session.output.write(task_payload);
																																			//end calling queue api
																																		}
																																	})
																																} else if (responseStatusCode == 401) {
																																	response.readAsBuffer(function(error, responseData) {
																																		if (error) {
																																			var AuthenticationError = error.toString();
																																			ctx.setVariable("retry", 'yes');
																																			logger.error("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + AuthenticationError);
																																			var ErrorTxt = "OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id 401 " + jobId + " is " + AuthenticationError;
																																			ctx.setVariable("ErrorTxt", ErrorTxt);
																																			ilsctx.setVariable("exitDescription", ErrorTxt);
																																			ilsctx.setVariable("exitStatus", "401");
																																			session.output.write(incomingdata);
																																		}
																																		else {
																																			var AuthenticationError = responseData.toString();
																																			ctx.setVariable("retry", 'yes');
																																			logger.error("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id 401 " + jobId + " is " + AuthenticationError);
																																			var ErrorTxt = "OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id 401 " + jobId + " is " + AuthenticationError;
																																			ctx.setVariable("ErrorTxt", ErrorTxt);
																																			ilsctx.setVariable("exitDescription", ErrorTxt);
																																			ilsctx.setVariable("exitStatus", "401");
																																			session.output.write(incomingdata);
																																		}
																																	})
																																} else if (responseStatusCode == 403) {
																																	response.readAsBuffer(function(error, responseData) {
																																		if (error) {
																																			var ForbiddenError = error.toString();
																																			ctx.setVariable("retry", 'yes');
																																			logger.error("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + ForbiddenError);
																																			var ErrorTxt = ("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + ForbiddenError);
																																			ctx.setVariable("ErrorTxt", ErrorTxt);
																																			ilsctx.setVariable("exitDescription", ErrorTxt);
																																			ilsctx.setVariable("exitStatus", "403");
																																			session.output.write(incomingdata);
																																		}
																																		else {
																																			var ForbiddenError = responseData.toString();
																																			ctx.setVariable("retry", 'yes');
																																			logger.error("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + ForbiddenError);
																																			var ErrorTxt = ("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + ForbiddenError);
																																			ctx.setVariable("ErrorTxt", ErrorTxt);
																																			ilsctx.setVariable("exitDescription", ErrorTxt);
																																			ilsctx.setVariable("exitStatus", "403");
																																			session.output.write(incomingdata);
																																		}
																																	})
																																} else if (responseStatusCode == 400) {
																																	response.readAsBuffer(function(error, responseData) {
																																		if (error) {
																																			var errorinfo = "error message while reading response from POST jobworkflow for job id " + jobId + ", details are : " + JobWorkflow_Callinfo + "; error info :" + error;
																																			ilsctx.setVariable("errorDescription", errorinfo);
																																			ilsctx.setVariable("errorStatus", "400");
																																			logger.error(" error message while reading response from POST jobworkflow for job id " + jobId + " is " + JSON.stringify(errorinfo));
																																			session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request job id " + jobId + " is " + JSON.stringify(errorinfo));
																																		} else {

																																			// framing failure message start
																																			var Failure_payload = {
																																				"msgId": incomingdata.msgId,
																																				"serviceName": incomingdata.serviceName,
																																				"jobId": incomingdata.jobId,
																																				"status": responseStatusCode,
																																				//"message" :  responseData.failureReasons,
																																				"timesStamp": new Date().toISOString()
																																			}
																																			var responseData = JSON.parse(responseData);
																																			if (responseData.message === undefined || responseData.message === null || responseData.message === '') {
																																				Failure_payload.message = JSON.stringify(responseData)
																																			} else {
																																				Failure_payload.message = responseData.message
																																			}
																																			//start calling queue api
																																			ilsctx.setVariable("exitDescription", "job Closure failed");
																																			ilsctx.setVariable("exitStatus", "400");
																																			ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																																			var Queueurl = session.parameters.FailureMQURL;
																																			var test = PushingToQcall(Queueurl, Failure_payload);
																																			// session.output.write(task_payload);
																																			//end calling queue api
																																		}
																																	});
																																}
																																else {
																																	// framing failure message start
																																	var Failure_payload = {
																																		"msgId": incomingdata.msgId,
																																		"serviceName": incomingdata.serviceName,
																																		"jobId": incomingdata.jobId,
																																		"status": responseStatusCode,
																																		"message": response.reasonPhrase,
																																		"timesStamp": new Date().toISOString()
																																	}
																																	//start calling queue api
																																	ilsctx.setVariable("exitDescription", "job Closure failed");
																																	ilsctx.setVariable("exitStatus", responseStatusCode);
																																	ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																																	var Queueurl = session.parameters.FailureMQURL;
																																	var test = PushingToQcall(Queueurl, Failure_payload);
																																	// session.output.write(task_payload);
																																	//end calling queue api
																																}
																															}
																														})
																													} catch (error) {
																														var errorinfo = "OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + ", details are : " + JobWorkflow_Callinfo + "; error info :" + error;
																														ilsctx.setVariable("errorDescription", errorinfo);
																														ilsctx.setVariable("errorStatus", "500");
																														logger.error(" urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + " is " + JSON.stringify(errorinfo));
																														session.reject("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + " is " + JSON.stringify(errorinfo));
																													}
																													// 5 end
																												} else {
																													var errorinfo = "lookup service result code for  LookupServiceResponse for jobtypeID  " + JobapiResponseIDjobTypeID + ", details are : " + Lookupinfo + "; error info :" + error;
																													ilsctx.setVariable("errorDescription", errorinfo);
																													ilsctx.setVariable("errorStatus", "500");
																													logger.error(" lookup service result code for  LookupServiceResponse for jobtypeID  " + JobapiResponseIDjobTypeID + " is " + lookupResponse.lookupRep.type[0].result + errorinfo);
																													session.reject(" lookup service result code for  LookupServiceResponse for jobtypeID  " + JobapiResponseIDjobTypeID + " is " + lookupResponse.lookupRep.type[0].result + errorinfo);
																												}// lookup end;

																											}
																										});

																									} else {
																										var errorinfo = "lookup service from  LookupServiceResponse for jobtypeID responsecode " + JobapiResponseIDjobTypeID + ", details are : " + Lookupinfo + "; error info :" + responseData;
																										ilsctx.setVariable("errorDescription", errorinfo);
																										ilsctx.setVariable("errorStatus", "500");
																										logger.error(" lookup service from  LookupServiceResponse for jobtypeID responsecode " + JobapiResponseIDjobTypeID + " is " + responseStatusCode + errorinfo);
																										session.reject("lookup service from  LookupServiceResponse for jobtypeID responsecode " + JobapiResponseIDjobTypeID + " is " + responseStatusCode + errorinfo);
																									}
																								}
																							});
																						} catch (error) {
																							var errorinfo = "urlopen connect error with  LookupServiceResponse for jobtypeID " + JobapiResponseIDjobTypeID + ", details are : " + Lookupinfo + "; error info :" + error;
																							ilsctx.setVariable("errorDescription", errorinfo);
																							ilsctx.setVariable("errorStatus", "500");
																							logger.error(" urlopen connect error with  LookupServiceResponse for jobtypeID " + JobapiResponseIDjobTypeID + " is " + JSON.stringify(errorinfo));
																							session.reject(" urlopen connect error with  LookupServiceResponse for jobtypeID " + JSON.stringify(errorinfo));
																						}
																						//lookup call end							

																					}
																				});
																			} else if (responseStatusCode == 401) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var AuthenticationError = error.toString();
																						ctx.setVariable("retry", 'yes');
																						logger.error("OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH for job id " + jobId + " is " + AuthenticationError);
																						var ErrorTxt = "OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH for job id 401 " + jobId + " is " + AuthenticationError;
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																						ilsctx.setVariable("exitDescription", ErrorTxt);
																						ilsctx.setVariable("exitStatus", "401");
																						session.output.write(incomingdata);
																					}
																					else {
																						var AuthenticationError = responseData.toString();
																						ctx.setVariable("retry", 'yes');
																						logger.error("OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH for job id 401 " + jobId + " is " + AuthenticationError);
																						var ErrorTxt = "OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH for job id 401 " + jobId + " is " + AuthenticationError;
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																						ilsctx.setVariable("exitDescription", ErrorTxt);
																						ilsctx.setVariable("exitStatus", "401");
																						session.output.write(incomingdata);
																					}
																				})
																			} else if (responseStatusCode == 403) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var ForbiddenError = error.toString();
																						ctx.setVariable("retry", 'yes');
																						logger.error("OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH for job id " + jobId + " is " + ForbiddenError);
																						var ErrorTxt = ("OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH for job id " + jobId + " is " + ForbiddenError);
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																						ilsctx.setVariable("exitDescription", ErrorTxt);
																						ilsctx.setVariable("exitStatus", "403");
																						session.output.write(incomingdata);
																					}
																					else {
																						var ForbiddenError = responseData.toString();

																						ctx.setVariable("retry", 'yes');
																						logger.error("OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH for job id " + jobId + " is " + ForbiddenError);
																						var ErrorTxt = ("OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH for job id " + jobId + " is " + ForbiddenError);
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																						ilsctx.setVariable("exitDescription", ErrorTxt);
																						ilsctx.setVariable("exitStatus", "403");
																						session.output.write(incomingdata);
																					}
																				})
																			} else if (responseStatusCode == 400) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error message while reading response from PATCH for job id " + jobId + ", details are : " + info + "; error info :" + error;
																						ilsctx.setVariable("errorDescription", errorinfo);
																						ilsctx.setVariable("errorStatus", "400");
																						logger.error(" error message while reading response from PATCH for job id " + jobId + " is " + JSON.stringify(errorinfo));
																						session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request job id " + jobId + " is " + JSON.stringify(errorinfo));
																					} else {
																						hm.response.statusCode = responseStatusCode;
																						hm.response.statusCode = responseStatusCode;
																						var apiResponse = responseData;
																						if (apiResponse == "No updates") {
																							var lookupURL = session.parameters.lookupURL;
																							var lookupMessage = {
																								"lookupReq": {
																									"type": [
																										{
																											"name": "jobTypes.workflows",
																											"id": JobapiResponseIDjobTypeID,
																											"label": "Completed"
																										}
																									]
																								}
																							}
																							//lookup call start
																							var LookupServiceResponse = {
																								target: lookupURL,
																								method: 'POST',
																								contentType: 'application/json',
																								data: lookupMessage
																							};
																							var LookupServiceResponseinfo = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																							try {
																								urlopen.open(LookupServiceResponse, function(error, response) {
																									if (error) {
																										var errorinfo = "urlopen connect error with mjcs LookupServiceResponse for jobtypeID " + JobapiResponseIDjobTypeID + ", details are : " + LookupServiceResponseinfo + "; error info :" + error;
																										ilsctx.setVariable("errorDescription", errorinfo);
																										ilsctx.setVariable("errorStatus", "500");
																										logger.error(" urlopen connect error with mjcs LookupServiceResponse for jobtypeID " + JobapiResponseIDjobTypeID + " is " + JSON.stringify(errorinfo));
																										session.reject(" urlopen connect error with mjcs LookupServiceResponse for jobtypeID " + JSON.stringify(errorinfo));
																									} else {
																										var responseStatusCode = response.statusCode;
																										if (responseStatusCode == 200) {
																											LookupServiceResponse
																											response.readAsBuffer(function(error, responseData) {
																												if (error) {
																													var errorinfo = "error reading response 'RestoreDevice_VERIFIEDfailure in getting message from mjcs LookupServiceResponse for jobtypeID', details are : " + LookupServiceResponseinfo + "; error info :" + error;
																													ilsctx.setVariable("errorDescription", errorinfo);
																													ilsctx.setVariable("errorStatus", "500");
																													logger.error(" failure in getting message from mjcs LookupServiceResponse for jobtypeID " + JSON.stringify(errorinfo));
																													session.reject(" failure in getting message from mjcs LookupServiceResponse for jobtypeID " + JSON.stringify(errorinfo));
																												} else {
																													hm.response.statusCode = responseStatusCode;
																													var lookupResponse = JSON.parse(responseData)
																													var lookupstatus;
																													if (lookupResponse.lookupRep.type[0].result == 0) {
																														lookupstatus = lookupResponse.lookupRep.type[0].status;
																														ctx.setVariable("lookupstatus", lookupstatus);
																														//5.start Call POST  /api/v1/ServiceType/Electric/Job/{jobId}/WorkFlow {for example if the status is 8}
																														var JobWorkflow_url = Url + '/oms/external/api/v1/ServiceType/Electric/Job/' + jobId + '/WorkFlow'
																														var TokenValue = apiToken;
																														var payload = lookupstatus
																														//	var payload1 = {lookupstatus}
																														//logger.error("payload1 "+JSON.stringify())
																														var JobWorkflow_Call = {
																															target: JobWorkflow_url,
																															sslClientProfile: 'OMS_Client_Profile',
																															method: 'POST',
																															contentType: 'application/json',
																															headers: {
																																'osiApiToken': TokenValue
																															},
																															data: payload
																														};
																														var info = " TargetURL :" + JobWorkflow_Call.target + "; Method :" + JobWorkflow_Call.method + "; Data :" + JSON.stringify(JobWorkflow_Call.data) + ". ";
																														try {
																															urlopen.open(JobWorkflow_Call, function(error, response) {
																																if (error) {
																																	//retry shoud be done
																																	var errorinfo = "OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + ", details are : " + info + "; error info :" + error
																																	ctx.setVariable("retry", 'yes');
																																	logger.debug(" urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + " is " + JSON.stringify(errorinfo));
																																	var ErrorTxt = ("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + " is " + JSON.stringify(errorinfo));
																																	ctx.setVariable("ErrorTxt", ErrorTxt);
																																	session.output.write(incomingdata);
																																	ilsctx.setVariable("exitDescription", errorinfo);
																																	ilsctx.setVariable("exitStatus", "500");
																																} else {
																																	var responseStatusCode = response.statusCode;
																																	if (responseStatusCode == 200 || responseStatusCode == 202) {
																																		response.readAsBuffer(function(error, responseData) {
																																			if (error) {
																																				var errorinfo = "error message while reading response from POST jobworkflow for job id " + jobId + ", details are : " + info + "; error info :" + error;
																																				ilsctx.setVariable("errorDescription", errorinfo);
																																				ilsctx.setVariable("errorStatus", "500");
																																				logger.error(" error message while reading response from POST jobworkflow for job id " + jobId + " is " + JSON.stringify(errorinfo));
																																				session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request job id " + jobId + " is " + JSON.stringify(errorinfo));
																																			} else {
																																				hm.response.statusCode = responseStatusCode;
																																				hm.response.statusCode = responseStatusCode;
																																				var JobGetapiResponse = JSON.parse(responseData);
																																				ilsctx.setVariable("status", "Completed");
																																				ilsctx.setVariable("statusId", "");
																																				var payload = {
																																					"msgId": incomingdata.msgId,
																																					"serviceName": incomingdata.serviceName,
																																					"jobId": incomingdata.jobId,
																																					"status": "200",
																																					"message": "Outage job close sucessfully.",
																																					"timesStamp": new Date().toISOString(),
																																					"userId": incomingdata.userId
																																				}
																																				//start calling queue api
																																				ilsctx.setVariable("exitStatus", "0");
																																				ilsctx.setVariable("exitDescription", session.parameters.ReceiveCloseExitDescription);
																																				ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																																				var Queueurl = session.parameters.FailureMQURL;
																																				var test = PushingToQcall(Queueurl, payload);
																																				//  session.output.write(task_payload);
																																				//end calling queue api
																																			}
																																		})
																																	} else if (responseStatusCode == 401) {
																																		response.readAsBuffer(function(error, responseData) {
																																			if (error) {
																																				var AuthenticationError = error.toString();
																																				ctx.setVariable("retry", 'yes');
																																				logger.error(" urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + AuthenticationError);
																																				var ErrorTxt = "OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id 401 " + jobId + " is " + AuthenticationError;
																																				ctx.setVariable("ErrorTxt", ErrorTxt);
																																				ilsctx.setVariable("exitDescription", ErrorTxt);
																																				ilsctx.setVariable("exitStatus", "401");
																																				session.output.write(incomingdata);
																																			}
																																			else {
																																				var AuthenticationError = responseData.toString();
																																				ctx.setVariable("retry", 'yes');
																																				logger.error("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id 401 " + jobId + " is " + AuthenticationError);
																																				var ErrorTxt = "OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id 401 " + jobId + " is " + AuthenticationError;
																																				ctx.setVariable("ErrorTxt", ErrorTxt);
																																				ilsctx.setVariable("exitDescription", ErrorTxt);
																																				ilsctx.setVariable("exitStatus", "401");
																																				session.output.write(incomingdata);
																																			}
																																		})
																																	} else if (responseStatusCode == 403) {
																																		response.readAsBuffer(function(error, responseData) {
																																			if (error) {
																																				var AuthenticationError = error.toString();
																																				ctx.setVariable("retry", 'yes');
																																				logger.error("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + AuthenticationError);
																																				var ErrorTxt = ("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + AuthenticationError);
																																				ctx.setVariable("ErrorTxt", ErrorTxt);
																																				ilsctx.setVariable("exitDescription", ErrorTxt);
																																				ilsctx.setVariable("exitStatus", "403");
																																				session.output.write(incomingdata);
																																			}
																																			else {
																																				var AuthenticationError = responseData.toString();
																																				ctx.setVariable("retry", 'yes');
																																				logger.error("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + AuthenticationError);
																																				var ErrorTxt = ("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request POST workflow for job id " + jobId + " is " + AuthenticationError);
																																				ctx.setVariable("ErrorTxt", ErrorTxt);
																																				ilsctx.setVariable("exitDescription", ErrorTxt);
																																				ilsctx.setVariable("exitStatus", "403");
																																				session.output.write(incomingdata);
																																			}
																																		})
																																	} else if (responseStatusCode == 400) {
																																		response.readAsBuffer(function(error, responseData) {
																																			if (error) {
																																				var errorinfo = "error message while reading response from POST jobworkflow for job id " + jobId + ", details are : " + info + "; error info :" + error;
																																				ilsctx.setVariable("errorDescription", errorinfo);
																																				logger.error(" error message while reading response from POST jobworkflow for job id " + jobId + " is " + JSON.stringify(errorinfo));
																																				session.reject(" error message while reading response from omsapijob_OutageJobClosure_Request job id " + jobId + " is " + JSON.stringify(errorinfo));
																																			} else {
																																				var errorinfo = "Job Closure failure 'JobWorkflow_Call', details are : " + info + "; error info :" + responseData;
																																				// framing failure message start
																																				var Failure_payload = {
																																					"msgId": incomingdata.msgId,
																																					"serviceName": incomingdata.serviceName,
																																					"jobId": incomingdata.jobId,
																																					"status": responseStatusCode,
																																					//"message" :  responseData.failureReasons,
																																					"timesStamp": new Date().toISOString()
																																				}
																																				var responseData = JSON.parse(responseData);
																																				if (responseData.message === undefined || responseData.message === null || responseData.message === '') {
																																					Failure_payload.message = JSON.stringify(responseData)
																																				} else {
																																					Failure_payload.message = responseData.message
																																				}
																																				//start calling queue api
																																				ilsctx.setVariable("exitDescription", errorinfo);
																																				ilsctx.setVariable("exitStatus", "400");
																																				ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																																				var Queueurl = session.parameters.FailureMQURL;
																																				var test = PushingToQcall(Queueurl, Failure_payload);
																																				// session.output.write(task_payload);
																																				//end calling queue api					
																																			}
																																		});
																																	}
																																	else {
																																		// framing failure message start
																																		var Failure_payload = {
																																			"msgId": incomingdata.msgId,
																																			"serviceName": incomingdata.serviceName,
																																			"jobId": incomingdata.jobId,
																																			"status": responseStatusCode,
																																			"message": response.reasonPhrase,
																																			"timesStamp": new Date().toISOString()
																																		}
																																		//start calling queue api
																																		ilsctx.setVariable("exitDescription", response.reasonPhrase);
																																		ilsctx.setVariable("exitStatus", responseStatusCode);
																																		ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																																		var Queueurl = session.parameters.FailureMQURL;
																																		var test = PushingToQcall(Queueurl, Failure_payload);
																																		// session.output.write(task_payload);
																																		//end calling queue api
																																	}
																																}
																															})
																														} catch (error) {
																															var errorinfo = "OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + ", details are : " + info + "; error info :" + error;
																															ilsctx.setVariable("errorDescription", errorinfo);
																															ilsctx.setVariable("errorStatus", "500");
																															logger.debug(" urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + " is " + JSON.stringify(errorinfo));
																															session.reject("OutageJobClosure_014 urlopen connect error from omsapijob_OutageJobClosure_Request JobWorkflow_Call for job id " + jobId + " is " + JSON.stringify(errorinfo));
																														}
																														// 5 end
																													} else {
																														var errorinfo = "lookup service result code for  LookupServiceResponse for jobtypeID  " + JobapiResponseIDjobTypeID + ", details are : " + info + "; error info :" + error;
																														ilsctx.setVariable("errorDescription", errorinfo);
																														ilsctx.setVariable("errorStatus", "500");
																														logger.error(" lookup service result code for  LookupServiceResponse for jobtypeID  " + JobapiResponseIDjobTypeID + " is " + lookupResponse.lookupRep.type[0].result + errorinfo);
																														session.reject(" lookup service result code for  LookupServiceResponse for jobtypeID  " + JobapiResponseIDjobTypeID + " is " + lookupResponse.lookupRep.type[0].result + errorinfo);
																													}// lookup end;

																												}
																											});

																										} else {
																											var errorinfo = "lookup service from  LookupServiceResponse for jobtypeID responsecode " + JobapiResponseIDjobTypeID + " is " + responseStatusCode + ", details are : " + info + "; error info :" + error;
																											ilsctx.setVariable("errorDescription", errorinfo);
																											ilsctx.setVariable("errorStatus", "500");
																											logger.error(" lookup service from  LookupServiceResponse for jobtypeID responsecode " + JobapiResponseIDjobTypeID + " is " + responseStatusCode);
																											session.reject("lookup service from  LookupServiceResponse for jobtypeID responsecode " + JobapiResponseIDjobTypeID + " is " + responseStatusCode);
																										}
																									}
																								});
																							} catch (error) {
																								var errorinfo = "urlopen connect error with mjcs LookupServiceResponse for jobtypeID " + JobapiResponseIDjobTypeID + ", details are : " + LookupServiceResponseinfo + "; error info :" + error
																								ilsctx.setVariable("errorDescription", errorinfo);
																								ilsctx.setVariable("errorStatus", "500");
																								logger.error(" urlopen connect error with mjcs LookupServiceResponse for jobtypeID " + JobapiResponseIDjobTypeID + " is " + JSON.stringify(errorinfo));
																								session.reject(" urlopen connect error with mjcs LookupServiceResponse for jobtypeID " + JSON.stringify(errorinfo));
																							}
																							//lookup call end							
																						} else {
																							// framing failure message start
																							var message = apiResponse
																							var Failure_payload = {
																								"msgId": incomingdata.msgId,
																								"serviceName": incomingdata.serviceName,
																								"jobId": incomingdata.jobId,
																								"status": responseStatusCode,
																								//"message" :  message,  
																								"timesStamp": new Date().toISOString()
																							}
																							Failure_payload.message = new Buffer(message).toString()
																							//start calling queue api
																							ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																							var Queueurl = session.parameters.FailureMQURL;
																							var test = PushingToQcall(Queueurl, Failure_payload);
																							ilsctx.setVariable("exitDescription", response.reasonPhrase);
																							ilsctx.setVariable("exitStatus", responseStatusCode);
																							// session.output.write(task_payload);
																							//end calling queue api
																						}
																					}
																				});

																			} else {
																				// framing failure message start
																				var Failure_payload = {
																					"msgId": incomingdata.msgId,
																					"serviceName": incomingdata.serviceName,
																					"jobId": incomingdata.jobId,
																					"status": responseStatusCode,
																					"message": response.reasonPhrase,
																					"timesStamp": new Date().toISOString()
																				}
																				//start calling queue api
																				var Queueurl = session.parameters.FailureMQURL;
																				var test = PushingToQcall(Queueurl, Failure_payload);
																				ilsctx.setVariable("exitDescription", response.reasonPhrase);
																				ilsctx.setVariable("exitStatus", responseStatusCode);
																				ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																				// session.output.write(task_payload);
																				//end calling queue api
																			}
																		}
																	})
																} catch (error) {
																	var errorinfo = "OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH api for job id " + jobId + ", details are : " + info + "; error info :" + error;
																	ilsctx.setVariable("errorDescription", errorinfo);
																	ilsctx.setVariable("errorStatus", "500");
																	logger.error(" urlopen connect error from omsapijob_OutageJobClosure_Request PATCH api  for job id " + jobId + " is " + JSON.stringify(errorinfo));
																	session.reject("OutageJobClosure_013 urlopen connect error from omsapijob_OutageJobClosure_Request PATCH api for job id " + jobId + " is " + JSON.stringify(errorinfo));
																}
																//2.call PATCH /api/ServiceType/Electric/Job/{jobId} end
															}
														});
													} else if (responseStatusCode == 401) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var AuthenticationError = error.toString();
																ctx.setVariable("retry", 'yes');
																logger.error("OutageJobClosure_012 urlopen connect error from omsapijob_OutageJobClosure_Request JobGetapi for job id 401 " + jobId + " and status " + status + " is " + AuthenticationError);
																var ErrorTxt = "OutageJobClosure_012 urlopen connect error from omsapijob_OutageJobClosure_Request JobGetapi for job id 401 " + jobId + " and status " + status + " is " + AuthenticationError;
																ctx.setVariable("ErrorTxt", ErrorTxt);
																ilsctx.setVariable("exitDescription", ErrorTxt);
																ilsctx.setVariable("exitStatus", "401");
																session.output.write(incomingdata);
															}
															else {
																var AuthenticationError = responseData.toString();
																ctx.setVariable("retry", 'yes');
																logger.error("OutageJobClosure_012 urlopen connect error from omsapijob_OutageJobClosure_Request JobGetapi for job id 401 " + jobId + " and status " + status + " is " + AuthenticationError);
																var ErrorTxt = "OutageJobClosure_012 urlopen connect error from omsapijob_OutageJobClosure_Request JobGetapi for job id 401 " + jobId + " and status " + status + " is " + AuthenticationError;
																ctx.setVariable("ErrorTxt", ErrorTxt);
																ilsctx.setVariable("exitDescription", ErrorTxt);
																ilsctx.setVariable("exitStatus", "401");
																session.output.write(incomingdata);
															}
														})
													} else if (responseStatusCode == 403) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var ForbiddenError = error.toString();
																ctx.setVariable("retry", 'yes');
																logger.error("OutageJobClosure_012 urlopen connect error from omsapijob_OutageJobClosure_Request JobGetapi for job id 403 " + jobId + " and status " + status + " is " + ForbiddenError);
																var ErrorTxt = ("OutageJobClosure_012 urlopen connect error from omsapijob_OutageJobClosure_Request Getapi for job id 403 " + jobId + " and status " + status + " is " + ForbiddenError);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																ilsctx.setVariable("exitDescription", ErrorTxt);
																ilsctx.setVariable("exitStatus", "403");
																session.output.write(incomingdata);
															}
															else {
																var ForbiddenError = responseData.toString();
																ctx.setVariable("retry", 'yes');
																logger.error("OutageJobClosure_012 urlopen connect error from omsapijob_OutageJobClosure_Request JobGetapi for job id 403 " + jobId + " and status " + status + " is " + ForbiddenError);
																var ErrorTxt = ("OutageJobClosure_012 urlopen connect error from omsapijob_OutageJobClosure_Request Getapi for job id 403 " + jobId + " and status " + status + " is " + ForbiddenError);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																ilsctx.setVariable("exitDescription", ErrorTxt);
																ilsctx.setVariable("exitStatus", "403");
																session.output.write(incomingdata);
															}
														})
													} else {
														var errorinfo = "failure in getting response, details are : " + info
														// framing failure message start
														var Failure_payload = {
															"msgId": incomingdata.msgId,
															"serviceName": incomingdata.serviceName,
															"jobId": incomingdata.jobId,
															"status": responseStatusCode,
															"message": response.reasonPhrase,
															"timesStamp": new Date().toISOString()
														}
														//start calling queue api
														var Queueurl = session.parameters.FailureMQURL;
														var test = PushingToQcall(Queueurl, Failure_payload);
														ilsctx.setVariable("exitDescription", errorinfo);
														ilsctx.setVariable("exitStatus", responseStatusCode);
														ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
														//  session.output.write(task_payload);
														//end calling queue api
													}
												}
											})
										} catch (error) {
											var errorinfo = "omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + ", details are : " + info + "; error info :" + error;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", "500");
											logger.error(" urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post is " + JSON.stringify(error));
											session.reject("omsapijob_003 urlopen connect error with omsapijob_OutageJobClosure_Request Restore_VERIFIED post jobid " + jobId + " is " + JSON.stringify(error));
										}
										//RESTORED CLOSE
									} else {
										var JobPATCH_url = Url + '/oms/external/api/ServiceType/Electric/Job/' + jobId
										var TokenValue = apiToken;
										var payload = { "customFieldValues": { "completed_by_field": true } }
										var JobPATCHCall = {
											target: JobPATCH_url,
											sslClientProfile: 'OMS_Client_Profile',
											method: 'PATCH',
											contentType: 'application/json',
											headers: {
												'osiApiToken': TokenValue
											},
											data: payload
										};
										var info = " TargetURL :" + JobPATCHCall.target + "; Method :" + JobPATCHCall.method + "; Data :" + JSON.stringify(JobPATCHCall.data) + ". ";
										urlopen.open(JobPATCHCall, function(error, response) {
											if (error) {
												var errorinfo = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error
												ctx.setVariable("retry", 'yes');
												logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
												var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo);
												ctx.setVariable("ErrorTxt", ErrorTxt);
												session.output.write(incomingdata);
												ilsctx.setVariable("exitDescription", errorinfo);
												ilsctx.setVariable("exitStatus", "500");
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200 || responseStatusCode == 202) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															ilsctx.setVariable("errorStatus", "500");
															logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
															session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response code recieved from call JobPATCHCall is " + responseStatusCode);
															var RestorePredicted_ResponseData = new Buffer(responseData, 'base64').toString('ascii');
															var StatusCheck_payload =
															{
																"msgId": incomingdata.msgId,
																"jobId": incomingdata.jobId,
																"serviceName": incomingdata.serviceName,
																"status": 200,
																"statusId": RestorePredicted_ResponseData,
																"timesStamp": new Date().toISOString(),
																"userId": incomingdata.userId
															}
															ctx.setVariable("RestorePredicted_payload", StatusCheck_payload);
															//start calling queue api
															ilsctx.setVariable("exitStatus", "0");
															ilsctx.setVariable("exitDescription", session.parameters.ReceiveSuccessExitDescription);
															session.output.write(StatusCheck_payload);
															//end calling queue api 
														}
													});
												} else if (responseStatusCode == 400) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															ilsctx.setVariable("errorStatus", "400");
															logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
														} else {
															if (responseData == 'No updates') {
															}
															else {
																logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
																var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
																var task_payload = {
																	"msgId": incomingdata.msgId,
																	"jobId": incomingdata.jobId,
																	"serviceName": incomingdata.serviceName,
																	"status": responseStatusCode,
																	"message": RestorePredicted_ResponseData_Failure,
																	"timesStamp": new Date().toISOString()
																}
																ctx.setVariable("RestorePredicted_Failure", task_payload);
																//start calling queue api
																ilsctx.setVariable("exitStatus", responseStatusCode);
																ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
																ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
																var Queueurl = session.parameters.FailureMQURL;
																var test = PushingToQcall(Queueurl, task_payload);
																session.output.write(task_payload);
																//end calling queue api 
															}
														}
													});

												} else if (responseStatusCode == 409) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorStatus", "409");
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
															session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
														} else {
															var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
															ctx.setVariable("retry", 'yes');
															logger.debug("  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData));
															var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData);
															ctx.setVariable("ErrorTxt", ErrorTxt);
															session.output.write(incomingdata);
															ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
															ilsctx.setVariable("exitStatus", "409");
														}
													})
												} else if (responseStatusCode == 401) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorStatus", "401");
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
															session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
														} else {
															var errorinfo = "error  response 'errorinfo', details are : " + info + "; error info :" + error

															ctx.setVariable("retry", 'yes');
															logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + " is " + JSON.stringify(responseData));
															var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid 401 " + jobId + " is " + JSON.stringify(responseData);
															ctx.setVariable("ErrorTxt", ErrorTxt);
															session.output.write(incomingdata);
															ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
															ilsctx.setVariable("exitStatus", "401");

														}
													})
												} else if (responseStatusCode == 403) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															ilsctx.setVariable("errorStatus", "403");
															logger.error(" error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
															session.reject("error message while reading from omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is" + JSON.stringify(errorinfo));
														} else {
															var errorinfo = "error  response 'errorinfo', details are : " + info + "; error info :" + error

															ctx.setVariable("retry", 'yes');
															logger.error("OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData));
															var ErrorTxt = "OutageJobClosure_004  urlopen connect error with omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(responseData);
															ctx.setVariable("ErrorTxt", ErrorTxt);
															session.output.write(incomingdata);
															ilsctx.setVariable("exitDescription", new Buffer(responseData, 'base64').toString('ascii'));
															ilsctx.setVariable("exitStatus", "403");

														}
													})
												} else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + ", details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															ilsctx.setVariable("errorStatus", "401");
															logger.error("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
															session.reject("failure in reading message from  omsapijob_OutageJobClosure_Request JobPATCHCall post jobid " + jobId + " is " + JSON.stringify(errorinfo));
														} else {
															logger.debug(" response returned from omsapijob_OutageJobClosure_Request post call is " + responseStatusCode + " " + responseData);
															var RestorePredicted_ResponseData_Failure = new Buffer(responseData, 'base64').toString('ascii');
															var task_payload = {
																"msgId": incomingdata.msgId,
																"jobId": incomingdata.jobId,
																"serviceName": incomingdata.serviceName,
																"status": responseStatusCode,
																"message": RestorePredicted_ResponseData_Failure,
																"timesStamp": new Date().toISOString()
															}
															ctx.setVariable("RestorePredicted_Failure", task_payload);
															//start calling queue api
															ilsctx.setVariable("exitStatus", responseStatusCode);
															ilsctx.setVariable("exitDescription", session.parameters.ReceiveErrorExitDescription);
															ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
															var Queueurl = session.parameters.FailureMQURL;
															var test = PushingToQcall(Queueurl, task_payload);
															session.output.write(task_payload);
															//end calling queue api 
														}
													});

												}
											}
										});
									}
								}
							})
						} else if (responseStatusCode == 401) {
							//retry shoud be done
							//var AuthenticationError;
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//ctx.setVariable("AuthenticationResponse", error)
									var AuthenticationError = error.toString();
									ctx.setVariable("retry", 'yes');
									logger.error("OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request post is 401 " + AuthenticationError);
									var ErrorTxt = "OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request post is 401 " + AuthenticationError;
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ilsctx.setVariable("exitDescription", ErrorTxt);
									ilsctx.setVariable("exitStatus", "401");
								}
								else {
									///ctx.setVariable("AuthenticationResponseToStr", responseData.toString())
									var AuthenticationError = responseData.toString();
									ctx.setVariable("retry", 'yes');
									logger.error("OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request post is 401" + AuthenticationError);
									var ErrorTxt = "OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request post is 401 " + AuthenticationError;
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ilsctx.setVariable("exitDescription", ErrorTxt);
									ilsctx.setVariable("exitStatus", "401");
								}
							})
						} else if (responseStatusCode == 403) {
							//retry shoud be done
							//var AuthenticationError;
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var ForbiddenError = error.toString();
									ctx.setVariable("retry", 'yes');
									logger.error("OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request post is " + ForbiddenError);
									var ErrorTxt = "OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + " is " + ForbiddenError;
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ilsctx.setVariable("exitDescription", ErrorTxt);
									ilsctx.setVariable("exitStatus", "403");
								}
								else {
									///ctx.setVariable("AuthenticationResponseToStr", responseData.toString())
									var ForbiddenError = responseData.toString();
									ctx.setVariable("retry", 'yes');
									logger.error(" OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + " is " + ForbiddenError);
									var ErrorTxt = "OutageJobClosure_002 urlopen connect error with omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + " is " + ForbiddenError;
									ctx.setVariable("ErrorTxt", ErrorTxt);
									ilsctx.setVariable("exitDescription", ErrorTxt);
									ilsctx.setVariable("exitStatus", "403");
								}
							})
						} else {
							var errorinfo = "failure in getting response, details are : " + info
							// framing business failure message start
							var Failure_payload = {
								"serviceName": "Interface47",
								"message": response.reasonPhrase,
								"timesStamp": new Date().toISOString(),
								"status": responseStatusCode
							}
							if (incomingdata.msgId != undefined) { Failure_payload.msgId = incomingdata.msgId }
							if (incomingdata.jobId != undefined) { Failure_payload.jobId = incomingdata.jobId }
							var Queueurl = session.parameters.FailureMQURL;
							var test = PushingToQcall(Queueurl, Failure_payload);
							ilsctx.setVariable("exitDescription", errorinfo);
							ilsctx.setVariable("exitDestination", session.parameters.FailureMQURL);
							ilsctx.setVariable("exitStatus", responseStatusCode);
						}
					}
				});
			} catch (error) {
				var errorinfo = "OutageJobClosure_001 urlopen connect error from  omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + ", details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatus", "500");
				logger.error(" urlopen connect error from JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
				session.reject(" OutageJobClosure_001 urlopen connect error from  omsapijob_OutageJobClosure_Request JobGetapi for job id " + jobId + " is " + JSON.stringify(error));
			}
		}
	}
})

function PushingToQcall(url, Data) {
	var StandaloneMQurl = url;
	var payload = Data;
	var PushingToQueue = {
		target: StandaloneMQurl,
		data: payload
	};
	var PushingToQueueinfo = " TargetURL :" + PushingToQueue.target + "; Data :" + JSON.stringify(PushingToQueue.data) + ". ";
	try {
		urlopen.open(PushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "OutageJobClosure_003 error omsapijob_OutageJobClosure_Request while keeping message to queue , details are : " + PushingToQueueinfo + "; error info :" + error
				ctx.setVariable("retry", 'yes');
				logger.debug("error omsapijob_OutageJobClosure_Request while keeping message to queue " + StandaloneMQurl + " is " + errorinfo);
				var ErrorTxt = ("OutageJobClosure_003 error omsapijob_OutageJobClosure_Request while keeping message to queue " + StandaloneMQurl + " is " + errorinfo);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ilsctx.setVariable("exitDescription", errorinfo);
				ilsctx.setVariable("exitStatus", "500");
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							ctx.setVariable("retry", 'yes');
							logger.debug("error omsapijob_RestoreVerify_ProcessRequest while keeping message to queue is " + error);
							var ErrorTxt = ("OutageJobClosure_003 error omsapijob_OutageJobClosure_Request while keeping message to queue is " + error);
							ctx.setVariable("ErrorTxt", ErrorTxt);
							ilsctx.setVariable("exitDescription", ErrorTxt);
							ilsctx.setVariable("exitStatus", "500");
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					ctx.setVariable("retry", 'yes');
					logger.debug("response code for omsapijob_OutageJobClosure_Request " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
					var ErrorTxt = ("OutageJobClosure_005 response code for omsapijob_OutageJobClosure_Request " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
					ctx.setVariable("ErrorTxt", ErrorTxt);
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "OutageJobClosure_003 error omsapijob_OutageJobClosure_Request while keeping message to queue , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		ilsctx.setVariable("errorStatus", "500");
		logger.error("error omsapijob_OutageJobClosure_Request while keeping message to queue " + StandaloneMQurl + " is " + errorinfo);
		session.reject("OutageJobClosure_003 error omsapijob_OutageJobClosure_Request while keeping message to queue " + StandaloneMQurl + " is " + errorinfo);
	}
}
