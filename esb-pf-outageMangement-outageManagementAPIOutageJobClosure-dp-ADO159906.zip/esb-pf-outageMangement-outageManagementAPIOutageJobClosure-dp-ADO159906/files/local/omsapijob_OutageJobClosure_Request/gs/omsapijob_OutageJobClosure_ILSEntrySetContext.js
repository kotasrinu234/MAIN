var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var ILSctx = session.name('ILS') || session.createContext('ILS');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var incomingdata = incomingdata;
		var description = session.parameters.ReceiveEntrydescription;
		ILSctx.setVariable("description", description);
		var messageType = session.parameters.messageType;
		ILSctx.setVariable("messageType", messageType);
		var urlIn = sm.getVar('var://service/URL-in');
		ILSctx.setVariable("sourceUrl", urlIn);
		if (incomingdata.msgId === undefined || incomingdata.msgId === null || incomingdata.msgId === "") {
			ILSctx.setVariable('correlationID', " ")
		} else {
			ILSctx.setVariable('correlationID', incomingdata.msgId)
		}
		if(incomingdata.jobId === undefined || incomingdata.jobId === null || incomingdata.jobId === ""){
			ILSctx.setVariable('jobId', " ")
		}
		else{
			ILSctx.setVariable('jobId', incomingdata.jobId)
		}
		if(incomingdata.timesStamp === undefined || incomingdata.timesStamp === null || incomingdata.timesStamp === ""){
			ILSctx.setVariable('sourceEventTimestamp', " ")
		}
		else{
			ILSctx.setVariable('sourceEventTimestamp', incomingdata.timesStamp)
		}
		if(incomingdata.serviceName === undefined || incomingdata.serviceName === null || incomingdata.serviceName === ""){
			ILSctx.setVariable('caller', " ")
		}
		else{
			ILSctx.setVariable('caller', incomingdata.serviceName)
		}
		if(incomingdata.userId === undefined || incomingdata.userId === null || incomingdata.userId === ""){
			ILSctx.setVariable('callerUserId', " ")
		}
		else{
			ILSctx.setVariable('callerUserId', incomingdata.userId)
		}
	}
});
