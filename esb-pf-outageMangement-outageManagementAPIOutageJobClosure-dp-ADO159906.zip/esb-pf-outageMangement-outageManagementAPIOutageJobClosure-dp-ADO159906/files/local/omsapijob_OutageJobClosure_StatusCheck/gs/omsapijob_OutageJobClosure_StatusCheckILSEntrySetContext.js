var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var uniqueId = uuidv4();
var ilsctx = session.name('ILS') || session.createContext('ILS');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var incomingdata = incomingdata;
		var description = session.parameters.OOSCEntrydescription;
		ilsctx.setVariable("entrydescription", description);
		var messageType = session.parameters.messageType;
		ilsctx.setVariable("messageType", messageType);
		var urlIn = sm.getVar('var://service/URL-in');
		ilsctx.setVariable("sourceUrl", urlIn);
		ilsctx.setVariable('correlationID', uniqueId)
		if (incomingdata.data[0].id === undefined || incomingdata.data[0].id === null || incomingdata.data[0].id === "") {
			ilsctx.setVariable('jobId', " ")
		}
		else {
			ilsctx.setVariable('jobId', incomingdata.data[0].id)
		}
		if (incomingdata.data[0].displayID === undefined || incomingdata.data[0].displayID === null || incomingdata.data[0].displayID === "") {
			ilsctx.setVariable('displayID', " ")
		}
		else {
			ilsctx.setVariable('displayID', incomingdata.data[0].displayID)
		}
		if (incomingdata.data[0].createdAt === undefined || incomingdata.data[0].createdAt === null || incomingdata.data[0].createdAt === "") {
			ilsctx.setVariable('sourceEventTimestamp', " ")
		}
		else {
			ilsctx.setVariable('sourceEventTimestamp', incomingdata.data[0].createdAt)
		}
	}
});
