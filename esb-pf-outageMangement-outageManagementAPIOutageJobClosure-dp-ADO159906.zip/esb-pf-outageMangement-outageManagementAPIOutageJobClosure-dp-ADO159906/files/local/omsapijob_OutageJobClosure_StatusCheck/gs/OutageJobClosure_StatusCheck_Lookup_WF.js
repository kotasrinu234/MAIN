var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ilsctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("OutageJobClosure") || session.createContext("OutageJobClosure");
var logger = console.options({
	'category': 'all'
});
var lookupURL = session.parameters.lookupURL;
function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var uniqueId = uuidv4();
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + readAsJSONError);
		session.reject("Error in reading incoming data" + readAsJSONError);
	}
	else {
		var successdescription = session.parameters.SExitdescription;
		var failedescription = session.parameters.FExitdescription;
		ilsctx.setVariable("exitDestination", session.parameters.StatusCheckMQURL);
		var Url = session.parameters.OMSurl;
		var id = incomingdata.data[0].id;
		var status = incomingdata.data[0].status;
		var jobTypeID = incomingdata.data[0].jobTypeID;
		var Payload = {
			"lookupReq": { "type": [{ "name": "jobTypes.workflows", "status": status, "id": jobTypeID }] }
		};
		
		var LookupCall = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: Payload
		};
		session.output.write(Payload);
		var statusLookupInfo = " TargetURL :" + LookupCall.target + "; Method :" + LookupCall.method + "; Data :" + JSON.stringify(LookupCall.data) + ". ";
		try {
			urlopen.open(LookupCall, function(error, response) {
				if (error) {
					var errorinfo = "url connection error 'LookupCall', details are : " + statusLookupInfo + "; error info :" + error;
					ilsctx.setVariable("errorStatus", "500");
					ilsctx.setVariable("errordescription", errorinfo);
					logger.error(" urlopen connect error with LookupCall for jobtypeID " + jobTypeID + " is " + JSON.stringify(errorinfo));
					session.reject(" urlopen connect error with LookupCall for jobtypeID " + JSON.stringify(errorinfo));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'LookupCall', details are : " + statusLookupInfo + "; error info :" + error;
								ilsctx.setVariable("errorStatus", "500");
								ilsctx.setVariable("errordescription", errorinfo);
								logger.error(" failure in getting message from LookupCall for jobtypeID " + JSON.stringify(errorinfo));
								session.reject(" failure in getting message from LookupCall for jobtypeID " + JSON.stringify(errorinfo));
							} else {
								hm.response.statusCode = responseStatusCode;
								var lookupstatus;
								if (responseData.lookupRep.type[0].result == 0) {
									lookupstatus = responseData.lookupRep.type[0].status;
									var label = responseData.lookupRep.type[0].label;
									if (label === 'Completed' || label === 'Cancelled' || label === 'Cancel') {

									}
									else {
										var lookupMessage = { "lookupReq": { "type": [{ "name": "jobTypes.workflows", "id": jobTypeID, "label": "Completed" }] } }
										var LookupServiceResponse = {
											target: lookupURL,
											method: 'POST',
											contentType: 'application/json',
											data: lookupMessage
										};
										var labelLookupinfo = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
										try {
											urlopen.open(LookupServiceResponse, function(error, response) {
												if (error) {
													var errorinfo = "url connection error 'LookupServiceResponse', details are : " + info + "; error labelLookupinfo :" + error;
													ilsctx.setVariable("errordescription", errorinfo);
													ilsctx.setVariable("errorStatus", "500");
													logger.error(" urlopen connect error with LookupCall for jobtypeID " + jobTypeID + " is " + JSON.stringify(errorinfo));
													session.reject(" urlopen connect error with LookupCall for jobtypeID " + JSON.stringify(errorinfo));
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response 'LookupServiceResponse', details are : " + labelLookupinfo + "; error info :" + error
																ilsctx.setVariable("errordescription", errorinfo);
																ilsctx.setVariable("errorStatus", "500");
																logger.error(" failure in getting message from LookupCall for jobtypeID " + JSON.stringify(errorinfo));
																session.reject(" failure in getting message from LookupCall for jobtypeID " + JSON.stringify(errorinfo));
															} else {
																hm.response.statusCode = responseStatusCode;

																var lookupstatus;
																if (responseData.lookupRep.type[0].result == 0) {
																	lookupstatus = responseData.lookupRep.type[0].status;
																	ctx.setVariable("lookupstatus", lookupstatus);
																	//5.start Call POST  /api/v1/ServiceType/Electric/Job/{jobId}/WorkFlow {for example if the status is 8}
																	var JobWorkflow_url = Url + '/oms/external/api/v1/ServiceType/Electric/Job/' + id + '/WorkFlow';
																	var payload = lookupstatus;
																	var JobWorkflow_Call = {
																		target: JobWorkflow_url,
																		sslClientProfile: 'OMS_Client_Profile',
																		method: 'POST',
																		contentType: 'application/json',
																		headers: {
																			'osiApiToken': session.parameters.multipurpose_apiToken
																		},
																		data: payload
																	};
																	var incPayload = {
																		status : lookupstatus
																	}
																	session.output.write(incPayload);
																	var wfinfo = " TargetURL :" + JobWorkflow_Call.target + "; Method :" + JobWorkflow_Call.method + "; Data :" + JSON.stringify(JobWorkflow_Call.data) + ". ";
																	try {
																		urlopen.open(JobWorkflow_Call, function(error, response) {
																			if (error) {
																				var errorinfo = "urlopen connect error from omsapijob_OutageJobClosure_StatusCheck JobWorkflow_Call for job id " + id + ", details are : " + wfinfo + "; error info :" + error
																				ilsctx.setVariable("errorStatus", "500");
																				ilsctx.setVariable("errordescription", errorinfo);
																				logger.error(" urlopen connect error from omsapijob_OutageJobClosure_StatusCheck JobWorkflow_Call for job id " + id + " is " + JSON.stringify(errorinfo));
																				session.reject(" urlopen connect error from omsapijob_OutageJobClosure_StatusCheck JobWorkflow_Call for job id " + id + " is " + JSON.stringify(errorinfo));
																			} else {
																				var responseStatusCode = response.statusCode;
																				var reasonPhrase = response.reasonPhrase;
																				if (responseStatusCode == 200 || responseStatusCode == 202) {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error message while reading response from POST jobworkflow for job id " + id + ", details are : " + wfinfo + "; error info :" + error
																							ilsctx.setVariable("errordescription", errorinfo);
																							ilsctx.setVariable("errorStatus", "500");
																							logger.error(" error message while reading response from POST jobworkflow for job id " + id + " is " + JSON.stringify(errorinfo));
																							session.reject(" error message while reading response from omsapijob_OutageJobClosure_StatusCheck job id " + id + " is " + JSON.stringify(errorinfo));
																						} else {
																							hm.response.statusCode = responseStatusCode;
																							hm.response.statusCode = responseStatusCode;
																							ilsctx.setVariable("errorStatus", "0");
																							ilsctx.setVariable("description", successdescription);
																						}
																					})
																				} else if (responseStatusCode == 401) {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var AuthenticationError = error.toString();
																							var errorinfo = "OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError + ", details are : " + wfinfo + "; error info :" + error
																							ilsctx.setVariable("errordescription", errorinfo);
																							ilsctx.setVariable("errorStatus", "401");
																							logger.error("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError);
																							session.reject("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError)
																						}
																						else {
																							var AuthenticationError = responseData.toString();
																							var errorinfo = "OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError + ", details are : " + wfinfo + "; errorresponseinfo :" + responseData
																							ilsctx.setVariable("errordescription", errorinfo);
																							ilsctx.setVariable("errorStatus", "401");
																							logger.error("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError);
																							session.reject("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError);
																						}
																					})
																				} else if (responseStatusCode == 403) {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var AuthenticationError = error.toString();
																							var errorinfo = "OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError + ", details are : " + wfinfo + "; error info :" + error
																							ilsctx.setVariable("errordescription", errorinfo);
																							ilsctx.setVariable("errorStatus", "403");
																							logger.error("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError);
																							session.reject("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError);
																						}
																						else {
																							var AuthenticationError = responseData.toString();
																							var errorinfo = "OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError + ", details are : " + wfinfo + "; errorresponseinfo :" + responseData
																							ilsctx.setVariable("errordescription", errorinfo);
																							ilsctx.setVariable("errorStatus", "403");
																							session.output.write(incomingdata);
																							logger.error("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError);
																							session.reject("OutageJobClosure_008 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck POST workflow for job id " + id + " is " + AuthenticationError);
																						}
																					})
																				} else if (responseStatusCode == 400) {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error message while reading response from POST jobworkflow for job id " + id + " , details are : " + wfinfo + "; error info :" + error;
																							ilsctx.setVariable("errorStatus", "500");
																							ilsctx.setVariable("errordescription", errorinfo);
																							logger.error(" error message while reading response from POST jobworkflow for job id " + id + " is " + JSON.stringify(errorinfo));
																							session.reject(" error message while reading response from omsapijob_OutageJobClosure_StatusCheck job id " + id + " is " + JSON.stringify(errorinfo));
																						} else {
																							// framing failure message start
																							var Failure_payload = {
																								"msgId": uniqueId,
																								"serviceName": 'JobClosure',
																								"jobId": id,
																								"status": responseStatusCode,
																								"message": reasonPhrase,
																								"timesStamp": new Date().toISOString()
																							}
																							ilsctx.setVariable("errorStatus", responseStatusCode);
																							ilsctx.setVariable("description", failedescription);
																							var Queueurl = session.parameters.StatusCheckMQURL;
																							var test = PushingToQcall(Queueurl, Failure_payload);
																							// session.output.write(task_payload);
																							//end calling queue api					
																						}
																					});
																				}
																				else {
																					// framing failure message start
																					var Failure_payload = {
																						"msgId": uniqueId,
																						"serviceName": 'JobClosure',
																						"jobId": id,
																						"status": responseStatusCode,
																						"message": reasonPhrase,
																						"timesStamp": new Date().toISOString()
																					}
																					//start calling queue api
																					ilsctx.setVariable("errorStatus", responseStatusCode);
																					ilsctx.setVariable("description", failedescription);
																					var Queueurl = session.parameters.StatusCheckMQURL;
																					var test = PushingToQcall(Queueurl, Failure_payload);
																					// session.output.write(task_payload);
																					//end calling queue api
																				}
																			}
																		})
																	} catch (err) {
																		var errorinfo = "url connection error 'JobWorkflow_Call', details are : " + wfinfo + "; error info :" + err;
																		ilsctx.setVariable("errorStatus", "500");
																		ilsctx.setVariable("errordescription", errorinfo);
																		logger.error(" urlopen connect error from omsapijob_OutageJobClosure_StatusCheck JobWorkflow_Call for job id " + id + " is " + JSON.stringify(errorinfo));
																		session.reject("OutageJobClosure_011 urlopen connect error from omsapijob_OutageJobClosure_StatusCheck JobWorkflow_Call for job id " + id + " is " + JSON.stringify(errorinfo));
																	}
																	// 5 end
																} else {
																	var errorinfo = "lookup service result code for LookupCall for jobtypeID  " + jobTypeID + " is " + responseData.lookupRep.type[0].result + ", details are : " + labelLookupinfo + "; error info :" + error
																	logger.error(" lookup service result code for LookupCall for jobtypeID  " + jobTypeID + " is " + responseData.lookupRep.type[0].result);
																	ilsctx.setVariable("errorStatus", "500");
																	ilsctx.setVariable("errordescription", errorinfo);
																	session.reject(" lookup service result code for LookupCall for jobtypeID  " + jobTypeID + " is " + responseData.lookupRep.type[0].result);
																}// lookup end;
															}
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading error response from lookupservice  is " + responseStatusCode + ", details are : " + statusLookupInfo + "; error info :" + error;
																ilsctx.setVariable("errorStatus", "500");
																ilsctx.setVariable("errordescription", errorinfo);
																logger.error(" failure in reading error response from lookupservice  is " + statusLookupInfo + " is " + responseStatusCode);
																session.reject("failure in reading error response from lookupservice  is " + statusLookupInfo + " is " + responseStatusCode);
															}
															else {
																var errorinfo = "error response from lookup service is " + responseStatusCode + ", details are : " + statusLookupInfo + "; errorresponseinfo :" + responseData;
																ilsctx.setVariable("errorStatus", responseStatusCode);
																ilsctx.setVariable("errordescription", errorinfo);
																logger.error(" error response from lookup service is " + statusLookupInfo + " is " + responseStatusCode);
																session.reject("error response from lookup service is " + statusLookupInfo + " is " + responseStatusCode);
															}
														})
													}
												}
											});
										} catch (err) {
											var errorinfo = "url connection error 'LookupServiceResponse', details are : " + labelLookupinfo + "; error info :" + err;
											ilsctx.setVariable("errorStatus", "500");
											ilsctx.setVariable("errordescription", errorinfo);
											logger.error(" urlopen connect error with LookupCall for jobtypeID " + jobTypeID + " is " + JSON.stringify(errorinfo));
											session.reject(" urlopen connect error with LookupCall for jobtypeID " + JSON.stringify(errorinfo));
										}
									}
									ctx.setVariable("lookupstatus", lookupstatus);
								} else {
									var errorinfo = "lookup service result code for LookupCall for jobtypeID  " + jobTypeID + " is " + responseData.lookupRep.type[0].result + ", details are : " + statusLookupInfo;
									logger.error(" lookup service result code for LookupCall for jobtypeID  " + jobTypeID + " is " + responseData.lookupRep.type[0].result);
									ilsctx.setVariable("errordescription", errorinfo);
									ilsctx.setVariable("errorStatus", "500");
									session.reject(" lookup service result code for LookupCall for jobtypeID  " + jobTypeID + " is " + responseData.lookupRep.type[0].result);
								}
							}
						});
					}
					else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading error response from lookupservice  is " + responseStatusCode + ", details are : " + statusLookupInfo + "; error info :" + error;
								ilsctx.setVariable("errorStatus", "500");
								ilsctx.setVariable("errordescription", errorinfo);
								logger.error(" failure in reading error response from lookupservice  is " + statusLookupInfo + " is " + responseStatusCode);
								session.reject("failure in reading error response from lookupservice  is " + statusLookupInfo + " is " + responseStatusCode);
							}
							else {
								var errorinfo = "error response from lookup service is " + responseStatusCode + ", details are : " + statusLookupInfo + "; errorresponseinfo :" + responseData;
								ilsctx.setVariable("errorStatus", responseStatusCode);
								ilsctx.setVariable("errordescription", errorinfo);
								logger.error(" error response from lookup service is " + statusLookupInfo + " is " + responseStatusCode);
								session.reject("error response from lookup service is " + statusLookupInfo + " is " + responseStatusCode);
							}
						})
					}
				}
			});
		}
		catch (error) {
			var errorinfo = "url connection error 'LookupCall', details are : " + statusLookupInfo + "; error info :" + error;
			ilsctx.setVariable("errorStatus", "500");
			ilsctx.setVariable("errordescription", errorinfo);
			logger.error(" urlopen connect error with LookupCall for jobtypeID " + jobTypeID + " is " + JSON.stringify(errorinfo));
			session.reject(" urlopen connect error with LookupCall for jobtypeID " + JSON.stringify(errorinfo));
		}
	}
});
function PushingToQcall(url, Data) {
	var StandaloneMQurl = url;
	var payload = Data;
	var PushingToQueue = {
		target: StandaloneMQurl,
		data: payload
	};
	var PushingToQueueInfo = " TargetURL :" + PushingToQueue.target + "; Data :" + JSON.stringify(PushingToQueue.data) + ". ";
	try {
		urlopen.open(PushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error 'PushingToQcall', details are : " + PushingToQueueInfo + "; error info :" + error
				logger.error("error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue " + StandaloneMQurl + " is " + errorinfo);
				ilsctx.setVariable("errorStatus", "500");
				ilsctx.setVariable("errordescription", errorinfo);
				session.reject("url connection error 'PushingToQcall'");
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							ctx.setVariable("retry", 'yes');
							logger.error("OutageJobClosure_009 error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue is " + readError);
							var errorinfo = ("OutageJobClosure_009 error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue is " + PushingToQueueInfo + readError);
							ilsctx.setVariable("errordescription", errorinfo);
							ilsctx.setVariable("errorStatus", "500");
							session.reject("OutageJobClosure_009 error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue is " + readError);

						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					logger.error("response code for omsapijob_OutageJobClosure_StatusCheck " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
					var errorinfo = ("OutageJobClosure_009 response code for omsapijob_OutageJobClosure_StatusCheck " + StandaloneMQurl + "details are : " + PushingToQueueInfo + " urlopen.open error [MQRC=" + mqrc + "]");
					ilsctx.setVariable("errordescription", errorinfo);
					ilsctx.setVariable("errorStatus", "500");
					session.reject("response code for omsapijob_OutageJobClosure_StatusCheck " + StandaloneMQurl + " urlopen.open error [MQRC=" + mqrc + "]");
				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error 'LookupServiceResponse', details are : " + PushingToQueueInfo + "; error info :" + err;
		ilsctx.setVariable("errorStatus", "500");
		ilsctx.setVariable("errordescription", errorinfo);
		logger.error("error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue " + StandaloneMQurl + " is " + errorinfo);
		session.reject("OutageJobClosure_009 error omsapijob_OutageJobClosure_StatusCheck while keeping message to queue " + StandaloneMQurl + " is " + errorinfo);
	}
}
