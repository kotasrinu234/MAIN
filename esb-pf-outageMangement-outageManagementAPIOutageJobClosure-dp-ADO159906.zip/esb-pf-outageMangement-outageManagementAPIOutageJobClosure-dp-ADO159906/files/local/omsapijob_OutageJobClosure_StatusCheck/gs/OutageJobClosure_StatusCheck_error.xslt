<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:dp="http://www.datapower.com/extensions" 
xmlns:dpconfig="http://www.datapower.com/param/config"
extension-element-prefixes="dp dpconfig"
exclude-result-prefixes="dp dpconfig">
	<xsl:template match="/">
		<xsl:variable name="encodedCredential" select="dp:http-request-header('Authorization')"/>
		<xsl:variable name="uname" select="substring-before(dp:decode(substring($encodedCredential,'7'),'base-64'),':')"/>
		<xsl:variable name="bindPWD" select="substring-after(dp:decode(substring($encodedCredential,'7'),'base-64'),':')"/>
		<xsl:variable name="errorMsg" select="dp:variable('var://context/ILS/errordescription')"/>
		<xsl:variable name="errorDetail" select="dp:variable('var://service/error-message')"/>
		<dp:set-variable name="'var://context/current/user'" value="$uname" />
		<xsl:choose>
		<xsl:when test="contains($errorDetail, 'Rejected by policy')">
		<dp:set-variable name="'var://context/ILS/errordescription'" value="concat('OutageJobClosure_015 : Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : ', $uname)"/>
	<xsl:message dp:type="all" dp:priority="error">OutageJobClosure_015 : Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : <xsl:value-of select="$uname"/>   </xsl:message>
		</xsl:when>
		<xsl:when test="$errorMsg">
		<dp:set-variable name="'var://context/ILS/errordescription'" value="$errorMsg"/>
		</xsl:when>
		<xsl:otherwise>
		<dp:set-variable name="'var://context/ILS/errordescription'" value="$errorMsg"/>
		</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
