var ctx = session.name("avja")|| session.createContext("avja");
var TokenValue=session.parameters.TokenValue;

var urlopen = require('urlopen');
var logger = console.options({'category':'all'});


function callURL(url, method, myctx,payload) {
	var options = {
        target: url,
        method: method,
        headers: {
            "osiApiToken": TokenValue
        },
        contentType: "application/json",
        sslClientProfile: "avja_createJob_Client_Profile"
    };
    if (method == "POST" || method=="PATCH") {
        options.data = payload;
    }
 urlopen.open(options, function(error, response) {
        if (error) {
            // an error occurred during reading the file
			throw error;
        } else {
            var responseStatusCode = response.statusCode;
			 var ctx = session.name("avja")|| session.createContext("avja");
             ctx.setVariable(myctx+"_responseStatusCode", responseStatusCode);
				ctx.setVariable(myctx+"_response", response);
					
            if (responseStatusCode == 200) {
				response.readAsJSON(function(error,data){
				if(error){
					logger.error("omsfoa_047 Error in reading response data");
					throw error;
				}else{
				 var ctx = session.name("avja")|| session.createContext("avja");
				 ctx.setVariable(myctx + '_response',data);	
				}
			});
			}else{
			  response.readAsBuffer(function(error, responseData) {
			     if (error) {
                         logger.error("failure in reading message" + JSON.stringify(error));
                        } else {
							var ctx = session.name("avja")|| session.createContext("avja");
							ctx.setVariable(myctx + '_buffer_response',""+responseData);
                         logger.error("response received with responseStatusCode "+responseStatusCode+" "+ responseData);
						 var responseDataStr = ""+responseData;
						 ctx.setVariable(myctx + '_buffer_response2',responseDataStr);
						 if (responseStatusCode == 400 && responseDataStr !=='No updates') {
							ctx.setVariable("customErrorCode", '400');
							ctx.setVariable("customErrorMessage", 'Bad Request');
							ctx.setVariable("customReasonMessage", 'Bad Request');
							session.reject("Bad Request");
							}
			     }
			  });
			  
			   			
			if(responseStatusCode == 403){
				ctx.setVariable("customErrorCode", '403');
				ctx.setVariable("customErrorMessage", 'Forbidden');
				ctx.setVariable("customReasonMessage", 'Forbidden');
				session.reject("Forbidden");
			}else if(responseStatusCode==404){
				ctx.setVariable("customErrorCode", '404');
				ctx.setVariable("customErrorMessage", 'No Records Found');
				ctx.setVariable("customReasonMessage", 'No Records Found');
				session.reject("No Records Found");
			}else if(responseStatusCode==500){
				ctx.setVariable("customErrorCode", '500');
				ctx.setVariable("customErrorMessage", 'Server Error');
				ctx.setVariable("customReasonMessage", 'Server Error');
				session.reject("Server Error");
			}
		}
}
 });
}
module.exports = callURL;