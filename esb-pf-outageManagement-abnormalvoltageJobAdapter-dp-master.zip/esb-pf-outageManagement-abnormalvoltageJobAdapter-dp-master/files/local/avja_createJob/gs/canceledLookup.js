var ctx = session.name("avja")|| session.createContext("avja");
var doLookup = require('./avja_lookup.js');
var internalIdJobIDMap = ctx.getVariable("internalIdJobIDMap");
var jobIDArr = ctx.getVariable("jobIDArr");
var njobIDArr = ctx.getVariable("jobIDArr");
var omsUrl = session.parameters.omsExternalURL;
var callURL = require('./callUrl.js');
var workflowLabel = session.parameters.workflowLabel;
var wfcIdArr = new Array();
var origjobIdArr = ctx.getVariable("origjobIdArr");
var origjobIdArrString = origjobIdArr.join('_');
ctx.setVariable("origjobIdArrString", origjobIdArrString);
var eventType = ctx.getVariable("eventType");
var internalIdJobIDMap = ctx.getVariable("internalIdJobIDMap");
var internalIdNetIDArr = ctx.getVariable("internalIdNetIDArr");


function getKeyByValue(object, value) {
  return Object.keys(object).find(key => object[key] === value);
}

function removeDuplicates(arr) {
return arr.filter((item,
index) => arr.indexOf(item) === index);
}


/* var eventType="";
if(inputJobType === 'HV_SUBSTATION'){
	eventType = "HIGHVOLT"
}else{
	eventType = "LOWVOLT";
} */

function getNetId(displayId){
	
var netId='';
var dispId='';
for(var i=0; i< internalIdNetIDArr.length; i++){
    if(internalIdNetIDArr[i].dispId === displayId){
        netId= internalIdNetIDArr[i].netId;
    }
}
for(var i=0; i< internalIdNetIDArr.length; i++){
    if(internalIdNetIDArr[i].dispId !=displayId && internalIdNetIDArr[i].netId=== netId){
        dispId= internalIdNetIDArr[i].dispId;
		break;
    }
}
return dispId;
	
}





jobIDArr =removeDuplicates(jobIDArr);

for(var i=0; i<jobIDArr.length;i++){
						ctx.setVariable('disValue_'+i,origjobIdArrString+'_'+internalIdJobIDMap[jobIDArr[i]]);

if(jobIDArr[i]!=null && internalIdJobIDMap[jobIDArr[i]] != null && !origjobIdArrString.includes(internalIdJobIDMap[jobIDArr[i]]) ){
var jobTypeWFID = ctx.getVariable('jobtypeWF_'+jobIDArr[i]+'_lookup')[0].id;
var jobTypeWFLabel = ctx.getVariable('jobtypeWF_'+jobIDArr[i]+'_lookup')[0].label;
ctx.setVariable("jobTypeWFID",jobTypeWFID);
ctx.setVariable("jobTypeWFLabel",jobTypeWFLabel);
//if(jobTypeWFLabel ==='New' || jobTypeWFLabel ==='In Progress' || jobTypeWFLabel ==='Pending'){
if(workflowLabel.includes(jobTypeWFLabel)){
						wfcIdArr.push(jobIDArr[i]);
						var typeArr = new Array();
						var jobTypeIdStatusReq = {};
						jobTypeIdStatusReq.name = "jobTypes.workflows";
						jobTypeIdStatusReq.id = jobTypeWFID;
						jobTypeIdStatusReq.label = 'CANCELED';
						typeArr.push(jobTypeIdStatusReq);
						doLookup(typeArr, 'jobtypeWFC_'+jobIDArr[i]);
}else{
	/* var comments = "A HIGHER LEVEL "+eventType +" CIRCUIT EVENT HAS BEEN CREATED,  EVENT NUMBER "+ internalIdJobIDMap[jobIDArr[i]] +" ADDITIONAL TROUBLE SHOOTING MAY BE REQUIRED."
	var remarks = { "customFieldValues": {"Remarks": comments}};
	var remarksURL = omsUrl+"/v1/ServiceType/Electric/Job/"+jobIDArr[i];
	callURL(remarksURL,"PATCH","remarks",remarks); */
	
	
	var comments = "A HIGHER LEVEL "+eventType +" CIRCUIT EVENT HAS BEEN CREATED,  EVENT NUMBER "+ getNetId(internalIdJobIDMap[jobIDArr[i]]) +" ADDITIONAL TROUBLE SHOOTING MAY BE REQUIRED."
	var json = { "comment": comments};
	var remarksURL = omsUrl+"/v1/ServiceType/Electric/Job/"+jobIDArr[i]+'/Comment';
	callURL(remarksURL,"POST","comments",json);

}

}

}

ctx.setVariable("wfcIdArr",wfcIdArr );