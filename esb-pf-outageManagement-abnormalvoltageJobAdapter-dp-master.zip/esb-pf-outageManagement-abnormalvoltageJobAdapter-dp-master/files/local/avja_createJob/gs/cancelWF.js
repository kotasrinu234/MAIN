var ctx = session.name("avja")|| session.createContext("avja");
var callURL = require('./callUrl.js');
var omsUrl = session.parameters.omsExternalURL;
var jobIDArr = ctx.getVariable("wfcIdArr");
var origjobIdArr = ctx.getVariable("origjobIdArr");
var origjobIdArrString = origjobIdArr.join('_');
var internalIdJobIDMap = ctx.getVariable("internalIdJobIDMap");

function removeDuplicates(arr) {
return arr.filter((item,
index) => arr.indexOf(item) === index);
}
 
function getKeyByValue(object, value) {
  return Object.keys(object).find(key => object[key] === value);
}

/* var eventType="";
if(inputJobType === 'HV_SUBSTATION'){
	eventType = "HIGHVOLT"
}else{
	eventType = "LOWVOLT";
} */

jobIDArr =removeDuplicates(jobIDArr);

for(var i=0; i<jobIDArr.length;i++){
	if(jobIDArr[i]!=null && internalIdJobIDMap[jobIDArr[i]] != null && !origjobIdArrString.includes(internalIdJobIDMap[jobIDArr[i]]) ){
		var jobTypeWFCStatus = ctx.getVariable('jobtypeWFC_'+jobIDArr[i]+'_lookup')[0].status;
		var postUrl = omsUrl+ "/v1/ServiceType/Electric/Job/"+jobIDArr[i]+"/WorkFlow"
		callURL(postUrl,"POST","CancelJob",jobTypeWFCStatus);
	}
}



