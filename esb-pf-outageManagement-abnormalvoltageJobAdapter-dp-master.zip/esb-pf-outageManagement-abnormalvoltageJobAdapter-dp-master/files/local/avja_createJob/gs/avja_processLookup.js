var urlopen = require('urlopen');
var ctx = session.name("avja")|| session.createContext("avja");

var doLookup = require('./avja_lookup.js');
var getOMSRespArr=ctx.getVariable('getOMSRespArr');
var inputArr=ctx.getVariable('inputArray');

var jobIDArr = new Array();
var internalIdJobIDMap = {};
var internalIdNetIDArr = new Array();
var json={};
			
            for (var i = 0; i < inputArr.length; i++) {
				for (var j=0; j< getOMSRespArr.length; j++){
				if(inputArr[i].xfmr === getOMSRespArr[j].networkModelExternalID){
					ctx.setVariable('matchValue_'+j,inputArr[i].xfmr+'_'+getOMSRespArr[j].networkModelExternalID);
						var typeArr = new Array();

						var jobTypeID = getOMSRespArr[j].jobTypeID
						var id = getOMSRespArr[j].id
						jobIDArr.push(getOMSRespArr[j].id);
						internalIdJobIDMap[id]=getOMSRespArr[j].displayID;
						json={};
						json.intId = getOMSRespArr[j].id;
						json.netId = getOMSRespArr[j].networkModelExternalID;
						json.dispId = getOMSRespArr[j].displayID
						internalIdNetIDArr.push(json);
						ctx.setVariable("internalIdNetIDArr", internalIdNetIDArr);
						var status = getOMSRespArr[j].status
						var jobTypeIdStatusReq = {};
						jobTypeIdStatusReq.name = "jobTypes.workflows";
						jobTypeIdStatusReq.id = jobTypeID;
						jobTypeIdStatusReq.status = status;
						typeArr.push(jobTypeIdStatusReq);
						doLookup(typeArr, 'jobtypeWF_'+id);
					}
					
				}
            }
			ctx.setVariable("jobIDArr",jobIDArr);
			
			ctx.setVariable("internalIdJobIDMap",internalIdJobIDMap);
			
