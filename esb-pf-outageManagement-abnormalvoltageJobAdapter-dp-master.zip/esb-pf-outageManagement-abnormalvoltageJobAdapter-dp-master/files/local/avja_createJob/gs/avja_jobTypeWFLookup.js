var ctx = session.name("avja")|| session.createContext("avja");
var doLookup = require('./avja_lookup.js');
var logger = console.options({
	'category': 'all'
});


var jobtypeRespArr = ctx.getVariable('jobTypeResp_lookup');
var wfId = jobtypeRespArr[0].id;

var typeArr = new Array();	
var jobTypeWFReq = {};
jobTypeWFReq.name="jobTypes.workflows";
jobTypeWFReq.id=wfId;
typeArr.push(jobTypeWFReq);
doLookup(typeArr,"jobTypeWFResp");