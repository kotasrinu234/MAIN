var ctx = session.name("avja")|| session.createContext("avja");
var ctx1 = session.name("ILS")|| session.createContext("ILS");
var doLookup = require('./avja_lookup.js');
var logger = console.options({
	'category': 'all'
});

var jobTypeLabel = '';
var jobType = ctx1.getVariable('jobType');
if((jobType== 'HV_SUBSTATION') || (jobType== 'HV_TRANSFORMER')){
 jobTypeLabel ='HIGH VOLTAGE';
} else {
 jobTypeLabel ='LOW VOLTAGE';
}
var typeArr = new Array();	
var jobTypeReq = {};
jobTypeReq.name="jobTypes";
jobTypeReq.label=jobTypeLabel;
typeArr.push(jobTypeReq);
doLookup(typeArr,"jobTypeResp");