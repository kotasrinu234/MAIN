var ctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlIn = sm.getVar('var://service/URL-in');
var logger = console.options({
	'category': 'all'
});


/* function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }

var correlationId = uuidv4(); */
var messageType = session.parameters.messageType;
var interfaceName = session.parameters.interfaceName;
var exitDescription = session.parameters.exitDescription;
var entryDescription = session.parameters.entryDescription;
var sourceUrl = session.parameters.sourceUrl;
var retryCount = '-1';
var jobType;


ctx.setVariable('messageType', messageType);
ctx.setVariable('interfaceName', interfaceName);
ctx.setVariable('exitStatus', '0');
ctx.setVariable('sourceUrl', sourceUrl);
//ctx.setVariable('exitDestination', urlIn);
ctx.setVariable('exitDescription', exitDescription);
ctx.setVariable('entryDescription', entryDescription);

session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

         
			var correlationId =incomingData.messageID;
			var jobType =incomingData.jobType;
/* 			var description ='';
			 if (jobType == "HV_SUBSTATION" )
			 {
                description = "Request for low/high voltage job creation(Circuit)"
            } else {
                description = "Request for low/high voltage job creation(Transformer)"
            } */


		var date = new Date();
		var sourceEventTimestamp = date.toISOString();
		
		
		ctx.setVariable("jobType", jobType);
		ctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		ctx.setVariable("entryDescription", entryDescription);
ctx.setVariable('correlationId', correlationId);
	
		
		

	}
});