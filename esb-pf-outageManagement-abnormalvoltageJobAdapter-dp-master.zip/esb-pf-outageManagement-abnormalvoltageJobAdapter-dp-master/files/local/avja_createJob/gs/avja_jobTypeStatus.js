var ctx = session.name("avja")|| session.createContext("avja");
var doLookup = require('./avja_lookup.js');
var logger = console.options({
	'category': 'all'
});

var jobTypeWFRespArr = ctx.getVariable('jobTypeWFResp_lookup');

var labels = '';
for(var i=0; i<jobTypeWFRespArr.length; i++){
if((jobTypeWFRespArr[i].label != 'Completed' && jobTypeWFRespArr[i].label != 'Archived' && jobTypeWFRespArr[i].label != 'Canceled') && !(labels.includes(jobTypeWFRespArr[i].label))){
	labels = labels + jobTypeWFRespArr[i].label + ',';
}
}
labels = labels.substring(0,labels.length -1).toUpperCase();
labels = labels.split(' ').join("%20");

ctx.setVariable('labels', labels);

