var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var OMS = session.parameters.omsExternalURL;
var logger = console.options({
    'category': 'all'
});
var TokenValue = session.parameters.TokenValue;
var ctx = session.name("avja")|| session.createContext("avja");
var lookUpURL = session.parameters.lookUpURL;
var failedArr = new Array();
var array = new Array();
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
        
        if ((OMS == undefined) || (OMS == '') || (OMS == null)) {
            logger.error("OMSUrl is missing" + JSON.stringify(error));
            session.reject("OMSUrl is missing");
        } else {
            var data = incomingdata.data;
            
            for (var i = 0; i < data.length; i++) {
                var object = {};
                
                object.xfmr = data[i].xfmr;
                object.deviceID = data[i].deviceID;
                if (incomingdata.jobType == 'HV_TRANSFORMER' || incomingdata.jobType == 'LV_TRANSFORMER') {
                    object.xfmr = data[i].xfmr;
					 }
                array.push(object);
            }
ctx.setVariable("inputArray",array);
           
            var jobType;
            if (incomingdata.jobType == "HV_TRANSFORMER" || incomingdata.jobType == "HV_SUBSTATION") {
                jobType = "HIGH%20VOLTAGE"
            } else {
                jobType = "LOW%20VOLTAGE"
            }
			
			var eventType="";
if(incomingdata.jobType == "HV_SUBSTATION"){
	       eventType = "HIGHVOLT"
     }else{
	eventType = "LOWVOLT";
}

ctx.setVariable("eventType",eventType); 

    ctx.setVariable("jobType",jobType);    
            var take = 1000;
			var skip = 0;
            ctx.setVariable("take",take);  
ctx.setVariable("skip",skip); 			
                var getOMSUrl = OMS + '/ServiceType/Electric/Job/Query/Params?jobTypes=' + jobType + '&skip=' + skip + '&take=' + take +  '&historical=false&includeFields=id,displayID,jobTypeID,status,networkModelExternalID';
                //getURLResponse(getOMSUrl, 'getOMS');
				getDataFn(getOMSUrl, skip, take);
				//var resArray = new Array();
				
            
	}}
})

function getDataFn(getOMSUrl, skip, take) {
                var OMSCall = {
                    target: getOMSUrl,
                    sslClientProfile: 'avja_createJob_Client_Profile',
                    method: 'GET',
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': TokenValue
                    }
                };
				 var resArray = new Array();
                urlopen.open(OMSCall, function(error, response) {
					var jobType =ctx.getVariable("jobType");
				
                    if (error) {
                        logger.error("avja_001 urlopen connect error with job params oms api get" + JSON.stringify(error));
                        session.reject("avja_001 urlopen connect error with job params oms api get" + JSON.stringify(error))
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    logger.error("avja_002 urlopen connect error with oms job params " + JSON.stringify(error));
									session.reject("avja_002 urlopen connect error with oms job params " + JSON.stringify(error));
                                } else {
                                   // if (type == 'duplicateOMS') {
                                        var totalWithHidden = responseData.totalWithHidden;
                                        var total = responseData.total;
                                        resArray = [...resArray, ...responseData.data]
										ctx.setVariable("getOMSRespArr",resArray);
                                        var temp = skip + take;
                                        if (temp < totalWithHidden) {
                                            skip = skip + 1000;
                                            getOMSUrl = OMS + '/ServiceType/Electric/Job/Query/Params?jobTypes=' + jobType +  '&skip=' + skip + '&take=' + take + '&historical=false&includeFields=id,displayID,jobTypeID,status,networkModelExternalID';
                                            getDataFn(getOMSUrl, skip, take);
                                        }
                                    //}
                                }
                            })
                        } else {
				response.readAsBuffer(function(error, errorresponseData) {
					if (error) {
						logger.error("failure in reading message from job params OMS call " + JSON.stringify(error));
						session.reject("failure in reading message from job params OMS call");
					} else {
						hm.current.statusCode = responseStatusCode;
						logger.error("avja_003 Error returned from job params OMS call" + " : with statusCode " + responseStatusCode+" "+ errorresponseData);
						session.reject("avja_003 Error returned from job params OMS call" + " : with statusCode " + responseStatusCode+" "+ errorresponseData);
					}
				});
                        }
                    }
                });
            }           