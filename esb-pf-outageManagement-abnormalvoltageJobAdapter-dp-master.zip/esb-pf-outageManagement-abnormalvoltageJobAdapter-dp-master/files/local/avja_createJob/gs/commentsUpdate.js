var ctx = session.name("avja")|| session.createContext("avja");
var callURL = require('./callUrl.js');
var omsUrl = session.parameters.omsExternalURL;
var jobIDArr = ctx.getVariable("wfcIdArr");
var origjobIdArrString = ctx.getVariable("origjobIdArrString");
var internalIdNetIDArr = ctx.getVariable("internalIdNetIDArr");



var eventType = ctx.getVariable("eventType");
var internalIdJobIDMap = ctx.getVariable("internalIdJobIDMap");

function getKeyByValue(object, value) {
  return Object.keys(object).find(key => object[key] === value);
}
function removeDuplicates(arr) {
return arr.filter((item,
index) => arr.indexOf(item) === index);
}
 
/* var eventType="";
if(inputJobType === 'HV_SUBSTATION'){
	eventType = "HIGHVOLT"
}else{
	eventType = "LOWVOLT";
} */

function getNetId(displayId){
	
var netId='';
var dispId='';
for(var i=0; i< internalIdNetIDArr.length; i++){
    if(internalIdNetIDArr[i].dispId === displayId){
        netId= internalIdNetIDArr[i].netId;
    }
}
for(var i=0; i< internalIdNetIDArr.length; i++){
    if(internalIdNetIDArr[i].dispId !=displayId && internalIdNetIDArr[i].netId=== netId){
        dispId= internalIdNetIDArr[i].dispId;
		break;
    }
}
return dispId;
	
}




jobIDArr =removeDuplicates(jobIDArr);
for(var i=0; i<jobIDArr.length;i++){
	//ctx.setVariable(i+"_"+jobIDArr[i],getKeyByValue(internalIdJobIDMap,jobIDArr[i]))
	if(jobIDArr[i]!=null && internalIdJobIDMap[jobIDArr[i]] != null && !origjobIdArrString.includes(internalIdJobIDMap[jobIDArr[i]]) ){
		var comments = "A HIGHER LEVEL "+eventType +" CIRCUIT EVENT HAS BEEN CREATED,  EVENT NUMBER "+ getNetId(internalIdJobIDMap[jobIDArr[i]]) +" ADDITIONAL TROUBLE SHOOTING MAY BE REQUIRED."
		var remarks = { "customFieldValues": {"Remarks": comments}};
		var remarksURL = omsUrl+"/v1/ServiceType/Electric/Job/"+jobIDArr[i];
		callURL(remarksURL,"PATCH","remarks",remarks);

	}
}



