var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var origjobIdArr = new Array();
var logger = console.options({
    'category': 'all'
});
var TokenValue = session.parameters.TokenValue;
var ctx = session.name("avja");
var ctx1 = session.name("ILS") || session.createContext("ILS");
var lookUpURL = session.parameters.lookUpURL;
var genericJobCreationUrl = session.parameters.genericJobCreationUrl;
var desc = session.parameters.desc;
var messageID = ctx1.getVariable('correlationId');
var currentDate = ctx.getVariable('currentDate');
var currentTime = ctx.getVariable('currentTime');
var failedArr = ctx.getVariable('failedArr');
var failedString = '';
if(failedArr !== undefined && failedArr !== null){
failedString = failedArr.join();}
ctx.setVariable("failedString",failedString);
var origjobIdArr = new Array();
ctx.setVariable("origjobIdArrNew",origjobIdArr);
ctx1.setVariable('exitDestination', genericJobCreationUrl);

/* var userName = session.parameters.userName;
var password = session.parameters.password;
var passwordBuffer = new Buffer(userName + ':' + password);
var Authorization = 'Basic ' + passwordBuffer.toString('base64');; */

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
		
        var jobType = incomingdata.jobType;
       // if(jobType === 'HV_TRANSFORMER' || jobType === 'LV_TRANSFORMER' ){
	if(incomingdata.jobType == "HV_TRANSFORMER" || incomingdata.jobType == "LV_TRANSFORMER" ){
		
		var duplicateremoval = ctx.getVariable('duplicateremoval_cd');
        for (var i = 0; i < duplicateremoval.length; i++) {
			var loc =duplicateremoval[i].loc;
            var obj = {};
			obj.messageID = messageID;
            obj.circuit = duplicateremoval[i].circuit;
            var substation = ctx.getVariable('subStationResponse' + i);
			if(substation !== undefined && substation !== null){
            var substationName = substation.name;
            obj.substation = substationName;
			}
			var subStationAddress = ctx.getVariable('subStation' + i);
			if(substation !== undefined && substation !== null){
            obj.address = subStationAddress + substationName;
			} 
            obj.aors = duplicateremoval[i].aors;
            obj.longitude = duplicateremoval[i].longitude;
            obj.latitude = duplicateremoval[i].latitude;
			//if (jobType == "HV_TRANSFORMER" || jobType == "LV_TRANSFORMER") {
				obj.networkModel = duplicateremoval[i].deviceID;
			//}
			var description ='';
			description = "Circuit" + desc;
					 
            if (jobType == "HV_SUBSTATION" || jobType == "HV_TRANSFORMER") {
                obj.jobType = "HIGH VOLTAGE";
                if (jobType == "HV_SUBSTATION") {
                    obj.jobSubType = "HIGH VOLTAGE CIRCUIT"
                } else if (jobType == "HV_TRANSFORMER" && duplicateremoval[i].jobSubType == 'HIGH VOLTAGE CIRCUIT') {
                    obj.jobSubType = "HIGH VOLTAGE CIRCUIT"
                } else {
                    session.reject("Invalid JobType::" + jobType)
                }
            } 
			//low voltage transformer check change
			else if (jobType == "LV_SUBSTATION"|| jobType == "LV_TRANSFORMER") {
                obj.jobType = "LOW VOLTAGE"
            } else {
                session.reject("Invalid JobType::" + jobType)
            }
			ctx1.setVariable("description",description);
            var p_avgVolt;
            if (jobType == "HV_SUBSTATION" || jobType == "LV_SUBSTATION") {
				var comArray =new Array();
                if (ctx.getVariable('CompletedFlag') == 'true') {
                    var array = [];
                    var repeatedComment = ' ';
                    for (var k = 0; k < incomingdata.data.length; k++) {
                        if (incomingdata.data[k].circuit == duplicateremoval[i].circuit) {
                            array.push(incomingdata.data[k].meter_number);
							var avg_volt =incomingdata.data[k].avg_volt;
                            p_avgVolt = (incomingdata.data[k].avg_volt / incomingdata.data[k].nominal_volt) * 100;
							var avgVolt = p_avgVolt.toFixed(2);
                            repeatedComment = ' VOLT LVL AT ' + avgVolt + '% AVG VOLT '+avg_volt + 'FOR PAST ' + incomingdata.data[k].hours_high_volt + ' HRS AT METER  ' + incomingdata.data[k].meter_number + ', XFMR ' + incomingdata.data[k].xfmr + ' , ADDRESS ' + incomingdata.data[k].address;
							var json ={};
							json.comment=repeatedComment;
							comArray.push(json);
                        }
                    }
					//logger.error("Array::"+JSON.stringify(array));
                    var mySetSerialized = new Set(array);
                    var myUniqueArrSerialized = [...mySetSerialized];
                    var circuitComment = 'NUMBER OF METERS ON XFMR: ' + myUniqueArrSerialized.length + ' , DEVICE LOC = ' + loc;
					var circuitJson ={};
					circuitJson.comment=circuitComment;
					comArray.push(circuitJson);
                    var CompletedFlagJobTime = ctx.getVariable('CompletedFlagJobTime');
                    var dateTime = CompletedFlagJobTime.split("T");
                    var date = dateTime[0].split("-");
                    var Rdot = dateTime[1].split(".")
                    var time = Rdot[0].split(":");
                    /* var finalComment = ' TRANSF(CIRCUIT) ' + ctx.getVariable('CompletedFlagJobID') + ' closed on ' + date[1] + "/" + date[2] + "/" + date[0] + " " + time[0] + ":" + time[1] + ":" + time[2]; */
                    var finalComment = ' TRANSFHV(CIRCUITHV) ' + ctx.getVariable('CompletedFlagJobID') + ' closed on ' + date[1] + "/" + date[2] + "/" + date[0] + " " + time[0] + ":" + time[1];
					var finalJson={};
					finalJson.comment=finalComment;
					comArray.push(finalJson);
                    obj.jobComments = comArray;
                } 
				else {
					//Defect for comments for high and low voltage
					
					var circuitComment='';
					 //if (jobType == "HV_SUBSTATION" || jobType == "HV_TRANSFORMER") {
					 if (jobType == "HV_SUBSTATION"){
					circuitComment = ' CALL SOC, HIGH VOLTAGE IMPACTING ENTIRE CIRCUIT, DEVICE LOCATION= ' + loc;
					 }
					 //if (jobType == "LV_SUBSTATION" || jobType == "LV_TRANSFORMER") {
					 if (jobType == "LV_SUBSTATION") {
                    circuitComment = ' CALL SOC, LOW VOLTAGE IMPACTING ENTIRE CIRCUIT, DEVICE LOCATION= ' + loc;
                    
					 }
					 var repeatedComment = ' ';	
					var commentArr = new Array();
					var circuitCommentJson = {};
					circuitCommentJson.comment = circuitComment;
					commentArr.push(circuitCommentJson);
					 
                    for (var j = 0; j < incomingdata.data.length; j++) {
						var json = {};
                        if (incomingdata.data[j].circuit == duplicateremoval[i].circuit) {
                            p_avgVolt = (incomingdata.data[j].avg_volt / incomingdata.data[j].nominal_volt) * 100;
							var avgVolt = p_avgVolt.toFixed(2);
                           /*  var date = new Date();
                            var currentTimestamp = date.toISOString();
                            var dateTime = currentTimestamp.split("T"); */
                            var dateRearrange = currentDate.split("-");
							var Rdot = currentTime.split(" ")
                            var time = Rdot[0].split(":");
							var hours = time[0];
							var AmOrPm = hours >= 12 ? 'PM' : 'AM';
							hours = (hours % 12) || 12;

                            repeatedComment = ' VOLTAGE LEVEL AT ' + avgVolt + '% ' + ' AVEREAGING = ' + incomingdata.data[j].avg_volt + ' FOR THE PAST ' + incomingdata.data[j].hours_high_volt + ' HOURS ON XFMR = ' + incomingdata.data[j].xfmr + ' , METER = ' + incomingdata.data[j].meter_number + ' , ADDRESS ' + incomingdata.data[j].address + ' AS OF ' + dateRearrange[1] + "/" + dateRearrange[2] + "/" + dateRearrange[0] + " " + hours + ":" + time[1] + ":" + time[2] + " "+AmOrPm;
							json.comment = repeatedComment;
							commentArr.push(json);
							
                        }
                    }
					
                    obj.jobComments = commentArr;
                }
            }
			else if (jobType == "HV_TRANSFORMER" || jobType == "LV_TRANSFORMER") {
                var array = [];
                for (var k = 0; k < incomingdata.data.length; k++) {
                    if (incomingdata.data[k].xfmr == duplicateremoval[i].xfmr) {
                        array.push(incomingdata.data[k].meter_number);
                    }
                }
                var mySetSerialized = new Set(array);
                var myUniqueArrSerialized = [...mySetSerialized];
				var commentArr = new Array();
				
                var circuitComment = 'NUMBER OF METERS ON XFMR: ' + myUniqueArrSerialized.length + ' , DEVICE LOC = ' +loc +', XFMR '+ duplicateremoval[i].xfmr;
				var circuitCommentJson = {};
				circuitCommentJson.comment = circuitComment;
				commentArr.push(circuitCommentJson);
				var repeatedComment = ' ';
                var jobCompletedComment = ' ';
                for (var j = 0; j < incomingdata.data.length; j++) {
                    if (incomingdata.data[j].xfmr == duplicateremoval[i].xfmr) {
                        p_avgVolt = (incomingdata.data[j].avg_volt / incomingdata.data[j].nominal_volt) * 100;
						var avgVolt = p_avgVolt.toFixed(2);
                        var date = new Date();
                        var currentTimestamp = date.toISOString();
                        repeatedComment =  ' VOLT LVL AT ' + avgVolt + '% ' + ' AVG VOLT= ' + incomingdata.data[j].avg_volt + ' FOR PAST ' + incomingdata.data[j].hours_high_volt + ' HRS AT METER  ' + incomingdata.data[j].meter_number + ' , ADDRESS ' + incomingdata.data[j].address;
						var json = {};
						json.comment = repeatedComment;
						commentArr.push(json);
                    }
                }
                if (ctx.getVariable('CompletedFlag') == 'true') {
                    var CompletedFlagJobTime = ctx.getVariable('CompletedFlagJobTime');
                    var dateTime = CompletedFlagJobTime.split("T");
                    var date = dateTime[0].split("-");
                    var Rdot = dateTime[1].split(".")
                    var time = Rdot[0].split(":");
                    jobCompletedComment = ' TRANSF(CIRCUIT) ' + ctx.getVariable('CompletedFlagJobID') + ' closed on ' + date[1] + "/" + date[2] + "/" + date[0] + " " + time[0] + ":" + time[1];
					var json = {};
					json.comment = jobCompletedComment;
					commentArr.push(json);
                }
                obj.jobComments = commentArr;
				
            } else {
                session.reject("Invalid JobType::" + jobType)
            }
			var ms = require('multistep');
                        ms.callRule('avja_createJob_ilsEntry_rule', null, null, function(error) {
                            if (error) {
                               // throw error;
                            }
                        });
            lookupResponse(genericJobCreationUrl, 'POST', obj, 'genericJobCreationUrlResponse', i);
        }

        function lookupResponse(url, method, data, contextName, i) {
            var options = {
                target: url,
                method: method,
                data: data,
				contentType: "application/json",
                sslClientProfile: 'avja_createJob_Client_Profile'
            };
            urlopen.open(options, function(error, response) {
                if (error) {
                    session.reject("avja_008 urlopen error: " + JSON.stringify(error));
                    logger.error("avja_008 Couldn't connect to the url " + url)
                    hm.current.statusCode = '500';
                } else {
                    var responseStatusCode = response.statusCode;
                    var responsePhrase = response.reasonPhrase;
                    if (responseStatusCode == 200) {
                        response.readAsJSON(function(error, responseData) {
                            if (error) {
                                hm.current.statusCode = '500';
                                session.output.write("readAsJSON error: " + JSON.stringify(error));
                            } else {
                                if (i === '') {
									var stepExitDesc ='Circuit ' + session.parameters.stepExitDesc;
									ctx1.setVariable("stepExitDesc",stepExitDesc);

                                    ctx.setVariable(contextName, responseData);
									ctx.setVariable(contextName, responseData);
									var origjobIdArr = ctx.getVariable("origjobIdArrNew");
									origjobIdArr.push(responseData.jobId);
									ctx.setVariable("origjobIdArrNew",origjobIdArr);
									var jobID = responseData.jobId;
									ctx1.setVariable("jobID",jobID);
									var ms = require('multistep');
                        ms.callRule('avja_createJob_ilsExit_rule', null, null, function(error) {
                            if (error) {
                               // throw error;
                            }
                        });
                                    
                                } else {
									var stepExitDesc ='Circuit ' + session.parameters.stepExitDesc;
									ctx1.setVariable("stepExitDesc",stepExitDesc);

                                    ctx.setVariable(contextName + i, responseData);
                                    ctx.setVariable(contextName + i, responseData);
									var origjobIdArr = ctx.getVariable("origjobIdArrNew");
									origjobIdArr.push(responseData.jobId);
									ctx.setVariable("origjobIdArrNew",origjobIdArr);
									var jobID = responseData.jobId;
									ctx1.setVariable("jobID",jobID);
									var ms = require('multistep');
                        ms.callRule('avja_createJob_ilsExit_rule', null, null, function(error) {
                            if (error) {
                               // throw error;
                            }
                        });
                                }
                            }
                        });
                    } else {
                        logger.error("avja_009 Couldn't connect to the job creation url " + url)
                        ctx.setVariable('responseStatusCode', responseStatusCode);
                        ctx.setVariable('responsePhrase', responsePhrase);
                        session.reject("avja_009 Couldn't connect to the job creation url::" + JSON.stringify(error));
                    }
                }
            });
        }
			}
    }
})

