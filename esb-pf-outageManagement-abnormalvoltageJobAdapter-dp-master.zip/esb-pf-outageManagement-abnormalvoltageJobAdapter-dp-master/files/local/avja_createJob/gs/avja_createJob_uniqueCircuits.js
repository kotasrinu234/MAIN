var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
    'category': 'all'
});
var TokenValue = session.parameters.TokenValue;
var ctx = session.name("avja")|| session.createContext("avja");
var ctx1 = session.name("ILS") || session.createContext("ILS");

//var repeatedThriceOrMore = ctx.getVariable('repeatedThriceOrMore');
var lookUpURL = session.parameters.lookUpURL;
var failedArr = new Array();
var status = ctx.getVariable('labels');
var messageID = ctx1.getVariable('correlationId');

function removeDuplicates(arr) {
				return arr.filter((item,
				index) => arr.indexOf(item) === index);
			}

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
        var OMS = session.parameters.omsExternalURL;
        if ((OMS == undefined) || (OMS == '') || (OMS == null)) {
            logger.error("OMSUrl is missing" + JSON.stringify(error));
            session.reject("OMSUrl is missing");
        } else {
			ctx.setVariable("flag1","one");
            var data = incomingdata.data; 
			if(incomingdata.jobType == "HV_TRANSFORMER" || incomingdata.jobType == "LV_TRANSFORMER" ){
			var deviceIdsArr = new Array();
            var array = new Array();
            for (var i = 0; i < data.length; i++) {
                var object = {};
				object.messageID = messageID;
                object.longitude = data[i].longitude;
                object.latitude = data[i].latitude;
                object.loc = data[i].device_address;
                object.aors = data[i].aors;
                object.circuit = data[i].circuit;
                object.xfmr = data[i].xfmr;
                object.deviceID = data[i].circuitDeviceID;
                object.jobSubType = 'HIGH VOLTAGE CIRCUIT';
				deviceIdsArr.push(data[i].xfmr);
                array.push(object);
            }
			
			deviceIdsArr =removeDuplicates(deviceIdsArr); 
			var repeatedThriceOrMore = new Array();
			
			ctx.setVariable("flag2","two");
			  const groups = array.reduce((groups, item) => {
			  const group = (groups[item.xfmr] || []);
			  group.push(item);
			  groups[item.xfmr] = group;
			  return groups;
			}, {});
			
			ctx.setVariable("array", array);
			ctx.setVariable("deviceIdsArr", deviceIdsArr);
			ctx.setVariable("groupedObjectsByXMFR", groups);
			ctx.setVariable("flag3","three");
			for(var i=0; i< deviceIdsArr.length; i++){
				var tempArr = groups[deviceIdsArr[i]];
				if(tempArr.length < 3){
					console.log(tempArr[0]);
				}else{
					repeatedThriceOrMore.push(...tempArr);
				}
			}
			
			ctx.setVariable("repeatedThriceOrMore", repeatedThriceOrMore);
			ctx.setVariable("flag4","four");
			var uniqueIds = [];
			var myUniqueArrSerializedParse = repeatedThriceOrMore.filter(element => {
			var isDuplicate = uniqueIds.includes(element.deviceID);
				if (!isDuplicate) {
					uniqueIds.push(element.deviceID);
					return true;
				}
			return false;
		    });

            ctx.setVariable('duplicateremoval_cd', myUniqueArrSerializedParse)
            var jobType;
            if (incomingdata.jobType == "HV_TRANSFORMER" || incomingdata.jobType == "HV_SUBSTATION") {
                jobType = "HIGH%20VOLTAGE"
            } else {
                jobType = "LOW%20VOLTAGE"
            }
            var date = new Date();
            var currentTimestamp = date.toISOString();
            var yesterday = new Date(date.getTime());
            yesterday.setDate(date.getDate() - 1);
            var yesterdayTimestamp = yesterday.toISOString();
            var take = 1000;
            for (var j = 0; j < myUniqueArrSerializedParse.length; j++) {
                var skip = 0;
               /*  var duplicateOMSUrl = OMS + '/ServiceType/Electric/Job/Query/Params?jobTypes=' + jobType + '&aors=' + myUniqueArrSerializedParse[j].aors + '&after=' + yesterdayTimestamp+ '&before=' + currentTimestamp + '&skip=' + skip + '&take=' + take + '&historical=false&includeFields=id,displayID,location,coordinates,outageSubtypeID,jobTypeID,transitionHistory,stateID,transitionHistory,transitionedAt,status,networkModelExternalID'; */
			   
			   
			   var duplicateOMSUrl = OMS + '/ServiceType/Electric/Job/Query/Params?jobTypes=' + jobType + '&statuses=' + status + '&delimiter=%2C&skip=' + skip + '&take=' + take + '&historical=false&includeFields=id,displayID,location,coordinates,outageSubtypeID,jobTypeID,transitionHistory,stateID,transitionHistory,transitionedAt,status,networkModelExternalID';
                var completedOMSUrl = OMS + '/ServiceType/Electric/Job/Query/Params?statuses=Completed&jobTypes=' + jobType + '&aors=' + myUniqueArrSerializedParse[j].aors + '&after=' + yesterdayTimestamp + '&before=' + currentTimestamp+ '&skip=' + skip + '&take=' + take + '&historical=false&includeFields=id,displayID,location,coordinates,outageSubtypeID,jobTypeID,transitionHistory,stateID,transitionHistory,transitionedAt,status,networkModelExternalID';
                var matchCircuit = myUniqueArrSerializedParse[j].circuit;
                var subStation = matchCircuit.split(/(\d+)/);
                
                ctx.setVariable('subStation' + j, subStation[0]);
                
                var substationUrl = OMS + '/ServiceType/Electric/Station/' + subStation[0];
				var subStation2 = matchCircuit;
				ctx.setVariable('subStation_new' + j, subStation2);
                
                lookupResponse(substationUrl, 'GET', '', 'subStationResponse', j);
                getDataFn(completedOMSUrl, skip, take, 'completedOMS');
                getDataFn(duplicateOMSUrl, skip, take, 'duplicateOMS');
            }
            var completedResArray = [];
            var resArray = [];
            //Recursive function call
            function getDataFn(OMSUrl, skip, take, type) {
                var OMSCall = {
                    target: OMSUrl,
                    sslClientProfile: 'avja_createJob_Client_Profile',
                    method: 'GET',
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': TokenValue
                    }
                };
                urlopen.open(OMSCall, function(error, response) {
                    if (error) {
                        logger.error("avja_001 urlopen connect error with job params oms api get" + JSON.stringify(error));
                        session.reject("avja_001 urlopen connect error with job params oms api get" + JSON.stringify(error))
                    } else {
                        var responseStatusCode = response.statusCode;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    logger.error("avja_002 urlopen connect error with oms job params " + JSON.stringify(error));
									session.reject("avja_002 urlopen connect error with oms job params " + JSON.stringify(error));
                                } else {
                                    if (type == 'duplicateOMS') {
                                        var totalWithHidden = responseData.totalWithHidden;
                                        var total = responseData.total;
                                        resArray = [...resArray, ...responseData.data]
                                        var temp = skip + take;
                                        if (temp < totalWithHidden) {
                                            skip = skip + 1000;
                                            var duplicateOMSUrl = OMS + '/ServiceType/Electric/Job/Query/Params?jobTypes=' + jobType + '&statuses=' + status + '&delimiter=%2C&skip=' + skip + '&take=' + take +'&historical=false&includeFields=id,displayID,location,coordinates,outageSubtypeID,jobTypeID,transitionHistory,stateID,transitionHistory,transitionedAt,status,networkModelExternalID';
                                            getDataFn(duplicateOMSUrl, skip, take, 'duplicateOMS');
                                        } else {
                                            ctx.setVariable('duplicateresArray', resArray)
                                            var resArrayLength = resArray.length;
                                            if (resArrayLength > 0) {
                                                for (var k = 0; k < resArrayLength; k++) {
                                                    if (!(resArray[k].id === undefined) && !(resArray[k].status === undefined)) {
                                                        var jobTypesLookupRequest = {
                                                            "lookupReq": {
                                                                "type": [{
															
                                                                    "name": "jobTypes.workflows",
                                                                    "id": resArray[k].jobTypeID,
                                                                    "status": resArray[k].status
                                                                }]
                                                            }
                                                        }
                                                        lookupResponse(lookUpURL, 'POST', jobTypesLookupRequest, 'duplicatejobTypesLookupResponse', k);
                                                    }
                                                    if (!(resArray[k].outageSubtypeID === undefined)) {
                                                        var outageSubtypeIDLookupRequest = {
                                                            "lookupReq": {
                                                                "type": [{
                                                                    "name": "outageSubtypes",
                                                                    "id": resArray[k].outageSubtypeID,
                                                                    "status": resArray[k].status
                                                                }]
                                                            }
                                                        }
                                                        lookupResponse(lookUpURL, 'POST', outageSubtypeIDLookupRequest, 'duplicateoutageSubtypeIDLookupResponse', k);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (type == 'completedOMS') {
                                        var totalWithHidden = responseData.totalWithHidden;
                                        var total = responseData.total;
                                        completedResArray = [...completedResArray, ...responseData.data]
                                        var temp = skip + take;
                                        if (temp < totalWithHidden) {
                                            skip = skip + 1000;
											completedOMSUrl = OMS + '/ServiceType/Electric/Job/Query/Params?statuses=Completed&jobTypes=' + jobType + '&aors=' + myUniqueArrSerializedParse[j].aors + '&after=' + yesterdayTimestamp + '&before=' + currentTimestamp+ '&skip=' + skip + '&take=' + take + '&historical=false&includeFields=id,displayID,location,coordinates,outageSubtypeID,jobTypeID,transitionHistory,stateID,transitionHistory,transitionedAt,status,networkModelExternalID';
                                            getDataFn(completedOMSUrl, skip, take, 'completedOMS');
                                        } else {
                                            ctx.setVariable('completedresArray', completedResArray)
                                            var resArrayLength = completedResArray.length;
                                            if (resArrayLength > 0) {
                                                for (var k = 0; k < resArrayLength; k++) {
                                                    if (!(completedResArray[k].outageSubtypeID === undefined)) {
                                                        var outageSubtypeIDLookupRequest = {
                                                            "lookupReq": {
                                                                "type": [{
                                                                    "name": "outageSubtypes",
                                                                    "id": completedResArray[k].outageSubtypeID,
                                                                    "status": completedResArray[k].status
                                                                }]
                                                            }
                                                        }
                                                        lookupResponse(lookUpURL, 'POST', outageSubtypeIDLookupRequest, 'completedoutageSubtypeIDLookupResponse', k);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            })
                        } else {
				response.readAsBuffer(function(error, errorresponseData) {
					if (error) {
						logger.error("failure in reading message from job params OMS call " + JSON.stringify(error));
						session.reject("failure in reading message from job params OMS call");
					} else {
						hm.current.statusCode = responseStatusCode;
						logger.error("avja_003 Error returned from job params OMS call" + " : with statusCode " + responseStatusCode+" "+ errorresponseData);
						session.reject("avja_003 Error returned from job params OMS call" + " : with statusCode " + responseStatusCode+" "+ errorresponseData);
					}
				});
                        }
                    }
                });
            }

            function lookupResponse(url, method, data, contextName, i) {
                if (method == 'POST') {
                    var options = {
                        target: url,
                        method: method,
                        data: data,
                        contentType: "application/json"
                    };
                } else if (method == 'GET') {
                    var options = {
                        target: url,
                        method: method,
                        data: data,
                        contentType: "application/json",
                        headers: {
                            'osiApiToken': TokenValue
                        },
                        sslClientProfile: 'avja_createJob_Client_Profile'
                    };
                } else {}

                urlopen.open(options, function(error, response) {
                    if (error) {
                        session.reject("avja_004 Couldn't connect to the url " + JSON.stringify(error));
                        logger.error("avja_004 Couldn't connect to the url " + url)
                        hm.current.statusCode = '500';
                    } else {
                        var responseStatusCode = response.statusCode;
                        var responsePhrase = response.reasonPhrase;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    hm.current.statusCode = '500';
                                    session.output.write("readAsJSON error: " + JSON.stringify(error));
                                } else {
									var ctx =session.name("avja")|| session.createContext("avja");
                                    if (i === '') {
										
                                        ctx.setVariable(contextName, responseData);
                                    } else {
                                        ctx.setVariable(contextName + i, responseData);
                                    }
                                }
                            });
                        } else if (responseStatusCode == 404) {
							var ctx =session.name("avja")|| session.createContext("avja");
							var subStation_new =ctx.getVariable('subStation_new'+i);
							var substationUrl2 = OMS + '/ServiceType/Electric/Station/' + subStation_new.substring(0,5);
							lookupResponse2(substationUrl2,  '', 'subStationResponse', i,subStation_new);
                        }else {
                            //logger.error("avja_005 Couldn't connect to the url " + url)
							var ctx = session.name("avja")|| session.createContext("avja");
                            ctx.setVariable('responseStatusCode1', responseStatusCode);
                            ctx.setVariable('responsePhrase1', responsePhrase);
                            //session.reject("avja_005 Couldn't connect to the url " + JSON.stringify(error));
							
                        }
                    }
                });
            }
		}
		}
        }
    
})

function lookupResponse2(url, data, contextName, i,subStation_new) {
                
               
                    var options = {
                        target: url,
                        method: 'GET',
                        contentType: "application/json",
                        headers: {
                            'osiApiToken': TokenValue
                        },
                        sslClientProfile: 'avja_createJob_Client_Profile'
                    };
                

                urlopen.open(options, function(error, response) {
                    if (error) {
                        session.reject("avja_004 Couldn't connect to the url " + JSON.stringify(error));
                        logger.error("avja_004 Couldn't connect to the url " + url)
                        hm.current.statusCode = '500';
                    } else {
                        var responseStatusCode = response.statusCode;
                        var responsePhrase = response.reasonPhrase;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    hm.current.statusCode = '500';
                                    session.output.write("readAsJSON error: " + JSON.stringify(error));
                                } else {
                                   
                                        ctx.setVariable(contextName + i, responseData);
                                    
                                }
                            });
                        }else{
							failedArr.push(subStation_new);
							ctx.setVariable('failedArr', failedArr);
						} 
                    }
                });
            }
