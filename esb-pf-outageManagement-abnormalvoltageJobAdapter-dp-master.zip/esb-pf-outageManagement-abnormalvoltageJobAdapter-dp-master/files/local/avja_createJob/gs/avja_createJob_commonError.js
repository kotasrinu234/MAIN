var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var errorSubcode = sm.getVar('var://service/error-subcode');
var errorCode = sm.getVar('var://service/error-code')
var obj = {};
hm.current.statusCode = '500';
obj.errorMessage = sm.getVar('var://service/error-message');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
session.output.write(obj);
