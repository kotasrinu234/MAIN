<xsl:stylesheet version="1.0" exclude-result-prefixes="dp" extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times">
   <xsl:output method="xml" version="2.0" encoding="UTF-8" indent="yes"/>
   <xsl:strip-space elements="*"/>
   
     <xsl:template match="/">
		 
	 <xsl:variable select="substring-after(dp:variable('var://service/system/ident')/identification/current-time,' ')" name="tempVAR"/>
		<dp:set-variable name="'var://context/avja/tempVAR'" value="string($tempVAR)"/>
		
		<xsl:variable select="dp:variable('var://service/system/ident')/identification/current-date" name="currentDate"/>
		<dp:set-variable name="'var://context/avja/currentDate'" value="string($currentDate)"/>
		<xsl:variable select="dp:variable('var://service/system/ident')/identification/current-time" name="currentTime"/>
		<dp:set-variable name="'var://context/avja/currentTime'" value="string($currentTime)"/>
		
		<xsl:variable name ="CompletedFlag" select= "dp:variable('var://context/avja/CompletedFlag')" />
		<xsl:variable name ="CompletedFlagJobTime" select="dp:variable('var://context/avja/CompletedFlagJobTime')" />
		
	<!-- 	<xsl:variable name="utcTimeStamp" select="current-dateTime()"/>
<dp:set-variable name="'var://context/avja/utcTimeStamp'" value="string($utcTimeStamp)" />	 -->	

		
		
		<xsl:choose>
		<xsl:when test = "$CompletedFlag='true'">
		<xsl:variable name="ErtEDTS">
			<xsl:choose>
				<xsl:when test="$tempVAR='EDT'">
					<xsl:call-template name="add-hours-to-dateTimeED">
						<xsl:with-param name="dateTime" select="substring($CompletedFlagJobTime,1,19)" />
					</xsl:call-template>
				</xsl:when>
				<xsl:when test="$tempVAR='EST'">
					<xsl:call-template name="add-hours-to-dateTimeES">
						<xsl:with-param name="dateTime" select="substring($CompletedFlagJobTime,1,19)" />
					</xsl:call-template>
				</xsl:when>
			</xsl:choose>

		</xsl:variable>
		
		</xsl:when>
		<!-- <xsl:otherwise>
		<xsl:variable name="ErtEDTS">
			<xsl:choose>
				<xsl:when test="$tempVAR='EDT'">
					<xsl:call-template name="add-hours-to-dateTimeED">
						<xsl:with-param name="dateTime" select="substring($utcTimeStamp,1,19)" />
					</xsl:call-template>
				</xsl:when>
				<xsl:when test="$tempVAR='EST'">
					<xsl:call-template name="add-hours-to-dateTimeES">
						<xsl:with-param name="dateTime" select="substring($utcTimeStamp,1,19)" />
					</xsl:call-template>
				</xsl:when>
			</xsl:choose>

		</xsl:variable>
		
		</xsl:otherwise>	 -->		
		</xsl:choose>
		
<dp:set-variable name="'var://context/avja/ESTimeStamp'" value="string($ErtEDTS)" />




</xsl:template>
   
   	
<xsl:template name="add-hours-to-dateTimeED">
		<xsl:param name="dateTime" />
		<xsl:param name="hours" select="4" />
		<xsl:variable name="dateTime-in-seconds">
			<xsl:call-template name="dateTime-to-seconds">
				<xsl:with-param name="dateTime" select="$dateTime" />
			</xsl:call-template>
		</xsl:variable>
		<xsl:variable name="total-seconds" select="$dateTime-in-seconds - 3600 * $hours" />
		<!-- new date -->
		<xsl:variable name="new-date">
			<xsl:call-template name="JDN-to-Gregorian">
				<xsl:with-param name="JDN" select="floor($total-seconds div 86400)" />
			</xsl:call-template>
		</xsl:variable>
		<!-- new time -->
		<xsl:variable name="t" select="$total-seconds mod 86400" />
		<xsl:variable name="h" select="floor($t div 3600)" />
		<xsl:variable name="r" select="$t mod 3600" />
		<xsl:variable name="m" select="floor($r div 60)" />
		<xsl:variable name="s" select="$r mod 60" />
		<!-- output -->
		<xsl:value-of select="$new-date" />
		<xsl:text>T</xsl:text>
		<xsl:value-of select="format-number($h, '00')" />
		<xsl:value-of select="format-number($m, ':00')" />
		<xsl:value-of select="format-number($s, ':00.###')" />
	</xsl:template>
<xsl:template name="add-hours-to-dateTimeES">
		<xsl:param name="dateTime" />
		<xsl:param name="hours" select="5" />
		<xsl:variable name="dateTime-in-seconds">
			<xsl:call-template name="dateTime-to-seconds">
				<xsl:with-param name="dateTime" select="$dateTime" />
			</xsl:call-template>
		</xsl:variable>
		<xsl:variable name="total-seconds" select="$dateTime-in-seconds - 3600 * $hours" />
		<!-- new date -->
		<xsl:variable name="new-date">
			<xsl:call-template name="JDN-to-Gregorian">
				<xsl:with-param name="JDN" select="floor($total-seconds div 86400)" />
			</xsl:call-template>
		</xsl:variable>
		<!-- new time -->
		<xsl:variable name="t" select="$total-seconds mod 86400" />
		<xsl:variable name="h" select="floor($t div 3600)" />
		<xsl:variable name="r" select="$t mod 3600" />
		<xsl:variable name="m" select="floor($r div 60)" />
		<xsl:variable name="s" select="$r mod 60" />
		<!-- output -->
		<xsl:value-of select="$new-date" />
		<xsl:text>T</xsl:text>
		<xsl:value-of select="format-number($h, '00')" />
		<xsl:value-of select="format-number($m, ':00')" />
		<xsl:value-of select="format-number($s, ':00.###')" />
	</xsl:template>

	<xsl:template name="dateTime-to-seconds">
		<xsl:param name="dateTime" />
		<xsl:variable name="date" select="substring-before($dateTime, 'T')" />
		<xsl:variable name="time" select="substring-after($dateTime, 'T')" />
		<xsl:variable name="year" select="substring($date, 1, 4)" />
		<xsl:variable name="month" select="substring($date, 6, 2)" />
		<xsl:variable name="day" select="substring($date, 9, 2)" />
		<xsl:variable name="hour" select="substring($time, 1, 2)" />
		<xsl:variable name="minute" select="substring($time, 4, 2)" />
		<xsl:variable name="second" select="substring($time, 7)" />
		<xsl:variable name="a" select="floor((14 - $month) div 12)" />
		<xsl:variable name="y" select="$year + 4800 - $a" />
		<xsl:variable name="m" select="$month + 12*$a - 3" />
		<xsl:variable name="jd" select="$day + floor((153*$m + 2) div 5) + 365*$y + floor($y div 4) - floor($y div 100) + floor($y div 400) - 32045" />
		<xsl:value-of select="86400*$jd + 3600*$hour + 60*$minute + $second" />
	</xsl:template>
	<xsl:template name="JDN-to-Gregorian">
		<xsl:param name="JDN" />
		<xsl:variable name="f" select="$JDN + 1401 + floor((floor((4 *$JDN + 274277) div 146097) *3) div 4) - 38" />
		<xsl:variable name="e" select="4*$f + 3" />
		<xsl:variable name="g" select="floor(($e mod 1461) div 4)" />
		<xsl:variable name="h" select="5*$g + 2" />
		<xsl:variable name="D" select="floor(($h mod 153) div 5 ) + 1" />
		<xsl:variable name="M" select="(floor($h div 153) + 2) mod 12 + 1" />
		<xsl:variable name="Y" select="floor($e div 1461) - 4716 + floor((14 - $M) div 12)" />
		<xsl:value-of select="$Y" />
		<xsl:value-of select="format-number($M, '-00')" />
		<xsl:value-of select="format-number($D, '-00')" />
	</xsl:template>

   </xsl:stylesheet>