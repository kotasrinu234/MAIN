var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
    'category': 'all'
});
var TokenValue = session.parameters.TokenValue;
var ctx = session.name("avja");
var lookUpURL = session.parameters.lookUpURL;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");

        session.reject(readAsJSONError);

    } else {
		var executeProcessing= ctx.getVariable('executeProcessing');
		if(executeProcessing == "true"){
        var completedresArray = ctx.getVariable('completedresArray');
        var duplicateresArray = ctx.getVariable('duplicateresArray');
        var duplicateremoval = ctx.getVariable('duplicateremoval');
        var duplicatejobTypesLookupResponse;
        var duplicateoutageSubtypeIDLookupResponse;
        var completedoutageSubtypeIDLookupResponse;
        var dflag, cflag;
        for (var i = 0; i < duplicateresArray.length; i++) {
            if (!(duplicateresArray[i].id === undefined) && !(duplicateresArray[i].status === undefined)) {
                duplicatejobTypesLookupResponse = ctx.getVariable('duplicatejobTypesLookupResponse' + i);
                if (!(duplicatejobTypesLookupResponse === undefined) && (duplicatejobTypesLookupResponse.lookupRep.type[0].result == 0)) {
                    if (duplicatejobTypesLookupResponse.lookupRep.type[0].label != 'Completed') {
                        duplicateoutageSubtypeIDLookupResponse = ctx.getVariable('duplicateoutageSubtypeIDLookupResponse' + i);
                        if (!(duplicateoutageSubtypeIDLookupResponse === undefined) && (duplicateoutageSubtypeIDLookupResponse.lookupRep.type[0].result == 0)) {
                            var outageSubtypeIDLookupResponselabel = duplicateoutageSubtypeIDLookupResponse.lookupRep.type[0].label;
                            for (var j = 0; j < duplicateremoval.length; j++) {
                             
								if (!(duplicateresArray[i].networkModelExternalID === undefined)) {
                                    if (duplicateremoval[j].deviceID == duplicateresArray[i].networkModelExternalID) {
                                        dflag = 'dmatch';
										ctx.setVariable("dmatchflag",dflag)
										/*  duplicateremoval.splice(j, 1);
										j--;  */
										duplicateremoval[j].dup = true;
                                    }
                                }
                            }
							
                         //   if (((dflag == 'dmatch') && (((incomingdata.jobType == 'HV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'CIRCUIT')) || ((incomingdata.jobType == 'HV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'TRANSF')))) || ((dflag == 'dmatch') && (((incomingdata.jobType == 'LV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'CIRCUIT')) || ((incomingdata.jobType == 'LV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'TRANSF'))))){
							 
							  if (((dflag == 'dmatch') && (((incomingdata.jobType == 'HV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'HIGH VOLTAGE CIRCUIT')) || ((incomingdata.jobType == 'HV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'HIGH VOLTAGE TRANSFORMER')))) || ((dflag == 'dmatch') && (((incomingdata.jobType == 'LV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'LOW VOLTAGE CIRCUIT')) || ((incomingdata.jobType == 'LV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'LOW VOLTAGE TRANSFORMER'))))){
							 
                                ctx.setVariable('DuplicateFlag', 'true');
                                //session.reject("The jobid " + duplicateresArray[i].id + " is duplicated");
                                logger.error("The jobid " + duplicateresArray[i].id + " is duplicated");
                            }
							
							
							// in case of LV duplicate check
							/* if((dflag == 'dmatch') && (((incomingdata.jobType == 'LV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'CIRCUITHV')) || ((incomingdata.jobType == 'LV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'TRANSFHV')))){
                                ctx.setVariable('DuplicateFlag', 'true');
                                session.reject("The jobid " + duplicateresArray[i].id + " is duplicated");
                                logger.error("The jobid " + duplicateresArray[i].id + " is duplicated");
                            } */
                        }
                    }
                }
            }
        }
		var noDuplicatesArr = new Array();
		
		for(var m=0; m< duplicateremoval.length; m++){
			if(duplicateremoval[m].dup === undefined){
				noDuplicatesArr.push(duplicateremoval[m]);
			}
		}
		ctx.setVariable("noDuplicatesArr", noDuplicatesArr);
		ctx.setVariable("modifiedDuplicates", duplicateremoval);
		ctx.setVariable("duplicateremoval", noDuplicatesArr);
		
        for (var k = 0; k < completedresArray.length; k++) {
            if (!(completedresArray[k].id === undefined) && !(completedresArray[k].status === undefined)) {
                completedoutageSubtypeIDLookupResponse = ctx.getVariable('completedoutageSubtypeIDLookupResponse' + k);

                if (!(completedoutageSubtypeIDLookupResponse === undefined) && (completedoutageSubtypeIDLookupResponse.lookupRep.type[0].result == 0)) {
                    var outageSubtypeIDLookupResponselabel = completedoutageSubtypeIDLookupResponse.lookupRep.type[0].label;

                    for (var l = 0; l < duplicateremoval.length; l++) {
                        /* if (!(completedresArray[k].location === undefined)) {
                            if ((duplicateremoval[l].longitude == completedresArray[k].location.coordinates[0]) && (duplicateremoval[l].latitude == completedresArray[k].location.coordinates[1])) {
                                cflag = 'cmatch';
                            }
                        } */
						if (!(completedresArray[k].networkModelExternalID === undefined)) {
                            if (duplicateremoval[l].deviceID == completedresArray[k].networkModelExternalID) {
                                cflag = 'cmatch';
                            }
                        }
                    }
					//in case of LV duplicate check
                    /* if (((cflag == 'cmatch') && (((incomingdata.jobType == 'HV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'CIRCUITHV')) || ((incomingdata.jobType == 'HV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'TRANSFHV')))) || ((cflag == 'cmatch') && (((incomingdata.jobType == 'LV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'CIRCUITHV')) || ((incomingdata.jobType == 'LV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'TRANSFHV'))))) */
						if (((cflag == 'cmatch') && (((incomingdata.jobType == 'HV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'HIGH VOLTAGE CIRCUIT')) || ((incomingdata.jobType == 'HV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'HIGH VOLTAGE TRANSFORMER'))))|| ((cflag == 'cmatch') && (((incomingdata.jobType == 'LV_SUBSTATION') && (outageSubtypeIDLookupResponselabel == 'LOW VOLTAGE CIRCUIT')) || ((incomingdata.jobType == 'LV_TRANSFORMER') && (outageSubtypeIDLookupResponselabel == 'LOW VOLTAGE TRANSFORMER'))))){
                        ctx.setVariable('CompletedFlag', 'true');
                        ctx.setVariable('CompletedFlagJobID', completedresArray[k].displayID);
                        if (!(completedresArray[k].jobTypeID === undefined)) {
                            for (var f = 0; f < completedresArray[k].transitionHistory.length; f++) {
                                var timestampLookupRequest = {
                                    "lookupReq": {
                                        "type": [{
                                            "name": "jobTypes.workflows",
                                            "id": completedresArray[k].jobTypeID,
                                            "status": completedresArray[k].transitionHistory[f].stateID
                                        }]
                                    }
                                }
                                lookupResponse(lookUpURL, 'POST', timestampLookupRequest, 'timestampLookupResponse', f, completedresArray[k].transitionHistory[f].transitionedAt);
                            }
                        }
                    }
                }
            }
        }

        function lookupResponse(url, method, data, contextName, i, transitionedAt) {

            var options = {
                target: url,
                method: method,
                data: data,
                contentType: "application/json"
            }
            urlopen.open(options, function(error, response) {
                if (error) {
                    session.reject("avja_006 urlopen error: " + JSON.stringify(error));
                    logger.error("avja_006 Couldn't connect to the url " + url)
                    hm.current.statusCode = '500';
                } else {
                    var responseStatusCode = response.statusCode;
                    var responsePhrase = response.reasonPhrase;
                    if (responseStatusCode == 200) {
                        response.readAsJSON(function(error, responseData) {
                            if (error) {
                                hm.current.statusCode = '500';
                                session.output.write("readAsJSON error: " + JSON.stringify(error));
                            } else {
                                ctx.setVariable(contextName + i, responseData);
                                if (!(responseData === undefined) && (responseData.lookupRep.type[0].result == 0)) {
                                    if (responseData.lookupRep.type[0].label == 'Completed') {
                                        ctx.setVariable('CompletedFlagJobTime', transitionedAt);
                                    }
                                }
                            }
                        });
                    } else {
                        logger.error("avja_007 Couldn't connect to the url " + url)
                        ctx.setVariable('responseStatusCode', responseStatusCode);
                        ctx.setVariable('responsePhrase', responsePhrase);
                        session.reject("avja_007 Couldn't connect to the url::" + url);
                    }
                }
            });
        }
	}
    }
})
