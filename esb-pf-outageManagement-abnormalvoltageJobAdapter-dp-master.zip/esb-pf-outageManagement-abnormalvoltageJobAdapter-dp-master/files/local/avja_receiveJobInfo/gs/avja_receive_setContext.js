var ctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlIn = sm.getVar('var://service/URL-in');
var logger = console.options({
	'category': 'all'
});

function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }

var correlationId = uuidv4();
var messageType = session.parameters.messageType;
var interfaceName = session.parameters.interfaceName;
var exitDescription = session.parameters.exitDescription;
var exitDestination = session.parameters.exitDestination;
var retryCount = '-1';
var jobType;


ctx.setVariable('correlationId', correlationId);
ctx.setVariable('messageType', messageType);
ctx.setVariable('interfaceName', interfaceName);
ctx.setVariable('exitStatus', '0');
ctx.setVariable('sourceUrl', urlIn);
ctx.setVariable('exitDescription', exitDescription);
ctx.setVariable('exitDestination', exitDestination);

session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
              var description = '';
			var jobType = incomingData.jobType;
			 if (jobType == "HV_SUBSTATION" )
			 {
                description = "Request for high voltage job creation(Circuit)"
            } else if (jobType == "LV_SUBSTATION" )
			 {
                description = "Request for low voltage job creation (Circuit)"
            } else if (jobType == "HV_TRANSFORMER" )
			 {
                description = "Request for high voltage job creation(Transformer)"
            } else {
                description = "Request for low voltage job creation (Transformer)"
            }


		var date = new Date();
		var sourceEventTimestamp = date.toISOString();
		
		
		ctx.setVariable("jobType", jobType);
		ctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		ctx.setVariable("description", description);

	
		
		

	}
});