var hm = require('header-metadata');
var headers = hm.current;
var logger = console.options({
    'category': 'all'
});
session.input.readAsBuffer(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
        var payload = incomingdata;
        headers.remove('MQMD');
        session.output.write(payload);
    }
});