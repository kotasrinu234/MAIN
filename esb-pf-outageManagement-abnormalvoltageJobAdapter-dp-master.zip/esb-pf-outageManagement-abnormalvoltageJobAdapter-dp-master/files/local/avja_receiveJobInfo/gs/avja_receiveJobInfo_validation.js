var ctx1 = session.name("ILS") || session.createContext("ILS");
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
        var dataLength = incomingdata.data.length;
        for (var i = 0; i < dataLength; i++) {
			var sum = i+1;
            if ((incomingdata.data[i].meter_number === undefined) || (incomingdata.data[i].meter_number === null) || (incomingdata.data[i].meter_number === '')) {
                session.reject('Found empty MeterNumber, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty MeterNumber, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].avg_volt === undefined) || (incomingdata.data[i].avg_volt === null) || (incomingdata.data[i].avg_volt === '')) {
                session.reject('Found empty Average Voltage, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty Average Voltage, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].hours_high_volt === undefined) || (incomingdata.data[i].hours_high_volt === null) || (incomingdata.data[i].hours_high_volt === '')) {
                session.reject('Found empty Hours High Volt, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty Hours High Volt, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].premise === undefined) || (incomingdata.data[i].premise === null) || (incomingdata.data[i].premise === '')) {
                session.reject('Found empty Premise, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty Premise, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].nominal_volt === undefined) || (incomingdata.data[i].nominal_volt === null) || (incomingdata.data[i].nominal_volt === '')) {
                session.reject('Found empty Nominal Voltage, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty Nominal Voltage, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].xfmr === undefined) || (incomingdata.data[i].xfmr === null) || (incomingdata.data[i].xfmr === '')) {
                session.reject('Found empty Transformer Number, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty Transformer Number, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].circuit === undefined) || (incomingdata.data[i].circuit === null) || (incomingdata.data[i].circuit === '')) {
                session.reject('Found empty Circuit, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty Circuit, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].aors === undefined) || (incomingdata.data[i].aors === null) || (incomingdata.data[i].aors === '')) {
                session.reject('Found empty AORS, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty AORS, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].longitude === undefined) || (incomingdata.data[i].longitude === null) || (incomingdata.data[i].longitude === '')) {
                session.reject('Found empty Longitude, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty Longitude, Kindly send a valid one in the ' + sum + ' array object');
            }
            if ((incomingdata.data[i].latitude === undefined) || (incomingdata.data[i].latitude === null) || (incomingdata.data[i].latitude === '')) {
                session.reject('Found empty Latitude, Kindly send a valid one in the ' + sum + ' array object');
				logger.error('Found empty Latitude, Kindly send a valid one in the ' + sum + ' array object');
            }
        }
		incomingdata.messageID = ctx1.getVariable('correlationId');
		ctx1.setVariable("outgoingData",incomingdata);
		session.output.write(incomingdata);
    }
});