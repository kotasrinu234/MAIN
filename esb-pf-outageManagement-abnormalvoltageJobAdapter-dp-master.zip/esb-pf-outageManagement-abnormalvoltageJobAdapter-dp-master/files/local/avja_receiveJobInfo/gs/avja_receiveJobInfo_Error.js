var sm = require('service-metadata');
var ctx = session.name("ILS") || session.createContext("ILS");

var WSM = session.name('WSM') || session.createContext('WSM');
var value = WSM.getVar('identity/username');

var logger = console.options({
    'category': 'all'
});


var username =  value;
ctx.setVariable('uname',username);
var correlationId = ctx.getVar('correlationId').toString();
var errorDescription = sm.getVar('var://service/error-message');
var errorSubcode = sm.getVar('var://service/error-subcode');
var errorCode = sm.getVar('var://service/error-code');
var obj = {};
obj.errorCode = sm.getVar('var://service/error-code');
obj.errorSubcode = sm.getVar('var://service/error-subcode');
obj.errorDescription = sm.getVar('var://service/error-message');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
if(errorSubcode === '0x01d30002'){
logger.error("id=avja_401|AAA failure for Reporting System username: " + username+ " with statusCode 401 Unauthorized with transaction id: " + correlationId + ", ErrorMessage:" +errorDescription);
	ctx.setVariable('exitStatus','401');
	
} else {
	logger.error("id=avja_500| failure with errorCode: " +errorCode+ " with transaction id: " + correlationId + "ErrorMessage:" +errorDescription);	
		ctx.setVariable('exitStatus','500');

}

session.output.write(obj);
