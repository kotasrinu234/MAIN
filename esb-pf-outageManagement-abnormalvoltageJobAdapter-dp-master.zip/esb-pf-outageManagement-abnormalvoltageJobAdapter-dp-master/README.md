# esb-pf-outageManagement-abnormalvoltageJobAdapter-dp

📌 PACKAGING INSTRUCTIONS

✅ Objects need to be selected while taking the export:

mpg:

avja_createJob
avja_receiveJobInfo


Tls Client profile:
avja_createJob_Client_Profile
avja_receiveJobInfo_AAA_AD_ClientProfile

Tls server profile
avja_receiveJobInfo_fsh_https_server_profile


AAA:

avja_receiveJobInfo_AAA


Mq handlers:
avja_createJob_mq_fsh
avja_createJob_mq_fsh_ALT

MQ managers

avja_createJob_QM
avja_createJob_QM_ALT
avja_receiveJobInfo_QM

**Note**: After deployment need to update TokenValue in avja_createJob and validate all objects are up and running.
