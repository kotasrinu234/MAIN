# esb-pf-outageManagement-trap-mq
esb-pf-outageManagement-trap-mq
