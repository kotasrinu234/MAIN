var urlopen = require('urlopen');
var fs = require('fs');
var groupBulkCrew = require('./BulkCrewAssignmentGrouping.js');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
'category': 'all'
});


var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('crewBulk') || session.createContext('crewBulk');

var lookupFailedList = [];
var userId = ctx.getVariable("userId");


session.input.readAsJSON(async function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in parsing incoming request " + JSON.stringify(readAsJSONError));
		session.reject("Error in parsing incoming request " + JSON.stringify(readAsJSONError));

	} else {
		var errorCheck = ctx.getVariable("ErrorJobIDs");

		if (!errorCheck) {

			let originalObject = incomingdata;

			let clonedIncomingObject = JSON.parse(JSON.stringify(originalObject));
			
			//logger.error("crewAssignmentList:"+JSON.stringify(incomingdata.crewAssignmentList));

			var groupedObject = groupBulkCrew(incomingdata.crewAssignmentList);

			//logger.error('groupedObject'+JSON.stringify(groupedObject));

			var cumulativeOMSResponse = [];

			//Object.keys(groupedObject).forEach((listKey, index) => {
				
				var listOfkeys = Object.keys(groupedObject);
				for(let l =0; l<listOfkeys.length; l++) {
					var listKey = listOfkeys[l];
				incomingdata.crewAssignmentList = groupedObject[listKey];

				var groupobj = groupedObject[listKey];
				
				//logger.error("groupobj:"+JSON.stringify(groupobj));

				var jobCount = session.parameters.jobCount;

				if (groupobj.length > jobCount) {

					var subCrewAssignmentList = [];

					var jobCount = session.parameters.jobCount;

					chunkArray(incomingdata.crewAssignmentList, jobCount, subCrewAssignmentList);


					//subCrewAssignmentList.forEach(subList => {
					for(let s=0; s < subCrewAssignmentList.length; s++) {
						
						//incomingdata.crewAssignmentList = subList;
						incomingdata.crewAssignmentList = subCrewAssignmentList[s];

						var clonedSubObject = JSON.parse(JSON.stringify(incomingdata));

						var omsResponseSub =   omsBulkCrewUpdate(clonedSubObject);
						if(l >= 400 && l%400==0 ) {					
							await waitFor(1000);						
						}
						cumulativeOMSResponse.push(omsResponseSub);

					}
 
				} else {

					var clonedObject = JSON.parse(JSON.stringify(incomingdata));


					var omsResponse =  omsBulkCrewUpdate(clonedObject);
					if(l >= 400 && l%400==0 ) {
						await waitFor(1000);	
					}


					if (omsResponse !== null && omsResponse !== '' && omsResponse !== undefined) {
						cumulativeOMSResponse.push(omsResponse);
					}
					else {
						return;
					}

				}

			//});
			}



			Promise.all(cumulativeOMSResponse).then((omsFinalResponse) => {

				const incomingData_omsResponse = {

					increquest: clonedIncomingObject,

					omsresponse: omsFinalResponse

				};

				session.output.write(incomingData_omsResponse);

			}).catch(err => {

				logger.error("groupobj error " + JSON.stringify(err));
			});
		} else {
			const incomingData_omsResponse = {
				increquest: incomingdata
			};
			session.output.write(incomingData_omsResponse);

		}

	}

});

function waitFor(delay) {
	return new Promise((resolve) => setTimeout(resolve, delay))
}

function omsBulkCrewUpdate(incomingdata) {
	// post call to get jobId
	return new Promise((resolve, reject) => {

		var omspayload = incomingdata.crewAssignmentList[0];
		var assignmentStatus = omspayload.assignmentStatus; // Need lookup
		var workType = omspayload.workType; // Need lookup
		var AssignmentStatusTypes = session.parameters.AssignmentStatusTypes;
		var AssignmentStatusList = AssignmentStatusTypes.split(',');
		var crewID;
		var crewIdFlag;
		var url = session.parameters.lookupUrl;
		var workTypeid;
		var assignmentStatusLookup;
		//Lookup cache call
		var lookupCacheObj = ctx.getVariable("LookupCache");
   
		var findlookup;
		if (lookupCacheObj) {
			var parsedLookup = JSON.parse(JSON.stringify(lookupCacheObj));
			findlookup = parsedLookup.find(parsedObject => (parsedObject.workType == workType && parsedObject.AssignmentStatus == assignmentStatus))
		}
		//logger.error("findlookup" + JSON.stringify(findlookup));
		if (findlookup) {
			workTypeid = findlookup.workTypeId;
			assignmentStatusLookup = findlookup.status;


			if (AssignmentStatusList.indexOf(assignmentStatus) !== -1) {
				crewIdFlag = 'false';
			} else {
				crewIdFlag = 'true';
			}
			if (omspayload.crewID && crewIdFlag === 'true') {
				crewID = omspayload.crewID;
			}
			
			var omsCrewAssignmentData = {
				"status": assignmentStatusLookup,
				"workTypeID": workTypeid,
				//"workTypeID": '5b6f07d5e45861646c06d95d',
				"crewExtID": crewID,
				"notes": "Auto Assigned by " + userId + "."
			}
			
			var omsDestination;
			
			if(omspayload.destination === undefined || omspayload.destination === null || omspayload.destination === ''){	
				
				omsDestination = {				
					 "modelType": "LEAD_CALL",
                     "fieldID": "address"  
				}
				
				omsCrewAssignmentData.destinationField = omsDestination;
			}
			else {
				omsCrewAssignmentData.destination = omspayload.destination;
				
			}
			
			
			var jobIdqueryParamsArr = [];
			incomingdata.crewAssignmentList.forEach(queryjobIdObj => {
				jobIdqueryParamsArr.push(queryjobIdObj.jobId);
			})
			var jobIdqueryParams = jobIdqueryParamsArr.join(",");
			var omsURL = session.parameters.omsURL;
			var updateURL = omsURL + "/oms/external/api/ServiceType/Electric/CrewAssignment?jobIDs=" + jobIdqueryParams;
			var omsToken = session.parameters.omsCrewAssignToken;
			var create = {
				target: updateURL,
				sslClientProfile: 'omsapi_client_profile',
				method: 'POST',
				contentType: 'application/json',
				data: omsCrewAssignmentData,
				headers: {
					'osiApiToken': omsToken
				}
			};
			var info = " TargetURL :" + create.target + "; Method :" + create.method + "; Data :" + JSON.stringify(create.data) + ". ";
			try {
				urlopen.open(create, function(error, response) {
					if (error) {
						var errorinfo = "crewAssignmentBulk_004:omsURL connection error, details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						var failedResponse = {
										
										failedReason: errorinfo,
										jobIds: jobIdqueryParams,
										jobDisplayId: omspayload.jobDisplayId
									};
									resolve(failedResponse);
						//session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting response of 'jobId POST omsURL', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									var failedResponse = {
										
										failedReason: errorinfo,
										jobIds: jobIdqueryParams,
										jobDisplayId: omspayload.jobDisplayId
									};
									resolve(failedResponse);
									//session.reject(errorinfo);

								} else {
									responseData.statusCode = responseStatusCode;
									resolve(responseData);
								}
							}); 

						}
						
						else if (responseStatusCode == 401 || responseStatusCode == 403) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error message while reading response from omsURL, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									var failedResponse = {
										
										failedReason: errorinfo,
										jobIds: jobIdqueryParams,
										jobDisplayId: omspayload.jobDisplayId
									};
									resolve(failedResponse);
									//session.reject(errorinfo);
								} else {
									var failedResponse = {
										statusCode: responseStatusCode,
										failedReason: responseData.toString(),
										jobIds: jobIdqueryParams,
										jobDisplayId: omspayload.jobDisplayId
									};
									var errorinfo = "crewAssignmentBulk_005:Unauthorized Error returned while doing post for omsCrewAssignToken :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode + " Unauthorized"
									logger.error(errorinfo);
									resolve(failedResponse);

								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting response of 'Bulk Crew POST omsURL', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									var failedResponse = {
										
										failedReason: errorinfo,
										jobIds: jobIdqueryParams,
										jobDisplayId: omspayload.jobDisplayId
									};
									resolve(failedResponse);
									//session.reject(errorinfo);
								} else {
									
									var failedResponse = {
										statusCode: responseStatusCode,
										failedReason: responseData.toString(),
										jobIds: jobIdqueryParams,
										jobDisplayId: omspayload.jobDisplayId
									};
									var errorinfo = "Error returned :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode + " Unauthorized"
									logger.error(errorinfo);
									// session.reject("Error returned " + ": with statusCode " + responseStatusCode + " " + responseData);
									resolve(failedResponse);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "crewAssignmentBulk_004:omsURL connection error, details are : " + info + "; error info :" + error
				logger.error(errorinfo);
				var failedResponse = {
										
										failedReason: errorinfo,
										jobIds: jobIdqueryParams,
										jobDisplayId: omspayload.jobDisplayId
									};
									resolve(failedResponse);
				//session.reject(errorinfo);
			}

		}
		else {

			lookupFailedList.push(omspayload);

			ctx.setVariable("lookupFailedList", lookupFailedList);
			resolve();
		}


	})
}


function chunkArray(array, chunk_size, result) {
	while (array.length) {
		result.push(array.splice(0, chunk_size));
	}
	return result;
}
