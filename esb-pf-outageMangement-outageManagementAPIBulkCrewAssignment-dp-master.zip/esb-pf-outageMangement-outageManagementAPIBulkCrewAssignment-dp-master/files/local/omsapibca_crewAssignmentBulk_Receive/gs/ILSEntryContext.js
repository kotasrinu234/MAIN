var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
var ilsCtx = session.name('ILS')|| session.createContext('ILS');
var messageType = session.parameters.messageType;
ilsCtx.setVariable('messageType',messageType);
var EntryDescription = session.parameters.EntryDescription;
var ExitDescription = session.parameters.ExitDescription;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
       // session.reject(readAsJSONError);
    } else {
		var correlationID = incomingdata.msgId
		var sourceEventTimestamp = incomingdata.timesStamp
		var crewAssignmentList = incomingdata.crewAssignmentList;
		var userID;
		 if(incomingdata.userId !== undefined && incomingdata.userId !== null && incomingdata.userId !== '')
		{
		   userID = incomingdata.userId;
		   ilsCtx.setVariable("userID", incomingdata.userId);
		}
		
var jobIds = [];
for (var i = 0; i < crewAssignmentList.length; i++) {
  var crewAssignment = crewAssignmentList[i];
  if(crewAssignment.jobId){
	  jobIds.push(crewAssignment.jobId);
  }
  else if(crewAssignment.jobDisplayId){
	   jobIds.push(crewAssignment.jobDisplayId);
  }
  else {
  }
}
var jobIDList = jobIds.join(',');
var sourceUrl = sm.getVar('var://service/URL-in');
ilsCtx.setVariable('sourceUrl',sourceUrl);
ilsCtx.setVariable('correlationID',correlationID);
ilsCtx.setVariable('sourceEventTimestamp',sourceEventTimestamp);
ilsCtx.setVariable('jobIDList',jobIDList);
ilsCtx.setVariable('EntryDescription',EntryDescription);
ilsCtx.setVariable('ExitDescription',ExitDescription);


	}
	});