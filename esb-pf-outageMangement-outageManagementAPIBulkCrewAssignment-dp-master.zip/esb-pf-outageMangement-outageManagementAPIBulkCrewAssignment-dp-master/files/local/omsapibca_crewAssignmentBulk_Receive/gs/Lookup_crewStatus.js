var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('crewBulk') || session.createContext('crewBulk');
var url = session.parameters.lookupUrl;

session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
    if (readAsJSONError) {
        logger.error("Error in parsing incoming request " + JSON.stringify(readAsJSONError));
        //session.reject("Error in parsing incoming request" + JSON.stringify(readAsJSONError));
    }
		else {
			//var omsPayload = incomingData.crewAssignmentList[0]
			//var assignmentStatus = incomingData.omsPayload; 
			//var workType = incomingData.omsPayload;
			var assignmentStatusLookup;
			var workTypeReq;
			var assignmentStatusReq;
			var workTypeID;
			var workTypeRespArray=[];
			var uniqueWorkType = [...new Set(incomingData.crewAssignmentList.map(item => item.workType))]; 
				
				 uniqueWorkType.map( (ele) => {		
					
						 workTypeReq = {
							"lookupReq": {
								"type": [
									{
										"name": "workTypes",
										"label": ele
									}
								]
							}
						};		
				
					var workTypeResp =  LookUp(url, workTypeReq, 'workType LookUp');
					
					
					
					workTypeRespArray.push(workTypeResp);

					
				});
				
                Promise.all(workTypeRespArray).then((workTypeResp) => {
	
					uniqueWorkType = uniqueWorkType.map( (ele, index) => {
					
				
					//if(workTypeResp[index].lookupRep){
						//logger.error("workTypeResp[index].lookupRep :"+JSON.stringify(workTypeResp[index].lookupRep));
					let workIdmap = {};
					try{
					  workIdmap = {
						 
						 [ele]: workTypeResp[index].lookupRep.type[0].id
					 };
					//}
					
					 return workIdmap;
					} catch(error) {
						logger.error("catch promise"+error);
					}
					
				});
				

				var uniqueAssignmentStatus = [...new Set(incomingData.crewAssignmentList.map(item => item.assignmentStatus))]; // [ 'A', 'B']
				const LookupCache = [];
				uniqueWorkType.forEach(workTypeObj => {
					if(workTypeObj) {
					uniqueAssignmentStatus.forEach((assignmentObj) => {
						
						//assignment status lookup
						
						 assignmentStatusReq = {
								  "lookupReq": {
									"type": [
									  {
										"name": "workType.workflows",
										"id": workTypeObj[Object.keys(workTypeObj)[0]],
										"label": assignmentObj
									  }
									]
								  }
								}
			
				LookUp(url, assignmentStatusReq, 'assignmentStatus LookUp').then(assignmentStatusResp => {
					
					assignmentStatusLookup = assignmentStatusResp.lookupRep.type[0].status;
					let finalres = {
					'workType' : Object.keys(workTypeObj)[0],
					'workTypeId': workTypeObj[Object.keys(workTypeObj)[0]],
					'AssignmentStatus': assignmentObj,
					'status': assignmentStatusLookup
					};
					 LookupCache.push(finalres);
			
					 ctx.setVariable('LookupCache',LookupCache);
					 });
						
					})
					}
				});
				
			
			//	logger.error("Trace 3");
			});	
		}
	
});

function LookUp(url, payload, myctx) {
	return new Promise((resolve, reject)=> {
	var LookupServiceResponse = {
		target: url,
		method: 'POST',
		contentType: 'application/json',
		data: payload
	};
	
	var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "; Data: " + JSON.stringify(LookupServiceResponse.data) + ". ";
	urlopen.open(LookupServiceResponse, function(error, response) {
		if (error) {
			var errorinfo = "crewAssignmentBulk_001:lookupUrl connection error '" + myctx + "', details are : " + info + "; error info :" + error
			logger.error(errorinfo);
			//session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response '" + myctx + "', details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						//session.reject(errorinfo);
					} else {
						if (responseData.lookupRep.type[0].result == 1) {
							var invalidresp = "crewAssignmentBulk_002:Invalid LookUp Request '" + myctx + "', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
							logger.error(invalidresp)
							//session.reject(invalidresp)
							resolve(invalidresp);
						} else {
							
							
							resolve(responseData);
							
							
						}
					}
				})
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response '" + myctx + "', details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						//session.reject(errorinfo);
					} else {
						var errorinfo = "error response '" + myctx + "', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
						hm.current.statusCode = responseStatusCode;
						logger.error(errorinfo);
						//session.reject(errorinfo);
					}
				});
			}
		}
	});
	});
}
