var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('crewBulk') || session.createContext('crewBulk');
session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
    if (readAsJSONError) {
        logger.error("Error in parsing incoming request " + JSON.stringify(readAsJSONError));
        session.reject("Error in parsing incoming request" + JSON.stringify(readAsJSONError));
           }
    
	if((incomingData.msgId=== undefined)||(incomingData.msgId===null)||(incomingData.msgId=== '')){
		session.reject("The msgId field is a mandatory");
	};
	if((incomingData.userId=== undefined)||(incomingData.userId===null)||(incomingData.userId=== '')){
		session.reject("The userId field is a mandatory");
	} else{
		ctx.setVariable("userId", incomingData.userId);
	}
	
	if((incomingData.timesStamp=== undefined)||(incomingData.timesStamp===null)||(incomingData.timesStamp=== '')){
		session.reject("The timesStamp field is a mandatory");
	};
		
		/*
	if (incomingData.crewAssignmentList[0].jobId === undefined || incomingData.crewAssignmentList[0].jobId === null || incomingData.crewAssignmentList[0].jobId === '') {
		if ((incomingData.crewAssignmentList[0].jobDisplayId === undefined) || (incomingData.crewAssignmentList[0].jobDisplayId === null) || (incomingData.crewAssignmentList[0].jobDisplayId === '')) {
				 session.reject("jobId or jobDisplayId is mandatory field ");
		}
	}
		
	if((incomingdata.crewAssignmentList[0].assignmentStatus === undefined)||(incomingdata.crewAssignmentList[0].assignmentStatus ===null)||(incomingdata.crewAssignmentList[0].assignmentStatus ==='')){
		session.reject("The assignmentStatus field is mandatory");
	} 

	if((incomingdata.crewAssignmentList[0].workType=== undefined)||(incomingdata.crewAssignmentList[0].workType===null)||(incomingdata.crewAssignmentList[0].workType==='')){
		session.reject("The workType field is mandatory");
	};
		*/
		const validList = incomingData.crewAssignmentList.filter(checkRequired);
		const invalidList = incomingData.crewAssignmentList.filter(item => !checkRequired(item));
		ctx.setVariable("invalidList", invalidList);
		incomingData.crewAssignmentList = validList;
		session.output.write(incomingData);
	
});
	function checkRequired(item) {
  
            return ((item.jobId !== '' && item.jobId !== undefined && item.jobId !== null) || (item.jobDisplayId !== '' && item.jobDisplayId !== undefined && item.jobDisplayId !== null))
			&&	item.assignmentStatus !== '' && item.assignmentStatus !== undefined && item.assignmentStatus !== null &&
			item.workType !== '' && item.workType !== undefined && item.workType !== null;
    }