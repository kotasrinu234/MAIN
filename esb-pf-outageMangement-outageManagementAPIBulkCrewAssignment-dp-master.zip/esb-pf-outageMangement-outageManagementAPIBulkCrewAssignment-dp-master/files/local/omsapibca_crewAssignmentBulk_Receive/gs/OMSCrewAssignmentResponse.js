var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('crewBulk') || session.createContext('crewBulk');
var ctxILS = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingData_omsResponse) {
	if (readAsJSONError) {
		logger.error("Error in parsing incoming request " + JSON.stringify(readAsJSONError));
		session.reject("Error in parsing incoming request" + JSON.stringify(readAsJSONError));
	}
	else {
		//logger.error("incoingData_omsResponse:" +JSON.stringify(incomingData_omsResponse));
		var errorCheck = ctx.getVariable("ErrorJobIDs");
		var bulkCrewAssignResp = {
			msgId: incomingData_omsResponse.increquest.msgId,
			timesStamp: new Date(),
			crewAssignmentList: []
		};
		if (!errorCheck) {
			incomingData_omsResponse = removeNullResponse(incomingData_omsResponse);
			
			bulkCrewAssignResp = parseOMSResponse(incomingData_omsResponse);
			
		} else {
			var incomeList = incomingData_omsResponse.increquest.crewAssignmentList;
			if (incomeList.length > 0) {
				ctxILS.setVariable("omsStatusCode", '0');
				for (let m = 0; m < incomeList.length; m++) {
					var errorJobObject = {
						status: "ERROR"
					};
					errorJobObject.jobDisplayId = incomeList[m].jobDisplayId;
					errorJobObject.jobId = incomeList[m].jobId;
					errorJobObject.failureReasons = errorCheck.statusCode + ":" + errorCheck.failedReason;
					bulkCrewAssignResp.crewAssignmentList.push(errorJobObject);
				}
			}
			else {
				ctxILS.setVariable("omsStatusCode", '0');
				var jobDisIdList = ctx.getVariable("jobDisplayIdList");
				
				for (let j = 0; j < jobDisIdList.length; j++) {
					var errorJobObject = {
						status: "ERROR"
					};
					errorJobObject.jobDisplayId = jobDisIdList[j];
					errorJobObject.failureReasons = errorCheck.statusCode + ":" + errorCheck.failedReason;
					bulkCrewAssignResp.crewAssignmentList.push(errorJobObject);
				}

			}
		}
		// Missing JobId array response		 
		var missingJobList = ctx.getVariable("MissingJobIDs");
		if (missingJobList === undefined) {
		}
		else {
			ctxILS.setVariable("omsStatusCode", '0');
			for (let m = 0; m < missingJobList.length; m++) {
				var missedJobObject = {
					status: "ERROR"
				};
				missedJobObject.jobDisplayId = missingJobList[m];
				missedJobObject.failureReasons = "JOB not found";
				bulkCrewAssignResp.crewAssignmentList.push(missedJobObject);
			}
		}
		var invalidList = ctx.getVariable("invalidList");
		if (invalidList === undefined) {
		}
		else {
			ctxILS.setVariable("omsStatusCode", '0');
			for (let inval = 0; inval < invalidList.length; inval++) {
				var invalidListObject = {
					status: "ERROR"
				};
				
				invalidListObject.jobId = invalidList[inval].jobId;
				invalidListObject.jobDisplayId = invalidList[inval].jobDisplayId;
				invalidListObject.assignmentStatus = invalidList[inval].assignmentStatus;
				invalidListObject.crewID = invalidList[inval].crewID;
				invalidListObject.workType = invalidList[inval].workType;
				invalidListObject.destination = invalidList[inval].destination;
				if(!(invalidListObject.jobId || invalidListObject.jobDisplayId)){
				invalidListObject.failureReasons = "JobId/JobDisplayId is mandatory field";
				}
				else if(!invalidListObject.assignmentStatus){
				invalidListObject.failureReasons = "AssignmentStatus is mandatory field";
				}
				
				else if(!invalidListObject.workType){
				invalidListObject.failureReasons = "WorkType is mandatory field";
				}
				
				else{
				}
				bulkCrewAssignResp.crewAssignmentList.push(invalidListObject);
			}
		}
		
		var crewAssignFailedList = ctx.getVariable("crewAssignFailedList");
		if (crewAssignFailedList === undefined) {
		}
		else {
			ctxILS.setVariable("omsStatusCode", '0');
			for (let inval = 0; inval < crewAssignFailedList.length; inval++) {
				bulkCrewAssignResp.crewAssignmentList.push(crewAssignFailedList[inval]);
			}
			
		}
		
		var lookupFailedList = ctx.getVariable("lookupFailedList");
		if (lookupFailedList === undefined) {
		}
		else {
			ctxILS.setVariable("omsStatusCode", '0');
			
			for (let m = 0; m < lookupFailedList.length; m++) {
				var duplicateRes = bulkCrewAssignResp.crewAssignmentList.find(crewList => crewList.jobId == lookupFailedList[m].jobId);
				if(duplicateRes) {
					
					var failureCrewIndex = bulkCrewAssignResp.crewAssignmentList.findIndex(crewObject => crewObject.jobId == duplicateRes.jobId);
					bulkCrewAssignResp.crewAssignmentList[failureCrewIndex].failureReasons = "WorkType/AssignmentStatus lookup failure";
				} else {
				var lookupFail = {
						status: "ERROR"
					};
					lookupFail.jobId = lookupFailedList[m].jobId;
					lookupFail.jobDisplayId = lookupFailedList[m].jobDisplayId;
					lookupFail.failureReasons = "WorkType/AssignmentStatus lookup failure";
					
				bulkCrewAssignResp.crewAssignmentList.push(lookupFail);
				}
			}
		
			
		}
		//logger.error("bulkCrewAssignResp"+JSON.stringify());
		bulkCrewAssignResp = respForMissingJobId(incomingData_omsResponse, bulkCrewAssignResp);

		session.output.write(bulkCrewAssignResp);
	}
});
function removeNullResponse(incomingData_omsResponse) {
	var afterNullsRemoved = incomingData_omsResponse.omsresponse.filter(omsNonNull => omsNonNull != null );
	incomingData_omsResponse.omsresponse = afterNullsRemoved;
	return incomingData_omsResponse;
}
function respForMissingJobId(incomingData_omsResponse, bulkCrewAssignResp) {
	incomingData_omsResponse.increquest.crewAssignmentList.forEach(incomingReq => {
		var jobID = incomingReq.jobId;
		var crewAssignmentListObject = {
						jobId: "",
						jobDisplayId: "",
						status: "ERROR",
						failureReasons : "Unknown error occurred"
					};
		var jobIdCheck =  bulkCrewAssignResp.crewAssignmentList.find(eleJobID =>  eleJobID.jobId == jobID);
		if(!jobIdCheck) {
			crewAssignmentListObject.jobId = jobID;
			crewAssignmentListObject.jobDisplayId = incomingReq.jobDisplayId;
			bulkCrewAssignResp.crewAssignmentList.push(crewAssignmentListObject);
		}
	})
	
	return bulkCrewAssignResp;
	
}
function parseOMSResponse(incomingData_omsResponse) {
	var bulkCrewAssignPayLoad = {
		msgId: incomingData_omsResponse.increquest.msgId,
		timesStamp: new Date(),
		crewAssignmentList: []
	};
    
	var inReqForRespProcess = incomingData_omsResponse.increquest;
	if(incomingData_omsResponse.omsresponse){
		
	var omsStatusCode = incomingData_omsResponse.omsresponse.find(omsStatus => omsStatus && omsStatus.statusCode == 200);

	if (omsStatusCode && omsStatusCode.statusCode == 200) {

		ctxILS.setVariable("omsStatusCode", '0');
		incomingData_omsResponse.omsresponse.forEach(omsdata => {
			if (omsdata.data) {
				omsdata.data.forEach(omsFiledata => {
					
					var crewAssignmentListObject = {
						jobId: "",
						jobDisplayId: "",
						status: ""
					};
					if (omsdata.statusCode == 200) {
						if (omsFiledata.status.returnCode == 'SUCCESS') {
							
							
							crewAssignmentListObject.status = omsFiledata.status.returnCode;
							
							if(omsFiledata.model.jobID){
								var tempInRequest = getInJobIdList(inReqForRespProcess, omsFiledata.model.jobID)
								crewAssignmentListObject.jobId = tempInRequest[0].jobId;
								crewAssignmentListObject.jobDisplayId = tempInRequest[0].jobDisplayId;
								crewAssignmentListObject.crewID = tempInRequest[0].crewID;
								crewAssignmentListObject.assignmentStatus = tempInRequest[0].assignmentStatus;
								crewAssignmentListObject.crewAssignmentDisplayID = omsFiledata.model.displayID;
							}
							
						} else if (omsFiledata.status.returnCode == 'ERROR') {
							
							crewAssignmentListObject.status = omsFiledata.status.returnCode;
							if(omsFiledata.model.jobID){
								var tempInRequest = getInJobIdList(inReqForRespProcess, omsFiledata.model.jobID)
								crewAssignmentListObject.jobId = tempInRequest[0].jobId;
								crewAssignmentListObject.jobDisplayId = tempInRequest[0].jobDisplayId;
								crewAssignmentListObject.crewID = tempInRequest[0].crewID;
								crewAssignmentListObject.assignmentStatus = tempInRequest[0].assignmentStatus;
								crewAssignmentListObject.failureReasons = omsFiledata.status.message;
								crewAssignmentListObject.editViolations = omsFiledata.status.editViolations;
							}
							else {
								return;
							}
							
						}
					}
					
					bulkCrewAssignPayLoad.crewAssignmentList.push(crewAssignmentListObject);
					
				})
			} else {
				
				let jobIdChunkList = omsdata.jobIds.split(',');
				jobIdChunkList.forEach(failedJobId => {
					var failedDisplayIdList = getInJobIdList(inReqForRespProcess, failedJobId);
					var crewAssignmentListObject = {
						jobId: "",
						status: "FAILURE"
					};
					if (omsdata.jobDisplayId) {
						crewAssignmentListObject.jobDisplayId = failedDisplayIdList.jobDisplayId;
					}
					crewAssignmentListObject.jobId = failedJobId;
					crewAssignmentListObject.failureReasons = omsdata.statusCode + ":" + omsdata.failedReason;
					bulkCrewAssignPayLoad.crewAssignmentList.push(crewAssignmentListObject);
					
				})
			}
		})
	}
	else {
		//logger.error("In Error else"+JSON.stringify(incomingData_omsResponse.omsresponse));
		ctxILS.setVariable("omsStatusCode", '0');
		if (incomingData_omsResponse.omsresponse != '' && incomingData_omsResponse.omsresponse != undefined && incomingData_omsResponse.omsresponse != null) {

				bulkCrewAssignPayLoad.crewAssignmentList = incomingData_omsResponse.increquest.crewAssignmentList.map(ele => {
					var failureObject = incomingData_omsResponse.omsresponse.find(omsData => omsData.jobIds.includes(ele.jobId));
					
					if(failureObject) {
					return {
						"jobDisplayId": ele.jobDisplayId,
						"jobId": ele.jobId,
						"status": "ERROR",
						"failureReasons": failureObject.statusCode + ":" + failureObject.failedReason
					}
					} else {
						return {
						"jobDisplayId": ele.jobDisplayId,
						"jobId": ele.jobId,
						"status": "ERROR",
						"failureReasons": incomingData_omsResponse.omsresponse[0].statusCode + ":" + incomingData_omsResponse.omsresponse[0].failedReason
					}
					}
				});
			}
	}
	}
	
	return bulkCrewAssignPayLoad;
}


function getInJobIdList(incomingreq, modelId) {
	
	var jobDisplayIdArray = incomingreq.crewAssignmentList.filter(crewItems => {
		return (crewItems.jobId == modelId)
	});
	
	
	//var jobDisplayId = tempInRequest[0].jobDisplayId;
	return jobDisplayIdArray;
}
