var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('crewBulk') || session.createContext('crewBulk');

function groupBulkCrew(crewAssignmentList) {
	
	
	var reducedCrewList = crewAssignmentList.reduce((acc, item) => {
 
    if(!item.hasOwnProperty('assignmentStatus')) {
        item.assignmentStatus = "noAssignmentStatus";
    }  
	if(!item.hasOwnProperty('crewID')) {
        item.crewID = "noCrewID";
    }
	if(!item.hasOwnProperty('workType')) {
        item.workType = "noWorkType";
    }
	if(!item.hasOwnProperty('destination')) {
        item.destination = "noDestination";
    }
	
    let compositeKey = item.assignmentStatus + '-' + item.crewID  + "-" + item.workType + "-" + item.destination;
	
	
	
    if (Object.keys(acc).includes(compositeKey)) return acc;

    acc[compositeKey] = crewAssignmentList.filter(g => {
        
			 if(!g.hasOwnProperty('assignmentStatus')) {
				 g.assignmentStatus='noAssignmentStatus'
			 }
			 if(!g.hasOwnProperty('crewID')) {
				 g.crewID='noCrewID'
			 }
			 if(!g.hasOwnProperty('workType')) {
				 g.workType='noWorkType'
			 }
			  if(!g.hasOwnProperty('destination')) {
				 g.destination='noDestination'
			 }
			 
        return (
        g.assignmentStatus === item.assignmentStatus && 
        g.crewID === item.crewID && 
        g.workType === item.workType && 
        g.destination === item.destination
        	
        )       
    })
    return acc;
}, {})
 
Object.keys(reducedCrewList).forEach(objKey => {
	reducedCrewList[objKey].map(e => {
		if(e.assignmentStatus === 'noAssignmentStatus') delete e.assignmentStatus;
		if(e.crewID === 'noCrewID') delete e.crewID;
		if(e.workType === 'noWorkType') delete e.workType;
		if(e.destination === 'noDestination') delete e.destination;
	
		return e;
	})
})
return reducedCrewList;
	
}	
module.exports = groupBulkCrew;