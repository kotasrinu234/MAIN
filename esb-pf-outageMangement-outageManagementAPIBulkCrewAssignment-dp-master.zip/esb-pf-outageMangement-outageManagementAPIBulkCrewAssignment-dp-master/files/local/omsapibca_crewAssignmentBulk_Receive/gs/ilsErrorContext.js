
var ilsctx = session.name("ILS") || session.createContext("ILS");
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

var errorSubcode = sm.getVar('var://service/error-subcode');
var errorCode = sm.getVar('var://service/error-code')
//var errorDescription = ilsctx.getVariable("errordescription");
var obj = {};
var errorResponse = {};

obj.errorDescription = sm.getVar('var://service/error-message');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
//ctx.setVariable("errorResponse", errorResponse);
session.output.write(obj);