var urlopen = require('urlopen');
var fs = require('fs');
var util = require('util');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('crewBulk') || session.createContext('crewBulk');
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.input.readAsJSON(async function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {


		for (let i = 0; i < incomingData.crewAssignmentList.length; i++) {
			if (incomingData.crewAssignmentList[i].jobId === undefined || incomingData.crewAssignmentList[i].jobId === null || incomingData.crewAssignmentList[i].jobId === '') {

				await updateJobId(incomingData);
				incomingData.crewAssignmentList = incomingData.crewAssignmentList.filter(isJobIdExist => {
					return (isJobIdExist.jobId && isJobIdExist.jobId != null && isJobIdExist.jobId != undefined)
				});
			}
		}
		session.output.write(incomingData);

	}
})
async function updateJobId(incomingData) {
	var jobDisplayIdList = [];
	var isJobId;

	for (let i = 0; i < incomingData.crewAssignmentList.length; i++) {
		if (incomingData.crewAssignmentList[i].jobId === undefined || incomingData.crewAssignmentList[i].jobId === null || incomingData.crewAssignmentList[i].jobId === '') {
			if ((incomingData.crewAssignmentList[i].jobDisplayId === undefined) || (incomingData.crewAssignmentList[i].jobDisplayId === null) || (incomingData.crewAssignmentList[i].jobDisplayId === '')) {
				session.reject("jobId or jobDisplayId is a mandatory field ");

			}
			else {

				jobDisplayIdList.push(incomingData.crewAssignmentList[i].jobDisplayId);

				ctx.setVariable("jobDisplayIdList", jobDisplayIdList);
				//post call to get jobId
				//    var JobId = await fetchJobId(incomingData.jobList[i].jobDisplayId);
				//	incomingData.jobList[i].jobId = JobId;					 
			}
		}

	}
	var missedJobId = [];
	var crewAssignFailedList = [];
	try {
		var JobIdList = await fetchJobId(jobDisplayIdList);

		var errorJobId = [];
		for (let j = 0; j < incomingData.crewAssignmentList.length; j++) {
			var keyToFind = 'displayID';
			if (incomingData.crewAssignmentList[j].jobId === undefined || incomingData.crewAssignmentList[j].jobId === null || incomingData.crewAssignmentList[j].jobId === '') {
				var foundObject = JobIdList.find(obj => obj[keyToFind] === incomingData.crewAssignmentList[j].jobDisplayId);
				if (foundObject) {
					incomingData.crewAssignmentList[j].jobId = foundObject.id;
				}
				else {
					missedJobId.push(incomingData.crewAssignmentList[j].jobDisplayId);
					ctx.setVariable("MissingJobIDs", missedJobId);
				}
			}
		}
	} catch (err) {
		for (let m = 0; m < jobDisplayIdList.length; m++) {
			var GetJobIdFail = {
				status: "FAILURE"
			};
			GetJobIdFail.jobDisplayId = jobDisplayIdList[m];
			GetJobIdFail.failureReasons = err.statusCode + " " + err.failedReason;
			crewAssignFailedList.push(GetJobIdFail);
		}
		ctx.setVariable("crewAssignFailedList", crewAssignFailedList);
		logger.error("Fetch jobid failed:" + JSON.stringify(err));
	}
}
function fetchJobId(displayIDList) {

	//post call to get jobId
	return new Promise((resolve, reject) => {
		let jobDisplayIdList = displayIDList;
		var responseJobid = [];
		var postJobDisplayIdList = jobDisplayIdList;
		var omsURL = session.parameters.omsURL;
		var omsCrewAssignToken = session.parameters.omsCrewAssignToken;
		var createURL = omsURL + "/oms/external/api/v1/ServiceType/Electric/Job/Query?isInternalIDs=false&includeFields=displayID%2Cid&historical=false";
		var create = {
			target: createURL,
			sslClientProfile: 'omsapi_client_profile',
			method: 'POST',
			contentType: 'application/json',
			data: postJobDisplayIdList,
			headers: {
				'osiApiToken': omsCrewAssignToken
			}
		};
		var info = " TargetURL :" + create.target + "; Method :" + create.method + "; Data :" + JSON.stringify(create.data) + ". ";
		try {
			urlopen.open(create, function(error, response) {
				if (error) {
					var errorinfo = "omsURL connection error, details are : " + info + "; error info :" + error
					logger.error(errorinfo);
					//session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in getting response of 'omsURL', details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								resolve(responseData);
							}
						});
					} else if (responseStatusCode == 401 || responseStatusCode == 403) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error message while reading response from omsURL, details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								var errorinfo = "crewAssignmentBulk_003:Unauthorized Error returned while GET call by JobDisplayId :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode + " Unauthorized"
								logger.error(errorinfo);
								var failedFetchJobId = {
									statusCode: responseStatusCode,
									failedReason: responseData.toString()
								};
								reject(failedFetchJobId);
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in getting response of 'omsURL', details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								//session.reject(errorinfo);
							} else {
								//	session.reject("Error returned " + ": with statusCode " + responseStatusCode + " " + responseData);
							}
							var failedFetchJobId = {
								statusCode: responseStatusCode,
								failedReason: responseData.toString()
							};
							reject(failedFetchJobId);
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "omsURL connection error, details are : " + info + "; error info :" + error
			logger.error(errorinfo);
			//session.reject(errorinfo);
		}
	})
}
