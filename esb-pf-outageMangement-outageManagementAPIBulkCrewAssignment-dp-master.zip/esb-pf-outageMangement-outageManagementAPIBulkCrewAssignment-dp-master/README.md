# esb-pf-outageMangement-outageManagementAPIBulkCrewAssignment-dp
Interface 67 Bul Crew Assaignment
