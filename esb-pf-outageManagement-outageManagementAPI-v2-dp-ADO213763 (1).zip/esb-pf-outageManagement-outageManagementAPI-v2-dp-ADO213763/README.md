# esb-pf-outageManagement-outageManagementAPI-v2-dp
a) MultiprotocalGateway Services
    omsapi_Gateway(MPGW)
    omsapi_OperationStatus_v2(MPGW)
    omsapi_v2(MPGW)
    omsapi_ReceiveComments
    omsapi_SendCrewStatus_v2
    omsapi_PublishCrewStatus_v2
    omsapi_SendOperationStatus_v2
b) SSL client profiles
    omsapi_client_profile
    omsapi_AD_AAA_Client_Profile
    omsapi_ReceiveComments_ClientProfile
    omsapi_addComments_ClientProfile
    omsapi_v2_attachment_ClientProfile
    omsapi_SendCrewStatus_v2_Client_Profile
c) IBM Mq queue manager
    Publish_Operation_Mode_qmgr
    omsapi_RECEIVE_REQUEST_QM
    omsapi_REQUEST_QM
    ESBIIB_omsapi
    omsapi_PublishCrewStatus_v2_Qmgr
    omsapi_Send_CrewStatus_v2_Qmgr
    omsapi_Send_CrewStatus_v2_Qmgr_ALT
    omsapi_SendOperationStatus_v2_Qmgr
    omsapi_SendOperationStatus_v2_Qmgr_ALT
    omsapi_SendOperationStatus_v2_Retry_Qmgr
    omsapi_v2_jobUpdate_Qmgr -  Newly added
	omsapi_v2_jobRestore_Verify_Qmgr -  Newly added
 
d)    AAA Policy 
    omsapi_PublishCrewStatus_v2_AAA_Policy
 
e) SQL DataSource Object 
    objectName :omsapi_db
 
f) MQURl : sample url
    apiToken_Urma : sample_apiToken_Urma
	
g) Tokens to be updated:
omsapi_ReceiveComments   : apiToken
omsapi_v2	             : apiToken
	                     : apiToken_Multipurpose
	                     : apiToken_chatbot
	                     : apiToken_maximo
	                     : apiToken_reporting
	                     : apiToken_Abnormal_Voltage
	                     : apiToken_ami
	                     : keyValue
omsapi_SendCrewStatus_v2 : SubscriptionKey
