var sm = require('service-metadata');
var uri = sm.URI;
var v1port=session.parameters.v1port;
var v2port=session.parameters.v2port;
var hosturl = "http://127.0.0.1:"
var version =session.parameters.version;
var port = "";
if(version==='v1'){
	port=v1port;
}
if(version==='v2'){
	port=v2port;
}

sm.routingUrl = hosturl+port+uri; 
