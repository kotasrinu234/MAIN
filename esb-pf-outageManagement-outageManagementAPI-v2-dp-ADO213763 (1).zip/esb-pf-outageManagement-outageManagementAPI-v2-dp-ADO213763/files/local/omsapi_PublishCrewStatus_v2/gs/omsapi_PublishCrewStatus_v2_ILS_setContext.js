var logger = console.options({
	'category': 'all'
});
var ctx1 = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
var lookupResponse = ctx1.getVar("lookupResponse");
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.entryDescription;
var exitDescription = session.parameters.exitDescription;
var apiName = session.parameters.apiName;
var messageType = session.parameters.messageType;
var exitDestination = session.parameters.MQPublishurl;
ctx.setVariable("messageType", messageType);
ctx.setVariable("exitDestination", exitDestination);
ctx.setVariable("apiName", apiName);
ctx.setVariable('entryDescription', entryDescription);
ctx.setVariable('exitDescription', exitDescription);
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var id = uuidv4()
ctx.setVariable("messageID", id);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name('ILS') || session.createContext('ILS');
		if (incomingdata.data[0]) {
			if (incomingdata.data[0].messageID) {
				if (incomingdata.data[0].messageID !== undefined || incomingdata.data[0].messageID !== null || incomingdata.data[0].messageID !== '') {
					ctx.setVariable("correlationID", incomingdata.data[0].messageID);
				}
			}
			else{
				ctx.setVariable("correlationID", id);
			}
			if (incomingdata.data[0].jobDisplayID) {
				if (incomingdata.data[0].jobDisplayID !== undefined || incomingdata.data[0].jobDisplayID !== null || incomingdata.data[0].jobDisplayID !== '') {
					ctx.setVariable("jobDisplayID", incomingdata.data[0].jobDisplayID);
				}
			}
			if (incomingdata.data[0].jobID) {
				if (incomingdata.data[0].jobID !== undefined || incomingdata.data[0].jobID !== null || incomingdata.data[0].jobID !== '') {
					ctx.setVariable("jobID", incomingdata.data[0].jobID);
				}
			}
			if (incomingdata.data[0].crew.externalID) {
				if (incomingdata.data[0].crew.externalID !== undefined || incomingdata.data[0].crew.externalID !== null || incomingdata.data[0].crew.externalID !== '') {
					ctx.setVariable("crewDisplayID", incomingdata.data[0].crew.externalID);
				}
			}
			if (incomingdata.data[0].createdAt) {
				if (incomingdata.data[0].createdAt !== undefined || incomingdata.data[0].createdAt !== null || incomingdata.data[0].createdAt !== '') {
					ctx.setVariable("createdAt", incomingdata.data[0].createdAt);
				}
			}
		}
		if (lookupResponse) {
			if (lookupResponse.lookupRep.type[0].label) {
				if (lookupResponse.lookupRep.type[0].label !== undefined || lookupResponse.lookupRep.type[0].label !== null || lookupResponse.lookupRep.type[0].label !== '') {
					ctx.setVariable("assignmentStatus", lookupResponse.lookupRep.type[0].label);
				}
			}
		}
	}
});
