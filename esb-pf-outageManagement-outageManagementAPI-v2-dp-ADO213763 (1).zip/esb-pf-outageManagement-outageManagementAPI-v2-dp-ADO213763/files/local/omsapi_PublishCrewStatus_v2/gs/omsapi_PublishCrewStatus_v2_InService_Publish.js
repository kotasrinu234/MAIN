var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		 		  
		var payload=incomingdata;
		 var ctx = session.name("PublishCrewStatus_Inservice")|| session.createContext("PublishCrewStatus_Inservice");
		var StandaloneMQurl = session.parameters.MQPublishurl;
		var publishuri = {
			target: StandaloneMQurl,
			data: payload
			};
		urlopen.open(publishuri, function(error, response) {
		var hm = require('header-metadata');
		if (error) {
			 var ctx = session.name("PublishCrewStatus_Inservice")|| session.createContext("PublishCrewStatus_Inservice");
			var mqconnection = 'Forbidden';
			ctx.setVariable("mqconnection", mqconnection);
			logger.error(" omsapi_v2_Inservice_160 error while keeping message to queue is " + error);
			
			session.reject(" error while keeping message to queue is " + error);
		} else {	var mqrc = response.statusCode;

			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						hm.response.statusCode = 403
						session.reject("error while keeping message to queue is " + error);
					} else {
						logger.debug("MQResponsecode " + mqrc);
					}
				});
			} else {
				var ctx = session.name("PublishCrewStatus_Inservice") || session.createContext("PublishCrewStatus_Inservice");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(" omsapi_v2_Inservice_160 response code is urlopen.open error [MQRC=" + mqrc + "]");

				session.reject(" response code is urlopen.open error [MQRC=" + mqrc + "]");

			}
		}
	});
//		session.output.write(payload);

	}
	});