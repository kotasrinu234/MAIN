var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
var url = session.parameters.lookupURL;
var urlopen = require('urlopen');
var hm = require('header-metadata');
var ilsctx = session.name("ILS") || session.createContext("ILS");
var logger = console.options({
	'category': 'all'
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading Incoming Data" + JSON.stringify(error));
		session.reject(readAsJSONError);
	}
	else {
		var crewstatus = incomingdata.data[0].status;
		var workTypeID = incomingdata.data[0].workTypeID;
		var lookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "workType.workflows",
						"id": workTypeID,
						"status": crewstatus
					}
				]
			}
		}
		var LookupServiceResponse = {
			target: url,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
		try {
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "urlopen connect error with  LookupServiceResponse for crewstatus , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error(" urlopen connect error with  LookupServiceResponse for crewstatus " + JSON.stringify(error));
					session.reject(" urlopen connect error with  LookupServiceResponse for crewstatus " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in getting message from LookupServiceResponse for crewstatus , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error(" failure in getting message from LookupServiceResponse for crewstatus " + JSON.stringify(error));
								session.reject("failure in getting message from LookupServiceResponse for crewstatus " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from LookupServiceResponse " + responseData);
								var lookupResponse = JSON.parse(responseData);
								ctx.setVariable("lookupResponse", lookupResponse);
							}
						});
					} else {
						var errorinfo = "lookup service from LookupServiceResponse for crewstatus " + responseStatusCode + " , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("lookup service from LookupServiceResponse for crewstatus responsecode is " + responseStatusCode);
						session.reject("lookup service from  LookupServiceResponse for crewstatus responsecode is " + responseStatusCode);
					}
				}
			});
		}
		catch (error) {
			var errorinfo = "urlopen connect error with  LookupServiceResponse for crewstatus , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error(" urlopen connect error with  LookupServiceResponse for crewstatus " + JSON.stringify(error));
			session.reject(" urlopen connect error with  LookupServiceResponse for crewstatus " + JSON.stringify(error));
		}
	}
})
