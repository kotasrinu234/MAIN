var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var ctx = session.name("PublishCrewStatus")|| session.createContext("PublishCrewStatus");	
	var nullCheckRequired = session.parameters.nullCheckRequired;
	
	if(readAsJSONError) {
		logger.error("Error in reading incoming json data");
var ctx = session.name("PublishCrewStatus")|| session.createContext("PublishCrewStatus");
ctx.setVariable("schemacheck", 'input json parsing failed');

		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("PublishCrewStatus")|| session.createContext("PublishCrewStatus");
		var IncomingData = incomingdata;
		ctx.setVariable("IncomingData", IncomingData);
		var schemacheck;
		if(nullCheckRequired == 'yes'){
	
			
			var jobDisplayID = incomingdata.data[0].jobDisplayID;
			if (jobDisplayID === null || jobDisplayID === '' || jobDisplayID === undefined) {
				var errorinfo = "jobDisplayID is not present in input payload";
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error(' jobDisplayID is not present in input payload');
				session.reject('jobDisplayID is not present in input payload');
				ctx.setVariable("schemacheck", 'jobDisplayID is not present in input payload');

	        }
			
	
		}// closing nullcheck
	}
	});
