var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var ttl = session.parameters.TimetoLive;
var id = ilsctx.getVar("messageID");
var messageID;
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var crewstatus = incomingdata.data[0].status;
		if(incomingdata.data[0].messageID){
			messageID = incomingdata.data[0].messageID;
		}
		else{
			messageID = id;
		}
		
		var workTypeID = incomingdata.data[0].workTypeID;
		if (crewstatus === null || crewstatus === '' || crewstatus === undefined) {
			var createdAt = incomingdata.data[0].createdAt;
			var jobDisplayID = incomingdata.data[0].jobDisplayID;
			var crewExternalID;
			if (incomingdata.data[0].crew == undefined || incomingdata.data[0].crew == null || incomingdata.data[0].crew == '') {

			} else {
				crewExternalID = incomingdata.data[0].crew.externalID;
			}
			var payload;
			if (crewExternalID == undefined || crewExternalID == null || crewExternalID == '') {
				if (createdAt == undefined || createdAt == null || createdAt == '') {
					payload = {

						"messageID": messageID,
						"createdAt": '',
						"jobId": jobDisplayID,
						"crewId": '',
						"crewAssignment": '',
						"ttl": ttl
					}
				} else {
					payload = {

						"messageID": messageID,
						"createdAt": createdAt,
						"jobId": jobDisplayID,
						"crewId": '',
						"crewAssignment": '',
						"ttl": ttl
					}
				}

			} else {
				if (createdAt == undefined || createdAt == null || createdAt == '') {
					payload = {

						"messageID": messageID,
						"createdAt": '',
						"jobId": jobDisplayID,
						"crewId": crewExternalID,
						"crewAssignment": '',
						"ttl": ttl
					}
				}
				else {
					payload = {

						"messageID": messageID,
						"createdAt": createdAt,
						"jobId": jobDisplayID,
						"crewId": crewExternalID,
						"crewAssignment": '',
						"ttl": ttl
					}
				}

			}
			session.output.write(payload);
			var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
			var StandaloneMQurl = session.parameters.MQPublishurl;
			var publishuri = {
				target: StandaloneMQurl,
				data: payload
			};
			var info = " TargetURL :" + publishuri.target + "; Data :" + JSON.stringify(publishuri.data) + ". ";
			try {
				urlopen.open(publishuri, function(error, response) {
					var hm = require('header-metadata');
					if (error) {
						var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
						var mqconnection = 'Forbidden';
						var errorinfo = "omsapi_v2_158 error while keeping message to queue is, details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ctx.setVariable("mqconnection", mqconnection);
						logger.error(" omsapi_v2_158 error while keeping message to queue is " + errorinfo);
						session.reject(" error while keeping message to queue is " + errorinfo);
					} else {
						var mqrc = response.statusCode;

						if (mqrc == 0) {
							var replyMQMD = response.get({
								type: 'mq'
							}, 'MQMD');
							var replyMQRFH2 = response.get({
								type: 'mq'
							}, 'MQRFH2');
							response.readAsBuffer(function(readError, responseData) {
								if (readError) {
									hm.response.statusCode = 403
									var errorinfo = "error while keeping message to queue is, details are : 403 " + info + "; error info :" + readError;
									ilsctx.setVariable("errorDescription", errorinfo);
									session.reject("error while keeping message to queue is " + errorinfo);
								} else {
									logger.debug("MQResponsecode " + mqrc);
								}
							});
						} else {
							var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
							var mqconnection = 'Forbidden';
							ctx.setVariable("mqconnection", mqconnection);
							var errorinfo = "omsapi_v2_158 response code is urlopen.open error [MQRC=" + mqrc + "], details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error(" omsapi_v2_158 response code is urlopen.open error [MQRC=" + mqrc + "]" + errorinfo);
							session.reject(" response code is urlopen.open error [MQRC=" + mqrc + "]" + errorinfo);

						}
					}
				});
			} catch (error) {
				var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
				var mqconnection = 'Forbidden';
				var errorinfo = "omsapi_v2_158 error while keeping message to queue is, details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(" omsapi_v2_158 error while keeping message to queue is " + errorinfo);
				session.reject(" error while keeping message to queue is " + errorinfo);
			}
		} else {
			var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
			var lookupResponse = ctx.getVar("lookupResponse");
			var lookupcrewlabel;
			if (lookupResponse.lookupRep.type[0].result == 0) {
				lookupcrewlabel = lookupResponse.lookupRep.type[0].label;


				var createdAt = incomingdata.data[0].createdAt;
				var jobDisplayID = incomingdata.data[0].jobDisplayID;
				var crewExternalID;
				if (incomingdata.data[0].crew == undefined || incomingdata.data[0].crew == null || incomingdata.data[0].crew == '') {

				} else {
					crewExternalID = incomingdata.data[0].crew.externalID;
				}
				var payload;
				if (crewExternalID == undefined || crewExternalID == null || crewExternalID == '') {
					if (incomingdata.data[0].createdAt == undefined || incomingdata.data[0].createdAt == null || incomingdata.data[0].createdAt == '') {

						payload = {

							"messageID": messageID,
							"createdAt": '',
							"jobId": jobDisplayID,
							"crewId": '',
							"crewAssignment": lookupcrewlabel,
							"ttl": ttl
						}
					} else {
						payload = {

							"messageID": messageID,
							"createdAt": createdAt,
							"jobId": jobDisplayID,
							"crewId": '',
							"crewAssignment": lookupcrewlabel,
							"ttl": ttl
						}
					}

				} else {

					if (incomingdata.data[0].createdAt == undefined || incomingdata.data[0].createdAt == null || incomingdata.data[0].createdAt == '') {
						payload = {

							"messageID": messageID,
							"createdAt": '',
							"jobId": jobDisplayID,
							"crewId": crewExternalID,
							"crewAssignment": lookupcrewlabel,
							"ttl": ttl
						}
					} else {
						payload = {

							"messageID": messageID,
							"createdAt": createdAt,
							"jobId": jobDisplayID,
							"crewId": crewExternalID,
							"crewAssignment": lookupcrewlabel,
							"ttl": ttl
						}
					}


				}
				session.output.write(payload);
				var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
				var StandaloneMQurl = session.parameters.MQPublishurl;
				var publishuri = {
					target: StandaloneMQurl,
					data: payload
				};
				var info = " TargetURL :" + publishuri.target + "; Data :" + JSON.stringify(publishuri.data) + ". ";
				try {
					urlopen.open(publishuri, function(error, response) {
						var hm = require('header-metadata');
						if (error) {
							var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
							var mqconnection = 'Forbidden';
							var errorinfo = "omsapi_v2_158 error while keeping message to queue is, details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error(" omsapi_v2_158 error while keeping message to queue is " + errorinfo);
							session.reject(" error while keeping message to queue is " + errorinfo);
						} else {
							var mqrc = response.statusCode;

							if (mqrc == 0) {
								var replyMQMD = response.get({
									type: 'mq'
								}, 'MQMD');
								var replyMQRFH2 = response.get({
									type: 'mq'
								}, 'MQRFH2');
								response.readAsBuffer(function(readError, responseData) {
									if (readError) {
										hm.response.statusCode = 403
										var errorinfo = "error while keeping message to queue is , details are : 403 " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										session.reject("error while keeping message to queue is " + errorinfo);
									} else {
										logger.debug("MQResponsecode " + mqrc);
									}
								});
							} else {
								var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
								var mqconnection = 'Forbidden';
								ctx.setVariable("mqconnection", mqconnection);
								var errorinfo = "omsapi_v2_158 response code is urlopen.open error [MQRC=" + mqrc + "], details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error(" omsapi_v2_158 response code is urlopen.open error [MQRC=" + mqrc + "]");
								session.reject(" response code is urlopen.open error [MQRC=" + mqrc + "]");

							}
						}
					});
				} catch (error) {
					var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
					var mqconnection = 'Forbidden';
					var errorinfo = "omsapi_v2_158 error while keeping message to queue is, details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error(" omsapi_v2_158 error while keeping message to queue is " + errorinfo);
					session.reject(" error while keeping message to queue is " + errorinfo);
				}
				//		session.output.write(payload);

			}
			else {
				var jobid = incomingdata.data[0].id;
				var errorinfo = "Lookup service result of worktypeid " + workTypeID + " and crewstatus " + crewstatus + " for jobid " + jobid + "  LookupServiceResponse code is " + lookupResponse.lookupRep.type[0].result;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("lookup service result of worktypeid " + workTypeID + " and crewstatus " + crewstatus + " for jobid " + jobid + "  LookupServiceResponse code is " + lookupResponse.lookupRep.type[0].result);
				session.reject("lookup service result of worktypeid " + workTypeID + " and crewstatus " + crewstatus + " for jobid " + jobid + "LookupServiceResponse code is  " + lookupResponse.lookupRep.type[0].result);
			}

		}
	}
});
