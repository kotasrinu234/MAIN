<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

		<xsl:variable name="TransactionID">
			<xsl:copy-of
				select="dp:variable('var://service/global-transaction-id')" />

		</xsl:variable>

		<xsl:choose>
			<xsl:when
				test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
				<xsl:message dp:type="all" dp:priority="error">
					TransactionID:
					<xsl:value-of select="$TransactionID" />
					ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>

				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'401'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Unauthorized'" />
			</xsl:when>
			<xsl:when
				test="contains(dp:variable('var://service/error-code'),'0x00230001' )">

				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>

			<xsl:when
				test="contains(dp:variable('var://service/error-subcode'),'0x00c30025' )">
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>
			<xsl:when
				test="contains(dp:variable('var://context/PublishCrewStatus/mqconnection'),'Forbidden')">
				<xsl:message dp:type="all" dp:priority="error">
					TransactionID:
					<xsl:value-of select="$TransactionID" />
					ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>

				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'403'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Forbidden'" />
			</xsl:when>
			<xsl:when
				test="contains(dp:variable('var://context/PublishCrewStatus/schemacheck'),'input json parsing failed' )">
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of select="'Invalid JSON format'" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>

			<xsl:when
				test="contains(dp:variable('var://service/error-subcode'),'0x00030001' )">
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>

			<xsl:when
				test="contains(dp:variable('var://context/PublishCrewStatus/schemacheck'),'jobDisplayID is not present in input payload' )">
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'jobDisplayID is not present in input payload'" />
			</xsl:when>
			<xsl:when
				test="contains(dp:variable('var://service/error-message'),'Invalid object syntax' )">
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>

			<xsl:when
				test="contains(dp:variable('var://service/error-message'),'Invalid JSON syntax' )">
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>

			<xsl:when
				test="contains(dp:variable('var://service/error-message'),'Invalid JSON format' )">
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>

			<xsl:when
				test="contains(dp:variable('var://service/error-message'),'Invalid string syntax' )">
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>

			<xsl:when
				test="contains(dp:variable('var://service/error-subcode'),'0x00030001' )">
				<xsl:message dp:type="all" dp:priority="error">
					omsapi_v2_157 ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-response'" value="'400'" />
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Bad Request'" />
			</xsl:when>

			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">
					ErrorMessage:
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:message>
				<dp:set-variable
					name="'var://service/error-protocol-reason-phrase'"
					value="'Internal Error'" />
				<!-- <dp:set-variable name="'var://service/error-protocol-reason-phrase'" 
					value="concat('TransactionID: ',$TransactionID,dp:variable('var://service/error-message'))" 
					/> -->
			</xsl:otherwise>
		</xsl:choose>
		<dp:set-variable name="'var://context/error/errorDetail'" value="concat(dp:variable('var://service/error-protocol-response'), dp:variable('var://service/error-message'), dp:variable('var://service/error-protocol-reason-phrase'), dp:variable('var://context/ILS/errorDescription'))" />
	</xsl:template>
</xsl:stylesheet>
