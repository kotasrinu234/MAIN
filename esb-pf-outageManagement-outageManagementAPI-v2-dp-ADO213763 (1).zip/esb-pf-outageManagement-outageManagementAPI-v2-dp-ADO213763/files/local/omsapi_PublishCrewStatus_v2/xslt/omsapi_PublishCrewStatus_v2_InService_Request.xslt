<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"

	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:param name="dpconfig:nullCheckRequired"/>
	
	<xsl:template match="/">
	
	
	<xsl:variable name="inpayload">
	<xsl:copy-of select="."/>
	</xsl:variable>
	<xsl:variable name="parsed-nodeset">
    <dp:parse select="$inpayload"/>
</xsl:variable>
	<dp:set-variable name="'var://context/PublishCrewStatus_Inservice/inpayload'" value="$parsed-nodeset"/>
	<xsl:choose>
	<xsl:when test="string-length(normalize-space($parsed-nodeset/*[local-name()='CrewStatus']))&gt; 0">
	<xsl:if test = "contains( $dpconfig:nullCheckRequired,'yes')" >
	<xsl:choose>
	<xsl:when test="string-length(normalize-space($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='crew']/text()))&gt; 0">
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error"> crew is missing in input request</xsl:message>				
	<dp:set-variable name="'var://context/PublishCrewStatus/schemacheck'" value="'schema failed'" />
	<dp:reject>crew missing in input request</dp:reject>
	</xsl:otherwise>
	</xsl:choose>
	</xsl:if>
	
	<xsl:variable name="month">
	<xsl:value-of select="substring($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='date']/text(),1,2 )"/>
	</xsl:variable>
	<xsl:variable name="Indate">
	<xsl:value-of select="substring($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='date']/text(),3,2 )"/>
	</xsl:variable>	
		<xsl:variable name="year">
	<xsl:value-of select="substring($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='date']/text(),5,4 )"/>
	</xsl:variable>	
	<xsl:variable name="FinalDate">
	<xsl:value-of select="concat($month,'-',$Indate,'-',$year,'T')"/>
	</xsl:variable>
	<xsl:variable name="inTimehour">
	<xsl:value-of select="substring($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='time']/text(),1,2 )"/>
	</xsl:variable>
		<xsl:variable name="inTimemin">
	<xsl:value-of select="substring($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='time']/text(),3,2 )"/>
	</xsl:variable>
			<xsl:variable name="inTimesec">
	<xsl:value-of select="substring($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='time']/text(),5,2 )"/>
	</xsl:variable>

<xsl:variable name="ConvertedEstDate">
	<xsl:value-of select="string(concat($year,'-',$month,'-',$Indate,'T',$inTimehour,':',$inTimemin,':',$inTimesec))"/>
	</xsl:variable>
		<xsl:variable name="Jsonx_Message">
<!-- get system time-->
<xsl:variable select="substring-after(dp:variable('var://service/system/ident')/identification/current-time,' ')" name="tempVAR"/>
<!-- get daylight saving offset-->
<xsl:variable select="date:date-time()" name="rightNow"/>
<xsl:variable name="edes_cdts">
<xsl:choose>
	<xsl:when test="string-length(normalize-space($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='time']/text()))&gt; 0">
	<xsl:choose>
	<xsl:when test="string-length(normalize-space($parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='date']/text()))&gt; 0">
	

<xsl:variable name="hours">
<xsl:choose>
<xsl:when test="$tempVAR='EDT'">
<xsl:value-of select="'4'"/>
</xsl:when>
<xsl:when test="$tempVAR='EST'">
<xsl:value-of select="'5'"/>
</xsl:when>
<xsl:otherwise>
<xsl:value-of select="'0'"/>
</xsl:otherwise>
</xsl:choose>
</xsl:variable>
<xsl:variable name="dateTime">
                                    <xsl:value-of select="concat($year,'-',$month,'-',$Indate, 'T', $inTimehour,':', $inTimemin ,':', $inTimesec)" />
                                 </xsl:variable>
                                 
                                 <xsl:variable name="time">
                                    <xsl:call-template name="add-hours-to-dateTime">
                                       <xsl:with-param name="dateTime" select="$dateTime" />
                                       <xsl:with-param name="hours" select="$hours" />
                                    </xsl:call-template>
                                 </xsl:variable>
                                 
                                 <xsl:value-of select="concat($time,'Z')" />
                                 </xsl:when>
                                 </xsl:choose>                                
                                 </xsl:when>
                                 </xsl:choose>
                              </xsl:variable>


	 <json:object
				xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
				xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
				xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">
				
						<json:string name="createdAt">					
						<xsl:value-of select="$edes_cdts"/>
						</json:string>
						<json:string name = "jobId">
						<xsl:value-of select="$parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='event']/text()"/>
						</json:string>
						<json:string name = "crewId">
						<xsl:value-of select="$parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='crew']/text()"/>
						</json:string>
						<json:string name = "crewAssignment">
						<xsl:value-of select="$parsed-nodeset/*[local-name()='CrewStatus']/*[local-name()='status']/text()"/>
						</json:string>
				
			</json:object>
			</xsl:variable>
			<dp:set-variable name="'var://context/PublishCrewStatus_Inservice/PublishPayload'" value="$Jsonx_Message"/>
			
			<xsl:copy-of select="$Jsonx_Message"/> 		
	
	
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error"> omsapi_v2_157 incorrect input xml format </xsl:message>				
	<dp:reject>omsapi_v2_157 incorrect input xml format </dp:reject>
	</xsl:otherwise>
	</xsl:choose>
	
	</xsl:template>
	
   <xsl:template name="add-hours-to-dateTime">
      <xsl:param name="dateTime" />
      <xsl:param name="hours" />
      <xsl:variable name="dateTime-in-seconds">
         <xsl:call-template name="dateTime-to-seconds">
            <xsl:with-param name="dateTime" select="$dateTime" />
         </xsl:call-template>
      </xsl:variable>
      <xsl:variable name="total-seconds" select="$dateTime-in-seconds + 3600 * $hours" />
      <xsl:variable name="new-date">
         <xsl:call-template name="JDN-to-Gregorian">
            <xsl:with-param name="JDN" select="floor($total-seconds div 86400)" />
         </xsl:call-template>
      </xsl:variable>
      <xsl:variable name="t" select="$total-seconds mod 86400" />
      <xsl:variable name="h" select="floor($t div 3600)" />
      <xsl:variable name="r" select="$t mod 3600" />
      <xsl:variable name="m" select="floor($r div 60)" />
      <xsl:variable name="s" select="$r mod 60" />
      <xsl:value-of select="$new-date" />
      <xsl:text>T</xsl:text>
      <xsl:value-of select="format-number($h, '00')" />
      <xsl:value-of select="format-number($m, ':00')" />
      <xsl:value-of select="format-number($s, ':00.###')" />
   </xsl:template>
   <xsl:template name="dateTime-to-seconds">
      <xsl:param name="dateTime" />
      <xsl:variable name="date" select="substring-before($dateTime, 'T')" />
      <xsl:variable name="time" select="substring-after($dateTime, 'T')" />
      <xsl:variable name="year" select="substring($date, 1, 4)" />
      <xsl:variable name="month" select="substring($date, 6, 2)" />
      <xsl:variable name="day" select="substring($date, 9, 2)" />
      <xsl:variable name="hour" select="substring($time, 1, 2)" />
      <xsl:variable name="minute" select="substring($time, 4, 2)" />
      <xsl:variable name="second" select="substring($time, 7)" />
      <xsl:variable name="a" select="floor((14 - $month) div 12)" />
      <xsl:variable name="y" select="$year + 4800 - $a" />
      <xsl:variable name="m" select="$month + 12*$a - 3" />
      <xsl:variable name="jd" select="$day + floor((153*$m + 2) div 5) + 365*$y + floor($y div 4) - floor($y div 100) + floor($y div 400) - 32045" />
      <xsl:value-of select="86400*$jd + 3600*$hour + 60*$minute + $second" />
   </xsl:template>
   <xsl:template name="JDN-to-Gregorian">
      <xsl:param name="JDN" />
      <xsl:variable name="f" select="$JDN + 1401 + floor((floor((4 *$JDN + 274277) div 146097) *3) div 4) - 38" />
      <xsl:variable name="e" select="4*$f + 3" />
      <xsl:variable name="g" select="floor(($e mod 1461) div 4)" />
      <xsl:variable name="h" select="5*$g + 2" />
      <xsl:variable name="D" select="floor(($h mod 153) div 5 ) + 1" />
      <xsl:variable name="M" select="(floor($h div 153) + 2) mod 12 + 1" />
      <xsl:variable name="Y" select="floor($e div 1461) - 4716 + floor((14 - $M) div 12)" />
      <xsl:value-of select="$Y" />
      <xsl:value-of select="format-number($M, '-00')" />
      <xsl:value-of select="format-number($D, '-00')" />
   </xsl:template>
	</xsl:stylesheet>
