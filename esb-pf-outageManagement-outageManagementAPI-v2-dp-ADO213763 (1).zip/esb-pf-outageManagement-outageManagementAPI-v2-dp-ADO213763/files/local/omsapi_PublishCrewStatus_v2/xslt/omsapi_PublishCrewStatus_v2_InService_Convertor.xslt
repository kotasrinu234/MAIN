<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:dp="http://www.datapower.com/extensions"
version="1.0">

<dp:input-mapping href="omsapi_PublishCrewStatus_v2_InService_Request.ffd" type="ffd"/>

<!-- This stylesheet copies the input to the output -->
<xsl:output method="xml" omit-xml-declaration="yes"/>


<xsl:template match="/">
<xsl:value-of select="sampleFile/sampleTag" disable-output-escaping="yes" />
</xsl:template>
</xsl:stylesheet>