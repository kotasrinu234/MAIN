var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.entryDescription;
var exitDescription = session.parameters.exitDescription;
var apiName = session.parameters.apiName;
var messageType = session.parameters.messageType;
var exitDestination = session.parameters.Backendurl;
ctx.setVariable("messageType", messageType);
ctx.setVariable("apiName", apiName);
ctx.setVariable('entryDescription', entryDescription);
ctx.setVariable('exitDescription', exitDescription);
ctx.setVariable('exitDestination', exitDestination);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.messageID !== undefined || incomingdata.messageID !== null || incomingdata.messageID !== '') {
			ctx.setVariable("correlationID", incomingdata.messageID)
		}
		if (incomingdata.jobId !== undefined || incomingdata.jobId !== null || incomingdata.jobId !== '') {
			ctx.setVariable("jobDisplayID", incomingdata.jobId)
		}
		if (incomingdata.crewId !== undefined || incomingdata.crewId !== null || incomingdata.crewId !== '') {
			ctx.setVariable("crewDisplayID", incomingdata.crewId)
		}
		if (incomingdata.createdAt !== undefined || incomingdata.createdAt !== null || incomingdata.createdAt !== '') {
			ctx.setVariable("createdAt", incomingdata.createdAt)
		}
		if (incomingdata.crewAssignment !== undefined || incomingdata.crewAssignment !== null || incomingdata.crewAssignment !== '') {
			ctx.setVariable("assignmentStatus", incomingdata.crewAssignment)
		}
		if (incomingdata.ttl !== undefined || incomingdata.ttl !== null || incomingdata.ttl !== '') {
			ctx.setVariable("ttl", incomingdata.ttl)
		}
	}
});
