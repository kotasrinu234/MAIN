// js is used to perform oms call 
var urlopen = require('urlopen');
var ctx = session.name("PublishCrewStatus") || session.createContext("PublishCrewStatus");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		var Backendurl = session.parameters.Backendurl;
		var backendtoken = session.parameters.SubscriptionKey;
		var payload = incomingdata;
		var backendapicall = {
			target: Backendurl,
			sslClientProfile: 'omsapi_SendCrewStatus_v2_Client_Profile',
			method: 'POST',
			contentType: 'application/json',
			data: payload,
			headers: {
				'Ocp-Apim-Subscription-Key': backendtoken
			},

		};
		var info = " TargetURL :" + backendapicall.target + "; Method :" + backendapicall.method + "; Data :" + JSON.stringify(backendapicall.data) + ". ";
		try {
			urlopen.open(backendapicall, function(error, response) {
				if (error) {
					var errorinfo = "omsapi_159 urlopen connect error with connecting to backend api , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatus", '500');
					logger.error(" omsapi_159 urlopen connect error with connecting to backend api " + JSON.stringify(errorinfo));
					session.reject("urlopen connect error with connecting to backend api " + JSON.stringify(errorinfo));
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "omsapi_159 error message while reading response from backendapi , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", '500');
								logger.error(" omsapi_159 error message while reading response from backendapi" + JSON.stringify(error));
								session.reject(" error message while reading response from backendapi" + JSON.stringify(error));
							} else {
								//store status code with response body in context variable
								hm.response.statusCode = responseStatusCode;
								ctx.setVar("response", responseData);
							}
						});
					}
					else if(responseStatusCode == 400) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "omsapi_159 Error returned while updating backendapi , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", '400');
								logger.error("omsapi_159 Error returned while updating backendapi  statusCode is  " + JSON.stringify(error));
								session.reject("Error returned while updating backendapi  statusCode is  " + JSON.stringify(error));
							} else {
								logger.info(" omsapi_159 Error returned while updating backendapi  statusCode " + responseStatusCode + " " + responseData);
							}
						});

					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "omsapi_159 Error returned while updating backendapi , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", '500');
								logger.error("omsapi_159 Error returned while updating backendapi  statusCode is  " + JSON.stringify(error));
								session.reject("Error returned while updating backendapi  statusCode is  " + JSON.stringify(error));
							} else {
								var errorinfo = "omsapi_159 Error returned while updating backendapi  statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", responseStatusCode);
								logger.error(" omsapi_159 Error returned while updating backendapi  statusCode " + responseStatusCode + " " + responseData);
								session.reject("urlopen connect error with connecting to backend api " + responseStatusCode + " " + responseData);

							}
						});

					}
				}
			});
		} catch (error) {
			var errorinfo = "omsapi_159 urlopen connect error with connecting to backend api , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", '500');
			logger.error(" omsapi_159 urlopen connect error with connecting to backend api " + JSON.stringify(errorinfo));
			session.reject("urlopen connect error with connecting to backend api " + JSON.stringify(errorinfo));
		}
	}
});
