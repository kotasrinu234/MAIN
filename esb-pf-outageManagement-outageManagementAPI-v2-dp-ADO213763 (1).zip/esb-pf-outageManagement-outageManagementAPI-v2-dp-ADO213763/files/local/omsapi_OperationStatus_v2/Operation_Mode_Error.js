//This gatewayscript is used to frame the error response when any error has occured
var hm = require('header-metadata');
var sm = require('service-metadata');
hm.current.statusCode = '500';
hm.response.set("Content-type", "application/json")
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var errctx = session.name("ILS") || session.createContext("ILS");
var errorInfo = ilsctx.getVariable("errorDescription");
var errorMessage = sm.getVar('var://service/error-message');
var logger = console.options({
    'category': 'all'
});
var errDetail = {};
if(errorMessage == 'Rejected by policy.'){
	errDetail.errCode = '401 Unauthorized '
}
if (errorInfo === null || errorInfo === '' || errorInfo === undefined) {
	errDetail.errorDetail = sm.getVar('var://service/error-message');
}
else{
	errDetail.errorDetail = errorInfo;
}
errctx.setVariable("errorInfo", errDetail);

logger.error("omsapiv2_145:error :" + errorMessage);
var obj = {};
obj.errorMessage = sm.getVar('var://service/error-message');
obj.errorCode = sm.getVar('var://service/error-code');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
session.output.write(obj);
