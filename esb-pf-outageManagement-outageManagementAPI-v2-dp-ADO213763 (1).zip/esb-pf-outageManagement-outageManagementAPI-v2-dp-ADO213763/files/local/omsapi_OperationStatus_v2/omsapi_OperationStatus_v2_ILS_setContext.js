var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.entryDescription;
var exitDescription = session.parameters.exitDescription;
var apiName = session.parameters.apiName;
var messageType = session.parameters.messageType;
var exitDestination = session.parameters.exitDestination;
ctx.setVariable("exitDestination", exitDestination);
ctx.setVariable("messageType", messageType);
ctx.setVariable("apiName", apiName);
ctx.setVariable('entryDescription', entryDescription);
ctx.setVariable('exitDescription', exitDescription);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.data[0].createdAt) {
			if (incomingdata.data[0].createdAt !== undefined || incomingdata.data[0].createdAt !== null || incomingdata.data[0].createdAt !== '') {
				ctx.setVariable("sourceEventTimestamp", incomingdata.data[0].createdAt);
			}
		}
	}
});
