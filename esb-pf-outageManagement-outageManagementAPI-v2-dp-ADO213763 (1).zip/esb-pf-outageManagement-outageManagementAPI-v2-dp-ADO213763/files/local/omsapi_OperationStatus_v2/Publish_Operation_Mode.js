var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var lookupURL = session.parameters.lookUpURL;
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
session.input.readAsJSON(function(error, json) {
	if (error) {
		var errorinfo = "omsapiv2_131:Error in reading incoming data";
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapiv2_131:Error in reading incoming data");
		session.reject("Error in reading incoming data")
	} else {
		/* validation of input data*/
		var nullcheck = session.parameters.nullcheck;
		if (nullcheck == 'yes') {
			console.log("json" + JSON.stringify(json));
			var operationModeID = json.data[0].operationModeID;
			if (operationModeID === null || operationModeID === '' || operationModeID === undefined) {
				var errorinfo = "omsapiv2_132:operationModeID not found.";
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapiv2_132:operationModeID not found.");
				session.reject('operationModeID not found.');
			} else {
				var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
				ctx.setVariable("operationModeID", operationModeID);
			}
			var createdAt = json.data[0].createdAt;
			if (createdAt === null || createdAt === '' || createdAt === undefined) {
				var errorinfo = "omsapiv2_133:createdAt not found.";
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapiv2_133:createdAt not found.");
				session.reject('createdAt not found.');
			} else {
				var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
				ctx.setVariable("createdAt", createdAt);
			}
			function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
			var id = uuidv4();
			var messageID;
			if (json.messageID) {
				if (json.messageID !== null || json.messageID !== '' || json.messageID !== undefined) {
					messageID = json.messageID;
				}
			}
			else {
				messageID = id
			}
			ilsctx.setVariable("correlationID", messageID);
		}
		var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
		ctx.setVariable("Incoming_json", json);
		var lookupMessage = {
			"lookupReq": {
				"type": [{
					"name": "operationModes",
					"id": operationModeID
				}]
			}
		}
		var LookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
		urlopen.open(LookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "omsapiv2_134:urlopen connect error with LookupServiceResponse, details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapiv2_134:urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
				session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				logger.debug("response:" + response);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "omsapiv2_135:failure in reading message from LookupServiceResponse, details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_135:failure in reading message from LookupServiceResponse" + JSON.stringify(error));
							session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));

						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("omsapiv2_136:response received from LookupServiceResponse " + JSON.stringify(responseData));
							if (responseData.lookupRep.type[0].result == 0) {
								var mode = responseData.lookupRep.type[0].label;
								ilsctx.setVariable("operationModeDisplayID", mode);
								logger.debug("Mode:" + mode);
								var obj = {
									"messageID": messageID,
									"createdAt": createdAt,
									"mode": mode
								}
								if (json.data[0].createdByUserName != undefined) {
									obj.createdBy = json.data[0].createdByUserName;
								}


								var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
								ctx.setVariable("Publishing_Payload", obj);
								session.output.write(obj);
							} else {
								ctx.setVariable("Mode", '');
								var mode = '';
								var errorinfo = "mode is blank., details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								session.reject('mode is blank.');
							}
						}
					});
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from LookupService, details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from LookupService  " + JSON.stringify(error));
							session.reject("failure in reading message from LookupService ");
						} else {
							var errorinfo = "Error code returned from from LookupService  " + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("Error code returned from from LookupService  " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from from LookupService " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
});
