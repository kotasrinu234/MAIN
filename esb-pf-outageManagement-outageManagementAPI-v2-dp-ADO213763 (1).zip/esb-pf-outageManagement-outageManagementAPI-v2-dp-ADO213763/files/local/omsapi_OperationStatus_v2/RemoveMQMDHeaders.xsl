<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/json" 
	extension-element-prefixes="dp" exclude-result-prefixes="dp da com max sr soapenv">
	<xsl:output method="xml" />
	<xsl:template match="/">
		<dp:remove-http-response-header name="MQMD" />
		<dp:remove-http-response-header name="X-MQRFH2-Data-0" />
		<dp:remove-http-response-header name="X-MQRFH2-Data-1" />
		<dp:remove-http-response-header name="MQRFH2" />
	</xsl:template>
</xsl:stylesheet>
