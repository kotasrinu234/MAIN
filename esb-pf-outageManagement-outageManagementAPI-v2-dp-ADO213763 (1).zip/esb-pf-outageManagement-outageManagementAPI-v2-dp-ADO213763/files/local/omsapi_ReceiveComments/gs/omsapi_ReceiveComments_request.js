var ctxadd = session.name("omsapi") || session.createContext("omsapi");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var backendURL = '';
var URL = '';
var commentURL = '';
var TokenValue = '';
var userId = '';
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("omsapi_ReceiveComments") || session.createContext("omsapi_ReceiveComments");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var omsExternalURL = session.parameters.omsExternalURL;
var currentDateTime = new Date().toISOString();
var currentDate = DateConversion(currentDateTime);
ctx.setVar("currentDate", currentDate);
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		hm.response.statusCode = 500
		session.output.write(readAsJSONError);
	} else {
		sm.setVar('var://service/mpgw/skip-backside', true);
		var callid = incomingdata.id;
		var inputcomment = incomingdata.comment;
		userId = incomingdata.userId;
		if (userId === null || userId === '' || userId === undefined) {
			var CommentPayload = {
				comment: inputcomment
			};
		}
		else {
			var CommentPayload = {
				comment: userId + ':' + inputcomment
			};
		}
		if (userId == 'URMAApp') {
			TokenValue = session.parameters.apiToken_Urma;
		} else if (userId == 'OutageApp') {
			TokenValue = session.parameters.apiToken_OutageApp;
		} else {
			TokenValue = session.parameters.apiToken
		}
		//contion to set URL based on the Query parameter objectType
		var replyMQRFH2 = hm.current.get('MQRFH2');
		var domTree = undefined;
		try {
			// use XML.parse() to parse the xmlString into a DOM tree structure
			domTree = XML.parse(replyMQRFH2);
		} catch (error) {
			// there was an error while parsing the XML string
			console.error('error parsing XML string ' + error);
			throw error;
		}
		var transform = require('transform');
		transform.xpath('/MQRFH2/NameValueData/NameValue/usr/URIExtract/text()', domTree, function(error, URINode) {
			if (error) {
				console.error('error while executing /library/book/title/text() xpath - ' + error);
				throw error;
			} else {
				var URI = URINode.item(0).textContent;
				ctx.setVariable("URIExtract", URI);
				if (URI == 'CALL') {
					backendURL = omsExternalURL + '/api/ServiceType/Electric/Call/Query?isInternalIDs=false&includeFields=notes,id';
				} else if (URI == 'JOB') {
					backendURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + callid + '/Comment';
					URL = URL = omsExternalURL + '/api/ServiceType/Electric/Job/' + callid + '?includeFields=id';
				} else if (URI == 'CREWASSIGNMENT') {
					backendURL = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + callid + '/Comment';
					URL = URL = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/Query?displayIDs=' + callid + '&includeFields=id';
				} else {
					throw error;
				}
				if (URI == 'CALL') {
					var causeCodeapi = {
						target: backendURL,
						sslClientProfile: 'omsapi_addComments_ClientProfile',
						method: 'POST',
						contentType: 'application/json',
						headers: {
							'osiApiToken': TokenValue
						},
						data: [callid]
					};
					var payload = {
						callid
					}
					session.output.write(payload);
				}
				else {
					var causeCodeapi = {
						target: backendURL,
						sslClientProfile: 'omsapi_ReceiveComments_ClientProfile',
						method: 'POST',
						contentType: 'application/json',
						headers: {
							'osiApiToken': TokenValue
						},
						data: CommentPayload
					}
					session.output.write(CommentPayload);
				}
				var commentinfo = " TargetURL :" + causeCodeapi.target + "; Method :" + causeCodeapi.method + "; Data :" + JSON.stringify(causeCodeapi.data) + ". ";
				try {
					urlopen.open(causeCodeapi, function(error, response) {
						if (error) {
							session.output.write(error);
							hm.response.statusCode = 500;
							var retryinfo = "connection failure , details are : " + commentinfo + "; retry info :" + error;
							ctx.setVariable("errorDescription", retryinfo);
							ilsctx.setVariable("exitDescription", retryinfo);
							ilsctx.setVariable("exitStatus", "500");
							ctx.setVariable("Retry", "yes");
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										hm.response.statusCode = 500
										session.output.write(error);
									} else {
										if (responseData.length === 0) {
											ctxadd.setVariable("Statuscode", '404');
											var errorinfo = "404 : Id not found ";
											ilsctx.setVariable("errorStatus", "404");
											ctx.setVariable("errorDescription", errorinfo);
											session.reject('Not found');
										}
										else {
											if (URI == 'CALL') {
												if (responseData[0].notes) {
													var id = responseData[0].id;
													var notes = responseData[0].notes;
													if (notes === undefined || notes === null || notes === '') {
														var patchURL = omsExternalURL + '/api/ServiceType/Electric/Call/' + id;
														var payload = currentDate + ":" + incomingdata.comment;
														var patchPayload = {
															"notes": payload
														};
														patchAPI(patchURL, patchPayload)
													}
													else {
														//	var delimiter = session.parameters.delimiter;
														var delimiter = session.parameters.delimiter.replace(/\\n/g, "\n");
														var patchURL = omsExternalURL + '/api/ServiceType/Electric/Call/' + id;
														var payload = notes + delimiter + currentDate + ":" + incomingdata.comment;
														var patchPayload = {
															"notes": payload
														};
														patchAPI(patchURL, patchPayload)
													}
												}
												else {
													var id = responseData[0].id;
													var patchURL = omsExternalURL + '/api/ServiceType/Electric/Call/' + id;
													var payload = currentDate + ":" + incomingdata.comment;
													var patchPayload = {
														"notes": payload
													};
													patchAPI(patchURL, patchPayload)
												}
											}
										}
									}
								});
							} else if (responseStatusCode == 400) {
								if (URI == 'CALL') {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											//dp:reject stop the transaction and go error rule with error code and description
											var errorinfo = "failure in reading message from oms call , details are : " + info + "; error info :" + error;
											ctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", '400');
											logger.error('failure in reading message from oms call ')
											session.reject("failure in reading message from oms call ");
										} else {
											var errorinfo = "Error code returned from oms call   " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
											ctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", responseStatusCode);
											logger.error("Error code returned from oms call   " + responseStatusCode + " " + responseData);
											session.reject("Error code returned from oms call   " + responseStatusCode + " " + responseData);
										}
									});
								} else {
									var options = {
										target: URL,
										sslClientProfile: 'omsapi_client_profile',
										method: 'GET',
										contentType: 'application/json',
										headers: {
											'osiApiToken': TokenValue
										},
									};
									var getinfo = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
									try {
										urlopen.open(options, function(error, response) {
											if (error) {
												session.output.write(error);
												hm.response.statusCode = 500
												ctx.setVariable("Retry", "yes");
												ilsctx.setVariable("exitStatus", "500");
												ilsctx.setVariable("exitDescription", error);
											}
											else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsJSON(function(error, responseData) {
														if (error) {
															hm.response.statusCode = 500
															session.output.write(error);
														} else {
															if (responseData.length === 0) {
																ctxadd.setVariable("Statuscode", '404');
																var errorinfo = "404 Id not found , details are : " + getinfo + "; error info :" + error;
																ctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "404");
																logger.error('Id not found');
																session.reject('Not found');
															} else {

																if (URI == 'CALL') {
																	var id = responseData[0].id;
																	commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + id + '/Comment';
																} else if (URI == 'JOB') {
																	var id = responseData.id;
																	commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/Comment';
																} else {
																	var id = responseData[0].id;
																	commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + id + '/Comment';
																}
																commentAPI(commentURL, CommentPayload, TokenValue)
															}
														}
													});
												} else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															//dp:reject stop the transaction and go error rule with error code and description    
															var errorinfo = "failure in reading message from GetCall api , details are : " + getinfo + "; error info :" + error;
															ctx.setVariable("errorDescription", errorinfo);
															ilsctx.setVariable("errorStatus", "500");
															session.reject("failure in reading message from GetCall api");
														} else {
															var errorinfo = "Error code returned from GetCall api  " + responseStatusCode + " , details are : " + getinfo + "; response info :" + responseData;
															ctx.setVariable("errorDescription", errorinfo);
															ilsctx.setVariable("exitDescription", errorinfo);
															if (responseStatusCode == 401 || responseStatusCode == 404) {
																ilsctx.setVariable("errorStatus", responseStatusCode);
																session.reject(errorinfo);
															}
															else {
																ctx.setVariable("Retry", "yes");
																ilsctx.setVariable("exitStatus", responseStatusCode);
															}
														}
													});
												}
											}
										});
									}
									catch (error) {
										session.output.write(error);
										hm.response.statusCode = 500
										ilsctx.setVariable("exitDescription", error);
										ilsctx.setVariable("exitStatus", "500");
										ctx.setVariable("Retry", "yes");
									}
								}
							} else if (responseStatusCode == 401) {
								response.readAsBuffer(function(error, ErrorresponseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										var errorinfo = "401 Not Authorized , details are : " + commentinfo + "; error info :" + error;
										ctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "401");
										logger.error("Not Authorized" + JSON.stringify(error));
										session.reject("401 Not Authorized");
									} else {
										var errorObj = {};
										errorObj.statusCode = response.statusCode;
										errorObj.reasonPhrase = ErrorresponseData;
										var errorinfo = "Details are : " + commentinfo + "; error info :" + responseStatusCode + ErrorresponseData;
										ctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "401");
										logger.error(errorinfo);
										session.reject(errorinfo);
										hm.response.statusCode = response.statusCode
									}
								});
							} else {
								response.readAsBuffer(function(error, ErrorresponseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										var errorinfo = "failure reading response from comments api , details are : " + commentinfo + "; error info :" + error;
										ctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "500");
										logger.error("failure reading response from comments api" + JSON.stringify(error));
										session.output.write("failure reading response from comments api");
									} else {
										var errorObj = {};
										errorObj.statusCode = response.statusCode;
										errorObj.reasonPhrase = ErrorresponseData;
										var retryinfo = "omsapi_108 Error response code received from comments api Status code is " + responseStatusCode + " and the reason is " + ErrorresponseData
										logger.error("omsapi_108 Error response code received from comments api Status code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
										session.output.write(errorObj);
										hm.response.statusCode = response.statusCode
										ctx.setVariable("errorDescription", retryinfo);
										ilsctx.setVariable("exitDescription", retryinfo);
										if (responseStatusCode == 401 || responseStatusCode == 404) {
											ilsctx.setVariable("errorStatus", responseStatusCode);
											session.reject(retryinfo);
										}
										else {
											ctx.setVariable("Retry", "yes");
											ilsctx.setVariable("exitStatus", responseStatusCode);
										}
									}
								});
							}
						}
					});
				}
				catch (error) {
					session.output.write(error);
					hm.response.statusCode = 500;
					var retryinfo = "connection failure , details are : " + commentinfo + "; retry info :" + error;
					ctx.setVariable("errorDescription", retryinfo);
					ilsctx.setVariable("exitDescription", retryinfo);
					ilsctx.setVariable("exitStatus", "500");
					ctx.setVariable("Retry", "yes");
				}
			}
		});
	}
});
function commentAPI(commentURL, CommentPayload, TokenValue) {
	//Performing oms call to update the comment
	var commentUriapi = {
		target: commentURL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': TokenValue
		},
		data: CommentPayload
	};
	var commentUriinfo = " TargetURL :" + commentUriapi.target + "; Method :" + commentUriapi.method + "; Data :" + JSON.stringify(commentUriapi.data) + ". ";
	session.output.write(CommentPayload);
	try {
		urlopen.open(commentUriapi, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with Get commentUriapi , details are : " + commentUriinfo + "; error info :" + error;
				ctx.setVariable("errorDescription", errorinfo);
				logger.error("urlopen connect error with Get commentUriapi" + JSON.stringify(error));
				ilsctx.setVariable("exitDescription", errorinfo);
				ilsctx.setVariable("exitStatus", "500");
				ctx.setVariable("Retry", "yes");
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message from commentUriapi , details are : " + commentUriinfo + "; error info :" + error;
							ctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", "500");
							logger.error(" failure in reading message from commentUriapi" + JSON.stringify(error));
							session.reject(" failure in reading message from commentUriapi" + JSON.stringify(error));
						} else {

						}
					});
				} else if (responseStatusCode == 401) {
					response.readAsBuffer(function(error, ErrorresponseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "401 Not Authorized , details are : " + commentUriinfo + "; error info :" + error;
							ctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", "401");
							logger.error("Not Authorized" + JSON.stringify(error));
							session.reject("401 Not Authorized");
						} else {
							var errorinfo = "Details are : " + commentUriinfo + "; error info :" + responseStatusCode + ErrorresponseData;
							ctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", "401");
							logger.error(errorinfo);
							session.reject(errorinfo);
							hm.response.statusCode = response.statusCode
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from commentUriapi api , details are : " + commentUriinfo + "; error info :" + error;
							ctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", "500");
							logger.error("failure in reading message from commentUriapi api");
							session.reject("failure in reading message from commentUriapi api");
						} else {
							var errorinfo = "Error code returned from commentUriapi api  " + responseStatusCode + " , details are : " + commentUriinfo + "; response info :" + responseData;
							ctx.setVariable("errorDescription", errorinfo);
							logger.error("Error code returned from commentUriapi api  " + responseStatusCode + " " + responseData);
							ilsctx.setVariable("exitDescription", errorinfo);
							if (responseStatusCode == 404) {
								ilsctx.setVariable("errorStatus", "404");
								session.reject(errorinfo);
							}
							else {
								ctx.setVariable("Retry", "yes");
								ilsctx.setVariable("exitStatus", responseStatusCode);
							}
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "urlopen connect error with Get commentUriapi , details are : " + commentUriinfo + "; error info :" + error;
		ctx.setVariable("errorDescription", errorinfo);
		logger.error("urlopen connect error with Get commentUriapi" + JSON.stringify(error));
		ilsctx.setVariable("exitDescription", errorinfo);
		ilsctx.setVariable("exitStatus", "500");
		ctx.setVariable("Retry", "yes");
	}
}

function patchAPI(patchURL, obj) {
	//Performing oms call to update the notes
	session.output.write(obj);
	var patchUriapi = {
		target: patchURL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': TokenValue
		},
		data: obj
	};
	var info = " TargetURL :" + patchUriapi.target + "; Method :" + patchUriapi.method + "; Data :" + JSON.stringify(patchUriapi.data) + ". ";
	try {
		urlopen.open(patchUriapi, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with patchUriapi , details are : " + info + "; error info :" + error;
				ctx.setVariable("errorDescription", errorinfo);
				ctx.setVariable("errorStatusCode", '500');
				logger.error("urlopen connect error with patchUriapi" + JSON.stringify(error))
				ilsctx.setVariable("exitDescription", errorinfo);
				ilsctx.setVariable("exitStatus", "500");
				ctx.setVariable("Retry", "yes");
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message from patchUriapi , details are : " + info + "; error info :" + error;
							ctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", '500');
							logger.error('failure in reading message from patchUriapi" + JSON.stringify(error)')
							session.reject(" failure in reading message from patchUriapi" + JSON.stringify(error));
						} else {

						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description  
							var errorinfo = "failure in reading message from patchUriapi api , details are : " + info + "; error info :" + error;
							ctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", '500');
							logger.error("failure in reading message from patchUriapi api");
							session.reject("failure in reading message from patchUriapi api");
						} else {
							var errorinfo = "Error code returned from patchUriapi api  " + responseStatusCode + " , details are : " + info + "; error info :" + error;
							ctx.setVariable("errorDescription", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							logger.error("Error code returned from patchUriapi api  " + responseStatusCode + " " + responseData);
							ilsctx.setVariable("exitDescription", errorinfo);
							if (responseStatusCode == 401 || responseStatusCode == 404) {
								ilsctx.setVariable("errorStatus", responseStatusCode);
								session.reject(errorinfo);
							}
							else {
								ctx.setVariable("Retry", "yes");
								ilsctx.setVariable("exitStatus", responseStatusCode);
							}
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "urlopen connect error with Get patchUriapi , details are : " + info + "; error info :" + error;
		ctx.setVariable("errorDescription", errorinfo);
		ctx.setVariable("errorStatusCode", '500');
		logger.error("urlopen connect error with patchUriapi" + JSON.stringify(error))
		ilsctx.setVariable("exitDescription", errorinfo);
		ilsctx.setVariable("exitStatus", "500");
		ctx.setVariable("Retry", "yes");
	}
}
function DateConversion(incomingDateTime) {
	const date = new Date(incomingDateTime);
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	const hours = String(date.getHours()).padStart(2, '0');
	const minutes = String(date.getMinutes()).padStart(2, '0');
	const seconds = String(date.getSeconds()).padStart(2, '0');
	const formattedDate = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
	return formattedDate;
}
