var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.receiveCommentEntryDescription;
var exitDescription = session.parameters.receiveCommentExitDescription;
var messageType = session.parameters.receiveCommentMessageType;
var apiName = session.parameters.apiName;
ctx.setVariable("apiName", apiName);
var jobDetailCount = session.parameters.Count;
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.messageID) {
			if (incomingdata.messageID !== undefined || incomingdata.messageID !== null || incomingdata.messageID !== '') {
				ctx.setVariable("correlationID", incomingdata.messageID);
			}
		}
		if (incomingdata.id) {
			if (incomingdata.id !== undefined || incomingdata.id !== null || incomingdata.id !== '') {
				var id = incomingdata.id;
				if (id.length == jobDetailCount) {
					ctx.setVariable("jobID", id)

				}
				else {
					ctx.setVariable("jobDisplayID", id)
				}
			}
		}
	}
	if (incomingdata.userId) {
		if (incomingdata.userId !== undefined || incomingdata.userId !== null || incomingdata.userId !== '') {
			ctx.setVariable("userID", incomingdata.userId);
		}
	}
	ctx.setVariable("sourceEventTimestamp", new Date().toISOString());
});
