//js is used to create a link job
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsapi_SendOperationStatus_v2") || session.createContext("omsapi_SendOperationStatus_v2");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var ctx1 = session.name('ILS') || session.createContext('ILS');
var exitDescription = session.parameters.exitDescription;
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data" + readAsJSONError;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		//Call "POST http://nrtstpopas.dteco.com:50000/RESTAdapter/operationmode
		var ctx = session.name("omsapi_SendOperationStatus_v2") || session.createContext("omsapi_SendOperationStatus_v2");
		var CRBurl = session.parameters.CRBurl;
		ctx1.setVar("exitDestination", CRBurl);
		var payload = incomingdata;
		ctx.setVariable("CRB_IncomingData", payload);
		var CRBapi = {
			target: CRBurl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'POST',
			contentType: 'application/json',
			data: payload
		};
		var info = " TargetURL :" + CRBapi.target + "; Method :" + CRBapi.method + "; Data :" + JSON.stringify(CRBapi.data) + ". ";
		try {
			urlopen.open(CRBapi, function(error, response) {
				if (error) {
					var ctx = session.name("omsapi_SendOperationStatus_v2") || session.createContext("omsapi_SendOperationStatus_v2");
					ctx.setVariable("retry", 'yes');
					var errorinfo = "omsapi_SendOperationStatus_v2_001 urlopen connect error with omsapi_SendOperationStatus_v2 CRBapi post , details are : " + info + "; error info :" + error;
					ctx1.setVariable("exitDescription", errorinfo);
					ctx1.setVariable("exitStatus", "500");
					logger.error(" urlopen connect error with omsapi_SendOperationStatus_v2 CRBapi post is " + JSON.stringify(error));
					var ErrorTxt = " omsapi_SendOperationStatus_v2_001 urlopen connect error with omsapi_SendOperationStatus_v2 CRBapi post is " + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 || responseStatusCode == 202) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "error message while reading from omsapi_SendOperationStatus_v2 CRBapi post call , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error(" error message while reading from omsapi_SendOperationStatus_v2 CRBapi post call " + JSON.stringify(error));
								session.reject("error message while reading from omsapi_SendOperationStatus_v2 CRBapi post call " + JSON.stringify(error));
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response code recieved from call api is " + responseStatusCode);
								ctx1.setVariable("exitDescription", exitDescription);
								ctx1.setVariable("exitStatus", "0");
							}
						});
					} else {

						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from omsapi_SendOperationStatus_v2 CRBapi post call , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from omsapi_SendOperationStatus_v2 CRBapi post call is  " + JSON.stringify(error));
								session.reject("failure in reading message from omsapi_SendOperationStatus_v2 CRBapi post call is ");
							} else {
								var errorinfo = "response returned from omsapi_SendOperationStatus_v2 CRBapi post call is " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error(" response returned from omsapi_SendOperationStatus_v2 CRBapi post call is " + responseStatusCode + " " + responseData);
								session.reject("response returned from omsapi_SendOperationStatus_v2 CRBapi post call is " + responseStatusCode + " " + responseData);
							}
						});

					}
				}
			});
		}
		catch (error) {
			var ctx = session.name("omsapi_SendOperationStatus_v2") || session.createContext("omsapi_SendOperationStatus_v2");
			ctx.setVariable("retry", 'yes');
			var errorinfo = "omsapi_SendOperationStatus_v2_001 urlopen connect error with omsapi_SendOperationStatus_v2 CRBapi post , details are : " + info + "; error info :" + error;
			ctx1.setVariable("exitDescription", errorinfo);
			ctx1.setVariable("exitStatus", "500");
			logger.error(" urlopen connect error with omsapi_SendOperationStatus_v2 CRBapi post is " + JSON.stringify(error));
			var ErrorTxt = " omsapi_SendOperationStatus_v2_001 urlopen connect error with omsapi_SendOperationStatus_v2 CRBapi post is " + JSON.stringify(error);
			ctx.setVariable("ErrorTxt", ErrorTxt);
		}
		//call end
	}
});
