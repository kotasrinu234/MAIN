var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.entryDescription;
var apiName = session.parameters.apiName;
var messageType = session.parameters.messageType;
ctx.setVariable("messageType", messageType);
ctx.setVariable("apiName", apiName);
ctx.setVariable('entryDescription', entryDescription);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.messageID) {
			if (incomingdata.messageID !== undefined || incomingdata.messageID !== null || incomingdata.messageID !== '') {
				ctx.setVariable("correlationID", incomingdata.messageID);
			}
		} 
		if (incomingdata.mode) {
			if (incomingdata.mode !== undefined || incomingdata.mode !== null || incomingdata.mode !== '') {
				ctx.setVariable("operationModeDisplayID", incomingdata.mode);
			}
		}
		if (incomingdata.createdAt) {
			if (incomingdata.createdAt !== undefined || incomingdata.createdAt !== null || incomingdata.createdAt !== '') {
				ctx.setVariable("sourceEventTimestamp", incomingdata.createdAt);
			}
		}
	}
});
