//Final Response payload to OMS
var ctx = session.name("crewList") || session.createContext("crewList");
var responseStatusCode = ctx.getVariable("responseStatusCode");
var response = ctx.getVariable("responseOfAPI");

var logger = console.options({
    'category': 'all'
});

var arrayList = ctx.getVariable("arrayList");
if (arrayList != undefined){
session.output.write(arrayList);
}
else{		
	session.reject ("Error Response received "+responseStatusCode +" and response data is " +response);
}