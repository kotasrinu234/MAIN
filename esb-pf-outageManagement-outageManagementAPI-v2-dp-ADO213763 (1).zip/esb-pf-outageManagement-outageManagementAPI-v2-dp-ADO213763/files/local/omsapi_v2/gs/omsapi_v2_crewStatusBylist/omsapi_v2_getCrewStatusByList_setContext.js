//This gateway script is to set context variables

var ctx = session.name("crewList")|| session.createContext("crewList");

//Set stylesheet parameters to variables

var omsExternalURL = session.parameters.omsExternalURL;
var lookupURL = session.parameters.lookUpURL;
var apiToken = session.parameters.apiToken ;
var apiToken_chatbot = session.parameters.apiToken_chatbot;
var apiToken_maximo = session.parameters.apiToken_maximo;
var apiToken_reporting = session.parameters.apiToken_reporting;
var apiToken_urma = session.parameters.apiToken_Urma;

//Set the retrieved stylesheet parameters to context variables to use it within the gateway script

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
ctx.setVariable("apiToken_maximo", apiToken_maximo);
ctx.setVariable("apiToken_reporting", apiToken_reporting);
ctx.setVariable("apiToken_urma", apiToken_urma);
