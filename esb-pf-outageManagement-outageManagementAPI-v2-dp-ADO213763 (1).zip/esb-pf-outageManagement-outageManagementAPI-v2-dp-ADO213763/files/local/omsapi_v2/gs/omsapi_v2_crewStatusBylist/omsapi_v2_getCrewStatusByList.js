
// getCrewStatusByList
// This file is for get OMS calls and Lookup service calls
var sm = require('service-metadata');
var hm = require('header-metadata');
var ctx = session.name("crewList") || session.createContext("crewList");
var urlopen = require('urlopen');
var logger = console.options(
		{'category': 'all'}
		);
var incomingUrl = sm.getVar('var://service/URI');
var crewIds = incomingUrl.substring((incomingUrl.lastIndexOf("crewIds=") + 8));
logger.info("Actual Input values of CrewIds " + crewIds);
var crewIdList = crewIds.split("%2C");
logger.info("CrewIds " + crewIdList);
ctx.setVariable("CrewIds", crewIdList);
var crewIdLength = crewIdList.length;
logger.info("crewIdLength " + crewIdLength);

//Start API token check with current user
var omsExternalURL = ctx.getVariable("omsExternalURL");
var lookupURL = ctx.getVariable("lookupURL");
var apiToken_OutageStatusApp = ctx.getVariable("apiToken");
var apiToken_chatbot = ctx.getVariable("apiToken_chatbot");
var apiToken_maximo = ctx.getVariable("apiToken_maximo");
var apiToken_reporting = ctx.getVariable("apiToken_reporting");
var apiToken_urma = ctx.getVariable("apiToken_urma");
var context = session.name("current") || session.createContext("current");
var currentUser = context.getVar("user");
// End API token check with current user

//Checking if the crewId/crewId's present in the Input GET request
if ((incomingUrl.includes("crewIds=")) && (crewIds != null) && (crewIds != '')) {

    var ctx = session.name("crewList") || session.createContext("crewList");
    var arrayList = [];
    var externalid;
    var deprecated;
    var activeAssignmentCount;
    var type;
    var id;
    var jobDisplayId;
	var jobId;
    var crewStatus;
    var crewWorkTypeID;
    var crewStatusLabel;
    var crewType;
    
    // Start API token check with current user
    var incomingUser = currentUser;
    var apiToken;
    if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
        apiToken = apiToken_OutageStatusApp;
    } else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
        apiToken = apiToken_chatbot;
    } else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
        apiToken = apiToken_reporting;
    } else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
        apiToken = apiToken_maximo;
    } else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
				apiToken = apiToken_urma;
	}
    // End API token check with current user
    
    for (let i = 0; i < crewIdLength; i++) {
    	var ctx = session.name("crewList") || session.createContext("crewList");
        // Start GET crewAssignmentAPI call
        var crewIdStatusUri = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/Query?isInternalIDs=false&includeFields=id,externalID,type,activeAssignmentCount,deprecated';
        var tokenValue = apiToken;
        var crewIdStatusAPI = {
            target: crewIdStatusUri,
            sslClientProfile: 'omsapi_client_profile',
            method: 'POST',
            contentType: 'text',
            headers: {
                'osiApiToken': tokenValue
            },
            data: '["'+ crewIdList[i] +'"]'
        };
        urlopen.open(crewIdStatusAPI, function(error, response) {
            if (error) {
                logger.error("omsapi_v2_161:urlopen connect error with Get crewIdStatusAPI with error for crewId " + crewIdList[i] + " " + JSON.stringify(error));
                session.reject("urlopen connect error with Get crewIdStatusAPI with error for crewId " + crewIdList[i] + " " + JSON.stringify(error));
            } else {
                var responseStatusCode = response.statusCode;
                if (responseStatusCode == 200) {
                    logger.info("crewIdStatusAPI response status code 200 for crewId " + crewIdList[i]);
                    response.readAsBuffer(function(error, responseData) {
                        if (error) {
                            logger.error("Failure in reading message from Get crewIdStatusAPI for crewId " + crewIdList[i] + " " + JSON.stringify(error));
                            session.reject("Failure in reading message from Get crewIdStatusAPI for crewId " + crewIdList[i] + " " + JSON.stringify(error));
                        } else {
                            var ctx = session.name("crewList") || session.createContext("crewList");
                            hm.response.statusCode = responseStatusCode;
                            var getcrewIdStatusAPIResponse = JSON.stringify(JSON.parse(responseData));
                            ctx.setVariable("crewIdStatusResponseData_" + crewIdList[i], getcrewIdStatusAPIResponse);
                            var crewData = JSON.parse(getcrewIdStatusAPIResponse);
                            ctx.setVariable("crewIdStatusResponseData_" + crewIdList[i], crewData.length);

                        	if (crewData.length === 0){
                        		logger.info("omsapi_v2_163:CrewId not found or deprecated " + crewIdList[i]);
                                var crewNotFoundObject = {
                                        "crewId": crewIdList[i],
                                        "errorCode": "400",
                                        "errorDescription": "Crew not found or deprecated"
                                    };
                                    arrayList.push(crewNotFoundObject);
                                    ctx.setVariable("arrayList", arrayList);
                        	} else {
                            for (let j = 0; j < crewData.length; ++j) {
                                if ((crewData[j].id != undefined) && (crewData[j].id != null) && (crewData[j].id != '')) {
                                	id = crewData[j].id;
                                    ctx.setVariable("id_" + [j] + "_" + crewIdList[i], id);
                                } else {
                                	id = "";
                                }
                                
                                if ((crewData[j].externalID != undefined) && (crewData[j].externalID != null) && (crewData[j].externalID != '')) {
                                	externalid = crewData[j].externalID;
                                	ctx.setVariable("externalid_" + [j] + "_" + crewIdList[i], externalid);
                                } else {
                                	externalid = "";
                                }
                                 
                                if ((crewData[j].deprecated != undefined) && (crewData[j].deprecated != null) && (crewData[j].deprecated != '')) {
                                	deprecated = crewData[j].deprecated;
                                	ctx.setVariable("deprecated_" + [j] + "_" + crewIdList[i], deprecated);
                                } else {
                                	deprecated = "";
                                }
                                
                                if ((crewData[j].activeAssignmentCount != undefined) && (crewData[j].activeAssignmentCount != null) && (crewData[j].activeAssignmentCount != '')) {
                                	activeAssignmentCount = crewData[j].activeAssignmentCount;
                                	ctx.setVariable("activeAssignmentCount_" + [j] + "_" + crewIdList[i], activeAssignmentCount);
                                } else {
                                	activeAssignmentCount = "";
                                }
                                
                                if ((crewData[j].type != undefined) && (crewData[j].type != null) && (crewData[j].type != '')) {
                                	type = crewData[j].type;
                                	 ctx.setVariable("type_" + [j] + "_" + crewIdList[i], type);
                                } else {
                                	type = "";
                                }

                            if(id === null || deprecated === true ){
                            	logger.info("omsapi_v2_163:CrewId not found or deprecated " + crewIdList[i]);
                            	
                            	// 'CrewId' not found reason code 404
                                var crewNotFoundObject = {
                                    "crewId": crewIdList[i],
                                    "errorCode": "400",
                                    "errorDescription": "Crew not found or deprecated"
                                };
                                arrayList.push(crewNotFoundObject);
                                ctx.setVariable("arrayList", arrayList);
                            }
                            else{                 
                          	// activeAssignmentCount check for response mapping
                            	if (crewData[j].activeAssignmentCount === 0 ) {
                            		ctx.setVariable("activeAssignmentCountValue" + crewIdList[i], activeAssignmentCount);
                            		crewStatus = 'Available';
                            		ctx.setVariable("crewStatus", crewStatus);
                            		if(crewData[j].type !== null && crewData[j].type !== undefined)
                            			{
                            			var test = lookupFunction(crewIdList[i], crewStatus, crewData[j].type);
                            			} else {
                                		var test = lookupFunction(crewIdList[i], crewStatus);
                            			}
                            		}
                            	else {	
                            		  // Start crewAssignmentAPI call to fetch JobDisplayId, status & workTypeId
                                    var crewAssignmentUri = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + crewIdList[i] + '/CrewAssignment?excludeResolved=true&includeFields=status,jobID,jobDisplayID,workTypeID';
                                    var tokenValue = apiToken;
                                    var types = crewData[j].type;
	                                var crewAssignmentOptions = {
	                                        target: crewAssignmentUri,
	                                        sslClientProfile: 'omsapi_client_profile',
	                                        method: 'GET',
	                                        contentType: 'application/json',
	                                        headers: {
	                                            'osiApiToken': tokenValue
	                                        },
	                                    };
	                                urlopen.open(crewAssignmentOptions, function(error, response,  ) {
	                                    if (error) {
	                                        logger.error("omsapi_v2_164:urlopen connect error with Get crewAssignmentAPI with error for crewId " + crewIdList[i] + " " + JSON.stringify(error));
	                                        session.reject("urlopen connect error with Get crewAssignmentAPI with error for crewId " + crewIdList[i] + " " + JSON.stringify(error));
	                                    } else {
	                                        var responseStatusCode = response.statusCode;
	                                        if (responseStatusCode == 200) {
	                                            logger.info("crewAssignmentAPI response status code 200 for crewId " + crewIdList[i]);
	                                            response.readAsBuffer(function(error, responseData) {
	                                                if (error) {
	                                                    logger.error("Failure in reading message from Get crewAssignmentAPI for crewId " + crewIdList[i] + " " + JSON.stringify(error));
	                                                    session.reject("Failure in reading message from Get crewAssignmentAPI for crewId " + crewIdList[i] + " " + JSON.stringify(error));
	                                                } else {
	                                                    var ctx = session.name("crewList") || session.createContext("crewList");
	                                                    hm.response.statusCode = responseStatusCode;
	                                                    var getCrewAssignmentApiResponse = JSON.parse(responseData);
	                                                    ctx.setVariable("crewAssignmentResponseData_" + crewIdList[i], getCrewAssignmentApiResponse);
	                                                    
	                                                    for (let j = 0; j < getCrewAssignmentApiResponse.data.length; j++) {
	                                                        jobDisplayId = getCrewAssignmentApiResponse.data[j].jobDisplayID;
	                                                        ctx.setVariable("jobDisplayID_" + [j] + "_" + crewIdList[i], jobDisplayId);
															jobId = getCrewAssignmentApiResponse.data[j].jobID;
	                                                        ctx.setVariable("jobID_" + [j] + "_" + crewIdList[i], jobId);
	                                                        crewStatus = getCrewAssignmentApiResponse.data[j].status;
	                                                        ctx.setVariable("crewStatus_" + [j] + "_" + crewIdList[i], crewStatus);
	                                                        crewWorkTypeID = getCrewAssignmentApiResponse.data[j].workTypeID;
	                                                        ctx.setVariable("crewWorkTypeID_" + [j] + "_" + crewIdList[i], crewWorkTypeID);
	                                                        
	                                                        // Start joblookupService to fetch crewWorkTypeID label & crewType label
	                                                        if (types === 0 || types === null || types === undefined){
	                                                            var lookupMessage = {
	                                                                    "lookupReq": {
	                                                                        "type": [
	                                                                        {
	                                                                            "name": "workType.workflows",
	                                                                            "id": crewWorkTypeID,
	                                                                            "status": crewStatus
	                                                                        }      ]
	                                                                    }
	                                                                }
	                                                        } else {
	                                                        	var lookupMessage = {
	                                                                    "lookupReq": {
	                                                                        "type": [
	                                                                        {
	                                                                            "name": "workType.workflows",
	                                                                            "id": crewWorkTypeID,
	                                                                            "status": crewStatus
	                                                                        },
	                                                                        {
	                                                                        	"name": "crewTypes",
	                                                                        	"status": types
	                                                                        }
	                                                                        ]
	                                                                    }
	                                                                }
	                                                        }
                                                            var joblookupService = {
                                                                target: lookupURL,
                                                                method: 'POST',
                                                                contentType: 'application/json',
                                                                data: lookupMessage  
                                                            };
                                                           
                                                            urlopen.open(joblookupService, function(error, response) {
                                                                if (error) {
                                                                    logger.error("omsapi_v2_166:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
                                                                    session.reject("urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
                                                                } else {
                                                                    var responseStatusCode = response.statusCode;
                                                                    if (responseStatusCode == 200) {
                                                                        logger.info("lookupServiceAPI response status code 200 for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i]);
                                                                        response.readAsBuffer(function(error, responseData) {
                                                                            if (error) {
                                                                                logger.error("Failure in reading message to lookupServiceAPI Response for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
                                                                                session.reject("Failure in reading message to lookupServiceAPI Response for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
                                                                            } else {
                                                                                var ctx = session.name("crewList") || session.createContext("crewList");
                                                                                var lookupResponse = JSON.parse(responseData);
                                                                                ctx.setVariable("JobIdlookupResponse_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], lookupResponse);
                                                                                logger.info("JobIdlookupResponse" + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(lookupResponse));

                                                                                if (lookupResponse.lookupRep.type[0].result == 0) {
                                                                                    if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
                                                                                    	crewStatusLabel = lookupResponse.lookupRep.type[0].label;
                                                                                        ctx.setVariable("crewStatusLabel", crewStatusLabel);
                                                                                    } else {
                                                                                    	crewStatusLabel = "";
                                                                                    }
                                                                                } else {
                                                                                	crewStatusLabel = "";
                                                                                }
                                                                                
                                                                                if (lookupResponse.lookupRep.type[1] !== undefined) {
                                                                                    if ((lookupResponse.lookupRep.type[1].label != undefined) && (lookupResponse.lookupRep.type[1].label != null) && (lookupResponse.lookupRep.type[1].label != '')) {
                                                                                    	crewType = lookupResponse.lookupRep.type[1].label;
                                                                                        ctx.setVariable("crewType", crewType);
                                                                                    } else {
                                                                                    	crewType = "";
                                                                                    }
                                                                                } else {
                                                                                	crewType = "";
                                                                                }
                                                                                
                                                                             // Final payload structure should be sent to client applications
						                                                        var resultObject = {
						                                                                "crewId": crewIdList[i],
						                                                                "jobId": getCrewAssignmentApiResponse.data[j].jobID,
																						"jobDisplayId": getCrewAssignmentApiResponse.data[j].jobDisplayID,
						                                                                "crewStatus": crewStatusLabel,
						                                                                "LogonStatus": "",
						                                                                "crewType": crewType,
						                                                                "errorCode": "",
						                                                                "errorDescription":""
						                                                            };
						                                                            arrayList.push(resultObject);
						                                                            ctx.setVariable("arrayList", arrayList);
                                                                            }
                                                                        });
                                                                    }
                                                                    else{
                                                                    	logger.error("omsapi_v2_167:lookupServiceAPI response status code is not 200 to fetch crewType & crewStatusLabel" + crewIdList[i] + " responseCode" + responseStatusCode);
                                                                    }
                                                                    }  
                                                                });  // End of lookupService
	                                                    }

	                                                }
	                                            });
	                                        }
	                                        else{
	                                        	logger.error("omsapi_v2_165:crewAssignmentOptionsAPI response status code is not 200 to fetch crewAssignment info" + crewIdList[i] + " responseCode" + responseStatusCode);
	                                        }
	                                        }
	                                    });  // End GET crewAssigmentAPI call
                            		}
                            	}
                            	}
                           }
                          }
                        });
                }
                else{
                	logger.error("omsapi_v2_162:crewIdStatusAPI response status code is not 200 to fetch crewId info" + crewIdList[i] + " responseCode" + responseStatusCode);	
                }
            }
            });
    }  // End of 'for' loop for iterations of crewId/crewIds in the input request
}

// End if loop, crewId/crewId's are present in input request
else {
    ctx.setVariable("responseStatusCode", 404);
    logger.error("omsapi_v2_170:CrewId not found in the request");
    session.reject("CrewId not found in the request");
}


//Start Function to retrieve Lookup values and structure the response when activeAssignmentCount is 0
function lookupFunction(crewIdList, crewStatus, type)
{
	logger.info("Inside Function");
	var crewType;
	//LookupMessage
	if (type !== null && type !== undefined ) {
		  logger.info("Inside Function");
		  var lookupReqMessage = {
		      "lookupReq": {
		          "type": [{
				        "name": "crewTypes",
		              "status": type
		          }
		          ]
		      }
		  }
		  var lookupService = {
		          target: lookupURL,
		          method: 'POST',
		          contentType: 'application/json',
		          data: lookupReqMessage
		      };
		  urlopen.open(lookupService, function(error, response) {
		      if (error) {
		          logger.error("omsapi_v2_168:urlopen connect error with lookupServiceAPI for CrewType " + type + " " + crewIdList + " " + JSON.stringify(error));
		          session.reject("urlopen connect error with lookupServiceAPI for CrewType " + type + " " + crewIdList + " " + JSON.stringify(error));
		      } else {
		          var responseStatusCode = response.statusCode;
		          if (responseStatusCode == 200) {
		              logger.info("lookupServiceAPI response status code 200 for CrewType " + type + " " + crewIdList);
		              response.readAsBuffer(function(error, responseData) {
		                  if (error) {
		                      logger.error("Failure in reading message to lookupServiceAPI Response for CrewType " + type + " " + crewIdList + " " + JSON.stringify(error));
		                      session.reject("Failure in reading message to lookupServiceAPI Response for CrewType " + type + " " + crewIdList + " " + JSON.stringify(error));
		                  } else {
		                      var ctx = session.name("crewList") || session.createContext("crewList");
		                      var lookupResponse = JSON.parse(responseData);
		                      ctx.setVariable("CrewTypelookupResponse_" + crewType + "_" + crewIdList, lookupResponse);
		                      logger.info("CrewTypelookupResponse" + crewType + " " + crewIdList + " " + JSON.stringify(lookupResponse));
		                      if (lookupResponse.lookupRep.type[0].result == 0) {
		                          if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
		                          	crewType = lookupResponse.lookupRep.type[0].label;
		                              ctx.setVariable("crewType", crewType);
		                              
		                              // Final payload structure should be sent to client applications
		                              var resultObject = {
		                            		  "crewId": crewIdList,
		                            		  "jobId": "",
											  "jobDisplayId": "",
		                            		  "crewStatus": crewStatus,
		                            		  "LogonStatus": "",
		                            		  "crewType": crewType,
		                            		  "errorCode": "",
		                            		  "errorDescription":""
		                            		  };
		                              arrayList.push(resultObject);
		                              ctx.setVariable("arrayList", arrayList);
		                          } else {
		                          	crewType = "";
		                          }
		                      } else {
		                      	crewType = "";
		                      }
		                  }
		              }); }
		          else {
		        	  logger.error("omsapi_v2_169:lookupServiceAPI response status code is not 200 to fetch crewType " + crewIdList + " responseCode" + responseStatusCode);
		          }
		          }} );
	} else {
        // Final payload structure should be sent when type is not found
        var resultObject = {
      		  "crewId": crewIdList,
      		  "jobId": "",
			  "jobDisplayId": "",
      		  "crewStatus": crewStatus,
      		  "LogonStatus": "",
      		  "crewType": "",
      		  "errorCode": "",
      		  "errorDescription":""
      		  };
        arrayList.push(resultObject);
        ctx.setVariable("arrayList", arrayList);
	}
 }
//End lookupserviceAPI call
