var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});

var ctx = session.name("validStatus")|| session.createContext("validStatus");

var apiToken_OutageStatusApp = session.parameters.apiToken ;
		ctx.setVariable("apiToken_OutageStatusApp", apiToken_OutageStatusApp);
		var apiToken_chatbot=session.parameters.apiToken_chatbot;
		ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
		var apiToken_maximo=session.parameters.apiToken_maximo;
		ctx.setVariable("apiToken_maximo", apiToken_maximo);
		var apiToken_reporting=session.parameters.apiToken_reporting;
		ctx.setVariable("apiToken_reporting", apiToken_reporting);
		
		var ctx1 = session.name("current") || session.createContext("current");
		var currentUser = ctx1.getVar("user");
		var apiToken;
		
		if(currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd'){
    		apiToken = apiToken_OutageStatusApp;
    		logger.info("inside OutageAPP----" +apiToken);
    	}else if(currentUser == 'dcas-cbo-esb-oms-dev' || currentUser == 'dcas-cbo-esb-oms-tst' || currentUser == 'dcas-cbo-esb-oms-prd'){
    		apiToken = apiToken_chatbot;
    		logger.info("inside chatbotAPP----" +apiToken);
    	} else if(currentUser == 'dcas-rpa-esb-oms-dev' || currentUser == 'dcas-rpa-esb-oms-tst' || currentUser == 'dcas-rpa-esb-oms-prd'){
    		apiToken = apiToken_reporting;
    		logger.info("inside reportAPP----" +apiToken);
    	} else if(currentUser == 'dcas-eam-sr-esb-dev' || currentUser == 'dcas-eam-sr-esb-test' || currentUser == 'dcas-eam-sr-esb-prod'){
    		apiToken = apiToken_maximo;
    		logger.info("inside maximoAPP----" +apiToken);
    	}  
		ctx.setVariable("apiToken", apiToken);
