var sm = require('service-metadata');
var urlopen = require('urlopen');
var qs = require ('querystring');
var getURLResponse = require('./validStatus_callUrl.js');
var preuri= session.parameters.preuri;
var prejoburi= session.parameters.prejoburi;
var omsExternalURL= session.parameters.omsExternalURL;
var logger = console.options({
    'category': 'all'
});

var ctx = session.name("validStatus")|| session.createContext("validStatus");

var uri = new String(sm.URI);
var json;
var id;
if(uri.indexOf("?") !=-1){
	json = qs.parse(uri.substring(uri.indexOf("?")+1));
	id = json.id;
	ctx.setVariable("id",id);
}
if(id===undefined || id==="" || id=== null){
	ctx.setVariable("customErrorCode", '400');
				ctx.setVariable("customErrorMessage", 'Bad Request');
				ctx.setVariable("customReasonMessage", 'Bad Request');
				session.reject('id is Mandatory');
	
}


var type= json.type;
ctx.setVariable("type",type);
if(type==='JOB'){
var jobId=type;
var uri= omsExternalURL + prejoburi +id+'?includeFields=id%2Cstatus%2CjobTypeID%2CdisplayID';
} 
if(type==='CREWASSIGNMENT'){
var caId=type;
var uri= omsExternalURL + preuri + 'Query?displayIDs=' +id+'&'+'delimiter=%2C&includeFields=id%2Cstatus%2CworkTypeID';
}

//https://10.0.96.10:8443/oms/external/api/ServiceType/Electric/CrewAssignment/

//https://10.0.96.10:8443/oms/external/api/ServiceType/Electric/CrewAssignment/Query?displayIDs=CA.22.02.00262&delimiter=%2C&skip=0&take=1000&includeFields=id%2Cstatus%2CworkTypeID&historical=false


/* var uri= preuri + 'Query?displayIDs=' +id+'&'+'delimiter=%2C&includeFields=id%2Cstatus%2CworkTypeID';
var uri= prejoburi +id+'&'+'?%2C&includeFields=id%2Cstatus%2CworkTypeID'; */

//https://10.0.96.10:8443/oms/external/api/ServiceType/Electric/Job/NW22020300032?includeFields=id%2Cstatus%2CjobTypeID&joinCallHazards=false&joinJobHazards=false&joinOutageStepExternalPremiseIDs=false

getURLResponse(uri,'validStatusGetResp');
