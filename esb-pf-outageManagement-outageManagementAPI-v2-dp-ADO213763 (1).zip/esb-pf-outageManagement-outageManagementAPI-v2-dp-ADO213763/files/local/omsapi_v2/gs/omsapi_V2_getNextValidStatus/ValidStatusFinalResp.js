var ctx = session.name("validStatus")|| session.createContext("validStatus");
var validStatusGetResp2Obj = ctx.getVariable('validStatusGetResp2');
var jobDisplayId = ctx.getVariable('jobDisplayId');
var type = ctx.getVariable('type');
if(validStatusGetResp2Obj !== undefined){
var workflowResp_lookup= ctx.getVariable('workflowResp_lookup');
var nextStatusArray =  ctx.getVariable("nextStatusArray");
var nextStatusFinalArray =  new Array();

var finalNextStatusArr = new Array();
for(var i=0 ; i < nextStatusArray.length; i++){
var nArr = nextStatusArray[i].transitionRequirements;
var cfArr = nextStatusArray[i].customFieldTrueArr;
for (var k=0 ; k < cfArr.length; k++){
	
	var labelObj = ctx.getVariable(cfArr[k].fieldID+'_lookup');
	var reqString = labelObj[0].label + ' ' +cfArr[k].fieldOperation ;
if (cfArr[k].fieldValue !==null)	
	reqString += ' ' +cfArr[k].fieldValue;  
	var json = {};
	json.requirements = reqString;
	nArr.push(json);
	}
	var obj = {};
	obj.status = nextStatusArray[i].status;
	if(nArr.length !== 0){
		obj.transitionRequirements = nArr;
	}
	nextStatusFinalArray.push(obj);
	
}		
		
		var resp ={};
		if(type=='CREWASSIGNMENT'){
		resp.id=ctx.getVariable("id");
		}
		if(type=='JOB'){
		resp.jobId=ctx.getVariable("intId");
		resp.jobDisplayId=ctx.getVariable("jobDisplayId");
		}
		resp.type=ctx.getVariable("type");
		resp.currentStatus=workflowResp_lookup[0].label;
		resp.nextStatus = nextStatusFinalArray;
		
		ctx.setVariable("finalresp", resp);
		session.output.write(ctx.getVariable('finalresp'));
}

