var sm = require('service-metadata');
var urlopen = require('urlopen');
var doLookup = require('./validstatus_lookup.js');
var getURLResponse = require('./validStatus_callUrl.js');
var omsExternalURL= session.parameters.omsExternalURL;
var preuri= session.parameters.preuri;
var prejoburi= session.parameters.prejoburi;
var logger = console.options({
    'category': 'all'
});

var ctx = session.name("validStatus")|| session.createContext("validStatus");
var uri2= '';
var validStatusGetResp = ctx.getVariable('validStatusGetResp');
var type = ctx.getVariable('type');
var status= '';
var intId='';
if(type==='CREWASSIGNMENT'){
	if (validStatusGetResp[0] == undefined){
		ctx.setVariable("customErrorCode", '404');
					ctx.setVariable("customErrorMessage", 'No Records Found');
					ctx.setVariable("customReasonMessage", 'No Records Found');
					session.reject("No Records Found");
	}
var intId= validStatusGetResp[0].id;
var workTypeID= validStatusGetResp[0].workTypeID;
var status= validStatusGetResp[0].status;
var uri2= omsExternalURL + preuri + intId+"/WorkFlow";
}
if(type==='JOB'){
var intId= validStatusGetResp.id;
ctx.setVariable("intId", intId);
var jobDisplayId= validStatusGetResp.displayID;
ctx.setVariable("jobDisplayId", jobDisplayId);
var jobTypeID= validStatusGetResp.jobTypeID;
var status= validStatusGetResp.status;
var uri2= omsExternalURL + prejoburi + intId+"/WorkFlow";
}



getURLResponse(uri2,'validStatusGetResp2');




var typeArr = new Array();

if(type=='CREWASSIGNMENT'){
 var validStatusworktypeReq = {};
        validStatusworktypeReq.name = "workType.workflows";
		validStatusworktypeReq.id = workTypeID;
        validStatusworktypeReq.status = status;        
        typeArr.push(validStatusworktypeReq);
}
if(type=='JOB'){
 var validStatusjobtypeReq = {};
        validStatusjobtypeReq.name = "jobTypes.workflows";
		validStatusjobtypeReq.id = jobTypeID;
        validStatusjobtypeReq.status = status;        
        typeArr.push(validStatusjobtypeReq);
}

/*  var validStatusworktypeReq = {};
        validStatusworktypeReq.name = "workType.workflows";
        validStatusworktypeReq.status = status;
        validStatusworktypeReq.id = workTypeID;
        typeArr.push(validStatusworktypeReq); */
		
		doLookup(typeArr, 'workflowResp');
		
		
		
		
		
