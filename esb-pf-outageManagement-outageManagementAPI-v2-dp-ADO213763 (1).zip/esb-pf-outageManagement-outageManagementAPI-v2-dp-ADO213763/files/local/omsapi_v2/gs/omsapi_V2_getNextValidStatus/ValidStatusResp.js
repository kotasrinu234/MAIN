var sm = require('service-metadata');
var doLookup = require('./validstatus_lookup.js');

var logger = console.options({
    'category': 'all'
});
var ctx = session.name("validStatus")|| session.createContext("validStatus");
		///var validStatusGetResp2 = ctx.getVariable('validStatusGetResp2');
		var validStatusGetResp2Obj = ctx.getVariable('validStatusGetResp2');
		if(validStatusGetResp2Obj !== undefined){
		var validStatusGetResp2Arr = Object.values(validStatusGetResp2Obj);
		/* var validStatusGetResp2Arr = [
  {
    "actionLabel": "Cancel",
    "toState": 2,

    "transitionRequirements": [
      {
        "requirements": [
          {
            "id": "5f10712debeb0f61b225fe161",

            "fieldID": "564c95db66659b91c8ce33c8",
            "fieldOperation": "NOT_NULL",
            "customField": true,
            "invalid": true
          }
        ],
        "invalid": true
      }
    ],
},
{
    "actionLabel": "Cancel",
    "toState": 2,

    "transitionRequirements": [
      {
        "requirements": [
          {
            "id": "5f10712debeb0f61b225fe162",

            "fieldID": "5e00dfc3ebeb0f13f63a2aca",
            "fieldOperation": "NOT_NULL",
            "customField": false,
            "invalid": true
          }
        ],
        "invalid": true
      }
    ],
},
{
    "actionLabel": "Cancel",
    "toState": 2,

    "transitionRequirements": [
      {
        "requirements": [
          {
            "id": "5f10712debeb0f61b225fe163",

            "fieldID": "5de7d76cebeb0f2023db226d",
            "fieldOperation": "NOT_NULL",
            "customField": true,
            "invalid": true
          }
        ],
        "invalid": true
      }
    ],
},
{
    "actionLabel": "Cancel",
    "toState": 2,

    "transitionRequirements": [
      {
        "requirements": [
          {
            "id": "5f10712debeb0f61b225fe164",

            "fieldID": "5e00dfc3ebeb0f13f63a2aca",
            "fieldOperation": "NOT_NULL",
            "customField": false,
            "invalid": true
          }
        ],
        "invalid": true
      }
    ],
}
];


 */

		//var toStatesArr= validStatusGetResp2.toStates;
		var tranReqArr = new Array();
		var customFieldTrueArr = new Array();
		var nextStatusArr = new Array();
		for (var i=0;i<validStatusGetResp2Arr.length;i++){
			// tostate object 
			var obj = validStatusGetResp2Arr[i];
			var nextStatusObj = {};
			
			nextStatusObj.status = obj.actionLabel;
			var transitionRequirements = new Array();
			//var actionLabel= obj.actionLabel;
			if(obj.transitionRequirements.length !==0)
				transitionRequirements=obj.transitionRequirements;
			var reqString='';
			
			for (var j=0;j<transitionRequirements.length;j++){
				tranReqArr = new Array();
			customFieldTrueArr = new Array();
				var requirements=transitionRequirements[j].requirements;
					for (var k=0;k<requirements.length;k++){
						var fieldID=requirements[k].fieldID;
						var fieldOperation=requirements[k].fieldOperation;
						var fieldValue=requirements[k].fieldValue;	
						var customField=requirements[k].customField;	
						
						if(customField===false){
						reqString= 	fieldID	+' '+fieldOperation+' '+fieldValue;	
						var reqJson = {};
						reqJson.requirements = reqString;	
						tranReqArr.push(reqJson);
						}else{
						var reqJson = {};
						//reqJson.requirements = reqString;	
						reqJson.customField = requirements[k].customField;	
						reqJson.fieldID = fieldID;	
						reqJson.fieldOperation = fieldOperation;	
						reqJson.fieldValue = fieldValue;	
						customFieldTrueArr.push(reqJson);						
					
							var typeArr = new Array();
							 var req = {};
									req.name = "jobCustomFields";
									req.id = fieldID;
									typeArr.push(req);
									doLookup(typeArr,fieldID);
						}						
					}
			requirements =null;					
							
		}
		if(obj.transitionRequirements.length !== 0){
			nextStatusObj.transitionRequirements = tranReqArr;
			nextStatusObj.customFieldTrueArr = customFieldTrueArr;
		}else{
			nextStatusObj.transitionRequirements = new Array();
			nextStatusObj.customFieldTrueArr = new Array();
		}		
nextStatusArr.push(nextStatusObj);
	}
		ctx.setVariable("nextStatusArray", nextStatusArr);
		ctx.setVariable("customFieldTrueArr", customFieldTrueArr);
		
		//to put the below code in next js file
}
		