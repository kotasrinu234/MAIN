var ctx = session.name("Restore_Verify") || session.createContext("Restore_Verify");
var omsExternalURL = session.parameters.omsExternalURL;
var hm = require('header-metadata');
var sm = require('service-metadata');
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var ils = session.name("ILS") || session.createContext("ILS");
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ils.setVariable('userId', userId);
var entryDescription = '';
var exitDescription = '';
var jobDetailCount = session.parameters.getImageJobDetailCount;
var apiName = session.parameters.restoreVerifyApiName;
var messageType = session.parameters.messageType;
ils.setVariable("messageType", messageType);
ils.setVariable("apiName", apiName);
var logger = console.options({
	'category': 'all'
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + readAsJSONError);
		session.reject("Error in reading incoming data" + readAsJSONError);
	}
	else {
		session.output.write(incomingdata);
		ctx.setVariable("omsExternalURL", omsExternalURL);
		if (incomingdata.jobId == null || incomingdata.jobId == '' || incomingdata.jobId == undefined) {
			var errorinfo = "jobId is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			logger.error('jobId is not present in input payload');
			session.reject('jobId is not present in input payload');
		}
		else {
			ctx.setVariable("jobId", incomingdata.jobId);
			if (incomingdata.jobId) {
				if (incomingdata.jobId !== undefined || incomingdata.jobId !== null || incomingdata.jobId !== '') {
					var jobId = incomingdata.jobId;
					if (jobId.length == jobDetailCount) {
						ils.setVariable("jobID", jobId)

					}
					else {
						ils.setVariable("jobDisplayID", jobId)
					}
				}
			}
		}
		if (incomingdata.messageID == null || incomingdata.messageID == '' || incomingdata.messageID == undefined) {
			var errorinfo = "messageID is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			logger.error('messageID is not present in input payload');
			session.reject('messageID is not present in input payload');
		}
		else {
			ils.setVariable("correlationID", incomingdata.messageID);
			ilsctx.setVariable("correlationID", incomingdata.messageID);
		}
		if (incomingdata.restoreVerify == null || incomingdata.restoreVerify == '' || incomingdata.restoreVerify == undefined) {
			var errorinfo = "Missing value for restoreVerify in input Payload ";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
		else {
			var restoreVerify = incomingdata.restoreVerify
			ctx.setVariable("restoreVerify", incomingdata.restoreVerify);
			if (restoreVerify === 'verify' || restoreVerify === 'restore') {
				ils.setVariable("restoreVerify", restoreVerify);
				ctx.setVariable("restoreVerify", restoreVerify);
			}
			else {
				var errorinfo = "Invalid value for restore/verify";
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatusCode", "400");
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
			if (restoreVerify === 'verify') {
				entryDescription = session.parameters.verifyEntryDescription;
				ils.setVariable('entryDescription', entryDescription);
				exitDescription = session.parameters.verifyExitDescription;
				ils.setVariable('exitDescription', exitDescription);
			}
			else if (restoreVerify === 'restore') {
				entryDescription = session.parameters.restoreEntryDescription;
				ils.setVariable('entryDescription', entryDescription);
				exitDescription = session.parameters.restoreExitDescription;
				ils.setVariable('exitDescription', exitDescription);
			}

		}
		if (incomingdata.timesStamp == null || incomingdata.timesStamp == '' || incomingdata.timesStamp == undefined) {
			var errorinfo = "timesStamp is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			logger.error("timesStamp is not present in input payload");
			session.reject("timesStamp is not present in input payload");
		}
		else {
			ctx.setVariable("timesStamp", incomingdata.timesStamp);
			ils.setVariable("sourceEventTimestamp", incomingdata.timesStamp);
		}
	}
});
