var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("Restore_Verify") || session.createContext("Restore_Verify");
var ils = session.name("ILS") || session.createContext("ILS");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var incomingUser = currentUser;
var restoreFlag = '';
var verifyFlag = '';
var logger = console.options({
	'category': 'all'
});
var apiToken;
var client;
if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma; 
	client = "UrmaApp"
}else if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd'){
	apiToken = session.parameters.apiToken;
	client = "OutageStatusApp"
}
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var id = ctx.getVar("jobId");
var omsUrl = ctx.getVar("omsExternalURL");
var restoreVerify = ctx.getVar("restoreVerify");
if (restoreVerify === 'restore') { restoreFlag = 'true' } else { restoreFlag = 'false' }
if (restoreVerify === 'verify') { verifyFlag = 'true' } else { verifyFlag = 'false' }
var getUrl = omsUrl + '/api/ServiceType/Electric/Job/' + id;
var getRestore_VerifyAPI = {
	target: getUrl,
	sslClientProfile: 'omsapi_client_profile',
	method: 'GET',
	contentType: 'application/json',
	headers: {
		'osiApiToken': apiToken
	}
};
var getCallInfo = " TargetURL :" + getRestore_VerifyAPI.target + "; Method :" + getRestore_VerifyAPI.method;
try {
	urlopen.open(getRestore_VerifyAPI, function(error, response) {
		if (error) {
			var errorinfo = "omsapiv2_189:urlopen connect error with getRestore_VerifyAPI, details are : " + getCallInfo + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			logger.error("omsapiv2_189:urlopen connect error with getRestore_VerifyAPI" + JSON.stringify(error));
			session.reject("omsapiv2_189:urlopen connect error with getRestore_VerifyAPI" + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			var responsePhrase = response.reasonPhrase;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in putting message to getRestore_VerifyAPI, details are : " + getCallInfo + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatusCode", "500");
						logger.error("failure in putting message to getRestore_VerifyAPI" + JSON.stringify(errorinfo));
						session.reject("failure in putting message to getRestore_VerifyAPI" + JSON.stringify(errorinfo));
					} else {
						hm.response.statusCode = responseStatusCode;
						logger.debug("response received from getRestore_VerifyAPI for JobId:" + "" + responseData);
						var energizationStatus = responseData.energizationStatus;
						var id = responseData.id;
						ctx.setVariable("energizationStatus", energizationStatus);
						if((restoreVerify === 'restore' && energizationStatus === 'RESTORED') || (restoreVerify === 'verify' && energizationStatus === 'RESTORED') || (restoreVerify === 'verify' && energizationStatus === 'VERIFIED')){
							var errorinfo = "Job already restored or verified. Details are : " + getCallInfo + "; error code : 200";
							var body = "Job already restored or verified.";
							ilsctx.setVariable("errorDescription", errorinfo);
							ils.setVariable('exitDescription', errorinfo);
							var payload = {
								body
							}
							session.output.write(payload);
						}
						else {
							var restore_Verify_MQURL = session.parameters.restore_Verify_MQURL;
							var ExternalRefID = id + ":" + id;
							var restore_Verify_MQPaload = {
								"CallBackData": {
									"messageID": ilsctx.getVar("correlationID"),
									"Client": client,
									"ServiceName": "RestoreVerify",
									"CallID": "",
									"Number": 0,
									"ExternalRefID": ExternalRefID
								},
								"RestoreVerify": {
									"JobIDGUID": id,
									"FieldTime": ctx.getVar("timesStamp"),
									"Verify": verifyFlag,
									"Restore": restoreFlag,
									"LastRequestStatus": ""
								}
							};
							session.output.write(restore_Verify_MQPaload);
							var pushingToQueue = {
								target: restore_Verify_MQURL,
								data: restore_Verify_MQPaload
							};
							var queueCallInfo = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";
							try {
								urlopen.open(pushingToQueue, function(error, response) {
									var hm = require('header-metadata');
									if (error) {
										var mqconnection = 'Forbidden';
										ctx.setVariable("mqconnection", mqconnection);
										logger.error(" error while keeping message to queue is " + error);
										var errorinfo = "error while keeping message to queue is , details are : " + queueCallInfo + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", "500");
										session.reject(" error while keeping message to queue is " + error);
									} else {
										var mqrc = response.statusCode;
										if (mqrc == 0) {
											var replyMQMD = response.get({
												type: 'mq'
											}, 'MQMD');
											var replyMQRFH2 = response.get({
												type: 'mq'
											}, 'MQRFH2');
											response.readAsBuffer(function(readError, responseData) {
												if (readError) {
													hm.response.statusCode = 500
													var errorinfo = "error while keeping message to queue is , details are : " + queueCallInfo + "; error info :" + error;
													ilsctx.setVariable("errorDescription", errorinfo);
													ilsctx.setVariable("errorStatusCode", "500");
													session.reject("error while keeping message  to queue is " + error);
												} else {
													logger.debug("MQResponsecode " + mqrc);
												}
											});
										} else {
											var mqconnection = 'Forbidden';
											ctx.setVariable("mqconnection", mqconnection);
											var errorinfo = "response code is urlopen.open error, details are : " + queueCallInfo + "; error info :" + mqrc;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatusCode", "500");
											logger.error("response code urlopen.open error of  Queue OMSAPIJOB.RESTORE.VERIFY.REQUEST [MQRC=" + mqrc + "]");
											session.reject(" response code is urlopen.open error [MQRC=" + mqrc + "]");
										}
									}
								});
							} catch (error) {
								var mqconnection = 'Forbidden';
								ctx.setVariable("mqconnection", mqconnection);
								logger.error(" error while keeping message to queue is " + error);
								var errorinfo = "error while keeping message to queue is , details are : " + queueCallInfo + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatusCode", "500");
								session.reject(" error while keeping message to queue is " + error);
							}
						}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "omsapiv2_187:failure in reading message from getRestore_VerifyAPI for negative ack, details are : " + getCallInfo + "; error info :" + error + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatusCode", "500");
						logger.error("omsapiv2_187:failure in reading message from getRestore_VerifyAPI for negative ack " + " " + responseData);
						session.reject("omsapiv2_187:failure in reading message from getRestore_VerifyAPI for negative ack" + " " + responseData);
					} else {
						var errorinfo = "omsapiv2_188:message from getRestore_VerifyAPI for negative ack, " + responseStatusCode + " details are : " + getCallInfo + "; response info :" + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatusCode", responseStatusCode);
						logger.error("omsapiv2_188:message from getRestore_VerifyAPI for negative ack, " + responseStatusCode + " details are : " + getCallInfo + "; response info :" + responseData);
						session.reject("omsapiv2_188:message from getRestore_VerifyAPI for negative ack, " + responseStatusCode + " details are : " + getCallInfo + "; response info :" + responseData);

					}
				});
			}
		}
	});
}
catch (err) {
	var errorinfo = "omsapiv2_189:urlopen connect error with getRestore_VerifyAPI, details are : " + getCallInfo + "; error info :" + err;
	ilsctx.setVariable("errorDescription", errorinfo);
	ilsctx.setVariable("errorStatusCode", "500");
	logger.error("omsapiv2_189:urlopen connect error with getRestore_VerifyAPI" + JSON.stringify(err));
	session.reject("omsapiv2_189:urlopen connect error with getRestore_VerifyAPI" + JSON.stringify(err));
}
