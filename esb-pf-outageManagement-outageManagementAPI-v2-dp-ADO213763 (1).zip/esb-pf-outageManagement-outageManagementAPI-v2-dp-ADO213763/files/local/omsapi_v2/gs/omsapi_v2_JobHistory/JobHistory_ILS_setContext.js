var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.getJobHistoryEntryDescription;
var exitDescription = session.parameters.getJobHistoryExitDescription;
function getParameterByName(name, url) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
} 
var incomingUrl = sm.getVar('var://service/URI');
var premiseId = getParameterByName("premiseId", incomingUrl);
var messageType = session.parameters.messageType;
var apiName = session.parameters.getJobHistoryApiName;
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
ctx.setVariable("apiName",apiName);
ctx.setVariable("messageType",messageType);
ctx.setVariable('entryDescription',entryDescription);
ctx.setVariable('exitDescription',exitDescription);
var id = uuidv4()
ctx.setVariable("correlationID",id)
if(premiseId !== undefined || premiseId!== null || premiseId!== ''){
	ctx.setVariable("premiseID",premiseId)}
ctx.setVariable("sourceEventTimestamp",new Date().toISOString())
