// This file is to call the OMS and Lookup services.
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("jobHistory") || session.createContext("jobHistory");
var omsExternalURL = ctx.getVar("omsExternalURL");
var omsExternalURL22 = 'https://adms-interface-pds.dteco.com:4920';
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
// Start API token check with current user
var lookupURL = ctx.getVar("lookupURL");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var premise_Id;
var rep;
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
// End API token check with current user

var logger = console.options({
	'category': 'all'
});
var id;
var aor;
var arrayList = [];
var feederId;

function getParameterByName(name, url) {
	name = name.replace(/[\[\]]/g, '\\$&');
	var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
		results = regex.exec(url);
	if (!results) return null;
	if (!results[2]) return '';
	return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

session.input.readAsBuffer(function(readAsJSONError, incomingdata) {

	var incomingUrl = sm.getVar('var://service/URI');
	var ctx = session.name("jobHistory") || session.createContext("jobHistory");
	ctx.setVariable("premiseId", getParameterByName("premiseId", incomingUrl));
	var premiseId = getParameterByName("premiseId", incomingUrl);

	/* API token check with current user */
	var incomingUser = currentUser;
	var apiToken;
	if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
		apiToken = apiToken_OutageStatusApp;
	} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
		apiToken = apiToken_chatbot;
	} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
		apiToken = apiToken_reportingApp;
	} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
		apiToken = apiToken_maximo;
	}

	/* Premise OMS call */
	var jobHistoryUrl = omsExternalURL + '/api/Premise/' + premiseId + '/Job?activeOnly=false&ignoreHistorical=false&join=true';
	var getJobHistory = {
		target: jobHistoryUrl,
		sslClientProfile: 'omsapi_client_profile',
		method: 'GET',
		headers: {
			'osiApiToken': apiToken
		},
	};
	// open connection to target

	var info = " TargetURL :" + getJobHistory.target + "; Method :" + getJobHistory.method + ". ";
	try {
		urlopen.open(getJobHistory, function(error, response) {
			// handle the error when connecting to target
			if (error) {
				var errorinfo = "omsapi_v2_174:url connection error with 'OMS PremiseCall', details are : " + info + "; error info :" + error
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", response.statusCode);
				ilsctx.setVariable("errorMessage", response.reasonPhrase);
				logger.error("omsapi_v2_174:" + errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response from 'PremiseCall', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("PremiseCall 200 is received");
							var getJobHistoryResponse = JSON.parse(responseData);
							var ctx = session.name("jobHistory") || session.createContext("jobHistory");
							ctx.setVariable('responseStatusCode', responseStatusCode);
							//ctx.setVariable("getJobHistoryResponse", getJobHistoryResponse);

							// FeederID OMS Call
							let uf = []
							getJobHistoryResponse.data && getJobHistoryResponse.data.forEach((item) => {
								if (item.archived && item.feederID) {
									uf.push(item.feederID);
								}
							});
							uf = [...new Set(uf)]
							ctx.setVariable('Filter', uf);
							uf.forEach((feederId) => {
								var getFeederIdUrl = omsExternalURL + '/api/ServiceType/Electric/Feeder/' + feederId + '?includeFields=externalID';
								var getfeederIdApi = {
									target: getFeederIdUrl,
									sslClientProfile: 'omsapi_client_profile',
									method: 'GET',
									contentType: 'application/json',
									headers: {
										'osiApiToken': apiToken
									},
								};

								var info = " TargetURL :" + getfeederIdApi.target + "; Method :" + getfeederIdApi.method + ". ";
								try {
									urlopen.open(getfeederIdApi, function(error, response) {
										if (error) {
											var errorinfo = "omsapi_v2_175:url connection error with 'OMS FeederIDCall', details are : " + info + "; error info :" + error
											ilsctx.setVar('errorDescription', errorinfo);
											ilsctx.setVariable("errorStatusCode", response.statusCode);
											ilsctx.setVariable("errorMessage", response.reasonPhrase);
											logger.error("omsapi_v2_175:" + errorinfo);
											session.reject(errorinfo);
										} else {
											var responseStatusCode = response.statusCode;
											var responsePhrase = response.reasonPhrase;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response from 'getfeederIdApi', details are : " + info + "; error info :" + error
														ilsctx.setVar('errorDescription', errorinfo);
														ilsctx.setVariable("errorStatusCode", responseStatusCode);
														ilsctx.setVariable("errorMessage", responsePhrase);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														hm.response.statusCode = responseStatusCode;
														logger.debug("FeederIDCall 200 is received");
														var getfeederIdApiResponse = JSON.parse(responseData);
														var ctx = session.name("jobHistory") || session.createContext("jobHistory");
														ctx.setVariable("getfeederIdApiResponse_" + feederId, getfeederIdApiResponse);
													}
													var ctx = session.name("jobHistory") || session.createContext("jobHistory");
													ctx.setVariable('FeederIDArr_' + feederId, getfeederIdApiResponse.externalID);
												});
											} else {
												var errorinfo = "omsapi_v2_176: FeederIDCall response status code is not 200 to fetch the externalID, details are : " + info + "; error info :" + error
												ilsctx.setVar('errorDescription', errorinfo);
												ilsctx.setVariable("errorStatusCode", responseStatusCode);
												ilsctx.setVariable("errorMessage", responsePhrase);
												logger.error("omsapi_v2_176: FeederIDCall response status code is not 200 to fetch the externalID" + " " + responseStatusCode);
												session.reject("FeederIDCall response status code is not 200 to fetch the externalID");
											}
										}

									});
								} catch (err) {
									var errorinfo = "omsapi_v2_175:url connection error with 'OMS FeederIDCall', details are : " + info + "; error info :" + err
									ilsctx.setVar('errorDescription', errorinfo);
									logger.error("omsapi_v2_175:" + errorinfo);
									session.reject(errorinfo);
								}
							}); // forEach end: FeederID call End

							for (let j = 0; j < getJobHistoryResponse.data.length; j++) {
								if (getJobHistoryResponse.data[j].archived) {
									id = getJobHistoryResponse.data[j].id;
									premise_Id = getJobHistoryResponse.data[j].id;
									var internalId = getJobHistoryResponse.data[0].id;
									var RestorationDate = getJobHistoryResponse.data[j].outageSteps.length > 0 ? getJobHistoryResponse.data[j].outageSteps[0].onTime : "";
									var ert = getJobHistoryResponse.data[j].publishedEtr ? getJobHistoryResponse.data[j].publishedEtr.value : "";
									var prnFlag = getJobHistoryResponse.data[j].premisesWithAMIRestorationNotifCount;
									var aorID = getJobHistoryResponse.data[j].aorID;
									var status = getJobHistoryResponse.data[j].status;
									var jobTypeID = getJobHistoryResponse.data[j].jobTypeID;
									var outageSubTypeID = getJobHistoryResponse.data[j].outageSubtypeID;
									var outageDate = getJobHistoryResponse.data[j].createdAt;
									var causeCode = getJobHistoryResponse.data[j].customFieldValuesExt.cause;
									var address = getJobHistoryResponse.data[j].address;
									var region = getJobHistoryResponse.data[j].regionName;
									var longtitude;
									var latitude;
									if (getJobHistoryResponse.data[j].location != undefined) {
										if (getJobHistoryResponse.data[j].location.coordinates != undefined) {
											longtitude = getJobHistoryResponse.data[j].location.coordinates[0];
											latitude = getJobHistoryResponse.data[j].location.coordinates[1];
										}
									}

									//Comment call Start
									//Call GET /api/v1/ServiceType/Electric/Job/{id}/Comment {id} as job internal id {id} from the response
									if (getJobHistoryResponse.data[j].id === null || getJobHistoryResponse.data[j].id === undefined || getJobHistoryResponse.data[j].id === '') {
										var ctx = session.name("jobHistory") || session.createContext("jobHistory");
										ctx.setVariable("id", '');
									} else {
										var getCommentUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + getJobHistoryResponse.data[j].id + '/Comment';
										var getCommentsApi = {
											target: getCommentUrl,
											sslClientProfile: 'omsapi_client_profile',
											method: 'GET',
											contentType: 'application/json',
											headers: {
												'osiApiToken': apiToken
											},
										};

										var info = " TargetURL :" + getCommentsApi.target + "; Method :" + getCommentsApi.method + ". ";
										try {
											urlopen.open(getCommentsApi, function(error, response) {
												if (error) {
													var errorinfo = "omsapi_v2_177:url connection error with 'OMS CommentsCall', details are : " + info + "; error info :" + error
													ilsctx.setVar('errorDescription', errorinfo);
													ilsctx.setVariable("errorStatusCode", response.statusCode);
													ilsctx.setVariable("errorMessage", response.reasonPhrase);
													logger.error("omsapi_v2_177:" + errorinfo);
													session.reject(errorinfo);
												} else {
													var responseStatusCode = response.statusCode;
													var responsePhrase = response.reasonPhrase;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response from 'CommentsCall', details are : " + info + "; error info :" + error
																ilsctx.setVar('errorDescription', errorinfo);
																ilsctx.setVariable("errorStatusCode", responseStatusCode);
																ilsctx.setVariable("errorMessage", responsePhrase);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																hm.response.statusCode = responseStatusCode;
																logger.debug("CommentsCall 200 is received");
																var getCommentsApiResponse = JSON.parse(responseData);
																let commentArray = [];
																var commentsArr = getCommentsApiResponse;
																for (let i = 0; i < commentsArr.length; i++) {
																	var deprecated = commentsArr[i].deprecated;
																	var comm = {
																		"comment": commentsArr[i].comment,
																		"timestamp": commentsArr[i].updatedAt
																	}
																	var rep1 = JSON.stringify(comm);

																	logger.info("rep1 is" + rep1);
																	if (deprecated == false) {
																		commentArray.push(rep1);
																	}
																}
																var ctx = session.name("jobHistory") || session.createContext("jobHistory");
																ctx.setVariable('commentsArr_' + getJobHistoryResponse.data[j].displayID, commentArray);
															}
														});
													} else {
														var errorinfo = "omsapi_v2_178: CommentsCall response status code is not 200 to fetch the comments, details are : " + info + "; error info :" + error
														ilsctx.setVar('errorDescription', errorinfo);
														ilsctx.setVariable("errorStatusCode", responseStatusCode);
														ilsctx.setVariable("errorMessage", responsePhrase);
														logger.error("omsapi_v2_178: CommentsCall response status code is not 200 to fetch the comments" + " " + responseStatusCode);
														session.reject("CommentsCall response status code is not 200 to fetch the comments");
													}
												}

											});
										} catch (err) {
											var errorinfo = "omsapi_v2_177:url connection error with 'OMS CommentsCall', details are : " + info + "; error info :" + err
											ilsctx.setVar('errorDescription', errorinfo);
											logger.error("omsapi_v2_177:" + errorinfo);
											session.reject(errorinfo);
										}
									}
									//Comment call End

									// LookUp calls Start
									var LookupMessage = {
										"lookupReq": {
											"type": [{
												"name": "jobTypes.workflows",
												"id": jobTypeID,
												"status": status
											},
											{
												"name": "outageSubtypes",
												"id": outageSubTypeID
											},
											{
												"name": "jobTypes",
												"id": jobTypeID
											},
											{
												"name": "aors",
												"id": aorID
											}
											]
										}
									}
									var LookupServiceResponse = {
										target: lookupURL,
										method: 'POST',
										contentType: 'application/json',
										data: LookupMessage
									};

									var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
									try {
										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												var errorinfo = "omsapi_v2_179:url connection error with 'OMS LookupService', details are : " + info + "; error info :" + error
												ilsctx.setVar('errorDescription', errorinfo);
												ilsctx.setVariable("errorStatusCode", response.statusCode);
												ilsctx.setVariable("errorMessage", response.reasonPhrase);
												logger.error("omsapi_v2_179:" + errorinfo);
												session.reject(errorinfo);
											} else {
												var responseStatusCode = response.statusCode;
												var responsePhrase = response.reasonPhrase;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error reading response from 'LookupServiceResponse', details are : " + info + "; error info :" + error
															ilsctx.setVar('errorDescription', errorinfo);
															ilsctx.setVariable("errorStatusCode", responseStatusCode);
															ilsctx.setVariable("errorMessage", responsePhrase);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("CommentsCall 200 is received");
															var LookupServiceResponse = JSON.parse(responseData);
															var ctx = session.name("jobHistory") || session.createContext("jobHistory");
															ctx.setVariable("LookupServiceResponse", LookupServiceResponse);
															ctx.setVariable('LookupServiceResponseArr_' + getJobHistoryResponse.data[j].displayID, JSON.stringify(LookupServiceResponse.lookupRep.type));
														}

														var resultObject = {
															"jobId": getJobHistoryResponse.data[j].id || "",
															"jobDisplayId": getJobHistoryResponse.data[j].displayID || "",
															"causeCode": getJobHistoryResponse.data[j].customFieldValuesExt.cause || "",
															"RestorationDate": (getJobHistoryResponse.data[j].outageSteps.length > 0 ? getJobHistoryResponse.data[j].outageSteps[0].onTime : "") || "",
															"etr": getJobHistoryResponse.data[j].publishedEtr ? getJobHistoryResponse.data[j].publishedEtr.value : "",
															"prnFlag": getJobHistoryResponse.data[j].premisesWithAMIRestorationNotifCount >= 0 ? getJobHistoryResponse.data[j].premisesWithAMIRestorationNotifCount : "",
															"premiseId": premiseId,
															"region": getJobHistoryResponse.data[j].regionName || "",
															"outageDate": getJobHistoryResponse.data[j].createdAt || "",
															"longtitude": longtitude || "",
															"latitude": latitude || "",
															"address": getJobHistoryResponse.data[j].address || "",
															"xCord": "",
															"yCord": "",
															"feederId": getJobHistoryResponse.data[j].feederID ? getJobHistoryResponse.data[j].feederID : ""
														}
														rep = JSON.stringify(resultObject);
														arrayList.push(rep);
														var ctx = session.name("jobHistory") || session.createContext("jobHistory");
														ctx.setVariable("arrayList", arrayList);
													});
												} else {
													var errorinfo = "omsapi_v2_180: LookupService response status code is not 200 to fetch the LookupServiceCall, details are : " + info + "; error info :" + error
													ilsctx.setVar('errorDescription', errorinfo);
													ilsctx.setVariable("errorStatusCode", responseStatusCode);
													ilsctx.setVariable("errorMessage", responsePhrase);
													logger.error("omsapi_v2_180: LookupService response status code is not 200 to fetch the LookupServiceCall" + " " + responseStatusCode);
													session.reject("LookupService response status code is not 200 to fetch the LookupServiceCall");
												}
											}

										});
									} catch (err) {
										var errorinfo = "omsapi_v2_179:url connection error with 'OMS LookupService', details are : " + info + "; error info :" + err
										ilsctx.setVar('errorDescription', errorinfo);
										logger.error("omsapi_v2_179:" + errorinfo);
										session.reject(errorinfo);
									}// LookUp calls End
								} //If condition End
							} // 'for' loop end 
						}
					});
				} else if (responseStatusCode == 401) {
					var errorinfo = "Not Authorized, " + responseStatusCode + " details are : " + info + "; error info :" + error;
					ilsctx.setVar('errorDescription', errorinfo);
					logger.error("Not Authorized" + errorinfo);
					session.reject(errorinfo);
				}
				else {
					logger.debug("omsapi_v2_173: premiseId not found");
					// session.reject("404: premiseId Not Found");
					ctx.setVariable("flag", "true");
				}
			}
		});
	} catch (err) {
		var errorinfo = "omsapi_v2_174:url connection error with 'OMS PremiseCall', details are : " + info + "; error info :" + err
		ilsctx.setVar('errorDescription', errorinfo);
		logger.error("omsapi_v2_174:" + errorinfo);
		session.reject(errorinfo);
	}
});
