//Final Response payload to OMS
var ctx = session.name("jobHistory") || session.createContext("jobHistory");
var responseStatusCode = ctx.getVariable("responseStatusCode");
var response = ctx.getVariable("responseOfAPI");
var startDate = ctx.getVariable("startDateQuery");
var flag = ctx.getVariable("flag");
var endDate = ctx.getVariable("endDateQuery");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var logger = console.options({
	'category': 'all'
});
if (flag !== "true") {
	var gethistoryArray = [];
	var arrayList = ctx.getVariable("arrayList");
	if (arrayList != undefined) {
		var arrayListArray = new Array();
		var arrayListStringifyArr = ctx.getVariable('arrayList');
		logger.debug("arrayListStringifyArr is" + arrayListStringifyArr);
		var jsonstr;
		if (!(arrayListStringifyArr == null)) {
			for (var ctr = 0; ctr < arrayListStringifyArr.length; ctr++) {

				jsonstr = arrayListStringifyArr[ctr];
				logger.info("arrayListArray is" + jsonstr);
				arrayListArray.push(JSON.parse(jsonstr));
				var displayID = arrayListArray[ctr].jobDisplayId;
				var feederID = arrayListArray[ctr].feederId;
				//Circuit
				var FeederIDArr = ctx.getVariable("FeederIDArr_" + feederID);
				if (FeederIDArr == null || FeederIDArr == '' || FeederIDArr == undefined) {
					arrayListArray[ctr].circuit = '';
				} else {
					arrayListArray[ctr].circuit = FeederIDArr;
				}
				//Circuit

				//LookUp
				var LookupServiceResponse = ctx.getVariable("LookupServiceResponseArr_" + displayID);
				var LookupService = JSON.parse(LookupServiceResponse);
				if (!LookupService) {
					arrayListArray[ctr].jobType = "";
					arrayListArray[ctr].jobSubType = "";
					arrayListArray[ctr].aor = "";
					arrayListArray[ctr].jobStatus = "";

				} else {
					arrayListArray[ctr].jobType = LookupService[2].result == 0 ? LookupService[2].label : "";
					arrayListArray[ctr].jobSubType = LookupService[1].result == 0 ? LookupService[1].label : "";
					arrayListArray[ctr].aor = LookupService[3].result == 0 ? LookupService[3].label : "";
					arrayListArray[ctr].jobStatus = LookupService[0].result == 0 ? LookupService[0].label : "";
				}
				//LookUp

				//comments            
				var commentArr = ctx.getVariable("commentsArr_" + displayID);

				var commentsNewArray = new Array();
				var commentsNewStringifyArr = ctx.getVariable('commentsArr_' + displayID);
				logger.info("commentsNewStringifyArr is" + commentsNewStringifyArr);
				var jsonstr1;

				if (!(commentsNewStringifyArr == null)) {
					for (var ctr1 = 0; ctr1 < commentsNewStringifyArr.length; ctr1++) {
						jsonstr1 = commentsNewStringifyArr[ctr1];
						commentsNewArray.push(JSON.parse(jsonstr1));
						logger.info("commentsNewArray" + commentsNewArray);
					}
				}
				ctx.setVariable('commentsNewArray', commentsNewArray);
				if (commentArr == null || commentArr == '' || commentArr == undefined) {
					arrayListArray[ctr].comments = [];
				} else {
					arrayListArray[ctr].comments = commentsNewArray;
				}
				//comments
			}
			var resultArray = []
			for (var index = 0; index < arrayListArray.length; index++) {
				if (new Date(startDate).getTime() < new Date(arrayListArray[index].outageDate).getTime() && new Date(endDate).getTime() > new Date(arrayListArray[index].outageDate).getTime()) {
					logger.info("Date entry is" + new Date(arrayListArray[index].outageDate).getTime());
					resultArray.push(arrayListArray[index])
				}
			}
			resultArray = resultArray.map((obj) => {
				delete obj.feederId;
				return obj
			});
			if (resultArray.length === 0) {
				var errorinfo = "omsapi_v2_181: 404 : No jobs available within the provided time interval";
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatusCode", "404");
				logger.error("omsapi_v2_181: No jobs available within the provided time interval");
				session.reject("404: No jobs available within the provided time interval");
			}
			session.output.write(resultArray);
		}
	} else {
		var errorinfo = "omsapi_v2_182: 404: Jobs Not Found ";
		ilsctx.setVariable("errorDescription", errorinfo);
                ilsctx.setVariable("errorStatusCode", "404");
		logger.error("omsapi_v2_182: Jobs Not Found");
		session.reject("404: Jobs Not Found");

	}
}
