//This gateway script is to set context variables
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var qs = require('querystring');

var ctx = session.name("jobHistory") || session.createContext("jobHistory");
var uri = new String(sm.URI);
var json;
var premiseID;
var startDate;
var endDate;
var logger = console.options({
	'category': 'all'
});
//Set stylesheet parameters to variables

var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookUpURL;
var apiToken_chatbot = session.parameters.apiToken_chatbot;
var apiToken_maximo = session.parameters.apiToken_maximo;
var apiToken_reporting = session.parameters.apiToken_reporting;

//Set the retrieved stylesheet parameters to context variables to use it within the gateway script

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
ctx.setVariable("apiToken_maximo", apiToken_maximo);
ctx.setVariable("apiToken_reporting", apiToken_reporting);


if (uri.indexOf("?") != -1) {
	json = qs.parse(uri.substring(uri.indexOf("?") + 1));
	premiseID = json.premiseId;
	startDate = json.startDate;
	endDate = json.endDate;
}

if (premiseID === null || premiseID === undefined || premiseID === '') {
	var errorinfo = "omsapi_v2_171: 400 premiseId is mandatory and missing in input request";
	ilsctx.setVariable("errorDescription", errorinfo);
	logger.error("omsapi_v2_171: premiseId is mandatory and missing in input request");
	session.reject("400:premiseId is mandatory and missing in input request");
} else {
	ctx.setVariable("premiseID", premiseID);
}

if (startDate != undefined && startDate != "" && startDate != null) {
	ctx.setVariable("startDate", startDate);
} else {
	ctx.setVariable("startDate", "");
}

if (endDate != undefined && endDate != "" && endDate != null) {
	ctx.setVariable("endDate", endDate);
} else {
	ctx.setVariable("endDate", "");
}

if (new Date(startDate).getTime() > new Date(endDate).getTime()) {
	var errorinfo = "omsapi_v2_172: 400 startDate should not be greaterthan the endDate";
	ilsctx.setVariable("errorDescription", errorinfo);
	logger.error("omsapi_v2_172: startDate should not be greaterthan the endDate");
	session.reject("400: startDate should not be greaterthan the endDate");
}
