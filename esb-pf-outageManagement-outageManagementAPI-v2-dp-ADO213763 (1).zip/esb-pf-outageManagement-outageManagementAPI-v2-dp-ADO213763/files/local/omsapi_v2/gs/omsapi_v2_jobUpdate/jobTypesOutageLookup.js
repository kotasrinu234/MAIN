var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
var doLookup = require('./omsapi_lookup.js');
var getURLResponse = require('./omsapi_urlopen.js');
var omsUrl = session.parameters.omsExternalURL;
var jobIdResponse = ctx.getVariable('jobIdResponse');
var jobStatus = ctx.getVariable('jobStatus');
var prevResponseCode = ctx.getVariable("responseStatusCode");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var typeArr;
if (prevResponseCode === 401) {
	ctx.setVariable("customErrorCode", '401');
	ctx.setVariable("customErrorMessage", 'UnAuthorized');
	ctx.setVariable("customReasonMessage", 'UnAuthorized');
	var errorinfo = "Received error as unauthorized , details are : " + info + "; error info :" + error;
	ilsctx.setVariable("errorDescription", errorinfo);
	session.reject("UnAuthorized");
} else if (prevResponseCode === 403) {
	ctx.setVariable("customErrorCode", '403');
	ctx.setVariable("customErrorMessage", 'Forbidden');
	ctx.setVariable("customReasonMessage", 'Forbidden');
	var errorinfo = "Received error as Forbidden";
	ilsctx.setVariable("errorDescription", errorinfo);
	session.reject("Forbidden");
} else if (jobIdResponse === undefined || jobIdResponse === '' || jobIdResponse === null) {
	ctx.setVariable("customErrorCode", '404');
	ctx.setVariable("customErrorMessage", 'No Records Found');
	ctx.setVariable("customReasonMessage", 'No Records Found');
	var errorinfo = "Received error as No Records Found ";
	ilsctx.setVariable("errorDescription", errorinfo);
	session.reject("No Records Found");
} else {
	var internalJobID = jobIdResponse.id;
	var leadCallID = jobIdResponse.leadCallID;
	if (leadCallID === null || leadCallID === '' || leadCallID === undefined) {
		ctx.setVariable("leadCallID", '');
	}
	else {
		ctx.setVariable("leadCallID", leadCallID);
	}
	ctx.setVariable("internalJobID", internalJobID);
	var jobTypeID = jobIdResponse.jobTypeID;
	var ert = ctx.getVariable('ert');
	var ertComments = ctx.getVariable('ertComments');
	var causeCode = ctx.getVariable('causeCode');
	var causeCodeComments = ctx.getVariable('causeCodeComments');
	var jobSubType = ctx.getVariable('jobSubType');
	var jobSubTypeComments = ctx.getVariable('jobSubTypeComments');

	var jobStatusComments = ctx.getVariable('jobStatusComments');
	var photo = ctx.getVariable('photo');
	var jobComments = ctx.getVariable('jobComments');
	var resourceNeeded = ctx.getVariable('resourceNeeded');
	typeArr = new Array();
	var jobTypesReq = {};
	jobTypesReq.name = "jobTypes";
	jobTypesReq.id = jobTypeID;
	typeArr.push(jobTypesReq);
	if (typeArr.length > 0) {
		if (jobStatus != undefined) {
			doLookup(typeArr, "JobTypes");
		}
	}

	typeArr = new Array();
	var jobOutageTypesReq = {};
	jobOutageTypesReq.name = "jobOutageTypes";
	jobOutageTypesReq.id = jobTypeID;
	typeArr.push(jobOutageTypesReq);
	if (typeArr.length > 0) {
		if (jobStatus != undefined) {
			doLookup(typeArr, "JobOutage");
		}
	}

	typeArr = new Array();
	var resourceNeededReq = {};
	resourceNeededReq.name = "jobCustomFields";
	resourceNeededReq.externalLabel = "Resource_Needed";
	resourceNeededReq.label = resourceNeeded;
	typeArr.push(resourceNeededReq);
	if (typeArr.length > 0) {
		if (resourceNeeded != undefined) {
			doLookup(typeArr, "resourceNeeded");
		}
	}
}
