var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.jobUpdateEntryDescription;
var exitDescription = session.parameters.jobUpdateExitDescription;
var apiName = session.parameters.jobUpdateApiName;
var messageType = session.parameters.messageType;
ctx.setVariable("messageType", messageType);
ctx.setVariable("apiName", apiName);
ctx.setVariable('entryDescription', entryDescription);
ctx.setVariable('exitDescription', exitDescription);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.msgId !== undefined || incomingdata.msgId !== null || incomingdata.msgId !== '') {
			ctx.setVariable("correlationId", incomingdata.msgId)
		}
		var uri = sm.URI;
		var jobID = uri.substring(uri.lastIndexOf("/") + 1);
		if (jobID !== undefined || jobID !== null || jobID !== '') {
			ctx.setVariable("jobID", jobID)
		}
		if (incomingdata) {
			if (incomingdata.photo) {
				if (incomingdata.photo !== undefined || incomingdata.photo !== null || incomingdata.photo !== '') {
					ctx.setVariable("fileName", incomingdata.photo)
				}
			} if (incomingdata.jobStatus) {
				if (incomingdata.jobStatus.jobStatus) {
					if (incomingdata.jobStatus.jobStatus !== undefined || incomingdata.jobStatus.jobStatus !== null || incomingdata.jobStatus.jobStatus !== '') {
						ctx.setVariable("jobStatus", incomingdata.jobStatus.jobStatus)
					}
				}
			}
			if (incomingdata.jobSubType) {
				if (incomingdata.jobSubType.jobSubType) {
					if (incomingdata.jobSubType.jobSubType !== undefined || incomingdata.jobSubType.jobSubType !== null || incomingdata.jobSubType.jobSubType !== '') {
						ctx.setVariable("jobSubType", incomingdata.jobSubType.jobSubType)
					}
				}
			}
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
	}
});
