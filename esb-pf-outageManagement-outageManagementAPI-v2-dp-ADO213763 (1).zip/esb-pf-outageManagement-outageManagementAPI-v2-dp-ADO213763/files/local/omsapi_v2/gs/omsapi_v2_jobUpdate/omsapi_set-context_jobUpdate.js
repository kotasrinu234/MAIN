var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
//var errctx = session.name('error') || session.createContext('error');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
var getURLResponse = require('./omsapi_urlopen.js');
var doLookup = require('./omsapi_lookup.js');
/* var apiToken_OutageStatusApp = session.parameters.apiToken ;
ctx.setVariable("apiToken_OutageStatusApp", apiToken_OutageStatusApp);
var apiToken_chatbot=session.parameters.apiToken_chatbot;
ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
var apiToken_maximo=session.parameters.apiToken_maximo;
ctx.setVariable("apiToken_maximo", apiToken_maximo);
var apiToken_reporting=session.parameters.apiToken_reporting;
ctx.setVariable("apiToken_reporting", apiToken_reporting);
	
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var apiToken;
	
if(currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd'){
	apiToken = apiToken_OutageStatusApp;
	logger.error("inside OutageAPP----" +apiToken);
}else if(currentUser == 'dcas-cbo-esb-oms-dev' || currentUser == 'dcas-cbo-esb-oms-tst' || currentUser == 'dcas-cbo-esb-oms-prd'){
	apiToken = apiToken_chatbot;
	logger.error("inside chatbotAPP----" +apiToken);
} else if(currentUser == 'dcas-rpa-esb-oms-dev' || currentUser == 'dcas-rpa-esb-oms-tst' || currentUser == 'dcas-rpa-esb-oms-prd'){
	apiToken = apiToken_reportingApp;
	logger.error("inside reportAPP----" +apiToken);
} else if(currentUser == 'dcas-eam-sr-esb-dev' || currentUser == 'dcas-eam-sr-esb-tst' || currentUser == 'dcas-eam-sr-esb-prd'){
	apiToken = apiToken_maximo;
	logger.error("inside maximoAPP----" +apiToken);
}  
ctx.setVariable("apiToken", apiToken);

*/
session.input.readAsJSON(function(error, json) {
	if (error) {
		throw error;
	}
	var typeArr;
	ctx.setVariable("json", json)
	//getURLResponse(omsUrl+"/api/v1/ServiceType/Electric/Job/"+jobId, "jobIdResponse");

	if (json.msgId != undefined) {
		var msgId = json.msgId;
		ctx.setVariable("msgId", msgId);
	} else throw Error('msgId not present');


	if (json.etr != undefined && json.etr.etr != undefined) {
		var ert = json.etr.etr;
		var ertComments = json.etr.comments;
		ctx.setVariable("ert", ert);

		if (ertComments != undefined) {
			ctx.setVariable("ertComments", ertComments);
		}
	}

	if (json.causeCode != undefined && json.causeCode.causeCode != undefined) {
		var causeCode = json.causeCode.causeCode;
		var causeCodeComments = json.causeCode.comments;
		typeArr = new Array();
		var causeCodeReq = {};
		causeCodeReq.name = "jobCustomFields.workflows";
		causeCodeReq.label = causeCode;
		typeArr.push(causeCodeReq);
		if (typeArr.length > 0) {
			doLookup(typeArr, "CauseCode");
		}
		ctx.setVariable("causeCode", causeCode);

		if (causeCodeComments != undefined) {
			ctx.setVariable("causeCodeComments", causeCodeComments);
		}
	}


	if (json.jobSubType != undefined && json.jobSubType.jobSubType != undefined) {
		var jobSubType = json.jobSubType.jobSubType;
		var jobSubTypeComments = json.jobSubType.comments;
		ctx.setVariable("jobSubType", jobSubType);
		typeArr = new Array();
		var outageSubTypeReq = {};
		outageSubTypeReq.name = "outageSubtypes";
		outageSubTypeReq.label = jobSubType;
		typeArr.push(outageSubTypeReq);
		if (typeArr.length > 0) {
			doLookup(typeArr, "JobStatus");
		}

		if (jobSubTypeComments != undefined) {
			ctx.setVariable("jobSubTypeComments", jobSubTypeComments);
		}
	}


	if (json.jobStatus != undefined && json.jobStatus.jobStatus != undefined) {
		var jobStatus = json.jobStatus.jobStatus;
		var jobStatusComments = json.jobStatus.comments;
		ctx.setVariable("jobStatus", jobStatus);

		if (jobStatusComments != undefined) {
			ctx.setVariable("jobStatusComments", jobStatusComments);
		}
	}

	if (json.photo != undefined) {
		var photo = json.photo;
		ctx.setVariable("photo", photo);
	}

	if (json.jobComments != undefined) {
		var jobComments = json.jobComments;
		ctx.setVariable("jobComments", jobComments);
	}

	if (json.resourceNeeded != undefined) {
		var resourceNeeded = json.resourceNeeded;
		ctx.setVariable("resourceNeeded", resourceNeeded);
	}


})
