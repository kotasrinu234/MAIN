var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var url = session.parameters.lookUpURL;
var mAArray = [];
var lookUpArray = [];
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
//var url = "http://localhost:8080/lookup"; 

function doLookup(arrObj, lookupCtx) {
	console.info("array length " + arrObj.length);
	var request = {};
	request.type = arrObj;
	var lookupUrl = url;
	var options = {
		target: lookupUrl,
		method: 'post',
		contentType: 'application/json',
		data: { "lookupReq": request }
	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	// open connection to target
	urlopen.open(options, function(error, response) {
		var ctx = session.name('jobUpdate') || session.createContext('jobUpdate');
		if (error) {
			ctx.setVariable("customErrorCode", error.errorCode);
			ctx.setVariable("customErrorMessage", error.errorMessage);
			ctx.setVariable("customReasonPhrase", error.errorMessage);
			session.output.write("urlopen error: " + JSON.stringify(error));
			var errorinfo = "failure from lookup api , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
			session.reject(error.errorMessage);

		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					var ctx = session.name('jobUpdate') || session.createContext('jobUpdate');
					ctx.setVariable(lookupCtx + '_lookup', responseData);
					if (error) {
						// error while reading response or transferring data to Buffer
						session.output.write("readAsBuffer error: " + JSON.stringify(error));
					} else {
						if (lookupCtx === 'materialAffected') {
							var mAlookupResponse = responseData.lookupRep.type;
							var Identifier = responseData.lookupRep.type[0].status;
							mAArray.push(Identifier);
							lookUpArray.push(mAlookupResponse);
							ctx.setVariable("materialAffectedlookup", lookUpArray);
							ctx.setVariable("materialAffectedIdentifier", mAArray);
						}
						else {
							var lookupResponse = responseData.lookupRep.type;
							ctx.setVariable(lookupCtx + "_lookup", lookupResponse);
						}
					}
				});
			} else {
				session.output.write("urlopen target return statusCode " + lookupResponse);
			}
		}
	});
}//end of function 
module.exports = doLookup;
