var ctx = session.name("jobUpdate")|| session.createContext("jobUpdate");
//var errctx = session.name('error') || session.createContext('error');
var sm = require('service-metadata');
var logger = console.options({'category': 'all'});
var omsUrl = session.parameters.omsExternalURL;
var uri = sm.URI;
var chatbot_userId = session.parameters.chatbot_userId;
var outageapp_userId = session.parameters.outageapp_userId;
var reporting_userId = session.parameters.reporting_userId;
var jobId=uri.substring(uri.lastIndexOf("/")+1);
var userId='';

ctx.setVariable("jobId", jobId);
var apiToken_OutageStatusApp = session.parameters.apiToken ;
		ctx.setVariable("apiToken_OutageStatusApp", apiToken_OutageStatusApp);
		var apiToken_chatbot=session.parameters.apiToken_chatbot;
		ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
		var apiToken_maximo=session.parameters.apiToken_maximo;
		ctx.setVariable("apiToken_maximo", apiToken_maximo);
		var apiToken_reporting=session.parameters.apiToken_reporting;
		ctx.setVariable("apiToken_reporting", apiToken_reporting);
		
		var ctx1 = session.name("current") || session.createContext("current");
		var currentUser = ctx1.getVar("user");
		ctx.setVariable("currentUser", currentUser );
		var apiToken;
		
		if(currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd'){
    		apiToken = apiToken_OutageStatusApp;
			userId = outageapp_userId;
    		logger.info("inside OutageAPP----" +apiToken);
    	}else if(currentUser == 'dcas-cbo-esb-oms-dev' || currentUser == 'dcas-cbo-esb-oms-tst' || currentUser == 'dcas-cbo-esb-oms-prd'){
    		apiToken = apiToken_chatbot;
			userId = chatbot_userId;
    		logger.info("inside chatbotAPP----" +apiToken);
    	} else if(currentUser == 'dcas-rpa-esb-oms-dev' || currentUser == 'dcas-rpa-esb-oms-tst' || currentUser == 'dcas-rpa-esb-oms-prd'){
    		apiToken = apiToken_reporting;
			userId = reporting_userId;
    		logger.info("inside reportAPP----" +apiToken);
    	} else if(currentUser == 'dcas-eam-sr-esb-dev' || currentUser == 'dcas-eam-sr-esb-test' || currentUser == 'dcas-eam-sr-esb-prod'){
    		apiToken = apiToken_maximo;
			userId = '';
    		logger.info("inside maximoAPP----" +apiToken);
    	}else if (currentUser == 'urma-esb-dev' || currentUser == 'urma-esb-test' || currentUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}
  
		ctx.setVariable("apiToken", apiToken);
		ctx.setVariable("userId", userId);



var getURLResponse = require('./omsapi_urlopen.js');
getURLResponse(omsUrl+"/api/v1/ServiceType/Electric/Job/"+jobId, "jobIdResponse");
