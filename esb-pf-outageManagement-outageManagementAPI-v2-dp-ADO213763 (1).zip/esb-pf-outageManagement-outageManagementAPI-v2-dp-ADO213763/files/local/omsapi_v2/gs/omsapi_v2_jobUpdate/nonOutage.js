var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var urlopen = require('urlopen');
var doLookup = require('./omsapi_lookup.js');
var callURL = require('./callUrl.js');
var omsUrl = session.parameters.omsExternalURL;
var outageErrorDesc = session.parameters.outageErrorDesc;
var causeCodeErrorDesc = session.parameters.causeCodeErrorDesc;
var jobStatusCommentsErrorDesc = session.parameters.jobStatusCommentsErrorDesc;
var activeCrewAssignmentErrorDesc = session.parameters.activeCrewAssignmentErrorDesc;
var jobStatusLabel = ctx.getVariable('jobStatus');
var jobStatusComments = ctx.getVariable('jobStatusComments');
var JobWorkflowIDLookUpResp = ctx.getVariable("JobWorkflowID_lookup");
var internalJobID = ctx.getVariable('internalJobID');
var leadCallID = ctx.getVariable('leadCallID');
var outageTypeLabel = ctx.getVariable('outageTypeLabel');
var jobIdResponse = ctx.getVariable('jobIdResponse');
var materialAffectedIdentifier = ctx.getVariable('materialAffectedIdentifier')
var reporting_userId = session.parameters.reporting_userId;
var outageapp_userId = session.parameters.outageapp_userId;
var maximo_userId = session.parameters.maximo_userId;
var chatbot_userId = session.parameters.chatbot_userId;
var Urma_UserId = session.parameters.Urma_UserId;
var messageId = "";
var App = "";
var logger = console.options({
	'category': 'all'
});

var jobWorkflowIDStatus = "";
if (JobWorkflowIDLookUpResp != undefined && JobWorkflowIDLookUpResp !== null && JobWorkflowIDLookUpResp !== '') {
	jobWorkflowIDStatus = JobWorkflowIDLookUpResp[0].status;
	ctx.setVariable('jobWorkflowIDStatus', jobWorkflowIDStatus);
}
//var jobWorkflowID = JobTypesJobOutageLookUpResp.lookupRep.type[0].id;	
/* if(jobStatusLabel !== undefined ){
 outageTypeLabel = JobOutageLookUpResp[0].label;	
} */
/* if(outageTypeLabel !=="UNPLANNED_OUTAGE" && jobStatusLabel !== undefined && jobStatusLabel !== null && jobStatusLabel !== ''){  */
/* if(outageTypeLabel !=="UNPLANNED_OUTAGE" && outageTypeLabel !=='' && outageTypeLabel !==undefined && (jobStatusLabel !== 'Closed' && jobStatusLabel !== 'Canceled' && jobStatusLabel !== 'Completed') ){  */
if (outageTypeLabel !== '' && outageTypeLabel !== undefined && (jobStatusLabel !== 'Closed' && jobStatusLabel !== 'Canceled' && jobStatusLabel !== 'Completed')) {
	var url = omsUrl + "/api/v1/ServiceType/Electric/Job/" + internalJobID + "/WorkFlow"
	callURL(url, "POST", "NonOutage", jobWorkflowIDStatus);
}


/* if(outageTypeLabel ==="UNPLANNED_OUTAGE" && jobStatusLabel !== undefined && jobStatusLabel !== null && jobStatusLabel !== ''){ */
var incomingdata = ctx.getVariable('json')
var activeCrewAssignmentCount = jobIdResponse.activeCrewAssignmentCount;
if (outageTypeLabel === "UNPLANNED_OUTAGE") {
	if (incomingdata.jobStatus.jobStatus === 'Closed' || incomingdata.jobStatus.jobStatus === 'Completed') {
		if (!(incomingdata.causeCode) || !(incomingdata.causeCode.causeCode)) {
			ctx.setVariable("customErrorCode", '400');
			ctx.setVariable("customErrorMessage", causeCodeErrorDesc);
			ctx.setVariable("customReasonMessage", causeCodeErrorDesc);
			var errorinfo = "Recieved failure message , details are : " + info + "; error info :" + causeCodeErrorDesc;
			ilsctx.setVariable("errorDescription", errorinfo);
			session.reject(causeCodeErrorDesc);
		}
		else if (!(incomingdata.jobStatus.comments) || incomingdata.jobStatus.comments === '') {
			ctx.setVariable("customErrorCode", '400');
			ctx.setVariable("customErrorMessage", jobStatusCommentsErrorDesc);
			ctx.setVariable("customReasonMessage", jobStatusCommentsErrorDesc);
			var errorinfo = "Recieved failure message , details are : " + info + "; error info :" + jobStatusCommentsErrorDesc;
			ilsctx.setVariable("errorDescription", errorinfo);
			session.reject(jobStatusCommentsErrorDesc);
		}
		else if (activeCrewAssignmentCount !== 0) {
			ctx.setVariable("customErrorCode", '400');
			ctx.setVariable("customErrorMessage", activeCrewAssignmentErrorDesc);
			ctx.setVariable("customReasonMessage", activeCrewAssignmentErrorDesc);
			var errorinfo = "Recieved failure message , details are : " + info + "; error info :" + activeCrewAssignmentErrorDesc;
			ilsctx.setVariable("errorDescription", errorinfo);
			session.reject(activeCrewAssignmentErrorDesc);
		}
		else {
			var payload = {
				"customFieldValues": {
					"Remarks": incomingdata.jobStatus.comments,
					"completed_by_field": 'true',
					"MaterialAffected": materialAffectedIdentifier
				}
			};
			var patchURL = omsUrl + "/api/ServiceType/Electric/Job/" + internalJobID
			callURL(patchURL, "PATCH", "ertComments", payload);
			var StandaloneMQurl = session.parameters.MQURL;
			function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
			var uuid = uuidv4();
			if (incomingdata.msgId === undefined || incomingdata.msgId === null || incomingdata.msgId === '') {
				messageId = uuid;
			}
			else {
				messageId = incomingdata.msgId
			}
			var ctx1 = session.name("current") || session.createContext("current");
			var currentUser = ctx1.getVar("user");

			if (currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd') {
				App = outageapp_userId;
			}
			else if (currentUser == 'dcas-cbo-esb-oms-dev' || currentUser == 'dcas-cbo-esb-oms-tst' || currentUser == 'dcas-cbo-esb-oms-prd') {
				App = chatbot_userId;
			} else if (currentUser == 'dcas-rpa-esb-oms-dev' || currentUser == 'dcas-rpa-esb-oms-tst' || currentUser == 'dcas-rpa-esb-oms-prd') {
				App = reporting_userId;
			} else if (currentUser == 'dcas-eam-sr-esb-dev' || currentUser == 'dcas-eam-sr-esb-tst' || currentUser == 'dcas-eam-sr-esb-prod') {
				App = maximo_userId;
			}else if (currentUser == 'urma-esb-dev' || currentUser == 'urma-esb-test' || currentUser == 'urma-esb-prod') {
				App = Urma_UserId;
			}
			ctx.setVariable("App", App);
			var inputdata = {
				"msgId": messageId,
				"serviceName": "Interface34/35",
				"jobId": internalJobID,
				"timesStamp": new Date().toISOString(),
				"userId": App
			};
			// ADO 111189 code related to outagejobcompletion commented
			//ADO 132294 code related to outagejobcompletion commented is uncommented
			/*if (currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd') {

			}
			else {*/
				sendToQueue(StandaloneMQurl, inputdata);
			/*}*/
		}
	}
	else {
		ctx.setVariable("customErrorCode", '400');
		ctx.setVariable("customErrorMessage", outageErrorDesc);
		ctx.setVariable("customReasonMessage", outageErrorDesc);
		session.reject(outageErrorDesc);
	}
}
/* var status=2;
var url = omsUrl+ "/api/v1/ServiceType/Electric/Call/"+leadCallID+"/Status"
	
	callURL(url,"POST","leadCallID",status); */

/*ctx.setVariable("customErrorCode", '400');
ctx.setVariable("customErrorMessage", outageErrorDesc);
ctx.setVariable("customReasonMessage", outageErrorDesc);
session.reject(outageErrorDesc);*/




var commentsURL = omsUrl + "/api/v1/ServiceType/Electric/Job/" + internalJobID + "/Comment";
//var remarksURL = omsUrl+"/api/v1/ServiceType/Electric/Job/"+internalJobID;
var json = {};

/* if(outageTypeLabel !=="UNPLANNED_OUTAGE" && jobStatusLabel !== undefined && jobStatusLabel !== null && jobStatusLabel !== ''){ 
if(jobStatusComments !=undefined && jobStatusComments!=null && jobStatusComments!=""){
	var remarks = { "customFieldValues": {"Remarks": jobStatusComments}};
	callURL(remarksURL,"PATCH","remarks",remarks);
}
}
 */
var ertComments = ctx.getVariable("ertComments");
if (ertComments != undefined && ertComments != null && ertComments != "") {
	json = {};
	json.comment = ertComments;
	callURL(commentsURL, "POST", "ertComments", json);
}

var causeCodeComments = ctx.getVariable("causeCodeComments");
if (causeCodeComments != undefined && causeCodeComments != null && causeCodeComments != "") {
	json = {};
	json.comment = causeCodeComments;
	callURL(commentsURL, "POST", "causeCodeComments", json);
}


var jobSubTypeComments = ctx.getVariable("jobSubTypeComments");
if (jobSubTypeComments != undefined && jobSubTypeComments != null && jobSubTypeComments != "") {
	json = {};
	json.comment = jobSubTypeComments;
	callURL(commentsURL, "POST", "jobSubTypeComments", json);
}
/* var jobStatusComments = ctx.getVariable("jobStatusComments");
if(jobStatusComments !=undefined && jobStatusComments!=null && jobStatusComments!=""){
	json = {};
	json.comment=jobStatusComments;
	callURL(commentsURL,"POST","jobStatusComments",json);
} */
var jobComments = ctx.getVariable("jobComments");
if (jobComments != undefined && jobComments != null && jobComments != "") {
	json = {};
	json.comment = jobComments;
	callURL(commentsURL, "POST", "jobComments", json);
}

function sendToQueue(targetQueue, incomingdata) {
	var pushingToQueue = {
		target: targetQueue,
		data: incomingdata
	};
	var info = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";
	urlopen.open(pushingToQueue, function(error, response) {
		var hm = require('header-metadata');
		if (error) {
			var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
			var mqconnection = 'Forbidden';
			ctx.setVariable("mqconnection", mqconnection);
			logger.error(" error while keeping receivecall message to queue is " + error);
			var errorinfo = "error while keeping receivecall message to queue is , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			session.reject(" error while keeping receivecall message to queue is " + error);
		} else {
			var mqrc = response.statusCode;
			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						hm.response.statusCode = 500
						var errorinfo = "error while keeping receivecall message to queue is , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						session.reject("error while keeping message receivecall to queue is " + error);
					} else {
						logger.debug("MQResponsecode " + mqrc);
					}
				});
			} else {
				var ctx = session.name("foa") || session.createContext("foa");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				var errorinfo = "response code receivecall is urlopen.open error, details are : " + info + "; error info :" + mqrc;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("TaskUpdate_001 : response code receivecall urlopen.open error of  Queue OMSAPITASK.UPDATE [MQRC=" + mqrc + "]");
				session.reject(" response code receivecall is urlopen.open error [MQRC=" + mqrc + "]");
			}
		}
	});
}
