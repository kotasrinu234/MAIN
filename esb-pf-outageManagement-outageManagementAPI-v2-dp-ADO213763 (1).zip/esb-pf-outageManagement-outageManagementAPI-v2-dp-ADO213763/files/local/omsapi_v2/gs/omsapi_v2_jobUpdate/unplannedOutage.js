var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
var doLookup = require('./omsapi_lookup.js');
var callURL = require('./callUrl.js');
var omsUrl = session.parameters.omsExternalURL;
var changeReason = session.parameters.changeReason;
var typeArr;
var jobStatusLabel = ctx.getVariable('jobStatus');
if (jobStatusLabel == 'Closed') {
	var jobStatusLabel2 = 'Canceled';
}
else {
	var jobStatusLabel2 = jobStatusLabel;
}
var jobStatus = ctx.getVariable('jobStatus');
var JobTypesLookUpResp = ctx.getVariable("JobTypes_lookup");
var JobOutageLookUpResp = ctx.getVariable("JobOutage_lookup");
var JobStatusLookUpResp = ctx.getVariable("JobStatus_lookup");
var CauseCodeLookUpResp = ctx.getVariable("CauseCode_lookup");
var resourceNeededLookUpResp = ctx.getVariable("resourceNeeded_lookup");
var causeCode = ctx.getVariable('causeCode');
var resourceNeeded = ctx.getVariable('resourceNeeded');
var jobSubType = ctx.getVariable('jobSubType');
var leadCallID = ctx.getVariable('leadCallID');
var internalJobID = ctx.getVariable('internalJobID');
var materialAffected = [];
var outageTypeLabel = '';
var jobWorkflowID = '';
var causeCodeStatus = "";
if (CauseCodeLookUpResp !== undefined && CauseCodeLookUpResp !== null && CauseCodeLookUpResp !== '') {
	causeCodeStatus = CauseCodeLookUpResp[0].status;
}

var resourceNeededId = "";
if (resourceNeededLookUpResp !== undefined && resourceNeededLookUpResp !== null && resourceNeededLookUpResp !== '') {
	resourceNeededId = resourceNeededLookUpResp[0].status;
}

var jobStatusID = "";
if (JobStatusLookUpResp !== undefined && JobStatusLookUpResp !== null && JobStatusLookUpResp !== '') {
	jobStatusID = JobStatusLookUpResp[0].id;
}
if (jobStatus != undefined) {
	jobWorkflowID = JobTypesLookUpResp[0].id;
	outageTypeLabel = JobOutageLookUpResp[0].label;
	ctx.setVariable('outageTypeLabel', outageTypeLabel);
}
/* if(outageTypeLabel !="UNPLANNED_OUTAGE" && outageTypeLabel !='' && outageTypeLabel !==undefined && jobStatusLabel !== undefined && jobStatusLabel !== null && jobStatusLabel !== ''){ */
if (outageTypeLabel != '' && outageTypeLabel !== undefined && jobStatusLabel !== undefined && jobStatusLabel !== null && jobStatusLabel !== '') {
	typeArr = new Array()
	var jobWorkflowReq = {};
	jobWorkflowReq.name = "jobTypes.workflows";
	jobWorkflowReq.id = jobWorkflowID;
	jobWorkflowReq.label = jobStatusLabel2;
	typeArr.push(jobWorkflowReq);
	doLookup(typeArr, "JobWorkflowID");
}
var incomingdata = ctx.getVariable('json')
var mAArr;
if (incomingdata.materialAffected != undefined && incomingdata.materialAffected.length > 0 && incomingdata.materialAffected != null) {
	materialAffected = incomingdata.materialAffected;
	var materialAffectedList = {};
	for (var i = 0; i < materialAffected.length; i++) {
		mAArr = new Array();
		materialAffectedList.name = "jobCustomFields.materialAffected";
		materialAffectedList.label = materialAffected[i];
		mAArr.push(materialAffectedList);
		doLookup(mAArr, "materialAffected");
		ctx.setVariable("materialAffected", materialAffected);
	}
}
var req = {};

var ert = ctx.getVariable('ert');
//if(ert != undefined && ert !=null && ert !=''){
if (ert != undefined) {
	var publishedEtr = {};
	publishedEtr.overridden = true;
	publishedEtr.value = ert;
	req.publishedEtr = publishedEtr;
	req.etrStatus = 'OVERRIDDEN';
	req.changeReason = changeReason;

}
var customFieldValues = {};

if (causeCode != undefined && causeCode != null && causeCode != '') {
	customFieldValues.cause = causeCodeStatus;
	req.customFieldValues = customFieldValues;
}
if (causeCode != undefined && causeCode != null && causeCode === '') {
	customFieldValues.cause = null;
	req.customFieldValues = customFieldValues;
}

if (jobSubType != undefined && jobSubType != null && jobSubType != '') {
	req.outageSubtypeID = jobStatusID;
}
if (jobSubType != undefined && jobSubType != null && jobSubType === '') {
	req.outageSubtypeID = null;
}

if (resourceNeeded != undefined && resourceNeeded != null && resourceNeeded != '') {
	//var customFieldValues={};
	customFieldValues.Resource_Needed = resourceNeededId;
	req.customFieldValues = customFieldValues;
}
if (resourceNeeded != undefined && resourceNeeded != null && resourceNeeded === '') {
	customFieldValues.Resource_Needed = null;
	req.customFieldValues = customFieldValues;
}

if (Object.keys(req).length !== 0)
	callURL(omsUrl + "/api/v1/ServiceType/Electric/Job/" + internalJobID, "PATCH", "jobUpdate", req);
