var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var apiToken_OutageStatusApp = session.parameters.apiToken;
ctx.setVariable("apiToken_OutageStatusApp", apiToken_OutageStatusApp);
var apiToken_chatbot = session.parameters.apiToken_chatbot;
ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
var apiToken_maximo = session.parameters.apiToken_maximo;
ctx.setVariable("apiToken_maximo", apiToken_maximo);
var apiToken_reporting = session.parameters.apiToken_reporting;
ctx.setVariable("apiToken_reporting", apiToken_reporting);
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
ctx.setVariable("currentUser", currentUser);
var apiToken;
if (currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;
} else if (currentUser == 'dcas-cbo-esb-oms-dev' || currentUser == 'dcas-cbo-esb-oms-tst' || currentUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;
} else if (currentUser == 'dcas-rpa-esb-oms-dev' || currentUser == 'dcas-rpa-esb-oms-tst' || currentUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reporting;
} else if (currentUser == 'dcas-eam-sr-esb-dev' || currentUser == 'dcas-eam-sr-esb-test' || currentUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;
} else if (currentUser == 'urma-esb-dev' || currentUser == 'urma-esb-test' || currentUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
function callURL(url, method, myctx, payload) {
	var options = {
		target: url,
		method: method,
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "omsapi_client_profile"
	};
	if (method == "POST" || method == "PATCH") {
		options.data = payload;
	}
	var info = " TargetURL :" + options + "; Method :" + options.method + "; Data :" + JSON.stringify(payload) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				throw error;
			} else {
				var responseStatusCode = response.statusCode;
				var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
				ctx.setVariable(myctx + "_responseStatusCode", responseStatusCode);
				ctx.setVariable(myctx + "_response", response);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, data) {
						if (error) {
							logger.error("omsfoa_047 Error in reading response data");
							throw error;
						} else {
							var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
							ctx.setVariable(myctx + '_response', data);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							logger.error("failure in reading message" + JSON.stringify(error));
						} else {
							var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
							ctx.setVariable(myctx + '_buffer_response', "" + responseData);
							logger.error("response received with responseStatusCode " + responseStatusCode + " " + responseData);
							var responseDataStr = "" + responseData;
							ctx.setVariable(myctx + '_buffer_response2', responseDataStr);
							if (responseStatusCode == 400 && responseDataStr !== 'No updates') {
								ctx.setVariable("customErrorCode", '400');
								ctx.setVariable("customErrorMessage", 'Bad Request');
								ctx.setVariable("customReasonMessage", 'Bad Request');
								var errorinfo = responseDataStr + ", details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								session.reject("Bad Request");
							}
						}
					});
					if (responseStatusCode == 403) {
						ctx.setVariable("customErrorCode", '403');
						ctx.setVariable("customErrorMessage", 'Forbidden');
						ctx.setVariable("customReasonMessage", 'Forbidden');
						var errorinfo = "Forbidden , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						session.reject("Forbidden");
					} else if (responseStatusCode == 404) {
						ctx.setVariable("customErrorCode", '404');
						ctx.setVariable("customErrorMessage", 'No Records Found');
						ctx.setVariable("customReasonMessage", 'No Records Found');
						var errorinfo = "No Records Found , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						session.reject("No Records Found");
					} else if (responseStatusCode == 500) {
						ctx.setVariable("customErrorCode", '500');
						ctx.setVariable("customErrorMessage", 'Server Error');
						ctx.setVariable("customReasonMessage", 'Server Error');
						var errorinfo = "Server Error , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						session.reject("Server Error");
					}
				}
			}
		});
	}
	catch (error) {
		throw error;
	}
}
module.exports = callURL;
