var ctx = session.name("jobUpdate")|| session.createContext("jobUpdate");
var jobStatusComments = ctx.getVariable("jobStatusComments");
var sm = require('service-metadata');
var omsUrl = session.parameters.omsExternalURL;
var callURL = require('./callUrl.js');
var internalJobID =  ctx.getVariable('internalJobID');
var materialAffected = ctx.getVar("materialAffected");
var commentsURL = omsUrl+"/api/v1/ServiceType/Electric/Job/"+internalJobID+"/Comment";
var remarksURL = omsUrl+"/api/v1/ServiceType/Electric/Job/"+internalJobID;
var mCallURL = omsUrl+"/api/ServiceType/Electric/Job/" + internalJobID
var jobWorkflowIDStatus= ctx.getVariable("jobWorkflowIDStatus");
var outageTypeLabel='';
var materialAffectedIdentifier = ctx.getVariable('materialAffectedIdentifier')
var JobOutageLookUpResp = ctx.getVariable("JobOutage_lookup");
var jobStatusLabel =  ctx.getVariable('jobStatus');

if(jobStatusLabel !== undefined ){
 outageTypeLabel = JobOutageLookUpResp[0].label;	
}


/* if(outageTypeLabel !=="UNPLANNED_OUTAGE" && jobStatusLabel !== undefined && jobStatusLabel !== null && jobStatusLabel !== ''){  */
if(outageTypeLabel !=="UNPLANNED_OUTAGE" && (jobStatusLabel === 'Closed'|| jobStatusLabel === 'Canceled'||jobStatusLabel === 'Completed') ){
if(jobStatusComments !== undefined && jobStatusComments!== null && jobStatusComments!== ""){
	var remarks = { "customFieldValues": {"Remarks": jobStatusComments}};
	callURL(remarksURL,"PATCH","remarks",remarks);
}
}

var json={};
if(jobStatusComments !== undefined && jobStatusComments!== null && jobStatusComments!== ""){
	json.comment=jobStatusComments;
	callURL(commentsURL,"POST","jobStatusComments",json);
}

/* if(outageTypeLabel !=="UNPLANNED_OUTAGE" && (jobStatusLabel === 'Closed'|| jobStatusLabel === 'Canceled') ){ 
var url = omsUrl+ "/api/v1/ServiceType/Electric/Job/"+internalJobID+"/WorkFlow"
	callURL(url,"POST","NonOutage",jobWorkflowIDStatus);
} */

if(materialAffected !== null && materialAffected !== undefined && materialAffected !== ''){
	if(outageTypeLabel !== "UNPLANNED_OUTAGE"){
		var mAffected = {"customFieldValues":{"MaterialAffected" : materialAffectedIdentifier }}
		callURL(mCallURL, "PATCH", "mAffected", mAffected);
	}
}
