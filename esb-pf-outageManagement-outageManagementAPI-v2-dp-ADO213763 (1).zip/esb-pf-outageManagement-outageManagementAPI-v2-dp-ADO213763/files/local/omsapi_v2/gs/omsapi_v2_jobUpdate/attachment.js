var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('jobUpdate') || session.createContext('jobUpdate');
var userId = ctx.getVariable("userId");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//if(incomingdata.includes('Attachments'))
		if (incomingdata.photo) {
			var ctx = session.name('jobUpdate') || session.createContext('jobUpdate');
			ctx.setVariable('action', 'attachments');
			var attachment = incomingdata.photo;
			if ((attachment != "") || (attachment != null)) {
				var jobIdResponse = ctx.getVariable('jobIdResponse');
				var internalJobID = jobIdResponse.id;
				var filename = attachment.substring(attachment.lastIndexOf("/") + 1);
				ctx.setVariable("filename", filename);
				var AttachmentUrl = session.parameters.AttachmentUrl;
				var checkForDup = session.parameters.checkForDup;
				//var downloadType = session.parameters.downloadType;
				var asyncReplyFlag = session.parameters.asyncReplyFlag;
				var Attachmentpayload = {};
				Attachmentpayload.asyncReplyFlag = asyncReplyFlag;
				Attachmentpayload.downloadType = 2;
				Attachmentpayload.checkForDup = checkForDup;
				Attachmentpayload.id = internalJobID;
				Attachmentpayload.url = attachment;
				Attachmentpayload.fileName = filename;
				Attachmentpayload.userId = userId;
				var AttachmentApi = {
					target: AttachmentUrl,
					sslClientProfile: 'omsapi_v2_attachment_ClientProfile',
					method: 'POST',
					contentType: 'application/json',
					data: Attachmentpayload
				};
				var info = " TargetURL :" + AttachmentApi.target + "; Method :" + "POST" + "; Data :" + JSON.stringify(AttachmentApi.data) + ". ";
				try {
					urlopen.open(AttachmentApi, function(error, response) {
						if (error) {
							// an error occurred during request sending or response header parsing
							var errorinfo = "id=omsapi_v2_154|Error while calling AttachmentApi , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("id=omsapi_v2_154|urlopen connect error with AttachmentApi" + JSON.stringify(error));
							session.reject(
								"id=omsapi_v2_154|Error while calling AttachmentApi");
						} else {
							// read response data
							// get the response status code
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										// error while reading response or transferring data
										logger.error("id=omsapi_v2_155|failure in putting message to AttachmentApi" + JSON.stringify(error));
									} else {
										hm.response.statusCode = '200 OK';
										logger.debug("response received from AttachmentApi call:" + responseData);
									}
								});
							} else {
								hm.current.statusCode = responseStatusCode;
								logger.error("Error returned from AttachmentApi call" + " : with statusCode " + responseStatusCode);
								var errorinfo = "id=omsapi_v2_156|Error returned from  AttachmentApi call " + responseStatusCode + ", details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								hm.response.statusCode = responseStatusCode;
								session.reject("id=omsapi_v2_156|Error returned from  AttachmentApi call");
							}
						}
					});
				}
				catch (error) {
					var errorinfo = "id=omsapi_v2_154|Error while calling AttachmentApi , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error("id=omsapi_v2_154|urlopen connect error with AttachmentApi" + JSON.stringify(error));
					session.reject(
						"id=omsapi_v2_154|Error while calling AttachmentApi");
				}
			}
		}
	}
	/*End Of AttachmentAPI Call*/
});
