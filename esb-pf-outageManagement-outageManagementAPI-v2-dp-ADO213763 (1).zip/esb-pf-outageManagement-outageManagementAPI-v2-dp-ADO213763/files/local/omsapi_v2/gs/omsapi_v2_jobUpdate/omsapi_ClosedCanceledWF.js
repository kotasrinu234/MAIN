var ctx = session.name("jobUpdate")|| session.createContext("jobUpdate");
var sm = require('service-metadata');
var callURL = require('./callUrl.js');
var omsUrl = session.parameters.omsExternalURL;
var url = omsUrl+ "/api/v1/ServiceType/Electric/Job/"+internalJobID+"/WorkFlow"
var internalJobID =  ctx.getVariable('internalJobID');
var jobWorkflowIDStatus= ctx.getVariable("jobWorkflowIDStatus");
var outageTypeLabel=ctx.getVariable('outageTypeLabel');
var jobStatusLabel =  ctx.getVariable('jobStatus');

if(outageTypeLabel !=="UNPLANNED_OUTAGE" && outageTypeLabel !=='' && outageTypeLabel !==undefined && (jobStatusLabel === 'Closed'|| jobStatusLabel === 'Canceled'||jobStatusLabel === 'Completed') ){ 
var url = omsUrl+ "/api/v1/ServiceType/Electric/Job/"+internalJobID+"/WorkFlow"
	callURL(url,"POST","NonOutage",jobWorkflowIDStatus);
}

var response = {};
response.msgId = ctx.getVariable("msgId");
session.output.write(response);