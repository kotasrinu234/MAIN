var ctx = session.name("jobUpdate") || session.createContext("jobUpdate");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma; 
}else{
	apiToken = ctx.getVariable("apiToken");
}
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
function getURLResponse(url, myctx) {
	var options = {
		target: url,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "omsapi_client_profile"

	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				ctx.setVariable("customErrorCode", '500');
				ctx.setVariable("customErrorMessage", 'Internal Server Error');
				ctx.setVariable("customReasonMessage", 'Internal Server Error');
				var errorinfo = "urlopen error: , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				session.output.write("urlopen error: " + JSON.stringify(error));
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							logEvent("readAsJSON error: " + JSON.stringify(error), "");
							session.output.write("readAsJSON error: " + JSON.stringify(error));
						} else {
							var ctx = session.name('jobUpdate') || session.createContext('jobUpdate');
							ctx.setVariable(myctx, responseData);

						}
					})

				}
			}
		});
	}
	catch (error) {
		ctx.setVariable("customErrorCode", '500');
		ctx.setVariable("customErrorMessage", 'Internal Server Error');
		ctx.setVariable("customReasonMessage", 'Internal Server Error');
		var errorinfo = "urlopen error: , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		session.output.write("urlopen error: " + JSON.stringify(error));
		logger.error(errorinfo);
		session.reject(errorinfo);
	}
}

module.exports = getURLResponse;
