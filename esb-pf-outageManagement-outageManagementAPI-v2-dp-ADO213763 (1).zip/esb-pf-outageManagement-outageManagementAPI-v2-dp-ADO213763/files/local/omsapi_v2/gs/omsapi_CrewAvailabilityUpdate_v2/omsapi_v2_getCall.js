var ctx = session.name("Crew_Avail") || session.createContext("Crew_Avail");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var Inp_crewId = ctx.getVariable("crewId");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var disposition_check = ctx.getVar("disposition_check");
var Disposition = ctx.getVar("Disposition");
var Disposition_new = ctx.getVar("Disposition_new");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var msgId = ctx.getVar("msgId");

var logger = console.options({
	'category': 'all'
});
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;

} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;

} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;

} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;

}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}

session.input.readAsJSON(function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		// uncatched error will stop the processing and the error will be logged
		var errorinfo = "Error in reading incoming data " + msgId + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("Error in reading incoming data " + msgId + JSON.stringify(error));
		session.reject("Error in reading incoming data" + msgId + JSON.stringify(error));
	}
	else {
		if (Inp_crewId == null || Inp_crewId == '' || Inp_crewId == undefined) {
			var errorinfo = "CrewId not found" + msgId + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("CrewId not found" + msgId + JSON.stringify(error));
			session.reject("CrewId not found" + msgId + JSON.stringify(error));
		}
		else {
			var getURL = omsExternalURL + '/api/ServiceType/Electric/Crew/' + Inp_crewId;
			var getCall = {
				target: getURL,
				sslClientProfile: 'omsapi_client_profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': apiToken
				},
			};
			var info = " TargetURL :" + getCall.target + "; Method :" + getCall.method + ". ";
			try {
				urlopen.open(getCall, function(error, response) {
					if (error) {
						var errorinfo = "omsapiv2_137 urlopen connect error with CrewAvailabilityUpdateGet for Inp_crewId " + msgId + " , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatusCode", "500");
						logger.error("omsapiv2_137 urlopen connect error with CrewAvailabilityUpdateGet for Inp_crewId " + msgId + " with error as " + JSON.stringify(error));
						session.reject(errorinfo);

					}
					else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading message from CrewAvailabilityUpdateGet" + msgId + " , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", "500");
									logger.error("failure in reading message from CrewAvailabilityUpdateGet" + msgId + JSON.stringify(error));
									session.reject(errorinfo);
								}
								else {
									ctx.setVariable("CrewAvailUpdateresponseData", JSON.parse(responseData));
								}
							});
						}
						else if (responseStatusCode == 404) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading the response data from CrewAvailabilityUpdateGet , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error("Failure in reading the response data from CrewAvailabilityUpdateGet" + JSON.stringify(error));
									session.reject(errorinfo);
								}
								else {
									var crewNotFoundObject = {
										"msgId": msgId,
										"errorCode": "404",
										"errorDescription": "Crew not found"
									};
									hm.current.statusCode = responseStatusCode;
									var errorDesc = JSON.stringify(crewNotFoundObject);
									logger.error(errorDesc);
									var errorinfo = "details are : " + info + "; error info :" + JSON.stringify(crewNotFoundObject);
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error(JSON.stringify(crewNotFoundObject));
									session.reject(JSON.stringify(crewNotFoundObject));

								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "failure in reading message from CrewAvailabilityUpdateGet api  for  crewId " + msgId + " , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error("failure in reading message from CrewAvailabilityUpdateGet api  for  crewId " + msgId + JSON.stringify(error));
									session.reject(errorinfo);

								} else {
									var errorinfo = "omsapiv2_183:Error code returned from CrewAvailabilityUpdateGet api  for  crewId: " + msgId + " statusCode " + responseStatusCode + " details are : " + info + "; response info :" + responseData
									ilsctx.setVariable('errorDescription', errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error("omsapiv2_183:Error code returned from CrewAvailabilityUpdateGet api  for  crewId: " + msgId + " statusCode " + responseStatusCode + " " + responseData);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			}
			catch (error) {
				var errorinfo = "omsapiv2_137 urlopen connect error with CrewAvailabilityUpdateGet for Inp_crewId " + msgId + " , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatusCode", "500");
				logger.error("omsapiv2_137 urlopen connect error with CrewAvailabilityUpdateGet for Inp_crewId " + msgId + " with error as " + JSON.stringify(error));
				session.reject(errorinfo);
			}
		}
	}
});
