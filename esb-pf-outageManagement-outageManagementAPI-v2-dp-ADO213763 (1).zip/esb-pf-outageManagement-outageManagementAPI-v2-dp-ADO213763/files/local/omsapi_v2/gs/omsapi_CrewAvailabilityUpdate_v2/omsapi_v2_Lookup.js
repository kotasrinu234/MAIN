var urlopen = require('urlopen');
var ctx = session.name("Crew_Avail") || session.createContext("Crew_Avail");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var hm = require('header-metadata');
var sm = require('service-metadata');
var lookupURL = ctx.getVariable("lookupURL");
var crewStatus = ctx.getVariable("crewStatus");
var Inp_crewId = ctx.getVariable("crewId");
var msgId = ctx.getVariable("msgId");
var logger = console.options({
	'category': 'all'
});
if (crewStatus == '' || crewStatus == null || crewStatus == undefined) { }
else {
	session.input.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			// an error occurred when parsing the content, e.g. invalid JSON object
			// uncatched error will stop the processing and the error will be logged
			var errorinfo = "Error in reading incoming data ; error info :" + readAsJSONError;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("Error in reading incoming data");
			session.reject("Error in reading incoming data")
		}
		else {
			var crewstatuslookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "crewCustomFields",
							"externalLabel": "crewStatusCustom",
							"label": crewStatus
						}
					]
				}
			}
			var crewstatuslookupResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: crewstatuslookupMessage
			};
			var info = " TargetURL :" + crewstatuslookupResponse.target + "; Method :" + crewstatuslookupResponse.method + ".";
			try {
				urlopen.open(crewstatuslookupResponse, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error from crewstatuslookupResponse" + msgId + " , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatusCode", "500");
						logger.error("urlopen connect error from crewstatuslookupResponse" + msgId + JSON.stringify(error));
						session.reject(errorinfo);
					}
					else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading the message for crewstatuslookupResponse" + msgId + " , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", "500");
									logger.error("Failure in reading the message for crewstatuslookupResponse" + msgId + JSON.stringify(error));
									session.reject(errorinfo);
								}
								else {
									hm.response.statusCode = responseStatusCode;
									ctx.setVariable("res", responseData);
									var type = responseData.lookupRep.type
									if (responseData.lookupRep.type[0].result == 0) {
										var identifier = responseData.lookupRep.type[0].status;
										if (identifier == '' || identifier == null || identifier == undefined) { }
										else {
											ctx.setVariable("identifier", identifier);
										}
									}
									else {
										var errorinfo = "crew status " + crewStatus + " lookup response for crew " + Inp_crewId + " is null , details are : " + info + "; response info :" + JSON.stringify(responseData);
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", "500");
										logger.error("crew status " + crewStatus + " lookup response for crew " + Inp_crewId + " is null " + JSON.stringify(responseData))
										session.reject(errorinfo);
									}
								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading the message for crewstatuslookupResponse , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
									session.reject(errorinfo);
								} else {
									var errorinfo = "Error received in reading lookup response data " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error("Error received in reading lookup response data " + responseStatusCode + responseData);
									session.reject(errorinfo);

								}
							})
						}
					}
				});
			}
			catch (error) {
				var errorinfo = "urlopen connect error from crewstatuslookupResponse" + msgId + " , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatusCode", "500");
				logger.error("urlopen connect error from crewstatuslookupResponse" + msgId + JSON.stringify(error));
				session.reject(errorinfo);
			}
		}
	});
}
