var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
var EntryDescription = session.parameters.CrewavaiupdateEntryDescription;
var ExitDescription = session.parameters.CrewavaiupdateExitDescription;
var messagetype = session.parameters.messageType;
var apiName = session.parameters.CrewavaiupdateapiName;
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ILSctx.setVariable('userId', userId);
if (apiName !== undefined || apiName !== null || apiName !== '') {
	ILSctx.setVariable("apiName", apiName);
}
if (EntryDescription !== undefined || EntryDescription !== null || EntryDescription !== '') {
	ILSctx.setVariable('EntryDescription', EntryDescription);
}
if (ExitDescription !== undefined || ExitDescription !== null || ExitDescription !== '') {
	ILSctx.setVariable('description', ExitDescription);
}
if (messagetype !== undefined || messagetype !== null || messagetype !== '') {
	ILSctx.setVariable('messageType', messagetype);
}
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		//var correlationID = msgId;
		var URL = sm.getVar('var://service/URI');
		var URI = URL.toString().split("/");
		var crewDisplayID = URI[4];
		if (crewDisplayID == null || crewDisplayID == '' || crewDisplayID == undefined) {
			ILSctx.setVariable("crewDisplayID", '');
		}
		else {
			ILSctx.setVariable("crewDisplayID", crewDisplayID);
		}
			if (incomingdata.msgId) {
			if (incomingdata.msgId !== undefined || incomingdata.msgId !== null || incomingdata.msgId !== '') {
				ILSctx.setVariable("correlationID", incomingdata.msgId)
			}
		}
			
		if (incomingdata.crewAssignmentStatus) {
			if (incomingdata.crewAssignmentStatus !== undefined || incomingdata.crewAssignmentStatus !== null || incomingdata.crewAssignmentStatus !== '') {
				ILSctx.setVariable("assignmentStatus", incomingdata.crewAssignmentStatus)
			}
		}
		if (incomingdata.longitude) {
			if (incomingdata.longitude !== undefined || incomingdata.longitude !== null || incomingdata.longitude !== '') {
				ILSctx.setVariable("longitude", incomingdata.longitude)
			}
		}
		if (incomingdata.latitude) {
			if (incomingdata.latitude !== undefined || incomingdata.latitude !== null || incomingdata.latitude !== '') {
				ILSctx.setVariable("latitude", incomingdata.latitude)
			}
		}
		ILSctx.setVariable("sourceEventTimestamp", new Date().toISOString())
	}
});
