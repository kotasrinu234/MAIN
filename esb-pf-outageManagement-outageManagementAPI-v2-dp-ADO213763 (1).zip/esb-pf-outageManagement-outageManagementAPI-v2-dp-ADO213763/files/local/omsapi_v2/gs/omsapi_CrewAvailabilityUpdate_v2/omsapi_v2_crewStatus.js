var urlopen = require('urlopen');
var ctx = session.name("Crew_Avail") || session.createContext("Crew_Avail");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var crewStatus = ctx.getVariable("crewStatus");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var Inp_crewId = ctx.getVariable("crewId");
var identifier = ctx.getVariable("identifier");
var msgId = ctx.getVariable("msgId");
var checkboth = ctx.getVariable("Both");
var logger = console.options({
	'category': 'all'
});
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;

} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;

} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;

} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;

}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}
if (checkboth == 'yes') { }
else {
	if (crewStatus == '' || crewStatus == null || crewStatus == undefined) { }
	else {
		session.input.readAsJSON(function(readAsJSONError, incomingdata) {
			if (readAsJSONError) {
				// an error occurred when parsing the content, e.g. invalid JSON object
				// uncatched error will stop the processing and the error will be logged
				var errorinfo = "Error in reading incoming data" + msgId + "; error info :" + readAsJSONError;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("Error in reading incoming data" + msgId + JSON.stringify(readAsJSONError));
				session.reject("Error in reading incoming data" + msgId + JSON.stringify(readAsJSONError))
			}


			else {
				var crewStatusURL = omsExternalURL + '/api/ServiceType/Electric/Crew/' + Inp_crewId;
				var crewStatusPayload = {
					"customFieldValues": {
						"crewStatusCustom": identifier
					}
				};
				var crewStatusPayloadPatch = {
					target: crewStatusURL,
					sslClientProfile: 'omsapi_client_profile',
					method: 'PATCH',
					contentType: 'application/json',
					data: crewStatusPayload,
					headers: {
						'osiApiToken': apiToken
					}
				};
				session.output.write(crewStatusPayload)
				var info = " TargetURL :" + crewStatusPayloadPatch.target + "; Method :" + crewStatusPayloadPatch.method + ". ";
				try {
					urlopen.open(crewStatusPayloadPatch, function(error, response) {
						if (error) {
							var errorinfo = "omsapiv2_138 url open cannot connect while sending crewstatus" + msgId + " , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatusCode", "500");
							logger.error("omsapiv2_138 url open cannot connect while sending crewstatus" + msgId + JSON.stringify(error));
							session.reject("omsapiv2_138 url open cannot connect while sending crewstatus" + msgId + JSON.stringify(error));
						}
						else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										//var errorinfo = "Unable to get response from crewStatusPayloadPatch" + msgId + " , details are : " + info + "; error info :" + error;
										//ilsctx.setVariable("errorDescription", errorinfo);
										logger.error("Unable to get response from crewStatusPayloadPatch" + msgId + JSON.stringify(error));
										//session.reject(errorinfo);
									}
									else {
										hm.response.statusCode = '200 OK';
										logger.debug("Message received from crewStatusPayloadPatch is " + msgId + JSON.stringify(responseData));
										if (crewStatus === 'AVAILABLE') {
											var postUrl = omsExternalURL + '/api/ServiceType/Electric/Crew/' + Inp_crewId + '/OnShift';
											var postPayload = {
												"shiftOnTime": new Date().toISOString()
											};
											var postCallPayload = {
												target: postUrl,
												sslClientProfile: 'omsapi_client_profile',
												method: 'POST',
												contentType: 'application/json',
												data: postPayload,
												headers: {
													'osiApiToken': apiToken
												}
											};
											var info = " TargetURL :" + postCallPayload.target + "; Method :" + postCallPayload.method + "; Data :" + JSON.stringify(postCallPayload.data) + ". ";
											urlopen.open(postCallPayload, function(error, response) {
												if (error) {
													var errorinfo = "url open cannot connect" + msgId + " , details are : " + info + "; error info :" + error;
													ilsctx.setVariable("errorDescription", errorinfo);
													ilsctx.setVariable("errorStatusCode", "500");
													logger.error("url open cannot connect" + msgId + JSON.stringify(error));
													session.reject("url open cannot connect while sending crewstatus" + msgId + JSON.stringify(error));
												}
												else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "Unable to get response from postCall" + msgId + " , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatusCode", "500");
																logger.error("Unable to get response from postCall" + msgId + JSON.stringify(error));
																session.reject(errorinfo);
															}
															else {
																hm.response.statusCode = '200 OK';
																logger.debug("Message received from postCall is " + msgId + JSON.stringify(responseData));
															}
														});
													}
													else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading response from postCall " + msgId + ", details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatusCode", "500");
																logger.error("failure in reading response from postCall " + msgId + JSON.stringify(error));
																session.reject(errorinfo);
															}
															else {
																hm.current.statusCode = responseStatusCode;
																var errorinfo = "Error returned from postCall " + msgId + ": with statusCode " + responseStatusCode +  ", details are : " + info + "; errorresponseinfo :" + responseData;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatusCode", responseStatusCode);
																logger.error("Error returned from postCall " + msgId + ": with statusCode " + responseStatusCode + " " + responseData);
																session.reject("Error returned from postCall " + msgId + ": with statusCode " + responseStatusCode + " " + responseData);
															}
														});
													}
												}
											});
										}
										else if (crewStatus === 'UN-AVAILABLE') {
											var patchUrl = omsExternalURL + '/api/ServiceType/Electric/Crew/' + Inp_crewId + '/OffShift';
											var patchPayload = {
												"shiftOffTime": new Date().toISOString()
											};
											var patchCallPayload = {
												target: patchUrl,
												sslClientProfile: 'omsapi_client_profile',
												method: 'PATCH',
												contentType: 'application/json',
												data: patchPayload,
												headers: {
													'osiApiToken': apiToken
												}
											};
											var info = " TargetURL :" + patchCallPayload.target + "; Method :" + patchCallPayload.method + "; Data :" + JSON.stringify(patchCallPayload.data) + ". ";
											urlopen.open(patchCallPayload, function(error, response) {
												if (error) {
													var errorinfo = "url open cannot connect" + msgId + " , details are : " + info + "; error info :" + error;
													ilsctx.setVariable("errorDescription", errorinfo);
													ilsctx.setVariable("errorStatusCode", "500");
													logger.error("url open cannot connect" + msgId + JSON.stringify(error));
													session.reject("url open cannot connect" + msgId + JSON.stringify(error));
												}
												else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "Unable to get response from patchCall" + msgId + " , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatusCode", "500");
																logger.error("Unable to get response from patchCall" + msgId + JSON.stringify(error));
																session.reject(errorinfo);
															}
															else {
																hm.response.statusCode = '200 OK';
																logger.debug("Message received from patchCall is " + msgId + JSON.stringify(responseData));
															}
														});
													}
													else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading response from patchCall " + msgId + ", details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatusCode", "500");
																logger.error("failure in reading response from patchCall " + msgId + JSON.stringify(error));
																session.reject(errorinfo);
															}
															else {
																hm.current.statusCode = responseStatusCode;
																var errorinfo = "failure in reading response from patchCall " + msgId + ": with statusCode " + responseStatusCode + ", details are : " + info + "; errorresponseinfo :" + responseData;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatusCode", responseStatusCode);
																logger.error("Error returned from patchCall " + msgId + ": with statusCode " + responseStatusCode + " " + responseData);
																session.reject("Error returned from patchCall " + msgId + ": with statusCode " + responseStatusCode + " " + responseData);
															}
														});
													}
												}
											});
										}
									}
								});
							}
							else if (responseStatusCode == 400) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "Failure in reading the response data , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", "500");
										logger.error("Failure in reading the response data" + JSON.stringify(error));
										session.reject(errorinfo);
									}
									else {
										var crewNotFoundObject = {
											"msgId": msgId,
											"errorCode": "400",
											"errorDescription": JSON.stringify(error)
										};
										hm.current.statusCode = responseStatusCode;
										var errorinfo = "Failure in reading the response data from crewstatuslookupResponse , details are : " + info + "; error info :" + JSON.stringify(crewNotFoundObject);
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", responseStatusCode);
										logger.error(JSON.stringify(crewNotFoundObject));
										session.reject(JSON.stringify(crewNotFoundObject));
									}
								});
							}
							else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure in reading response from crewStatusPayloadPatch " + msgId + ", details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", "500");
										logger.error("failure in reading response from crewStatusPayloadPatch " + msgId + JSON.stringify(error));
										session.reject(errorinfo);
									}
									else {
										hm.current.statusCode = responseStatusCode;
										logger.error("Error returned from crewStatusPayloadPatch " + msgId + ": with statusCode " + responseStatusCode + " " + responseData);
									}
								});
							}
						}
					});
				}
				catch (error) {
					var errorinfo = "omsapiv2_138 url open cannot connect while sending crewstatus" + msgId + " , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatusCode", "500");
					logger.error("omsapiv2_138 url open cannot connect while sending crewstatus" + msgId + JSON.stringify(error));
					session.reject(errorinfo);
				}
			}
		});
	}
}
