var ctx = session.name("Crew_Avail") || session.createContext("Crew_Avail");
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookUpURL;
var apiToken_chatbot = session.parameters.apiToken_chatbot;
var apiToken_maximo = session.parameters.apiToken_maximo;
var apiToken_reporting = session.parameters.apiToken_reporting;
var nullcheck = session.parameters.nullcheck;
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	ctx.setVariable("omsExternalURL", omsExternalURL);
	ctx.setVariable("apiToken", apiToken);
	ctx.setVariable("lookupURL", lookupURL);
	ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
	ctx.setVariable("apiToken_maximo", apiToken_maximo);
	ctx.setVariable("apiToken_reporting", apiToken_reporting);
	if (nullcheck == 'yes') {
		var URL = sm.getVar('var://service/URI');
		//var crewId = URL.substring(URL.lastIndexOf("Crew/")+5,URL.lastIndexOf("/Status"));
		var URI = URL.toString().split("/");
		var crewId = URI[4];
		if (crewId == null || crewId == '' || crewId == undefined) {
			var errorinfo = "crewId is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error('crewId is not present in input payload');
			session.reject('crewId is not present in input payload');
		}
		else {
			ctx.setVariable("crewId", crewId);
		}

		var msgId = incomingdata.msgId;

		if (msgId == null || msgId == '' || msgId == undefined) {
			var errorinfo = "msgId is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error('msgId is not present in input payload');
			session.reject('msgId is not present in input payload');
		}
		else {
			ctx.setVariable("msgId", msgId);
		}
		var crewStatus = incomingdata.crewStatus;
		var longitude = incomingdata.longitude;
		var latitude = incomingdata.latitude;
		var InputMissingObject = {
			"errorCode": "500",
			"errorDescription": "Missing input property"
		};
		if (crewStatus == null || crewStatus == '' || crewStatus == undefined) {
			if (longitude == null || longitude == '' || longitude == undefined) {
				if (latitude == null || latitude == '' || latitude == undefined) {
					var errorinfo = InputMissingObject;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error(JSON.stringify(InputMissingObject));
					session.reject(JSON.stringify(InputMissingObject));

				}
				else {
					ctx.setVariable("latitude", latitude)
					var errorinfo = InputMissingObject;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error(JSON.stringify(InputMissingObject));
					session.reject(JSON.stringify(InputMissingObject));
				}
			}
			else {
				ctx.setVariable("longitude", longitude)
				if (latitude == null || latitude == '' || latitude == undefined) {
					var errorinfo = InputMissingObject;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error(JSON.stringify(InputMissingObject));
					session.reject(JSON.stringify(InputMissingObject));
				}
				else {
					ctx.setVariable("latitude", latitude)
				}
			}
		}
		else {
			ctx.setVariable("crewStatus", crewStatus);
			if (longitude == null || longitude == '' || longitude == undefined) {
				if (latitude == null || latitude == '' || latitude == undefined) {
				}
				else {
					ctx.setVariable("latitude", latitude)
				}
			}
			else {
				ctx.setVariable("longitude", longitude)
				if (latitude == null || latitude == '' || latitude == undefined) {
				}
				else {
					ctx.setVariable("latitude", latitude)
				}
			}
		}
	}

});
