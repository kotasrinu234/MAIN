var urlopen = require('urlopen');
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var crewId = ctx.getVariable("crewId");
var lookupURL = ctx.getVariable("lookupURL");
var leadAssignmentIDArray = ctx.getVariable("leadAssignmentIDArray");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var logger = console.options({
	'category': 'all'
});
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;
	logger.debug("inside OutageAPP----" + apiToken);
} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;
	logger.debug("inside chatbotAPP----" + apiToken);
} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;
	logger.debug("inside reportAPP----" + apiToken);
} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;
	logger.debug("inside maximoAPP----" + apiToken);
}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}
var crewAssignmentStatusMap = new Map([
	['Arrived', 'AR'],
	['En-Route', 'EN'],
	['Acknowleged', 'AK'],
	['Dispatched', 'DP'],
	['Canceled', 'CP'],
	['Completed', 'CP']
]);
var array_List = [];
var errorarray = [];
ctx.setVariable("errorarray", errorarray);
ctx.setVariable("array_List", array_List);
var URL = sm.getVar('var://service/URI');
var jobIds = URL.substring(URL.lastIndexOf("jobIds=") + 7);
var jobId_List = jobIds.split("%2C");
logger.debug("jobId:" + jobId_List);

var leadAssignmentIDArrayLength = leadAssignmentIDArray.length;
for (var i = 0; i < leadAssignmentIDArrayLength; i++) {
	var leadAssignmentID = leadAssignmentIDArray[i];
	var crewAssignmentUri = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + leadAssignmentID;
	var test = OMScrewassigmnet(crewAssignmentUri, leadAssignmentID);
}

function OMScrewassigmnet(crewAssignmentUri, leadAssignmentID) {
	var getcrewAssignmentApi = {
		target: crewAssignmentUri,
		sslClientProfile: 'omsapi_client_profile',
		method: 'GET',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
	};
	var info = " TargetURL :" + getcrewAssignmentApi.target + "; Method :" + getcrewAssignmentApi.method + ". ";
	try {
		urlopen.open(getcrewAssignmentApi, function(error, response) {
			if (error) {
				var errorinfo = "omsapiv2_123:urlopen connect error with Get getcrewAssignmentApi , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapiv2_123:urlopen connect error with Get getcrewAssignmentApi " + JSON.stringify(error));
				session.reject("urlopen connect error with Get getcrewAssignmentApi " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "omsapiv2_124:failure in reading message from getcrewAssignmentApi , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_124:failure in reading message from getcrewAssignmentApi" + JSON.stringify(error));
							session.reject(" failure in reading message from getcrewAssignmentApi" + JSON.stringify(error));
						} else {
							var getJobApiResponse = JSON.parse(responseData);
							logger.debug("responsepayload+++++++++++" + JSON.stringify(getJobApiResponse));
							if (getJobApiResponse.crew === undefined) {
								var jobid = ctx.getVariable("jobID_" + leadAssignmentID);
								var payload = {
									"jobId": jobid,
									"crewAssignments": {
										"errorCode": '404',
										"errorDescription": 'crew Not found'
									}
								}
								errorarray.push(payload);
								ctx.setVariable("errorarray", errorarray);
							} else {
								var name = getJobApiResponse.crew.name;
								logger.debug("name is++++++++" + name);
								var eta = JSON.parse(responseData).eta;
								var status = JSON.parse(responseData).status;
								var test = OMSpremiseresponse(responseData, leadAssignmentID, array_List, name, eta, status);
							}
						}
					});
				} else if (responseStatusCode == 404) {
					var jobid = ctx.getVariable("jobID_" + leadAssignmentID);
					var payload = {
						"jobId": jobid,
						"crewAssignments": {
							"errorCode": '404',
							"errorDescription": 'crew Not found'
						}
					}
					logger.debug("reached inside 404 block of job" + payload);
					errorarray.push(payload);
					ctx.setVariable("errorarray", errorarray);
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from job api , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from job api " + JSON.stringify(error));
							session.reject("failure in reading message from job api ");
						} else {
							var errorinfo = "omsapiv2_125:Error code returned from job api  " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_125:Error code returned from job api  " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from job api " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "omsapiv2_123:urlopen connect error with Get getcrewAssignmentApi , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapiv2_123:urlopen connect error with Get getcrewAssignmentApi " + JSON.stringify(error));
		session.reject("urlopen connect error with Get getcrewAssignmentApi " + JSON.stringify(error));
	}
}


function OMSpremiseresponse(responseData, leadAssignmentID, array_List, name, eta, status) {
	var workTypeID = JSON.parse(responseData).workTypeID;
	var crewId;
	//logger.error("Control reached here");
	var reponsemessage = JSON.parse(responseData);
	if (reponsemessage.crew != undefined || reponsemessage.crew != '' || reponsemessage.crew != null) {
		if (reponsemessage.crew.customFieldValuesExt != undefined || reponsemessage.crew.customFieldValuesExt != '' || reponsemessage.crew.customFieldValuesExt != null) {
			crewId = JSON.parse(responseData).crew.customFieldValuesExt.CrewID;
			if (crewId == null) {
				crewId = '';
			}
		}

	} else {
		crewId = '';
	}
	logger.debug("omsapiv2_126:crewId+++++" + crewId);
	var lookupMessage = {
		"lookupReq": {
			"type": [{
				"name": "workType.workflows",
				"id": workTypeID,
				"status": status
			}]
		}
	}
	var LookupServiceResponse = {
		target: lookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: lookupMessage
	};
	var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
	try {
		urlopen.open(LookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "omsapiv2_127:urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapiv2_127:urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
				session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				logger.debug("response:" + response);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, LookupresponseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "omsapiv2_128:failure in reading message from LookupServiceResponse , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_128:failure in reading message from LookupServiceResponse" + JSON.stringify(error));
							session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));

						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
							if (LookupresponseData.lookupRep.type[0].result == 0) {
								var label = LookupresponseData.lookupRep.type[0].label;
								var crewAssignmentStatus = crewAssignmentStatusMap.get(label);
								console.log("jobId_List[i]" + jobId_List[i]);
								var jobid = ctx.getVariable("jobID_" + leadAssignmentID);
								var jobDisplayId = ctx.getVariable("displayID_" + leadAssignmentID);
								logger.debug("jobid++++++" + jobid + "leadassignmentid " + leadAssignmentID);
								if (crewAssignmentStatus == null) {
									crewAssignmentStatus = '';
								}
								if (name == null) {
									name = '';
								}
								if (eta == null) {
									eta = '';
								}
								var obj = {
									"jobId": jobid,
									"jobDisplayId": jobDisplayId,
									"crewAssignments": {
										"crewId": crewId,
										"name": name,
										"crewAssignmentStatus": label,
										"eta": eta
									}

								}
								array_List.push(obj);
								ctx.setVariable("array_List", array_List);
								logger.debug("omsapiv2_129:arrayList" + JSON.stringify(array_List));
							}
						}
					});
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from worktypelookup api , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from worktypelookup api " + JSON.stringify(error));
							session.reject("failure in reading message from worktypelookup api ");
						} else {
							var errorinfo = "omsapiv2_130:Error code returned from worktypelookup api  " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_130:Error code returned from worktypelookup api  " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from worktypelookup api " + responseStatusCode + " " + responseData);
						}
					});
				}

			}
		});
	}
	catch (error) {
		var errorinfo = "omsapiv2_127:urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapiv2_127:urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
		session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
	}
}
