var urlopen = require('urlopen');
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var hm = require('header-metadata');
var sm = require('service-metadata');
var apiToken = ctx.getVariable("apiToken");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var crewId = ctx.getVariable("crewId");
var lookupURL = ctx.getVariable("lookupURL");
var logger = console.options({
    'category': 'all'
});
var array_List = ctx.getVariable("array_List");
var errorJob404 = ctx.getVariable("errorJob404");
var errorarray = ctx.getVariable("errorarray");
var final_array = [];
var job = {};
var jobList = {};
var array_ListLength = array_List.length;
for (var i = 0; i < array_ListLength; i++) {
    final_array.push(array_List[i]);
}

var errorjob404length = errorJob404.length;

for (var i = 0; i < errorjob404length; i++) {
    final_array.push(errorJob404[i]);
}

var errorarrayLength = errorarray.length;
for (var i = 0; i < errorarrayLength; i++) {
    final_array.push(errorarray[i]);
}

jobList["jobList"] = final_array;
job["job"] = jobList;

session.output.write(job);