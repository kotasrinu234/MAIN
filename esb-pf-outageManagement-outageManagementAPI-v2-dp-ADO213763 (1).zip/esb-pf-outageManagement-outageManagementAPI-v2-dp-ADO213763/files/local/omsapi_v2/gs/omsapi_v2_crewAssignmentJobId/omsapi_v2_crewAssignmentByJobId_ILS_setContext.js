var ctx = session.name('ILS') || session.createContext('ILS');
var sm = require('service-metadata');
var apiName = session.parameters.getCrewAssignmentByJobListApiName;
var entryDescription = session.parameters.getCrewAssignmentByJobListEntryDescription;
var exitDescription = session.parameters.getCrewAssignmentByJobListExitDescription;
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var messageType = session.parameters.messageType;
if (apiName !== undefined || apiName !== null || apiName !== '') {
	ctx.setVariable("apiName", apiName);
}
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var URL = sm.getVar('var://service/URI');
if (URL.includes("jobIds=")) {
	var jobIds = URL.substring(URL.lastIndexOf("jobIds=") + 7);
	var jobId_List = jobIds.split("%2C");
}
ctx.setVariable("correlationID", uuidv4());
if (jobId_List) {
	if (jobId_List !== undefined || jobId_List !== null || jobId_List !== '') {
		ctx.setVariable("jobIDList", jobId_List);
	}
}
ctx.setVariable("sourceEventTimestamp", new Date().toISOString());
