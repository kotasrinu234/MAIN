var urlopen = require('urlopen');
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var crewId = ctx.getVariable("crewId");
var lookupURL = ctx.getVariable("lookupURL");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var logger = console.options({
	'category': 'all'
});
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;
	logger.debug("inside OutageAPP----" + apiToken);
} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;
	logger.debug("inside chatbotAPP----" + apiToken);
} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;
	logger.debug("inside reportAPP----" + apiToken);
} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;
	logger.debug("inside maximoAPP----" + apiToken);
}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}

var crewAssignmentStatusMap = new Map([
	['Arrived', 'AR'],
	['En-Route', 'EN'],
	['Acknowleged', 'AK'],
	['Dispatched', 'DP'],
	['Canceled', 'CP'],
	['Completed', 'CP']
]);
var URL = sm.getVar('var://service/URI');


if (URL.includes("jobIds=")) {
	var jobIds = URL.substring(URL.lastIndexOf("jobIds=") + 7);
	var jobId_List = jobIds.split("%2C");
	logger.debug("jobIdList:" + jobId_List);
	var jobLength = jobId_List.length;
	logger.debug("jobLength:" + jobLength);

	var errorJob404 = [];
	var leadAssignmentIdarray = [];
	ctx.setVariable("errorJob404", errorJob404);
	ctx.setVariable("leadAssignmentIDArray", leadAssignmentIdarray);
	var jobid_current;


	for (var i = 0; i < jobLength; i++) {
		var JobUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobId_List[i];
		jobid_current = jobId_List[i];
		var test = OMSpremiseresponse(JobUri, jobid_current);

	}
} else {
	ctx.setVariable("responseStatusCode", 400);
	var errorinfo = "jobIds not found in the input request";
	ilsctx.setVariable("errorDescription", errorinfo);
	logger.error("jobIds not found in the input request");
	session.reject("jobId's not found");

}

function OMSpremiseresponse(JobUri, jobid_current) {
	var getJobApi = {
		target: JobUri,
		sslClientProfile: 'omsapi_client_profile',
		method: 'GET',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
	};
	var info = " TargetURL :" + getJobApi.target + "; Method :" + getJobApi.method + ". ";
	try {
		urlopen.open(getJobApi, function(error, response) {
			if (error) {
				var errorinfo = "omsapiv2_120:urlopen connect error with Get CrewGetApi for crewId " + crewId + " , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapiv2_120:urlopen connect error with Get CrewGetApi for crewId " + crewId + " with error as " + JSON.stringify(error));
				session.reject("urlopen connect error with Get jobApi with error as " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "omsapiv2_121:failure in reading message from CrewGetApi , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_121:failure in reading message from CrewGetApi" + JSON.stringify(error));
							session.reject(" failure in reading message from CrewGetApi" + JSON.stringify(error));
						} else {
							var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
							ctx.setVariable("responseData", JSON.stringify(responseData));
							var leadAssignmentID = JSON.parse(responseData).leadAssignmentID;
							if (leadAssignmentID == null || leadAssignmentID == '' || leadAssignmentID == undefined) {
								//  logger.error('leadAssignmentID is not present Jobresponse payload');
								//session.reject('leadAssignmentID is not present Jobresponse payload');
								var payload = {
									"jobId": jobid_current,
									"crewAssignments": {
										"errorCode": '404',
										"errorDescription": 'LeadAssignmentID is not present in job'
									}
								}
								logger.debug("reached inside 404 block of job" + payload);
								errorJob404.push(payload);
								ctx.setVariable("errorJob404", errorJob404);
							} else {
								leadAssignmentIdarray.push(leadAssignmentID);
								var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
								ctx.setVariable("leadAssignmentIDArray", leadAssignmentIdarray);
								ctx.setVariable("jobID_" + leadAssignmentID, jobid_current);
								if (JSON.parse(responseData).displayID != undefined || JSON.parse(responseData).displayID != null || JSON.parse(responseData).displayID != '') {
									var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
									ctx.setVariable("displayID_" + leadAssignmentID, JSON.parse(responseData).displayID);
								}
							}
						}
					});
				} else if (responseStatusCode == 404) {
					var payload = {
						"jobId": jobid_current,
						"crewAssignments": {
							"errorCode": '404',
							"errorDescription": 'Job not found.'
						}

					}
					logger.debug("reached inside 404 block of job" + payload);
					errorJob404.push(payload);
					ctx.setVariable("errorJob404", errorJob404);
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from job api , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from job api " + JSON.stringify(error));
							session.reject("failure in reading message from job api ");
						} else {
							var errorinfo = "omsapiv2_122:Error code returned from job api  " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_122:Error code returned from job api  " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from job api " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "omsapiv2_120:urlopen connect error with Get CrewGetApi for crewId " + crewId + " , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapiv2_120:urlopen connect error with Get CrewGetApi for crewId " + crewId + " with error as " + JSON.stringify(error));
		session.reject("urlopen connect error with Get jobApi with error as " + JSON.stringify(error));
	}
}
