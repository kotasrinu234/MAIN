var ctx = session.name("Crew_Job")|| session.createContext("Crew_Job");
//set stylesheet parameters to variable

var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookUpURL;
var nullCheck = session.parameters.nullCheck;
var apiToken_chatbot=session.parameters.apiToken_chatbot;
var apiToken_maximo=session.parameters.apiToken_maximo;
var apiToken_reporting=session.parameters.apiToken_reporting;

//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
ctx.setVariable("apiToken_maximo", apiToken_maximo);
ctx.setVariable("apiToken_reporting", apiToken_reporting);


