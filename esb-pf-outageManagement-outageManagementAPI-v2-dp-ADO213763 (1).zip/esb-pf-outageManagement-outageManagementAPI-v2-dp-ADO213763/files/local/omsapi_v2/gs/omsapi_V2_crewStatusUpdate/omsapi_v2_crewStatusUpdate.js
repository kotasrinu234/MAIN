var urlopen = require('urlopen');
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var Inp_crewId = ctx.getVariable("crewId");
var lookupURL = ctx.getVariable("lookupURL");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var disposition_check = ctx.getVar("disposition_check");
var Disposition = ctx.getVar("Disposition");
var Disposition_new = ctx.getVar("Disposition_new");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var logger = console.options({
	'category': 'all'
});
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;

} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;

} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;

} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;

}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}

session.input.readAsJSON(function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		// uncatched error will stop the processing and the error will be logged
		var errorinfo = "Error in reading incoming data, details are : error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data")
	} else {
		var jobId = json.jobId;
		var msgId = json.msgId;
		ctx.setVariable("msgId", msgId);
		var action = json.action;
		var latitude = json.latitude;
		var longitude = json.longitude;
		var comments = json.comments;
		var Disposition = json.disposition;
		var workType = json.workType;
		var check_longitude;
		var check_latitude;
		var crew_check;
		var check;
		var comment_check;
		if (workType == null || workType == undefined || workType == '') {
			session.reject('workType is not present');
		} else {
			ctx.setVariable("workType", workType);
		}
		if (longitude == null || longitude == undefined || longitude == '') {
			check_longitude = 'True';
		} else {
			check_longitude = 'False';
		}
		if (latitude == null || latitude == undefined || latitude == '') {
			check_latitude = 'True';
		} else {
			check_latitude = 'False';
		}
		if (comments == null || comments == undefined || comments == '') {
			comment_check = 'True';
		} else {
			comment_check = 'False'
		}
		if (check_longitude == 'True' || check_latitude == 'True') {
			check = 'True';
		} else {
			check = 'False';
		}
		ctx.setVariable("check", check);
		ctx.setVariable("comment_check", comment_check);
		var CrewUri = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + Inp_crewId;
		ctx.setVariable("msgId", msgId);
		var CrewGetApi = {
			target: CrewUri,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
		};
		var info = " TargetURL :" + CrewGetApi.target + "; Method :" + CrewGetApi.method + ". ";
		try {
			urlopen.open(CrewGetApi, function(error, response) {
				if (error) {
					var errorinfo = "omsapi_v2_014 urlopen connect error with Get CrewGetApi for Inp_crewId , details are : " + info + "; error info :" + error
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error("omsapi_v2_014 urlopen connect error with Get CrewGetApi for Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
					session.reject("urlopen connect error with Get CrewGetApi for Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));

				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message from CrewGetApi , details are : " + info + "; error info :" + error
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from CrewGetApi" + JSON.stringify(error));
								session.reject(" failure in reading message from CrewGetApi" + JSON.stringify(error));
							} else {
								var jobIdUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobId;
								var crewID = JSON.parse(responseData).id;
								var crewInternalID = JSON.parse(responseData).id;
								ctx.setVariable("crewInternalID", crewInternalID);
								var requestedCrewType = JSON.parse(responseData).type;
								ctx.setVariable("requestedCrewType", requestedCrewType);
								var GetJobApi = {
									target: jobIdUri,
									sslClientProfile: 'omsapi_client_profile',
									method: 'GET',
									contentType: 'application/json',
									headers: {
										'osiApiToken': apiToken
									},
								}
								var info = " TargetURL :" + GetJobApi.target + "; Method :" + GetJobApi.method + ". ";
								try {
									urlopen.open(GetJobApi, function(error, response) {
										if (error) {
											var errorinfo = "omsapi_v2_015 urlopen connect error with Get GetJobApi for jobId , details are : " + info + "; error info :" + error
											ilsctx.setVariable("errorDescription", errorinfo);
											logger.error("omsapi_v2_015 urlopen connect error with Get GetJobApi for jobId " + jobId + " with error as " + JSON.stringify(error));
											session.reject("urlopen connect error with Get GetJobApi for jobId " + jobId + " with error as " + JSON.stringify(error));
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "failure in reading message from GetJobApi , details are : " + info + "; error info :" + error
														ilsctx.setVariable("errorDescription", errorinfo);
														logger.error("failure in reading message from GetJobApi" + JSON.stringify(error));
														session.reject(" failure in reading message from GetJobApi" + JSON.stringify(error));
													} else {
														ctx.setVariable("job_responseData", JSON.parse(responseData));
														var leadAssignmentID = JSON.parse(responseData).leadAssignmentID;
														var leadAssignmentWorkTypeID = JSON.parse(responseData).leadAssignmentWorkTypeID;
														var id = JSON.parse(responseData).id;
														ctx.setVariable("id", id);
														if (JSON.parse(responseData).workTypeID != undefined) {
															var JOB_workTypeID = JSON.parse(responseData).workTypeID;
															ctx.setVariable("JOB_workTypeID", JOB_workTypeID);
														} else {
															var JOB_workTypeID = '';
															ctx.setVariable("JOB_workTypeID", JOB_workTypeID);
														}

														var JOB_jobTypeID = JSON.parse(responseData).jobTypeID;
														ctx.setVariable("JOB_jobTypeID", JOB_jobTypeID);
														var CrewAssignmentUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/CrewAssignment' + '?excludeResolved=true';
														var CrewAssignmentapi = {
															target: CrewAssignmentUri,
															sslClientProfile: 'omsapi_client_profile',
															method: 'GET',
															contentType: 'application/json',
															headers: {
																'osiApiToken': apiToken
															},
														};
														var info = " TargetURL :" + CrewAssignmentapi.target + "; Method :" + CrewAssignmentapi.method + ". ";
														try {
															urlopen.open(CrewAssignmentapi, function(error, response) {
																if (error) {
																	var errorinfo = "omsapi_v2_016 urlopen connect error with Get CrewAssignmentapi for jobId , details are : " + info + "; error info :" + error
																	ilsctx.setVariable("errorDescription", errorinfo);
																	logger.error("omsapi_v2_016 urlopen connect error with Get CrewAssignmentapi for jobId " + id + " with error as " + JSON.stringify(error));
																	session.reject("urlopen connect error with Get CrewAssignmentapi for jobId " + id + " with error as " + JSON.stringify(error));
																} else {
																	var responseStatusCode = response.statusCode;
																	logger.debug("responseStatusCode" + responseStatusCode);
																	if (responseStatusCode == 200) {
																		response.readAsJSON(function(error, responseData) {
																			if (error) {
																				var errorinfo = "failure in reading message from CrewAssignmentapi , details are : " + info + "; error info :" + error
																				ilsctx.setVariable("errorDescription", errorinfo);
																				logger.error("failure in reading message from CrewAssignmentapi" + JSON.stringify(error));
																				session.reject(" failure in reading message from CrewAssignmentapi" + JSON.stringify(error));
																			} else {
																				ctx.setVariable("crewresponseData", responseData);
																				var crewAssignmentLenght = responseData.data.length;
																				if (crewAssignmentLenght == 0 && action == 'Assign') {
																					ctx.setVariable("action_value", action);
																				} else if (crewAssignmentLenght == 0 && action != 'Assign') {
																					ctx.setVariable("responseStatusCode", '400');
																					ctx.setVariable("notFound", 'True');
																					ctx.setVariable("Id_Req", 'True');
																					ctx.setVariable("error", 'F');
																					var jobmessage = session.parameters.crewStatusUpdateJobMessage;
																					var errorinfo = jobmessage + ", details are : " + info + "; error info :" + error
																					ilsctx.setVariable("errorDescription", errorinfo);
																					session.reject(jobmessage);
																				}
																				var ActionFlag = 'False';
																				for (var i = 0; i < crewAssignmentLenght; i++) {
																					var Flag;
																					var data = responseData.data[i];
																					//var workTypeID = responseData.data[i].workTypeID;
																					var CrewAssign_ID = responseData.data[i].id;
																					var crew = data.crew;
																					if (crew == '' || crew == undefined || crew == null) {
																						logger.debug("crewAssignment is not found");
																						Flag = 'False';
																					} else {
																						var crewAssignment = crew.externalID;
																					}
																					if (Inp_crewId == crewAssignment) {
																						Flag = 'True';
																						ActionFlag = 'True';
																					} else {
																						Flag = 'False';
																					}
																					logger.debug("ActionFlag" + ActionFlag);
																					logger.debug("action" + action);
																					if ((action != 'Assign' && Flag == 'True') || (action == 'Assign' && ActionFlag == 'False' && i == (crewAssignmentLenght - 1))) {
																						crew_check = 'True';
																						logger.debug('crew_check' + crew_check);
																						if (action != 'Assign') {
																							if (disposition_check == 'False') {
																								CustomFieldValues(CrewAssign_ID)
																							} else { }
																							LookupStatusresponse(action, workType, CrewAssign_ID, Inp_crewId, id, longitude, latitude, comments, check, comment_check)
																						} else {
																							ctx.setVariable("action_value", action);
																						}
																					} else if (action != 'Assign' && Flag == 'False') {
																						ctx.setVariable("responseStatusCode", '400');
																						ctx.setVariable("notFound", 'True');
																						ctx.setVariable("Id_Req", 'True');
																						ctx.setVariable("error", 'F');
																						var jobmessage = session.parameters.crewStatusUpdateJobMessage;
																						if (crew_check != 'True' && i == (crewAssignmentLenght - 1)) {
																							var errorinfo = jobmessage + ", details are : " + info + "; error info :" + error
																							ilsctx.setVariable("errorDescription", errorinfo);
																							session.reject(jobmessage);
																						} else { }
																					} else if (action == 'Assign' && ActionFlag == 'True') {
																						logger.debug('inside if');
																						ctx.setVariable("responseStatusCode", '400');
																						ctx.setVariable("notFound", 'True');
																						ctx.setVariable("Id_Req", 'True');
																						ctx.setVariable("error", 'F');
																						var crewmessage = session.parameters.crewStatusUpdateJobCrewErrorMessage;
																						if (crew_check != 'True') {
																							var errorinfo = crewmessage + " details are : " + info + "; error info :" + error
																							ilsctx.setVariable("errorDescription", errorinfo);
																							session.reject(crewmessage);
																						}
																					}
																				}
																			}
																		});
																	} else {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				//dp:reject stop the transaction and go error rule with error code and description
																				var errorinfo = "failure in reading message from CrewAssignmentapi api  for  jobId , details are : " + info + "; error info :" + error
																				ilsctx.setVariable("errorDescription", errorinfo);
																				logger.error("failure in reading message from CrewAssignmentapi api  for  jobId " + JSON.stringify(error));
																				session.reject("failure in reading message from CrewAssignmentapi api  for  jobId ");
																			} else {
																				var errorinfo = "Error code returned from CrewAssignmentapi api  for  jobId: " + id + " statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
																				ilsctx.setVariable("errorDescription", errorinfo);
																				logger.error("Error code returned from CrewAssignmentapi api  for  jobId: " + id + " statusCode " + responseStatusCode + " " + responseData);
																				session.reject("Error code returned from CrewAssignmentapi api  for  jobId: " + id + " statusCode " + responseStatusCode + " " + responseData);
																			}
																		});
																	}
																}
															});
														}
														catch (error) {
															var errorinfo = "omsapi_v2_016 urlopen connect error with Get CrewAssignmentapi for jobId , details are : " + info + "; error info :" + error
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error("omsapi_v2_016 urlopen connect error with Get CrewAssignmentapi for jobId " + id + " with error as " + JSON.stringify(error));
															session.reject("urlopen connect error with Get CrewAssignmentapi for jobId " + id + " with error as " + JSON.stringify(error));
														}
													}
												})
											} else if (responseStatusCode == 404) {
												var errorinfo = "404 Not Found , details are : " + info + "; error info :" + error
												ilsctx.setVariable("errorDescription", errorinfo);
												ctx.setVariable("notFound", 'True');
												session.reject("Job Not found.");
												ctx.setVariable("error", '404');
												ctx.setVariable("responseStatusCode", responseStatusCode);
											} else {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														//dp:reject stop the transaction and go error rule with error code and description
														var errorinfo = "failure in reading message from GetJobApi api  for  jobId  , details are : " + info + "; error info :" + error;
														ilsctx.setVariable("errorDescription", errorinfo);
														logger.error("failure in reading message from GetJobApi api  for  jobId " + JSON.stringify(error));
														session.reject("failure in reading message from GetJobApi api  for  jobId ");
													} else {

														var errorinfo = "Error code returned from GetJobApi api  for  jobId: " + jobId + " statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
														ilsctx.setVariable("errorDescription", errorinfo);
														logger.error("Error code returned from GetJobApi api  for  jobId: " + jobId + " statusCode " + responseStatusCode + " " + responseData);
														session.reject("Error code returned from GetJobApi api  for  jobId: " + jobId + " statusCode " + responseStatusCode + " " + responseData);
													}
												});
											}
										}
									});
								}
								catch (error) {
									var errorinfo = "omsapi_v2_015 urlopen connect error with Get GetJobApi for jobId , details are : " + info + "; error info :" + error
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("omsapi_v2_015 urlopen connect error with Get GetJobApi for jobId " + jobId + " with error as " + JSON.stringify(error));
									session.reject("urlopen connect error with Get GetJobApi for jobId " + jobId + " with error as " + JSON.stringify(error));
								}
							}
						});
					} else if (responseStatusCode == 404) {
						var errorinfo = "404 Not Found , details are : " + info + "; error info :" + error
						ilsctx.setVariable("errorDescription", errorinfo);
						ctx.setVariable("notFound", 'True');
						ctx.setVariable("error", '404');
						session.reject("Crew Not found.");
						ctx.setVariable("responseStatusCode", responseStatusCode);
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from CrewGetApi api  for  crewId , details are : " + info + "; error info :" + error
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from CrewGetApi api  for  crewId " + JSON.stringify(error));
								session.reject("failure in reading message from CrewGetApi api  for  crewId ");
							} else {
								var errorinfo = "Error code returned from CrewGetApi api  for  crewId: " + Inp_crewId + " statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("Error code returned from CrewGetApi api  for  crewId: " + Inp_crewId + " statusCode " + responseStatusCode + " " + responseData);
								session.reject("Error code returned from CrewGetApi api  for  crewId: " + Inp_crewId + " statusCode " + responseStatusCode + " " + responseData);
							}
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "omsapi_v2_014 urlopen connect error with Get CrewGetApi for Inp_crewId , details are : " + info + "; error info :" + error
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("omsapi_v2_014 urlopen connect error with Get CrewGetApi for Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
			session.reject("urlopen connect error with Get CrewGetApi for Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
		}
	}
});

function LookupStatusresponse(action, workType, CrewAssign_ID, Inp_crewId, id, longitude, latitude, comments, check, comment_check) {
	var WorktypeIDlookupMessage = {
		"lookupReq": {
			"type": [{
				"name": "workTypes",
				"label": workType
			}]
		}
	}
	var WorktypeIDlookupResponse = {
		target: lookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: WorktypeIDlookupMessage
	};
	var info = " TargetURL :" + WorktypeIDlookupResponse.target + "; Method :" + WorktypeIDlookupResponse.method + "; Data :" + JSON.stringify(WorktypeIDlookupResponse.data) + ". ";
	try {
		urlopen.open(WorktypeIDlookupResponse, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with WorktypeIDlookupResponse , details are : " + info + "; error info :" + error
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error(" urlopen connect error with WorktypeIDlookupResponse" + JSON.stringify(error));
				session.reject("urlopen connect error with WorktypeIDlookupResponse" + JSON.stringify(error));
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				logger.debug("response:" + response);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "failure in reading message from WorktypeIDlookupResponse , details are : " + info + "; error info :" + error
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from WorktypeIDlookupResponse" + JSON.stringify(error));
							session.reject("failure in reading message from WorktypeIDlookupResponse" + JSON.stringify(error));

						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from WorktypeIDlookupResponse " + JSON.stringify(responseData));
							if (responseData.lookupRep.type[0].result == 0) {
								var WorkTypeID = responseData.lookupRep.type[0].id;
								ctx.setVariable("WorkTypeID", WorkTypeID);
								var lookupMessage = {
									"lookupReq": {
										"type": [{
											"name": "workType.workflows",
											"id": WorkTypeID,
											"label": action
										}]
									}
								}
								var LookupServiceResponse = {
									target: lookupURL,
									method: 'POST',
									contentType: 'application/json',
									data: lookupMessage
								};
								var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
								try {
									urlopen.open(LookupServiceResponse, function(error, response) {
										if (error) {
											var errorinfo = "omsapi_v2_017 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error
											ilsctx.setVariable("errorDescription", errorinfo);
											logger.error("omsapi_v2_017 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
											session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
										} else {
											// read response data
											// get the response status code
											var responseStatusCode = response.statusCode;
											logger.debug("response:" + response);
											if (responseStatusCode == 200) {
												response.readAsJSON(function(error, responseData) {
													if (error) {
														// error while reading response or transferring data to Buffer
														var errorinfo = "failure in reading message from LookupServiceResponse , details are : " + info + "; error info :" + error
														ilsctx.setVariable("errorDescription", errorinfo);
														logger.error("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
														session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));

													} else {
														hm.response.statusCode = responseStatusCode;
														logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
														if (responseData.lookupRep.type[0].result == 0) {
															var status = responseData.lookupRep.type[0].status;
															var workFlowUri = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + CrewAssign_ID + '/WorkFlow';
															WorkflowAPI(workFlowUri, status, Inp_crewId, id, CrewAssign_ID, longitude, latitude, comments, check, comment_check);

														} else {
															var errorinfo = "omsapiv2_114:lookup result is not 0 , details are : " + info + "; error info :" + error
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error("omsapiv2_114:lookup result is not 0");
															session.reject("lookup result is not 0");
														}
													}
												});
											} else {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														//dp:reject stop the transaction and go error rule with error code and description
														var errorinfo = "failure in reading message from lookupresponse , details are : " + info + "; error info :" + error
														ilsctx.setVariable("errorDescription", errorinfo);
														logger.error("failure in reading message from lookupresponse" + JSON.stringify(error));
														session.reject("failure in reading message from lookupresponse");
													} else {
														var errorinfo = "omsapiv2_115:lookup response is " + " statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
														ilsctx.setVariable("errorDescription", errorinfo);
														logger.error("omsapiv2_115:lookup response is " + " statusCode " + responseStatusCode + " " + responseData);
														session.reject("lookup response is" + " statusCode " + responseStatusCode + " " + responseData);
													}
												});
											}
										}
									});
								} catch (error) {
									var errorinfo = "omsapi_v2_017 urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("omsapi_v2_017 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
									session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
								}
							} else {
								var errorinfo = "WorktypeIDlookupResponse result is not 0 , details are : " + info + "; error info :" + error
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error('WorktypeIDlookupResponse result is not 0');
								session.reject("WorktypeIDlookupResponse result is not 0");
							}
						}
					});
				} else {
					var errorinfo = "WorktypeIDlookupResponse is not 200 , details are : " + info + "; error info :" + error
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error('WorktypeIDlookupResponse is not 200');
					session.reject("WorktypeIDlookupResponse is not 200");

				}
			}
		});
	} catch (error) {
		var errorinfo = "urlopen connect error with WorktypeIDlookupResponse , details are : " + info + "; error info :" + error
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error(" urlopen connect error with WorktypeIDlookupResponse" + JSON.stringify(error));
		session.reject("urlopen connect error with WorktypeIDlookupResponse" + JSON.stringify(error));
	}
}

function WorkflowAPI(workFlowUri, status, Inp_crewId, id, CrewAssign_ID, longitude, latitude, comments, check, comment_check) {
	var payload = {
		"status": status
	}
	var workflowApi = {
		target: workFlowUri,
		sslClientProfile: 'omsapi_client_profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};
	var info = " TargetURL :" + workflowApi.target + "; Method :" + workflowApi.method + "; Data :" + JSON.stringify(workflowApi.data) + ". ";
	try {
		urlopen.open(workflowApi, function(error, response) {
			if (error) {
				var errorinfo = "omsapi_v2_018 urlopen connect error with Get workflowApi for Id , details are : " + info + "; error info :" + error
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapi_v2_018 urlopen connect error with Get workflowApi for Id " + CrewAssign_ID + " with error as " + JSON.stringify(error));
				session.reject("urlopen connect error with Get workflowApi for Id " + CrewAssign_ID + " with error as " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message from workflowApi , details are : " + info + "; error info :" + error
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from workflowApi" + JSON.stringify(error));
							session.reject(" failure in reading message from workflowApi" + JSON.stringify(error));
						} else {
							var payload = {
								"location": {
									"coordinates": [
										longitude,
										latitude
									],
									"type": "POINT"
								}
							}
							var CrewPatchUri = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + Inp_crewId;
							CrewPatchapiCall(CrewPatchUri, payload, id, Inp_crewId, comments, check, comment_check);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from workflowApi , details are : " + info + "; error info :" + error
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from workflowApi api  " + JSON.stringify(error));
							session.reject("failure in reading message from workflowApi api");
						} else {
							var errorinfo = "Error code returned from workflowApi api  for  id: " + CrewAssign_ID + " statusCode " + responseStatusCode + " , details are : " + info + "; resonse info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("Error code returned from workflowApi api  for  id: " + CrewAssign_ID + " statusCode " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from workflowApi api  for id: " + CrewAssign_ID + " statusCode " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	} catch (error) {
		var errorinfo = "omsapi_v2_018 urlopen connect error with Get workflowApi for Id , details are : " + info + "; error info :" + error
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapi_v2_018 urlopen connect error with Get workflowApi for Id " + CrewAssign_ID + " with error as " + JSON.stringify(error));
		session.reject("urlopen connect error with Get workflowApi for Id " + CrewAssign_ID + " with error as " + JSON.stringify(error));
	}
}

function CrewPatchapiCall(CrewPatchUri, payload, id, Inp_crewId, comments, check, comment_check) {
	var CrewPatchapi = {
		target: CrewPatchUri,
		sslClientProfile: 'omsapi_client_profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};
	if (check == 'False') {
		var info = " TargetURL :" + CrewPatchapi.target + "; Method :" + CrewPatchapi.method + "; Data :" + JSON.stringify(CrewPatchapi.data) + ". ";
		try {
			urlopen.open(CrewPatchapi, function(error, response) {
				if (error) {
					var errorinfo = "omsapi_v2_019 urlopen connect error with Get CrewPatchapi for action PR with Inp_crewId " + Inp_crewId + " , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error("omsapi_v2_019 urlopen connect error with Get CrewPatchapi for action PR with Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
					session.reject("urlopen connect error with Get CrewPatchapi for Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message from for action PR  CrewPatchapi , details are : " + info + "; error info :" + error
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from for action PR  CrewPatchapi" + JSON.stringify(error));
								session.reject(" failure in reading message from for action PR  CrewPatchapi" + JSON.stringify(error));
							} else {
								logger.debug("crewPatch call is Succesfull");
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from CrewPatchapi api , details are : " + info + "; error info :" + error
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from CrewPatchapi api  " + JSON.stringify(error));
								session.reject("failure in reading message from CrewPatchapi api");
							} else {
								var errorinfo = "Error code returned from CrewPatchapi api  for  crewId: " + Inp_crewId + " statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("Error code returned from CrewPatchapi api  for  crewId: " + Inp_crewId + " statusCode " + responseStatusCode + " " + responseData);
								session.reject("Error code returned from CrewPatchapi api  for crewId: " + Inp_crewId + " statusCode " + responseStatusCode + " " + responseData);
							}
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "omsapi_v2_019 urlopen connect error with Get CrewPatchapi for action PR with Inp_crewId " + Inp_crewId + " , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("omsapi_v2_019 urlopen connect error with Get CrewPatchapi for action PR with Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
			session.reject("urlopen connect error with Get CrewPatchapi for Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
		}
	}
	if (comment_check == 'False') {
		var payload = {
			"comment": comments
		}
		var commentUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/Comment';
		commentAPI(commentUri, payload, id);
	}
}

function commentAPI(commenturl, payload, id) {
	//Performing oms call to update the comment
	var commentUriapi = {
		target: commenturl,
		sslClientProfile: 'omsapi_client_profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};
	var info = " TargetURL :" + commentUriapi.target + "; Method :" + commentUriapi.method + "; Data :" + JSON.stringify(commentUriapi.data) + ". ";
	try {
		urlopen.open(commentUriapi, function(error, response) {
			if (error) {
				var errorinfo = "omsapi_v2_020 urlopen connect error with Get commentUriapi  for action PR with jobId " + id + " , details are : " + info + "; error info :" + error
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapi_v2_020 urlopen connect error with Get commentUriapi  for action PR with jobId " + id + " with error as " + JSON.stringify(error));
				session.reject("urlopen connect error with Get commentUriapi for action PR with jobId " + id + " with error as " + JSON.stringify(error));

			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message from CrewGetApi , details are : " + info + "; error info :" + error
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from commentUriapi" + JSON.stringify(error));
							session.reject(" failure in reading message from commentUriapi" + JSON.stringify(error));
						} else { }
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from CrewGetApi , details are : " + info + "; error info :" + error
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from commentUriapi api  " + JSON.stringify(error));
							session.reject("failure in reading message from commentUriapi api");
						} else {
							var errorinfo = "failure in reading message from CrewGetApi , details are : " + info + "; error info :" + error
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("Error code returned from commentUriapi api  for  jobId: " + id + " statusCode " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from commentUriapi api  for jobId: " + id + " statusCode " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	} catch (error) {
		var errorinfo = "omsapi_v2_020 urlopen connect error with Get commentUriapi  for action PR with jobId " + id + " , details are : " + info + "; error info :" + error
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapi_v2_020 urlopen connect error with Get commentUriapi  for action PR with jobId " + id + " with error as " + JSON.stringify(error));
		session.reject("urlopen connect error with Get commentUriapi for action PR with jobId " + id + " with error as " + JSON.stringify(error));
	}
}

function CustomFieldValues(CrewAssign_ID) {
	var URL = omsExternalURL + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssign_ID;
	var payload = {
		"customFieldValues": {
			"Disposition": Disposition_new
		}
	}
	var CrewAssignmentPatchapi = {
		target: URL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};
	var info = " TargetURL :" + CrewAssignmentPatchapi.target + "; Method :" + CrewAssignmentPatchapi.method + "; Data :" + JSON.stringify(CrewAssignmentPatchapi.data) + ". ";
	try {
		urlopen.open(CrewAssignmentPatchapi, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with  CrewAssignmentPatchapi , details are : " + info + "; error info :" + error
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("urlopen connect error with  CrewAssignmentPatchapi with error as " + JSON.stringify(error));
				session.reject("urlopen connect error with  CrewAssignmentPatchapi with error as " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from PatchJobAPI , details are : " + info + "; error info :" + error
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("failure in reading message from PatchJobAPI " + JSON.stringify(error));
						session.reject("failure in reading message from PatchJobAPI ");
					} else {
						if ((responseStatusCode == 200) || (responseStatusCode == 400 && responseData == 'No updates')) {
							//hm.response.statusCode = responseStatusCode;
							logger.info("response received from patch call api " + JSON.stringify(responseData));
						} else {
							response.readAsBuffer(function(error, ErrorresponseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "failure reading response from patch call api , details are : " + info + "; error info :" + error
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("failure reading response from patch call api" + JSON.stringify(error));
									session.output.write("failure reading response from patch call api");
								} else {
									var errorinfo = "error response from patch call api " + responseStatusCode + " , details are : " + info + "; response info :" + ErrorresponseData;
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("error response from patch call api" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
									session.reject("error response from patch call api" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								}
							});

						}
					}
				});
			}
		});
	}
	catch (error) {
		var errorinfo = "urlopen connect error with  CrewAssignmentPatchapi , details are : " + info + "; error info :" + error
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("urlopen connect error with  CrewAssignmentPatchapi with error as " + JSON.stringify(error));
		session.reject("urlopen connect error with  CrewAssignmentPatchapi with error as " + JSON.stringify(error));
	}
}
