var urlopen = require('urlopen');
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var hm = require('header-metadata');
var sm = require('service-metadata');
var apiToken = ctx.getVariable("apiToken");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var requestedCrewType = ctx.getVariable("requestedCrewType");
var crewInternalID = ctx.getVariable("crewInternalID");
var action_value = ctx.getVariable("action_value");
var worktypeid = ctx.getVariable("worktypeid");
var Inp_crewId = ctx.getVariable("crewId");
var check = ctx.getVariable("check");
var comment_check = ctx.getVariable("comment_check");
var id = ctx.getVariable("id");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var disposition_check = ctx.getVar("disposition_check");
var Disposition = ctx.getVar("Disposition");
var Disposition_new = ctx.getVar("Disposition_new");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var Worktype_status = ctx.getVar("Worktype_status");
var WorkTypeID = ctx.getVar("WorkTypeID");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var logger = console.options({
	'category': 'all'
});

var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;
	logger.debug("inside OutageAPP----" + apiToken);
} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;
	logger.debug("inside chatbotAPP----" + apiToken);
} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;
	logger.debug("inside reportAPP----" + apiToken);
} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;
	logger.debug("inside maximoAPP----" + apiToken);
}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (action_value == 'Assign') {
		var payload = {
			"workTypeID": WorkTypeID,
			"crewID": crewInternalID,
			"status": Worktype_status,
			"requestedCrewType": requestedCrewType
		}
		//var jobid = incomingdata.jobId;
		var CrewPOSTUri = omsExternalURL + '/api/ServiceType/Electric/CrewAssignment?jobIDs=' + id;
		var CrewPOSTapi = {
			target: CrewPOSTUri,
			sslClientProfile: 'omsapi_client_profile',
			method: 'POST',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		var info = " TargetURL :" + CrewPOSTapi.target + "; Method :" + CrewPOSTapi.method + "; Data :" + JSON.stringify(CrewPOSTapi.data) + ". ";
		try {
			urlopen.open(CrewPOSTapi, function(error, response) {
				if (error) {
					var errorinfo = "omsapi_v2_022 urlopen connect error with  CrewPOSTapi , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error("omsapi_v2_022 urlopen connect error with  CrewPOSTapi with error as " + JSON.stringify(error));
					session.reject("urlopen connect error with  CrewPOSTapi with error as " + JSON.stringify(error));

				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading message from CrewPOSTapi , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from CrewPOSTapi" + JSON.stringify(error));
								session.reject(" failure in reading message from CrewPOSTapi" + JSON.stringify(error));

							} else {
								var result = responseData.data[0].status.success;
								var message = responseData.data[0].status.message;
								if (message) {
									var message = responseData.data[0].status.message;
									logger.error(message);
									var errorinfo = message + " , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									session.reject(message);
								}
								else {
									ctx.setVariable("workflow_data", responseData);
									var CrewAssign_ID = responseData.data[0].model.id;
									if (disposition_check == 'False') {
										CustomFieldValues(CrewAssign_ID)
									} else { }
									var longitude = incomingdata.longitude;
									var latitude = incomingdata.latitude;
									var payload = {
										"location": {
											"coordinates": [
												longitude,
												latitude
											],
											"type": "POINT"
										}
									}

									var CrewPatchUri = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + Inp_crewId;
									var CrewPatchapi = {
										target: CrewPatchUri,
										sslClientProfile: 'omsapi_client_profile',
										method: 'PATCH',
										contentType: 'application/json',
										headers: {
											'osiApiToken': apiToken
										},
										data: payload
									};
									var info = " TargetURL :" + CrewPatchapi.target + "; Method :" + CrewPatchapi.method + "; Data :" + JSON.stringify(CrewPatchapi.data) + ". ";
									if (check == 'False') {
										try {
											urlopen.open(CrewPatchapi, function(error, response) {
												if (error) {
													var errorinfo = "omsapi_v2_019 urlopen connect error with PATCH CrewPatchapi for action AS with Inp_crewId " + Inp_crewId + " , details are : " + info + "; error info :" + error;
													ilsctx.setVariable("errorDescription", errorinfo);
													logger.error("omsapi_v2_019 urlopen connect error with PATCH CrewPatchapi for action AS with Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
													session.reject("urlopen connect error with PATCH CrewPatchapi for action AS with Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));

												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading message from CrewPatchapi , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("failure in reading message from CrewPatchapi" + JSON.stringify(error));
																session.reject(" failure in reading message from CrewPatchapi" + JSON.stringify(error));
															} else {
																logger.debug('CrewPatchapi is Successful' + responseData);
															}
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																//dp:reject stop the transaction and go error rule with error code and description
																var errorinfo = "failure in reading message from CrewPatchapi api , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("failure in reading message from CrewPatchapi api  " + JSON.stringify(error));
																session.reject("failure in reading message from CrewPatchapi api");
															} else {
																var errorinfo = "Error code returned from CrewPatchapi api  for id: " + Inp_crewId + " statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("Error code returned from CrewPatchapi api  for id: " + Inp_crewId + " statusCode " + responseStatusCode + " " + responseData);
																session.reject("Error code returned from CrewPatchapi api  for id: " + Inp_crewId + " statusCode " + responseStatusCode + " " + responseData);
															}
														});
													}
												}
											});
										}
										catch (error) {
											var errorinfo = "omsapi_v2_019 urlopen connect error with PATCH CrewPatchapi for action AS with Inp_crewId " + Inp_crewId + " , details are : " + info + "; error info :" + error;
											ilsctx.setVariable("errorDescription", errorinfo);
											logger.error("omsapi_v2_019 urlopen connect error with PATCH CrewPatchapi for action AS with Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
											session.reject("urlopen connect error with PATCH CrewPatchapi for action AS with Inp_crewId " + Inp_crewId + " with error as " + JSON.stringify(error));
										}
									}
									var payload = {
										"comment": incomingdata.comments
									}
									var commentUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/Comment';
									var commentUriapi = {
										target: commentUri,
										sslClientProfile: 'omsapi_client_profile',
										method: 'POST',
										contentType: 'application/json',
										headers: {
											'osiApiToken': apiToken
										},
										data: payload
									};
									var info = " TargetURL :" + commentUriapi.target + "; Method :" + commentUriapi.method + "; Data :" + JSON.stringify(commentUriapi.data) + ". ";
									if (comment_check == 'False') {
										try {
											urlopen.open(commentUriapi, function(error, response) {
												if (error) {
													var errorinfo = "omsapi_v2_020 urlopen connect error with POST commentUriapi for action AS with jobId " + id + " , details are : " + info + "; error info :" + error;
													ilsctx.setVariable("errorDescription", errorinfo);
													logger.error("omsapi_v2_020 urlopen connect error with POST commentUriapi for action AS with jobId " + id + " with error as " + JSON.stringify(error));
													session.reject("urlopen connect error with POST commentUriapi for action AS with jobId " + id + " with error as " + JSON.stringify(error));

												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "failure in reading message from commentUriapi , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("failure in reading message from commentUriapi" + JSON.stringify(error));
																session.reject(" failure in reading message from commentUriapi" + JSON.stringify(error));
															} else { }
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																//dp:reject stop the transaction and go error rule with error code and description
																var errorinfo = "failure in reading message from commentUriapi api , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("failure in reading message from commentUriapi api  " + JSON.stringify(error));
																session.reject("failure in reading message from commentUriapi api");
															} else {
																var errorinfo = "Error code returned from commentUriapi api  for  id: " + id + " statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("Error code returned from commentUriapi api  for  id: " + id + " statusCode " + responseStatusCode + " " + responseData);
																session.reject("Error code returned from commentUriapi api  for id: " + id + " statusCode " + responseStatusCode + " " + responseData);
															}
														});
													}
												}
											});
										}
										catch (error) {
											var errorinfo = "omsapi_v2_020 urlopen connect error with POST commentUriapi for action AS with jobId " + id + " , details are : " + info + "; error info :" + error;
											ilsctx.setVariable("errorDescription", errorinfo);
											logger.error("omsapi_v2_020 urlopen connect error with POST commentUriapi for action AS with jobId " + id + " with error as " + JSON.stringify(error));
											session.reject("urlopen connect error with POST commentUriapi for action AS with jobId " + id + " with error as " + JSON.stringify(error));
										}
									}
								}
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from CrewPOSTapi api , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("failure in reading message from CrewPOSTapi api  " + JSON.stringify(error));
								session.reject("failure in reading message from CrewPOSTapi api");
							} else {
								var errorinfo = "Error code returned from CrewPOSTapi api  for  id: " + id + " statusCode " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("Error code returned from CrewPOSTapi api  for  id: " + id + " statusCode " + responseStatusCode + " " + responseData);
								session.reject("Error code returned from CrewPOSTapi api  for id: " + id + " statusCode " + responseStatusCode + " " + responseData);
							}
						});
					}
				}
			});
		}
		catch (error) {
			var errorinfo = "omsapi_v2_022 urlopen connect error with  CrewPOSTapi , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("omsapi_v2_022 urlopen connect error with  CrewPOSTapi with error as " + JSON.stringify(error));
			session.reject("urlopen connect error with  CrewPOSTapi with error as " + JSON.stringify(error));
		}
	}

});

function CustomFieldValues(CrewAssign_ID) {
	var URL = omsExternalURL + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssign_ID;
	var payload = {
		"customFieldValues": {
			"Disposition": Disposition_new
		}
	}
	var CrewAssignmentPatchapi = {
		target: URL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};
	var info = " TargetURL :" + CrewAssignmentPatchapi.target + "; Method :" + CrewAssignmentPatchapi.method + "; Data :" + JSON.stringify(CrewAssignmentPatchapi.data) + ". ";
	try {
		urlopen.open(CrewAssignmentPatchapi, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with  CrewAssignmentPatchapi , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("urlopen connect error with  CrewAssignmentPatchapi with error as " + JSON.stringify(error));
				session.reject("urlopen connect error with  CrewAssignmentPatchapi with error as " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from PatchJobAPI , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("failure in reading message from PatchJobAPI " + JSON.stringify(error));
						session.reject("failure in reading message from PatchJobAPI ");
					} else {
						if ((responseStatusCode == 200) || (responseStatusCode == 400 && responseData == 'No updates')) {
							//hm.response.statusCode = responseStatusCode;
							logger.info("response received from patch call api " + JSON.stringify(responseData));
						} else {
							response.readAsBuffer(function(error, ErrorresponseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "failure reading response from patch call api , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("failure reading response from patch call api" + JSON.stringify(error));
									session.output.write("failure reading response from patch call api");
								} else {
									var errorinfo = "error response from patch call api" + responseStatusCode + " , details are : " + info + "; response info :" + ErrorresponseData;
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("error response from patch call api" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
									session.reject("error response from patch call api" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								}
							});

						}
					}
				});
			}
		});
	}
	catch (error) {
		var errorinfo = "urlopen connect error with  CrewAssignmentPatchapi , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("urlopen connect error with  CrewAssignmentPatchapi with error as " + JSON.stringify(error));
		session.reject("urlopen connect error with  CrewAssignmentPatchapi with error as " + JSON.stringify(error));
	}
}
