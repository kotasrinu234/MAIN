var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var errexitctx = session.name("ILSExit") || session.createContext("ILSExit");
var entryDescription = session.parameters.CrewStatusUpdateEntryDescription;
var exitDescription = session.parameters.CrewStatusUpdateExitDescription;
var messageType = session.parameters.messageType;
var apiName = session.parameters.CrewStatusUpdateApiName;
var jobDetailCount = session.parameters.getImageJobDetailCount;
if (apiName !== undefined || apiName !== null || apiName !== '') {
	ctx.setVariable("apiName", apiName);
}
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var URL = sm.getVar('var://service/URI');
		var URI = URL.toString().split("/");
		var crewDisplayID = URI[4];
		if (crewDisplayID) {
			if (crewDisplayID == null || crewDisplayID == '' || crewDisplayID == undefined) {
				errexitctx.setVariable("crewDisplayID", '');
			}
			else {
				errexitctx.setVariable("crewDisplayID", crewDisplayID);
			}
		}
		if (crewDisplayID) {
			if (crewDisplayID == null || crewDisplayID == '' || crewDisplayID == undefined) {
				ctx.setVariable("crewDisplayID", '');
			}
			else {
				ctx.setVariable("crewDisplayID", crewDisplayID);
			}
		}
		if (incomingdata.msgId) {
			if (incomingdata.msgId !== undefined || incomingdata.msgId !== null || incomingdata.msgId !== '') {
				ctx.setVariable('correlationID', incomingdata.msgId);
			}
		}
		else {
			ctx.setVariable('correlationID', uuidv4());
		}
		if (incomingdata.jobId) {
			var Id = incomingdata.jobId
			if (Id !== null || Id !== '' || Id !== undefined) {
				if (Id.length == jobDetailCount) {
					ctx.setVariable("jobID", Id);
				}
				else {
					ctx.setVariable("jobDisplayID", Id);
				}
			}
		}
		if (incomingdata.action) {
			if (incomingdata.action !== undefined || incomingdata.action !== null || incomingdata.action !== '') {
				ctx.setVariable("assignmentStatus", incomingdata.action)
			}
		}
		if (incomingdata.workType) {
			if (incomingdata.workType !== undefined || incomingdata.workType !== null || incomingdata.workType !== '') {
				ctx.setVariable("workType", incomingdata.workType)
			}
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
	}
});
