var urlopen = require('urlopen');
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var action_value = ctx.getVariable("action_value");
var lookupURL = ctx.getVariable("lookupURL");
var workType = ctx.getVariable("workType");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (action_value == 'Assign') {
		var WorktypeIDlookupMessage = {
			"lookupReq": {
				"type": [{
					"name": "workTypes",
					"label": workType
				}]
			}
		}
		var WorktypeIDlookupResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: WorktypeIDlookupMessage
		};
		var info = " TargetURL :" + WorktypeIDlookupResponse.target + "; Method :" + WorktypeIDlookupResponse.method + "; Data :" + JSON.stringify(WorktypeIDlookupResponse.data) + ". ";
		try {
			urlopen.open(WorktypeIDlookupResponse, function(error, response) {
				if (error) {
					var errorinfo = "urlopen connect error with WorktypeIDlookupResponse, details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error(JSON.stringify(errorinfo));
					session.reject(JSON.stringify(errorinfo));
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					logger.debug("response:" + response);
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure in reading message from WorktypeIDlookupResponse, details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error(JSON.stringify(errorinfo));
								session.reject(JSON.stringify(errorinfo));

							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from WorktypeIDlookupResponse " + JSON.stringify(responseData));
								if (responseData.lookupRep.type[0].result == 0) {
									var WorkTypeID = responseData.lookupRep.type[0].id;
									ctx.setVariable("WorkTypeID", WorkTypeID);
									var lookupMessage = {
										"lookupReq": {
											"type": [{
												"name": "workType.workflows",
												"id": WorkTypeID,
												"label": "Dispatched"
											}]
										}
									}
									var LookupServiceResponse = {
										target: lookupURL,
										method: 'POST',
										contentType: 'application/json',
										data: lookupMessage
									};
									var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
									try {
										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												var errorinfo = "urlopen connect error with  LookupServiceResponse, details are : " + info + "; error info :" + error;
												ilsctx.setVariable("errorDescription", errorinfo);
												logger.error(JSON.stringify(errorinfo));
												session.reject(JSON.stringify(errorinfo))
											} else {
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsJSON(function(error, responseData) {
														if (error) {
															// error while reading response or transferring data to Buffer
															var errorinfo = "failure in reading message from LookupServiceResponse, details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error(JSON.stringify(errorinfo));
															session.reject(JSON.stringify(errorinfo));
														} else {
															hm.response.statusCode = responseStatusCode;
															if (responseData.lookupRep.type[0].result == 0) {
																var status = responseData.lookupRep.type[0].status;
																ctx.setVariable("Worktype_status", status);
															} else {
																var errorinfo = "lookup result for wortypeid is not 0, details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error(JSON.stringify(errorinfo));
																session.reject(JSON.stringify(errorinfo));
															}
														}
													});
												} else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															//dp:reject stop the transaction and go error rule with error code and description
															var errorinfo = "failure in reading message from lookupresponse, details are : " + info + "; error info :" + error;
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error(JSON.stringify(errorinfo));
															session.reject(JSON.stringify(errorinfo));
														} else {
															var errorinfo = "lookup response is  " + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
															ilsctx.setVariable("errorDescription", errorinfo);
															logger.error(errorinfo);
															session.reject(errorinfo);
														}
													});
												}
											}
										});
									}
									catch (error) {
										var errorinfo = "urlopen connect error with  LookupServiceResponse, details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										logger.error(JSON.stringify(errorinfo));
										session.reject(JSON.stringify(errorinfo))
									}
								} else {
									var errorinfo = "WorktypeIDlookupResponse result is not 0, details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("WorktypeIDlookupResponse result is not 0");
									session.reject("WorktypeIDlookupResponse result is not 0");
								}
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "failure in reading message from WorktypeIDlookupResponse, details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error(JSON.stringify(errorinfo));
								session.reject(JSON.stringify(errorinfo));
							} else {
								var errorinfo = "WorktypeIDlookupResponse response is  " + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "urlopen connect error with WorktypeIDlookupResponse, details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error(JSON.stringify(errorinfo));
			session.reject(JSON.stringify(errorinfo));
		}
		var JOB_workTypeID = ctx.getVariable("JOB_workTypeID");
		/*         if (JOB_workTypeID == undefined || JOB_workTypeID == '' || JOB_workTypeID == null) {
					logger.debug("inside if+");
		
					var jobTypeID = ctx.getVariable("JOB_jobTypeID");
		
					var lookupMessage = {
						"lookupReq": {
							"type": [{
								"name": "jobTypesWorkID",
								"id": jobTypeID
		
							}]
						}
					}
					var LookupServiceResponse = {
						target: lookupURL,
						method: 'POST',
						contentType: 'application/json',
						data: lookupMessage
					};
		
					urlopen.open(LookupServiceResponse, function(error, response) {
						if (error) {
							logger.error("omsapi_v2_021 urlopen connect error with jobTypesWorkID LookupServiceResponse" + JSON.stringify(error));
							session.reject("urlopen connect error with jobTypesWorkID LookupServiceResponse" + JSON.stringify(error))
						} else {
							// read response data
							// get the response status code
							var responseStatusCode = response.statusCode;
							logger.debug("response:" + response);
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										logger.error("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
										session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));
		
									} else {
										hm.response.statusCode = responseStatusCode;
										logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
										if (responseData.lookupRep.type[0].result == 0) {
											var label = responseData.lookupRep.type[0].label;
											var worktypeid = label;
											ctx.setVariable("worktypeid", worktypeid);
										} else {
											logger.error("lookup result for wortypeid is not 0");
											session.reject("worktypid didnt return from lookup response");
										}
									}
								});
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										logger.error("failure in reading message from lookupresponse" + JSON.stringify(error));
										session.reject("failure in reading message from lookupresponse");
									} else {
										logger.error("lookup response is  " + responseStatusCode + " " + responseData);
										session.reject("lookup response is " + responseStatusCode + " " + responseData);
									}
								});
							}
						}
					});
		
				} else {
					var worktypeid = JOB_workTypeID;
					ctx.setVariable("worktypeid", worktypeid);
				} */
	}
});
