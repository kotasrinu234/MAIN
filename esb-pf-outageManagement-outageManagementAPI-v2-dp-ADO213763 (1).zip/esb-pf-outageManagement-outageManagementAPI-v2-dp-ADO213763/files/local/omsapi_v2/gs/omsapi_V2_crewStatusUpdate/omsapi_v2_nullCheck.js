var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
//set stylesheet parameters to variable

var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookUpURL;
var apiToken_chatbot = session.parameters.apiToken_chatbot;
var apiToken_maximo = session.parameters.apiToken_maximo;
var apiToken_reporting = session.parameters.apiToken_reporting;

//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
ctx.setVariable("apiToken_maximo", apiToken_maximo);
ctx.setVariable("apiToken_reporting", apiToken_reporting);

//To perform null check on request payload
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var nullcheck = session.parameters.nullcheck;
	if (nullcheck == 'yes') {
		var URL = sm.getVar('var://service/URI');
		//var crewId = URL.substring(URL.lastIndexOf("Crew/")+5,URL.lastIndexOf("/Status"));
		var URI = URL.toString().split("/");
		var crewId = URI[4];
		if (crewId == null || crewId == '' || crewId == undefined) {
			var errorinfo = "crewId is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error('crewId is not present in input payload');
			session.reject('crewId is not present in input payload');
		}
		else {
			ctx.setVariable("crewId", crewId);
		}

		var msgId = incomingdata.msgId;

		if (msgId == null || msgId == '' || msgId == undefined) {
			var errorinfo = "msgId is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error('msgId is not present in input payload');
			session.reject('msgId is not present in input payload');
		}

		var jobId = incomingdata.jobId;
		if (jobId == null || jobId == '' || jobId == undefined) {
			var errorinfo = "jobId is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error('jobId is not present in input payload');
			session.reject('jobId is not present in input payload');
		}

		var action = incomingdata.action;
		if (action == null || action == '' || action == undefined) {
			var errorinfo = "action is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error('action is not present in input payload');
			session.reject('action is not present in input payload');
		}
	}
	var Disposition = incomingdata.disposition;
	var disposition_check;
	if (Disposition == null || Disposition == undefined || Disposition == '') {
		disposition_check = 'True';
		ctx.setVariable("disposition_check", disposition_check);
	} else {
		disposition_check = 'False';
		ctx.setVariable("disposition_check", disposition_check);
		ctx.setVariable("Disposition", Disposition);
		var i = 0;
		var Disposition_new = [];
		for (i = 0; i < Disposition.length; i++) {
			var label = Disposition[i];
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "crewAssignmentCustomFields",
						"externalLabel": "Disposition",
						"label": label
					}]
				}
			}
			var LookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
			try {
				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
						session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						logger.debug("response:" + JSON.stringify(response));
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "omsapiv2_101:failure in reading message from LookupServiceResponse , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("omsapiv2_101:failure in reading message from LookupServiceResponse" + JSON.stringify(error));
									session.reject("failure in reading message from LookupServiceResponse" + JSON.stringify(error));

								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
									var status;
									if (responseData.lookupRep.type[0].result == 0) {
										status = responseData.lookupRep.type[0].status;
									} else {
										var errorinfo = "disposition lookup result is not 0 ";
										ilsctx.setVariable("errorDescription", errorinfo);
										session.reject('disposition lookup result is not 0')
									}
									Disposition_new.push(status);
									var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
									ctx.setVariable("Disposition_new", Disposition_new);
								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "failure in reading message from lookup call , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("failure in reading message from lookup call " + JSON.stringify(error));
									session.reject("failure in reading message from lookup call");
								} else {
									var errorinfo = "Error code returned from lookup call:" + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
									ilsctx.setVariable("errorDescription", errorinfo);
									logger.error("Error code returned from lookup call:" + responseStatusCode + " " + responseData);
									session.reject("Error code returned from lookup call: " + responseStatusCode + " " + responseData);
								}
							});
						}
					}
				});
			}
			catch (error) {
				var errorinfo = "urlopen connect error with LookupServiceResponse , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
				session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error))
			}

		}
	}
});
