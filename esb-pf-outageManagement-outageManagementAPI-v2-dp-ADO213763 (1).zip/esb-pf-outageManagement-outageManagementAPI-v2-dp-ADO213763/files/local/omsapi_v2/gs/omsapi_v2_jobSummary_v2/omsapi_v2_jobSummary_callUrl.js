var ctx = session.name("JobSummary") || session.createContext("JobSummary");
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");


function callURL(url, method, myctx, payload) {
	var options = {
		target: url,
		method: method,
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "omsapi_client_profile"
	};
	if (method == "POST" || method == "PATCH") {
		options.data = payload;
	}


	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				var errorinfo = "url connection error with 'callURL', details are : " + info + "; error info :" + error
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", response.statusCode);
				ilsctx.setVariable("errorMessage", response.reasonPhrase);
				logger.error(errorinfo);
				session.reject(errorinfo);
				//throw error;
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				var ctx = session.name("JobSummary") || session.createContext("JobSummary");
				ctx.setVariable(myctx + "_responseStatusCode", responseStatusCode);
				ctx.setVariable(myctx + "_response", response);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response from 'callURL', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
							//throw error;
						} else {
							logger.info("success url response received");
							var ctx = session.name("JobSummary") || session.createContext("JobSummary");
							ctx.setVariable(myctx + "_responseData", responseData);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message 'callURL', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "response received , details are : " + info + "; error info :" + error + responseData;
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error("response received " + responseStatusCode + " " + responseData);
							session.reject("response received" + " " + responseStatusCode + " " + responseData);
						}
					});


				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error with 'callURL', details are : " + info + "; error info :" + err
		ilsctx.setVar('errorDescription', errorinfo);
		logger.error(errorinfo);
		session.reject(errorinfo);
	}
}

module.exports = callURL;
