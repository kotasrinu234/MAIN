var ctx = session.name("JobSummary")|| session.createContext("JobSummary");
var doLookup = require('./omsapi_lookup.js');

var typeArr=new Array();
var lookUpArr=new Array();

var omsJobIdDetailList = ctx.getVariable('omsJobDetails_responseData');
if ((omsJobIdDetailList != undefined) && (omsJobIdDetailList != null) && (omsJobIdDetailList != '')) {
for(var i=0; i<omsJobIdDetailList.length;i++){
	ctx.setVariable(omsJobIdDetailList[i].displayID,omsJobIdDetailList[i].displayID);
	ctx.setVariable(omsJobIdDetailList[i].displayID+'_jobType',omsJobIdDetailList[i].jobTypeID);
	ctx.setVariable(omsJobIdDetailList[i].displayID+'_statusCode',omsJobIdDetailList[i].status);
	
	typeArr = new Array();
	var statusReq = {};
	statusReq.name="jobTypes.workflows";
	statusReq.id=omsJobIdDetailList[i].jobTypeID;
	statusReq.status=omsJobIdDetailList[i].status;
	typeArr.push(statusReq);
	doLookup(typeArr,"jobStatus_"+omsJobIdDetailList[i].displayID);

	typeArr = new Array();
	var jobTypeReq = {};
	jobTypeReq.name="jobTypes";
	jobTypeReq.id=omsJobIdDetailList[i].jobTypeID;
	typeArr.push(jobTypeReq);
	doLookup(typeArr,"jobType_"+omsJobIdDetailList[i].displayID);
}
}

var omsJobDetailsCallList = ctx.getVariable("omsJobDetailsCallResponse_responseData");
if ((omsJobDetailsCallList != undefined) && (omsJobDetailsCallList != null) && (omsJobDetailsCallList != '')) {
for(var i=0; i<omsJobDetailsCallList.length;i++){
	ctx.setVariable(omsJobDetailsCallList[i].displayID,omsJobDetailsCallList[i].displayID);
	ctx.setVariable(omsJobDetailsCallList[i].displayID+'_jobType',omsJobDetailsCallList[i].jobTypeID);
	ctx.setVariable(omsJobDetailsCallList[i].displayID+'_statusCode',omsJobDetailsCallList[i].status);
	
	lookUpArr = new Array();
	var statusReq = {};
	statusReq.name="jobTypes.workflows";
	statusReq.id=omsJobDetailsCallList[i].jobTypeID;
	statusReq.status=omsJobDetailsCallList[i].status;
	lookUpArr.push(statusReq);
	doLookup(lookUpArr,"jobStatus_"+omsJobDetailsCallList[i].displayID);

	lookUpArr = new Array();
	var jobTypeReq = {};
	jobTypeReq.name="jobTypes";
	jobTypeReq.id=omsJobDetailsCallList[i].jobTypeID;
	lookUpArr.push(jobTypeReq);
	doLookup(lookUpArr,"jobType_"+omsJobDetailsCallList[i].displayID);
}
}