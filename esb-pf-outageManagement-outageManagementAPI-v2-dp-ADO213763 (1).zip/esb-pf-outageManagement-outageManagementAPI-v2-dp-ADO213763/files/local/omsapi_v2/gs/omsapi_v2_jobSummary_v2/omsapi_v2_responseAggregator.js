var ctx = session.name("JobSummary")|| session.createContext("JobSummary");
var jobIds = ctx.getVariable('inputJobIds');
var omsJobIdsResponse = ctx.getVariable("omsJobDetails_responseData");
var omsJobIdsResponseDetails = ctx.getVariable("omsJobDetailsCallResponse_responseData");
var dbIds = ctx.getVariable("dbJobIds");
var omsIds = ctx.getVariable("omsJobIds");
var validOmsIds = new Array();
var responseArray = new Array();
var json;
var jobs = {};
var jobStatusMap = new Map([
	['7', 'Pending'],
	['8', 'Assigned'],
	['9', 'Held'],
	['10', 'Broadcast and Cancel'],
	['11', 'Broadcast and Cancel'],
	['12', 'Canceled'],
	['13', 'Verified'],
	['14', 'Dup and Cancel'],
	['15', 'Agreed Response'],
	['16', 'Closed'],
	['17', 'Awaiting Closure'],
	['18', 'Dispatch Assigned'],
	['20', ' Dependent Status (used by InService to track'],
	['21', 'Scheduled']
]);
var jobStatusValue;

for(var i =0; i<dbIds.length;i++ ){
	json={};
	if(ctx.getVariable(dbIds[i]) !== undefined && ctx.getVariable(dbIds[i])!=''){
		json.insvcJobNumber = dbIds[i];
		json.jobExist = "true";
		var jStatus = ctx.getVariable(dbIds[i]+'_statusCode');
		jobStatusValue = jobStatusMap.get(jStatus);
		json.jobStatus= jobStatusValue;
		json.jobType=ctx.getVariable(dbIds[i]+'_jobType');		
	}else{
		json.insvcJobNumber = dbIds[i];
		json.jobExist = "false";
	}
	responseArray.push(json);
}

if ((omsJobIdsResponse != undefined) && (omsJobIdsResponse != null) && (omsJobIdsResponse != '')) {
for(var i =0; i<omsJobIdsResponse.length;i++ ){
	json={};
	validOmsIds.push(omsJobIdsResponse[i].displayID);
		json.insvcJobNumber = omsJobIdsResponse[i].displayID;
		json.jobExist = "true";
		var jobStatusLookup=ctx.getVariable("jobStatus_"+omsJobIdsResponse[i].displayID+'_lookup');
		var jobTypeLookup=ctx.getVariable("jobType_"+omsJobIdsResponse[i].displayID+'_lookup');
		json.jobStatus=jobStatusLookup[0].label;
		json.jobType=jobTypeLookup[0].label;
		//json.jobStatus=jobStatusLookup.lookupRep.type[0].label;
		//json.jobType=jobTypeLookup.lookupRep.type[0].label;
		
	
	responseArray.push(json);
}
}

if ((omsJobIdsResponseDetails != undefined) && (omsJobIdsResponseDetails != null) && (omsJobIdsResponseDetails != '')) {

for(var k =0; k<omsJobIdsResponseDetails.length;k++ ){
	json={};
	validOmsIds.push(omsJobIdsResponseDetails[k].displayID);
		json.insvcJobNumber = omsJobIdsResponseDetails[k].displayID;
		json.jobExist = "true";
		var jobStatusLookup=ctx.getVariable("jobStatus_"+omsJobIdsResponseDetails[k].displayID+'_lookup');
		var jobTypeLookup=ctx.getVariable("jobType_"+omsJobIdsResponseDetails[k].displayID+'_lookup');
		json.jobStatus=jobStatusLookup[0].label;
		json.jobType=jobTypeLookup[0].label;	
		
	
	responseArray.push(json);
}
}


var validOmsIdsString =  validOmsIds.join();

for(var j=0; j<omsIds.length;j++){
	if(omsIds[j]===""){
		ctx.setVariable("customErrorCode", '400');
				ctx.setVariable("customErrorMessage", 'Bad Request');
				ctx.setVariable("customReasonMessage", 'Bad Request');
				session.reject('Empty JobId found');
	}
	if(!(validOmsIdsString.includes(omsIds[j]))){
		json={};
		json.insvcJobNumber = omsIds[j];
		json.jobExist = "false";
		responseArray.push(json);
	}
}

jobs["JOBS"] = responseArray;


ctx.setVariable("jobs",jobs);
session.output.write(jobs);