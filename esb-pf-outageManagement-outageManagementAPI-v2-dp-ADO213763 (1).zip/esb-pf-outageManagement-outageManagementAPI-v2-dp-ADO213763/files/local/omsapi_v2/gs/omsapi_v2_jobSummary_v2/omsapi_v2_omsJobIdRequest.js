var ctx = session.name("JobSummary")|| session.createContext("JobSummary");
var callURL = require('./omsapi_v2_jobSummary_callUrl.js');
var url = session.parameters.omsExternalURL +"/api/ServiceType/Electric/Job/Query?isInternalIDs=false&includeFields=displayID%2Cstatus%2CjobTypeID&historical="+session.parameters.historicalValue;
//var url = "https://10.0.96.10:8443/oms/external/api/ServiceType/Electric/Job/Query?isInternalIDs=false&includeFields=displayID%2Cstatus%2CjobTypeID&historical=false";
var idList = ctx.getVariable("omsJobIds");

//fetching JobIds Summary
if (idList.length > 0){
callURL(url,"POST","omsJobDetails",idList);
}