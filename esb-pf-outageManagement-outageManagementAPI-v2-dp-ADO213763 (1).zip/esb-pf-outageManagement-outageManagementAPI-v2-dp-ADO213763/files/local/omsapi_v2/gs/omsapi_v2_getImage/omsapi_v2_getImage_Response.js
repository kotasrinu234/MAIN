var logger = console.options({
'category': 'all'
});

var json={};
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var response = ctx.getVar("getImageAPIResponse");

if(ctx.getVariable("responseArray") !=null || ctx.getVariable("responseArray") !='' || ctx.getVariable("responseArray") != undefined) { 
	json= ctx.getVariable("responseArray");
} else {
	json= '';
}

session.output.write(json);