var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var qs = require('querystring');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name('ILS') || session.createContext('ILS');
var keyField = session.parameters.keyField;
var keyValue = session.parameters.keyValue;
var businessProcess = session.parameters.businessProcess;
var azureURL = session.parameters.azureURL;
var uri = new String(sm.URI);
var json;
var idTypes;
var id;
var source;
var attachementId;
var fileName;
var requestTime;
var endDate;

if (uri.indexOf("?") != -1) {
	json = qs.parse(uri.substring(uri.indexOf("?") + 1));
	idTypes = json.idType;
	id = json.id;
	source = json.source;
	attachementId = json.attachementId;
	fileName = json.fileName;
	requestTime = json.requestTime;
	endDate = json.endDate;
}

//start : https://dte-api.dteco.com/api/imageFoundation/test/Images/process
var azureMetadataUrl = azureURL + '/' + businessProcess + '/subject/' + id;
var azureMetadataOptions = {
	target: azureMetadataUrl,
	sslClientProfile: 'omsapiv2_getImage_Client_Profile',
	method: 'GET',
	contentType: 'application/json',
	headers: {
		[keyField]: keyValue
	},

};
var info = " TargetURL :" + azureMetadataOptions.target + "; Method :" + azureMetadataOptions.method;
try {
	urlopen.open(azureMetadataOptions, function(error, response) {
		if (error) {
			var errorinfo = "omsapiv2_142:urlopen connect error with getImageAPI, details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("omsapiv2_142:urlopen connect error with getImageAPI" + JSON.stringify(errorinfo));
			session.reject("urlopen connect error with getImageAPI" + JSON.stringify(errorinfo));
		} else {
			var responseStatusCode = response.statusCode;
			var responsePhrase = response.reasonPhrase;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in putting message to getImageAPI, details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("failure in putting message to getImageAPI" + JSON.stringify(errorinfo));
						session.reject("failure in putting message to getImageAPI" + JSON.stringify(errorinfo));
					} else {
						hm.response.statusCode = responseStatusCode;
						logger.debug("response received from getImageAPI for JobId:" + "" + responseStatusCode);
						var getImageAPIResponse = JSON.parse(responseData);
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
						ctx.setVariable("getImageAPIResponse", getImageAPIResponse);
						var Date = getImageAPIResponse.displayID;
						var attachementId = getImageAPIResponse.attachementId;
						var responseArray = [];
						var responseArr = getImageAPIResponse;
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");

						for (var i = 0; i < responseArr.length; i++) {
							var response = {
								"id": id,
								"uploadTimeStamp": responseArr[i].Date,
								"attachementId": responseArr[i].attachementId,
								"fileName": responseArr[i].Name,
								"sourceUploadBy": responseArr[i].sourceUploadBy,
								"sourceUploadTimeStamp": responseArr[i].sourceUploadTimeStamp,
								"url": responseArr[i].url,
								"errorCode": responseArr[i].Status
							}
							responseArray.push(response);
						}
						ctx.setVariable('responseArray', responseArray);
					}
				});
			} else {
				var ctx = session.name("omsApiv_2") || session.createContext("omsApiv_2");
				ctx.setVariable('responseStatusCode', responseStatusCode);
				ctx.setVariable('responsePhrase', responsePhrase);
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from getImageAPI for negative ack, details are : " + info + "; error info :" + error +responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						logger.error("failure in reading message from getImageAPI for negative ack " + " " + responseData);
						session.reject("failure in reading message from getImageAPI for negative ack" + " " + responseData);
					} else {
						var errorinfo = "message from getImageAPI for negative ack, " + responseStatusCode +" details are : " + info + "; response info :" + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						session.reject('' + responseData);
					}
				});
			}
		}
	});
}
catch (err) {
	var errorinfo = "omsapiv2_142:urlopen connect error with getImageAPI, details are : " + info + "; error info :" + err;
	ilsctx.setVariable("errorDescription", errorinfo);
	logger.error("omsapiv2_142:urlopen connect error with getImageAPI" + JSON.stringify(errorinfo));
	session.reject("urlopen connect error with getImageAPI" + JSON.stringify(errorinfo));
}
