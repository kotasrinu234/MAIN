var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var qs = require('querystring');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var uri = new String(sm.URI);
var json;
var idTypes;
var id;
var source;
var attachementId;
var fileName;
var requestTime;
var endDate;

if (uri.indexOf("?") != -1) {
	json = qs.parse(uri.substring(uri.indexOf("?") + 1));
	idTypes = json.idType;
	if (idTypes == undefined || idTypes == null || idTypes == '') {
		var errorinfo = "idType cannot be empty in incoming request";
		ilsctx.setVariable("errorDescription", errorinfo);
		session.reject("idType cannot be empty in incoming request");
	} else if (idTypes != undefined || idType != null || idTypes != '') {
		if (idTypes === "1") {
			ctx.setVariable("idType", idTypes);
		} else {
			var errorinfo = "idType can be 1";
		ilsctx.setVariable("errorDescription", errorinfo);
			session.reject("idType can be 1");
		}
	}

	id = json.id;
	if (id === undefined || id === null || id === '') {
		var errorinfo = "id not found";
		ilsctx.setVariable("errorDescription", errorinfo);
		session.reject("id not found");
	} else {
		ctx.setVariable("id", id);
	}

	source = json.source;
	if (source === undefined || source === null || source === '') {
		var errorinfo = "source not found";
		ilsctx.setVariable("errorDescription", errorinfo);
		session.reject("source not found");
	} else if (source != undefined || source != null || source != '') {
		if (source === "1") {
			ctx.setVariable("source", source);
		} else {
			var errorinfo = "source can be 1";
		ilsctx.setVariable("errorDescription", errorinfo);
			session.reject("source can be 1");
		}
	}

	if ((source != "1") && (idTypes != "1")) {
		var errorinfo = "source and idTypes can be 1";
		ilsctx.setVariable("errorDescription", errorinfo);
		session.reject("source and idTypes can be 1");
	}

	if ((source == undefined && idTypes == undefined) || (id == undefined && idTypes == undefined) || (source == undefined && id == undefined)) {
		var errorinfo = "some required fields are missing";
		ilsctx.setVariable("errorDescription", errorinfo);
		session.reject('some required fields are missing');
		//logger.error("some required fields are not found.");
	}
}
