var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var exitDestination = session.parameters.azureURL;
ctx.setVariable("exitDestination", exitDestination);
var stepExitDescription = session.parameters.getImageStepExitDescription;
ctx.setVariable("stepExitDescription", stepExitDescription);
var ms = require('multistep');
	ms.callRule('omsapi_V2_PP_getImage_exit_rule', null, null, function(error) {
		if (error) {
			logger.error("Error in omsapi_V2_PP_getImage_exit_rule");
		}
	});
