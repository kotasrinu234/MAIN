var sm = require('service-metadata');
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.getImageEntryDescription;
var exitDescription = session.parameters.getImageExitDescription;
var jobDetailCount = session.parameters.getImageJobDetailCount;
var apiName = session.parameters.getImageApiName;
var messageType = session.parameters.messageType;
ctx.setVariable("messageType", messageType);
ctx.setVariable("apiName", apiName);
ctx.setVariable('entryDescription', entryDescription);
ctx.setVariable('exitDescription', exitDescription);
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var id = uuidv4()
ctx.setVariable("correlationID", id);
var uri = new String(sm.URI);
var qs = require('querystring');
var json;
if(uri.indexOf("?") !=-1) {
	json = qs.parse(uri.substring(uri.indexOf("?")+1));
	var jobId=json.id;
}
if (jobId) {
	if (jobId !== undefined || jobId !== null || jobId !== '') {
		if (jobId.length == jobDetailCount) {
			ctx.setVariable("jobID", jobId)

		}
		else {
			ctx.setVariable("jobDisplayID", jobId)
		}
	}
}
ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
