//This gatewayscript is used to frame the error response when any error has occured
//Date: 12th March 2020
//Author: Bhagya Lakshmi C D
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsapi_ReceiveComments")|| session.createContext("omsapi_ReceiveComments");
var ReqVal = ctx.getVariable("RequestValidation");
var logger = console.options({
    'category': 'all'
});
if(ReqVal == 'Failed'){
	//logger.error("Inside Error if");
	hm.current.statusCode = 400;
}
     
