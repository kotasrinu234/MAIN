var ctxadd = session.name("omsapi") || session.createContext("omsapi");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var backendURL = '';
var CommentPayload = '';
var TokenValue = '';
var readID = '';
var userId = '';
var urlIn = sm.getVar('var://service/URL-in');
var ctx = session.name("omsapi_ReceiveComments") || session.createContext("omsapi_ReceiveComments");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var ctx1 = session.name('ILS') || session.createContext('ILS');
var msgID = ctx1.getVar("correlationID");
ctx.setVariable("RequestValidation", "");
var customHeader = urlIn.split('=');
var URI = customHeader[customHeader.length - 1];
var logger = console.options({
	'category': 'all'
});
var URL = '';
var currentDateTime = new Date().toISOString();
var currentDate = DateConversion(currentDateTime);
ctx.setVar("currentDate", currentDate);
var commentURL = '';
var ctx2 = session.name("current") || session.createContext("current");
var currentUser = ctx2.getVar("user");
var TokenValue ;
var incomingUser = currentUser;
if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	TokenValue = session.parameters.apiToken_Urma; 
}else if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	TokenValue = session.parameters.apiToken;
}else{
	TokenValue = session.parameters.apiToken_Multipurpose
}
var omsExternalURL = session.parameters.omsExternalURL;
logger.info("URI::" + URI)
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		hm.response.statusCode = 500
		session.output.write(readAsJSONError);
	} else {
		sm.setVar('var://service/mpgw/skip-backside', true);
		var asyncReplyFlag = incomingdata.asyncReplyFlag;
		if (asyncReplyFlag == true) {
			if (!(incomingdata.id === undefined || incomingdata.id === '' || incomingdata.id === null)) {
				if (!(incomingdata.comment === undefined || incomingdata.comment === '' || incomingdata.comment === null)) {
					var mqmd = {
						MQMD: {
							StrucId: {
								$: 'MD '
							},
							Format: {
								$: 'MQHRF2 '
							},
							MsgType: {
								$: '8'
							},
							Persistence: {
								$: '1'
							}
						}
					};
					var mqrfh2 = {
						MQRFH2: {
							Version: {
								$: '2'
							},
							Format: {
								$: 'MQSTR'
							},
							NameValueData: {
								NameValue: [{
									usr: {
										URIExtract: {
											$: URI
										},
									}
								}]
							}
						}
					};
					var urlopenHeaders = {
						MQMD: mqmd,
						MQRFH2: mqrfh2
					};
					if (incomingdata.messageID === null || incomingdata.messageID === undefined || incomingdata.messageID === '') {
						incomingdata.messageID = msgID;
					}
					else {
						incomingdata.messageID = incomingdata.messageID;
					}
					session.output.write(incomingdata);
					var options = {
						target: 'dpmq://omsapi_RECEIVE_REQUEST_QM/?RequestQueue=OMSAPI.REQUEST.FOR.COMMENT',
						headers: urlopenHeaders,
						data: incomingdata,
					};
					var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
					try {
						urlopen.open(options, function(error, response) {
							if (error) {
								var errorinfo = "omsapi_102 unable to connect MQ , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("omsapi_102 unable to connect MQ " + JSON.stringify(error));
								session.reject("Unable to connect MQ" + JSON.stringify(error));
							} else {
								var mqrc = response.statusCode;
								if (mqrc == 0) {
									var replyMQMD = response.get({
										type: 'mq'
									}, 'MQMD');
									var replyMQRFH2 = response.get({
										type: 'mq'
									}, 'MQRFH2');
									response.readAsBuffer(function(readError, responseData) {
										if (readError) {
											var errorinfo = "omsapi_105 error reading response from MQ , details are : " + info + "; error info :" + readError;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatusCode", "500");
											logger.error("omsapi_105 error reading response from MQ" + readError);
											session.reject("Error reading response from MQ" + readError);
										} else {
											logger.info("MQResponseData" + responseData);
										}
									});
								} else {
									var errorinfo = "omsapi_106 urlopen.open error [MQRC=" + mqrc + "] , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", mqrc);
									logger.error('omsapi_106 ** urlopen.open error [MQRC=' + mqrc + ']');
									session.reject('urlopen.open error MQ [MQRC=' + mqrc + ']');
								}
							}
						});
					}
					catch (error) {
						var errorinfo = "omsapi_102 unable to connect MQ , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatusCode", "500");
						logger.error("omsapi_102 unable to connect MQ " + JSON.stringify(error));
						session.reject("Unable to connect MQ" + JSON.stringify(error));
					}
				} else {
					ctx.setVariable("RequestValidation", "Failed");
					var errorinfo = "omsapi_103 comment is not present in input payload : Bad Request , details are : " + info + "; error info :" + JSON.stringify(incomingdata);
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error("omsapi_103 comment is not present in input payload" + JSON.stringify(incomingdata));
					ilsctx.setVariable("errorStatusCode", '400');
					session.reject("Bad Request");
				}
			} else {
				ctx.setVariable("RequestValidation", "Failed");
				var errorinfo = "omsapi_104 id is not present in input payload : Bad Request , details are : " + info + "; error info :" + JSON.stringify(incomingdata);
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapi_104 id is not present in input payload" + JSON.stringify(incomingdata));
				ilsctx.setVariable("errorStatusCode", '400');
				session.reject("Bad Request");
			}
		} else if (asyncReplyFlag == false) {
			userId = incomingdata.userId;
			if (userId === null || userId === '' || userId === undefined) {
				CommentPayload = incomingdata.comment;
			}
			else {
				CommentPayload = userId + ':' + incomingdata.comment;
			}
			readID = incomingdata.id;
			if (URI == 'CALL') {
				backendURL = omsExternalURL + '/api/ServiceType/Electric/Call/Query?isInternalIDs=false&includeFields=notes,id';
			}
			else if (URI == 'JOB') {
				backendURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + readID + '/Comment';
				URL = URL = omsExternalURL + '/api/ServiceType/Electric/Job/' + readID + '?includeFields=id';
			} else if (URI == 'CREWASSIGNMENT') {
				backendURL = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + readID + '/Comment';
				URL = URL = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/Query?displayIDs=' + readID + '&includeFields=id';
			} else {
				ctx.setVariable("RequestValidation", "Failed");
				session.reject("Bad Request");
			}
			var obj = {};
			obj.comment = CommentPayload;
			if (URI == 'CALL') {
				var options = {
					target: backendURL,
					sslClientProfile: 'omsapi_addComments_ClientProfile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: [readID]
				};
				var payload = {
					readID
				}
				session.output.write(payload);
			}
			else {
				var options = {
					target: backendURL,
					sslClientProfile: 'omsapi_addComments_ClientProfile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
					data: obj
				};
				session.output.write(obj);
			}
			var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
			try {
				urlopen.open(options, function(error, response) {
					if (error) {
						var errorinfo = "omsapi_101 urlopen connect error with OMS API call , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatusCode", '500');
						logger.error("omsapi_101 urlopen connect error with OMS API call " + JSON.stringify(error));
						session.reject("omsapi_101 urlopen connect error with OMS API call " + JSON.stringify(error));
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									hm.response.statusCode = 500
									session.output.write(error);
								} else {
									if (responseData.length === 0) {
										ctxadd.setVariable("Statuscode", '404');
										var errorinfo = "ID not found";
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", '404');
										session.reject('Not found');
									}
									else {
										if (URI == 'CALL') {
											if (responseData[0].notes) {
												var id = responseData[0].id;
												var notes = responseData[0].notes;
												if (notes === undefined || notes === null || notes === '') {
													var patchURL = omsExternalURL + '/api/ServiceType/Electric/Call/' + id;
													var payload = currentDate + ":" + incomingdata.comment;
													var patchPayload = {
														"notes": payload
													};
													patchAPI(patchURL, patchPayload)
												}
												else {
													var delimiter = session.parameters.delimiter.replace(/\\n/g, "\n");
													var patchURL = omsExternalURL + '/api/ServiceType/Electric/Call/' + id;
													var payload = notes + delimiter + currentDate + ":" + incomingdata.comment;
													var patchPayload = {
														"notes": payload
													};
													patchAPI(patchURL, patchPayload)
												}
											}
											else {
												var id = responseData[0].id;
												var patchURL = omsExternalURL + '/api/ServiceType/Electric/Call/' + id;
												var payload = currentDate + ":" + incomingdata.comment;
												var patchPayload = {
													"notes": payload
												};
												patchAPI(patchURL, patchPayload)
											}
										}
									}
								}
							});
						} else if (responseStatusCode == 400) {
							if (URI == 'CALL') {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										var errorinfo = "failure in reading message from oms call , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", '400');
										logger.error('failure in reading message from oms call ')
										session.reject("failure in reading message from oms call ");
									} else {
										var errorinfo = "Error code returned from oms call   " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", responseStatusCode);
										logger.error("Error code returned from oms call   " + responseStatusCode + " " + responseData);
										session.reject("Error code returned from oms call   " + responseStatusCode + " " + responseData);
									}
								});
							} else {
								var options = {
									target: URL,
									sslClientProfile: 'omsapi_client_profile',
									method: 'GET',
									contentType: 'application/json',
									headers: {
										'osiApiToken': TokenValue
									},
								};
								var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
								urlopen.open(options, function(error, response) {
									if (error) {
										session.output.write(error);
										hm.response.statusCode = 500
										var errorinfo = "urlopen connect error with OMS API call , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatusCode", "500");
										logger.error("urlopen connect error with OMS API call " + JSON.stringify(error));
										session.reject("urlopen connect error with OMS API call " + JSON.stringify(error));
									}
									else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode == 200) {
											response.readAsJSON(function(error, responseData) {
												if (error) {
													hm.response.statusCode = 500
													session.output.write(error);
													var errorinfo = "unable to read response from OMS API call , details are : " + info + "; errorresponse info :" + responseData;
													ilsctx.setVariable("errorDescription", errorinfo);
													ilsctx.setVariable("errorStatusCode", "500");
													logger.error("unable to read response from OMS API call " + JSON.stringify(error));
													session.reject("unable to read response from OMS API call " + JSON.stringify(error));

												} else {
													//var responseObj = {};
													//var stringResponseData = responseData.toString();													
													if (responseData.length === 0) {
														ctxadd.setVariable("Statuscode", '404');
														session.reject('Not found');
													} else {
														if (URI == 'JOB') {
															var id = responseData.id;
															commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/Comment';
														} else {
															var id = responseData[0].id;
															commentURL = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + id + '/Comment';
														}
														commentAPI(commentURL, obj)
													}
												}
											});
										} else {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													//dp:reject stop the transaction and go error rule with error code and description
													var errorinfo = "failure in reading message from GetCall api , details are : " + info + "; error info :" + error;
													ilsctx.setVariable("errorDescription", errorinfo);
													ilsctx.setVariable("errorStatusCode", '500');
													logger.error('failure in reading message from GetCall api')
													session.reject("failure in reading message from GetCall api");
												} else {
													var errorinfo = "Error code returned from GetCall api  " + responseStatusCode + " , details are : " + info + "; errorresponse info :" + responseData;
													ilsctx.setVariable("errorDescription", errorinfo);
													ilsctx.setVariable("errorStatusCode", responseStatusCode);
													logger.error("Error code returned from GetCall api  " + responseStatusCode + " " + responseData);
													session.reject("Error code returned from GetCall api  " + responseStatusCode + " " + responseData);
												}
											});
										}
									}
								});
							}
						}
						else {
							response.readAsBuffer(function(error, ErrorresponseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "failure reading response from comments api , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error("failure reading response from comments api" + JSON.stringify(error));
									session.output.write("failure reading response from comments api");
								} else {
									var errorObj = {};
									errorObj.statusCode = response.statusCode;
									errorObj.reasonPhrase = ErrorresponseData;
									hm.response.statusCode = response.statusCode
									var errorinfo = "omsapi_100 urlopen connect error with OMS API call Response code is " + responseStatusCode + " , details are : " + info + "; errorresponseinfo :" + ErrorresponseData;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error("omsapi_100 urlopen connect error with OMS API call " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
									session.reject("urlopen connect error with OMS API call " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								}
							});

						}
					}
				});
			}
			catch (error) {
				var errorinfo = "omsapi_101 urlopen connect error with OMS API call , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatusCode", '500');
				logger.error("omsapi_101 urlopen connect error with OMS API call " + JSON.stringify(error));
				session.reject("omsapi_101 urlopen connect error with OMS API call " + JSON.stringify(error));
			}
		} else {
			ctx.setVariable("RequestValidation", "Failed");
			var errorinfo = "omsapi_107 asyncReplyFlag is not valid or not present in input payload , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", '400');
			logger.error("omsapi_107 asyncReplyFlag is not valid or not present in input payload" + JSON.stringify(incomingdata));
			session.reject("Bad Request");
		}
	}
});
function commentAPI(commentURL, obj) {
	//Performing oms call to update the comment
	session.output.write(obj);
	var commentUriapi = {
		target: commentURL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': TokenValue
		},
		data: obj
	};
	var info = " TargetURL :" + commentUriapi.target + "; Method :" + commentUriapi.method + "; Data :" + JSON.stringify(commentUriapi.data) + ". ";
	try {
		urlopen.open(commentUriapi, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with Get commentUriapi , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatusCode", '500');
				logger.error("urlopen connect error with Get commentUriapi" + JSON.stringify(error))
				session.reject("urlopen connect error with Get commentUriapi" + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message from commentUriapi , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatusCode", '500');
							logger.error('failure in reading message from commentUriapi" + JSON.stringify(error)')
							session.reject(" failure in reading message from commentUriapi" + JSON.stringify(error));
						} else {

						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description  
							var errorinfo = "failure in reading message from commentUriapi api , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatusCode", '500');
							logger.error("failure in reading message from commentUriapi api");
							session.reject("failure in reading message from commentUriapi api");
						} else {
							var errorinfo = "Error code returned from commentUriapi api  " + responseStatusCode + " , details are : " + info + "; errorresponseinfo :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							logger.error("Error code returned from commentUriapi api  " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from commentUriapi api  " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "urlopen connect error with Get commentUriapi , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		ilsctx.setVariable("errorStatusCode", '500');
		logger.error("urlopen connect error with Get commentUriapi" + JSON.stringify(error))
		session.reject("urlopen connect error with Get commentUriapi" + JSON.stringify(error));
	}
}
function patchAPI(patchURL, obj) {
	//Performing oms call to update the notes
	session.output.write(obj);
	var patchUriapi = {
		target: patchURL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': TokenValue
		},
		data: obj
	};
	var info = " TargetURL :" + patchUriapi.target + "; Method :" + patchUriapi.method + "; Data :" + JSON.stringify(patchUriapi.data) + ". ";
	try {
		urlopen.open(patchUriapi, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with patchUriapi , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatusCode", '500');
				logger.error("urlopen connect error with patchUriapi" + JSON.stringify(error))
				session.reject("urlopen connect error with patchUriapi" + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message from patchUriapi , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatusCode", '500');
							logger.error('failure in reading message from patchUriapi" + JSON.stringify(error)')
							session.reject(" failure in reading message from patchUriapi" + JSON.stringify(error));
						} else {
							
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description  
							var errorinfo = "failure in reading message from patchUriapi api , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							logger.error("failure in reading message from patchUriapi api");
							session.reject("failure in reading message from patchUriapi api");
						} else {
							var errorinfo = "Error code returned from patchUriapi api  " + responseStatusCode + " , details are : " + info + "; responsedatainfo :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							logger.error("Error code returned from patchUriapi api  " + responseStatusCode + " " + responseData);
							session.reject("Error code returned from patchUriapi api  " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "urlopen connect error with Get patchUriapi , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		ilsctx.setVariable("errorStatusCode", '500');
		logger.error("urlopen connect error with patchUriapi" + JSON.stringify(error))
		session.reject("urlopen connect error with patchUriapi" + JSON.stringify(error));
	}
}
function DateConversion(incomingDateTime) {
    const date = new Date(incomingDateTime);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
    return formattedDate;
}
