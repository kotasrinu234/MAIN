var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.addCommentEntryDescription;
var exitDescription = session.parameters.addCommentExitDescription;
var messageType = session.parameters.messageType;
var jobDetailCount = session.parameters.getImageJobDetailCount;
var apiName = session.parameters.addCommentApiName;
ctx.setVariable('apiName', apiName);
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.messageID) {
			if (incomingdata.messageID !== undefined || incomingdata.messageID !== null || incomingdata.messageID !== '') {
				ctx.setVariable("correlationID", incomingdata.messageID);
			}
		}
		else {
			ctx.setVariable("correlationID", uuidv4());
		}
		if (incomingdata.id) {
			if (incomingdata.id !== undefined || incomingdata.id !== null || incomingdata.id !== '') {
				var id = incomingdata.id;
				if (id.length == jobDetailCount) {
					ctx.setVariable("jobID", id)

				}
				else {
					ctx.setVariable("jobDisplayID", id)
				}
			}
		}
		if (incomingdata.userId) {
			if (incomingdata.userId !== undefined || incomingdata.userId !== null || incomingdata.userId !== '') {
				ctx.setVariable("userID", incomingdata.userId);
			}
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString());
	}
});
