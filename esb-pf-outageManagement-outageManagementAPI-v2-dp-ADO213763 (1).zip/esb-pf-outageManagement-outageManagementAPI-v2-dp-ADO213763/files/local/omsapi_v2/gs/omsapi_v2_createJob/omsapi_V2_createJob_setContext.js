var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
		//set stylesheet parameters to variable
		var omsExternalURL = session.parameters.omsExternalURL;
		var apiToken = session.parameters.apiToken ;
		var lookupURL =session.parameters.lookUpURL;
		var apiToken_chatbot=session.parameters.apiToken_chatbot;
		var apiToken_maximo=session.parameters.apiToken_maximo;
		var apiToken_reporting=session.parameters.apiToken_reporting;
		var apiToken_Abnormal_Voltage=session.parameters.apiToken_Abnormal_Voltage;
		
		//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js
		ctx.setVariable("omsExternalURL", omsExternalURL);
		ctx.setVariable("apiToken", apiToken);
		ctx.setVariable("lookupURL",lookupURL);
		ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
		ctx.setVariable("apiToken_maximo", apiToken_maximo);
		ctx.setVariable("apiToken_reporting", apiToken_reporting);
		ctx.setVariable("apiToken_Abnormal_Voltage", apiToken_Abnormal_Voltage);
		
		var circuit = incomingdata.circuit;
		if(circuit === undefined || circuit === null ||circuit === '' ){
			  logger.debug("circuit not found");
            }
			else{
				var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
				ctx.setVariable("circuit", circuit);
			}
		
		var networkModel = incomingdata.networkModel;
		if(networkModel === undefined || networkModel === null ||networkModel === '' ){
			  logger.debug("networkModel not found");
          } else {
				var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
				ctx.setVariable("networkModel", networkModel);
			}
		
		var address = incomingdata.address;
		if(address === undefined || address === null ||address === '' ){
			  logger.debug("address not found");
           }
			else{
				ctx.setVariable("address", address);
			}
		
		
		var substation = incomingdata.substation;
		if(substation === undefined || substation === null ||substation === '' ){
			logger.debug("substation not found");
           }
			else{
				ctx.setVariable("substation", substation);
			}
		
		var longitude = incomingdata.longitude;
		if(longitude === undefined || longitude === null ||longitude === '' ){
			  logger.debug("longitude not found");
              }
			else{
				ctx.setVariable("longitude", longitude);
			}
		
		var latitude = incomingdata.latitude;
		if(latitude === undefined || latitude === null ||latitude === '' ){
			  logger.debug("latitude not found");
           }
			else{
				ctx.setVariable("latitude", latitude);
			}
		
		var aors = incomingdata.aors;
    	var jobType = incomingdata.jobType;
    	var jobSubType = incomingdata.jobSubType;
   
		if(aors === undefined || aors === null ||aors === '' ){
			logger.debug("aors not found");
           }
			else{
				ctx.setVariable("aors", aors);
			}
		
		if(jobType === undefined || jobType === null ||jobType === '' ){
			  session.reject("jobType not found");
			  logger.error("omsapiv2_140:jobType not found");
            }
			else{
				ctx.setVariable("jobType", jobType);
			}
		
		if(jobSubType === undefined || jobSubType === null ||jobSubType === '' ){
			  logger.debug("jobSubType not found");
           }
			else{
				ctx.setVariable("jobSubType", jobSubType);
			}
		
		//var jobComments = incomingdata.jobComments;
		
		//var jobComments = incomingdata.jobComments.comment;
		
		/* for (var i = 0; i < jobComments.length; i++) {
			 var comments = incomingdata.jobComments[i].comment; 
			 
			 var comm = {
                     "comment": commentsArr[i].comment,
                     "timestamp": commentsArr[i].updatedAt
                 }
			 commentArray.push(comm);
			 
			 if(comments === undefined || comments === null ||comments === '' ){
				  logger.debug("jobComments not found");
		         }
				else{
					
					ctx.setVariable("comments", comments);
				}
		 }*/
		 
		 var commentArray = [];
		 var jobComments = incomingdata.jobComments;
		 for (var i = 0; i < jobComments.length; i++) {
             //var deprecated = commentsArr[i].deprecated;
             var comm = {
                 "comment": jobComments[i].comment,
                 //"timestamp": commentsArr[i].updatedAt
             }
            /* if (deprecated == false) {
                 commentArray.push(comm);
             }*/
             commentArray.push(comm);
         }
         ctx.setVariable('commentsArr', commentArray);
		
		
   }
});
