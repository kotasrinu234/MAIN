var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");
//var apiToken= ctx.getVar("apiToken");
var lookupURL = ctx.getVar("lookupURL");
var aorID = ctx.getVar("aorIDArray");
var jobTypeID = ctx.getVar("idfromJobType");
var jobSubType = ctx.getVar("jobSubType");
var circuit = ctx.getVar("circuit");
var networkModel = ctx.getVar("networkModel");
var address = ctx.getVar("address");
var substation = ctx.getVar("substation");
var longitude = ctx.getVar("longitude");
var latitude = ctx.getVar("latitude");
var jobComments = ctx.getVar("commentsArr");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var apiToken_Abnormal_Voltage = ctx.getVar("apiToken_Abnormal_Voltage");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		session.reject("Error in reading incoming data")
	} else {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		var incomingUser = currentUser;

		var apiToken;
		if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
			apiToken = apiToken_OutageStatusApp;
		} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
			apiToken = apiToken_chatbot;
		} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
			apiToken = apiToken_reportingApp;
		} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
			apiToken = apiToken_maximo;
		} else if (incomingUser == 'dcas-abnv-esb-dev' || incomingUser == 'dcas-abnv-esb-tst' || incomingUser == 'dcas-abnv-esb-prd') {
			apiToken = apiToken_Abnormal_Voltage;
		}
		//POST /api/v1/ServiceType/Electric/Job
		var createJobAPIUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job';
		var payload;
		if ((longitude === undefined || longitude === null || longitude === '') && (latitude === undefined || latitude === null || latitude === '') && (jobComments === undefined || jobComments === null || jobComments === '')) {
			payload = {
				"nominalFeeder": circuit,
				"address": address,
				"aorIDs": aorID,
				"substation": substation,
				"jobTypeID": jobTypeID,
				"outageSubtypeID": jobSubType
			}
		} else if (jobComments === undefined || jobComments === null || jobComments === '') {
			payload = {
				"nominalFeeder": circuit,
				"address": address,
				"aorIDs": aorID,
				"substation": substation,
				"jobTypeID": jobTypeID,
				"outageSubtypeID": jobSubType
			}
		} else {
			payload = {
				"nominalFeeder": circuit,
				"networkModelExternalID": networkModel,
				"address": address,
				"aorIDs": aorID,
				"location": {
					"coordinates": [
						longitude,
						latitude
					],
					"type": "POINT"
				},
				"substation": substation,
				"jobTypeID": jobTypeID,
				"outageSubtypeID": jobSubType,
				"commentAdds":
					jobComments



			}
		}
		var createJobAPI = {
			target: createJobAPIUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'POST',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
			data: payload
		};
		var info = " TargetURL :" + createJobAPI.target + "; Method :" + createJobAPI.method + "; Data :" + JSON.stringify(createJobAPI.data) + ". ";
		try {
			urlopen.open(createJobAPI, function(error, response) {
				if (error) {
					var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
					var errorinfo = "omsapiv2_142:urlopen connect error with createJobAPI, details are : " + info + "; error info :" + error;
					ctx.setVariable("errorDescription", errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_142:urlopen connect error with createJobAPI" + JSON.stringify(error));
					session.reject("urlopen connect error with createJobAPI");
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								var errorinfo = "failure in putting message to createJobAPI, details are : " + info + "; error info :" + error;
								ctx.setVariable("errorDescription", errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("failure in putting message to createJobAPI" + JSON.stringify(error));
								session.reject("failure in putting message to createJobAPI");
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from createJobAPI for JobId:" + "" + responseStatusCode);
								var createJobAPIResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								var displayId = createJobAPIResponse.displayID;
								ctx.setVariable("displayId", displayId);
								ctx.setVariable("createJobAPIResponse", createJobAPIResponse);
								ctx.setVariable("createJobAPIResponseStatusCode", responseStatusCode);

							}
						});
					} else {
						var ctx = session.name("omsApiv_2") || session.createContext("omsApiv_2");
						ctx.setVariable('responseStatusCode', responseStatusCode);
						ctx.setVariable('responsePhrase', responsePhrase);
						//session.reject("Bad response received from oms");
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								var errorinfo = "failure in reading message from createJobAPI for negative ack , details are : " + info + "; error info :" + error;
								ctx.setVariable("errorDescription", errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("failure in reading message from createJobAPI for negative ack " + JSON.stringify(error));
								session.reject("failure in reading message from createJobAPI for negative ack ");
							} else {
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								var errorinfo = "response received from createJobAPI for negative ack , details are : " + info + "; response info :" + responseData + responseStatusCode;
								ctx.setVariable("errorDescription", errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("response received from createJobAPI for negative ack " + " " + responseStatusCode);
								session.reject("response received from createJobAPI for negative ack " + " " + responseStatusCode);
							}
						});
					}
				} //1st api call end
			});
		} catch (error) {
			var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
			var errorinfo = "omsapiv2_142:urlopen connect error with createJobAPI, details are : " + info + "; error info :" + error;
			ctx.setVariable("errorDescription", errorinfo);
			ctx.setVariable("errorStatusCode", error.errorCode);
			ctx.setVariable("errorMessage", error.errorMessage);
			logger.error("omsapiv2_142:urlopen connect error with createJobAPI" + JSON.stringify(errorinfo));
			session.reject("urlopen connect error with createJobAPI");
		}
	}
});
