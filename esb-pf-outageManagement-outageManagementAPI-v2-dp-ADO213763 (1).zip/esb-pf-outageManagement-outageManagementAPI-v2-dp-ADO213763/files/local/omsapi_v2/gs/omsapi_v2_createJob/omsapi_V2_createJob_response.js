var logger = console.options({
'category': 'all'
});

var json={};
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");

if(ctx.getVariable("displayId") !=null || ctx.getVariable("displayId") !='' || ctx.getVariable("displayId") != undefined){ 
	json.jobId=ctx.getVariable("displayId");
}else {
	json.jobId='';
}
session.output.write(json);