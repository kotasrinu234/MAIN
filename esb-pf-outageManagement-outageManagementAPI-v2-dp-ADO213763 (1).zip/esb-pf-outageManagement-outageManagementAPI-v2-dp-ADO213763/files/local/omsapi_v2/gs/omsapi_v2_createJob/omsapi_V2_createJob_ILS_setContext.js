var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.jobCreateEntryDescription;
var exitDescription = session.parameters.jobCreateExitDescription;
var messageType = session.parameters.messageType;
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var apiName = session.parameters.jobCreateApiName;
if (apiName !== undefined || apiName !== null || apiName !== '') {
	ctx.setVariable("apiName", apiName);
}
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.messageID) {
			if (incomingdata.messageID !== undefined || incomingdata.messageID !== null || incomingdata.messageID !== '') {
				ctx.setVariable("correlationID", incomingdata.messageID)
			}
		}
		if (incomingdata.jobType) {
			if (incomingdata.jobType !== undefined || incomingdata.jobType !== null || incomingdata.jobType !== '') {
				ctx.setVariable("jobType", incomingdata.jobType)
			}
		}
		if (incomingdata.jobSubType) {
			if (incomingdata.jobSubType !== undefined || incomingdata.jobSubType !== null || incomingdata.jobSubType !== '') {
				ctx.setVariable("jobSubType", incomingdata.jobSubType)
			}
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
	}
});
