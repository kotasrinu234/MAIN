var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");
var apiToken = ctx.getVar("apiToken");
var lookupURL = ctx.getVar("lookupURL");
var aors = ctx.getVar("aors");
var jobType = ctx.getVar("jobType");
var jobSubType = ctx.getVar("jobSubType");
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		session.reject("Error in reading incoming data")
	} else {

		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");

		if (aors == '' || aors == undefined) {
			logger.debug("aors element is not found from incoming request");
		} else {
			//aor lookup start 
			var aorIDArray = [];
			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "aors",
							"label": aors
						}
					]
				}
			}
			var aorLookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + aorLookupServiceResponse.target + "; Method :" + aorLookupServiceResponse.method + "; Data :" + JSON.stringify(aorLookupServiceResponse.data) + ". ";
			//aor lookup url open start
			try {
				urlopen.open(aorLookupServiceResponse, function(error, response) {
					if (error) {
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
						var errorinfo = "omsapiv2_141:urlopen connect error with aorLookupServiceResponse, details are : " + info + "; error info :" + error
						ctx.setVariable("errorDescription", errorinfo);
						logger.error("omsapiv2_141:urlopen connect error with aorLookupServiceResponse" + JSON.stringify(errorinfo));
						session.reject("urlopen connect error with aorLookupServiceResponse");
						//throw error;
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									var errorinfo = "failure in putting message to  aorLookupServiceResponse, details are : " + info + "; error info :" + error
									ctx.setVariable("errorDescription", errorinfo);
									ctx.setVariable("errorStatusCode", responseStatusCode);
									ctx.setVariable("errorMessage", responsePhrase);
									logger.error("failure in putting message to  aorLookupServiceResponse" + JSON.stringify(error));
									session.reject("failure in putting message to  aorLookupServiceResponse");
								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from  aorLookupServiceResponse " + responseData);
									var aorLookupServiceResponse = JSON.parse(responseData)
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("aorLookupServiceResponse", aorLookupServiceResponse);
									logger.debug("aorLookupServiceResponse----" + JSON.stringify(aorLookupServiceResponse));
									var Id;
									if (aorLookupServiceResponse.lookupRep.type[0].result == 0) {
										//logger.error("Inside if crew---------- ");
										Id = aorLookupServiceResponse.lookupRep.type[0].id;
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										aorIDArray.push(Id);
										ctx.setVariable("aorIDArray", aorIDArray);
									} else {
										logger.error("Id is not found from aorLookupServiceResponse");
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										ctx.setVariable("aorIDArray", aorIDArray);
									}
								}
							});
						} else {
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							var errorinfo = "aorLookupServiceResponse is not 200, details are : " + info + "; error info :" + error
							ctx.setVariable("errorDescription", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							logger.error("aorLookupServiceResponse is not 200");
						}
					}
				});
			}
			catch (error) {
				var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
				var errorinfo = "omsapiv2_141:urlopen connect error with aorLookupServiceResponse, details are : " + info + "; error info :" + error
				ctx.setVariable("errorDescription", errorinfo);
				ctx.setVariable("errorStatusCode", error.errorCode);
				ctx.setVariable("errorMessage", error.errorMessage);
				logger.error("omsapiv2_141:urlopen connect error with aorLookupServiceResponse" + JSON.stringify(errorinfo));
				session.reject("urlopen connect error with aorLookupServiceResponse");
			}

			//aor lookup end 	
		}


		if (jobType == '' || jobType == undefined) {
			logger.debug("jobType element is not found from incoming request");
		} else {
			//Start: JobTypeLookup 
			var jobTypeLookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "jobTypes",
							"label": jobType
						}
					]
				}
			}
			var jobTypeLookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: jobTypeLookupMessage
			};
			var info = " TargetURL :" + jobTypeLookupServiceResponse.target + "; Method :" + jobTypeLookupServiceResponse.method + "; Data :" + JSON.stringify(jobTypeLookupServiceResponse.data) + ". ";
			try {
				urlopen.open(jobTypeLookupServiceResponse, function(error, response) {
					if (error) {
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
						var errorinfo = "urlopen connect error with jobTypeLookup, details are : " + info + "; error info :" + error
						ctx.setVariable("errorDescription", errorinfo);
						logger.error("urlopen connect error with jobTypeLookup" + JSON.stringify(errorinfo));
						session.reject("urlopen connect error with jobTypeLookup");
					} else {
						var responseStatusCode = response.statusCode;
						var responsePhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									var errorinfo = "failure in putting message to jobTypeLookupService, details are : " + info + "; error info :" + error
									ctx.setVariable("errorDescription", errorinfo);
									ctx.setVariable("errorStatusCode", responseStatusCode);
									ctx.setVariable("errorMessage", responsePhrase);
									logger.error("failure in putting message to jobTypeLookupService" + JSON.stringify(errorinfo));
									session.reject("failure in putting message to jobTypeLookupService");
								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from jobTypeLookupServiceResponse:" + responseStatusCode);
									var jobTypeLookupServiceResponse = JSON.parse(responseData);
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									//ctx.setVariable("jobTypeLookupServiceResponse", jobTypeLookupServiceResponse);
									//var label ;

									var id;
									if (jobTypeLookupServiceResponse.lookupRep.type[0].result == 0) {
										id = jobTypeLookupServiceResponse.lookupRep.type[0].id;
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										ctx.setVariable("idfromJobType", id);
									} else {
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										ctx.setVariable("idfromJobType", '');
										logger.error("id is not found from jobTypeLookupServiceResponse");
									}
								}
							});
						} else {
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							var errorinfo = "Unable to find the id details in jobTypeLookupServiceResponse call, details are : " + info + "; error info :" + error + responseStatusCode;
							ctx.setVariable("errorDescription", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							logger.error("Unable to find the id details in jobTypeLookupServiceResponse call" + " " + responseStatusCode);
						}
					}
				});
			}
			catch (error) {
				var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
				var errorinfo = "urlopen connect error with jobTypeLookup, details are : " + info + "; error info :" + error
				ctx.setVariable("errorDescription", errorinfo);
				ctx.setVariable("errorStatusCode", error.errorCode);
				ctx.setVariable("errorMessage", error.errorMessage);
				logger.error("urlopen connect error with jobTypeLookup" + JSON.stringify(errorinfo));
				session.reject("urlopen connect error with jobTypeLookup");
			}

			//End : JobTypeLookup	
		}


		if (jobSubType == '' || jobSubType == undefined) {
			logger.debug("jobSubType element is not found from incoming request");
		} else {
			//Start: JobSubTypeLookup :OutageSubType Lookup Start :Do a lookup using outageSubTypes and get "externalID".
			var outageSubTypeLookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "outageSubtypes",
							"label": jobSubType
						}
					]
				}
			}

			var outageSubTypeLookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: outageSubTypeLookupMessage
			};
			var info = " TargetURL :" + outageSubTypeLookupServiceResponse.target + "; Method :" + outageSubTypeLookupServiceResponse.method + "; Data :" + JSON.stringify(outageSubTypeLookupServiceResponse.data) + ". ";
			var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
			ctx.setVariable("outageSubTypeLookupRequest", outageSubTypeLookupMessage);
			try {
				urlopen.open(outageSubTypeLookupServiceResponse, function(error, response) {
					if (error) {
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
						var errorinfo = "urlopen connect error with outageSubTypeLookup, details are : " + info + "; error info :" + error;
						ctx.setVariable("errorDescription", errorinfo);
						logger.error("urlopen connect error with outageSubTypeLookup" + JSON.stringify(error));
						session.reject("urlopen connect error with outageSubTypeLookup");
					} else {
						var responseStatusCode = response.statusCode;
						var responsePhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									var errorinfo = "failure in putting message to outageSubTypeLookupServiceResponse, details are : " + info + "; error info :" + error + responseData;
									ctx.setVariable("errorDescription", errorinfo);
									ctx.setVariable("errorStatusCode", responseStatusCode);
									ctx.setVariable("errorMessage", responsePhrase);
									logger.error("failure in putting message to outageSubTypeLookupServiceResponse" + JSON.stringify(error));
									session.reject("failure in putting message to outageSubTypeLookupServiceResponse");
								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from outageSubTypeLookupServiceResponse:" + responseStatusCode);
									var outageSubTypeLookupServiceResponse = JSON.parse(responseData);
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("outageSubTypeLookupServiceResponse", outageSubTypeLookupServiceResponse);
									var id;
									if (outageSubTypeLookupServiceResponse.lookupRep.type[0].result == 0) {
										id = outageSubTypeLookupServiceResponse.lookupRep.type[0].id;
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										ctx.setVariable("jobSubType", id);
									} else {
										var id = '';
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										ctx.setVariable("jobSubType", id);
										logger.error("label is not found from outageSubTypeLookupServiceResponse");
									}
								}
							});
						} else {
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							var errorinfo = "Unable to find the label details in outageSubTypeLookupServiceResponse call, details are : " + info + "; error info :" + error;
							ctx.setVariable("errorDescription", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							logger.error("Unable to find the label details in outageSubTypeLookupServiceResponse call" + " " + responseStatusCode);
						}
					}
				});
			} catch (error) {
				var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
				var errorinfo = "urlopen connect error with outageSubTypeLookup, details are : " + info + "; error info :" + error;
				ctx.setVariable("errorDescription", errorinfo);
				ctx.setVariable("errorStatusCode", error.errorCode);
				ctx.setVariable("errorMessage", error.errorMessage);
				logger.error("urlopen connect error with outageSubTypeLookup" + JSON.stringify(error));
				session.reject("urlopen connect error with outageSubTypeLookup");
			}
			//End : JobTypeLookup			
		}

	}
});
