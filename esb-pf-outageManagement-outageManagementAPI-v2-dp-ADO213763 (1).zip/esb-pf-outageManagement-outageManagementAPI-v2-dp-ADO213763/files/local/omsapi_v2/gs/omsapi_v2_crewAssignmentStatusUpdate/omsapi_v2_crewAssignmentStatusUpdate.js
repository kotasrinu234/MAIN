var urlopen = require('urlopen');
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var crewErrorDescription = ctx.getVariable("crewErrorDescription");
var JobErrorDescription = ctx.getVariable("JobErrorDescription");
var Description = ctx.getVariable("ErrorDescription");
var crewId = ctx.getVariable("crewId");
var lookupURL = ctx.getVariable("lookupURL");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var disposition_check = ctx.getVar("disposition_check");
var Disposition = ctx.getVar("Disposition");
var Disposition_new = ctx.getVar("Disposition_new");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var logger = console.options({
	'category': 'all'
});
var incomingUser = currentUser;
var apiToken;

if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;
	logger.debug("inside OutageAPP----" + apiToken);
} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;
	logger.debug("inside chatbotAPP----" + apiToken);
} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;
	logger.debug("inside reportAPP----" + apiToken);
} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;
	logger.debug("inside maximoAPP----" + apiToken);
} else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}

function urlOpenAsync(options) {
	return new Promise((resolve, reject) => {
		urlopen.open(options, function(error, response) {
			if (error) {
				reject(error);
			} else {
				resolve(response);
			}
		});
	});
}

function readAsBufferAsync(response) {
	return new Promise((resolve, reject) => {
		response.readAsBuffer(function(error, data) {
			if (error) {
				reject(error);
			} else {
				resolve(data);
			}
		});
	});
}

function readAsJSONAsync(response) {
	return new Promise((resolve, reject) => {
		response.readAsJSON(function(error, data) {
			if (error) {
				reject(error);
			} else {
				resolve(data);
			}
		});
	});
}

session.input.readAsJSON(async function(error, json) {
	if (error) {
		// an error occurred when parsing the content, e.g. invalid JSON object
		var errorinfo = "Error in reading incoming data";
		ilsctx.setVariable("errorDescription", errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
		logger.error("omsapiv2_088:Error in reading incoming data");
		session.reject("omsapiv2_088:Error in reading incoming data");
	} else {
		try {
			var jobId = json.jobId;
			var msgId = json.msgId;
			ctx.setVariable("msgId", msgId);
			var crewAssignmentStatus = json.crewAssignmentStatus;
			var latitude = json.latitude;
			var longitude = json.longitude;
			var comments = json.comments;
			var eta = json.eta;
			var eta_check;
			var check_longitude;
			var check_latitude;
			var check;
			var comment_check;

			// Check longitude
			if (longitude == null || longitude == undefined || longitude == '') {
				check_longitude = 'True';
			} else {
				check_longitude = 'False';
			}

			// Check ETA
			if (eta == null || eta == undefined || eta == '') {
				eta_check = 'True';
			} else {
				ctx.setVariable("eta", eta);
				eta_check = 'False';
			}

			// Check latitude
			if (latitude == null || latitude == undefined || latitude == '') {
				check_latitude = 'True';
			} else {
				check_latitude = 'False';
			}

			// Check comments
			if (comments == null || comments == undefined || comments == '') {
				comment_check = 'True';
			} else {
				comment_check = 'False'
			}

			// Determine if coordinates are missing
			if (check_longitude == 'True' || check_latitude == 'True') {
				check = 'True';
			} else {
				check = 'False';
			}

			// Call main processing function
			await processCrewAssignment(crewAssignmentStatus, jobId, latitude, longitude, comments, eta, eta_check, check, comment_check);

		} catch (error) {
			var errorinfo = "Error processing crew assignment: " + error;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			logger.error("omsapiv2_088:" + errorinfo);
			session.reject(errorinfo);
		}
	}
});

// ===== MAIN CREW ASSIGNMENT PROCESSING FUNCTION =====

async function processCrewAssignment(crewAssignmentStatus, jobId, latitude, longitude, comments, eta, eta_check, check, comment_check) {
	try {
		// Performing oms call for getting Crew using CrewID
		var CrewUri = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + crewId;
		var TokenValue = apiToken;
		var CrewGetApi = {
			target: CrewUri,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},
		};
		var info = " TargetURL :" + CrewGetApi.target + "; Method :" + CrewGetApi.method + ". ";

		// Fetch crew data
		var response = await urlOpenAsync(CrewGetApi);
		var responseStatusCode = response.statusCode;

		if (responseStatusCode == 200) {
			var responseData = await readAsBufferAsync(response);

			// Performing oms call for getting job using jobID
			var jobIdUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobId;
			var GetJobApi = {
				target: jobIdUri,
				sslClientProfile: 'omsapi_client_profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
			}
			info = " TargetURL :" + GetJobApi.target + "; Method :" + GetJobApi.method + ". ";

			// Fetch job data
			var jobResponse = await urlOpenAsync(GetJobApi);
			var jobResponseStatusCode = jobResponse.statusCode;

			if (jobResponseStatusCode == 200) {
				var JobresponseData = await readAsBufferAsync(jobResponse);
				var id = JSON.parse(JobresponseData).id;
				var CrewAssignmentUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/CrewAssignment' + '?excludeResolved=true';
				var CrewAssignmentapi = {
					target: CrewAssignmentUri,
					sslClientProfile: 'omsapi_client_profile',
					method: 'GET',
					contentType: 'application/json',
					headers: {
						'osiApiToken': TokenValue
					},
				};
				info = " TargetURL :" + CrewAssignmentapi.target + "; Method :" + CrewAssignmentapi.method + ". ";

				// Fetch crew assignment data
				var crewAssignmentResponse = await urlOpenAsync(CrewAssignmentapi);
				var crewAssignmentStatusCode = crewAssignmentResponse.statusCode;

				if (crewAssignmentStatusCode == 200) {
					var CrewresponseData = await readAsBufferAsync(crewAssignmentResponse);
					var crewAssignmentLength = JSON.parse(CrewresponseData).data.length;
					logger.debug("crewAssignmentLength: " + crewAssignmentLength);
					var flag = 'True';

					// Process each crew assignment
					for (var i = 0; i < crewAssignmentLength; i++) {
						var data = JSON.parse(CrewresponseData).data[i];
						var workflow_id = JSON.parse(CrewresponseData).data[i].id;
						var workTypeID = JSON.parse(CrewresponseData).data[i].workTypeID;
						var Crew_status = JSON.parse(CrewresponseData).data[i].status;
						logger.debug("crew: " + JSON.stringify(data));
						var crew = data.crew;

						if (crew == '' || crew == undefined || crew == null) {
							// Crew assignment is not found
						} else {
							var crewAssignment = crew.externalID;
							if (crewAssignment == crewId) {
								// ===== EXECUTE PATCH OPERATIONS WITH FLOW CONTROL =====
								// Wait for ETA PATCH to complete (success or fail)
								if (eta_check == 'False') {
									var URL = omsExternalURL + '/api/ServiceType/Electric/CrewAssignment/' + workflow_id;
									var etaPatchResult = await etaPatchAPI(URL, eta);
									
									// If ETA PATCH failed, terminate the process with error
									if (!etaPatchResult.success) {
										logger.error("etaPatchAPI failed - Terminating process. Error: " + etaPatchResult.error + ", Status Code: " + etaPatchResult.statusCode);
										session.reject("etaPatchAPI failed - Terminating process. Error: " + etaPatchResult.error + ", Status Code: " + etaPatchResult.statusCode);
										// Error already set by etaPatchAPI, just return to terminate
										return; // Exit early, error already set by etaPatchAPI
									}
									logger.info("etaPatchAPI completed successfully, proceeding to CustomFieldValues");
								}

								// Wait for Disposition/CustomFieldValues PATCH to complete (success or fail)
								if (disposition_check == 'False') {
									var customFieldResult = await CustomFieldValues(workflow_id);
									
									// If CustomFieldValues PATCH failed, terminate the process with error
									if (!customFieldResult.success) {
										logger.error("CustomFieldValues failed - Terminating process. Error: " + customFieldResult.error + ", Status Code: " + customFieldResult.statusCode);
										session.reject("CustomFieldValues failed - Terminating process. Error: " + customFieldResult.error + ", Status Code: " + customFieldResult.statusCode);
										// Error already set by CustomFieldValues, just return to terminate
										return; // Exit early, error already set by CustomFieldValues
									}
									logger.info("CustomFieldValues completed successfully, proceeding to Lookup");
								}

								flag = 'True';

								// ===== PROCEED TO WORKFLOW PROCESSING ONLY AFTER PATCH OPERATIONS SUCCEED =====
								// All PATCH operations completed successfully, now proceed with Lookup operations
								await LookupStatusresponse(crewAssignmentStatus, crewAssignment, workflow_id, id, workTypeID, Crew_status, longitude, latitude, comments, check, comment_check);
							}
						}
					}

					// Check if crew was found and processed
					if (flag != 'True') {
						logger.error("omsapiv2_116:CrewID is not assigned");
						ctx.setVariable("notFound", 'True');
						ilsctx.setVar('errorDescription', "CrewID is not assigned");
						ilsctx.setVariable("errorStatusCode", "404");
						ctx.setVariable("responseStatusCode", '404');
						ctx.setVariable("error", '404');
						ctx.setVariable("errorDescription", Description);
						session.reject(Description);
					}
				} else {
					var errorData = await readAsBufferAsync(crewAssignmentResponse);
					var errorinfo = "Error code returned from CrewAssignmentapi api for jobId: " + id + " statusCode " + crewAssignmentStatusCode + " " + errorData;
					ilsctx.setVar('errorDescription', errorinfo);
					ilsctx.setVariable("errorStatusCode", crewAssignmentStatusCode);
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			} else if (jobResponseStatusCode === 404) {
				ctx.setVariable("notFound", 'True');
				logger.error("omsapiv2_118:Job Not found.");
				ctx.setVariable("error", '404');
				ilsctx.setVar('errorDescription', "Job Not found.");
				ilsctx.setVariable("errorStatusCode", "404");
				ctx.setVariable("responseStatusCode", jobResponseStatusCode);
				ctx.setVariable("errorDescription", JobErrorDescription);
				session.reject(JobErrorDescription);
			} else {
				var errorData = await readAsBufferAsync(jobResponse);
				var errorinfo = "Error code returned from GetJobApi api for jobId: " + jobId + " statusCode " + jobResponseStatusCode + " " + errorData;
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", jobResponseStatusCode);
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		} else if (responseStatusCode == 404) {
			ctx.setVariable("responseStatusCode", responseStatusCode);
			logger.error("omsapiv2_119:Crew Not found.");
			ilsctx.setVar('errorDescription', "Crew Not found.");
			ilsctx.setVariable("errorStatusCode", "404");
			ctx.setVariable("error", '404');
			ctx.setVariable("notFound", 'True');
			ctx.setVariable("errorDescription", crewErrorDescription);
			session.reject(crewErrorDescription);
		} else {
			var errorData = await readAsBufferAsync(response);
			var errorinfo = "Error code returned from CrewGetApi api for crewId: " + crewId + " statusCode " + responseStatusCode + " " + errorData;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", responseStatusCode);
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	} catch (error) {
		var errorinfo = "urlopen connect error with Get CrewGetApi for crewId: " + error;
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
		logger.error("omsapiv2_089:" + errorinfo);
		session.reject(errorinfo);
	}
}

// ===== LOOKUP STATUS RESPONSE FUNCTION =====

async function LookupStatusresponse(crewAssignmentStatus, crewAssignment, workflow_id, id, workTypeID, Crew_status, longitude, latitude, comments, check, comment_check) {
	var lookupMessage = {
		"lookupReq": {
			"type": [{
				"name": "workType.workflows",
				"id": workTypeID,
				"status": Crew_status
			}]
		}
	}
	var LookupServiceResponse = {
		target: lookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: lookupMessage
	};
	var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

	try {
		var response = await urlOpenAsync(LookupServiceResponse);
		var responseStatusCode = response.statusCode;
		logger.debug("response: " + response);

		if (responseStatusCode == 200) {
			var responseData = await readAsJSONAsync(response);

			if (responseData.lookupRep.type[0].result == 0) {
				var label = responseData.lookupRep.type[0].label;
				ctx.setVariable("label", label);
				await LookupResponse(workTypeID, crewAssignmentStatus, workflow_id, id, longitude, latitude, comments, check, comment_check, Crew_status);
			} else {
				ilsctx.setVar('errorDescription', "lookup result is not 0");
				ilsctx.setVariable("errorStatusCode", "400");
				logger.error("omsapiv2_114:lookup result is not 0");
				session.reject("omsapiv2_114:lookup result is not 0");
			}
		} else {
			var errorData = await readAsBufferAsync(response);
			var errorinfo = "lookup response statusCode " + responseStatusCode + " " + errorData;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", responseStatusCode);
			logger.error("omsapiv2_115:" + errorinfo);
			session.reject("omsapiv2_115:" + errorinfo);
		}
	} catch (error) {
		var errorinfo = "urlopen connect error with LookupServiceResponse: " + error;
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
		logger.error("omsapiv2_098:" + errorinfo);
		session.reject(errorinfo);
	}
}

// ===== LOOKUP RESPONSE FUNCTION =====

async function LookupResponse(workTypeID, crewAssignmentStatus, workflow_id, id, longitude, latitude, comments, check, comment_check, Crew_status) {
	var lookupMessage = {
		"lookupReq": {
			"type": [{
				"name": "workType.workflows",
				"id": workTypeID,
				"label": crewAssignmentStatus
			}]
		}
	}
	var LookupServiceResponse = {
		target: lookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: lookupMessage
	};
	var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

	try {
		var response = await urlOpenAsync(LookupServiceResponse);
		var responseStatusCode = response.statusCode;
		logger.debug("response: " + JSON.stringify(response));

		if (responseStatusCode == 200) {
			var responseData = await readAsJSONAsync(response);

			hm.response.statusCode = responseStatusCode;
			logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));

			if (responseData.lookupRep.type[0].result == 0) {
				var status = responseData.lookupRep.type[0].status;
				if (Crew_status == status) {
					var url = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + crewId;
					var payload = {
						"location": {
							"coordinates": [
								longitude,
								latitude
							],
							"type": "POINT"
						}
					}
					await CrewPatchapiCall(url, payload, id, comments, check, comment_check, workflow_id);
					logger.debug("crew assignment status already exists.");
				} else {
					var workFlowUri = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + workflow_id + '/WorkFlow';
					await WorkflowAPI(workFlowUri, status, id, longitude, latitude, comments, check, comment_check, workflow_id);
				}
			} else {
				ilsctx.setVar('errorDescription', "lookup response result is not 0");
				ilsctx.setVariable("errorStatusCode", "400");
				logger.error("lookup response result is not 0");
				session.reject("lookup response result is not 0");
			}
		} else {
			var errorData = await readAsBufferAsync(response);
			var errorinfo = "lookup response statusCode " + responseStatusCode + " " + errorData;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", responseStatusCode);
			logger.error("omsapiv2_111:" + errorinfo);
			session.reject(errorinfo);
		}
	} catch (error) {
		var errorinfo = "urlopen connect error with LookupServiceResponse: " + error;
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
		logger.error("omsapiv2_100:" + errorinfo);
		session.reject(errorinfo);
	}
}

// ===== WORKFLOW API FUNCTION =====

async function WorkflowAPI(workFlowUri, status, id, longitude, latitude, comments, check, comment_check, workflow_id) {
	var payload = {
		"status": status
	}
	var workflowApi = {
		target: workFlowUri,
		sslClientProfile: 'omsapi_client_profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};

	var info = " TargetURL :" + workflowApi.target + "; Method :" + workflowApi.method + "; Data :" + JSON.stringify(workflowApi.data) + ". ";

	try {
		var response = await urlOpenAsync(workflowApi);
		var responseStatusCode = response.statusCode;

		if (responseStatusCode == 200) {
			var responseData = await readAsBufferAsync(response);
			var url = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + crewId;
			var payload = {
				"location": {
					"coordinates": [
						longitude,
						latitude
					],
					"type": "POINT"
				}
			}
			await CrewPatchapiCall(url, payload, id, comments, check, comment_check, workflow_id);
		} else {
			var errorData = await readAsBufferAsync(response);
			var errorinfo = "Error code returned from workflowApi api " + responseStatusCode + " " + errorData;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", responseStatusCode);
			logger.error("omsapiv2_110:" + errorinfo);
			session.reject(errorinfo);
		}
	} catch (error) {
		var errorinfo = "urlopen connect error with Get workflowApi: " + error;
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
		logger.error("omsapiv2_102:" + errorinfo);
		session.reject(errorinfo);
	}
}

// ===== CREW PATCH API CALL FUNCTION =====

async function CrewPatchapiCall(url, payload, id, comments, check, comment_check, workflow_id) {
	var CrewPatchapi = {
		target: url,
		sslClientProfile: 'omsapi_client_profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};

	if (check == 'False') {
		var info = " TargetURL :" + CrewPatchapi.target + "; Method :" + CrewPatchapi.method + "; Data :" + JSON.stringify(CrewPatchapi.data) + ". ";

		try {
			var response = await urlOpenAsync(CrewPatchapi);
			var responseStatusCode = response.statusCode;

			if (responseStatusCode == 200) {
				var responseData = await readAsBufferAsync(response);
				logger.debug("crewPatch call is Successful");
			} else {
				var errorData = await readAsBufferAsync(response);
				var errorinfo = "Error code returned from CrewPatchapi api " + responseStatusCode + " " + errorData;
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", responseStatusCode);
				logger.error("omsapiv2_109:" + errorinfo);
				session.reject(errorinfo);
			}
		} catch (error) {
			var errorinfo = "urlopen connect error with Get CrewPatchapi: " + error;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			logger.error("omsapiv2_104:" + errorinfo);
			session.reject(errorinfo);
		}
	}

	// Process comments if provided
	if (comment_check == 'False') {
		var commenturl = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + id + '/Comment';
		var commentpayload = {
			"comment": comments
		}
		await commentAPI(commenturl, commentpayload);
	}
}

// ===== COMMENT API FUNCTION =====

async function commentAPI(commenturl, payload) {
	//Performing oms call to update the comment
	var commentUriapi = {
		target: commenturl,
		sslClientProfile: 'omsapi_client_profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};
	var info = " TargetURL :" + commentUriapi.target + "; Method :" + commentUriapi.method + "; Data :" + JSON.stringify(commentUriapi.data) + ". ";

	try {
		var response = await urlOpenAsync(commentUriapi);
		var responseStatusCode = response.statusCode;

		if (responseStatusCode == 200) {
			var responseData = await readAsBufferAsync(response);
			logger.debug("commentUriapi response statusCode: " + responseStatusCode);
		} else {
			var errorData = await readAsBufferAsync(response);
			var errorinfo = "Error code returned from commentUriapi api " + responseStatusCode + " " + errorData;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", responseStatusCode);
			logger.error("omsapiv2_108:" + errorinfo);
			session.reject(errorinfo);
		}
	} catch (error) {
		var errorinfo = "urlopen connect error with Get commentUriapi: " + error;
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
		logger.error("omsapiv2_106:" + errorinfo);
		session.reject(errorinfo);
	}
}

// ===== ETA PATCH API FUNCTION WITH FLOW CONTROL AND ERROR HANDLING =====

async function etaPatchAPI(URL, eta) {
	var payload = {
		'eta': eta
	};
	var etaPatchAPIapi = {
		target: URL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};
	var info = " TargetURL :" + etaPatchAPIapi.target + "; Method :" + etaPatchAPIapi.method + "; Data :" + JSON.stringify(etaPatchAPIapi.data) + ". ";

	try {
		var response = await urlOpenAsync(etaPatchAPIapi);
		var responseStatusCode = response.statusCode;
		ctx.setVariable("responseStatusCode", responseStatusCode);
		var responseData = await readAsBufferAsync(response);

		if ((responseStatusCode == 200) || (responseStatusCode == 400 && responseData == 'No updates')) {
			logger.info("etaPatchAPI successful - response received with status code: " + responseStatusCode);
			// SUCCESS: Return success flag
			return { success: true, statusCode: responseStatusCode };
		} else {
			// FAILURE: Log error and return failure flag with details
			var errorinfo = "etaPatchAPI failed with Response code: " + responseStatusCode + " and reason: " + responseData;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", responseStatusCode);
			ilsctx.setVariable("errorMessage", "etaPatchAPI failed");
			logger.error("etaPatchAPI failed: " + errorinfo);
			// Return failure flag with error details to terminate process
			return { success: false, statusCode: responseStatusCode, error: errorinfo };
		}
	} catch (error) {
		// ERROR: Log error and return failure flag
		var errorinfo = "urlopen connect error with etaPatchAPI: " + error;
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
		ilsctx.setVariable("errorMessage", "etaPatchAPI connection error");
		logger.error("etaPatchAPI error: " + errorinfo);
		// Return failure flag with error details to terminate process
		return { success: false, statusCode: 500, error: errorinfo };
	}
}

// ===== CUSTOM FIELD VALUES FUNCTION WITH FLOW CONTROL AND ERROR HANDLING =====

async function CustomFieldValues(workflow_id) {
	var URL = omsExternalURL + '/api/ServiceType/Electric/CrewAssignment/' + workflow_id;
	var payload = {
		"customFieldValues": {
			"Disposition": Disposition_new
		}
	}
	var CrewAssignmentPatchapi = {
		target: URL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: payload
	};
	var info = " TargetURL :" + CrewAssignmentPatchapi.target + "; Method :" + CrewAssignmentPatchapi.method + "; Data :" + JSON.stringify(CrewAssignmentPatchapi.data) + ". ";

	try {
		var response = await urlOpenAsync(CrewAssignmentPatchapi);
		var responseStatusCode = response.statusCode;
		ctx.setVariable("responseStatusCode", responseStatusCode);
		var responseData = await readAsBufferAsync(response);

		if ((responseStatusCode == 200) || (responseStatusCode == 400 && responseData == 'No updates')) {
			logger.info("CustomFieldValues successful - response received with status code: " + responseStatusCode);
			// SUCCESS: Return success flag
			return { success: true, statusCode: responseStatusCode };
		} else {
			// FAILURE: Log error and return failure flag with details
			var errorinfo = "CustomFieldValues failed with Response code: " + responseStatusCode + " and reason: " + responseData;
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", responseStatusCode);
			ilsctx.setVariable("errorMessage", "CustomFieldValues failed");
			logger.error("CustomFieldValues failed: " + errorinfo);
			// Return failure flag with error details to terminate process
			return { success: false, statusCode: responseStatusCode, error: errorinfo };
		}
	} catch (error) {
		// ERROR: Log error and return failure flag
		var errorinfo = "urlopen connect error with CustomFieldValues: " + error;
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
		ilsctx.setVariable("errorMessage", "CustomFieldValues connection error");
		logger.error("CustomFieldValues error: " + errorinfo);
		// Return failure flag with error details to terminate process
		return { success: false, statusCode: 500, error: errorinfo };
	}
}
