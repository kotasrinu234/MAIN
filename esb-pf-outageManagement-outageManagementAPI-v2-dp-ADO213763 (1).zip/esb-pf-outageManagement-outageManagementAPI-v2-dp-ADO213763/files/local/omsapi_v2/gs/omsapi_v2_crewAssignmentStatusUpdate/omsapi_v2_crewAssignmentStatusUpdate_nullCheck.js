//set stylesheet parameters to variable
var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookUpURL;
var crewErrorDescription = session.parameters.crewErrorDescription;
var JobErrorDescription = session.parameters.JobErrorDescription;
var ErrorDescription = session.parameters.ErrorDescription;
var apiToken_chatbot = session.parameters.apiToken_chatbot;
var apiToken_maximo = session.parameters.apiToken_maximo;
var apiToken_reporting = session.parameters.apiToken_reporting;

//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("crewErrorDescription", crewErrorDescription);
ctx.setVariable("JobErrorDescription", JobErrorDescription);
ctx.setVariable("ErrorDescription", ErrorDescription);
ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
ctx.setVariable("apiToken_maximo", apiToken_maximo);
ctx.setVariable("apiToken_reporting", apiToken_reporting);

//To perform null check on request payload

var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var nullcheck = session.parameters.nullcheck;
	if (nullcheck == 'yes') {
		var URL = sm.getVar('var://service/URI');
		var URI = URL.toString().split("/");
		var crewId = URI[4];
		if (crewId == null || crewId == '' || crewId == undefined) {
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "404");
			logger.error('crewId is not present in input payload');
			session.reject('crewId is not present in input payload');
		}
		else {
			ctx.setVariable("crewId", crewId);
		}

		var msgId = incomingdata.msgId;

		if (msgId == null || msgId == '' || msgId == undefined) {
			var errorinfo = "msgId is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "404");
			logger.error(errorinfo);
			session.reject(errorinfo);
		}

		var jobId = incomingdata.jobId;
		if (jobId == null || jobId == '' || jobId == undefined) {
			var errorinfo = "jobId is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "404");
			logger.error(errorinfo);
			session.reject(errorinfo);
		}

		var crewAssignmentStatus = incomingdata.crewAssignmentStatus;
		if (crewAssignmentStatus == null || crewAssignmentStatus == '' || crewAssignmentStatus == undefined) {
			var errorinfo = "crewAssignmentStatus is not present in input payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatusCode", "404");
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	}
	var Disposition = incomingdata.disposition;
	var disposition_check;
	if (Disposition == null || Disposition == undefined || Disposition == '') {
		disposition_check = 'True';
		ctx.setVariable("disposition_check", disposition_check);
	} else {
		disposition_check = 'False';
		ctx.setVariable("disposition_check", disposition_check);
		ctx.setVariable("Disposition", Disposition);
		var i = 0;
		var Disposition_new = [];
		for (i = 0; i < Disposition.length; i++) {
			var label = Disposition[i];
			var lookupMessage = {
				"lookupReq": {
					"type": [{
						"name": "crewAssignmentCustomFields",
						"externalLabel": "Disposition",
						"label": label
					}]
				}
			}
			var LookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
			try {
				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "url connection error with 'LookupServiceResponse', details are : " + info + "; error info :" + error
						ilsctx.setVar('errorDescription', errorinfo);
						ilsctx.setVariable("errorStatusCode", "500");
						ilsctx.setVariable("errorMessage", response.reasonPhrase);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var responsePhrase = response.reasonPhrase;
						//logger.debug("response:" + JSON.stringify(response));
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "omsapiv2_101:failure in reading message from LookupServiceResponse, details are : " + info + "; error info :" + error
									ilsctx.setVar('errorDescription', errorinfo);
									ilsctx.setVariable("errorStatusCode", "500");
									ilsctx.setVariable("errorMessage", responsePhrase);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
									var status;
									if (responseData.lookupRep.type[0].result == 0) {
										status = responseData.lookupRep.type[0].status;
									} else {
										ilsctx.setVar('errorDescription', "disposition lookup result is not 0");
										ilsctx.setVariable("errorStatusCode", "400");
										session.reject('disposition lookup result is not 0')
									}
									Disposition_new.push(status);
									var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
									ctx.setVariable("Disposition_new", Disposition_new);
								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "failure in reading message from lookup call, details are : " + info + "; error info :" + error
									ilsctx.setVar('errorDescription', errorinfo);
									ilsctx.setVariable("errorStatusCode", "500");
									ilsctx.setVariable("errorMessage", responsePhrase);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var responseinfo = "Error code returned from lookup call : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ilsctx.setVar('errorDescription', responseinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									logger.error(responseinfo);
									session.reject(responseinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "url connection error with 'LookupServiceResponse', details are : " + info + "; error info :" + error
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", "500");
				ilsctx.setVariable("errorMessage", response.reasonPhrase);
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	}
});
