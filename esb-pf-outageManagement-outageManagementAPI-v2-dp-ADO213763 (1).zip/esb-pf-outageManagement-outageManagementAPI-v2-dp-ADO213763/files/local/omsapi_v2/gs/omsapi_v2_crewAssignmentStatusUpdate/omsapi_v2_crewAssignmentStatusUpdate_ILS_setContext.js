var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.CrewAssignmentstatusUpdateEntryDescription;
var exitDescription = session.parameters.CrewAssignmentstatusUpdateExitDescription;
var messageType = session.parameters.messageType;
var apiName = session.parameters.getCrewAssignmentStatusUpdateApiName;
if (apiName !== undefined || apiName !== null || apiName !== '') {
	ctx.setVariable("apiName", apiName);
}
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
var ILSctx = session.name('ILS') || session.createContext('ILS');
function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var URL = sm.getVar('var://service/URI');
		var URI = URL.toString().split("/");
		var crewDisplayID = URI[4];
		if (crewDisplayID == null || crewDisplayID == '' || crewDisplayID == undefined) {
			ctx.setVariable("crewDisplayID", '');
		}
		else {
			ctx.setVariable("crewDisplayID", crewDisplayID);
		}
		if (incomingdata.msgId !== undefined || incomingdata.msgId !== null || incomingdata.msgId !== '') {
				ILSctx.setVariable('correlationID', incomingdata.msgId);
			} else {
				ILSctx.setVariable('correlationID', uuidv4());
			}
		if (incomingdata.crewAssignmentStatus) {
			if (incomingdata.crewAssignmentStatus !== undefined || incomingdata.crewAssignmentStatus !== null || incomingdata.crewAssignmentStatus !== '') {
				ctx.setVariable("assignmentStatus", incomingdata.crewAssignmentStatus)
			}
		}
		if (incomingdata.longitude) {
			if (incomingdata.longitude !== undefined || incomingdata.longitude !== null || incomingdata.longitude !== '') {
				ctx.setVariable("longitude", incomingdata.longitude)
			}
		}
		if (incomingdata.latitude) {
			if (incomingdata.latitude !== undefined || incomingdata.latitude !== null || incomingdata.latitude !== '') {
				ctx.setVariable("latitude", incomingdata.latitude)
			}
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
	}
});
