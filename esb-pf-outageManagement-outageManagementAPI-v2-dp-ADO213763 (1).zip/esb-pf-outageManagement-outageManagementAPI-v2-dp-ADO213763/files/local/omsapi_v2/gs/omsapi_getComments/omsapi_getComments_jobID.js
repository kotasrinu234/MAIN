var ctxadd = session.name("omsapi") || session.createContext("omsapi");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var incomingUser = currentUser;
var apiToken;
var logger = console.options({
	'category': 'all'
});
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var qs = require('querystring');
var urlIn = sm.getVar('var://service/URL-in');
var Count = session.parameters.getImageJobDetailCount;
var omsExternalURL = session.parameters.omsExternalURL;
var objectTypeCheck = ctxadd.getVariable("objectTypeCheck");
var ctx = session.name("omsapi_ReceiveComments") || session.createContext("omsapi_ReceiveComments");
var internalId = '';
var incData = ctxadd.getVar("incomingdata");
var respObj = ctxadd.getVar("responseObj");
var uri = new String(sm.URI);
var json;
var jobID = '';
var callID = '';
if (incomingUser == 'dcas-wismo-esb-dev' || incomingUser == 'dcas-wismo-esb-test' || incomingUser == 'dcas-wismo-esb-prod' || incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Multipurpose;
	if (uri.indexOf("?") != -1) {
		json = qs.parse(uri.substring(uri.indexOf("?") + 1));
		if (json.jobID) {
			jobID = json.jobID;
		}
		else if (json.callID) {
			callID = json.callID;
		}
	}
	if (jobID) {
		if (jobID.length < Count) {
			var getInternalIdUrl = omsExternalURL + '/api/ServiceType/Electric/Job/' + jobID + '?includeFields=id';
			var getInternalIdApi = {
				target: getInternalIdUrl,
				sslClientProfile: 'omsapi_client_profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': apiToken
				}
			};
			var info = " TargetURL :" + getInternalIdApi.target + "; Method :" + getInternalIdApi.method + ". ";
			try {
				urlopen.open(getInternalIdApi, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'with getInternalIdApi', details are : " + info + "; error info :" + error
						ilsctx.setVar('errorDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						var responsePhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'getInternalIdApi', details are : " + info + "; error info :" + error
									ilsctx.setVar('errorDescription', errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									ilsctx.setVariable("errorMessage", responsePhrase);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									internalId = responseData.id;
									logger.error(responseData.id);
									commentcall(internalId);
									ctx.setVariable("internalId", internalId);
								}
							});
						} else if (responseStatusCode == 401) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "omsapiv2_183:failure in reading response from 'getInternalIdApi', details are : " + info + "; error info :" + error
									ilsctx.setVar('errorDescription', errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									ilsctx.setVariable("errorMessage", responsePhrase);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "omsapiv2_183:Error returned from getInternalIdApi call " + responseStatusCode + ", details are : " + info + "; errorresponse info :" + responseData
									ilsctx.setVar('errorDescription', errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									ilsctx.setVariable("errorMessage", responsePhrase);
									logger.error("Error returned from getInternalIdApi call" + " " + responseStatusCode);
									session.reject(errorinfo);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'getInternalIdApi', details are : " + info + "; error info :" + error
									ilsctx.setVar('errorDescription', errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									ilsctx.setVariable("errorMessage", responsePhrase);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "Unable to find the details in getInternalIdApi call " + responseStatusCode + ", details are : " + info + "; errorresponse info :" + responseData
									ilsctx.setVar('errorDescription', errorinfo);
									ilsctx.setVariable("errorStatusCode", responseStatusCode);
									ilsctx.setVariable("errorMessage", responsePhrase);
									logger.error("Unable to find the details in getInternalIdApi call" + " " + responseStatusCode);
									session.reject(errorinfo);
								}
							});
						}
					}

				});
			} catch (error) {
				var errorinfo = "url connection error with getInternalIdApi, details are : " + info + "; error info :" + error
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", error.errorCode);
				ilsctx.setVariable("errorMessage", error.errorMessage);
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
		else {
			internalId = jobID;
			ctx.setVariable("internalId", internalId);
			commentcall(internalId);
		}
	}
	else if (callID) {
		notescall(callID)
	}
}
else {
	logger.error("Incoming user is not Wismo/URMA, the user : " + incomingUser);
	session.reject("Incoming user is not Wismo/URMA, the user : " + incomingUser);
	var errorinfo = "Incoming user is not Wismo/URMA, the user : " + incomingUser;
	ilsctx.setVar('errorDescription', errorinfo);
}
function commentcall(internalId) {
	var commentURL = omsExternalURL + '/api/ServiceType/Electric/Job/' + internalId + '/Comment?includeFields=createdAt,createdByUserName,comment';
	var commentApi = {
		target: commentURL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'GET',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		}
	};
	var info = " TargetURL :" + commentApi.target + "; Method :" + commentApi.method + ". ";
	try {
		urlopen.open(commentApi, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'with commentApi', details are : " + info + "; error info :" + error
				ilsctx.setVar('errorDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'commentApi', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = responseStatusCode;
							ctx.setVariable("commentresponse", responseData);
							if (!(responseData[0] === undefined || responseData[0] === '' || responseData[0] === null)) {
								ctx.setVariable("responseData", responseData);
								var payload = {
									responseData
								}
								ctx.setVar("payload", payload)
								session.output.write(JSON.parse(JSON.stringify(payload)));
							} else {
								var errorinfo = "404 Unable to find the comments for " + internalId + ", details are : " + info + "; errorresponse info :" + responseData
								ilsctx.setVar('errorDescription', errorinfo);
								ilsctx.setVariable("errorStatusCode", "404");
								ilsctx.setVariable("errorMessage", "Not Found");
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						}
					});
				} else if (responseStatusCode == 401) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "omsapiv2_184:failure in reading response from 'commentApi', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "omsapiv2_184:Error returned from commentApi call " + responseStatusCode + ", details are : " + info + "; errorresponse info :" + responseData
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error("Error returned from commentApi call" + " " + responseStatusCode);
							session.reject(errorinfo);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and take the control to error rule with error code and description
							var errorinfo = "error reading response 'commentApi', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "Unable to find the details in commentApi call " + responseStatusCode + ", details are : " + info + "; errorresponse info :" + responseData
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error("Unable to find the details in commentApi call" + " " + responseStatusCode);
							session.reject(errorinfo);
						}
					});
				}
			}

		});
	} catch (error) {
		var errorinfo = "url connection error 'with commentApi', details are : " + info + "; error info :" + error
		ilsctx.setVar('errorDescription', errorinfo);
		logger.error(errorinfo);
		session.reject(errorinfo);
	}
}
function notescall(internalcallId) {
	var notesURL = omsExternalURL + '/api/ServiceType/Electric/Call/Query?isInternalIDs=false&includeFields=notes,displayID,jobDisplayID';
	var Payload = {
		internalcallId
	};
	session.output.write(Payload);
	var notesApi = {
		target: notesURL,
		sslClientProfile: 'omsapi_client_profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: [internalcallId]
	};
	var info = " TargetURL :" + notesApi.target + "; Method :" + notesApi.method + "; Data " + notesApi.data + " . ";
	try {
		urlopen.open(notesApi, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'with notesApi', details are : " + info + "; error info :" + error
				ilsctx.setVar('errorDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'notesApi', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = responseStatusCode;
							ctx.setVariable("commentresponse", responseData);
							if (!(responseData[0] === undefined || responseData[0] === '' || responseData[0] === null)) {
								ctx.setVariable("responseData", responseData);
								var payload = {
									responseData
								}
								ctx.setVar("payload", payload)
								session.output.write(JSON.parse(JSON.stringify(payload)));
							} else {
								var errorinfo = "404 Unable to find the notes for " + internalcallId + ", details are : " + info + "; errorresponse info :" + responseData
								ilsctx.setVar('errorDescription', errorinfo);
								ilsctx.setVariable("errorStatusCode", "404");
								ilsctx.setVariable("errorMessage", "Not Found");
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						}
					});
				} else if (responseStatusCode == 401) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "omsapiv2_184:failure in reading response from 'notesApi', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "omsapiv2_184:Error returned from notesApi call " + responseStatusCode + ", details are : " + info + "; errorresponse info :" + responseData
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error("Error returned from commentApi call" + " " + responseStatusCode);
							session.reject(errorinfo);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and take the control to error rule with error code and description
							var errorinfo = "error reading response 'notesApi', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "Unable to find the details in notesApi call " + responseStatusCode + ", details are : " + info + "; errorresponse info :" + responseData
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error("Unable to find the details in notesApi call" + " " + responseStatusCode);
							session.reject(errorinfo);
						}
					});
				}
			}

		});
	} catch (error) {
		var errorinfo = "url connection error with 'notesApi', details are : " + info + "; error info :" + error
		ilsctx.setVar('errorDescription', errorinfo);
		logger.error(errorinfo);
		session.reject(errorinfo);
	}
}
