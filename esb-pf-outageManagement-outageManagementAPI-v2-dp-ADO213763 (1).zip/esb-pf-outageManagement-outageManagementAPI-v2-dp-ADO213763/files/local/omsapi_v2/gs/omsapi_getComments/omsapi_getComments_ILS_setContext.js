var logger = console.options({
	'category': 'all'
});
var qs = require('querystring');
var sm = require('service-metadata');
var ctx = session.name('ILS') || session.createContext('ILS');
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var jobDetailCount = session.parameters.getImageJobDetailCount;
var messageType = session.parameters.messageType;
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
var uri = sm.URI;
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
session.INPUT.readAsBuffer(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var entryDescription = session.parameters.getCommentjobIDEntryDescription;
		var exitDescription = session.parameters.getCommentjobIDExitDescription;
		var apiName = session.parameters.getCommentjobIDApiName;
		if (apiName !== undefined || apiName !== null || apiName !== '') {
			ctx.setVariable('apiName', apiName);
		}
		if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
			ctx.setVariable('entryDescription', entryDescription);
		}
		if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
			ctx.setVariable('exitDescription', exitDescription);
		}
		var json = '';
		if (uri.indexOf("?") != -1) {
			json = qs.parse(uri.substring(uri.indexOf("?") + 1));
		}
		if (json.messageID) {
			if (json.messageID !== undefined || json.messageID !== null || json.messageID !== '') {
				ctx.setVariable("correlationID", json.messageID);
			}
			else {
				logger.error("messageID is empty");
				session.reject("messageID is empty");
				var errorinfo = "messageID is empty";
				ilsctx.setVariable("errorStatusCode", "500");
				ilsctx.setVariable("errorMessage", "");
				ilsctx.setVar('errorDescription', errorinfo);
			}
		}
		else {
			logger.error("MessageID is not present");
			session.reject("MessageID is not present");
			var errorinfo = "MessageID is not present";
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			ilsctx.setVariable("errorMessage", "");
		}
		if (json.jobID) {
			if (json.jobID !== undefined || json.jobID !== null || json.jobID !== '') {
				var id = json.jobID;
				if (id.length == jobDetailCount) {
					ctx.setVariable("jobID", id);
				}
				else {
					ctx.setVariable("jobDisplayID", id);
				}
			}
			else {
				logger.error("JobId is empty");
				session.reject("JobId is empty");
				var errorinfo = "JobId is empty";
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", "500");
				ilsctx.setVariable("errorMessage", "");
			}
		}
		else if (json.callID) {
			if (json.callID !== undefined || json.callID !== null || json.callID !== '') {
				var id = json.callID;
				ctx.setVariable("callID", id);
			}
			else {
				logger.error("callID is empty");
				session.reject("callID is empty");
				var errorinfo = "callID is empty";
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", "500");
				ilsctx.setVariable("errorMessage", "");
			}
		}
		else {
			logger.error("JobId and callID are not present");
			session.reject("JobId and callID are not present");
			var errorinfo = "JobId and callID are not present";
			ilsctx.setVar('errorDescription', errorinfo);
			ilsctx.setVariable("errorStatusCode", "500");
			ilsctx.setVariable("errorMessage", "");
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString());
	}
});
