var ctx = session.name("Meter_Details") || session.createContext("Meter_Details");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var apiToken_Multipurpose = ctx.getVar("apiToken_Multipurpose");
var ctx1 = session.name("current") || session.createContext("current");
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var currentUser = ctx1.getVar("user");
var meterIds = ctx.getVar("meterArr");
var timesStamp = ctx.getVar("timesStamp");
var successArray = [];
var errorArray = [];
var reqSuccessData = {};
var reqErrorData = {};
var logger = console.options({
	'category': 'all'
});
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;

} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;

} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;

} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;

}
else if (incomingUser == 'esb-pnfcep-onp-dev' || incomingUser == 'esb-pnfcep-onp-test' || incomingUser == 'esb-pnfcep-onp-prod') {
	apiToken = apiToken_Multipurpose;

}
session.input.readAsJSON(function(error, json) {
	if (error) {
		var errorinfo = "Error in reading incoming data " + JSON.stringify(error)
		logger.error("Error in reading incoming data " + JSON.stringify(error));
		session.reject("Error in reading incoming data" + JSON.stringify(error));
		ctx.setVar('errorDescription', errorinfo);
		ctx.setVariable("errorStatusCode", "500");
	}
	else {
		var NoOfMeterIDs = session.parameters.NoOfMeterIDs;
		for (var i = 0; i < NoOfMeterIDs && i < meterIds.length; i++) {
			var getURL = omsExternalURL + '/api/v1/ServiceType/Electric/Meter/' + meterIds[i];
			getCallResponse(getURL, meterIds[i]);
		}

	}
});

function getCallResponse(url, meterId) {
	var options = {
		target: url,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "omsapi_client_profile"

	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "meterId : " + meterId;
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with getCallResponse, details are : 500 " + info + "; error info :" + error;
				logger.error(" urlopen error " + JSON.stringify(errorinfo));
				session.reject("urlopen error: " + JSON.stringify(errorinfo));
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", "500");
			} else {
				var responseStatusCode = response.statusCode;
				var ctx = session.name("Meter_Details") || session.createContext("Meter_Details");
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "urlopen connect error with getCallResponse, details are : 500 " + info + "; error info :" + error;
							logger.error("urlopen connect error with getCallResponse " + JSON.stringify(errorinfo));
							session.reject("urlopen connect error with getCallResponse " + JSON.stringify(errorinfo));
							session.output.write("readAsJSON error: " + JSON.stringify(errorinfo));
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", "500");
						} else {
							if (responseData.deprecated === false) {
								reqSuccessData.connected = responseData.connected;
								reqSuccessData.deviceID = responseData.deviceID;
								reqSuccessData.premiseID = responseData.externalPremiseID;
								reqSuccessData.meterID = responseData.meterID;
								reqSuccessData.activeOutage = responseData.activeOutage;
								reqSuccessData.activeAccount = responseData.activeAccount;
								successArray.push(reqSuccessData)
								ctx.setVariable("successArray", successArray)
								reqSuccessData = {};
							}
						}
					})
				}
				else if (responseStatusCode == 404) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "Failure in reading the response data from " + url + ", details are : " + info + "; error info :" + error;
							logger.error("failure in reading message from " + " " + JSON.stringify(errorinfo));
							session.reject("failure in reading message from " + " " + JSON.stringify(errorinfo));
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", "500");
						} else {
							var errorinfo = "Error returned from " + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
							logger.error(JSON.stringify(errorinfo));
							session.reject(JSON.stringify(errorinfo));
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
						}
					});
				}
				else if (responseStatusCode == 401) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "Failure in reading the response data from " + ", details are : " + info + "; error info :" + error;
							logger.error("failure in reading message from " + " " + JSON.stringify(errorinfo));
							session.reject("failure in reading message from " + " " + JSON.stringify(errorinfo));
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", "500");
						} else {
							var errorinfo = "Error returned from " + url + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
							logger.error("Error returned from " + " " + JSON.stringify(errorinfo));
							session.reject("Error returned from " + " " + JSON.stringify(errorinfo));
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
						}
					});
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "urlopen connect error with getCallResponse" + responseStatusCode + ", details are : " + info + "; error info :" + error;
							logger.error("failure in reading message from " + url + " " + JSON.stringify(errorinfo));
							session.reject("failure in reading message from " + url + " " + JSON.stringify(errorinfo));
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", "500");
						} else {
							var errorinfo = "urlopen connect error with getCallResponse" + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							reqErrorData.meterID = meterId;
							reqErrorData.errorCode = responseStatusCode;
							reqErrorData.errorDescription = "No Premise Service found matching the meter ID";
							errorArray.push(reqErrorData)
							ctx.setVariable("errorArray", errorArray)
							reqErrorData = {};
						}
					});
				}
			}
		});
	}
	catch (err) {
		var errorinfo = "urlopen connect error with getCallResponse, details are : 500 " + info + "; error info :" + err;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error(" urlopen error " + JSON.stringify(errorinfo));
		session.reject("urlopen error: " + JSON.stringify(errorinfo));
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", "500");
	}
}
