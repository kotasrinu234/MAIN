var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ctx = session.name("Meter_Details") || session.createContext("Meter_Details");
		//set stylesheet parameters to variable
		var omsExternalURL = session.parameters.omsExternalURL;
		var apiToken = session.parameters.apiToken;
		var apiToken_chatbot = session.parameters.apiToken_chatbot;
		var apiToken_maximo = session.parameters.apiToken_maximo;
		var apiToken_reporting = session.parameters.apiToken_reporting;
		var apiToken_Abnormal_Voltage = session.parameters.apiToken_Abnormal_Voltage;
		var apiToken_Multipurpose = session.parameters.apiToken_Multipurpose;
		var msgId = incomingdata.messageId;
		var timesStamp = incomingdata.timesStamp;
		var meterIds = incomingdata.meterIds;

		//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js
		ctx.setVariable("omsExternalURL", omsExternalURL);
		ctx.setVariable("apiToken", apiToken);
		ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
		ctx.setVariable("apiToken_maximo", apiToken_maximo);
		ctx.setVariable("apiToken_reporting", apiToken_reporting);
		ctx.setVariable("apiToken_Abnormal_Voltage", apiToken_Abnormal_Voltage);
		ctx.setVariable("apiToken_Multipurpose", apiToken_Multipurpose);

		if (msgId === undefined || msgId === null || msgId === '') {
			var errorinfo = "msgId not found";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("msgId not found");
			session.reject("msgId not found");
		}
		else {
			ctx.setVariable("msgId", msgId);
		}

		if (timesStamp === undefined || timesStamp === null || timesStamp === '') {
			var errorinfo = "timesStamp not found";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("timesStamp not found");
			session.reject("timesStamp not found");
		} else {
			ctx.setVariable("timesStamp", timesStamp);
		}

		if (meterIds === undefined || meterIds === null || meterIds.length === 0) {
			var errorinfo = "meterIds not found";
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("meterIds not found");
			session.reject("meterIds not found");
		}
		else {
			var meterIdArray = [];
			for (var i = 0; i < meterIds.length; i++) {
				//var deprecated = commentsArr[i].deprecated;
				var meter = meterIds[i].meterId;
				meterIdArray.push(meter);
			}
			ctx.setVariable('meterArr', meterIdArray);
		}

	}
});
