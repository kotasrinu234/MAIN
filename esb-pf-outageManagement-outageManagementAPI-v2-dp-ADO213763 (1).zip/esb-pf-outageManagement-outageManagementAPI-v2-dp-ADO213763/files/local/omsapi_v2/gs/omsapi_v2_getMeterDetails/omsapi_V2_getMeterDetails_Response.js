var logger = console.options({
	'category': 'all'
});
var ctx = session.name("Meter_Details") || session.createContext("Meter_Details");


var json = {};
var msgId = ctx.getVariable("msgId");
var timesStamp = ctx.getVariable("timesStamp");
var errorArray = ctx.getVariable("errorArray");
var successArray = ctx.getVariable("successArray");
var MeterArray = [];
//MeterArray.push(successArray);
//MeterArray.push(errorArray);
if (errorArray !== undefined && errorArray !== null && errorArray.length !== "0") {
	if (successArray !== undefined && successArray !== null && successArray.length !== "0") {
		MeterArray = successArray.concat(errorArray)
	}
}
else if (errorArray === undefined || errorArray === null || errorArray.length === "0") {
	MeterArray = successArray
}
else {
	MeterArray = errorArray
}
ctx.setVariable("MeterArray", MeterArray)

if (msgId != null || msgId != '' || msgId != undefined) {
	json.msgId = msgId;
}

if (MeterArray != null || MeterArray.length != '0' || MeterArray != undefined) {
	json.meterIds = MeterArray;
}

json.timestamp = new Date().toISOString();

ctx.setVariable('FinalResponse', json);
session.output.write(json);
