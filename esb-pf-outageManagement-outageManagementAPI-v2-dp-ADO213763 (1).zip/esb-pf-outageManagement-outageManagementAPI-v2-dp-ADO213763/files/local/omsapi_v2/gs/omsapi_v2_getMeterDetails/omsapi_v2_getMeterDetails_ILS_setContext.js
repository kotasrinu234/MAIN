var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.getMeterDetailsEntryDescription;
var exitDescription = session.parameters.getMeterDetailsExitDescription;
var apiName = session.parameters.getMeterDetailsApiName;
var messageType = session.parameters.messageType;
ctx.setVariable("messageType", messageType);
ctx.setVariable("apiName", apiName);
ctx.setVariable('entryDescription', entryDescription);
ctx.setVariable('exitDescription', exitDescription);
ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.messageId !== undefined || incomingdata.messageId !== null || incomingdata.messageId !== '') {
			ctx.setVariable("correlationID", incomingdata.messageId);
		}

	}
});
