var ctx = session.name("JobSummary")|| session.createContext("JobSummary");
var jobIds = ctx.getVariable('inputJobIds');
var omsJobIdsResponse = ctx.getVariable("omsJobDetails_responseData");
var omsJobIdsResponseDetails = ctx.getVariable("omsJobDetailsCallResponse_responseData");
var dbIds = ctx.getVariable("dbJobIds");
var omsIds = ctx.getVariable("omsJobIds");
var validOmsIds = new Array();
var responseArray = new Array();
var json;
var jobs = {};
var jobStatusMap = new Map([
	['7', 'Pending'],
	['8', 'Assigned'],
	['9', 'Held'],
	['10', 'Broadcast and Cancel'],
	['11', 'Broadcast and Cancel'],
	['12', 'Canceled'],
	['13', 'Verified'],
	['14', 'Dup and Cancel'],
	['15', 'Agreed Response'],
	['16', 'Closed'],
	['17', 'Awaiting Closure'],
	['18', 'Dispatch Assigned'],
	['20', ' Dependent Status (used by InService to track'],
	['21', 'Scheduled']
]);
var jobStatusValue;

for(var i =0; i<dbIds.length;i++ ){
	json={};
	if(ctx.getVariable(dbIds[i]) !== undefined && ctx.getVariable(dbIds[i])!=''){
		json.jobId = dbIds[i];
		var jStatus = ctx.getVariable(dbIds[i]+'_statusCode');
		jobStatusValue = jobStatusMap.get(jStatus);
		json.jobStatus= jobStatusValue;
		json.jobType=ctx.getVariable(dbIds[i]+'_jobType');
		var string = ctx.getVariable(dbIds[i]+'_region');
		if(string !== '' || string !== null || string != undefined){
		json.region = string.substring(0,2);
		}
		//json.region=ctx.getVariable(dbIds[i]+'_region');
		json.aor=ctx.getVariable(dbIds[i]+'_aor');
		json.circuit=ctx.getVariable(dbIds[i]+'_circuit');
		json.stormId=ctx.getVariable(dbIds[i]+'_STORM_JOB');
		json.jobExists = 'Y';
	}else{
		json.jobId = dbIds[i];
		json.jobExists = "N";
	}
	responseArray.push(json);
}

if ((omsJobIdsResponse != undefined) && (omsJobIdsResponse != null) && (omsJobIdsResponse != '')) {
for(var i =0; i<omsJobIdsResponse.length;i++ ){
	json={};
	validOmsIds.push(omsJobIdsResponse[i].displayID);
		json.jobId = omsJobIdsResponse[i].displayID;
		var ctx = session.name("JobSummary")|| session.createContext("JobSummary");
		var jobStatusLookup=ctx.getVariable("jobStatus_"+omsJobIdsResponse[i].displayID+'_lookup');
		var jobTypeLookup=ctx.getVariable("jobType_"+omsJobIdsResponse[i].displayID+'_lookup');
		var aorsIdsLookup=ctx.getVariable("aorsIds_"+omsJobIdsResponse[i].displayID+'_lookup');
		json.jobStatus=jobStatusLookup[0].label;
		json.jobType=jobTypeLookup[0].label;
		if(aorsIdsLookup != undefined){

		json.aor= aorsIdsLookup[0].label;
		
		}
		if(omsJobIdsResponse[i].feederName){	
		json.circuit = omsJobIdsResponse[i].feederName;
		}
		if(omsJobIdsResponse[i].regionName){
		var string = omsJobIdsResponse[i].regionName;
		if(string !== '' || string !== null || string != undefined){
		json.region = string.substring(0,2);
		}
		}
		if(!(omsJobIdsResponse[i].operationEventIDs.length)){
			json.stormId =''
		}else{
		var omsJobStormDisplayId = ctx.getVariable("JobStorm_"+omsJobIdsResponse[i].displayID+'_StormId');
		json.stormId =omsJobStormDisplayId;
		}
		//json.jobType=jobTypeLookup.lookupRep.type[0].label;
		json.jobExists = 'Y';
	
	responseArray.push(json);
}
}

if ((omsJobIdsResponseDetails != undefined) && (omsJobIdsResponseDetails != null) && (omsJobIdsResponseDetails != '')) {

for(var k =0; k<omsJobIdsResponseDetails.length;k++ ){
	json={};
	validOmsIds.push(omsJobIdsResponseDetails[k].displayID);
		json.jobId = omsJobIdsResponseDetails[k].displayID;
		
		var jobStatusLookup=ctx.getVariable("jobStatus_"+omsJobIdsResponseDetails[k].displayID+'_lookup');
		var jobTypeLookup=ctx.getVariable("jobType_"+omsJobIdsResponseDetails[k].displayID+'_lookup');
		var aorsIdsLookup=ctx.getVariable("aorsIds_"+omsJobIdsResponseDetails[k].displayID+'_lookup');
		json.jobStatus=jobStatusLookup[0].label;
		json.jobType=jobTypeLookup[0].label;
		json.aor=aorsIdsLookup[0].label;	
		
		if(omsJobIdsResponseDetails[k].feederName){
		json.circuit = omsJobIdsResponseDetails[k].feederName;
		}
		if(omsJobIdsResponseDetails[k].regionName){
		var string = omsJobIdsResponseDetails[k].regionName;
		if(string !== '' || string !== null || string !== undefined ){
		json.region = string.substring(0,2);
		}
		}
		
		if(!(omsJobIdsResponseDetails[k].operationEventIDs.length)){
			json.stormId =''
		}else{
		var omsJobStormDisplayId = ctx.getVariable("JobStorm_"+omsJobIdsResponseDetails[k].displayID+'_StormId');
		json.stormId =omsJobStormDisplayId;
		
		}
		
		json.jobExists = 'Y';
	
	responseArray.push(json);
}
}


var validOmsIdsString =  validOmsIds.join();

for(var j=0; j<omsIds.length;j++){
	if(omsIds[j]===""){
		ctx.setVariable("customErrorCode", '400');
				ctx.setVariable("customErrorMessage", 'Bad Request');
				ctx.setVariable("customReasonMessage", 'Bad Request');
				session.reject('Empty JobId found');
	}
	if(!(validOmsIdsString.includes(omsIds[j]))){
		json={};
		json.jobId = omsIds[j];
		json.jobExists = "N";
		responseArray.push(json);
	}
}

jobs["jobs"] = responseArray;


ctx.setVariable("jobs",jobs);
session.output.write(jobs);
