var ctx = session.name("JobSummary")|| session.createContext("JobSummary");
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
//var apiToken=session.parameters.apiToken;
		var apiToken_OutageStatusApp = session.parameters.apiToken ;
		ctx.setVariable("apiToken_OutageStatusApp", apiToken_OutageStatusApp);
		var apiToken_chatbot=session.parameters.apiToken_chatbot;
		ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
		var apiToken_maximo=session.parameters.apiToken_maximo;
		ctx.setVariable("apiToken_maximo", apiToken_maximo);
		var apiToken_reporting=session.parameters.apiToken_reporting;
		ctx.setVariable("apiToken_reporting", apiToken_reporting);
		
		var ctx1 = session.name("current") || session.createContext("current");
		var currentUser = ctx1.getVar("user");
		var apiToken;
		if(currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd'){
    		apiToken = apiToken_OutageStatusApp;
    	}else if(currentUser == 'dcas-cbo-esb-oms-dev' || currentUser == 'dcas-cbo-esb-oms-tst' || currentUser == 'dcas-cbo-esb-oms-prd'){
    		apiToken = apiToken_chatbot;
    	} else if(currentUser == 'dcas-rpa-esb-oms-dev' || currentUser == 'dcas-rpa-esb-oms-tst' || currentUser == 'dcas-rpa-esb-oms-prd'){
    		apiToken = apiToken_reporting;
    	} else if(currentUser == 'dcas-eam-sr-esb-dev' || currentUser == 'dcas-eam-sr-esb-test' || currentUser == 'dcas-eam-sr-esb-prod'){
    		apiToken = apiToken_maximo;
    	}  else if (currentUser == 'urma-esb-dev' || currentUser == 'urma-esb-test' || currentUser == 'urma-esb-prod') {
				apiToken = session.parameters.apiToken_Urma;
		}
		ctx.setVariable("apiToken", apiToken);



session.INPUT.readAsJSON(function(error,inputRequest){
	if (error) {
                        logger.error("unable to read the input request" + JSON.stringify(error));
                        session.reject("unable to read the input request" + JSON.stringify(error))
    }

var jobIdArray = inputRequest.jobIds;	
if (jobIdArray ==='' || jobIdArray === undefined || jobIdArray === null || !(Array.isArray(jobIdArray)) || jobIdArray.length ===0 ){
				ctx.setVariable("customErrorCode", '400');
				ctx.setVariable("customErrorMessage", 'Bad Request');
				ctx.setVariable("customReasonMessage", 'Bad Request');
				session.reject('Array of JobIds is required');
}
	


var omsIds = new Array();
var dbIds = new Array();
var dbIdStr ='';
								
var dbqueryPre="SELECT num_1, tycod, status_code, feeder, ag_id, dgroup FROM AGENCY_EVENT  WHERE num_1 IN ('";
var dbqueryPost="')";

var StormIdquery=
"select AG_ID,num_1,DGROUP,status_code,LEV3,PREMISE,NUM_CUST,FEEDER,SUB_TYCOD,TYCOD,(select JOB_NUM from spm_summary where to_date(substr(AD_TS,0,length(AD_TS)-2),'YYYYMMDDHH24MiSS') between STORM_START_DT_TM and nvl(STORM_END_DT_TM,sysdate)) storm_job from aeven where curent='T' and num_1 IN ('";


for (var i=0; i < jobIdArray.length;i++){
	if(jobIdArray[i].charCodeAt(1)>47 && jobIdArray[i].charCodeAt(1)<58){
		dbIds.push(jobIdArray[i]);
	}else{
		omsIds.push(jobIdArray[i]);
	}
	
}
dbIdStr = dbIds.join("','");
ctx.setVariable("StormIdquery", StormIdquery+dbIdStr+dbqueryPost);
ctx.setVariable("dbQuery", dbqueryPre+dbIdStr+dbqueryPost);
ctx.setVariable("omsJobIds", omsIds);
ctx.setVariable("dbJobIds", dbIds);
ctx.setVariable("inputJobIds", jobIdArray);
ctx.setVariable("omsJobIdsCount", omsIds.length);
ctx.setVariable("dbJobIdsCount", dbIds.length);




});
