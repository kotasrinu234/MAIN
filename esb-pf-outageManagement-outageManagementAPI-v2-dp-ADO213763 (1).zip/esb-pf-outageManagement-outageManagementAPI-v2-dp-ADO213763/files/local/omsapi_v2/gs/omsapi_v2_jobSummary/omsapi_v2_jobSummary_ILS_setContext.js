var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.getJobSummaryEntryDescription;
var exitDescription = session.parameters.getJobSummaryExitDescription;
var messageType = session.parameters.messageType;
var apiName = session.parameters.getJobSummaryApiName;
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
ctx.setVariable("apiName",apiName);
ctx.setVariable("messageType",messageType);
ctx.setVariable('entryDescription',entryDescription);
ctx.setVariable('exitDescription',exitDescription);
var id = uuidv4()
ctx.setVariable("correlationID",id)
ctx.setVariable("sourceEventTimestamp",new Date().toISOString())
