var ctx = session.name("JobSummary")|| session.createContext("JobSummary");
//var apiToken=session.parameters.apiToken;
		var apiToken_OutageStatusApp = session.parameters.apiToken ;
		ctx.setVariable("apiToken_OutageStatusApp", apiToken_OutageStatusApp);
		var apiToken_chatbot=session.parameters.apiToken_chatbot;
		ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
		var apiToken_maximo=session.parameters.apiToken_maximo;
		ctx.setVariable("apiToken_maximo", apiToken_maximo);
		var apiToken_reporting=session.parameters.apiToken_reporting;
		ctx.setVariable("apiToken_reporting", apiToken_reporting);
		
		var ctx1 = session.name("current") || session.createContext("current");
		var currentUser = ctx1.getVar("user");
		var apiToken;
		
		if(currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd'){
    		apiToken = apiToken_OutageStatusApp;
    		//logger.error("inside OutageAPP----" +apiToken);
    	}else if(currentUser == 'dcas-cbo-esb-oms-dev' || currentUser == 'dcas-cbo-esb-oms-tst' || currentUser == 'dcas-cbo-esb-oms-prd'){
    		apiToken = apiToken_chatbot;
    		//logger.error("inside chatbotAPP----" +apiToken);
    	} else if(currentUser == 'dcas-rpa-esb-oms-dev' || currentUser == 'dcas-rpa-esb-oms-tst' || currentUser == 'dcas-rpa-esb-oms-prd'){
    		apiToken = apiToken_reporting;
    		//logger.error("inside reportAPP----" +apiToken);
    	} else if(currentUser == 'dcas-eam-sr-esb-dev' || currentUser == 'dcas-eam-sr-esb-tst' || currentUser == 'dcas-eam-sr-esb-prd'){
    		apiToken = apiToken_maximo;
    		//logger.error("inside maximoAPP----" +apiToken);
    	} else if (currentUser == 'urma-esb-dev' || currentUser == 'urma-esb-test' || currentUser == 'urma-esb-prod') {
				apiToken = session.parameters.apiToken_Urma;
		}
		ctx.setVariable("apiToken", apiToken);



session.INPUT.readAsJSON(function(error,inputRequest){

var jobIdArray = inputRequest.jobIds;
var omsIds = new Array();
var dbIds = new Array();
var dbIdStr ='';
var dbqueryPre="SELECT num_1, tycod, status_code FROM AGENCY_EVENT  WHERE num_1 IN ('";
var dbqueryPost="')";
for (var i=0; i < jobIdArray.length;i++){
	if(jobIdArray[i].charCodeAt(1)>47 && jobIdArray[i].charCodeAt(1)<58){
		dbIds.push(jobIdArray[i]);
	}else{
		omsIds.push(jobIdArray[i]);
	}
	
}
dbIdStr = dbIds.join("','");
ctx.setVariable("dbQuery", dbqueryPre+dbIdStr+dbqueryPost);
ctx.setVariable("omsJobIds", omsIds);
ctx.setVariable("dbJobIds", dbIds);
ctx.setVariable("inputJobIds", jobIdArray);
ctx.setVariable("omsJobIdsCount", omsIds.length);
ctx.setVariable("dbJobIdsCount", dbIds.length);




});
