var ctx = session.name("JobSummary")|| session.createContext("JobSummary");
var callURL = require('./omsapi_v2_jobSummary_callUrl.js');
var url = session.parameters.omsExternalURL +"/api/ServiceType/Electric/Job/Query?isInternalIDs=false&includeFields=displayID%2Cstatus%2CjobTypeID%2CregionName%2CfeederName%2CaorID%2CoperationEventIDs&historical=true";
var omsJobList = ctx.getVariable("omsJobIds");

var logger = console.options({
	'category': 'all'
});

var validIds = new Array();
var callArr  = new Array();

var omsJobDetailsCall = ctx.getVariable("omsJobDetails_responseData");

if((omsJobDetailsCall != undefined) && (omsJobDetailsCall != null) && (omsJobDetailsCall != '')){

for(var i =0; i<omsJobDetailsCall.length;i++ ){	
	validIds.push(omsJobDetailsCall[i].displayID);		
}
}

var validOmsIds =  validIds.join();


for(var j=0; j<omsJobList.length;j++){
	if(!(validOmsIds.includes(omsJobList[j]))){
		
		callArr.push(omsJobList[j]);
		
	}
}


//fetching JobIds Summary
if (callArr.length > 0){
callURL(url,"POST","omsJobDetailsCallResponse",callArr);
}
