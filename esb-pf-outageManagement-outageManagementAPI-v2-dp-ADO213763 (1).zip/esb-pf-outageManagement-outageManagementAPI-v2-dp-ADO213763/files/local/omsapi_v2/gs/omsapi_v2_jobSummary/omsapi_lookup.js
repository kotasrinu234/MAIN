var ctx = session.name("JobSummary") || session.createContext("JobSummary");
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var url = session.parameters.lookUpURL;
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
//var url = "http://localhost:8080/lookup"; 

function doLookup(arrObj, lookupCtx) {
	console.info("array length " + arrObj.length);
	var request = {};
	request.type = arrObj;
	var lookupUrl = url;
	var options = {
		target: lookupUrl,
		method: 'post',
		contentType: 'application/json',
		data: { "lookupReq": request }
	};

	// open connection to target

	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			var ctx = session.name('JobSummary') || session.createContext('JobSummary');
			if (error) {
				var errorinfo = "url connection error with 'doLookup', details are : " + info + "; error info :" + error
				ilsctx.setVar('errorDescription', errorinfo);
				ilsctx.setVariable("errorStatusCode", error.errorCode);
				ilsctx.setVariable("errorMessage", error.errorMessage);
				ctx.setVariable("customErrorCode", error.errorCode);
				ctx.setVariable("customErrorMessage", error.errorMessage);
				ctx.setVariable("customReasonPhrase", error.errorMessage);
				session.output.write(errorinfo);
				session.reject(errorinfo);

			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						var ctx = session.name('JobSummary') || session.createContext('JobSummary');
						ctx.setVariable('lookupResponseData', responseData);
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response 'doLookup', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							session.output.write(errorinfo);
						} else {
							var lookupResponse = responseData.lookupRep.type;
							ctx.setVariable(lookupCtx + "_lookup", lookupResponse);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message 'doLookup', details are : " + info + "; error info :" + error
							ilsctx.setVar('errorDescription', errorinfo);
							ilsctx.setVariable("errorStatusCode", responseStatusCode);
							ilsctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
						} else {
							logger.error("response received " + responseStatusCode + " " + responseData);
						}
					});

				}
			}
		});
	} catch (error) {
		var errorinfo = "url connection error with 'doLookup', details are : " + info + "; error info :" + error;
		ilsctx.setVar('errorDescription', errorinfo);
		ilsctx.setVariable("errorStatusCode", error.errorCode);
		ilsctx.setVariable("errorMessage", error.errorMessage);
		ctx.setVariable("customErrorCode", error.errorCode);
		ctx.setVariable("customErrorMessage", error.errorMessage);
		ctx.setVariable("customReasonPhrase", error.errorMessage);
		session.output.write(errorinfo);
		session.reject(errorinfo);
	}
	/* 
	 */


}//end of function 

module.exports = doLookup;
