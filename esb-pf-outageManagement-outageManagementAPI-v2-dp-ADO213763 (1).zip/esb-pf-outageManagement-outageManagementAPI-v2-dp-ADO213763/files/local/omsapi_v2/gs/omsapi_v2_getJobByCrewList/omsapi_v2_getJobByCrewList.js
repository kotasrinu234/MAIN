// getJobByCrewList
// This file is for get OMS calls and Lookup service calls
var sm = require('service-metadata');
var hm = require('header-metadata');
var ctx = session.name("crewList") || session.createContext("crewList");
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var ctx1 = session.name("ILS") || session.createContext("ILS");
var exitDescription = session.parameters.getJobByCrewListExitDescription;
var incomingUrl = sm.getVar('var://service/URI');
var getQueryParams = (params, url) => {
	let href = url;
	// this is an expression to get query strings
	let regexp = new RegExp('[?&]' + params + '=([^&#]*)', 'i');
	let qString = regexp.exec(href);
	return qString ? qString[1] : null;
};
var leadCallAddress = "";
var crewIds = getQueryParams('crewIds', incomingUrl);
var excludeResolved;
if (incomingUrl.includes("excludeResolved=") == false) {
	excludeResolved = 'true';
} else {
	excludeResolved = getQueryParams('excludeResolved', incomingUrl);
}

ctx.setVariable("excludeResolved", excludeResolved);
logger.info("Actual Input values of CrewIds " + crewIds);

var crewIdList;
if (crewIds.includes("%2C")) {
	crewIdList = crewIds.split("%2C");
} else if (crewIds.includes(",")) {
	crewIdList = crewIds.split(",");
} else {
	crewIdList = [crewIds];
}
logger.info("CrewIds " + crewIdList);
ctx.setVariable("CrewIds", crewIdList);
var crewIdLength = crewIdList.length;
logger.info("crewIdLength " + crewIdLength);

// Start API token check with current user
var omsExternalURL = ctx.getVariable("omsExternalURL");
var lookupURL = ctx.getVariable("lookupURL");
var apiToken_OutageStatusApp = ctx.getVariable("apiToken");
var apiToken_chatbot = ctx.getVariable("apiToken_chatbot");
var apiToken_maximo = ctx.getVariable("apiToken_maximo");
var apiToken_reporting = ctx.getVariable("apiToken_reporting");
var apiToken_urma = ctx.getVariable("apiToken_urma");
var context = session.name("current") || session.createContext("current");
var currentUser = context.getVar("user");
// End API token check with current user

// Checking if the crewId/crewId's present in the Input GET request
if ((incomingUrl.includes("crewIds=")) && (crewIds != null) && (crewIds != '')) {

	var ctx = session.name("crewList") || session.createContext("crewList");

	var arrayList = [];
	var jobId;
	var jobDisplayId;
	var crewStatus;
	var crewWorkTypeID;
	var networkModelTypeLength;
	var contactMethodLength;

	// Start API token check with current user
	var incomingUser = currentUser;
	var apiToken;
	if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
		apiToken = apiToken_OutageStatusApp;
	} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
		apiToken = apiToken_chatbot;
	} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
		apiToken = apiToken_reporting;
	} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
		apiToken = apiToken_maximo;
	} else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
		apiToken = apiToken_urma;
	}
	// End API token check with current user

	// Iterating through each crewId/crewId's received from the input request
	for (let i = 0; i < crewIdLength; i++) {

		// Start GET crewAssignmentAPI call
		var crewAssignmentUri = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + crewIdList[i] + '/CrewAssignment?excludeResolved=' + excludeResolved;
		var tokenValue = apiToken;

		var crewAssignmentOptions = {
			target: crewAssignmentUri,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': tokenValue
			},
		};
		var info = " TargetURL :" + crewAssignmentOptions.target + "; Method :" + crewAssignmentOptions.method + ". ";
		try {
			urlopen.open(crewAssignmentOptions, function(error, response) {
				if (error) {
					var errorinfo = "omsapi_v2_001:urlopen connect error with Get crewAssignmentAPI with error for crewId " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					logger.error("omsapi_v2_001:urlopen connect error with Get crewAssignmentAPI with error for crewId " + crewIdList[i] + " " + JSON.stringify(error));
					session.reject("urlopen connect error with Get crewAssignmentAPI with error for crewId " + crewIdList[i] + " " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						logger.info("crewAssignmentAPI response status code 200 for crewId " + crewIdList[i]);
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in reading message from Get crewAssignmentAPI for crewId " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("Failure in reading message from Get crewAssignmentAPI for crewId " + crewIdList[i] + " " + JSON.stringify(error));
								session.reject("Failure in reading message from Get crewAssignmentAPI for crewId " + crewIdList[i] + " " + JSON.stringify(error));
							} else {
								var ctx = session.name("crewList") || session.createContext("crewList");
								hm.response.statusCode = responseStatusCode;
								var getCrewAssignmentApiResponse = JSON.parse(responseData);
								ctx.setVariable("crewAssignmentResponseData_" + crewIdList[i], JSON.stringify(getCrewAssignmentApiResponse));
								var total = getCrewAssignmentApiResponse.total;
								ctx.setVariable("totalFieldValueOf_" + crewIdList[i], total);
								logger.info("totalFieldValueOf_" + crewIdList[i], +total);

								// If found and 'Total' field value is '0' from the result set for the crewId
								if (total == 0) {
									logger.info("Total field value is zero for crewId " + crewIdList[i]);
									var exitinfo = "Total field value is zero for crewId " + crewIdList[i];
									ctx1.setVariable("exitDescription", exitinfo);
									var totalFieldobject = {
										"crewId": crewIdList[i]
									}

									arrayList.push(totalFieldobject);
									ctx.setVariable("arrayList", arrayList);
								}
								// If found and 'Total' field value is greater than '0' from the result set for the crewId
								else {
									logger.info("Total field value is greater than 0 for crewId " + crewIdList[i]);
									var exitinfo = "Total field value is greater than 0 for crewId  " + crewIdList[i];
									ctx1.setVariable("exitDescription", exitinfo);
									// If 'Total' field value is greater than '0' result set contains multiple blocks ,For each block call the GET /api/v1/ServiceType/Electric/Job/{id} using "jobDisplayID" from the result set.
									for (let j = 0; j < total; j++) {

										var ctx = session.name("crewList") || session.createContext("crewList");
										jobId = getCrewAssignmentApiResponse.data[j].jobID;
										jobDisplayId = getCrewAssignmentApiResponse.data[j].jobDisplayID;
										crewStatus = getCrewAssignmentApiResponse.data[j].status;
										ctx.setVariable("crewStatus_" + [j] + "_" + crewIdList[i], crewStatus);
										crewWorkTypeID = getCrewAssignmentApiResponse.data[j].workTypeID;
										ctx.setVariable("crewWorkTypeID_" + [j] + "_" + crewIdList[i], crewWorkTypeID);
										ctx.setVariable("jobDisplayID_" + [j] + "_" + crewIdList[i], jobDisplayId);

										// Start GET jobAPI call
										var jobUri = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobId;

										var jobFoundOptions = {
											target: jobUri,
											sslClientProfile: 'omsapi_client_profile',
											method: 'GET',
											contentType: 'application/json',
											headers: {
												'osiApiToken': tokenValue
											},

										};
										var info = " TargetURL :" + jobFoundOptions.target + "; Method :" + jobFoundOptions.method + ". ";
										try {
											urlopen.open(jobFoundOptions, function(error, response) {
												if (error) {
													var errorinfo = "omsapi_v2_002:urlopen connect error with Get jobAPI with error for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
													ilsctx.setVariable("errorDescription", errorinfo);
													logger.error("omsapi_v2_002:urlopen connect error with Get jobAPI with error for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
													session.reject("urlopen connect error with Get jobAPI with error for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														logger.info("jobAPI response status code 200 for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i]);

														response.readAsBuffer(function(error, jobResponseData) {
															if (error) {
																var errorinfo = "Failure in reading message from Get jobAPI for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("Failure in reading message from Get jobAPI for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																session.reject("Failure in reading message from Get jobAPI for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
															} else {
																hm.response.statusCode = responseStatusCode;
																var ctx = session.name("crewList") || session.createContext("crewList");
																var getJobApiResponse = JSON.parse(jobResponseData);
																ctx.setVariable("jobApiResponse_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], JSON.stringify(getJobApiResponse));
																////ADO184556 starts
																var deviceOperatingVoltage;
																if ((getJobApiResponse.voltage != undefined) && (getJobApiResponse.voltage != null) && (getJobApiResponse.voltage != '')) {
																	deviceOperatingVoltage = getJobApiResponse.voltage;
																	ctx.setVariable("deviceOperatingVoltage", deviceOperatingVoltage);
																} else {
																	deviceOperatingVoltage = 0;
																	ctx.setVariable("deviceOperatingVoltage", deviceOperatingVoltage);
																}
																//ADO184556 ends

																var jobId;
																if ((getJobApiResponse.id != undefined) && (getJobApiResponse.id != null) && (getJobApiResponse.id != '')) {
																	jobId = getJobApiResponse.id;
																	ctx.setVariable("jobId", jobId);
																} else {
																	jobId = "";
																}

																var jobDisplayId;
																if ((getJobApiResponse.displayID != undefined) && (getJobApiResponse.displayID != null) && (getJobApiResponse.displayID != '')) {
																	jobDisplayId = getJobApiResponse.displayID;
																	ctx.setVariable("jobDisplayId", jobDisplayId);
																} else {
																	jobDisplayId = "";
																}

																var status = getJobApiResponse.status;
																if (status == undefined) {
																	status = "";
																	ctx.setVariable("status" + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID, status);
																} else {
																	ctx.setVariable("status" + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID, status);
																}

																var jobTypeID;
																if ((getJobApiResponse.jobTypeID != undefined) && (getJobApiResponse.jobTypeID != null) && (getJobApiResponse.jobTypeID != '')) {
																	jobTypeID = getJobApiResponse.jobTypeID;
																	ctx.setVariable("jobTypeID", jobTypeID);

																} else {
																	jobTypeID = "";
																}

																var outageSubtypeID;
																if ((getJobApiResponse.outageSubtypeID != undefined) && (getJobApiResponse.outageSubtypeID != null) && (getJobApiResponse.outageSubtypeID != '')) {
																	outageSubtypeID = getJobApiResponse.outageSubtypeID;
																	ctx.setVariable("outageSubtypeID", outageSubtypeID);

																} else {
																	outageSubtypeID = "";
																}

																var leadCallID;
																if ((getJobApiResponse.leadCallID != undefined) && (getJobApiResponse.leadCallID != null) && (getJobApiResponse.leadCallID != '')) {
																	leadCallID = getJobApiResponse.leadCallID;
																} else {
																	leadCallID = "";
																}

																var createdAt;
																if ((getJobApiResponse.createdAt != undefined) && (getJobApiResponse.createdAt != null) && (getJobApiResponse.createdAt != '')) {
																	createdAt = getJobApiResponse.createdAt;
																	ctx.setVariable("createdAt", createdAt);
																} else {
																	createdAt = "";
																}

																var causeCode;
																if ((getJobApiResponse.customFieldValuesExt != undefined) && (getJobApiResponse.customFieldValuesExt != null) && (getJobApiResponse.customFieldValuesExt != '')) {
																	if ((getJobApiResponse.customFieldValuesExt.cause != undefined) && (getJobApiResponse.customFieldValuesExt.cause != null) && (getJobApiResponse.customFieldValuesExt.cause != '')) {
																		causeCode = getJobApiResponse.customFieldValuesExt.cause;
																		ctx.setVariable("causeCode", causeCode);

																	} else {
																		causeCode = "";

																	}
																} else {
																	causeCode = "";

																}

																var ert;
																if ((getJobApiResponse.publishedEtr != undefined) && (getJobApiResponse.publishedEtr != null) && (getJobApiResponse.publishedEtr != '')) {
																	if ((getJobApiResponse.publishedEtr.value != undefined) && (getJobApiResponse.publishedEtr.value != null) && (getJobApiResponse.publishedEtr.value != '')) {
																		ert = getJobApiResponse.publishedEtr.value;
																		ctx.setVariable("ert", ert);
																	} else {
																		ert = "";
																	}
																} else {
																	ert = "";

																}

																var circuit;
																if ((getJobApiResponse.feederName != undefined) && (getJobApiResponse.feederName != null) && (getJobApiResponse.feederName != '')) {
																	circuit = getJobApiResponse.feederName;
																	ctx.setVariable("circuit", circuit);
																} else {
																	circuit = "";
																}

																var customerOut = getJobApiResponse.currentAffected;
																if (customerOut == undefined) {
																	customerOut = "";
																	ctx.setVariable("customerOut", customerOut);
																} else {
																	ctx.setVariable("customerOut", customerOut);
																}

																var address;
																if ((getJobApiResponse.address != undefined) && (getJobApiResponse.address != null) && (getJobApiResponse.address != '')) {
																	address = getJobApiResponse.address;
																	ctx.setVariable("address", address);
																} else {
																	address = "";

																}

																var latitude;
																var longitude;
																if ((getJobApiResponse.location != undefined) && (getJobApiResponse.location != null) && (getJobApiResponse.location != '')) {
																	if ((getJobApiResponse.location.coordinates != undefined) && (getJobApiResponse.location.coordinates != null) && (getJobApiResponse.location.coordinates != '')) {
																		longitude = getJobApiResponse.location.coordinates[0];
																		latitude = getJobApiResponse.location.coordinates[1];
																		ctx.setVariable("longitude", longitude);
																		ctx.setVariable("latitude", latitude);

																	} else {
																		longitude = "";
																		latitude = "";

																	}
																} else {
																	longitude = "";
																	latitude = "";
																}

																var crewId = crewIdList[i];
																ctx.setVariable("crewId_" + [i], crewId);

																var networkModelType = getJobApiResponse.networkModelType;
																if (networkModelType == undefined) {
																	networkModelType = "";
																	ctx.setVariable("networkModelType" + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID, networkModelType);
																} else {
																	ctx.setVariable("networkModelType" + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID, networkModelType);
																}

																networkModelTypeLength = networkModelType.toString().length;

																var deviceType;
																if ((getJobApiResponse.deviceType != undefined) && (getJobApiResponse.deviceType != null) && (getJobApiResponse.deviceType != '')) {
																	deviceType = getJobApiResponse.deviceType;
																	ctx.setVariable("deviceType", deviceType);
																} else {
																	deviceType = "";
																}

																//Get the 'contactMethod' and 'externalCallCodeID' values,Using the "leadCallID" from the job payload. Call GET /api/ServiceType/Electric/Call/{id}.

																//Start GET callAPI call

																//Start if leadCallID present in the jobAPI response
																if (leadCallID.length > 0) {
																	logger.info("Inside leadCallID present block");

																	var callUri = omsExternalURL + '/api/ServiceType/Electric/Call/' + leadCallID;
																	ctx.setVariable("leadCallID_value_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], leadCallID);
																	var getCallOptions = {
																		target: callUri,
																		sslClientProfile: 'omsapi_client_profile',
																		method: 'GET',
																		contentType: 'application/json',
																		headers: {
																			'osiApiToken': tokenValue
																		},

																	};
																	var info = " TargetURL :" + getCallOptions.target + "; Method :" + getCallOptions.method + "; Data :" + JSON.stringify(getCallOptions.data) + ". ";
																	try {
																		urlopen.open(getCallOptions, function(error, response) {
																			if (error) {
																				var errorinfo = "omsapi_v2_003:urlopen connect error with Get callAPI with error for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																				ilsctx.setVariable("errorDescription", errorinfo);
																				logger.error("omsapi_v2_003:urlopen connect error with Get callAPI with error for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																				session.reject("urlopen connect error with Get callAPI with error for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																			} else {
																				var responseStatusCode = response.statusCode;
																				if (responseStatusCode == 200) {
																					logger.info("callAPI response status code 200 for leadCallID " + leadCallID);
																					response.readAsBuffer(function(error, callResponseData) {
																						if (error) {
																							var errorinfo = "Failure in reading message from Get callAPI for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																							ilsctx.setVariable("errorDescription", errorinfo);
																							logger.error("Failure in reading message from Get callAPI for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																							session.reject("Failure in reading message from Get callAPI for leadCallID and jobDisplayID  " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																						} else {
																							var ctx = session.name("crewList") || session.createContext("crewList");
																							var getCallApiResponse = JSON.parse(callResponseData);
																							ctx.setVariable("callResponseData_" + leadCallID + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], JSON.stringify(getCallApiResponse));
																							var contactMethod;
																							contactMethod = getCallApiResponse.contactMethod;
																							if (contactMethod == undefined) {
																								contactMethod = "";
																								ctx.setVariable("contactMethod_" + leadCallID + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], contactMethod);
																							} else {
																								ctx.setVariable("contactMethod_" + leadCallID + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], contactMethod);
																							}

																							contactMethodLength = contactMethod.toString().length;

																							//ADO199296 starts
																							if ((getCallApiResponse.address !== undefined) && (getCallApiResponse.address !== null) && (getCallApiResponse.address !== '')) {
																								leadCallAddress = getCallApiResponse.address;
																								ctx.setVariable("leadCallAddress", leadCallAddress);
																							} else {
																								ctx.setVariable("leadCallAddress", "");
																							}
																							//ADO199296 ends

																							var callCode;
																							callCode = getCallApiResponse.externalCallCodeID;
																							if (callCode == undefined) {
																								callCode = "";
																								ctx.setVariable("callCode_" + leadCallID + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], callCode);
																							} else {
																								ctx.setVariable("callCode_" + leadCallID + "_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], callCode);
																							}

																							//Lookup Service API calls for jobType,jobSubType,callSource,jobStatus,crewAssignmentStatus and extent fields

																							// Start lookupServiceAPI call

																							//LookupMessage
																							var lookupMessage = {
																								"lookupReq": {
																									"type": [{
																										"name": "jobTypes",
																										"id": jobTypeID
																									},
																									{
																										"name": "outageSubtypes",
																										"id": outageSubtypeID
																									},
																									{
																										"name": "contactMethodTypes",
																										"status": contactMethod
																									},
																									{
																										"name": "jobTypes.workflows",
																										"id": jobTypeID,
																										"status": status
																									},
																									{
																										"name": "workType.workflows",
																										"id": getCrewAssignmentApiResponse.data[j].workTypeID,
																										"status": getCrewAssignmentApiResponse.data[j].status
																									},
																									{
																										"name": "networkModelTypeLabels",
																										"status": networkModelType
																									}

																									]
																								}
																							}
																							var lookupServiceResponse = {
																								target: lookupURL,
																								method: 'POST',
																								contentType: 'application/json',
																								data: lookupMessage
																							};
																							ctx.setVariable("lookupRequest_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], lookupMessage);
																							var info = " TargetURL :" + lookupServiceResponse.target + "; Method :" + lookupServiceResponse.method + "; Data :" + JSON.stringify(lookupServiceResponse.data) + ". ";
																							try {
																								urlopen.open(lookupServiceResponse, function(error, response) {
																									if (error) {
																										var errorinfo = "omsapi_v2_004:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																										ilsctx.setVariable("errorDescription", errorinfo);
																										logger.error("omsapi_v2_004:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																										session.reject("urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));

																									} else {
																										var responseStatusCode = response.statusCode;
																										if (responseStatusCode == 200) {
																											logger.info("lookupServiceAPI response status code 200 for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i]);
																											response.readAsBuffer(function(error, responseData) {
																												if (error) {
																													var errorinfo = "Failure in reading message to lookupServiceAPI Response for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																													ilsctx.setVariable("errorDescription", errorinfo);
																													logger.error("Failure in reading message to lookupServiceAPI Response for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																													session.reject("Failure in reading message to lookupServiceAPI Response for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																												} else {
																													var ctx = session.name("crewList") || session.createContext("crewList");
																													var lookupResponse = JSON.parse(responseData);
																													ctx.setVariable("lookupResponse_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], lookupResponse);
																													logger.info("lookupResponse" + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(lookupResponse));

																													var jobType;
																													if (lookupResponse.lookupRep.type[0].result == 0) {
																														if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
																															jobType = lookupResponse.lookupRep.type[0].label;
																															ctx.setVariable("jobType", jobType);
																														} else {
																															jobType = "";
																														}
																													} else {
																														jobType = "";
																													}
																													var jobSubType;
																													if (lookupResponse.lookupRep.type[1].result == 0) {
																														if ((lookupResponse.lookupRep.type[1].label != undefined) && (lookupResponse.lookupRep.type[1].label != null) && (lookupResponse.lookupRep.type[1].label != '')) {
																															jobSubType = lookupResponse.lookupRep.type[1].label;
																															ctx.setVariable("jobSubType", jobSubType);
																														} else {
																															jobSubType = "";
																														}
																													} else {
																														jobSubType = "";
																													}
																													var callSource;
																													if ((contactMethod.toString().length > 0) && (lookupResponse.lookupRep.type[2].result == 0)) {
																														if ((lookupResponse.lookupRep.type[2].label != undefined) && (lookupResponse.lookupRep.type[2].label != null) && (lookupResponse.lookupRep.type[2].label != '')) {
																															callSource = lookupResponse.lookupRep.type[2].label;
																															ctx.setVariable("callSource", callSource);
																														} else {
																															callSource = "";
																														}
																													} else {
																														callSource = "";
																													}
																													var jobStatus;
																													if (lookupResponse.lookupRep.type[3].result == 0) {
																														if ((lookupResponse.lookupRep.type[3].label != undefined) && (lookupResponse.lookupRep.type[3].label != null) && (lookupResponse.lookupRep.type[3].label != '')) {
																															jobStatus = lookupResponse.lookupRep.type[3].label;
																															ctx.setVariable("jobStatus", jobStatus);
																														} else {
																															jobStatus = "";
																														}
																													} else {
																														jobStatus = "";
																													}

																													var crewAssignmentStatus;
																													if (lookupResponse.lookupRep.type[4].result == 0) {
																														if ((lookupResponse.lookupRep.type[4].label != undefined) && (lookupResponse.lookupRep.type[4].label != null) && (lookupResponse.lookupRep.type[4].label != '')) {
																															crewAssignmentStatus = lookupResponse.lookupRep.type[4].label;
																															ctx.setVariable("crewAssignmentStatus", crewAssignmentStatus);
																														} else {
																															crewAssignmentStatus = "";
																														}
																													} else {
																														crewAssignmentStatus = "";
																													}

																													var extent;
																													if ((networkModelType.toString().length > 0) && (lookupResponse.lookupRep.type[5].result == 0)) {
																														if ((lookupResponse.lookupRep.type[5].label != undefined) && (lookupResponse.lookupRep.type[5].label != null) && (lookupResponse.lookupRep.type[5].label != '')) {
																															extent = lookupResponse.lookupRep.type[5].label;
																															ctx.setVariable("extent", extent);
																														} else {
																															extent = "";
																														}
																													} else {
																														extent = "";
																													}

																													// Final payload structure should be sent to client applications
																													var jobObject = {

																														"jobId": jobId,
																														"jobDisplayId": jobDisplayId,
																														"jobType": jobType,
																														"jobSubType": jobSubType,
																														"outageDate": createdAt,
																														"callSource": callSource,
																														"causeCode": causeCode,
																														"etr": ert,
																														"circuit": circuit,
																														"customerOut": customerOut,
																														"address": address,
																														"longitude": longitude,
																														"latitude": latitude,
																														"crewId": crewId,
																														"jobStatus": jobStatus,
																														"crewAssignmentStatus": crewAssignmentStatus,
																														"extent": extent,
																														"deviceType": deviceType,
																														"callCode": callCode,
																														"deviceOperatingVoltage": deviceOperatingVoltage
																													};
																													if (getCallApiResponse && getCallApiResponse.address) {
																														if ((getCallApiResponse.address == undefined) && (getCallApiResponse.address == null) && (getCallApiResponse.address == '')) {
																															jobObject.leadCallAddress = "";
																														}
																														else {
																															leadCallAddress = getCallApiResponse.address
																															jobObject.leadCallAddress = leadCallAddress;
																														}
																													}

																													else {
																														jobObject.leadCallAddress = "";
																													}

																													ctx1.setVariable('exitDescription', exitDescription);
																													arrayList.push(jobObject);
																													ctx.setVariable("arrayList", arrayList);

																												}
																											});
																										} else {
																											logger.error("lookupServiceAPI response status code is not 200 for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + responseStatusCode);
																											var exitinfo = "lookupServiceAPI response status code is not 200 for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + responseStatusCode;
																											ctx1.setVariable("exitDescription", exitinfo);
																										}

																									}
																								});
																							}
																							catch (error) {
																								var errorinfo = "omsapi_v2_004:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																								ilsctx.setVariable("errorDescription", errorinfo);
																								logger.error("omsapi_v2_004:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																								session.reject("urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																							}

																							//End lookupServiceAPI call

																						}

																					});
																				} else if ((responseStatusCode == 404) || (responseStatusCode == 403) || (responseStatusCode == 401) || (responseStatusCode == 400)) {

																					response.readAsBuffer(function(error, callResponseData) {
																						if (error) {
																							var errorinfo = "Failure in reading message from Get callAPI for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																							ilsctx.setVariable("errorDescription", errorinfo);
																							logger.error("Failure in reading message from Get callAPI for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																							session.reject("Failure in reading message from Get callAPI for leadCallID and jobDisplayID  " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																						} else {
																							logger.error("callAPI response status code for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " responseStatusCode is " + responseStatusCode + " and response is " + callResponseData);
																							var exitinfo = "callAPI response status code for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " responseStatusCode is " + responseStatusCode + " and response is " + callResponseData;
																							ctx1.setVariable("exitDescription", exitinfo);
																							//Call Function
																							var test = lookupFunction(jobTypeID, outageSubtypeID, status, getCrewAssignmentApiResponse.data[j].workTypeID, getCrewAssignmentApiResponse.data[j].status, networkModelType, getCrewAssignmentApiResponse.data[j].jobDisplayID, crewIdList[i], arrayList, lookupURL, jobId, createdAt, causeCode, ert, circuit, customerOut, address, longitude, latitude, deviceType, deviceOperatingVoltage, leadCallAddress);

																						}

																					});

																				} else {
																					response.readAsBuffer(function(error, callResponseData) {
																						if (error) {
																							var errorinfo = "Failure in reading message from Get callAPI for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																							ilsctx.setVariable("errorDescription", errorinfo);
																							logger.error("Failure in reading message from Get callAPI for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																							session.reject("Failure in reading message from Get callAPI for leadCallID and jobDisplayID  " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																						} else {
																							logger.error("callAPI response status code for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " responseStatusCode is " + responseStatusCode + " and response is " + callResponseData);
																							var exitinfo = "callAPI response status code for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " responseStatusCode is " + responseStatusCode + " and response is " + callResponseData;
																							ctx1.setVariable("exitDescription", exitinfo);
																						}

																					});
																				}

																			}
																		});
																	}
																	catch (error) {
																		var errorinfo = "omsapi_v2_003:urlopen connect error with Get callAPI with error for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																		ilsctx.setVariable("errorDescription", errorinfo);
																		logger.error("omsapi_v2_003:urlopen connect error with Get callAPI with error for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																		session.reject("urlopen connect error with Get callAPI with error for leadCallID and jobDisplayID " + leadCallID + " " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																	}
																	//End GET callAPI call
																}
																//End if leadCallID present in the jobAPI response

																//Start if leadCallID is not present in the jobAPI response
																else {
																	logger.info("Inside leadCallID not present block");
																	var exitinfo = "leadCallID is not present ";
																	ctx1.setVariable("exitDescription", exitinfo);
																	ctx.setVariable("leadCallID_value_" + getCrewAssignmentApiResponse.data[j].jobDisplayID + "_" + crewIdList[i], leadCallID);

																	//Call Function
																	var test = lookupFunction(jobTypeID, outageSubtypeID, status, getCrewAssignmentApiResponse.data[j].workTypeID, getCrewAssignmentApiResponse.data[j].status, networkModelType, getCrewAssignmentApiResponse.data[j].jobDisplayID, crewIdList[i], arrayList, lookupURL, jobId, createdAt, causeCode, ert, circuit, customerOut, address, longitude, latitude, deviceType, deviceOperatingVoltage);

																}
																//End if leadCallID is not present in the jobAPI response('else' block)

															}
														});

													}
													// 'Job' not found reason code 404
													else if (responseStatusCode == 404) {
														logger.info("Job not found for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i]);
														var jobNotFoundobject = {
															"crewId": crewIdList[i],
														};
														var exitinfo = "Job not found for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + jobNotFoundobject;
														ctx1.setVariable("exitDescription", exitinfo);
														arrayList.push(jobNotFoundobject);
														ctx.setVariable("arrayList", arrayList);

													} else {
														response.readAsBuffer(function(error, jobResponseData) {
															if (error) {
																var errorinfo = "Failure in reading message from Get jobAPI for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																logger.error("Failure in reading message from Get jobAPI for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
																session.reject("Failure in reading message from Get jobAPI for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
															} else {
																var ctx = session.name("crewList") || session.createContext("crewList");
																ctx.setVariable("responseStatusCode", responseStatusCode);
																var data = jobResponseData;
																ctx.setVariable("responseOfAPI", data.toString());
																logger.error("jobAPI response status code is not 200/404 for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " responseStatusCode is " + responseStatusCode + " and response is " + jobResponseData);
																var exitinfo = "jobAPI response status code is not 200/404 for jobDisplayID and crewId " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " responseStatusCode is " + responseStatusCode + " and response is " + jobResponseData;
																ctx1.setVariable("exitDescription", exitinfo);
															}
														});

													}

												}

											});
										}
										catch (error) {
											var errorinfo = "omsapi_v2_002:urlopen connect error with Get jobAPI with error for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
											ilsctx.setVariable("errorDescription", errorinfo);
											logger.error("omsapi_v2_002:urlopen connect error with Get jobAPI with error for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
											session.reject("urlopen connect error with Get jobAPI with error for jobDisplayID and crewID " + getCrewAssignmentApiResponse.data[j].jobDisplayID + " " + crewIdList[i] + " " + JSON.stringify(error));
										}
										// End GET jobAPI call

									}
									// End If found and 'Total' field value is greater than '0' from the result set for the crewId('for' loop)

								}
								//End If found and 'Total' field value is greater than '0' from the result set for the crewId

							}
						});

					}
					// 'CrewId' not found reason code 404
					else if (responseStatusCode == 404) {
						logger.info("CrewId not found " + crewIdList[i]);

						var crewNotFoundObject = {
							"crewId": crewIdList[i],
							"errorCode": "404",
							"errorDescription": "Crew not found"
						};
						var exitinfo = crewNotFoundObject;
						ctx1.setVariable("exitDescription", exitinfo);
						arrayList.push(crewNotFoundObject);
						ctx.setVariable("arrayList", arrayList);

					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in reading message from Get crewAssignmentAPI for crewId " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								logger.error("Failure in reading message from Get crewAssignmentAPI for crewId " + crewIdList[i] + " " + JSON.stringify(error));
								session.reject("Failure in reading message from Get crewAssignmentAPI for crewId " + crewIdList[i] + " " + JSON.stringify(error));
							} else {
								var ctx = session.name("crewList") || session.createContext("crewList");
								ctx.setVariable("responseStatusCode", responseStatusCode);
								var data = responseData;
								logger.info("Data " + data);
								ctx.setVariable("responseOfAPI", data.toString());
								logger.error("crewAssignmentAPI response status code is not 200/404 for crewId " + crewIdList[i] + " responseStatusCode is " + responseStatusCode + " and response is " + data);
								var exitinfo = "crewAssignmentAPI response status code is not 200/404 for crewId " + crewIdList[i] + " responseStatusCode is " + responseStatusCode + " and response is " + data;
								ctx1.setVariable("exitDescription", exitinfo);
							}
						});
					}

				}
			});
		}
		catch (error) {
			var errorinfo = "omsapi_v2_001:urlopen connect error with Get crewAssignmentAPI with error for crewId " + crewIdList[i] + " , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			logger.error("omsapi_v2_001:urlopen connect error with Get crewAssignmentAPI with error for crewId " + crewIdList[i] + " " + JSON.stringify(error));
			session.reject("urlopen connect error with Get crewAssignmentAPI with error for crewId " + crewIdList[i] + " " + JSON.stringify(error));
		}
		// End GET crewAssigmentAPI call
	}
	// End of 'for' loop for iterations of crewId/crewIds in the input request

}
// End if loop, crewId/crewId's are present in input request
else {
	ctx.setVariable("responseStatusCode", 400);
	var errorinfo = "omsapi_v2_006:CrewId not found in the input request 400 , details are : " + info + "; error info :" + error;
	ilsctx.setVariable("errorDescription", errorinfo);
	logger.error("omsapi_v2_006:CrewId not found in the input request");
	session.reject("CrewId not found in the input request");
}

//Start Function to retrieve Lookup values and structure the response
function lookupFunction(jobTypeID, outageSubtypeID, status, crewWorkTypeID, crewStatus, networkModelType, currentJobDisplayID, currentCrewId, arrayList, lookupURL, jobId, createdAt, causeCode, ert, circuit, customerOut, address, longitude, latitude, deviceType, deviceOperatingVoltage, leadCallAddress) {
	// Lookup Message
	var lookupMessage = {
		"lookupReq": {
			"type": [{
				"name": "jobTypes",
				"id": jobTypeID
			},
			{
				"name": "outageSubtypes",
				"id": outageSubtypeID
			},
			{
				"name": "jobTypes.workflows",
				"id": jobTypeID,
				"status": status
			},
			{
				"name": "workType.workflows",
				"id": crewWorkTypeID,
				"status": crewStatus
			},
			{
				"name": "networkModelTypeLabels",
				"status": networkModelType
			}

			]
		}
	}

	var lookupServiceResponse = {
		target: lookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: lookupMessage
	};
	ctx.setVariable("lookupRequest_" + currentJobDisplayID + "_" + currentCrewId, lookupMessage);
	var info = " TargetURL :" + lookupServiceResponse.target + "; Method :" + lookupServiceResponse.method + "; Data :" + JSON.stringify(lookupServiceResponse.data) + ". ";
	try {
		urlopen.open(lookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "omsapi_v2_005:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapi_v2_005:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " " + JSON.stringify(error));
				session.reject("urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " " + JSON.stringify(error));

			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					logger.info("lookupServiceAPI response status code 200 for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId);
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "Failure in reading message to lookupServiceAPI Response for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							logger.error("Failure in reading message to lookupServiceAPI Response for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " " + JSON.stringify(error));
							session.reject("Failure in reading message to lookupServiceAPI Response for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " " + JSON.stringify(error));
						} else {
							var ctx1 = session.name("ILS") || session.createContext("ILS");
							ctx1.setVariable('exitDescription', exitDescription);
							var ctx = session.name("crewList") || session.createContext("crewList");
							var lookupResponse = JSON.parse(responseData);
							ctx.setVariable("lookupResponse_" + currentJobDisplayID + "_" + currentCrewId, lookupResponse);
							logger.info("lookupResponse" + currentJobDisplayID + " " + currentCrewId + " " + JSON.stringify(lookupResponse));
							var jobType;
							if (lookupResponse.lookupRep.type[0].result == 0) {
								if ((lookupResponse.lookupRep.type[0].label != undefined) && (lookupResponse.lookupRep.type[0].label != null) && (lookupResponse.lookupRep.type[0].label != '')) {
									jobType = lookupResponse.lookupRep.type[0].label;
									ctx.setVariable("jobType", jobType);
								} else {
									jobType = "";
								}
							} else {
								jobType = "";
							}
							var jobSubType;
							if (lookupResponse.lookupRep.type[1].result == 0) {
								if ((lookupResponse.lookupRep.type[1].label != undefined) && (lookupResponse.lookupRep.type[1].label != null) && (lookupResponse.lookupRep.type[1].label != '')) {
									jobSubType = lookupResponse.lookupRep.type[1].label;
									ctx.setVariable("jobSubType", jobSubType);
								} else {
									jobSubType = "";
								}
							} else {
								jobSubType = "";
							}

							var jobStatus;
							if (lookupResponse.lookupRep.type[2].result == 0) {
								if ((lookupResponse.lookupRep.type[2].label != undefined) && (lookupResponse.lookupRep.type[2].label != null) && (lookupResponse.lookupRep.type[2].label != '')) {
									jobStatus = lookupResponse.lookupRep.type[2].label;
									ctx.setVariable("jobStatus", jobStatus);
								} else {
									jobStatus = "";
								}
							} else {
								jobStatus = "";
							}

							var crewAssignmentStatus;
							if (lookupResponse.lookupRep.type[3].result == 0) {
								if ((lookupResponse.lookupRep.type[3].label != undefined) && (lookupResponse.lookupRep.type[3].label != null) && (lookupResponse.lookupRep.type[3].label != '')) {
									crewAssignmentStatus = lookupResponse.lookupRep.type[3].label;
									ctx.setVariable("crewAssignmentStatus", crewAssignmentStatus);
								} else {
									crewAssignmentStatus = "";
								}
							} else {
								crewAssignmentStatus = "";
							}

							var extent;
							if ((networkModelType.toString().length > 0) && (lookupResponse.lookupRep.type[4].result == 0)) {
								if ((lookupResponse.lookupRep.type[4].label != undefined) && (lookupResponse.lookupRep.type[4].label != null) && (lookupResponse.lookupRep.type[4].label != '')) {
									extent = lookupResponse.lookupRep.type[4].label;
									ctx.setVariable("extent", extent);
								} else {
									extent = "";
								}
							} else {
								extent = "";
							}

							// Final payload structure should be sent to client applications
							var jobObject = {

								"jobId": jobId,
								"jobDisplayId": jobDisplayId,
								"jobType": jobType,
								"jobSubType": jobSubType,
								"outageDate": createdAt,
								"callSource": "",
								"causeCode": causeCode,
								"etr": ert,
								"circuit": circuit,
								"customerOut": customerOut,
								"address": address,
								"longitude": longitude,
								"latitude": latitude,
								"crewId": currentCrewId,
								"jobStatus": jobStatus,
								"crewAssignmentStatus": crewAssignmentStatus,
								"extent": extent,
								"deviceType": deviceType,
								"callCode": "",
								"deviceOperatingVoltage": deviceOperatingVoltage

							};

							if (leadCallAddress) {
								if ((leadCallAddress == undefined) && (leadCallAddress == null) && (leadCallAddress == '')) {
									jobObject.leadCallAddress = "";
								}
								else {
									jobObject.leadCallAddress = leadCallAddress;
								}
							}
							else {
								jobObject.leadCallAddress = "";
							}

							arrayList.push(jobObject);
							ctx.setVariable("arrayList", arrayList);

						}
					});
				} else {
					logger.error("lookupServiceAPI response status code is not 200 for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " " + responseStatusCode);
					var exitinfo = "lookupServiceAPI response status code is not 200 for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " " + responseStatusCode;
					ctx1.setVariable("exitDescription", exitinfo);
				}

			}
		});
	}
	catch (error) {
		var errorinfo = "omsapi_v2_005:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapi_v2_005:urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " " + JSON.stringify(error));
		session.reject("urlopen connect error with lookupServiceAPI for jobDisplayID and crewId " + currentJobDisplayID + " " + currentCrewId + " " + JSON.stringify(error));
	}
}
//End lookupserviceAPI call
//End Function
