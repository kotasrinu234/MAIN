var sm = require('service-metadata');
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.getJobByCrewListEntryDescription;
var apiName = session.parameters.getJobByCrewListApiName;
var messageType = session.parameters.messageType;
ctx.setVariable("messageType", messageType);
ctx.setVariable("apiName", apiName);
ctx.setVariable('entryDescription', entryDescription);
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var id = uuidv4()
ctx.setVariable("correlationID", id);
var incomingUrl = sm.getVar('var://service/URI');
var getQueryParams = (params, url) => {
	let href = url;
	// this is an expression to get query strings
	let regexp = new RegExp('[?&]' + params + '=([^&#]*)', 'i');
	let qString = regexp.exec(href);
	return qString ? qString[1] : null;
};
var crewIds = getQueryParams('crewIds', incomingUrl);
var crewIdList;
if (crewIds.includes("%2C")) {
	crewIdList = crewIds.split("%2C");
} else if (crewIds.includes(",")) {
	crewIdList = crewIds.split(",");
} else {
	crewIdList = [crewIds];
}
if (crewIdList) {
	if (crewIdList !== undefined || crewIdList !== null || crewIdList !== '') {
		ctx.setVariable("crewDisplayIDList", crewIdList);
	}
}
ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
