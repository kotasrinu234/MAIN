//Final Response payload to OMS
var ctx = session.name("crewList") || session.createContext("crewList");
var responseStatusCode = ctx.getVariable("responseStatusCode");
var response = ctx.getVariable("responseOfAPI");
var ilsctx = session.name('omsApiv2') || session.createContext('omsApiv2');
var logger = console.options({
	'category': 'all'
});

var arrayList = ctx.getVariable("arrayList");
var jobs = {};
var job = {};

if (arrayList != undefined) {
	jobs["jobs"] = arrayList;
	job["job"] = jobs;
	session.output.write(job);
}
else {
	var errorinfo = "Error Response received " + responseStatusCode + " and response data is " + response;
	ilsctx.setVariable("errorDescription", errorinfo);
	session.reject("Error Response received " + responseStatusCode + " and response data is " + response);
}
