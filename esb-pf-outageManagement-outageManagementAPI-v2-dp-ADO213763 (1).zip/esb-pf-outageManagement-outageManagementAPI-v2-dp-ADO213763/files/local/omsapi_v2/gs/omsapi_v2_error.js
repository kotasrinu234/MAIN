var ctx = session.name("Crew_Job") || session.createContext("Crew_Job");
var hm = require('header-metadata');
var sm = require('service-metadata');
var Flag = ctx.getVariable("notFound");
var msgId = ctx.getVariable("msgId");
var leadAssignmentIDError = ctx.getVariable("leadAssignmentIDError");
var leadAssignmentError = ctx.getVariable("leadAssignmentError");
var Id_Req = ctx.getVariable("Id_Req");
var error = ctx.getVariable("error");
var errorCode = sm.getVar('var://service/error-code');
var responseStatusCode = ctx.getVariable("responseStatusCode");
var ctx1 = session.name("omsApiv_2") || session.createContext("omsApiv_2");
var responseStatus_Code = ctx1.getVariable("responseStatusCode");
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var ctxaaa = session.name("aaa") || session.createContext("aaa");
var errorStatusCode = ctxaaa.getVar("customErrorCode");
var errorPhrase = ctxaaa.getVar("customErrorMessage");
var errorInfo = ilsctx.getVariable("errorDescription");
var ilserrorCode = ilsctx.getVar("errorStatusCode");
var errctx = session.name("ILS") || session.createContext("ILS");
var errexitctx = session.name("ILSExit") || session.createContext("ILSExit");
var jobType_jobSubType = "";
var crewDisplayID_employeeDisplayID_crewStatus = "";
var longitude_latitude = "";
if (errexitctx.getVar("crewStatus") == null || errexitctx.getVar("crewStatus") == '' || errexitctx.getVar("crewStatus") == undefined) {
}
else {
	var crewStatus = errexitctx.getVar("crewStatus");
}
if (errexitctx.getVar("employeeDisplayID") == null || errexitctx.getVar("employeeDisplayID") == '' || errexitctx.getVar("employeeDisplayID") == undefined) {
}
else {
	var employeeDisplayID = errexitctx.getVar("employeeDisplayID");
}
if (errctx.getVar("crewDisplayID") == null || errctx.getVar("crewDisplayID") == '' || errctx.getVar("crewDisplayID") == undefined) {
}
else {
	var crewDisplayID = errctx.getVar("crewDisplayID");
}

if (errctx.getVar("jobType") == null || errctx.getVar("jobType") == '' || errctx.getVar("jobType") == undefined) {
}
else {
	var jobType = errctx.getVar("jobType");
}
if (errctx.getVar("jobSubType") == null || errctx.getVar("jobSubType") == '' || errctx.getVar("jobSubType") == undefined) {
}
else {
	var jobSubType = errctx.getVar("jobSubType");
}
if (errctx.getVar("latitude") == null || errctx.getVar("latitude") == '' || errctx.getVar("latitude") == undefined) {
}
else {
	var latitude = errctx.getVar("latitude");
}
if (errctx.getVar("longitude") == null || errctx.getVar("longitude") == '' || errctx.getVar("longitude") == undefined) {
}
else {
	var longitude = errctx.getVar("longitude");
}
var errormessage = sm.getVar('var://service/error-message');
jobType_jobSubType = (jobSubType || '') + ":" + (jobType || '');
crewDisplayID_employeeDisplayID_crewStatus = (crewDisplayID || '') + ":" + (employeeDisplayID || '') + ":" + (crewStatus || '');
longitude_latitude = (latitude || '') + ":" + (longitude || '');
errctx.setVar("longitude:latitude", longitude_latitude);
errctx.setVar("jobType:jobSubType", jobType_jobSubType);
errctx.setVar("crewDisplayID:employeeDisplayID:crewStatus", crewDisplayID_employeeDisplayID_crewStatus);
var errDtl = {};
var errCode = '';
if (ilserrorCode == null || ilserrorCode == '' || ilserrorCode == undefined) {
	errCode = errorCode;
}
else {
	hm.current.statusCode = ilserrorCode;
	errCode = ilserrorCode;
}
errctx.setVar("errCode", errCode);
if (errorInfo) {
	if (errorInfo !== undefined || errorInfo !== null || errorInfo !== '') {
		errDtl.errorMessage = errorInfo;
	}
	else {
		errDtl.errorMessage = errormessage;
	}
}
else {
	if (errorStatusCode !== null || errorStatusCode !== '' || errorStatusCode !== undefined) {
		errDtl.errorStatusCode = errorStatusCode;
	}
	if (errorPhrase !== null || errorPhrase !== '' || errorPhrase !== undefined) {
		errDtl.errorPhrase = errorPhrase;
	}
	if (errormessage !== null || errormessage !== '' || errormessage !== undefined) {
		errDtl.errorMessage = errormessage;
	}
}
errctx.setVariable("errorInfo", errDtl);
session.output.write(errDtl);
if (((responseStatusCode == '404') || (responseStatusCode == '400')) && (Flag == 'True')) {
	var error_obj = {};
	if (Id_Req == 'True') {
		error_obj.msgId = msgId;
	}
	error_obj.errorCode = error;
	error_obj.errorDescription = sm.getVar('var://service/error-message');
	//session.output.write(error_obj);
	logger.debug("call api error " + JSON.stringify(error_obj));
}
else if ((responseStatusCode == '404') && (notFound == 'True')) {
	var errormessage = sm.getVar('var://service/error-message');
}
else {
	var obj = {};
	if (leadAssignmentIDError == 'True') {
		obj.errorMessage = 'leadAssignmentID is not present Jobresponse payload';
	} else if (leadAssignmentError == 'True') {
		obj.errorMessage = 'leadAssignmentWorkTypeID is not present Jobresponse payload';
	} else if (responseStatusCode == '404') {
		//logger.error("Inside 404 ELSE IF");
		var errormessage = sm.getVar('var://service/error-message');
		obj.errorMessage = sm.getVar('var://service/error-message');
	} else if ((errorCode == '0x00d30003') && (responseStatusCode == '400')) {
		var errormessage = sm.getVar('var://service/error-message');
		obj.errorMessage = sm.getVar('var://service/error-message');
	} else if (responseStatusCode == '400') {
		//logger.error("Inside 400 ELSE IF");
		var errormessage = sm.getVar('var://service/error-message');
		obj.errorMessage = sm.getVar('var://service/error-message');
	} else if (responseStatus_Code == '400') {
		// logger.error("Inside 400 ++");
		var errormessage = sm.getVar('var://service/error-message');
		obj.errorMessage = sm.getVar('var://service/error-message');
	} else if (errormessage == 'Rejected by Policy ') {
		//logger.error("Inside 401 ++");
		/* var errormessage = sm.getVar('var://service/error-message');
		  hm.current.statusCode = '400' + " " + errormessage;
		  obj.errorMessage = sm.getVar('var://service/error-message');*/

		//logger.error("+++++++errormessage" + errormessage);
	} else {
		var errormessage = sm.getVar('var://service/error-message');
		//logger.error("Inside 500 ELSE ");
		obj.errorMessage = sm.getVar('var://service/error-message');
	}
	var errormessage = sm.getVar('var://service/error-message');
	var jsonerrorcode = sm.getVar('var://service/error-code');
	if (errormessage == 'Invalid JSON format' || jsonerrorcode == '0x00c30025' || errormessage == 'Invalid string syntax' || errormessage == 'Invalid object syntax' || errormessage == 'Invalid JSON property value') {
		logger.error("omsapi_v2_013 Input Schema Validation Error");

	}
	obj.errorHeaders = sm.getVar('var://service/error-headers');
	obj.errorCode = sm.getVar('var://service/error-code');
	obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
	//logger.error("obj.errorHeaders" + obj.errorHeaders);
	//session.output.write(obj);

	//create Job API
	var error_Code = sm.getVar('var://service/error-code');
	if ((responseStatus_Code == '404') || (responseStatus_Code == '400')) {
		var obj1 = {};
		obj1.errorMessage = sm.getVar('var://service/error-message');
		obj1.errorCode = responseStatus_Code;
		//session.output.write(obj1);
		logger.debug("Insdie error +++++r " + JSON.stringify(obj1));
	}
}
