var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var url = session.parameters.lookUpURL;
//var url = "http://localhost:8080/lookup"; 

function doLookup(arrObj, lookupCtx, uri) {
	//console.error("array length " + arrObj.length);
	var request = {};
	request.type = arrObj;
	var lookupUrl = url;
	var options = {
		target: lookupUrl,
		method: 'post',
		contentType: 'application/json',
		data: { "lookupReq": request }
	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		// open connection to target
		urlopen.open(options, function(error, response) {
			var ctx = session.name('omsApiv2') || session.createContext('omsApiv2');
			if (error) {
				var errorinfo = "urlopen error, details are : " + info + "; error info :" + error;
				ctx.setVariable("errorStatusCode", error.errorCode);
				ctx.setVariable("errorMessage", error.errorMessage);
				ctx.setVariable("errorDescription", errorinfo);
				ctx.setVariable("customErrorCode", error.errorCode);
				ctx.setVariable("customErrorMessage", error.errorMessage);
				ctx.setVariable("customReasonPhrase", error.errorMessage);
				session.output.write("urlopen error: " + JSON.stringify(errorinfo));
				session.reject(error.errorMessage);

			} else {
				var responseStatusCode = response.statusCode;
				var reasonPhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						var ctx = session.name('omsApiv2') || session.createContext('omsApiv2');
						ctx.setVariable('lookupResponseData', responseData);
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "readAsBuffer error:, details are : " + info + "; error info :" + error;
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", reasonPhrase);
							ctx.setVariable("errorDescription", errorinfo);
							session.output.write("readAsBuffer error: " + JSON.stringify(errorinfo));
						} else {
							var lookupResponse = responseData.lookupRep.type;
							ctx.setVariable(lookupCtx + "_lookup", lookupResponse);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "readAsBuffer error:, details are : " + info + "; error info :" + error;
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", reasonPhrase);
							ctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message" + JSON.stringify(errorinfo));

						} else {
							var errorinfo = "readAsBuffer error:, details are : " + info + "; error info :" + responseData;
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", reasonPhrase);
							ctx.setVariable("errorDescription", errorinfo);
							logger.error("response received " + responseStatusCode + " " + responseData);
							session.output.write("response received " + responseStatusCode + " " + responseData);

						}
					});


				}
			}
		});
	}
	catch (error) {
		var errorinfo = "urlopen error, details are : " + info + "; error info :" + error;
		ctx.setVariable("errorStatusCode", error.errorCode);
		ctx.setVariable("errorMessage", error.errorMessage);
		ctx.setVariable("errorDescription", errorinfo);
		ctx.setVariable("customErrorCode", error.errorCode);
		ctx.setVariable("customErrorMessage", error.errorMessage);
		ctx.setVariable("customReasonPhrase", error.errorMessage);
		session.output.write("urlopen error: " + JSON.stringify(errorinfo));
		session.reject(error.errorMessage);
	}
}//end of function 

module.exports = doLookup;
