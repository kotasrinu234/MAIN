var sm = require('service-metadata');
var ctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
var entryDescription = session.parameters.getCrewMemberEntryDescription;
var messageType = session.parameters.messageType;
var apiName = session.parameters.getCrewMemberApiName;
if (apiName !== undefined || apiName !== null || apiName !== '') {
	ctx.setVariable("apiName", apiName);
}
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable("entryDescription", entryDescription);
}
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var id = uuidv4()
ctx.setVariable("correlationID", id)
var URL = sm.getVar('var://service/URI');
var start = URL.lastIndexOf('/');
var empId = URL.substring(start + 1);
if (empId) {
	if (empId !== undefined || empId !== null || empId !== '') {
		ctx.setVariable("crewDisplayID", empId)
	}
}
ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
