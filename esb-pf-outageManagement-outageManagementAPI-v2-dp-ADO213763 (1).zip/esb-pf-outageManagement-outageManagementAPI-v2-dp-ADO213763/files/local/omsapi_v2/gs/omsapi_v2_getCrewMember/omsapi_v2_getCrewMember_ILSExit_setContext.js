var ctx = session.name('ILSExit') || session.createContext('ILSExit');
var ctx1 = session.name('omsApiv2') || session.createContext('omsApiv2');
var ilsctx = session.name('ILS') || session.createContext('ILS');
var exitDescription = session.parameters.getCrewMemberExitDescription;
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
var crewAssignmentStatus = ctx1.getVar("crewAssignmentStatus");
var getCrewApiResponse = ctx1.getVar("getCrewApiResponse");
var initialActiveAssignmentCount = ctx1.getVar("initialActiveAssignmentCount");
if (getCrewApiResponse) {
	if (getCrewApiResponse.customFieldValuesExt) {
		if (getCrewApiResponse.customFieldValuesExt.employeeid) {
			var employeeId = getCrewApiResponse.customFieldValuesExt.employeeid;
			if (employeeId !== undefined || employeeId !== null || employeeId !== '') {
				ctx.setVariable("employeeDisplayID", employeeId)
			}
		}
		if (getCrewApiResponse.customFieldValuesExt.crewStatusCustom) {
			var crewStatusCustom = getCrewApiResponse.customFieldValuesExt.crewStatusCustom;
			if (crewStatusCustom !== undefined || crewStatusCustom !== null || crewStatusCustom !== '') {
				ctx.setVariable("crewStatus", crewStatusCustom)
			}
		}
	}
}
if (initialActiveAssignmentCount) {
	if (initialActiveAssignmentCount !== undefined || initialActiveAssignmentCount !== null || initialActiveAssignmentCount !== '') {
		ctx.setVariable("activeStatusCount", initialActiveAssignmentCount)
	}
}
if (crewAssignmentStatus) {
	if (crewAssignmentStatus !== undefined || crewAssignmentStatus !== null || crewAssignmentStatus !== '') {
		ilsctx.setVariable("assignmentStatus", crewAssignmentStatus)
	}
}
ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
