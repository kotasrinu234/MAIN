var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");
var apiToken = ctx.getVar("apiToken");
var lookupURL = ctx.getVar("lookupURL");
var workTypeID = ctx.getVar("workTypeID");
var activeAssignmentCount = ctx.getVar("activeAssignmentCount");
var initialActiveAssignmentCount = ctx.getVar("initialActiveAssignmentCount");
var leadAssignmentID = ctx.getVar("leadAssignmentID");
var status = ctx.getVar("status");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var logger = console.options({
	'category': 'all'
});

//session.input.readAsJSON(function(readAsJSONError, incomingdata) {
if (initialActiveAssignmentCount == 0) {
	var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
	var crewStatus = activeAssignmentCount;
	var flag = 'true';
	//ctx.setVariable("crewStatus", crewStatus);
	ctx.setVariable("flag", flag);
} else if (leadAssignmentID === null || leadAssignmentID === undefined || leadAssignmentID === '') {
	var errorinfo = "omsapiv2_026:leadAssignmentID not found from the getCrewAPi call";
	ctx.setVariable("errorDescription", errorinfo);
	session.reject("leadAssignmentID not found from the getCrewAPi call");
	logger.error("omsapiv2_026:leadAssignmentID not found from the getCrewAPi call");
} else {
	var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
	var incomingUser = currentUser;
	var apiToken;
	if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
		apiToken = apiToken_OutageStatusApp;
	} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
		apiToken = apiToken_chatbot;
	} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
		apiToken = apiToken_reportingApp;
	} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
		apiToken = apiToken_maximo;
	}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}

	//Call /api/v1/ServiceType/{sid}/CrewAssignment/{id} 
	var getCrewAssignmentUrl = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + leadAssignmentID;
	var getCrewAssignmentApi = {
		target: getCrewAssignmentUrl,
		sslClientProfile: 'omsapi_client_profile',
		method: 'GET',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
	};
	var info = " TargetURL :" + getCrewAssignmentApi.target + "; Method :" + getCrewAssignmentApi.method + ". ";
	try {
		urlopen.open(getCrewAssignmentApi, function(error, response) {
			if (error) {
				var errorinfo = "omsapiv2_028:failure in putting message to getCrewAssignmentApi, details are : " + info + "; error info :" + error
				ctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapiv2_027:urlopen connect error with getCrewAssignmentApi" + JSON.stringify(errorinfo));
				session.reject("urlopen connect error with getCrewAssignmentApi");
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "omsapiv2_028:failure in putting message to getCrewAssignmentApi, details are : " + info + "; error info :" + error
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							logger.error("omsapiv2_028:failure in putting message to getCrewAssignmentApi" + JSON.stringify(errorinfo));
							session.reject("failure in putting message to getCrewAssignmentApi");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("omsapiv2_029:response received from getCrewAssignmentApi for empId:" + "" + responseStatusCode);
							var getCrewAssignmentResponse = JSON.parse(responseData);
							var workTypeID = getCrewAssignmentResponse.workTypeID;
							var status = getCrewAssignmentResponse.status;
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							ctx.setVariable("getCrewAssignmentResponse", getCrewAssignmentResponse);
							ctx.setVariable("getCrewAssignmentResponseStatusCode", responseStatusCode);
							ctx.setVariable("workTypeID", workTypeID);
							ctx.setVariable("status", status);
							//console.log("getCrewAssignmentResponseStatusCode----"+JSON.stringify(getCrewAssignmentResponse));

							var lookupMessage = {
								"lookupReq": {
									"type": [
										{
											"name": "workType.workflows",
											"id": workTypeID,
											"status": status
										}
									]
								}
							}

							var LookupServiceResponse = {
								target: lookupURL,
								method: 'POST',
								contentType: 'application/json',
								data: lookupMessage
							};
							ctx.setVariable("LookupRequest", lookupMessage);
							//ctx.setVariable("LookupServiceResponse", LookupServiceResponse);
							var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

							try {
								urlopen.open(LookupServiceResponse, function(error, response) {
									if (error) {
										var errorinfo = "omsapiv2_030:urlopen connect error with LookupServiceResponse, details are : " + info + "; error info :" + error;
										ctx.setVariable("errorDescription", errorinfo);
										logger.error("omsapiv2_030:urlopen connect error with LookupServiceResponse" + JSON.stringify(errorinfo));
										session.reject("urlopen connect error with LookupServiceResponse");
										//throw error;
									} else {
										var responseStatusCode = response.statusCode;
										var responsePhrase = response.reasonPhrase;
										if (responseStatusCode == 200) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													//dp:reject stop the transaction and go error rule with error code and description
													var errorinfo = "failure in putting message to LookupServiceResponse, details are : " + info + "; error info :" + error;
													ctx.setVariable("errorStatusCode", responseStatusCode);
													ctx.setVariable("errorMessage", responsePhrase);
													ctx.setVariable("errorDescription", errorinfo);
													logger.error("failure in putting message to LookupServiceResponse" + JSON.stringify(errorinfo));
													session.reject("failure in putting message to LookupServiceResponse");
												} else {
													hm.response.statusCode = responseStatusCode;
													logger.debug("omsapiv2_031:response received from LookupServiceResponse for empId:" + "" + responseStatusCode);
													var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
													var lookupResponse = JSON.parse(responseData);
													ctx.setVariable("lookupResponse", lookupResponse);
													if (lookupResponse.lookupRep.type[0].result == 0) {
														var label = lookupResponse.lookupRep.type[0].label;
														if (label != undefined && label != null) {
															var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
															ctx.setVariable("crewAssignmentStatus", label);
														} else {
															var label = '';
															var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
															ctx.setVariable("crewAssignmentStatus", label);
														}
													} else {
														logger.error("label is not found from LookupServiceResponse");
													}
												}
											});
										} else {
											var errorinfo = "omsapiv2_032:LookupServiceResponse is not 200 , details are : " + info + "; error info :" + error + responseStatusCode;
											ctx.setVariable("errorStatusCode", responseStatusCode);
											ctx.setVariable("errorMessage", responsePhrase);
											ctx.setVariable("errorDescription", errorinfo);
											ctx.setVariable("responseStatusCode", responseStatusCode);
											ctx.setVariable('responsePhrase', responsePhrase);
											session.reject("LookupServiceResponse is not 200");
											logger.error("omsapiv2_032:LookupServiceResponse is not 200");
										}
									}
								});
							}
							catch (error) {
								var errorinfo = "omsapiv2_030:urlopen connect error with LookupServiceResponse, details are : " + info + "; error info :" + error;
								ctx.setVariable("errorStatusCode", response.statusCode);
								ctx.setVariable("errorMessage", response.reasonPhrase);
								ctx.setVariable("errorDescription", errorinfo);
								logger.error("omsapiv2_030:urlopen connect error with LookupServiceResponse" + JSON.stringify(errorinfo));
								session.reject("urlopen connect error with LookupServiceResponse");
							}
						}
					});
				} else {
					ctx.setVariable("responseStatusCode", responseStatusCode);
					ctx.setVariable('responsePhrase', responsePhrase);
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							//logger.error("failure in reading message from CrewAssignmentApi for negative ack " + JSON.stringify(error));
							var errorinfo = "failure in reading message from CrewAssignmentApi for negative ack, details are : " + info + "; error info :" + error;
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							ctx.setVariable("errorDescription", errorinfo);
							session.reject("failure in reading message from CrewAssignmentApi for negative ack " + errorinfo);
						} else {
							var errorinfo = "omsapiv2_033:Error response received from CrewAssignmentApi " + responseStatusCode + " , details are : " + info + "; response info :" + responseData;
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							ctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_033:Error response received from CrewAssignmentApi " + " " + responseData);
							session.reject("Error response received from CrewAssignmentApi " + " " + responseData);
						}
					});
				}
			}
		}); //1st api call end
	} catch (error) {
		var errorinfo = "omsapiv2_028:failure in putting message to getCrewAssignmentApi, details are : " + info + "; error info :" + error;
		ctx.setVariable("errorStatusCode", error.errorCode);
		ctx.setVariable("errorMessage", error.errorMessage);
		ctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapiv2_028:failure in putting message to getCrewAssignmentApi" + JSON.stringify(errorinfo));
		session.reject("failure in putting message to getCrewAssignmentApi");
	}

}
//});
