var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");
var doLookup = require('./getEmployeeDetails_Lookup.js');
//var apiToken= ctx.getVar("apiToken");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var lookupURL = ctx.getVar("lookupURL");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");

var logger = console.options({
	'category': 'all'
});

//session.input.readAsJSON(function(readAsJSONError, incomingdata) {
var URL = sm.getVar('var://service/URI');
var start = URL.lastIndexOf('/');
var empId = URL.substring(start + 1);
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
//ctx.setVariable("employeeId",empId);

var incomingUser = currentUser;
var apiToken;

if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;
} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;
} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;
} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;
}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}

if (empId === null || empId === undefined || empId === '') {
	var errorinfo = "omsapiv2_022:EmployeeID not found" + empId;
	ctx.setVariable("errorDescription", errorinfo);
	session.reject("EmployeeID not found");
	logger.error("omsapiv2_022:EmployeeID not found" + empId);
} else {
	//Call GET /api/v1/ServiceType/Electric/Crew/{id}. 
	var crewApiUri = omsExternalURL + '/api/v1/ServiceType/Electric/Crew/' + empId;
	var getCrewapi = {
		target: crewApiUri,
		sslClientProfile: 'omsapi_client_profile',
		method: 'GET',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
	};
	var info = " TargetURL :" + getCrewapi.target + "; Method :" + getCrewapi.method + ". ";
	try {
		urlopen.open(getCrewapi, function(error, response) {
			if (error) {
				var errorinfo = "omsapiv2_023:urlopen connect error with GetCrewapi, details are : " + info + "; error info :" + error;
				ctx.setVariable("errorStatusCode", error.errorCode);
				ctx.setVariable("errorMessage", error.errorMessage);
				ctx.setVariable("errorDescription", errorinfo);
				logger.error("omsapiv2_023:urlopen connect error with GetCrewapi" + JSON.stringify(errorinfo));
				session.reject("urlopen connect error with GetCrewapi");
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "omsapiv2_24:failure in putting message to GetCrewapi, details are : " + info + "; error info :" + error
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							ctx.setVariable("errorDescription", errorinfo);
							logger.error("omsapiv2_24:failure in putting message to GetCrewapi" + JSON.stringify(errorinfo));
							session.reject("failure in putting message to GetCrewapi");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("omsapiv2_25:response received from GetCrewapi for empId:" + "" + responseStatusCode);
							var getCrewApiResponse = JSON.parse(responseData);
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							ctx.setVariable("getCrewApiResponse", getCrewApiResponse);
							ctx.setVariable("getCrewApiResponseStatusCode", responseStatusCode);

							var crewId = getCrewApiResponse.customFieldValuesExt.CrewID;
							var employeeId = getCrewApiResponse.customFieldValuesExt.employeeid;
							var aorIDs = getCrewApiResponse.aorIDs;
							//ctx.setVariable("employeeId",employeeId);

							if (crewId == null || crewId == '' || crewId == undefined) {
								crewId = '';
								ctx.setVariable("crewId", crewId);
							}
							else {
								ctx.setVariable("crewId", crewId);
							}
							if (employeeId == null || employeeId == '' || employeeId == undefined) {
								employeeId = '';
								ctx.setVariable("employeeId", employeeId);
							}
							else {
								ctx.setVariable("employeeId", employeeId);
							}

							var name = getCrewApiResponse.name;
							if (name == null || name == '' || name == undefined) {
								name = '';
								ctx.setVariable("name", name);
							}
							else {
								ctx.setVariable("name", name);
							}
							var phoneNumber = getCrewApiResponse.phoneNumber;
							if (phoneNumber == null || phoneNumber == '' || phoneNumber == undefined) {
								phoneNumber = '';
								ctx.setVariable("phoneNumber", phoneNumber);
							}
							else {
								ctx.setVariable("phoneNumber", phoneNumber);
							}

							var crewShftStat = JSON.stringify(getCrewApiResponse.onShift);

							if (crewShftStat == null || crewShftStat == '' || crewShftStat == undefined) {
								crewShftStat = '';
								ctx.setVariable("crewShftStat", crewShftStat);
							}
							else {
								ctx.setVariable("crewShftStat", crewShftStat);
							}
							//new change

							if (aorIDs == null || aorIDs == '' || aorIDs == undefined) {
								aorIDs = '';
								ctx.setVariable("aorIDs", aorIDs);
							}
							else {
								ctx.setVariable("aorIDs", aorIDs);
							}
							for (var i = 0; i < aorIDs.length; i++) {
								var aorsReq = {};
								var typeArr = new Array();
								aorsReq.name = "aors";
								aorsReq.id = aorIDs[i];
								typeArr.push(aorsReq);
								doLookup(typeArr, aorIDs[i]);
							}

							//new change ends

							var leadAssignmentID = getCrewApiResponse.leadAssignmentID;
							if (leadAssignmentID == null || leadAssignmentID == '' || leadAssignmentID == undefined) {
								leadAssignmentID = '';
								ctx.setVariable("leadAssignmentID", leadAssignmentID);
							}
							else {
								ctx.setVariable("leadAssignmentID", leadAssignmentID);
							}

							var activeAssignmentCount = getCrewApiResponse.activeAssignmentCount;
							ctx.setVariable("initialActiveAssignmentCount", activeAssignmentCount);

							if (activeAssignmentCount == undefined) {
								activeAssignmentCount = '';
								ctx.setVariable("activeAssignmentCount", activeAssignmentCount);
							} else if (activeAssignmentCount == 0) {
								var activeAssignmentCountzero = getCrewApiResponse.customFieldValuesExt.crewStatusCustom;
								ctx.setVariable("activeAssignmentCount", activeAssignmentCountzero);
							}
							else {
								ctx.setVariable("activeAssignmentCount", activeAssignmentCount);
							}
						}
					});
				} else {
					ctx.setVariable('responseStatusCode', responseStatusCode);
					ctx.setVariable('responsePhrase', responsePhrase);
					logger.error("omsapiv2_025:EmployeeID not found" + empId);
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from GetCrewapi for negative ack, details are : " + info + "; error info :" + error;
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							ctx.setVariable("errorDescription", errorinfo);
							logger.error("failure in reading message from GetCrewapi for negative ack " + JSON.stringify(errorinfo));
							session.reject("failure in reading message from GetCrewapi for negative ack ");
						} else {
							var errorinfo = "response received from GetCrewapi for negative ack " + responseStatusCode + ", details are : " + info + "; error info :" + responseData;
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							ctx.setVariable("errorDescription", errorinfo);
							logger.error("response received from GetCrewapi for negative ack " + " " + responseStatusCode);
							session.reject("response received from GetCrewapi for negative ack " + " " + responseStatusCode);
						}
					});
				}
			} //1st api call end
		});
	} catch (error) {
		var errorinfo = "omsapiv2_023:urlopen connect error with GetCrewapi, details are : " + info + "; error info :" + error
		ctx.setVariable("errorStatusCode", error.errorCode);
		ctx.setVariable("errorMessage", error.errorMessage);
		ctx.setVariable("errorDescription", errorinfo);
		logger.error("omsapiv2_023:urlopen connect error with GetCrewapi" + JSON.stringify(errorinfo));
		session.reject("urlopen connect error with GetCrewapi");
	}
}
// });
