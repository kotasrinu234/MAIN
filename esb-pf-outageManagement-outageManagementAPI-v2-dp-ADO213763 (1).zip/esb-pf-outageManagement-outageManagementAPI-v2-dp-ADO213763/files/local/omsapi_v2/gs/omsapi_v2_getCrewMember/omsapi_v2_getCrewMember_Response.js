var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
var getCrewApiResponseStatusCode = ctx.getVar("getCrewApiResponseStatusCode");
var activeAssignmentCount = ctx.getVar("activeAssignmentCount");
var logger = console.options({
	'category': 'all'
});

//session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var aorlist = new Array();
	var aorIDs =ctx.getVariable("aorIDs");
	
	
	for(var i=0;i<aorIDs.length;i++){
		var aorlabel =ctx.getVariable(aorIDs[i]+"_lookup")[0].label;
		//aorlist.push(ctx.getVariable(aorIDs[i]+"_lookup"))
		aorlist.push(aorlabel)
		}
									

	if(getCrewApiResponseStatusCode === 200 || activeAssignmentCount != 0) { 
			var json={};
			var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
			var flagVal = ctx.getVariable("flag");
			
			json.employeeId=ctx.getVariable("employeeId");
		
			if(ctx.getVariable("crewId") !=null && ctx.getVariable("crewId") !='' && ctx.getVariable("crewId") != undefined){ 
				json.crewId =ctx.getVariable("crewId");
			}else {
				json.crewId ='';
			}
			
			if(ctx.getVariable("name") !=null && ctx.getVariable("name") !='' && ctx.getVariable("name") != undefined){ 
				json.name =ctx.getVariable("name");
			}else {
				json.name ='';
			}
			
			if(ctx.getVariable("phoneNumber") !=null && ctx.getVariable("phoneNumber") !='' && ctx.getVariable("phoneNumber") != undefined){ 
				json.phoneNumber =ctx.getVariable("phoneNumber");
			}else {
				json.phoneNumber ='';
			}
			
			if(flagVal == "true") {
				json.crewStatus = ctx.getVariable("activeAssignmentCount") ;
			} else {
				json.crewStatus = ctx.getVariable("crewAssignmentStatus");
			}
			
			if (ctx.getVariable("onShift") == true){
				json.crewShiftStatus = 'on' ;
			}else{
				json.crewShiftStatus='off';
			}
			
			json.aors=aorlist;
			
			session.output.write(json);
	}	else {
		var errorinfo = "omsapiv2_034:getCrewApiResponseStatus response is not 200";
		ctx.setVariable("errorDescription", errorinfo);
		session.reject("getCrewApiResponseStatus response is not 200");
		logger.error("omsapiv2_034:getCrewApiResponseStatus response is not 200");
	}
//});
