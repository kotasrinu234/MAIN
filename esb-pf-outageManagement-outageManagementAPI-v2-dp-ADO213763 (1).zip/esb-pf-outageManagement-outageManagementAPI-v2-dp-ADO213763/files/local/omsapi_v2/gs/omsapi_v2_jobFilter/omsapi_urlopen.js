var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
var apiToken=ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var logger = console.options({'category':'all'});
function getURLResponse(url,myctx){
var options = {
    target: url,
	method: "get",
	 headers: {
		 "osiApiToken":apiToken
	 },
	 contentType: "application/json",
	 sslClientProfile: "omsapi_client_profile"
	 
};
urlopen.open(options, function(error, response){
    if (error) {
       ctx.setVariable("customErrorCode", '500');
		ctx.setVariable("customErrorMessage", 'Internal Server Error');
		ctx.setVariable("customReasonMessage", 'Internal Server Error');
		
        session.output.write ("urlopen error: " + JSON.stringify(error));
		session.reject(error.errorMessage);
    } else {
        var responseStatusCode = response.statusCode;
ctx.setVariable("responseStatusCode",responseStatusCode);
        if (responseStatusCode == 200) {
			response.readAsJSON(function(error, responseData) {
                if (error) {
					 // error while reading response or transferring data to Buffer
					 logEvent("readAsJSON error: " + JSON.stringify(error),"");
                    session.output.write("readAsJSON error: " + JSON.stringify(error));
                } else {
					 var ctx = session.name('jobFilter') || session.createContext('jobFilter');
						ctx.setVariable(myctx,responseData);
					
				}
            })
                        
}
else{
	response.readAsBuffer(function(error, responseData) {
			                                    if (error) {
			                                         
			                                           logger.error("failure in reading message" + JSON.stringify(error));
			                                           session.reject("failure in reading message"+ JSON.stringify(error));
			                                    } else {
			                                           logger.error("response received "+responseStatusCode+" "+ responseData);
			                                           session.reject("response received"+" "+responseStatusCode+" "+ responseData);
			                                      }
			                             });
	
	
}
}})
}
  
module.exports = getURLResponse;

