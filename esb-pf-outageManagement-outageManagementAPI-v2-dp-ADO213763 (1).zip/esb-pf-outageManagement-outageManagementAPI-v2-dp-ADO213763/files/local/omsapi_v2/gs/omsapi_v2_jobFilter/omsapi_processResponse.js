var ctx = session.name("jobFilter") || session.createContext("jobFilter");
var doLookup = require('./omsapi_lookup.js');
var getURLResponse = require('./omsapi_urlopen.js');
var callURL = require('./callUrl.js');
var omsUrl = session.parameters.omsExternalURL;
var prevResponseCode = ctx.getVariable("responseStatusCode");
var leadCallIDArr = new Array();

var omsResponse = ctx.getVariable('omsResponse');

if (prevResponseCode === 401) {
    ctx.setVariable("customErrorCode", '401');
    ctx.setVariable("customErrorMessage", 'UnAuthorized');
    ctx.setVariable("customReasonMessage", 'UnAuthorized');
    session.reject("UnAuthorized");
} else if (prevResponseCode === 403) {
    ctx.setVariable("customErrorCode", '403');
    ctx.setVariable("customErrorMessage", 'Forbidden');
    ctx.setVariable("customReasonMessage", 'Forbidden');
    session.reject("Forbidden");
} else if (omsResponse !== undefined && omsResponse !== '' && omsResponse !== null) {
	
    var outputArr = new Array();
    if (omsResponse.data.length === 0) {
        ctx.setVariable("customErrorCode", '404');
        ctx.setVariable("customErrorMessage", 'No Records Found');
        ctx.setVariable("customReasonMessage", 'No Records Found');
        session.reject("No Records Found");

    }

	var totalRecords = ctx.getVariable('totalRecords')
	var dataArr = new Array();
	//dataArr.push(omsResponse.data);
	
	for(var i=0; i< omsResponse.data.length; i++){
		dataArr[dataArr.length] = omsResponse.data[i];
	}
	var skip = 1000;
	var take = 1000;
	
	while(skip <= totalRecords){
	var arr = ctx.getVariable("omsResponse_"+skip).data;
	for(var i=0; i< arr.length; i++){
		dataArr[dataArr.length] = arr[i];
	}
		skip = skip + take;
	}
	ctx.setVariable('dataArrLength', dataArr.length);
	omsResponse.data = dataArr;
	
    for (var i = 0; i < omsResponse.data.length; i++) {
        var respObj = {};

        var jobID = omsResponse.data[i].id;
		var displayID = omsResponse.data[i].displayID;
        var jobTypeID = omsResponse.data[i].jobTypeID;
        var deviceType = omsResponse.data[i].deviceType;
        var networkModelType = omsResponse.data[i].networkModelType;

        var outageSubtypeID = "";
        if (omsResponse.data[i].outageSubtypeID != undefined) {
            outageSubtypeID = omsResponse.data[i].outageSubtypeID;
        }

        var createdAt = omsResponse.data[i].createdAt;
        var leadCallID = omsResponse.data[i].leadCallID;
        if (leadCallID !== undefined) {
            //getURLResponse(omsUrl+"/api/v1/ServiceType/Electric/Call/Query?isInternalIDs=true&includeFields=id%2CjobDisplayID%2CcontactMethod&historical=false", "leadContact_"+displayID);
			
            leadCallIDArr.push(leadCallID);
        }
        var customFieldValuesExtCause = "";
        if (omsResponse.data[i].customFieldValuesExt != undefined && omsResponse.data[i].customFieldValuesExt.cause != undefined) {
            customFieldValuesExtCause = omsResponse.data[i].customFieldValuesExt.cause;
        }
        var publishedEtrValue = "";
        if (omsResponse.data[i].publishedEtr != undefined && omsResponse.data[i].publishedEtr.value != undefined) {
            publishedEtrValue = omsResponse.data[i].publishedEtr.value;
        }
        var address = "";
        if (omsResponse.data[i].address != undefined) {
            address = omsResponse.data[i].address;
        }

        var location = "";
        if (omsResponse.data[i].location != undefined && omsResponse.data[i].location.coordinates != undefined) {
            location = omsResponse.data[i].location;
        }
        //ctx.setVariable("location_" + displayID, location);
        var latitude = "";
        if (location != "") {
            latitude = location.coordinates[1];
        }
        var longitude = "";
        if (location != "") {
            longitude = location.coordinates[0];
        }


        var feederName = omsResponse.data[i].feederName;
        var currentAffected = omsResponse.data[i].currentAffected;
        //var address = omsResponse.data[i].address;
        //var location = omsResponse.data[i].location;
        var aorID = omsResponse.data[i].aorID;
        var status = omsResponse.data[i].status;
        var leadAssignmentStatus = "";
        if (omsResponse.data[i].leadAssignmentStatus != undefined)
            leadAssignmentStatus = omsResponse.data[i].leadAssignmentStatus;

        var leadAssignmentWorkTypeID = "";
        if (omsResponse.data[i].leadAssignmentWorkTypeID != undefined)
            leadAssignmentWorkTypeID = omsResponse.data[i].leadAssignmentWorkTypeID;
        var leadCrewExternalID = omsResponse.data[i].leadCrewExternalID;

        respObj.jobId = jobID;
		respObj.jobDisplayId = displayID;
        respObj.jobType = "";
        respObj.jobSubType = "";
		

        respObj.outageDate = createdAt;
        respObj.callSource = "";
        respObj.causeCode = customFieldValuesExtCause;
        respObj.etr = publishedEtrValue;
        respObj.circuit = feederName;
        respObj.customerOut = currentAffected;

        respObj.address = address;
        respObj.longitude = longitude;
        respObj.latitude = latitude;
        respObj.aor = "";
        respObj.jobStatus = "";
        respObj.crewAssignmentStatus = "";
		respObj.deviceType = deviceType;
		
        if (leadCrewExternalID != undefined && leadCrewExternalID != null)
            respObj.crewId = leadCrewExternalID;
        else
            respObj.crewId = "";
        outputArr.push(respObj);

        var typeArr = new Array();
        var jobTypeReq = {};
        jobTypeReq.name = "jobTypes";
        jobTypeReq.id = jobTypeID;
        typeArr.push(jobTypeReq);

        var jobTypeIdStatusReq = {};
        jobTypeIdStatusReq.name = "jobTypes.workflows";
        jobTypeIdStatusReq.id = jobTypeID;
        jobTypeIdStatusReq.status = status;
        typeArr.push(jobTypeIdStatusReq);



        var outageSubtypesReq = {};
        outageSubtypesReq.name = "outageSubtypes";
        outageSubtypesReq.id = outageSubtypeID;
        typeArr.push(outageSubtypesReq);

        /* var contactMethodTypesReq = {};
        contactMethodTypesReq.name="contactMethodTypes";
        contactMethodTypesReq.id="";
        contactMethodTypesReq.label="OMS Electra (Internal)";
        typeArr.push(contactMethodTypesReq);
         */

        var aorsReq = {};
        aorsReq.name = "aors";
        aorsReq.id = aorID;
        typeArr.push(aorsReq);


        var leadAssignmentReq = {};
        leadAssignmentReq.name = "workType.workflows";
        leadAssignmentReq.status = leadAssignmentStatus;
        leadAssignmentReq.id = leadAssignmentWorkTypeID;
        typeArr.push(leadAssignmentReq);

        var jobStatusWorkflowReq = {};
        jobStatusWorkflowReq.name = "jobTypes";
        jobStatusWorkflowReq.status = status;
        jobStatusWorkflowReq.id = jobTypeID;
        typeArr.push(jobStatusWorkflowReq);
		
		if (networkModelType !== undefined){
			var networkModelTypeReq = {};
		networkModelTypeReq.name='networkModelTypeLabels';
		networkModelTypeReq.status = networkModelType;
		typeArr.push(networkModelTypeReq);
		}
		
		var uri ='/jobFilter/'+jobTypeID+'&'+status+'&'+outageSubtypeID+'&'+leadAssignmentStatus+'&'+leadAssignmentWorkTypeID+'&'+networkModelType;
        doLookup(typeArr, displayID,uri);
    }

    ctx.setVariable("outputArr", outputArr);
    //ctx.setVariable("leadCallIDArr", leadCallIDArr);
	callURL(omsUrl+"/api/ServiceType/Electric/Call/Query?isInternalIDs=true&includeFields=id%2CjobDisplayID%2CcontactMethod%2CexternalCallCodeID","POST","contactMethod",leadCallIDArr);
} else {
    ctx.setVariable("customErrorCode", '400');
    ctx.setVariable("customErrorMessage", 'Bad Request');
    ctx.setVariable("customReasonMessage", 'Bad Request');
}