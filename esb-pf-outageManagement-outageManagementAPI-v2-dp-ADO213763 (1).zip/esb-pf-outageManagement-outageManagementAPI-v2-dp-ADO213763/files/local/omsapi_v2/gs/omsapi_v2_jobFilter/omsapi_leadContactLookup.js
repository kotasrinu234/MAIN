var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
//var omsElectraLabel = session.parameters.labelName;
var doLookup = require('./omsapi_lookup.js');
var logger = console.options({
	'category': 'all'
});


/* var omsResponse = ctx.getVariable('omsResponse');
var outputArr = ctx.getVariable("outputArr");
var leadContactArr = ctx.getVariable('leadContactArr');

for(var i=0;i<omsResponse.data.length;i++){
var typeArr = new Array();	
var displayID= omsResponse.data[i].displayID;
var foundEntry = leadContactArr.find(e => e.hasOwnProperty(displayID));
//var leadContact=ctx.getVariable("leadContact_"+displayID)
//var contactMethod = ctx.getVariable("leadContact_"+displayID)*1;
var contactMethod='';
if(foundEntry != undefined && foundEntry.contactMethod !=undefined){
 contactMethod = foundEntry.contactMethod;
}
if(contactMethod !== undefined && contactMethod !== ''){
var contactMethodTypesReq = {};
contactMethodTypesReq.name="contactMethodTypes";
//contactMethodTypesReq.status=ctx.getVariable("leadContact_"+displayID);
contactMethodTypesReq.status=contactMethod;
//contactMethodTypesReq.label=omsElectraLabel;
typeArr.push(contactMethodTypesReq);
doLookup(typeArr,"leadContact_"+displayID);
} 
} */
