var omsUrl = session.parameters.omsExternalURL;
var getURLResponse = require('./omsapi_urlopen.js');
var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
ctx.setVariable("omsUrl",omsUrl);
var dispatchGroup= ctx.getVariable("aors");
//var aorsLength= ctx.getVariable("aorsLength");
var queryString = ctx.getVariable('queryString');
var aorsList = ctx.getVariable('aors_lookup');
var joblimit = ctx.getVariable('jobLimit');
var labelArr = new Array();
var dispatchGroupArr;
if(dispatchGroup !=undefined){
dispatchGroupArr= dispatchGroup.split(',');
}
if(dispatchGroup!=undefined && dispatchGroupArr.length===1){
for(var i=0; i< aorsList.length; i++){
if(aorsList[i].label !=undefined && aorsList[i].label.includes(dispatchGroup))
labelArr.push(aorsList[i].label);
}
}else if(dispatchGroup!=undefined && dispatchGroupArr.length > 1){
	for(var j=0;j<dispatchGroupArr.length;j++){
		for(var k=0; k < aorsList.length;k++){
			if(aorsList[k].label !=undefined && aorsList[k].label.includes(dispatchGroupArr[j]))
			labelArr.push(aorsList[k].label);
			}
		}
	}
	
ctx.setVariable("labelArr", labelArr);
if(dispatchGroup !=undefined){
queryString += "&aors="+labelArr.join(",");
ctx.setVariable("queryString",queryString);
}
var take = 1000;
if( joblimit != undefined && joblimit < take){
	take = joblimit;
}
	

var queryString_updated = queryString.replace(/ /g,"%20")+'&includeFields=id%2CjobTypeID%2CdisplayID%2CoutageSubtypeID%2CleadCallID%2CcustomFieldValuesExt%2Ccause%2Cstatus%2CcreatedAt%2CpublishedEtr%2Cvalue%2CfeederName%2CcurrentAffected%2Caddress%2Clocation%2Ccoordinates%2CaorID%2CleadAssignmentStatus%2CleadAssignmentWorkTypeID%2CleadCrewExternalID%2CnetworkModelType%2CdeviceType';
 var url = omsUrl+queryString_updated;
 ctx.setVariable("url", url);
 getURLResponse(url+'&take='+take,"omsResponse");