var ctx = session.name("jobFilter")|| session.createContext("jobFilter");

var outputArr = ctx.getVariable("outputArr");
var leadContactArr = ctx.getVariable('leadContactArr');

for(var i=0;i<outputArr.length;i++){
var obj=outputArr[i];
var displayID=obj.jobDisplayId;
var foundEntry = leadContactArr.find(e => e.hasOwnProperty(displayID));
/* var leadContact=ctx.getVariable("leadContact_"+displayID+"_lookup");
if (leadContact !==undefined && leadContact.label !== "undefined")
outputArr[i].callSource=leadContact[0].label;
else
	outputArr[i].callSource=""; */

//var leadContactCode = ctx.getVariable('leadContactCode_'+displayID);
if(foundEntry != undefined && foundEntry.callCode !=undefined){
	outputArr[i].callCode = foundEntry.callCode;
	
}else{
	outputArr[i].callCode = '';
}

}
ctx.setVariable("outputArr",outputArr);
session.output.write(outputArr);