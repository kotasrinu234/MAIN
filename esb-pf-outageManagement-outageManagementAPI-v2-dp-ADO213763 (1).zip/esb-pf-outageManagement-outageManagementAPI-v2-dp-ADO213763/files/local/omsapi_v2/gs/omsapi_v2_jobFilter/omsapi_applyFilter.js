var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
var jobSubtype = ctx.getVariable("jobSubType");
var jobSubTypeArr;
var jobStatus = ctx.getVariable("jobStatus");
var jobStatusArr;
var outputArr = ctx.getVariable("outputArr");
var jobSubtypeFilterArr;
var externalCallCodeInputArr = ctx.getVariable("externalCallCodeInput");
var crewAssignmentStatusInput = ctx.getVariable('crewAssignmentStatusInput');
var extentList  = ctx.getVariable('extent');
var externalCallCodeList;

function matchEntry(arr, entry){
   var flag = false;
   for(var i=0;i< arr.length; i++){
    if (arr[i]=== entry){
     flag = true;
	 return flag;
    }
  }
  return flag;
}


if(jobSubtype !=undefined){
	jobSubTypeArr = jobSubtype.split(',');
	//ctx.setVariable('action','Inside JobSubtype');
	jobSubtypeFilterArr = new Array();
	for(var i=0;i<outputArr.length;i++){
		if(matchEntry(jobSubTypeArr,outputArr[i].jobSubType)){
			jobSubtypeFilterArr.push(outputArr[i]);
		}
	}
ctx.setVariable("filteredArray", jobSubtypeFilterArr);
//ctx.setVariable("filteredArray2", jobSubtypeFilterArr);

}else{
	ctx.setVariable("filteredArray", outputArr);

}


//jobStatus start
var filteredArray = ctx.getVariable("filteredArray");


if(jobStatus !=undefined){
	jobStatusArr = jobStatus.split(',');
	var jobStatusFilterArr = new Array();
	for(var i=0;i<filteredArray.length;i++){
		if(matchEntry(jobStatusArr,filteredArray[i].jobStatus)){
			jobStatusFilterArr.push(filteredArray[i]);	
		}
	}
	ctx.setVariable("filteredArray", jobStatusFilterArr);
}

filteredArray = ctx.getVariable("filteredArray");

if(externalCallCodeInputArr !== undefined){
	externalCallCodeList = externalCallCodeInputArr.split(',');
	var externalCallCodeFilterArr = new Array();
	for(var i=0;i<filteredArray.length;i++){
		if(matchEntry(externalCallCodeList, filteredArray[i].callCode)){
			externalCallCodeFilterArr.push(filteredArray[i]);
		}
	}
	ctx.setVariable("filteredArray", externalCallCodeFilterArr);
}

filteredArray = ctx.getVariable("filteredArray");

if(crewAssignmentStatusInput !== undefined ){
var crewAssignmentFilterArr = new Array();
if(crewAssignmentStatusInput==='Y'||crewAssignmentStatusInput==='y'){
	for(var i=0;i<filteredArray.length;i++){
		if(filteredArray[i].crewAssignmentStatus !==undefined && filteredArray[i].crewAssignmentStatus !=='')
			crewAssignmentFilterArr.push(filteredArray[i]);
		}
}else if(crewAssignmentStatusInput==='N'||crewAssignmentStatusInput==='n'){
	for(var i=0;i<filteredArray.length;i++){
		if(filteredArray[i].crewAssignmentStatus !==undefined && filteredArray[i].crewAssignmentStatus ==='')
			crewAssignmentFilterArr.push(filteredArray[i]);
		}
}
ctx.setVariable("filteredArray", crewAssignmentFilterArr);

}

filteredArray = ctx.getVariable("filteredArray");

if(extentList !=undefined){
	var extentFilterArr = new Array();
	for(var i=0;i<filteredArray.length;i++){
		if(extentList.includes(filteredArray[i].extent)){
			extentFilterArr.push(filteredArray[i]);
		}
	}
	ctx.setVariable("filteredArray", extentFilterArr);
}

session.output.write(ctx.getVariable("filteredArray"));