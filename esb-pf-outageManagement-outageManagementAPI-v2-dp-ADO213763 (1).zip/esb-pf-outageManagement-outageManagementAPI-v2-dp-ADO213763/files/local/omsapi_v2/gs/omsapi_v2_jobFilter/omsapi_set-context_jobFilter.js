var doLookup = require('./omsapi_lookup.js');
var sm = require('service-metadata');
var qs = require ('querystring');

var logger = console.options({
	'category': 'all'
});
var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
var MaxJobLimit = Number(session.parameters.MaxJobLimit) ;

var uri = new String(sm.URI);
var json;
var jobTypes;
if(uri.indexOf("?") !=-1){
	json = qs.parse(uri.substring(uri.indexOf("?")+1));
	jobTypes = json.jobType;
}
if(jobTypes===undefined || jobTypes==="" || jobTypes=== null){
	ctx.setVariable("customErrorCode", '400');
				ctx.setVariable("customErrorMessage", 'Bad Request');
				ctx.setVariable("customReasonMessage", 'Bad Request');
				session.reject('JobType is Mandatory');
	
}
var jobStatus= json.jobStatus;
var aor = json.aor;
var startDate = json.startDate;
var endDate = json.endDate;
var extent = json.extent;

if(extent != undefined && extent !==null && extent !==""){
	ctx.setVariable("extent", extent);
}


//var apiToken=session.parameters.apiToken;
		var apiToken_OutageStatusApp = session.parameters.apiToken ;
		ctx.setVariable("apiToken_OutageStatusApp", apiToken_OutageStatusApp);
		var apiToken_chatbot=session.parameters.apiToken_chatbot;
		ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
		var apiToken_maximo=session.parameters.apiToken_maximo;
		ctx.setVariable("apiToken_maximo", apiToken_maximo);
		var apiToken_reporting=session.parameters.apiToken_reporting;
		ctx.setVariable("apiToken_reporting", apiToken_reporting);
		
		var ctx1 = session.name("current") || session.createContext("current");
		var currentUser = ctx1.getVar("user");
		var apiToken;
		
		if(currentUser == 'dcas-opa-esb-oms-dev' || currentUser == 'dcas-opa-esb-oms-tst' || currentUser == 'dcas-opa-esb-oms-prd'){
    		apiToken = apiToken_OutageStatusApp;
    		logger.info("inside OutageAPP----" +apiToken);
    	}else if(currentUser == 'dcas-cbo-esb-oms-dev' || currentUser == 'dcas-cbo-esb-oms-tst' || currentUser == 'dcas-cbo-esb-oms-prd'){
    		apiToken = apiToken_chatbot;
    		logger.info("inside chatbotAPP----" +apiToken);
    	} else if(currentUser == 'dcas-rpa-esb-oms-dev' || currentUser == 'dcas-rpa-esb-oms-tst' || currentUser == 'dcas-rpa-esb-oms-prd'){
    		apiToken = apiToken_reporting;
    		logger.info("inside reportAPP----" +apiToken);
    	} else if(currentUser == 'dcas-eam-sr-esb-dev' || currentUser == 'dcas-eam-sr-esb-test' || currentUser == 'dcas-eam-sr-esb-prod'){
    		apiToken = apiToken_maximo;
    		logger.info("inside maximoAPP----" +apiToken);
    	}  
		ctx.setVariable("apiToken", apiToken);

var lookupUrl=session.parameters.lookUpURL;
ctx.setVariable("lookupUrl",lookupUrl);

var omsUrl = session.parameters.omsExternalURL;
ctx.setVariable("omsUrl",omsUrl);

var queryString="/api/ServiceType/Electric/Job/Query/Params?";

/* var statusCodeMap = new Map([ 
['P','Pending'],
['A','Assigned'],
['H','Held'],
['B','Broadcast and Cancel '],
['X','Broadcast and Cancel '],
['C','Cancel'],
['V','Verified'],
['Z','Dup and Cancel'],
['R','Agreed Response'],
['L','Closed'],
['W','Awaiting Closure'],
['D','Dispatch Assigned'],
['S',' Dependent Status (used by InService to track'],
['U','Scheduled']
]); */
/* 
var badRequestFlag=false;
var badRequestMessage = "";
 */
/* var jobType = json.jobType;
ctx.setVariable("jobTypeLength", jobType.length);
if(jobType != undefined && jobType.length > 0){
	var arr = jobType;
	var jobTypeName='';
	var jobTypeArr = new Array();
	console.error('Length of array'+ arr.length);
	for( var i=0; i< arr.length; i++){
		jobTypeName=arr[i];
		jobTypeArr.push(jobTypeName);
	}
var jobTypes=jobTypeArr.join(','); */
queryString += "jobTypes="+jobTypes;

ctx.setVariable("jobTypes", jobTypes);

	/* if(jobTypes === undefined || jobTypes === ''){
				ctx.setVariable("customErrorCode", '400');
				ctx.setVariable("customErrorMessage", 'Bad Request');
				ctx.setVariable("customReasonMessage", 'Bad Request');
				session.reject('jobType is required');
}
 */

var jobSubType = json.jobSubType;
if(jobSubType != undefined && jobSubType !=="" && jobSubType !==null){
ctx.setVariable("jobSubType", jobSubType);
}


/* var jobStatus = json.jobStatus;
if(jobStatus != undefined){
	var statusList = jobStatus.split(',');
	var mappedArr = new Array();
	for(var i=0; i<statusList.length;i++){
		mappedArr.push(statusList[i]);
	}
 */
 if(jobStatus !== undefined && jobStatus !=="" && jobStatus !==null ){
 queryString += "&statuses="+jobStatus;
	ctx.setVariable("jobStatus", jobStatus);
 }



var dispatchGroup = aor;
if(dispatchGroup != undefined && dispatchGroup != null && dispatchGroup != ""){
	var dispatchGroupArr = dispatchGroup.split(',');
	//ctx.setVariable("aorsLength", dispatchGroupArr.length);
	if (dispatchGroupArr.length ===1 && dispatchGroupArr[0].length > 3){
		queryString += "&aors="+dispatchGroup;
		
	}else if ((dispatchGroupArr.length ===1 && dispatchGroupArr[0].length === 3) || dispatchGroupArr.length > 1){
			ctx.setVariable("aors", dispatchGroup);
		var aorsReq={};
			aorsReq.name="aors";
			var typeArr= new Array();
			typeArr.push(aorsReq);
			var uri ='/jobFilter/aors';
			doLookup(typeArr,"aors",uri);
		
	}else{
		throw Error('Incorrect AOR');
	}
}


ctx.setVariable("dateRangeFlag", 'false');
if(startDate != undefined && startDate !==null && startDate !==""  &&endDate != undefined && endDate !==null && endDate !=="" ){
	var after = startDate;
	var before = endDate;
	queryString += "&after="+after+"&before="+before;
	ctx.setVariable("dateRangeFlag", 'true');
}
 
var jobState = json.jobState;
var historic=false;
if(jobState != undefined && jobState !==null && jobState !==""){
	if(jobState ==="R"){
		historic=true;
	}
		if(jobState ==="A"){
		historic=false;
	}
		queryString +="&historical="+historic;
		ctx.setVariable("jobState", jobState);
		ctx.setVariable("historic", historic);
}
var externalCallCode = json.callCode;
if(externalCallCode != undefined && externalCallCode !=="" && externalCallCode !==null){
ctx.setVariable("externalCallCodeInput", externalCallCode);
}

var crewAssignmentStatus = json.activeCrewAssignment;
if(crewAssignmentStatus != undefined && crewAssignmentStatus !=="" && crewAssignmentStatus !==null){
ctx.setVariable("crewAssignmentStatusInput", crewAssignmentStatus);
}

var jobLimit = Number(json.jobLimit);
if(jobLimit !== undefined && jobLimit !=="" && !(isNaN(jobLimit))){
	if(jobLimit>MaxJobLimit){
				ctx.setVariable("customErrorCode", '500');
				ctx.setVariable("customErrorMessage", 'jobLimit should not exceed MaxJobLimit('+MaxJobLimit+')');
				ctx.setVariable("customReasonMessage", 'jobLimit should not exceed MaxJobLimit('+MaxJobLimit+')');
				session.reject('jobLimit should not exceed MaxJobLimit('+MaxJobLimit+')');
	}
ctx.setVariable("jobLimit", jobLimit);
}else {
		jobLimit=Number(MaxJobLimit);
		ctx.setVariable("jobLimit", jobLimit);
	}

ctx.setVariable("queryString",queryString);
