var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
var doLookup = require('./omsapi_lookup.js');
//var getURLResponse = require('./omsapi_urlopen.js');
//var omsUrl = session.parameters.omsExternalURL;

//var omsResponse = ctx.getVariable('omsResponse');
var outputArr = ctx.getVariable("outputArr");
var contactMethodArr = ctx.getVariable("contactMethod_response");
/* var statusValuetoCodeMap = new Map([ 
['PENDING','P'],
['ASSIGNED','A'],
['HELD','H'],
['BROADCAST AND CANCEL ','B'],
['BROADCAST AND CANCEL ','X'],
['CANCEL','C'],
['VERIFIED','V'],
['DUP AND CANCEL','Z'],
['AGREED RESPONSE','R'],
['CLOSED','L'],
['AWAITING CLOSURE','W'],
['DISPATCH ASSIGNED','D'],
['DEPENDENT STATUS (USED BY INSERVICE TO TRACK','S'],
['SCHEDULED','U']
]);

var crewAssignmentMap = new Map([ 
['ARRIVED','AR'],
['EN-ROUTE','EN'],
['ACKNOWLEGED','AK'],
['DISPATCHED','DP'],
['CANCELED','CP'],
['CANCELLED','CP'],
['COMPLETED','CP']
]); */


for(var i=0; i< outputArr.length;i++){
	//ctx.setVariable("mylabel_"+outputArr[i].jobDisplayId+"_lookup", ctx.getVariable(outputArr[i].jobDisplayId+"_lookup") );
	var obj = ctx.getVariable(outputArr[i].jobDisplayId+"_lookup");
	//var leadContactObj = ctx.getVariable("leadContact_"+outputArr[i].jobDisplayId);
	
outputArr[i].jobType=obj[0].label; //to check
//outputArr[i].jobSubType=obj[2].label;
if(obj[2].label !=undefined  && obj[2].label !=null)
outputArr[i].jobSubType=obj[2].label;
else
outputArr[i].jobSubType= "";
/* if(leadContactObj.contactMethod != undefined){
outputArr[i].callSource=leadContactObj.contactMethod;
}else{
	outputArr[i].callSource="";
} */
outputArr[i].aor = obj[3].label;
//outputArr[i].jobStatus=statusValuetoCodeMap.get("Pending");
 if(obj[5].label !=undefined && obj[1].label !=null){
	//if(statusValuetoCodeMap.has(obj[1].label)){
				//outputArr[i].jobStatus=statusValuetoCodeMap.get(obj[1].label.toUpperCase());
				outputArr[i].jobStatus=obj[1].label;
/* 	}else{
				outputArr[i].jobStatus="";
	} */
}else{
	outputArr[i].jobStatus="";
}

//outputArr[i].jobStatus = obj[1].label; //to map
if(obj[4].label !=undefined && obj[4].label !=null){
	//if(crewAssignmentMap.has(obj[4].label)){
				//outputArr[i].crewAssignmentStatus=crewAssignmentMap.get(obj[4].label.toUpperCase());
				outputArr[i].crewAssignmentStatus=obj[4].label;
	/* }else{
				outputArr[i].crewAssignmentStatus="";
	} */
}else{
	outputArr[i].crewAssignmentStatus="";
}
//outputArr[i].crewAssignmentStatus = obj[4].label;//to map
//ctx.setVariable("jobState_"+outputArr[i].jobId, obj[5].label);


 if(obj[6] !==undefined && obj[6].label !=undefined && obj[6].label !=null){
	outputArr[i].extent=obj[6].label;
}else{
	outputArr[i].extent="";
}

}

ctx.setVariable('outputArr',outputArr);

var leadContactArr = new Array();
var json;

for(var j=0;j<contactMethodArr.length;j++){

	json={};
	
	var jobDisplayId = contactMethodArr[j].jobDisplayID;
	json[jobDisplayId] = jobDisplayId;
	var contactMethod = contactMethodArr[j].contactMethod;
	var callCode = contactMethodArr[j].externalCallCodeID;
	/* if(contactMethod != undefined){
		json.contactMethod= contactMethodArr[j].contactMethod;
		//ctx.setVariable("leadContact_"+jobDisplayId, contactMethod);
	}else{	
	json.contactMethod= contactMethodArr[j].contactMethod;
	//ctx.setVariable("leadContact_"+jobDisplayId, '');
	} */
	if(callCode != undefined){
		json.callCode= contactMethodArr[j].externalCallCodeID;
		//ctx.setVariable("leadContactCode_"+jobDisplayId, callCode);
	}else{	
		json.callCode= '';
	//ctx.setVariable("leadContactCode_"+jobDisplayId, '');
	}
	leadContactArr.push(json);
}
ctx.setVariable('leadContactArr', leadContactArr);
session.output.write(outputArr);
