var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
var apiToken=ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var logger = console.options({'category':'all'});


function callURL(url, method, myctx,payload) {
	var options = {
        target: url,
        method: method,
        headers: {
            "osiApiToken": apiToken
        },
        contentType: "application/json",
        sslClientProfile: "omsapi_client_profile"
    };
    if (method == "POST" || method=="PATCH") {
        options.data = payload;
    }
 urlopen.open(options, function(error, response) {
        if (error) {
            // an error occurred during reading the file
			throw error;
        } else {
            var responseStatusCode = response.statusCode;
			 var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
             ctx.setVariable(myctx+"_responseStatusCode", responseStatusCode);
             ctx.setVariable(myctx+"_response", response);
					
            if (responseStatusCode == 200) {
				response.readAsJSON(function(error,data){
				if(error){
					logger.error("omsfoa_047 Error in reading response data");
					throw error;
				}else{
				 var ctx = session.name("jobFilter")|| session.createContext("jobFilter");
				 ctx.setVariable(myctx + '_response',data);	
				}
			});
			}else{
			  response.readAsBuffer(function(error, responseData) {
			     if (error) {
                         logger.error("failure in reading message" + JSON.stringify(error));
                        } else {
                         logger.error("response received with responseStatusCode "+responseStatusCode+" "+ responseData);
			     }
			  });
				if (responseStatusCode == 400) {
					ctx.setVariable("customErrorCode", '400');
					ctx.setVariable("customErrorMessage", 'Bad Request');
					ctx.setVariable("customReasonMessage", 'Bad Request');
					session.reject("Bad Request");
				}else if(responseStatusCode == 403){
					ctx.setVariable("customErrorCode", '403');
					ctx.setVariable("customErrorMessage", 'Forbidden');
					ctx.setVariable("customReasonMessage", 'Forbidden');
					session.reject("Forbidden");
				}else if(responseStatusCode==404){
					ctx.setVariable("customErrorCode", '404');
					ctx.setVariable("customErrorMessage", 'No Records Found');
					ctx.setVariable("customReasonMessage", 'No Records Found');
					session.reject("No Records Found");
				}else if(responseStatusCode==500){
					ctx.setVariable("customErrorCode", '500');
					ctx.setVariable("customErrorMessage", 'Server Error');
					ctx.setVariable("customReasonMessage", 'Server Error');
					session.reject("Server Error");
				}
			
        }
		}
    });
}

module.exports = callURL;