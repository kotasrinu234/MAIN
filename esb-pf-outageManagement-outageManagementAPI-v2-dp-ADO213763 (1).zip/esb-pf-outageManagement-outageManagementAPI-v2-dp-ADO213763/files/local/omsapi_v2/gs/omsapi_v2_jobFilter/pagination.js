	var getURLResponse = require('./omsapi_urlopen.js');
	var ctx = session.name("jobFilter") || session.createContext("jobFilter");
	var joblimit = ctx.getVariable('jobLimit');
var omsResponse = ctx.getVariable('omsResponse');
		var skip = 1000;
		var take = 1000;
		var totalWithHidden = omsResponse.totalWithHidden;
		if(joblimit === undefined){
			
			joblimit = totalWithHidden;
		}
		if(joblimit > 1000){
		
		ctx.setVariable('totalRecords', totalWithHidden);
		var baseurl = ctx.getVariable('url');
		if(joblimit !== undefined){
			if(joblimit < totalWithHidden){
				ctx.setVariable('totalRecords', joblimit);
			}else{
				ctx.setVariable('totalRecords', totalWithHidden);
			}
			joblimit = joblimit - take;
		}
		var url ='';
		
		while(skip <= totalWithHidden){
			
			if (joblimit < take){
				take = joblimit
				url = baseurl + '&skip='+skip+'&take='+take;
				getURLResponse(url,"omsResponse_"+skip);		
			 //console.log('skip= '+ skip +" take="+ take +" remaining=" + joblimit)
				return;
				
			}
			url = baseurl + '&skip='+skip+'&take='+take;
			getURLResponse(url,"omsResponse_"+skip);		
			 joblimit = joblimit - take;
			 //console.log('skip= '+ skip +" take="+ take +" remaining=" + joblimit)
			skip = skip + take;
			
			
			url ='';
		}
	}