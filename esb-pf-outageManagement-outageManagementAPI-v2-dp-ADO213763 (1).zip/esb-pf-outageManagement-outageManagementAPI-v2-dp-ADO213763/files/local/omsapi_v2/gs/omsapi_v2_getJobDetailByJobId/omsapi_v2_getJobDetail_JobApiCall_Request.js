var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");
//var apiToken= ctx.getVar("apiToken");
var lookupURL = ctx.getVar("lookupURL");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var job_id;
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;
} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;
} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;
} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;
} else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}
var logger = console.options({
	'category': 'all'
});

session.input.readAsBuffer(function(readAsJSONError, incomingdata) {

	var URL = sm.getVar('var://service/URI');
	var start = URL.lastIndexOf('/');
	var jobId = URL.substring(start + 1);
	var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
	ctx.setVariable("jobId", jobId);


	if (jobId === null || jobId === undefined || jobId === '') {
		var errorinfo = "omsapiv2_035: 404 jobId not found";
		ctx.setVariable("errorDescription", errorinfo);
		session.reject("jobId not found");
		logger.error("omsapiv2_035:jobId not found");
	} else {

		var jobUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobId;

		var getJobApi = {
			target: jobUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
		};

		var info = " TargetURL :" + getJobApi.target + "; Method :" + getJobApi.method + ". ";
		try {
			urlopen.open(getJobApi, function(error, response) {
				if (error) {
					var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
					var errorinfo = "omsapiv2_036: url connection error with 'getJobApi', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_036: " + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								var errorinfo = "omsapiv2_037: error reading response 'getJobApi', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("omsapiv2_037: " + errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								// logger.error("omsapiv2_038:response received from getJobApi " + ":" + responseStatusCode);
								var getJobApiResponse = JSON.parse(responseData.toString('utf8'));
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								ctx.setVariable("getJobApiResponse", getJobApiResponse);

								job_id = getJobApiResponse.id;
								ctx.setVariable("job_id", job_id);
								//console.log("rom job response----" +job_id);
								var id = getJobApiResponse.displayID;
								var internalId = getJobApiResponse.id;
								ctx.setVariable("internalId", internalId);
								if (id == null || id == '' || id == undefined) {
									id = '';
									ctx.setVariable("id", id);
								} else {
									ctx.setVariable("id", id);
								}
								var energizationStatus = getJobApiResponse.energizationStatus;
								if (energizationStatus == null || energizationStatus == '' || energizationStatus == undefined) {
									energizationStatus = '';
									ctx.setVariable("energizationStatus", energizationStatus);
								} else {
									ctx.setVariable("energizationStatus", energizationStatus);
								}
								//ADO184553 starts
								var deviceOperatingVoltage = getJobApiResponse.voltage;
								if (deviceOperatingVoltage == null || deviceOperatingVoltage == '' || deviceOperatingVoltage == undefined) {
									deviceOperatingVoltage = '';
									ctx.setVariable("deviceOperatingVoltage", deviceOperatingVoltage);
								} else {
									ctx.setVariable("deviceOperatingVoltage", deviceOperatingVoltage);
								}
								//ADO184553 ends
								var customerOut = getJobApiResponse.currentAffected;
								if (customerOut == undefined) {
									customerOut = '';
									ctx.setVariable("customerOut", customerOut);
								} else {
									ctx.setVariable("customerOut", customerOut);
								}

								var activeCrewAssignmentCount = getJobApiResponse.activeCrewAssignmentCount;
								if (activeCrewAssignmentCount == undefined) {
									activeCrewAssignmentCount = '';
									ctx.setVariable("activeCrewAssignmentCount", activeCrewAssignmentCount);
								} else {
									ctx.setVariable("activeCrewAssignmentCount", activeCrewAssignmentCount);
								}

								var status = getJobApiResponse.status;
								if (status == undefined) {
									status = '';
									ctx.setVariable("status", status);
								} else {
									ctx.setVariable("status", status);
								}

								var createDate = getJobApiResponse.createdAt;
								if (createDate == null || createDate == '' || createDate == undefined) {
									createDate = '';
									ctx.setVariable("createDate", createDate);
								} else {
									ctx.setVariable("createDate", createDate);
								}


								var circuit = getJobApiResponse.feederID;
								if (circuit == null || circuit == '' || circuit == undefined) {
									circuit = '';
									ctx.setVariable("circuit", circuit);
								} else {
									ctx.setVariable("circuit", circuit);
								}

								var leadCrewExternalID = getJobApiResponse.leadCrewExternalID;
								if (leadCrewExternalID === null || leadCrewExternalID === undefined || leadCrewExternalID === '') {
									leadCrewExternalID = '';
									ctx.setVariable("leadCrewExternalID", leadCrewExternalID);
								} else {
									ctx.setVariable("leadCrewExternalID", leadCrewExternalID);
								}

								var causeCode = getJobApiResponse.customFieldValuesExt;
								var causeValues = causeCode.cause;
								if ((causeCode === undefined || causeCode === null || causeCode === '') && (causeValues === undefined || causeValues === null || causeValues === '')) {
									causeValues = '';
									ctx.setVariable("causeValues", causeValues);
								} else if ((causeCode != undefined || causeCode != null || causeCode != '') && (causeValues === undefined || causeValues === null || causeValues === '')) {
									causeValues = '';
									ctx.setVariable("causeValues", causeValues);
								} else {
									ctx.setVariable("causeValues", causeValues);
								}


								var publishedEtr;
								if (getJobApiResponse.publishedEtr === undefined || getJobApiResponse.publishedEtr === null || getJobApiResponse.publishedEtr === '') {
									publishedEtr = '';
									ctx.setVariable("publishedEtr", publishedEtr);
									//logger.error("inside  else publish value-----");
								} else {
									if (getJobApiResponse.publishedEtr.value === undefined || getJobApiResponse.publishedEtr.value === null || getJobApiResponse.publishedEtr.value === '') {
										publishedEtr = '';
										ctx.setVariable("publishedEtr", publishedEtr);
										//logger.error("inside 2nd publish value-----");
									} else {
										//logger.error("inside publish value-----");

										publishedEtr = getJobApiResponse.publishedEtr.value;
										ctx.setVariable("publishedEtr", publishedEtr);
										ctx.setVariable("publishedEtr", publishedEtr);
									}
								}

								var leadCrewID = getJobApiResponse.leadCrewID;
								if (leadCrewID === null || leadCrewID === undefined || leadCrewID === '') {
									leadCrewID = '';
									ctx.setVariable("leadCrewID", leadCrewID);
								} else {
									ctx.setVariable("leadCrewID", leadCrewID);
								}

								var callCount = getJobApiResponse.callCount;
								if (callCount == undefined) {
									callCount = '';
									ctx.setVariable("callCount", callCount);
								} else {
									ctx.setVariable("callCount", callCount);
								}

								var address = getJobApiResponse.address;
								if (address == null || address == '' || address == undefined) {
									address = '';
									ctx.setVariable("address", address);
								} else {
									ctx.setVariable("address", address);
								}


								var premisesWithAMIRestorationNotifCount = getJobApiResponse.premisesWithAMIRestorationNotifCount;
								if (premisesWithAMIRestorationNotifCount == undefined) {
									premisesWithAMIRestorationNotifCount = '';
									ctx.setVariable("premisesWithAMIRestorationNotifCount", premisesWithAMIRestorationNotifCount);
								} else {
									ctx.setVariable("premisesWithAMIRestorationNotifCount", premisesWithAMIRestorationNotifCount);
								}


								var leadCallID = getJobApiResponse.leadCallID;
								if (leadCallID == null || leadCallID == '' || leadCallID == undefined) {
									leadCallID = '';
									ctx.setVariable("leadCallID", leadCallID);
								} else {
									ctx.setVariable("leadCallID", leadCallID);
								}

								var aorID = getJobApiResponse.aorID;
								if (aorID == null || aorID == '' || aorID == undefined) {
									aorID = '';
									ctx.setVariable("aorID", aorID);
								} else {
									ctx.setVariable("aorID", aorID);
								}

								var callId = [];
								if (callCount > 1) {
									for (var i = 0; i < callCount; i++) {
										callId[i] = getJobApiResponse.calls[i].id;
									}
								}

								var jobTypeID = getJobApiResponse.jobTypeID;
								if (jobTypeID == null || jobTypeID == '' || jobTypeID == undefined) {
									jobTypeID = '';
									ctx.setVariable("jobTypeID", jobTypeID);
								} else {
									ctx.setVariable("jobTypeID", jobTypeID);
								}

								var leadAssignmentWorkTypeID = getJobApiResponse.leadAssignmentWorkTypeID;
								if (leadAssignmentWorkTypeID == null || leadAssignmentWorkTypeID == '' || leadAssignmentWorkTypeID == undefined) {
									leadAssignmentWorkTypeID = '';
									ctx.setVariable("leadAssignmentWorkTypeID", leadAssignmentWorkTypeID);
								} else {
									ctx.setVariable("leadAssignmentWorkTypeID", leadAssignmentWorkTypeID);
								}

								//ALM 5505
								var nominalFeederId = getJobApiResponse.nominalFeederID;
								if (nominalFeederId == null || nominalFeederId == '' || nominalFeederId == undefined) {
									nominalFeederId = '';
									ctx.setVariable("nominalFeederId", nominalFeederId);
								} else {
									ctx.setVariable("nominalFeederId", nominalFeederId);
									var URL = omsExternalURL + '/api/ServiceType/Electric/Feeder/' + nominalFeederId + '?includeFields=externalID';
									getURLResponse(URL, 'IdResponse');
								}


								var leadAssignmentStatus = getJobApiResponse.leadAssignmentStatus;
								if (leadAssignmentStatus == null || leadAssignmentStatus == '' || leadAssignmentStatus == undefined) {
									leadAssignmentStatus = '';
									ctx.setVariable("leadAssignmentStatus", leadAssignmentStatus);
								} else {
									ctx.setVariable("leadAssignmentStatus", leadAssignmentStatus);
								}

								var leadAssignmentID = getJobApiResponse.leadAssignmentID;
								if (leadAssignmentID == null || leadAssignmentID == '' || leadAssignmentID == undefined) {
									leadAssignmentID = '';
									ctx.setVariable("leadAssignmentID", leadAssignmentID);
								} else {
									ctx.setVariable("leadAssignmentID", leadAssignmentID);
								}

								var outageSubTypeID = getJobApiResponse.outageSubtypeID;
								if (outageSubTypeID == null || outageSubTypeID == '' || outageSubTypeID == undefined) {
									outageSubTypeID = '';
									ctx.setVariable("outageSubTypeID", outageSubTypeID);
								} else {
									ctx.setVariable("outageSubTypeID", outageSubTypeID);
								}

								var deviceType = getJobApiResponse.deviceType;
								if (deviceType == null || deviceType == '' || deviceType == undefined) {
									deviceType = '';
									ctx.setVariable("deviceType", deviceType);
								} else {
									ctx.setVariable("deviceType", deviceType);
								}


								//var contactMethod = JSON.stringify(getLeadCallApiResponse.contactMethod);

								var networkModelType = JSON.stringify(getJobApiResponse.networkModelType);
								if (networkModelType == undefined || networkModelType == '') {
									networkModelType = '';
									ctx.setVariable("networkModelType", networkModelType);
								} else {
									ctx.setVariable("networkModelType", networkModelType);
								}
								var regionName = getJobApiResponse.regionName;
								if (regionName == undefined) {
									regionName = '';
									ctx.setVariable("regionName", regionName);
								} else {
									ctx.setVariable("regionName", regionName);
								}

								//ADO171595 starts
								
								if (getJobApiResponse.feederName == null || getJobApiResponse.feederName == '' || getJobApiResponse.feederName == undefined) {
									var feederName = '';
									ctx.setVariable("feederName", feederName);
								} else {
									ctx.setVariable("feederName", getJobApiResponse.feederName);
								}

								var deviceInfo = getJobApiResponse.deviceInfo;
								var outageSubtype = '';
								if (deviceInfo?.customFieldValuesExt?.OUTAGE_SUBTYPE) {
									outageSubtype = deviceInfo.customFieldValuesExt.OUTAGE_SUBTYPE;
								}
								ctx.setVariable("OUTAGE_SUBTYPE", outageSubtype);
								
								//ADO171595 ends
								var longtitude;
								var latitude;
								if (getJobApiResponse.location != undefined) {
									if (getJobApiResponse.location.coordinates != undefined) {
										longtitude = getJobApiResponse.location.coordinates[0];
										latitude = getJobApiResponse.location.coordinates[1];
										ctx.setVariable("longtitude_getJobApicall", longtitude);
										ctx.setVariable("latitude_getJobApiCall", latitude);
									}
								}
							}
							//comment Start
							//Call GET /api/v1/ServiceType/Electric/Job/{id}/Comment {id} as jobId
							var getCommentUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + job_id + '/Comment';
							//console.log("comment url is --------------" +getCommentUrl);
							var getCommentsApi = {
								target: getCommentUrl,
								sslClientProfile: 'omsapi_client_profile',
								method: 'GET',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
							};

							var info = " TargetURL :" + getCommentsApi.target + "; Method :" + getCommentsApi.method + ". ";
							try {
								urlopen.open(getCommentsApi, function(error, response) {
									if (error) {
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										var errorinfo = "omsapiv2_039: url connection error with 'getCommentsApi', details are : " + info + "; error info :" + error
										ctx.setVar('errorDescription', errorinfo);
										ctx.setVariable("errorStatusCode", response.statusCode);
										ctx.setVariable("errorMessage", response.reasonPhrase);
										logger.error("omsapiv2_039: " + errorinfo);
										session.reject(errorinfo);
									} else {
										var responseStatusCode = response.statusCode;
										var responsePhrase = response.reasonPhrase;
										if (responseStatusCode == 200) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													//dp:reject stop the transaction and go error rule with error code and description
													var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
													var errorinfo = "error reading response 'getCommentsApi', details are : " + info + "; error info :" + error
													ctx.setVar('errorDescription', errorinfo);
													ctx.setVariable("errorStatusCode", responseStatusCode);
													ctx.setVariable("errorMessage", responsePhrase);
													logger.error("omsapiv2_040: " + errorinfo);
													session.reject(errorinfo);
												} else {
													hm.response.statusCode = responseStatusCode;
													// logger.error("omsapiv2_041:response received from getCommentsApi" + responseStatusCode);
													var getCommentsApiResponse = JSON.parse(responseData);
													var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
													//ctx.setVariable("getCommentsApiResponse", getCommentsApiResponse);
													var commentArray = [];
													var commentsArr = getCommentsApiResponse;
													var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");

													for (var i = 0; i < commentsArr.length; i++) {
														var deprecated = commentsArr[i].deprecated;
														var comm = {
															"comment": commentsArr[i].comment,
															"timestamp": commentsArr[i].updatedAt
														}
														if (deprecated == false) {
															commentArray.push(comm);
														}
													}
													ctx.setVariable('commentsArr', commentArray);
												}
											});
										} else {
											var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
											var errorinfo = "omsapiv2_042:Unable to find the details in getCommentsApi call " + responseStatusCode + ", details are : " + info + "; error info :" + error
											ctx.setVar('errorDescription', errorinfo);
											ctx.setVariable("errorStatusCode", responseStatusCode);
											ctx.setVariable("errorMessage", responsePhrase);
											logger.error("omsapiv2_042:Unable to find the details in getCommentsApi call" + " " + responseStatusCode);
										}
									}

								});
							} catch (err) {
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								var errorinfo = "omsapiv2_039: url connection error with 'getCommentsApi', details are : " + info + "; error info :" + err
								ctx.setVar('errorDescription', errorinfo);
								logger.error("omsapiv2_039: " + errorinfo);
								session.reject(errorinfo);
							}
							//comment End
							//ALM 5070
							var callsCount = session.parameters.callsCount;
							if (callId.length <= callsCount) {
								for (var i = 0; i < callId.length; i++) {
									var URL = omsExternalURL + '/api/ServiceType/Electric/Call/' + callId[i] + '?includeFields=address,status';
									getURLResponse(URL, 'AddressResponse');
								}
							}

						});
					} else if (responseStatusCode == 401) {
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
						logger.error("Not Authorized");
						var errorinfo = "401 Not Authorized, details are : " + info + "; error info :" + error
						ctx.setVar('errorDescription', errorinfo);
						ctx.setVariable("errorStatusCode", responseStatusCode);
						ctx.setVariable("errorMessage", responsePhrase);
						session.reject("Not Authorized" + responseStatusCode);
					} else {
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
						logger.error("omsapiv2_043:JobId not found");
						//session.reject("JobId not found");
						var errorinfo = "omsapiv2_043: 404 JobId not found, details are : " + info + "; error info :" + error
						ctx.setVar('errorDescription', errorinfo);
						ctx.setVariable("errorStatusCode", responseStatusCode);
						ctx.setVariable("errorMessage", responsePhrase);
						ctx.setVariable('responseStatusCode', responseStatusCode);
						ctx.setVariable('responsePhrase', responsePhrase);
						session.reject("JobId not found");
					}
				}

			});
		} catch (err) {
			var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
			var errorinfo = "omsapiv2_036: url connection error with 'getJobApi', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error("omsapiv2_036: " + errorinfo);
			session.reject(errorinfo);
		}
	}
	//end
});


function getURLResponse(url, myctx) {
	var options = {
		target: url,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "omsapi_client_profile"

	};

	var info = " TargetURL :" + options.target + "; Method :" + options.method + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				hm.current.statusCode = '500';
				var ctx1 = session.name("current") || session.createContext("current");
				var trrpt = ctx1.getVariable("trrpt");
				var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
				var errorinfo = "urlopen error 'getURLResponse' details are : " + info + "; error info :" + error
				ctx.setVar('errorDescription', errorinfo);
				ctx.setVariable("errorStatusCode", response.statusCode);
				ctx.setVariable("errorMessage", response.reasonPhrase);
				logger.error(trrpt + errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
				ctx.setVariable("responseStatusCode", responseStatusCode);
				logger.debug("response code" + responseStatusCode);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							hm.current.statusCode = '500';
							var errorinfo = "error reading response 'getURLResponse', details are : " + info + "; error info :" + error
							ctx.setVar('errorDescription', errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							session.output.write("readAsJSON error: " + errorinfo);
						} else {
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							if (myctx === "AddressResponse") {
								var testArray = ctx.getVariable("testArray");
								testArray.push(responseData);
								ctx.setVariable("testArray", testArray);
							}
							else {
								var externalId = responseData.externalID;
								ctx.setVariable("NominalExternalId", externalId);
							}
							logger.debug("response data" + JSON.stringify(responseData));

						}
					})
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							var errorinfo = "error reading response 'getURLResponse', details are : " + info + "; error info :" + error
							ctx.setVar('errorDescription', errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							var errorinfo = "Error code returned from 'getURLResponse' " + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
							ctx.setVar('errorDescription', errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		});
	} catch (err) {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		hm.current.statusCode = '500';
		var errorinfo = "url connection error with 'getURLResponse', details are : " + info + "; error info :" + err
		ctx.setVar('errorDescription', errorinfo);
		var ctx1 = session.name("current") || session.createContext("current");
		var trrpt = ctx1.getVariable("trrpt");
		logger.error(trrpt + errorinfo);
		session.reject(errorinfo);
	}
}
