var doLookup = require('./omsapi_v2_lookup.js');
var logger = console.options({
	'category': 'all'
});


var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var typeArr;
var crewArr;
var workArr;
var CrewIdArray = ctx.getVariable('crewArr');
ctx.setVariable("CrewIdArray", CrewIdArray)
for (var i = 0; i < CrewIdArray.length; i++) {
	typeArr = new Array();
	var workTypeID = CrewIdArray[i].workTypeID;
	var status = CrewIdArray[i].status;
	var crewType = CrewIdArray[i].crewtype;
	var id = CrewIdArray[i].id;
	var type = CrewIdArray[i].type;

	var lookupReq = {};
	lookupReq.name = "workType.workflows";
	lookupReq.id = workTypeID;
	lookupReq.status = status;
	typeArr.push(lookupReq);
	doLookup(typeArr, "status_" + id);

	var workLookupReq = {};
	workArr = new Array();
	workLookupReq.name = "workTypes";
	workLookupReq.id = workTypeID;
	workArr.push(workLookupReq);
	doLookup(workArr, "status_" + workTypeID);

	var crewLookupReq = {};
	crewArr = new Array();
	crewLookupReq.name = "crewTypes";
	crewLookupReq.status = crewType;
	crewArr.push(crewLookupReq);
	doLookup(crewArr, "status_" + crewType);

}
