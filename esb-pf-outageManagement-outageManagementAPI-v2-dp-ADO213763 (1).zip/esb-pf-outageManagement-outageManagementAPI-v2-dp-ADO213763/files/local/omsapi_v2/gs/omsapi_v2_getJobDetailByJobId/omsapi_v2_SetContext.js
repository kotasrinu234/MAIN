var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

	
var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var lookupURL = session.parameters.lookUpURL;
var apiToken_chatbot=session.parameters.apiToken_chatbot;
var apiToken_maximo=session.parameters.apiToken_maximo;
var apiToken_reporting=session.parameters.apiToken_reporting;
var testArray = [];

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("apiToken_chatbot", apiToken_chatbot);
ctx.setVariable("apiToken_maximo", apiToken_maximo);
ctx.setVariable("apiToken_reporting", apiToken_reporting);
ctx.setVariable("testArray", testArray);
