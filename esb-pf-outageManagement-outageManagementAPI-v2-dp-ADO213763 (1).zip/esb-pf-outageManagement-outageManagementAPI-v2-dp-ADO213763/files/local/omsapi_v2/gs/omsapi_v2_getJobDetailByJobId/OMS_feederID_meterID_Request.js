//Circuit_Feeder, Meter ID call to OMS
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");

//Start API token check with current user
var lookupURL = ctx.getVar("lookupURL");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
//End API token check with current user

var FeederID = ctx.getVar("circuit");
var MeterID = ctx.getVar("leadCallID");
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var logger = console.options({
	'category': 'all'
});

// End API token check with current user

session.input.readAsBuffer(function(readAsJSONError, incomingdata) {

	// Start API token check with current user
	var incomingUser = currentUser;
	var apiToken;
	if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
		apiToken = apiToken_OutageStatusApp;
	} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
		apiToken = apiToken_chatbot;
	} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
		apiToken = apiToken_reportingApp;
	} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
		apiToken = apiToken_maximo;
	}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
	}
	// End API token check with current user
	var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
	var FeederID = ctx.getVar("circuit");
	var leadCallResponseStausCode = ctx.getVar("leadCallResponseStausCode");

	if (FeederID == undefined || FeederID == '' || FeederID == null) {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		var feederId = '';
		ctx.getVar("feederId");

	} else {

		//Feeder OMS call start
		//Call Get /api/ServiceType/Electric/Feeder/{id} with includeFields=externalID and map externalID.

		var getFeederIdUrl = omsExternalURL + '/api/ServiceType/Electric/Feeder/' + FeederID + '?includeFields=externalID';
		var getfeederIdApi = {
			target: getFeederIdUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
		};
		var info = " TargetURL :" + getfeederIdApi.target + "; Method :" + getfeederIdApi.method + ". ";
		try {
			urlopen.open(getfeederIdApi, function(error, response) {
				if (error) {
					var errorinfo = "omsapiv2_039:url connection error 'with getfeederIdApi', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_039: " + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and take the control to error rule with error code and description
								var errorinfo = "omsapiv2_040: error reading response 'getfeederIdApi', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("omsapiv2_040: " + errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								//logger.error("omsapiv2_041:response received from getfeederIdApi" + responseStatusCode);
								var getfeederIdApiResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								var feederId = getfeederIdApiResponse.externalID;
								ctx.setVariable("feederId", feederId);
								ctx.setVariable("getfeederIdApiResponse", getfeederIdApiResponse);
							}
						});
					} else {
						var errorinfo = "omsapiv2_042:Unable to find the details in getFeederIdApi call, details are : " + info + "; error info :" + error
						ctx.setVar('errorDescription', errorinfo);
						ctx.setVariable("errorStatusCode", responseStatusCode);
						ctx.setVariable("errorMessage", responsePhrase);
						logger.error("omsapiv2_042:Unable to find the details in getFeederIdApi call" + " " + responseStatusCode);
					}
				}

			});
		} catch (error) {
			var errorinfo = "omsapiv2_039:url connection error with getfeederIdApi, details are : " + info + "; error info :" + error
			ctx.setVar('errorDescription', errorinfo);
			ctx.setVariable("errorStatusCode", error.errorCode);
			ctx.setVariable("errorMessage", error.errorMessage);
			logger.error("omsapiv2_039: " + errorinfo);
			session.reject(errorinfo);
		}
		//Feeder OMS call End
	}

});

//END
