var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");
//var apiToken= ctx.getVar("apiToken");
var leadCallID = ctx.getVar("leadCallID");
var lookupURL = ctx.getVar("lookupURL");
var jobTypeID = ctx.getVar("jobTypeID");
var internalId = ctx.getVar("internalId");

//var aorID = ctx.getVar("aorID");
var status = ctx.getVar("status");
/* var leadAssignmentWorkTypeID = ctx.getVar("leadAssignmentWorkTypeID");
var leadAssignmentStatus = ctx.getVar("leadAssignmentStatus"); */
var outageSubTypeID = ctx.getVar("outageSubTypeID");
var leadAssignmentID = ctx.getVar("leadAssignmentID");
var leadCrewID = ctx.getVar("leadCrewID");
//var networkModelType = ctx.getVar("networkModelType");
var leadCrewExternalID = ctx.getVar("leadCrewExternalID");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");

var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var logger = console.options({
	'category': 'all'
});

function getByValue2(arr, value) {

	var result = arr.filter(function(o) { return o.workTypeID == value; });
	return result ? result[0] : null; // or undefined

}

session.input.readAsBuffer(function(readAsJSONError, incomingdata) {

	//condition removed start

	var getCrewAssignmentUrl = omsExternalURL + '/api/ServiceType/Electric/Job/' + internalId + '/CrewAssignment?excludeResolved=false&join=true';
	var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
	var incomingUser = currentUser;
	var apiToken;
	if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
		apiToken = apiToken_OutageStatusApp;
	} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
		apiToken = apiToken_chatbot;
	} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
		apiToken = apiToken_reportingApp;
	} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
		apiToken = apiToken_maximo;
	} else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
		apiToken = session.parameters.apiToken_Urma;
	}

	var finalArray = new Array();
	var CrewIdArray = ctx.getVariable('CrewIdArray');

	for (var i = 0; i < CrewIdArray.length; i++) {

		var crewAssignmentStatusArr = ctx.getVariable('status_' + CrewIdArray[i].id + '_lookup');
		var crewTypeArr = ctx.getVariable('status_' + CrewIdArray[i].crewtype + '_lookup');
		var workTypeArr = ctx.getVariable('status_' + CrewIdArray[i].workTypeID + '_lookup');
		ctx.setVariable("myarr_" + i, crewAssignmentStatusArr);
		ctx.setVariable("crewTypeArr_" + i, crewTypeArr);
		ctx.setVariable("workTypeArr_" + i, workTypeArr);
		var label = crewAssignmentStatusArr[0].label;

		var obj = {};
		if (CrewIdArray[i].crewId === '' || CrewIdArray[i].crewId === null || CrewIdArray[i].crewId === undefined) {
		} else {
			obj.crewId = CrewIdArray[i].crewId;
			if (crewAssignmentStatusArr[0].label === '' || crewAssignmentStatusArr[0].label === null || crewAssignmentStatusArr[0].label === undefined) {
			} else {
				obj.crewAssignmentStatus = label;
			}
			if (CrewIdArray[i].crewtype === crewTypeArr[0].status) {
				if (crewTypeArr[0].label === '' || crewTypeArr[0].label === null || crewTypeArr[0].label === undefined) {
				}
				else {
					obj.crewType = crewTypeArr[0].label;
				}
			}
			if (CrewIdArray[i].workTypeID === workTypeArr[0].id) {
				if (workTypeArr[0].label === '' || workTypeArr[0].label === null || workTypeArr[0].label === undefined) {
				}
				else {
					obj.workType = workTypeArr[0].label;
				}
			}
			if (CrewIdArray[i].destination === '' || CrewIdArray[i].destination === null || CrewIdArray[i].destination === undefined) {
				obj.destination = '';
				if (CrewIdArray[i].longitude === '' || CrewIdArray[i].longitude === null || CrewIdArray[i].longitude === undefined) {
					obj.longitude = '';
				}
				else {
					obj.longitude = CrewIdArray[i].longitude;
				}
				if (CrewIdArray[i].latitude === '' || CrewIdArray[i].latitude === null || CrewIdArray[i].latitude === undefined) {
					obj.latitude = '';
				}
				else {
					obj.latitude = CrewIdArray[i].latitude;
				}
			}
			else {
				obj.destination = CrewIdArray[i].destination;
				if (CrewIdArray[i].longitude === '' || CrewIdArray[i].longitude === null || CrewIdArray[i].longitude === undefined) {
					obj.longitude = '';
				}
				else {
					obj.longitude = CrewIdArray[i].longitude;
				}
				if (CrewIdArray[i].latitude === '' || CrewIdArray[i].latitude === null || CrewIdArray[i].latitude === undefined) {
					obj.latitude = '';
				}
				else {
					obj.latitude = CrewIdArray[i].latitude;
				}
			}
			finalArray.push(obj);
		}
	}
	ctx.setVariable('finalArr', finalArray);

	//ALM 5070
	var callAddressArray = new Array();
	var testArray = ctx.getVariable("testArray");
	var count = session.parameters.NoOfCalls;
	var callAdd = {};
	if (testArray.length !== 0) {
		for (var m = 0; m < testArray.length && m < count; m++) {
			if (testArray[m].status === '' || testArray[m].status === null || testArray[m].status === undefined) {
			}
			else {
				if (testArray[m].status === 'ACTIVE') {
					callAdd.address = testArray[m].address;
					callAddressArray.push(callAdd)
					callAdd = {};
				}
			}

		}
	}

	ctx.setVariable('callAddressArray', callAddressArray);

	if (leadCallID == undefined || leadCallID == '') {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		ctx.getVar("leadCallID");
	} else {

		var incomingUser = currentUser;
		var apiToken;
		if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
			apiToken = apiToken_OutageStatusApp;
		} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
			apiToken = apiToken_chatbot;
		} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
			apiToken = apiToken_reportingApp;
		} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
			apiToken = apiToken_maximo;
		}
		//Call GET /api/v1/ServiceType/Electric/Call/{id}
		var leadCallUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + leadCallID;
		var getLeadCallApi = {
			target: leadCallUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			headers: {
				'osiApiToken': apiToken
			},
		};

		var info = " TargetURL :" + getLeadCallApi.target + "; Method :" + getLeadCallApi.method + ". ";
		try {
			urlopen.open(getLeadCallApi, function(error, response) {
				if (error) {
					var errorinfo = "omsapiv2_044: url connection error with 'getLeadCallApi', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_044: " + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "omsapiv2_045: error reading response 'getLeadCallApi', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("omsapiv2_045: " + errorinfo);
								session.reject(errorinfo);
							} else {
								//hm.response.statusCode = responseStatusCode;
								//logger.error("omsapiv2_046:response received from getLeadCallApi"+ responseStatusCode);		
								var getLeadCallApiResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								ctx.setVariable("getLeadCallApiResponse", getLeadCallApiResponse);

								var leadCallResponseStausCode = responseStatusCode;
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								ctx.setVariable("leadCallResponseStausCode", leadCallResponseStausCode);
								var longtitude;
								var latitude;
								if (getLeadCallApiResponse.location != undefined) {
									if (getLeadCallApiResponse.location.coordinates != undefined) {
										longtitude = getLeadCallApiResponse.location.coordinates[0];
										latitude = getLeadCallApiResponse.location.coordinates[1];
										ctx.setVariable("longtitude_getLeadCall", longtitude);
										ctx.setVariable("latitude_getLeadCall", latitude);
									}
								}

								var phoneNumber = getLeadCallApiResponse.phoneNumber;
								if (phoneNumber === null || phoneNumber === undefined || phoneNumber === '') {
									phoneNumber = '';
									ctx.setVariable("phoneNumber", phoneNumber);
								} else {
									ctx.setVariable("phoneNumber", phoneNumber);
								}

								var contactMethod = JSON.stringify(getLeadCallApiResponse.contactMethod);
								//var contactMethod = ' ';
								if (contactMethod === undefined) {
									contactMethod = '';
									ctx.setVariable("contactMethod", contactMethod);
									//logger.error("inside contactmethod lookup file");
								} else {
									ctx.setVariable("contactMethod", contactMethod);
									//logger.error("else  contactmethod lookup file");
								}

								var premiseID = getLeadCallApiResponse.premiseID;
								if (premiseID === undefined) {
									premiseID = '';
									ctx.setVariable("premiseID", premiseID);
								} else {
									ctx.setVariable("premiseID", premiseID);
								}

								var name = getLeadCallApiResponse.name;
								if (name === null || name === undefined || name === '') {
									name = '';
									ctx.setVariable("name", name);
								} else {
									ctx.setVariable("name", name);
								}

								var meterID = getLeadCallApiResponse.meterID;
								if (meterID === null || meterID === undefined || meterID === '') {
									meterID = '';
									ctx.setVariable("meterID", meterID);
								} else {
									ctx.setVariable("meterID", meterID);
								}

								var externalCallCodeID = getLeadCallApiResponse.externalCallCodeID;
								if (externalCallCodeID === null || externalCallCodeID === undefined || externalCallCodeID === '') {
									externalCallCodeID = '';
									ctx.setVariable("externalCallCodeID", externalCallCodeID);
								} else {
									ctx.setVariable("externalCallCodeID", externalCallCodeID);
								}

								//ADO199295 starts
								var leadCallAddress;
								if ((getLeadCallApiResponse.address != undefined) && (getLeadCallApiResponse.address != null) && (getLeadCallApiResponse.address != '')) {
									leadCallAddress = getLeadCallApiResponse.address;
									ctx.setVariable("leadCallAddress", leadCallAddress);
								} else {
									ctx.setVariable("leadCallAddress", "");
								}
								//ADO199295 ends

							}
						});
					} else {
						var leadCallResponseStausCode = responseStatusCode;
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
						ctx.setVariable("leadCallResponseStausCode", leadCallResponseStausCode);
						logger.error("omsapiv2_047:Unable to find in getLeadCallApiResponse call" + " " + responseStatusCode);
					}
				}
			});
		} catch (err) {
			var errorinfo = "omsapiv2_044: url connection error with 'getcallApi', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error("omsapiv2_044: " + errorinfo);
			session.reject(errorinfo);
		}
		//end	
	}

	//aor LookupStart : Using "aorID" do a lookup and get label.
	var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
	var aorID = ctx.getVar("aorID");
	var aorIDLength = aorID.length;
	if (aorIDLength > 0) {
		var aorLookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "aors",
						"id": aorID
					}
				]
			}
		}
		var aorLookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: aorLookupMessage
		};

		var info = " TargetURL :" + aorLookupServiceResponse.target + "; Method :" + aorLookupServiceResponse.method + "; Data :" + JSON.stringify(aorLookupServiceResponse.data) + ". ";
		try {
			urlopen.open(aorLookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "omsapiv2_048: url connection error with 'aorLookupServiceResponse', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_048: " + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapv2_049: error reading response 'aorLookupServiceResponse', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("omsapv2_049: " + errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								//logger.error("omsapiv2_050:response received from aorLookupServiceResponse:"+ responseStatusCode);		
								var aorLookupServiceResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								//ctx.setVariable("aorLookupServiceResponse", aorLookupServiceResponse);
								var label;
								if (aorLookupServiceResponse.lookupRep.type[0].result == 0) {
									label = aorLookupServiceResponse.lookupRep.type[0].label;
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("aorLookup", label);
								} else {
									var label = '';
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("aorLookup", label);
									logger.error("label is not found from aorLookupServiceResponse");
								}
							}
						});
					} else {
						logger.error("omsapiv2_051:Unable to find the label details in aorLookupServiceResponse call" + " " + responseStatusCode);
					}
				}

			});
		} catch (err) {
			var errorinfo = "omsapiv2_048: url connection error with 'aorLookupServiceResponse', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error("omsapiv2_048: " + errorinfo);
			session.reject(errorinfo);
		}

	} else {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		ctx.getVar("aorID");

	}


	//end 	


	//Lookup calls start leadAssignmentWorkTypeID and leadAssignmentStatus------	
	//if((leadAssignmentWorkTypeID !=null && leadAssignmentWorkTypeID !='' && leadAssignmentWorkTypeID != undefined) && (leadAssignmentStatus !=null && leadAssignmentStatus !='' && leadAssignmentStatus != undefined)){ 
	//if((leadAssignmentWorkTypeID ===null && leadAssignmentWorkTypeID ===' ' && leadAssignmentWorkTypeID === undefined) && (leadAssignmentStatus ===null && leadAssignmentStatus ==='' && leadAssignmentStatus === undefined)){	
	console.log("leadAssignmentWorkTypeID lookup");
	//workflow LookupStart :  lookup using the WorkTypeID (leadAssignmentWorkTypeID) and the leadAssignmentStatus, 
	/* var leadAssignmentLookupMessage= 	{
			"lookupReq": {
				"type": [
					{
						"name": "workType.workflows",
						"id": leadAssignmentWorkTypeID,
						"status": leadAssignmentStatus
					}
				]
			}
		}
	var leadAssignmentLookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data:leadAssignmentLookupMessage
		};
	urlopen.open(leadAssignmentLookupServiceResponse, function(error, response) {
		if (error) {
			logger.error("omsapiv2_056:urlopen connect error with leadAssignmentLookupService" + JSON.stringify(error));
			session.reject("urlopen connect error with leadAssignmentLookupService");
		} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 )  {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("omsapiv2_057:failure in putting message to leadAssignmentLookupService" + JSON.stringify(error));
								session.reject("failure in putting message to leadAssignmentLookupService");
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.error("response received from leadAssignmentLookupServiceResponse:"+ responseStatusCode);		
								var leadAssignmentLookupServiceResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
								ctx.setVariable("leadAssignmentLookupServiceResponse", leadAssignmentLookupServiceResponse);
								
								//start 
								if(leadAssignmentLookupServiceResponse.lookupRep.type[0].result==0){
									var label = leadAssignmentLookupServiceResponse.lookupRep.type[0].label;
									if(label !=undefined && label !=null){
										var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
										ctx.setVariable("crewAssignmentStatus", label);
									} else {
										var label='';
										var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
										ctx.setVariable("crewAssignmentStatus", label);
									}
								} else {
									logger.error("label is not found from jobStatusLookupServiceResponse");
								}
								
							}
						});
					} else {
						logger.error("omsapiv2_058:Unable to find the label details in leadAssignmentLookupServiceResponse call"+" "+responseStatusCode);
					}
		   }
	}); 
} else if (leadAssignmentID !=null && leadAssignmentID != undefined && leadAssignmentID !='') { */
	/* 	//call GET /api/v1/ServiceType/Electric/CrewAssignment/{id}
		console.log("leadAssignmentID lookup else confition");
		//workflow LookupStart :  lookup using the WorkTypeID (leadAssignmentWorkTypeID) and the leadAssignmentStatus, 
		//var getCrewAssignmentUrl = omsExternalURL + '/api/v1/ServiceType/Electric/CrewAssignment/' + leadAssignmentID;
		var getCrewAssignmentUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job/'+internalId+'/CrewAssignment/';
		
		var incomingUser = currentUser;
		var apiToken;
		if(incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd'){
			apiToken = apiToken_OutageStatusApp;
		}else if(incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd'){
			apiToken = apiToken_chatbot;
		} else if(incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd'){
			apiToken = apiToken_reportingApp;
		} else if(incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod'){
			apiToken = apiToken_maximo;
		}  
		
		var getCrewAssignmentApi = {
			target: getCrewAssignmentUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
		};
		
		urlopen.open(getCrewAssignmentApi, function(error, response) {
			if (error) {
				logger.error("omsapiv2_059:urlopen connect error with getCrewAssignmentApi" + JSON.stringify(error));
				session.reject("urlopen connect error with getCrewAssignmentApi");
			} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200 )  {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									logger.error("omsapiv2_060:failure in putting message to getCrewAssignmentApi" + JSON.stringify(error));
									session.reject("failure in putting message to getCrewAssignmentApi");
								} else {
									hm.response.statusCode = responseStatusCode;
									//logger.error("omsapiv2_061:response received from getCrewAssignmentApi"+ responseStatusCode);		
									var getCrewAssignmentResponse = JSON.parse(responseData);
									var getCrewAssignmentResponseDataArr = getCrewAssignmentResponse.data;
							for(var i=0; i<getCrewAssignmentResponseDataArr.length; i++){
									var workTypeID = getCrewAssignmentResponseDataArr[i].workTypeID;
									var status = getCrewAssignmentResponseDataArr[i].status;
									var  crewId = getCrewAssignmentResponseDataArr[i].crew.externalID;
									if(crewId === undefined || crewId ==='' || crewId === null)
										crewId ='';
									var crewArr = new Array();
									//var status = getCrewAssignmentResponse.status;
									var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
									//ctx.setVariable("getCrewAssignmentResponse", getCrewAssignmentResponse);
									ctx.setVariable("workTypeID", workTypeID);
									ctx.setVariable("crewId", crewId);
									ctx.setVariable("status", status);
									//Make  workflow lookup call with workTypeID and Status
									var leadAssignmentLookupMessage= 	{
											"lookupReq": {
												"type": [
													{
														"name": "workType.workflows",
														"id": workTypeID,
														"status": status
													}
												]
											}
										}
									var leadAssignmentLookupServiceResponse = {
											target: lookupURL,
											method: 'POST',
											contentType: 'application/json',
											data:leadAssignmentLookupMessage
										};
									
									urlopen.open(leadAssignmentLookupServiceResponse, function(error, response) {
										if (error) {
											logger.error("omsapiv2_062:urlopen connect error with leadAssignmentLookupService" + JSON.stringify(error));
											session.reject("urlopen connect error with leadAssignmentLookupService");
										} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200 )  {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																logger.error("omsapiv2_063:failure in putting message to leadAssignmentLookupService" + JSON.stringify(error));
																session.reject("failure in putting message to leadAssignmentLookupService");
															} else {
																hm.response.statusCode = responseStatusCode;
																logger.error("omsapiv2_064:response received from leadAssignmentLookupServiceResponse:"+ responseStatusCode);		
																var leadAssignmentLookupServiceResponse = JSON.parse(responseData);
																var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
																//ctx.setVariable("leadAssignmentLookupServiceResponse", leadAssignmentLookupServiceResponse);
																var label ;
																
																//start 
																if(leadAssignmentLookupServiceResponse.lookupRep.type[0].result==0){
																	var label = leadAssignmentLookupServiceResponse.lookupRep.type[0].label;
																	if(label !=undefined && label !=null){
																		var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
																		var crewId = ctx.getVariable("crewId");
																		//ctx.setVariable("crewAssignmentStatus", label);
																		ctx.setVariable("crewAssignmentStatus_"+crewId, label);
																	} else {
																		var label='';
																		var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
																		//ctx.setVariable("crewAssignmentStatus", label);
																		var crewId = ctx.getVariable("crewId");
																		ctx.setVariable("crewAssignmentStatus_"+crewId, label);
																	}
																} else {
																	logger.error("label is not found from leadAssignmentLookupServiceResponse");
																}
																//end 
															}
														});
													} else {
														logger.error("omsapiv2_065:Unable to find the label details in leadAssignmentLookupServiceResponse call"+" "+responseStatusCode);
													}
										   }
									}); 
								}//end for loop
								}
							});
						} else {
							logger.error("omsapiv2_066:Unable to find the details in getCrewAssignmentResponse call"+" "+responseStatusCode);
						}
			   }
		}); */
	/* } else {
		var label ='';
		var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
		ctx.setVariable("crewAssignmentStatus", label);
		logger.error("omsapiv2_067:unable to find leadAssignmentStatus,leadAssignmentWorkTypeID,leadAssignmentID from the jobAPI call");
	} */


	//End :lookup call ends leadAssignmentWorkTypeID and leadAssignmentStatus------

	//Start:JobTypeId Lookup Start :Do a lookup using jobTypeID and get "externalID".

	if (jobTypeID == undefined || jobTypeID == '') {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		ctx.getVar("jobTypeID");
	} else {
		var jobTypeLookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "jobTypes",
						"id": jobTypeID
					}
				]
			}
		}
		var jobTypeLookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: jobTypeLookupMessage
		};
		//ctx.setVariable("jobTypeLookupRequest", jobTypeLookupMessage);
		//ctx.setVariable(" jobStatusLookupServiceResponse", jobStatusLookupServiceResponse);

		var info = " TargetURL :" + jobTypeLookupServiceResponse.target + "; Method :" + jobTypeLookupServiceResponse.method + "; Data :" + JSON.stringify(jobTypeLookupServiceResponse.data) + ". ";
		try {
			urlopen.open(jobTypeLookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "omsapiv2_068: url connection error 'jobTypeLookupServiceResponse', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_068: " + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "omsapiv2_069: error reading response 'jobTypeLookupServiceResponse', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("omsapiv2_069: " + errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								//logger.error("omsapiv2_070:response received from jobTypeLookupServiceResponse:"+ responseStatusCode);		
								var jobTypeLookupServiceResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								//ctx.setVariable("jobTypeLookupServiceResponse", jobTypeLookupServiceResponse);
								//var label ;
								if (jobTypeLookupServiceResponse.lookupRep.type[0].result == 0) {
									var label = jobTypeLookupServiceResponse.lookupRep.type[0].label;
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("jobType", label);
								} else {
									var label = '';
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("jobType", label);
									logger.error("label is not found from jobTypeLookupServiceResponse");
								}
							}
						});
					} else {
						logger.error("omsapiv2_071:Unable to find the label details in jobTypeLookupServiceResponse call" + " " + responseStatusCode);
					}
				}
			});
		} catch (err) {
			var errorinfo = "omsapiv2_068: url connection error with 'jobTypeLookupServiceResponse', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error("omsapiv2_068: " + errorinfo);
			session.reject(errorinfo);
		}
	}

	// End: Jobtype Lookup

	//OutageSubType Lookup Start :Do a lookup using outageSubTypes and get "externalID".
	if (outageSubTypeID == undefined || outageSubTypeID == '') {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		ctx.getVar("outageSubTypeID");
	} else {
		var outageSubTypeLookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "outageSubtypes",
						"id": outageSubTypeID
					}
				]
			}
		}

		var outageSubTypeLookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: outageSubTypeLookupMessage
		};

		var info = " TargetURL :" + outageSubTypeLookupServiceResponse.target + "; Method :" + outageSubTypeLookupServiceResponse.method + "; Data :" + JSON.stringify(outageSubTypeLookupServiceResponse.data) + ". ";
		try {
			urlopen.open(outageSubTypeLookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "omsapiv2_072: url connection error with 'outageSubTypeLookupServiceResponse', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_072: " + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapiv2_073: error reading response 'outageSubTypeLookupServiceResponse', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("omsapiv2_073: " + errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								//logger.error("omsapiv2_074:response received from outageSubTypeLookupServiceResponse:"+ responseStatusCode);		
								var outageSubTypeLookupServiceResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								ctx.setVariable("outageSubTypeLookupServiceResponse", outageSubTypeLookupServiceResponse);
								var label;
								if (outageSubTypeLookupServiceResponse.lookupRep.type[0].result == 0) {
									label = outageSubTypeLookupServiceResponse.lookupRep.type[0].label;
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("outageSubType", label);
								} else {
									var label = '';
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("outageSubType", label);
									logger.error("label is not found from outageSubTypeLookupServiceResponse");
								}
							}
						});
					} else {
						logger.error("omsapiv2_075:Unable to find the label details in outageSubTypeLookupServiceResponse call" + " " + responseStatusCode);
					}
				}
			});
		} catch (err) {
			var errorinfo = "omsapiv2_072: url connection error with 'outageSubTypeLookupServiceResponse', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error("omsapiv2_072: " + errorinfo);
			session.reject(errorinfo);
		}
	}

	//var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
	//var leadCrewExternalID = ctx.getVar("leadCrewExternalID");
	if ((leadCrewExternalID == undefined || leadCrewExternalID == '') && (leadCrewID == undefined || leadCrewID == '')) {
		//logger.error("leadCrewExternalID, leadCrewID not found from the getJobAPI call");
		console.log("inside 1st if");
	} else if (leadCrewExternalID != null || leadCrewExternalID != '' || leadCrewExternalID != undefined) {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		ctx.getVar("leadCrewExternalID");
		console.log("inside 2nd if");
	} else {
		console.log("else condition");
		//Start :crewId call Start :call  GET /api/ServiceType/Electric/Crew/{id} 
		console.log("inside final else  if");
		var incomingUser = currentUser;
		var apiToken;
		if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
			apiToken = apiToken_OutageStatusApp;
		} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
			apiToken = apiToken_chatbot;
		} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
			apiToken = apiToken_reportingApp;
		} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
			apiToken = apiToken_maximo;
		}

		var crewCallUrl = omsExternalURL + '/api/ServiceType/Electric/Crew/' + leadCrewID;
		var getCrewApi = {
			target: crewCallUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
		};

		var info = " TargetURL :" + getCrewApi.target + "; Method :" + getCrewApi.method + ". ";
		try {
			urlopen.open(getCrewApi, function(error, response) {
				if (error) {
					var errorinfo = "url connection error 'getCrewApi', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'getCrewApi', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								logger.error("response received from getCrewApi " + responseStatusCode);
								var getCrewApiResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								var externalID = getCrewApiResponse.externalID;
								//ctx.setVariable("getCrewApiResponse---", getCrewApiResponse);
								ctx.setVariable("externalID", externalID);
							}
						});
					} else {
						logger.error("Unable to find the details in getCrewApiResponse call" + " " + responseStatusCode);
					}
				}
			});
		} catch (err) {
			var errorinfo = "url connection error with 'getCrewApi', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
		//End:crewId call end
	}

	//Start networkModelType

	var networkModelType = ctx.getVar("networkModelType");
	var networkModelTypeLength = networkModelType.length;

	if (networkModelTypeLength > 0) {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		logger.debug("inside if networkModelType");
		var networkModelTypeLookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "networkModelTypeLabels",
						"status": networkModelType
					}
				]
			}
		}
		var networkLookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: networkModelTypeLookupMessage
		};


		var info = " TargetURL :" + networkLookupServiceResponse.target + "; Method :" + networkLookupServiceResponse.method + "; Data :" + JSON.stringify(networkLookupServiceResponse.data) + ". ";
		try {
			urlopen.open(networkLookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "omsapiv2_052: url connection error with 'networkLookupServiceResponse', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					logger.error("omsapiv2_052: " + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'networkLookupServiceResponse', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								//logger.error("response received from networkLookupServiceResponse:"+ responseStatusCode);		
								var networkLookupServiceResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								ctx.setVariable("networkLookupServiceResponse", networkLookupServiceResponse);
								if (networkLookupServiceResponse.lookupRep.type[0].result == 0) {
									var label = networkLookupServiceResponse.lookupRep.type[0].label;
									if (label != undefined && label != null) {
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										ctx.setVariable("networkLabel", label);
									} else {
										var networkLabel = '';
										var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
										ctx.setVariable("networkLabel", networkLabel);
									}
								} else {
									logger.error("label is not found from networkLookupServiceResponse");
								}
							}
						});
					} else {
						logger.error("Unable to find the label details in networkLookupServiceResponse call" + " " + responseStatusCode);
					}
				}
			});
		} catch (err) {
			var errorinfo = "omsapiv2_052: url connection error with 'networkLookupServiceResponse', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error("omsapiv2_052: " + errorinfo);
			session.reject(errorinfo);
		}
	} else {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		var networkModelType = '';
		ctx.getVar("networkModelType");
	}


	//End networkModelType		


	//Start JobStatus Lookup  : Using "JobStatus" do a lookup and get label. -------------------
	var jobStatusLookupMessage = {
		"lookupReq": {
			"type": [
				{
					"name": "jobTypes.workflows",
					"id": jobTypeID,
					"status": status
				}
			]
		}
	}
	var jobStatusLookupServiceResponse = {
		target: lookupURL,
		method: 'POST',
		contentType: 'application/json',
		data: jobStatusLookupMessage
	};

	var info = " TargetURL :" + jobStatusLookupServiceResponse.target + "; Method :" + jobStatusLookupServiceResponse.method + "; Data :" + JSON.stringify(jobStatusLookupServiceResponse.data) + ". ";
	try {
		urlopen.open(jobStatusLookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "omsapiv2_052: url connection error with 'jobStatusLookupServiceResponse', details are : " + info + "; error info :" + error
				ctx.setVar('errorDescription', errorinfo);
				ctx.setVariable("errorStatusCode", response.statusCode);
				ctx.setVariable("errorMessage", response.reasonPhrase);
				logger.error("omsapiv2_052: " + errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "omsapiv2_053: error reading response 'jobStatusLookupServiceResponse', details are : " + info + "; error info :" + error
							ctx.setVar('errorDescription', errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							logger.error("omsapiv2_053: " + errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = responseStatusCode;
							//logger.error("omsapiv2_054:response received from jobStatusLookupServiceResponse:"+ responseStatusCode);		
							var jobStatusLookupServiceResponse = JSON.parse(responseData);
							var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
							ctx.setVariable("jobStatusLookupServiceResponse", jobStatusLookupServiceResponse);
							if (jobStatusLookupServiceResponse.lookupRep.type[0].result == 0) {
								var label = jobStatusLookupServiceResponse.lookupRep.type[0].label;
								if (label != undefined && label != null) {
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("jobStatus", label);
								} else {
									var jobStatus = '';
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("jobStatus", jobStatus);
								}
							} else {
								logger.error("label is not found from jobStatusLookupServiceResponse");
							}
						}
					});
				} else {
					logger.error("omsapiv2_055:Unable to find the label details in jobStatusLookupServiceResponse call" + " " + responseStatusCode);
				}
			}
		});
	} catch (err) {
		var errorinfo = "omsapiv2_052: url connection error with 'jobStatusLookupServiceResponse', details are : " + info + "; error info :" + err
		ctx.setVar('errorDescription', errorinfo);
		logger.error("omsapiv2_052: " + errorinfo);
		session.reject(errorinfo);
	}
	//end jobStatus Lookup---------------------

});
