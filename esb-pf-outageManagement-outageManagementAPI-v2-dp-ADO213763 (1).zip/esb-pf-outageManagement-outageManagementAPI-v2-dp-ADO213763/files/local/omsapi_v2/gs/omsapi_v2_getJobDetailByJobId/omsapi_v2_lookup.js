var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var url = session.parameters.lookUpURL;
//var url = "http://localhost:8080/lookup"; 

function doLookup(arrObj, lookupCtx) {
	//console.error("array length " + arrObj.length);
	var request = {};
	request.type = arrObj;
	var lookupUrl = url;
	var options = {
		target: lookupUrl,
		method: 'post',
		contentType: 'application/json',
		data: { "lookupReq": request }
	};
	// open connection to target

	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			var ctx = session.name('omsApiv2') || session.createContext('omsApiv2');
			if (error) {
				var errorinfo = "url connection error with 'lookupURL', details are : " + info + "; error info :" + error
				ctx.setVar('errorDescription', errorinfo);
				ctx.setVariable("errorStatusCode", error.errorCode);
				ctx.setVariable("errorMessage", error.errorMessage);
				ctx.setVariable("customErrorCode", error.errorCode);
				ctx.setVariable("customErrorMessage", error.errorMessage);
				ctx.setVariable("customReasonPhrase", error.errorMessage);
				session.output.write(errorinfo);
				session.reject(errorinfo);

			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						var ctx = session.name('omsApiv2') || session.createContext('omsApiv2');
						ctx.setVariable('lookupResponseData', responseData);
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "error reading response 'lookupURL', details are : " + info + "; error info :" + error
							ctx.setVar('errorDescription', errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorMessage", responsePhrase);
							session.output.write(errorinfo);
						} else {
							var lookupResponse = responseData.lookupRep.type;
							ctx.setVariable(lookupCtx + "_lookup", lookupResponse);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading message 'lookupURL', details are : " + info + "; error info :" + error
							ctx.setVar('errorDescription', errorinfo);
							logger.error(errorinfo);

						} else {
							var errorinfo = "error response 'lookupURL', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVar('errorDescription', errorinfo);
							logger.error(errorinfo);
							session.output.write(errorinfo);

						}
					});


				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error with 'lookupURL', details are : " + info + "; error info :" + err
		ctx.setVar('errorDescription', errorinfo);
		ctx.setVariable("customErrorCode", err.errorCode);
		ctx.setVariable("customErrorMessage", err.errorMessage);
		ctx.setVariable("customReasonPhrase", err.errorMessage);
		session.output.write(errorinfo);
		session.reject(errorinfo);
	}
	/* 
	 */


}//end of function 

module.exports = doLookup;
