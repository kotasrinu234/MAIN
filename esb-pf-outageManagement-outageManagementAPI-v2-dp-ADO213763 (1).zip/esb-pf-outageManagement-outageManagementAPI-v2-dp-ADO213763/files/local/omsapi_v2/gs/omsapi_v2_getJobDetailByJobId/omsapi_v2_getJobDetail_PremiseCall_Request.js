var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");
var lookupURL = ctx.getVar("lookupURL");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");
var omsElectra = session.parameters.labelName;
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var logger = console.options({
	'category': 'all'
});

session.input.readAsBuffer(function(readAsJSONError, incomingdata) {

	var incomingUser = currentUser;
	var apiToken;
	if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
		apiToken = apiToken_OutageStatusApp;
	} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
		apiToken = apiToken_chatbot;
	} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
		apiToken = apiToken_reportingApp;
	} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
		apiToken = apiToken_maximo;
	}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}

	var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
	var leadCallID = ctx.getVar("leadCallID");
	var premiseID = ctx.getVar("premiseID");
	var leadCallResponseStausCode = ctx.getVar("leadCallResponseStausCode");

	if (leadCallID == undefined || leadCallID == '' || leadCallID == null) {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		var premiseID = '';
		ctx.getVar("premiseID");
		console.log("inside lead call blank ");
	} else if (leadCallResponseStausCode == 200) {
		console.log("inside leadCallResponseStausCode 200 ");
		//Start  Premise call Call GET /api/v1/Premise/{id}
		var premiseCallUrl = omsExternalURL + '/api/v1/Premise/' + premiseID;
		var getPremiseApi = {
			target: premiseCallUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': apiToken
			},
		};

		var info = " TargetURL :" + getPremiseApi.target + "; Method :" + getPremiseApi.method + ". ";
		try {
			urlopen.open(getPremiseApi, function(error, response) {
				if (error) {
					var errorinfo = "omsapiv2_080: url connection error with 'getPremiseApi', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_080: " + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapiv2_081: error reading response 'getPremiseApi', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("omsapiv2_081: " + errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								//logger.error("omsapiv2_082:response received from getPremiseApi "+ responseStatusCode);		
								var getPremiseApiResponse = JSON.parse(responseData.toString());
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");


								var premiseId = getPremiseApiResponse.externalID;
								if (premiseId == undefined) {
									premiseId = '';
									ctx.setVariable("premiseId", premiseId);
								}
								else {
									ctx.setVariable("premiseId", premiseId);
								}

								var longtitude;
								var latitude;
								if (getPremiseApiResponse.location != undefined) {
									if (getPremiseApiResponse.location.coordinates != undefined) {
										longtitude = getPremiseApiResponse.location.coordinates[0];
										latitude = getPremiseApiResponse.location.coordinates[1];
										ctx.setVariable("longtitude_premiseCall", longtitude);
										ctx.setVariable("latitude_premiseCall", latitude);
									}
								}
							}
						});
					} else {
						logger.error("omsapiv2_083:Unable to find the details in getPremiseApiResponse call" + " " + responseStatusCode);
					}
				}
			});
		} catch (err) {
			var errorinfo = "omsapiv2_080: url connection error with 'getPremiseApi', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error("omsapiv2_080: " + errorinfo);
			session.reject(errorinfo);
		}

	} else {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		var premiseID = '';
		ctx.getVar("premiseID");
		console.log("inside lead response 400l blank ");
	}

	//Lookup Start :using the "contactMethod" field from GET Call API and label "OMS Electra (Internal)" do a lockup.

	var contactMethod = ctx.getVar("contactMethod");
	console.log("contact value is------" + contactMethod);
	if (leadCallID == undefined || leadCallID == '' || leadCallID == null) {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		var contactMethod = '';
		ctx.getVar("contactMethod");
		console.log("inside lead contactMethod call blank ");
	} else if (leadCallResponseStausCode == 200) {
		var contactMethodLookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "contactMethodTypes",
						"status": contactMethod
					}
				]
			}
		}

		var contactMethodLookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: contactMethodLookupMessage
		};

		var info = " TargetURL :" + contactMethodLookupServiceResponse.target + "; Method :" + contactMethodLookupServiceResponse.method + "; Data :" + JSON.stringify(contactMethodLookupServiceResponse.data) + ". ";
		try {
			urlopen.open(contactMethodLookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "omsapiv2_084:url connection error with 'contactMethodLookupServiceResponse', details are : " + info + "; error info :" + error
					ctx.setVar('errorDescription', errorinfo);
					ctx.setVariable("errorStatusCode", response.statusCode);
					ctx.setVariable("errorMessage", response.reasonPhrase);
					logger.error("omsapiv2_084:" + errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "omsapiv2_085:error reading response 'contactMethodLookupServiceResponse', details are : " + info + "; error info :" + error
								ctx.setVar('errorDescription', errorinfo);
								ctx.setVariable("errorStatusCode", responseStatusCode);
								ctx.setVariable("errorMessage", responsePhrase);
								logger.error("omsapiv2_085:" + errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								//logger.error("omsapiv2_086:response received from contactMethodLookupServiceResponse:"+ responseStatusCode);		
								var contactMethodLookupServiceResponse = JSON.parse(responseData);
								var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
								ctx.setVariable("contactMethodLookupServiceResponse", contactMethodLookupServiceResponse);
								if (contactMethodLookupServiceResponse.lookupRep.type[0].result == 0) {
									var label = contactMethodLookupServiceResponse.lookupRep.type[0].label;
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("contactMethod", label);
								} else {
									var label = '';
									var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
									ctx.setVariable("contactMethod", label);
									logger.error("label is not found from contactMethodLookupServiceResponse");
								}
							}
						});
					} else {
						logger.error("omsapiv2_087:Unable to find the label details in contactMethodLookupServiceResponse call" + " " + responseStatusCode);
					}
				}
			});
		} catch (err) {
			var errorinfo = "omsapiv2_084:url connection error with 'contactMethodLookupServiceResponse', details are : " + info + "; error info :" + err
			ctx.setVar('errorDescription', errorinfo);
			logger.error("omsapiv2_084:" + errorinfo);
			session.reject(errorinfo);
		}
	} else {
		var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
		ctx.getVar("contactMethod");
		console.log("inside contactMethod lead response 400 blank ");
	}

});
