var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
var omsExternalURL = ctx.getVar("omsExternalURL");
//var apiToken= ctx.getVar("apiToken");
var leadCallID = ctx.getVar("leadCallID");
var lookupURL = ctx.getVar("lookupURL");
var jobTypeID = ctx.getVar("jobTypeID");
var internalId = ctx.getVar("internalId");

//var aorID = ctx.getVar("aorID");
var status = ctx.getVar("status");
/* var leadAssignmentWorkTypeID = ctx.getVar("leadAssignmentWorkTypeID");
var leadAssignmentStatus = ctx.getVar("leadAssignmentStatus"); */
var outageSubTypeID = ctx.getVar("outageSubTypeID");
var leadAssignmentID = ctx.getVar("leadAssignmentID");
var leadCrewID = ctx.getVar("leadCrewID");
//var networkModelType = ctx.getVar("networkModelType");
var leadCrewExternalID = ctx.getVar("leadCrewExternalID");
var apiToken_OutageStatusApp = ctx.getVar("apiToken");
var apiToken_chatbot = ctx.getVar("apiToken_chatbot");
var apiToken_reportingApp = ctx.getVar("apiToken_reporting");
var apiToken_maximo = ctx.getVar("apiToken_maximo");

var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var logger = console.options({
	'category': 'all'
});
var finalArr = new Array();

function getByValue2(arr, value) {

	var result = arr.filter(function(o) {
		return o.workTypeID == value;
	});

	return result ? result[0] : null; // or undefined

}

//condition removed start

var getCrewAssignmentUrl = omsExternalURL + '/api/ServiceType/Electric/Job/' + internalId + '/CrewAssignment?excludeResolved=false&join=true';
var crewArr = new Array();
var crewIdWorkIdArr = new Array();
var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
ctx.setVariable('crewArr', crewArr);
var incomingUser = currentUser;
var apiToken;
if (incomingUser == 'dcas-opa-esb-oms-dev' || incomingUser == 'dcas-opa-esb-oms-tst' || incomingUser == 'dcas-opa-esb-oms-prd') {
	apiToken = apiToken_OutageStatusApp;
} else if (incomingUser == 'dcas-cbo-esb-oms-dev' || incomingUser == 'dcas-cbo-esb-oms-tst' || incomingUser == 'dcas-cbo-esb-oms-prd') {
	apiToken = apiToken_chatbot;
} else if (incomingUser == 'dcas-rpa-esb-oms-dev' || incomingUser == 'dcas-rpa-esb-oms-tst' || incomingUser == 'dcas-rpa-esb-oms-prd') {
	apiToken = apiToken_reportingApp;
} else if (incomingUser == 'dcas-eam-sr-esb-dev' || incomingUser == 'dcas-eam-sr-esb-test' || incomingUser == 'dcas-eam-sr-esb-prod') {
	apiToken = apiToken_maximo;
}else if (incomingUser == 'urma-esb-dev' || incomingUser == 'urma-esb-test' || incomingUser == 'urma-esb-prod') {
	apiToken = session.parameters.apiToken_Urma;
}

var getCrewAssignmentApi = {
	target: getCrewAssignmentUrl,
	sslClientProfile: 'omsapi_client_profile',
	method: 'GET',
	contentType: 'application/json',
	headers: {
		'osiApiToken': apiToken
	},
};

var info = " TargetURL :" + getCrewAssignmentApi.target + "; Method :" + getCrewAssignmentApi.method + ". ";
try {
	urlopen.open(getCrewAssignmentApi, function(error, response) {
		if (error) {
			var errorinfo = "omsapiv2_059: url connection error with 'getCrewAssignmentApi', details are : " + info + "; error info :" + error
			ctx.setVar('errorDescription', errorinfo);
			ctx.setVariable("errorStatusCode", response.statusCode);
			ctx.setVariable("errorMessage", response.reasonPhrase);
			logger.error("omsapiv2_059: " + errorinfo);
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			var responsePhrase = response.reasonPhrase;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response 'getCrewAssignmentApi', details are : " + info + "; error info :" + error
						ctx.setVar('errorDescription', errorinfo);
						ctx.setVariable("errorStatusCode", responseStatusCode);
						ctx.setVariable("errorMessage", responsePhrase);
						logger.error("omsapiv2_060: " + errorinfo);
						session.reject(errorinfo);
					} else {
						hm.response.statusCode = responseStatusCode;
						//logger.error("omsapiv2_061:response received from getCrewAssignmentApi"+ responseStatusCode);		
						var getCrewAssignmentResponse = JSON.parse(responseData);
						var getCrewAssignmentResponseDataArr = getCrewAssignmentResponse.data;
						//ctx.setVariable("getCrewAssignmentResponse", getCrewAssignmentResponse);


						for (var i = 0; i < getCrewAssignmentResponseDataArr.length; i++) {
							var jsonObj = {};
							if (getCrewAssignmentResponseDataArr[i].status === undefined || getCrewAssignmentResponseDataArr[i].status === null || getCrewAssignmentResponseDataArr[i].status === "") {
							} else {
								jsonObj.status = getCrewAssignmentResponseDataArr[i].status;
							}
							if (getCrewAssignmentResponseDataArr[i].id === undefined || getCrewAssignmentResponseDataArr[i].id === null || getCrewAssignmentResponseDataArr[i].id === "") {
							} else {
								jsonObj.id = getCrewAssignmentResponseDataArr[i].id;
							}
							if (getCrewAssignmentResponseDataArr[i].crew === undefined || getCrewAssignmentResponseDataArr[i].crew === null || getCrewAssignmentResponseDataArr[i].crew === "") {
								if (getCrewAssignmentResponseDataArr[i].destination === undefined || getCrewAssignmentResponseDataArr[i].destination === null || getCrewAssignmentResponseDataArr[i].destination === "") {
								} else {
									jsonObj.destination = getCrewAssignmentResponseDataArr[i].destination;
									if (getCrewAssignmentResponseDataArr[i].location === null || getCrewAssignmentResponseDataArr[i].location === undefined || getCrewAssignmentResponseDataArr[i].location === "") {
									} else {
										if (getCrewAssignmentResponseDataArr[i].location.type === 'Point') {
											if (getCrewAssignmentResponseDataArr[i].location.coordinates[0] === null || getCrewAssignmentResponseDataArr[i].location.coordinates[0] === undefined || getCrewAssignmentResponseDataArr[i].location.coordinates[0] === "") {
											} else {
												jsonObj.longitude = getCrewAssignmentResponseDataArr[i].location.coordinates[0]
											}
											if (getCrewAssignmentResponseDataArr[i].location.coordinates[1] === null || getCrewAssignmentResponseDataArr[i].location.coordinates[1] === undefined || getCrewAssignmentResponseDataArr[i].location.coordinates[1] === "") {
											} else {
												jsonObj.latitude = getCrewAssignmentResponseDataArr[i].location.coordinates[1];
											}
										}
									}
								}
							} else {
								if (getCrewAssignmentResponseDataArr[i].crew.externalID === undefined || getCrewAssignmentResponseDataArr[i].crew.externalID === null || getCrewAssignmentResponseDataArr[i].crew.externalID === "") {
								} else {
									jsonObj.crewId = getCrewAssignmentResponseDataArr[i].crew.externalID;
									if (getCrewAssignmentResponseDataArr[i].workTypeID === undefined || getCrewAssignmentResponseDataArr[i].workTypeID === null || getCrewAssignmentResponseDataArr[i].workTypeID === "") {
									} else {
										jsonObj.workTypeID = getCrewAssignmentResponseDataArr[i].workTypeID;
									}
									if (getCrewAssignmentResponseDataArr[i].crew.type === undefined || getCrewAssignmentResponseDataArr[i].crew.type === null || getCrewAssignmentResponseDataArr[i].crew.type === "") {
									} else {
										jsonObj.crewtype = getCrewAssignmentResponseDataArr[i].crew.type;
									}
								}
								if (getCrewAssignmentResponseDataArr[i].destination === undefined || getCrewAssignmentResponseDataArr[i].destination === null || getCrewAssignmentResponseDataArr[i].destination === "") {
								} else {
									jsonObj.destination = getCrewAssignmentResponseDataArr[i].destination;
									if (getCrewAssignmentResponseDataArr[i].location === null || getCrewAssignmentResponseDataArr[i].location === undefined || getCrewAssignmentResponseDataArr[i].location === "") {
									} else {
										if (getCrewAssignmentResponseDataArr[i].location.type === 'Point') {
											if (getCrewAssignmentResponseDataArr[i].location.coordinates[0] === null || getCrewAssignmentResponseDataArr[i].location.coordinates[0] === undefined || getCrewAssignmentResponseDataArr[i].location.coordinates[0] === "") {
											} else {
												jsonObj.longitude = getCrewAssignmentResponseDataArr[i].location.coordinates[0]
											}
											if (getCrewAssignmentResponseDataArr[i].location.coordinates[1] === null || getCrewAssignmentResponseDataArr[i].location.coordinates[1] === undefined || getCrewAssignmentResponseDataArr[i].location.coordinates[1] === "") {
											} else {
												jsonObj.latitude = getCrewAssignmentResponseDataArr[i].location.coordinates[1];
											}
										}
									}
								}
							}

							crewIdWorkIdArr.push(jsonObj);
						}
						var ctx = session.name("omsApiv2") || session.createContext("omsApiv2");
						ctx.setVariable('crewIdWorkIdArr', crewIdWorkIdArr);
						var crewArr;

						crewArr = crewIdWorkIdArr.filter(item => item.hasOwnProperty("crewId"));

						ctx.setVariable('crewArr', crewArr);

					}
				});
			}
		}
	});
} catch (error) {
	var errorinfo = "url connection error with 'getCrewAssignmentApi', details are : " + info + "; error info :" + error
	ctx.setVar('errorDescription', errorinfo);
	ctx.setVariable("errorStatusCode", error.errorCode);
	ctx.setVariable("errorMessage", error.errorMessage);
	logger.error("omsapiv2_059: " + errorinfo);
	session.reject(errorinfo);
}
//condition removed end
