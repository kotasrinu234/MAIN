var sm = require('service-metadata');
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.getJobDetailEntryDescription;
var exitDescription = session.parameters.getJobDetailExitDescription;
var messageType = session.parameters.messageType;
var apiName = session.parameters.getJobDetailApiName;
var jobDetailCount = session.parameters.jobDetailCount;
var hm = require('header-metadata');
var headers = hm.current;
var auth = headers.get('Authorization');
var encodedCreds = auth.substring(6);
var decodedCreds = Buffer.from(encodedCreds, 'base64').toString('utf8');
var parts = decodedCreds.split(':');
var userId = parts[0];
ctx.setVariable('userId', userId);
if (apiName !== undefined || apiName !== null || apiName !== '') {
	ctx.setVariable("apiName", apiName);
}
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
	ctx.setVariable('entryDescription', entryDescription);
}
if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
	ctx.setVariable('exitDescription', exitDescription);
}
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var id = uuidv4()
ctx.setVariable("correlationID", id)
var URL = sm.getVar('var://service/URI');
var start = URL.lastIndexOf('/');
var jobId = URL.substring(start + 1);
if (jobId) {
	if (jobId !== undefined || jobId !== null || jobId !== '') {
		if (jobId.length <= jobDetailCount) {
			ctx.setVariable("jobDisplayID", jobId)
		}
		else {
			ctx.setVariable("jobID", jobId)
		}
	}
}
ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
