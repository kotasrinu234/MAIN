var logger = console.options({
'category': 'all'
});

//session.input.readAsJSON(function(readAsJSONError, incomingdata) {
var finalArr = new Array();
var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");

function getByValue2(arr, value) {
  var result  = arr.filter(function(o){return o.workTypeID == value;} );
  return result? result[0] : null; // or undefined
}

	
	var json={};
	//var ctx = session.name("omsApiv2")|| session.createContext("omsApiv2");
	var jobId = ctx.getVariable("job_id");
	var jobDisplayId = ctx.getVariable("id");
	//var contactMethod = ctx.setVariable("contactMethod", contactMethod);
	//var region = jobId.substring(0, 2);
	//logger.error("kasturi contact" + contactMethod);
	
	if(jobId !=null || jobId !='' ||jobId != undefined){ 
		json.jobId=ctx.getVariable("job_id");
	}else {
		json.jobId='';
	}
	
	if(ctx.getVariable("jobId") !=null || ctx.getVariable("jobId") !='' || ctx.getVariable("jobId") != undefined){ 
		json.jobDisplayId=ctx.getVariable("id");
	}else {
		json.jobDisplayId='';
	}
	
	
	if(ctx.getVariable("jobStatus") ==null || ctx.getVariable("jobStatus") =='' || ctx.getVariable("jobStatus") == undefined){ 
		json.jobStatus ='';
	}else {
		json.jobStatus =ctx.getVariable("jobStatus");
	}
	
	
	if(ctx.getVariable("jobType") ==null || ctx.getVariable("jobType") =='' || ctx.getVariable("jobType") == undefined){ 
		json.jobType='';
	}else {
		json.jobType=ctx.getVariable("jobType");
	}
	
	if(ctx.getVariable("outageSubType") ==null || ctx.getVariable("outageSubType") =='' || ctx.getVariable("outageSubType") == undefined){ 
		json.jobSubType='';
	}else {
		json.jobSubType=ctx.getVariable("outageSubType");
	}
	
	if(ctx.getVariable("createDate") ==null || ctx.getVariable("createDate") =='' || ctx.getVariable("createDate") == undefined){ 
		json.outageDate='';
	}else {
		json.outageDate=ctx.getVariable("createDate");
	}
	
	
	if(ctx.getVariable("deviceType") ==null || ctx.getVariable("deviceType") =='' || ctx.getVariable("deviceType") == undefined){ 
		json.deviceType='';
	}else {
		json.deviceType=ctx.getVariable("deviceType");
	}

	
	if(ctx.getVariable("publishedEtr") == null || ctx.getVariable("publishedEtr") =='' || ctx.getVariable("publishedEtr") == undefined){ 
		json.etr='';
	}else {
		json.etr=ctx.getVariable("publishedEtr");
	}
	
	if(ctx.getVariable("feederId") ==null || ctx.getVariable("feederId") =='' || ctx.getVariable("feederId") == undefined){ 
		json.circuit='';
	}else {
		json.circuit=ctx.getVariable("feederId");
	}
	
	if(ctx.getVariable("callCount") == undefined){ 
		json.numOfCalls='';
	}else {
		json.numOfCalls=ctx.getVariable("callCount");
	}
	if(ctx.getVariable("aorLookup") ==null || ctx.getVariable("aorLookup") =='' || ctx.getVariable("aorLookup") == undefined){ 
		json.aor ='';
	}else {
		json.aor =ctx.getVariable("aorLookup");
	}
	
	if(ctx.getVariable("contactMethod") == null || ctx.getVariable("contactMethod") =='' || ctx.getVariable("contactMethod") == undefined){ 
		json.callSource='';
	}else {
		json.callSource=ctx.getVariable("contactMethod");
	}
	if(ctx.getVariable("customerOut") != undefined){ 
		json.customerOut=ctx.getVariable("customerOut");
	}else {
		json.customerOut='';
	}
	
	if(ctx.getVariable("causeValues") ==null || ctx.getVariable("causeValues") =='' || ctx.getVariable("causeValues") == undefined){ 
		json.causeCode='';
	}else {
		json.causeCode=ctx.getVariable("causeValues");
	}
	
	if(ctx.getVariable("name") ==null || ctx.getVariable("name") =='' || ctx.getVariable("name") == undefined){ 
		json.name='';
	}else {
		json.name=ctx.getVariable("name");
	}
	
	if(ctx.getVariable("phoneNumber") ==null || ctx.getVariable("phoneNumber") =='' || ctx.getVariable("phoneNumber") == undefined){ 
		json.phoneNumber='';
	}else {
		json.phoneNumber=ctx.getVariable("phoneNumber");
	}
	
	
	if(ctx.getVariable("premiseId") ==null || ctx.getVariable("premiseId") =='' || ctx.getVariable("premiseId") == undefined) { 
		json.premiseId='';
	}else {
		json.premiseId=ctx.getVariable("premiseId");
	}
	
	if(ctx.getVariable("premisesWithAMIRestorationNotifCount") == undefined){ 
		json.prnFlag='';
	}else {
		json.prnFlag=ctx.getVariable("premisesWithAMIRestorationNotifCount");
	}
	
	/* if(ctx.getVariable("crewAssignmentStatus") ==null || ctx.getVariable("crewAssignmentStatus") =='' || ctx.getVariable("crewAssignmentStatus") == undefined){ 
		json.crewAssignmentStatus='';
	}else {
		json.crewAssignmentStatus=ctx.getVariable("crewAssignmentStatus");
	} */
	
	/* if(ctx.getVariable("leadCrewExternalID") !=null || ctx.getVariable("leadCrewExternalID") !='' || ctx.getVariable("leadCrewExternalID") != undefined){ 
		json.crewId=ctx.getVariable("leadCrewExternalID");
	}else if(ctx.getVariable("externalID") !=null || ctx.getVariable("externalID") !='' || ctx.getVariable("externalID") != undefined) {
		json.crewId=ctx.getVariable("externalID");
	} else {
		json.crewId='';
	} */
	json.crew = ctx.getVariable('finalArr');
	
	if(ctx.getVariable('callAddressArray') ==null || ctx.getVariable('callAddressArray') =='' || ctx.getVariable('callAddressArray') == undefined){ 
		json.callAddress = '';
	}else {
		json.callAddress = ctx.getVariable('callAddressArray');
	}
	if(ctx.getVariable('nominalFeederId') ==null || ctx.getVariable('nominalFeederId') =='' || ctx.getVariable('nominalFeederId') == undefined){ 
		json.nominalCircuit = '';
	}else {
		json.nominalCircuit = ctx.getVariable('NominalExternalId');
	}
	
	if(ctx.getVariable("address") ==null || ctx.getVariable("address") =='' || ctx.getVariable("address") == undefined){ 
		json.address='';
	}else {
		json.address=ctx.getVariable("address");
	}
	
	if((ctx.getVariable("longtitude_getJobApicall") != undefined) && (ctx.getVariable("latitude_getJobApiCall") != undefined)){ 
		json.longitude=ctx.getVariable("longtitude_getJobApicall");
		json.latitude=ctx.getVariable("latitude_getJobApiCall");
	} else if((ctx.getVariable("longtitude_premiseCall") != undefined) && (ctx.getVariable("latitude_premiseCall") != undefined)) {
		json.longitude=ctx.getVariable("longtitude_premiseCall");
		json.latitude=ctx.getVariable("latitude_premiseCall");
	} else if((ctx.getVariable("longtitude_getLeadCall") != undefined) && (ctx.getVariable("latitude_getLeadCall") != undefined)) { 
		json.longitude=ctx.getVariable("longtitude_getLeadCall");
		json.latitude=ctx.getVariable("latitude_getLeadCall");
	}else {
		json.longitude='';
		json.latitude='';
	}
	
	if(ctx.getVariable("networkLabel") == undefined){ 
		json.extent='';
	}else {
		json.extent=ctx.getVariable("networkLabel");
	}
	
	if(ctx.getVariable("externalCallCodeID") ==null || ctx.getVariable("externalCallCodeID") =='' || ctx.getVariable("externalCallCodeID") == undefined){ 
		json.callCode='';
	}else {
		json.callCode=ctx.getVariable("externalCallCodeID");
	}
	
	if(ctx.getVariable("regionName") ==null || ctx.getVariable("regionName") =='' || ctx.getVariable("regionName") == undefined){ 
		json.region='';
	}else {
		json.region=ctx.getVariable("regionName");
	}
	
	if(ctx.getVariable("meterID") ==null || ctx.getVariable("meterID") =='' || ctx.getVariable("meterID") == undefined){ 
		json.meterId='';
	}else {
		json.meterId=ctx.getVariable("meterID");
	}
	
	if(ctx.getVariable("energizationStatus") ==null || ctx.getVariable("energizationStatus") =='' || ctx.getVariable("energizationStatus") == undefined){ 
		json.energizationStatus='';
	}else {
		json.energizationStatus=ctx.getVariable("energizationStatus");
	}
	//ADO184553 starts
	if(ctx.getVariable("deviceOperatingVoltage") ==null || ctx.getVariable("deviceOperatingVoltage") =='' || ctx.getVariable("deviceOperatingVoltage") == undefined){ 
		json.deviceOperatingVoltage=0;
	}else {
		json.deviceOperatingVoltage=ctx.getVariable("deviceOperatingVoltage");
	}
	//ADO184553 ends
	if(ctx.getVariable("activeCrewAssignmentCount") === 0){
		json.activeCrewAssignmentCount=ctx.getVariable("activeCrewAssignmentCount");
	}
	else if(ctx.getVariable("activeCrewAssignmentCount") ==null || ctx.getVariable("activeCrewAssignmentCount") =='' || ctx.getVariable("activeCrewAssignmentCount") == undefined){ 
		json.activeCrewAssignmentCount='';
	}else {
		json.activeCrewAssignmentCount=ctx.getVariable("activeCrewAssignmentCount");
	}
	
	//ADO171595 starts
	
	if(ctx.getVariable("feederName") ==null || ctx.getVariable("feederName") =='' || ctx.getVariable("feederName") == undefined){ 
		json.feederName='';
	}else {
		json.feederName=ctx.getVariable("feederName");
	}
	
	if(ctx.getVariable("OUTAGE_SUBTYPE") ==null || ctx.getVariable("OUTAGE_SUBTYPE") =='' || ctx.getVariable("OUTAGE_SUBTYPE") == undefined){ 
		json.outageSubTypeCustom='';
	}else {
		json.outageSubTypeCustom=ctx.getVariable("OUTAGE_SUBTYPE");
	}
	
	//ADO171595 ends
	
	//ADO199295 starts
	
	if(ctx.getVariable("leadCallAddress") ==null || ctx.getVariable("leadCallAddress") =='' || ctx.getVariable("leadCallAddress") == undefined){ 
		json.leadCallAddress='';
	}else {
		json.leadCallAddress=ctx.getVariable("leadCallAddress");
	}
	
	//ADO199295 ends
	
	//json.region=region;
	json.xCord='';
	json.yCord='';
	json.comments={};
	
	if(ctx.getVariable("commentsArr") !=null || ctx.getVariable("commentsArr") !='' || ctx.getVariable("commentsArr") != undefined){ 
		json.comments.comments= ctx.getVariable("commentsArr");
	}else {
		json.comments.comments= '';
	}
ctx.setVariable('FinalResponse',json);
session.output.write(json);
//});
