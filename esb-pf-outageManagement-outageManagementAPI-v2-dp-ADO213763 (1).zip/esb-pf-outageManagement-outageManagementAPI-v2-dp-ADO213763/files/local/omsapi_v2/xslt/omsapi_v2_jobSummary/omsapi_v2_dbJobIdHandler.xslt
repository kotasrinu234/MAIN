<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions"
    xmlns:dpconfig="http://www.datapower.com/param/config"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig ">
    <xsl:output method="xml" />
    <xsl:template match="/">
<xsl:variable name = "omsJobIdsCount" select="dp:variable('var://context/JobSummary/dbJobIdsCount')"/>
		<xsl:if test="$omsJobIdsCount &gt; 0">
		<xsl:variable name = "query" select="dp:variable('var://context/JobSummary/dbQuery')"/>
		<xsl:variable name="dbresults">		
			<dp:sql-execute source="'omsapi_db'" statement="$query" />
		</xsl:variable>
							
<dp:set-variable name="'var://context/JobSummary/rowCount'" value="count($dbresults/sql/row)" />
		<xsl:choose>
			<xsl:when test="count($dbresults/sql/row)!=0">
				<xsl:for-each select="$dbresults/sql/row">
						<xsl:variable name = "jobId" select="column[name='NUM_1']/value"/>
						<xsl:variable name = "jobType" select="column[name='TYCOD']/value"/>
						<xsl:variable name = "statusCode" select="column[name='STATUS_CODE']/value"/>
						<xsl:variable name = "region" select="column[name='AG_ID']/value"/>
						<xsl:variable name = "aor" select="column[name='DGROUP']/value"/>
						<xsl:variable name = "circuit" select="column[name='FEEDER']/value"/>
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId)" value="string($jobId)" />
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_jobType')" value="string($jobType)" />
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_statusCode')" value="string($statusCode)" />
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_region')" value="string($region)" />
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_aor')" value="string($aor)" />
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_circuit')" value="string($circuit)" />
				</xsl:for-each>
			</xsl:when>		
			<xsl:when test="$dbresults/sql/@result ='error'">
			<dp:set-variable name="'var://context/JobFilter/customErrorCode'" value="'500'" />
    		<dp:set-variable name="'var://context/JobFilter/customReasonMessage'" value="concat(' ',$dbresults/sql/message)" />
			<dp:set-variable name="'var://context/JobFilter/customErrorMessage'" value="concat(' ',$dbresults/sql/message)" />
			<dp:reject><xsl:value-of select="concat(' ',$dbresults/sql/message)" /></dp:reject>
			</xsl:when>
			<xsl:when test="count($dbresults/sql/row)=0">
			<dp:set-variable name="'var://context/JobFilter/customErrorCode'" value="'404'" />
    		<dp:set-variable name="'var://context/JobFilter/customReasonMessage'" value="' Records Not Found'" />
			<dp:set-variable name="'var://context/JobFilter/customErrorMessage'" value="' Records Not Found'" />
			<!-- <dp:reject>Records Not Found</dp:reject> -->
			</xsl:when>
		</xsl:choose>
		
		<!-- StormId Query code starts -->
		<xsl:variable name = "StormJobIds" select="dp:variable('var://context/JobSummary/dbJobIds')"/>
		
		<xsl:for-each select="StormIdquery">
		 <xsl:message dp:type="all" dp:priority="info">
		 <xsl:value-of select="$StormIdquery"/>
		 </xsl:message>
		</xsl:for-each>
		<xsl:variable name = "StormIdquery" select="dp:variable('var://context/JobSummary/StormIdquery')"/>
		<xsl:variable name="StormIdquerydbresults">		
			<dp:sql-execute source="'omsapi_db'" statement="$StormIdquery" />
		</xsl:variable>
							
<dp:set-variable name="'var://context/JobSummary/StormIdqueryrowCount'" value="count($StormIdquerydbresults/sql/row)" />
		<xsl:choose>
			<xsl:when test="count($StormIdquerydbresults/sql/row)!=0">
				<xsl:for-each select="$StormIdquerydbresults/sql/row">
						<xsl:variable name = "STORM_JOB" select="column[name='STORM_JOB']/value"/>
						<xsl:variable name = "jobId" select="column[name='NUM_1']/value"/>
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_STORM_JOB')" value="string($STORM_JOB)" />
				</xsl:for-each>
			</xsl:when>
			
			<xsl:when test="$StormIdquerydbresults/sql/@result ='error'">
			<dp:set-variable name="'var://context/JobFilter/customErrorCode'" value="'500'" />
    		<dp:set-variable name="'var://context/JobFilter/customReasonMessage'" value="concat(' ',$StormIdquerydbresults/sql/message)" />
			<dp:set-variable name="'var://context/JobFilter/customErrorMessage'" value="concat(' ',$StormIdquerydbresults/sql/message)" />
			<dp:reject><xsl:value-of select="concat(' ',$StormIdquerydbresults/sql/message)" /></dp:reject>
			</xsl:when>
			<xsl:when test="count($StormIdquerydbresults/sql/row)=0">
<!-- 				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_STORM_JOB')" value="''" /> -->
<!-- 			<dp:reject>Records Not Found</dp:reject>  -->
			</xsl:when>
		</xsl:choose>
		
		<!-- StormId Query code ends -->
		
		
</xsl:if>


</xsl:template>
</xsl:stylesheet>
