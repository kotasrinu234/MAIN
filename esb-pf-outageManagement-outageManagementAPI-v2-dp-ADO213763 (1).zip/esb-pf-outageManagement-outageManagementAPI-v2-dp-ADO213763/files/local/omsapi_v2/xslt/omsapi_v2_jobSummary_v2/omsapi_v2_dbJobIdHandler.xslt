<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions"
    xmlns:dpconfig="http://www.datapower.com/param/config"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig ">
    <xsl:output method="xml" />
    <xsl:template match="/">
<xsl:variable name = "omsJobIdsCount" select="dp:variable('var://context/JobSummary/dbJobIdsCount')"/>
		<xsl:if test="$omsJobIdsCount &gt; 0">
		<xsl:variable name = "query" select="dp:variable('var://context/JobSummary/dbQuery')"/>
		<xsl:variable name="dbresults">		
			<dp:sql-execute source="'omsapi_db'" statement="$query" />
		</xsl:variable>
							
<dp:set-variable name="'var://context/JobSummary/rowCount'" value="count($dbresults/sql/row)" />
		<xsl:choose>
			<xsl:when test="count($dbresults/sql/row)!=0">
				<xsl:for-each select="$dbresults/sql/row">
						<xsl:variable name = "jobId" select="column[name='NUM_1']/value"/>
						<xsl:variable name = "jobType" select="column[name='TYCOD']/value"/>
						<xsl:variable name = "statusCode" select="column[name='STATUS_CODE']/value"/>
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId)" value="string($jobId)" />
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_jobType')" value="string($jobType)" />
				<dp:set-variable name="concat('var://context/JobSummary/',$jobId,'_statusCode')" value="string($statusCode)" />
				</xsl:for-each>
			</xsl:when>
			
			<xsl:when test="$dbresults/sql/@result ='error'">
			<dp:set-variable name="'var://context/JobFilter/customErrorCode'" value="'500'" />
    		<dp:set-variable name="'var://context/JobFilter/customReasonMessage'" value="concat(' ',$dbresults/sql/message)" />
			<dp:set-variable name="'var://context/JobFilter/customErrorMessage'" value="concat(' ',$dbresults/sql/message)" />
			<dp:reject><xsl:value-of select="concat(' ',$dbresults/sql/message)" /></dp:reject>
			</xsl:when>
			<xsl:when test="count($dbresults/sql/row)=0">
			<dp:set-variable name="'var://context/JobFilter/customErrorCode'" value="'404'" />
    		<dp:set-variable name="'var://context/JobFilter/customReasonMessage'" value="' Records Not Found'" />
			<dp:set-variable name="'var://context/JobFilter/customErrorMessage'" value="' Records Not Found'" />
			<!-- <dp:reject>Records Not Found</dp:reject> -->
			</xsl:when>
		</xsl:choose>
</xsl:if>
</xsl:template>
</xsl:stylesheet>