<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:dp="http://www.datapower.com/extensions" 
xmlns:dpconfig="http://www.datapower.com/param/config"
extension-element-prefixes="dp dpconfig"
exclude-result-prefixes="dp dpconfig">
	
	<!--<xsl:param name="dpconfig:outageAppUser" select="''"/>-->
	<xsl:param name="dpconfig:outageAppBindDN" select="''"/>
	<xsl:param name="dpconfig:outageAppTargetBaseDN" select="''"/>

	<!--<xsl:param name="dpconfig:chatBotUser" select="''"/>-->
	<xsl:param name="dpconfig:chatBotBindDN" select="''"/>
	<xsl:param name="dpconfig:chatBotTargetBaseDN" select="''"/>
	
	<!--<xsl:param name="dpconfig:reportingAppUser" select="''"/>-->
	<xsl:param name="dpconfig:reportingAppBindDN" select="''"/>
	<xsl:param name="dpconfig:reportingAppTargetBaseDN" select="''"/>
	
	<!--<xsl:param name="dpconfig:maximoAppUser" select="''"/>-->
	<xsl:param name="dpconfig:maximoAppBindDN" select="''"/>
	<xsl:param name="dpconfig:maximoAppTargetBaseDN" select="''"/>
	
	<xsl:param name="dpconfig:abnormalAppBindDN" select="''"/>
	<xsl:param name="dpconfig:abnormalAppTargetBaseDN" select="''"/>
	
	<xsl:param name="dpconfig:amiAppBindDN" select="''"/>
	<xsl:param name="dpconfig:amiAppTargetBaseDN" select="''"/>
	
	<xsl:param name="dpconfig:ppsAppBindDN" select="''"/>
	<xsl:param name="dpconfig:ppsAppTargetBaseDN" select="''"/>
	
	<xsl:param name="dpconfig:crmAppBindDN" select="''"/>
	<xsl:param name="dpconfig:crmAppTargetBaseDN" select="''"/>

    <xsl:param name="dpconfig:phaAppBindDN" select="''"/>
	<xsl:param name="dpconfig:phaAppTargetBaseDN" select="''"/>
	
	<xsl:param name="dpconfig:urmaAppBindDN" select="''"/>
	<xsl:param name="dpconfig:urmaAppTargetBaseDN" select="''"/>

	<!-- Get the value-of stylesheet parameter -->
	<!--<xsl:variable name="outageAppUser" select="$dpconfig:outageAppUser"/>-->
	<xsl:variable name="outageAppBindDN" select="$dpconfig:outageAppBindDN"/>
	<xsl:variable name="outageAppTargetBaseDN" select="$dpconfig:outageAppTargetBaseDN"/> 
	
	<!--<xsl:variable name="chatBotUser" select="$dpconfig:chatBotUser"/>-->
	<xsl:variable name="chatBotBindDN" select="$dpconfig:chatBotBindDN"/>
	<xsl:variable name="chatBotTargetBaseDN" select="$dpconfig:chatBotTargetBaseDN"/> 
	
	<!--<xsl:variable name="reportingAppUser" select="$dpconfig:reportingAppUser"/>-->
	<xsl:variable name="reportingAppBindDN" select="$dpconfig:reportingAppBindDN"/>
	<xsl:variable name="reportingAppTargetBaseDN" select="$dpconfig:reportingAppTargetBaseDN"/> 
	
	<!--<xsl:variable name="maximoAppUser" select="$dpconfig:maximoAppUser"/>-->
	<xsl:variable name="maximoAppBindDN" select="$dpconfig:maximoAppBindDN"/>
	<xsl:variable name="maximoAppTargetBaseDN" select="$dpconfig:maximoAppTargetBaseDN"/> 
	
	<xsl:variable name="abnormalAppBindDN" select="$dpconfig:abnormalAppBindDN"/>
	<xsl:variable name="abnormalAppTargetBaseDN" select="$dpconfig:abnormalAppTargetBaseDN"/> 
	
	<xsl:variable name="amiAppBindDN" select="$dpconfig:amiAppBindDN"/>
	<xsl:variable name="amiAppTargetBaseDN" select="$dpconfig:amiAppTargetBaseDN"/>
	
	<xsl:variable name="ppsAppBindDN" select="$dpconfig:ppsAppBindDN"/>
	<xsl:variable name="ppsAppTargetBaseDN" select="$dpconfig:ppsAppTargetBaseDN"/>
	
	<xsl:variable name="crmAppBindDN" select="$dpconfig:crmAppBindDN"/>
	<xsl:variable name="crmAppTargetBaseDN" select="$dpconfig:crmAppTargetBaseDN"/> 

    <xsl:variable name="phaAppBindDN" select="$dpconfig:phaAppBindDN"/>
	<xsl:variable name="phaAppTargetBaseDN" select="$dpconfig:phaAppTargetBaseDN"/>
	
	<xsl:variable name="urmaAppBindDN" select="$dpconfig:urmaAppBindDN"/>
	<xsl:variable name="urmaAppTargetBaseDN" select="$dpconfig:urmaAppTargetBaseDN"/>

	<xsl:template match="/">
		<xsl:variable name="encodedCredential" select="dp:http-request-header('Authorization')"/>
		<xsl:variable name="uname" select="substring-before(dp:decode(substring($encodedCredential,'7'),'base-64'),':')"/>
		<xsl:variable name="bindPWD" select="substring-after(dp:decode(substring($encodedCredential,'7'),'base-64'),':')"/>
		
		<dp:set-variable name="'var://context/current/user'" value="$uname" />
		<xsl:choose>
			<xsl:when test="($uname='dcas-opa-esb-oms-dev') or ($uname='dcas-opa-esb-oms-tst') or ($uname='dcas-opa-esb-oms-prd')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$outageAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$outageAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='dcas-cbo-esb-oms-dev') or ($uname='dcas-cbo-esb-oms-tst') or ($uname='dcas-cbo-esb-oms-prd')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$chatBotBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$chatBotTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='dcas-rpa-esb-oms-dev') or ($uname='dcas-rpa-esb-oms-tst') or ($uname='dcas-rpa-esb-oms-prd')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$reportingAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$reportingAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='dcas-eam-sr-esb-dev') or ($uname='dcas-eam-sr-esb-test') or ($uname='dcas-eam-sr-esb-prod')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$maximoAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$maximoAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='dcas-abnv-esb-dev') or ($uname='dcas-abnv-esb-tst') or ($uname='dcas-abnv-esb-prd')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$abnormalAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$abnormalAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='esb-pnfcep-onp-dev') or ($uname='esb-pnfcep-onp-test') or ($uname='esb-pnfcep-onp-prod')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$amiAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$amiAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='dcas-wismo-esb-dev') or ($uname='dcas-wismo-esb-test') or ($uname='dcas-wismo-esb-prod')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$ppsAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$ppsAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='dcas-crb-esb-oms-dev') or ($uname='dcas-crb-esb-oms-tst') or ($uname='dcas-crb-esb-oms-prd')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$crmAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$crmAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='pha-esb-dev') or ($uname='pha-esb-test') or ($uname='pha-esb-prod')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$phaAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$phaAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='urma-esb-dev') or ($uname='urma-esb-test') or ($uname='urma-esb-prod')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$urmaAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$urmaAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/current/validUser'" value="'false'" />
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/current/validUser')='true'">
				<xsl:variable name="serverAddress" select="'corpad.dtenet.com'"/>
				<xsl:variable name="portNumber" select="'636'"/>
				<xsl:variable name="bindDN" select="dp:variable('var://context/current/bindDN')"/>
				<xsl:variable name="bindPassword" select="$bindPWD"/>
				<xsl:variable name="targetBaseDN" select="dp:variable('var://context/current/targetBaseDN')"/>
				<xsl:variable name="attributeName" select="'sAMAccountName,member'"/>
				<xsl:variable name="filter" select="'(|(objectClass=group))'"/>
				<xsl:variable name="sslProxyProfile" select="'client:omsapi_AD_AAA_Client_Profile'"/>
				<xsl:variable name="ldapLBGroup" select="''"/>

				<xsl:variable name="ldapResults" select="dp:ldap-search($serverAddress, $portNumber, $bindDN, $bindPassword, $targetBaseDN, $attributeName, $filter, 'sub', $sslProxyProfile, $ldapLBGroup)"/>
				<dp:set-variable name="'var://context/current/ldapResults'" value="$ldapResults" />
				<!-- <xsl:copy-of select="$ldapResults" /> -->
				<xsl:choose>
					<xsl:when test="$ldapResults/LDAP-search-results/result" >
						<accepted />
					</xsl:when>
					<xsl:otherwise >
						<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Methods'"/>
						<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Headers'"/>
						<dp:set-variable name="'var://context/aaa/customErrorCode'" value="'401'"/>
						<dp:set-variable name="'var://context/aaa/customErrorMessage'" value="'Unauthorized'"/>
						<dp:set-variable name="'var://context/aaa/customReasonMessage'" value="'Unauthorized'"/>
						<dp:reject>'omsapiv2_185 : Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : <xsl:value-of select="$uname"/> </dp:reject>
				<dp:set-variable name="'var://context/omsApiv2/errorDescription'" value="concat('Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : ', $uname)"/>
						<dp:set-variable name="'var://context/omsApiv2/errorStatusCode'" value="'401'"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Methods'"/>
				<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Headers'"/>
				<dp:set-variable name="'var://context/aaa/customErrorCode'" value="'401'"/>
				<dp:set-variable name="'var://context/aaa/customErrorMessage'" value="'Unauthorized'"/>
				<dp:set-variable name="'var://context/aaa/customReasonMessage'" value="'Unauthorized'"/>
				<dp:reject>'omsapiv2_186 : Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : <xsl:value-of select="$uname"/> </dp:reject>
				<dp:set-variable name="'var://context/omsApiv2/errorDescription'" value="concat('Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : ', $uname)"/>
				<dp:set-variable name="'var://context/omsApiv2/errorStatusCode'" value="'401'"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

</xsl:stylesheet>
