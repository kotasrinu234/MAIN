<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">
			<!-- <xsl:variable name="TransactionID">
				<xsl:copy-of select="dp:variable('var://service/global-transaction-id')" />
			</xsl:variable> -->
			
			<xsl:variable name="aaaCustomErrorCode" select="dp:variable('var://context/aaa/customErrorCode')"/>
	<xsl:variable name="aaaCustomErrorMessage" select="dp:variable('var://context/aaa/customErrorMessage')"/>
			<xsl:variable name="errorMessage" select="dp:variable('var://service/error-message')"/>
			<xsl:variable name="aaaCustomReasonMessage" select="dp:variable('var://context/aaa/customReasonMessage')" />
			<xsl:choose>
					<xsl:when test="string($aaaCustomErrorCode) !=''">
						<xsl:variable name="code" select="$aaaCustomErrorCode" /> 
						<dp:set-http-response-header name="'x-dp-response-code'" value="'-1'" />
						<dp:set-variable name="'var://service/error-protocol-response'" value="$code"/>
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$aaaCustomReasonMessage"/>
						<dp:append-response-header name="'x-dp-response-code'" value="'$aaaCustomReasonMessage'" />
						//<xsl:message>inside 1st when ++++</xsl:message>
			       </xsl:when>
				<!-- 	<xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy ') and contains(dp:variable('var://service/error-code'),'0x00d30003')">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'401'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'" />
						<xsl:message>inside 1st when ++++</xsl:message>
					</xsl:when> -->
					<xsl:when test="contains(dp:variable('var://service/error-code'),'0x00d30003')">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$errorMessage" />
					</xsl:when>
					<xsl:when test="contains(dp:variable('var://service/error-code'),'0x0213000e' ) or contains(dp:variable('var://service/error-code'),'0x00d30003' )"> 
						<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$errorMessage"/>
					</xsl:when>
					<xsl:when test="contains(dp:variable('var://service/error-code'),'0x00230001' )">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Request'" />
					</xsl:when>
					<xsl:when test="contains(dp:variable('var://context/pdss/schemacheck'),'schema failed' )">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Request'" />
					</xsl:when>
					<xsl:when test="contains(dp:variable('var://context/pdss/mqconnection'),'Forbidden')"> 
						<dp:set-variable name="'var://service/error-protocol-response'" value="'502'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Gateway'" />
					</xsl:when>
					<xsl:otherwise>
						<dp:set-variable name="'var://service/error-protocol-response'" value="'500'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Interval Server Error (General Error)'" />
					</xsl:otherwise>
			</xsl:choose>	
				<dp:set-variable name="'var://context/ILS/errStatusDetail'" value="concat('ErrorCode =', dp:variable('var://service/error-protocol-response'),',', 'Error Message = ', dp:variable('var://service/error-protocol-reason-phrase') , ',', 'Error Info = ', dp:variable('var://context/ILS/errorDescription'))" />
	</xsl:template>
</xsl:stylesheet>
