<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:date="http://exslt.org/dates-and-times" xmlns:dp="http://www.datapower.com/extensions" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" version="1.0" extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
   <xsl:output method="xml" omit-xml-declaration="yes" indent="yes" />
   <xsl:variable name="commonStatus" select="document('local:///omsapi/xml/omsapi_CommonStatus.xml')" />
   <xsl:template match="/">
      <xsl:variable name="uri" select="dp:variable('var://service/URI')" />
      <xsl:variable name="premiseId" select="dp:variable('var://context/jobHistory/premiseId')" />
      <xsl:variable name="startDate" select="dp:variable('var://context/jobHistory/startDate')" /> 
      <xsl:variable name="endDate" select="dp:variable('var://context/jobHistory/endDate')" /> 
      <xsl:variable name="identTime" select="substring-after(dp:variable('var://service/system/ident')/identification/current-time,' ')" />
      <xsl:variable name="currentDate" select="dp:variable('var://service/system/ident')/identification/current-date" />
      <xsl:variable name="currentTime" select="dp:variable('var://service/system/ident')/identification/current-time" />
      <dp:set-variable name="'var://context/jobHistory/identTime'" value="string($identTime)" />
      <xsl:choose>
         <xsl:when test="string-length(normalize-space($startDate)) &gt; 0">
            <!--<xsl:variable name="startDateQuery" select="$startDate" />-->
			<xsl:variable name="startDateQuery" select="concat($startDate,' ','00:00:00')" />
            <xsl:message dp:type="all" dp:priority="debug">
               <xsl:value-of select="$startDateQuery" />
            </xsl:message>
            <dp:set-variable name="'var://context/jobHistory/startDateQuery'" value="$startDateQuery" />
         </xsl:when>
         <xsl:otherwise>
            <xsl:variable name="systemDateTime" select="concat($currentDate,' ','00:00:00')" />
            <xsl:variable name="yearDec" select="1" />
            <xsl:variable name="d0" select="substring-before($systemDateTime, '-')" />
            <xsl:variable name="d1" select="substring-before(substring-after($systemDateTime, '-'), '-')" />
            <xsl:variable name="d2" select="substring-after(substring-after($systemDateTime, '-'), '-')" />
            <xsl:variable name="newYear" select="substring($d0, 1, 4) - $yearDec" />
            <xsl:variable name="startDateQuery" select="concat($newYear, '-', $d1, '-', $d2)" />
            <xsl:message dp:type="all" dp:priority="debug">
               <xsl:value-of select="$startDateQuery" />
            </xsl:message>
            <dp:set-variable name="'var://context/jobHistory/startDateQuery'" value="$startDateQuery" />
         </xsl:otherwise>
      </xsl:choose>
      <xsl:choose>
         <xsl:when test="string-length(normalize-space($endDate)) &gt; 0">
            <xsl:variable name="endDateQuery" select="concat($endDate,' ','23:59:59')" />
            <xsl:message dp:type="all" dp:priority="debug">
               <xsl:value-of select="$endDateQuery" />
            </xsl:message>
            <dp:set-variable name="'var://context/jobHistory/endDateQuery'" value="$endDateQuery" />
         </xsl:when>
         <xsl:otherwise>
            <xsl:variable name="endDateQuery" select="concat($currentDate,' ','23:59:59')" />
            <xsl:message dp:type="all" dp:priority="debug">
               <xsl:value-of select="$endDateQuery" />
            </xsl:message>
            <dp:set-variable name="'var://context/jobHistory/endDateQuery'" value="$endDateQuery" />
         </xsl:otherwise>
      </xsl:choose>      
   </xsl:template>
</xsl:stylesheet>
