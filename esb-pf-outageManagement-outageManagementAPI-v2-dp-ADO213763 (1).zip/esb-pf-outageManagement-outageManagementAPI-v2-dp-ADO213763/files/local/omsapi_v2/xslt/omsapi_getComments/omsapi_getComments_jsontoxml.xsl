<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp dpconfig" exclude-result-prefixes="dp dpconfig">
	<xsl:template match="/">
		<xsl:variable name="contextPayload" select="dp:variable('var://context/omsapi_ReceiveComments/commentresponse')"/>
		<!-- <xsl:variable name="payloadStr" select="dp:binaryNodeToString($contextPayload)"/> -->
		<xsl:copy-of select="dp:stringToJSONx($contextPayload)"/>
	</xsl:template>
</xsl:stylesheet>