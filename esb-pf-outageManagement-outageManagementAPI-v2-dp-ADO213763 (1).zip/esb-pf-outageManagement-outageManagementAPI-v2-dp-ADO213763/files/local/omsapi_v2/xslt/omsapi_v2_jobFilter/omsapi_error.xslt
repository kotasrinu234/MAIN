<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" version="1.0" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
	<xsl:variable name="jobUpdateErrorCode" select="dp:variable('var://context/jobUpdate/customErrorCode')"/>
	<xsl:variable name="jobUpdateErrorMessage" select="dp:variable('var://context/jobUpdate/customErrorMessage')"/>
	<xsl:variable name="jobUpdateReasonMessage" select="dp:variable('var://context/jobUpdate/customReasonMessage')"/>
	<xsl:variable name="validStatusErrorCode" select="dp:variable('var://context/validStatus/customErrorCode')"/>
	<xsl:variable name="validStatusErrorMessage" select="dp:variable('var://context/validStatus/customErrorMessage')"/>
	<xsl:variable name="validStatusReasonMessage" select="dp:variable('var://context/validStatus/customReasonMessage')"/>
	<xsl:variable name="jobFilterErrorCode" select="dp:variable('var://context/jobFilter/customErrorCode')"/>
	<xsl:variable name="jobFilterErrorMessage" select="dp:variable('var://context/jobFilter/customErrorMessage')"/>
	<xsl:variable name="jobFilterReasonMessage" select="dp:variable('var://context/jobFilter/customReasonMessage')"/>
	<xsl:variable name="jobSummaryErrorCode" select="dp:variable('var://context/JobSummary/customErrorCode')"/>
	<xsl:variable name="jobSummaryErrorMessage" select="dp:variable('var://context/JobSummary/customErrorMessage')"/>
	<xsl:variable name="jobSummaryReasonMessage" select="dp:variable('var://context/JobSummary/customReasonMessage')"/>
	<xsl:variable name="aaaCustomErrorCode" select="dp:variable('var://context/aaa/customErrorCode')"/>
	<xsl:variable name="aaaCustomErrorMessage" select="dp:variable('var://context/aaa/customErrorMessage')"/>
	<xsl:variable name="aaaCustomReasonMessage" select="dp:variable('var://context/aaa/customReasonMessage')"/>
	<xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
	<xsl:variable name="systemErrorMessage" select="dp:variable('var://service/error-message')"/>
	<xsl:variable name="errorDescription" select="dp:variable('var://context/omsApiv2/errorDescription')"/>
	<xsl:template match="/">
		<xsl:variable name="msgId" select="*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'msgId']]"/>
		<xsl:variable name="customErrorCode">
			<xsl:if test="$jobUpdateErrorCode">
				<xsl:value-of select="$jobUpdateErrorCode"/>
			</xsl:if>
			<xsl:if test="$validStatusErrorCode">
				<xsl:value-of select="$validStatusErrorCode"/>
			</xsl:if>
			<xsl:if test="$jobFilterErrorCode">
				<xsl:value-of select="$jobFilterErrorCode"/>
			</xsl:if>
			<xsl:if test="$jobSummaryErrorCode">
				<xsl:value-of select="$jobSummaryErrorCode"/>
			</xsl:if>
		</xsl:variable>
		<xsl:variable name="customErrorMessage">
			<xsl:if test="$jobUpdateErrorMessage">
				<xsl:value-of select="$jobUpdateErrorMessage"/>
			</xsl:if>
			<xsl:if test="$validStatusErrorMessage">
				<xsl:value-of select="$validStatusErrorMessage"/>
			</xsl:if>
			<xsl:if test="$jobFilterErrorMessage">
				<xsl:value-of select="$jobFilterErrorMessage"/>
			</xsl:if>
			<xsl:if test="$jobSummaryErrorMessage">
				<xsl:value-of select="$jobSummaryErrorMessage"/>
			</xsl:if>
		</xsl:variable>
		<xsl:variable name="customReasonMessage">
			<xsl:if test="$jobUpdateReasonMessage">
				<xsl:value-of select="$jobUpdateReasonMessage"/>
			</xsl:if>
			<xsl:if test="$validStatusReasonMessage">
				<xsl:value-of select="$validStatusReasonMessage"/>
			</xsl:if>
			<xsl:if test="$jobFilterReasonMessage">
				<xsl:value-of select="$jobFilterReasonMessage"/>
			</xsl:if>
			<xsl:if test="$jobSummaryReasonMessage">
				<xsl:value-of select="$jobSummaryReasonMessage"/>
			</xsl:if>
		</xsl:variable>
		<json:object xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">
			<xsl:choose>
				<xsl:when test="string($customErrorCode) !=''">
					<xsl:variable name="code" select="$customErrorCode"/>
					<xsl:variable name="text" select="concat(' ', $customReasonMessage)"/>
					<dp:set-variable name="'var://service/error-protocol-response'" value="$code"/>
					<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$customReasonMessage"/>
					<xsl:if test="$msgId">
						<json:string name="msgId">
							<xsl:value-of select="$msgId"/>
						</json:string>
					</xsl:if>
					<json:string name="errorCode">
						<xsl:value-of select="$customErrorCode"/>
					</json:string>
					<json:string name="errorDescription">
						<xsl:value-of select="$customErrorMessage"/>
					</json:string>
					<xsl:message dp:type="all" dp:priority="error">id=omsapi_v2_151|errorString:<xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage)"/>
					</xsl:message>
					<dp:set-variable name="'var://context/ILS/errStatusDetail'" value="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage , ',', 'Error Info = ', $errorDescription)"/>
				</xsl:when>
				<xsl:when test="string($aaaCustomErrorCode) !=''">
					<xsl:variable name="code" select="$aaaCustomErrorCode"/>
					<xsl:variable name="text" select="concat(' ', $aaaCustomReasonMessage)"/>
					<dp:set-variable name="'var://service/error-protocol-response'" value="$code"/>
					<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$aaaCustomReasonMessage"/>
					<xsl:if test="$msgId">
						<json:string name="msgId">
							<xsl:value-of select="$msgId"/>
						</json:string>
					</xsl:if>
					<json:string name="errorCode">
						<xsl:value-of select="$aaaCustomErrorCode"/>
					</json:string>
					<json:string name="errorDescription">
						<xsl:value-of select="$aaaCustomErrorMessage"/>
					</json:string>
					<xsl:message dp:type="all" dp:priority="error">id=omsapi_v2_152|errorString:<xsl:value-of select="concat('ErrorCode =', $aaaCustomErrorCode,',', 'Error Message = ', $aaaCustomErrorMessage)"/>
						<dp:set-variable name="'var://context/ILS/errStatusDetail'" value="concat('ErrorCode =', $aaaCustomErrorCode,',', 'Error Message = ', $aaaCustomErrorMessage , ',', 'Error Info = ', $systemErrorMessage)"/>
					</xsl:message>
				</xsl:when>
				<xsl:when test="string($customErrorCode) =''">
					<xsl:if test="$msgId">
						<json:string name="msgId">
							<xsl:value-of select="$msgId"/>
						</json:string>
					</xsl:if>
					<json:string name="errorCode">
						<xsl:value-of select="$systemErrorCode"/>
					</json:string>
					<json:string name="errorDescription">
						<xsl:value-of select="$systemErrorMessage"/>
					</json:string>
					<xsl:message dp:type="all" dp:priority="error">id=omsapi_v2_153|errorString:<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $systemErrorMessage)"/>
						<dp:set-variable name="'var://context/ILS/errStatusDetail'" value="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $systemErrorMessage , ',', 'Error Info = ', $errorDescription)"/>
					</xsl:message>
				</xsl:when>
			</xsl:choose>
		</json:object>
		<xsl:variable name="ilsErrorCode">
			<xsl:choose>
				<xsl:when test="string($customErrorCode) !=''">
					<xsl:value-of select="$customErrorCode"/>
				</xsl:when>
				<xsl:when test="string($aaaCustomErrorCode) !=''">
					<xsl:value-of select="$aaaCustomErrorCode"/>
				</xsl:when>
				<xsl:when test="string($customErrorCode) =''">
					<xsl:value-of select="$systemErrorCode"/>
				</xsl:when>
			</xsl:choose>
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/ilsErrorCode'" value="$ilsErrorCode"/>
		<dp:set-http-request-header name="'Content-Type'" value="'application/json'"/>
	</xsl:template>
</xsl:stylesheet>
