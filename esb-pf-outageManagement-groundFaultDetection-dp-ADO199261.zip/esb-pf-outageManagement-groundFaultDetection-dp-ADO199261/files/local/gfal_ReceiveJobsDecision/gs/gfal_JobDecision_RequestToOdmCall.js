var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("ExternalRefID")|| session.createContext("ExternalRefID");
	var jsonInput = incomingdata;
	//console.log("incomingdata----"+incomingdata);
	ctx.setVariable("inputjson", incomingdata);
	var jobSubType = incomingdata.groundFaultParameters.jobSubType[0];
	ctx.setVariable("jobSubType", jobSubType);
});