var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	var ctx = session.name("ExternalRefID") || session.createContext("ExternalRefID");
	var ilsctx = session.name("ILS") || session.createContext("ILS");
	var JobID = ctx.getVar("JobID");
	var Circuit = ctx.getVar("Circuit");
	//JobSubType from odm repsonse
	var jobSubType = ctx.getVar("jobSubType");
	var RestorationStatusPayload = ctx.getVar("RestorationStatusPayload");
	//JobId from OMS base64 payload
	var job_Id = ctx.getVar("JobIdfromDecode");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	var ExitDescription = session.parameters.ExitDescription;
	//logger.error("JobIdfromDecode--------"+job_Id);

ilsctx.setVariable("exitDestination", omsExternalURL);

	//logger.error("oms+++++"+omsExternalURL);
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data";
		logger.error("Error in reading incoming data");
		ilsctx.setVariable("exitStatus", "500");
		ilsctx.setVariable("ExitDescription", errorinfo);
		session.reject(errorinfo);
	} else {
		//calling lookup service with label
		var url = lookupURL;
		//invoking lookup service and storing response in a var
		//logger.error("url++++"+url);
		var lookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "outageSubtypes",
						"label": jobSubType
					}
				]
			}
		}

		logger.debug("lookupMessage----" + lookupMessage);
		var LookupServiceResponse = {
			target: url,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
		urlopen.open(LookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "gfal_023 : url connection error 'LookupServiceResponse', details are : " + info + "; error info :" + error
				logger.error("gfal_023:urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
				ilsctx.setVariable("exitStatus", "500");
				ilsctx.setVariable("ExitDescription", errorinfo);
				session.reject(errorinfo);
				//throw error;
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "gfal_024 : failure in putting message to 'LookupServiceResponse', details are : " + info + "; error info :" + error
							logger.error("gfal_024:failure in putting message to  LookupServiceResponse" + JSON.stringify(error));
							ilsctx.setVariable("exitStatus", "500");
							ilsctx.setVariable("ExitDescription", errorinfo);
							session.reject(errorinfo);
						} else {
							ilsctx.setVariable("exitStatus", "0");
							ilsctx.setVariable("ExitDescription", ExitDescription);
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from  LookupServiceResponse " + responseData);
							var lookupResponse = JSON.parse(responseData)
							logger.debug("lookupresponse----" + LookupServiceResponse);
							var Id;
							if (lookupResponse.lookupRep.type[0].result == 0) {
								Id = lookupResponse.lookupRep.type[0].id;
							} else {
								var errorinfo = "Error response received from 'LookupServiceResponse', details are : " + info + "; error info :" + error
								ilsctx.setVariable("exitStatus", "500");
								ilsctx.setVariable("ExitDescription", errorinfo);
								session.reject("Error response received from Lookup service");
								logger.error(errorinfo);
							}// lookup end;

							//start


							// Call: PATCH /api/v1/ServiceType/Electric/Job/{id}  # Job id from decoded payload

							var ctx = session.name("ExternalRefID") || session.createContext("ExternalRefID");
							var lookupResponse = ctx.getVar("lookupResponse");
							//var IdfromLookup = ctx.getVar("Id");
							var JobID = ctx.getVar("JobID");
							var job_Id = ctx.getVar("JobIdfromDecode");
							var omsExternalURL = ctx.getVar("omsExternalURL");

							//logger.error("omsExternalURL----"+omsExternalURL);
							var JobURL = omsExternalURL + 'Job/' + job_Id;
							var TokenValue = apiToken;
							var payload = {
								"outageSubtypeID": Id
							}

							var JobPATCHapi = {
								target: JobURL,
								sslClientProfile: 'gfal_OMS_SSL_ClientProfile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': TokenValue
								},
								data: payload
							};
							var info = " TargetURL :" + JobPATCHapi.target + "; Method :" + JobPATCHapi.method + "; Data :" + JSON.stringify(JobPATCHapi.data) + ". ";
							urlopen.open(JobPATCHapi, function(error, response) {
								if (error) {
									var errorinfo = "gfal_025 : url connection error 'JobPATCHapi', details are : " + info + "; error info :" + error
									logger.error("gfal_025:urlopen connect error with JobPATCHapi" + JSON.stringify(error));
									ilsctx.setVariable("exitStatus", "500");
									ilsctx.setVariable("ExitDescription", errorinfo);
									session.reject(errorinfo);
									//throw error;
								} else {
									// read response data
									// get the response status code
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {

										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "gfal_026 : error in reading response from 'JobPATCHapi', details are : " + info + "; error info :" + error
												//dp:reject stop the transaction and go error rule with error code and description
												logger.debug("gfal_026:failure in putting message to Jobapi comments" + JSON.stringify(error));
												ilsctx.setVariable("exitStatus", "500");
												ilsctx.setVariable("ExitDescription", errorinfo);
												session.reject(errorinfo);
											} else {
												//store status code with response body in context variable
												ilsctx.setVariable("exitStatus", "0");
												ilsctx.setVariable("ExitDescription", ExitDescription);
												hm.response.statusCode = responseStatusCode;
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from Jobapi comments" + responseStatusCode);

												// Call: POST /api/v1/ServiceType/Electric/Job/{id}/Comment  # job id from decoded payload.

												var ctx = session.name("ExternalRefID") || session.createContext("ExternalRefID");
												var JobID = ctx.getVar("JobID");
												var job_Id = ctx.getVar("JobIdfromDecode");
												var omsExternalURL = ctx.getVar("omsExternalURL");
												var JobURL = omsExternalURL + 'Job/' + job_Id + '/Comment';
												var TokenValue = apiToken;
												var TextVar1 = ctx.getVar("TextVar1");
												var TextVar2 = ctx.getVar("TextVar2");
												var Circuit = ctx.getVar("Circuit");
												//JobSubType from odm repsonse
												var jobSubType = ctx.getVar("jobSubType");

												// Comment text": Updating subtype to $1 due to correlation with existing ground fault alarm on circuit.". 
												var payload = {
													"comment": TextVar1 + ' ' + jobSubType + ' ' + TextVar2 + ' ' + Circuit
												}
												var Jobcommentapi = {
													target: JobURL,
													sslClientProfile: 'gfal_OMS_SSL_ClientProfile',
													method: 'POST',
													contentType: 'application/json',
													headers: {
														'osiApiToken': TokenValue
													},
													data: payload
												};
												var info = " TargetURL :" + Jobcommentapi.target + "; Method :" + Jobcommentapi.method + "; Data :" + JSON.stringify(Jobcommentapi.data) + ". ";
												urlopen.open(Jobcommentapi, function(error, response) {
													if (error) {
														var errorinfo = "gfal_027 : url connection error 'JobPATCHapi', details are : " + info + "; error info :" + error
														logger.error("gfal_027:urlopen connect error with Jobapi" + JSON.stringify(error));
														ilsctx.setVariable("exitStatus", "500");
														ilsctx.setVariable("ExitDescription", errorinfo);
														session.reject(errorinfo);
														throw error;
													} else {
														// read response data
														// get the response status code
														var responseStatusCode = response.statusCode;
														if (responseStatusCode == 200) {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "gfal_028 : failure in reading response from 'JobPATCHapi', details are : " + info + "; error info :" + error
																	logger.error("gfal_028:failure in putting message to Jobapi comments" + JSON.stringify(error));
																	ilsctx.setVariable("exitStatus", "500");
																	ilsctx.setVariable("ExitDescription", errorinfo);
																	session.reject(errorinfo);
																} else {
																	ilsctx.setVariable("exitStatus", "0");
																	ilsctx.setVariable("ExitDescription", ExitDescription);
																	//store status code with response body in context variable
																	hm.response.statusCode = responseStatusCode;
																	hm.response.statusCode = responseStatusCode;
																	logger.debug("response received from Jobapi comments" + responseStatusCode);
																}
															});
														} else {
															//start 
															var ctx = session.name("ExternalRefID") || session.createContext("ExternalRefID");
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "Error returned from Jobapi comments : " + info + "; error info :" + responseStatusCode + error
																	logger.error("Error returned from Jobapi comments with statusCode " + responseStatusCode);
																	ilsctx.setVariable("exitStatus", responseStatusCode);
																	ilsctx.setVariable("ExitDescription", errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "gfal_029:Error returned from Jobapi comments : " + info + "; error info :" + responseStatusCode + JSON.stringify(responseData)
																	logger.error("gfal_029:Error returned from Jobapi comments with statusCode " + responseStatusCode);
																	ilsctx.setVariable("exitStatus", responseStatusCode);
																	ilsctx.setVariable("ExitDescription", errorinfo);
																	session.reject(errorinfo);
																}
															});
															//end 		
														}
													}
												});
												//calling job comment end 
											}
										});
									} else {
										//start 
										var ctx = session.name("ExternalRefID") || session.createContext("ExternalRefID");
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "gfal_030:Error returned from JobPatchapi comments : " + info + "; error info :" + responseStatusCode + error + "Unauthorized"
												logger.error("gfal_030:Error returned from Jobapi with statusCode " + responseStatusCode);
												ilsctx.setVariable("exitStatus", responseStatusCode);
												ilsctx.setVariable("ExitDescription", errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "gfal_030:Error returned from JobPatchapi comments : " + info + "; error info :" + responseStatusCode + "Unauthorized"
												logger.error("gfal_030:Error returned from Jobapi with statusCode " + responseStatusCode);
												ilsctx.setVariable("exitStatus", responseStatusCode);
												ilsctx.setVariable("ExitDescription", errorinfo);
												session.reject(errorinfo);
											}
										});
										//end 
									}
								}
							});
						}
					});
				} else {
					var errorinfo = "failure in reading response from 'LookupServiceResponse', details are : " + info + "; error info :" + error
					logger.error("lookup response is not 200");
					ilsctx.setVariable("exitStatus", "500");
					ilsctx.setVariable("ExitDescription", errorinfo);
					session.reject(errorinfo);
				}
			}
		});
	}

});
