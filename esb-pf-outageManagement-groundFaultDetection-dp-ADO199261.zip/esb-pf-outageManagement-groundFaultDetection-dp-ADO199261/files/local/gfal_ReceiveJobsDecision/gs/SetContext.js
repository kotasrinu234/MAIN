var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

var ctx = session.name("ExternalRefID")|| session.createContext("ExternalRefID");
//set stylesheet parameters to variable
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.osiApiToken;
var TextVar1 =session.parameters.TextVar1;
var TextVar2 =session.parameters.TextVar2;
var lookupURL =session.parameters.lookupURL;
var nullCheckRequired = session.parameters.nullCheckRequired;
var Circuit = ctx.getVar("circuitId");
//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js
ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("TextVar1",TextVar1);
ctx.setVariable("TextVar2",TextVar2);
ctx.setVariable("lookupURL",lookupURL);
ctx.setVariable("nullCheckRequired",nullCheckRequired);	
		var payload={
			  "__DecisionID__": Circuit
	              }
			session.output.write(payload);
			ctx.setVariable("omsPayload", payload);	
}
});
