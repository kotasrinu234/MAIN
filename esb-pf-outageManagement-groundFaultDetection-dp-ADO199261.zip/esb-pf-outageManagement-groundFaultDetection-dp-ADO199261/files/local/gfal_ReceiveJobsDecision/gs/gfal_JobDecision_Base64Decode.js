var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsBuffer(function(error, buf) { 
var str = buf.toString();
//str = str.substr(str.indexOf(">")+1);
//str = str.substr(0, str.indexOf("<"));
str = new Buffer.from(str, 'base64').toString();
var resp = JSON.parse(str);
var Id= resp.data[0].id;
//var ctx = session.name('myContext') || session.createContext('myContext');
var ctx = session.name("ExternalRefID")|| session.createContext("ExternalRefID");
ctx.setVariable("decode", str);
ctx.setVariable("Response", resp);
ctx.setVariable("JobIdfromDecode", Id);

//session.output.write(Id);

logger.debug("gfal_022:JobIDFromDecodedPayload"+'' +Id);

});