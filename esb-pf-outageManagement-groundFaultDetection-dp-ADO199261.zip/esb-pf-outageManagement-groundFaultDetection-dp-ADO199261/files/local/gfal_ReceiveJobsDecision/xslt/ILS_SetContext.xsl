<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpquery="http://www.datapower.com/param/query"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:regexp="http://exslt.org/regular-expressions"
	extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ser="http://dteco.com/DeviceManagement/ServiceOrder"
	version="1.0">
	<xsl:variable name="Delimiter" select="'_'" />
	<xsl:template match="/">
		<xsl:variable name="Input">
			<xsl:copy-of select="dp:variable('var://context/DP_Var1')" />
		</xsl:variable>
		<xsl:variable name="TransactoinID">
			<xsl:copy-of select="dp:variable('var://service/global-transaction-id')" />
		</xsl:variable>

	
		<xsl:variable name="JobID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='JobID']/text())" />
		<xsl:variable name="circuitID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='Circuit']/text())" />
		<xsl:variable name="RestorationStatusPayload" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatusPayload']/text())" />
		<xsl:variable name="TimeStamp" select="date:date-time()"/>
		
		<dp:set-variable name="'var://context/groundfaultReport/nullCheckRequired'" value="$nullCheckValue" /> 
		<xsl:if test = "$nullCheckValue = 'yes'">
		<xsl:choose>
			<xsl:when test ="string-length($JobID) &gt; 0">
				<xsl:value-of select="$JobID" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>JobId not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		
		<xsl:choose>
			<xsl:when test ="string-length($circuitID) &gt; 0">
				<xsl:value-of select="$circuitID" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>CircuitId not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>	
		
		<xsl:choose>
			<xsl:when test ="string-length($RestorationStatusPayload) &gt; 0">
				<xsl:value-of select="$RestorationStatusPayload" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Unable to Decode the Payload</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
	
	</xsl:if>
		<dp:set-variable name="'var://context/ExternalRefID/circuitID'" value="string($circuitID)" />	
		<dp:set-variable name="'var://context/ExternalRefID/JobID'" value="string($JobID)" />	
		<dp:set-variable name="'var://context/ExternalRefID/RestorationStatusPayload'" value="string($RestorationStatusPayload)" />	
		
		<xsl:copy-of select="$RestorationStatusPayload"/>
		<!-- custom logging -->
		<xsl:message dp:type="all" dp:priority="debug">
			GroundFaultAlert_ReceiveJobsDecision REQUEST: <xsl:value-of select="concat('CircuitID:',$circuitID,'JobID:',$JobID,'RestorationStatusPayload:',$RestorationStatusPayload,'TimeStamp:',$TimeStamp)" />
		</xsl:message>

		<xsl:call-template name="set_ILS_Context">
			<xsl:with-param name="circuitID" select="$circuitID" />
			<xsl:with-param name="JobID" select="$JobID" />
			<xsl:with-param name="RestorationStatusPayload" select="$RestorationStatusPayload" />
			<xsl:with-param name="TimeStamp" select="$TimeStamp" />
		</xsl:call-template>
		
	</xsl:template>

	<xsl:template name="set_ILS_Context">
		<xsl:param name="circuitID" />
		<xsl:param name="JobID" />
		<xsl:param name="RestorationStatusPayload" />
		<xsl:param name="TimeStamp" />

		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()" />
		<dp:set-variable name="'var://context/TimeStamp'" value="$TimeStamp" />
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'RECEIVED'" />
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'GroundFaultAlert_ReceiveJobsDecision'" />
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')" />
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))" />
		<dp:set-variable name="'var://context/ServiceLog/User'" value="' '" />
		<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="string($circuitID)" />
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="string($JobID)" />
		<dp:set-variable name="'var://context/ServiceLog/ContextElement3'" value="string($RestorationStatusPayload)" />
		<dp:set-variable name="'var://context/ServiceLog/ContextElement4'" value="''" />
		<!-- <dp:set-variable name="'var://context/ServiceLog/ContextElement5'" 
			value="concat('TransactionId:',string(dp:variable('var://service/global-transaction-id')))"/> -->


	</xsl:template>
</xsl:stylesheet>
