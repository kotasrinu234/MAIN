<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions"
 xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig">

  <xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>

  <xsl:param name="dpconfig:EntryDescription" select="''"/>
  <xsl:variable name="EntryDescription" select="$dpconfig:EntryDescription"/>
  <xsl:param name="dpconfig:ExitDescription" select="''"/>
  <xsl:variable name="ExitDescription" select="$dpconfig:ExitDescription"/>
  <xsl:param name="dpconfig:messageType" select="''"/>
  <xsl:variable name="messageType" select="$dpconfig:messageType"/>
  
  
 
  <xsl:template match="/">
    <!-- Variable to store the correlation ID -->
    <xsl:variable name="correlationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='CorrelationID'])" />
    <dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID" />

   <dp:set-variable name="'var://context/ILS/messageType'" value="$messageType"/>

    <xsl:variable name="CircuitDisplayID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='Circuit'])"/>
    <dp:set-variable name="'var://context/ILS/CircuitDisplayID'" value="($CircuitDisplayID)"/>
    
    <xsl:variable name="jobDisplayID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='JobID'])"/>
    <dp:set-variable name="'var://context/ILS/jobDisplayID'" value="($jobDisplayID)"/>

    <xsl:variable name="sourceEventTimestamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='Timestamp'])" />
    <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="($sourceEventTimestamp)"/>

     <dp:set-variable name="'var://context/ILS/EntryDescription'" value="string($EntryDescription)"/>
    </xsl:template>
</xsl:stylesheet>