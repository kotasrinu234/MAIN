<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	
	<xsl:output method="text" omit-xml-declaration="yes"/>
	
	<xsl:param name="dpconfig:nullCheckRequired" />

	<xsl:template match="/">
		<!-- <xsl:variable name ="nullCheckValue" value="'yes'"/> -->
		<xsl:variable name="nullCheckValue" select="$dpconfig:nullCheckRequired" />
		<xsl:variable name="CorrelationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='CorrelationID']/text())" />
		<xsl:variable name="Timestamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='Timestamp']/text())" />
		<xsl:variable name="TroubleCode" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='TroubleCode']/text())" />
		<xsl:variable name="JobID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='JobID']/text())" />
		<xsl:variable name="circuitID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='Circuit']/text())" />
		<xsl:variable name="RestorationStatusPayload" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatusPayload']/text())" />
		<dp:set-variable name="'var://context/ExternalRefID/IDcircuit'" value="$circuitID" />
		<dp:set-variable name="'var://context/groundfaultReport/nullCheckRequired'" value="$nullCheckValue" />  
		
		<xsl:if test = "$nullCheckValue ='yes'">
			<xsl:choose>
				<xsl:when test ="string-length($circuitID) &gt; 0">
					<xsl:value-of select="$circuitID" />
		        </xsl:when>	
				<xsl:otherwise>
					<dp:reject>Circuit Id not found</dp:reject>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:choose>
				<xsl:when test ="string-length($JobID) &gt; 0">
					<xsl:value-of select="$JobID" />
		        </xsl:when>	
				<xsl:otherwise>
					<dp:reject>JobID not found</dp:reject>
				</xsl:otherwise>
		   </xsl:choose>
			<xsl:choose>
				<xsl:when test ="string-length($RestorationStatusPayload) &gt; 0">
					<xsl:value-of select="$RestorationStatusPayload" />
		        </xsl:when>	
				<xsl:otherwise>
					<dp:reject>RestorationStatusPayload not found</dp:reject>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:choose>
				<xsl:when test ="string-length($CorrelationID) &gt; 0">
					<xsl:value-of select="$CorrelationID" />
		        </xsl:when>	
				<xsl:otherwise>
					<dp:reject>CorrelationID not found</dp:reject>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:choose>
				<xsl:when test ="string-length($Timestamp) &gt; 0">
					<xsl:value-of select="$Timestamp" />
		        </xsl:when>	
				<xsl:otherwise>
					<dp:reject>Timestamp not found</dp:reject>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:choose>
				<xsl:when test ="string-length($TroubleCode) &gt; 0">
					<xsl:value-of select="$TroubleCode" />
		        </xsl:when>	
				<xsl:otherwise>
					<dp:reject>TroubleCode not found</dp:reject>
				</xsl:otherwise>
			</xsl:choose>
	  </xsl:if>
   </xsl:template>
	
</xsl:stylesheet>
