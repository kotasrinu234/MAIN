<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	extension-element-prefixes="dp" exclude-result-prefixes="dp"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:typ="http://www.ibm.com/wbe/casoap/types">
	
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes" />
	<xsl:template match="/">

		<xsl:variable name="JobID">
			<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='JobID']/text()" />
		</xsl:variable>
		<xsl:variable name="Circuit">
			<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='Circuit']/text()" />
		</xsl:variable>
		<xsl:variable name="RestorationStatusPayload">
			<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ODMRestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatusPayload']/text()" />
		</xsl:variable>

		<dp:set-variable name="'var://context/ExternalRefID/JobID'" value="string($JobID)" />
		<dp:set-variable name="'var://context/ExternalRefID/Circuit'" value="string($Circuit)" />
		<dp:set-variable name="'var://context/ExternalRefID/RestorationStatusPayload'" value="string($RestorationStatusPayload)" />
         <xsl:copy-of select="$RestorationStatusPayload"/>
              		
        <xsl:message dp:type="all" dp:priority="debug">gfal_020:ODM REQUEST : <xsl:value-of select="concat('Circuit:',$Circuit,'JobID:', $JobID,'RestorationStatusPayload:', $RestorationStatusPayload)"/></xsl:message>
		<xsl:message dp:type="all" dp:priority="debug">gfal_021:CircuitID : <xsl:value-of select="$Circuit"/></xsl:message>

	</xsl:template>
</xsl:stylesheet>