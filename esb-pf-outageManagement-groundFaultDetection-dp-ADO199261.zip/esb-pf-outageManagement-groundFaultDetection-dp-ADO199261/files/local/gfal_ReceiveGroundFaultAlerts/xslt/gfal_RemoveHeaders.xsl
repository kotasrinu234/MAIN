<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:typ="http://www.ibm.com/wbe/casoap/types"
	extension-element-prefixes="dp" exclude-result-prefixes="dp">
	<xsl:output method="xml" encoding="UTF-8" indent="yes" />

	<xsl:template match="/">


		<dp:remove-http-response-header name="Age" />
		<dp:remove-http-response-header name="Date" />
		<dp:remove-http-response-header name="Set-Cookie" />
		<dp:remove-http-response-header name="SameSite" />
		<dp:remove-http-response-header name="content-language" />
		<dp:remove-http-response-header name="p3p" />
		<dp:remove-http-response-header name="x-frame-options" />
		<dp:remove-http-response-header name="x-content-type-options" />
		<dp:remove-http-response-header name="x-xss-protection" />
		<dp:remove-http-response-header name="x-powered-by" />
		<dp:remove-http-response-header name="content-security-policy" />
		<dp:remove-http-response-header name="strict-transport-security" />
		<dp:remove-http-response-header name="Set-Cookie" />
		<dp:remove-http-response-header name="set-cookie" />
		<dp:remove-http-response-header name="CF-Cache-Status" />
		<dp:remove-http-response-header name="cf-request-id" />
		<dp:remove-http-response-header name="Expect-CT" />
		<dp:remove-http-response-header name="Server" />
		<dp:remove-http-response-header name="CF-RAY" />
		<dp:remove-http-response-header name="X-Global-Transaction-ID" />


	</xsl:template>
</xsl:stylesheet>