<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">	
			<xsl:variable name="nullcheck">
					<xsl:value-of select="dp:variable('var://context/groundfaultReport/nullCheckRequired')"/>
			</xsl:variable>
			<xsl:choose>
				<xsl:when test="contains($nullcheck,'yes')">
					<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
					<xsl:message>inside 400 condition</xsl:message>
				</xsl:when>
				<xsl:otherwise>
						<dp:set-variable name="'var://service/error-protocol-response'" value="dp:variable('var://service/error-headers')" />
						<xsl:message>inside otherwise condition</xsl:message>
				</xsl:otherwise>
			</xsl:choose>	
			<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
	</xsl:template>
</xsl:stylesheet>
