<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig date">
	<xsl:output method="text" omit-xml-declaration="yes"/>
	<xsl:template match="/">
		<xsl:variable name="PayLoad">
			<soap:Envelope xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
				<soap:Body>
					<sendGroundFaultEvent>
						<Verb>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/verb')"/>
						</Verb>
						<Noun>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/noun')"/>
						</Noun>
						<Timestamp>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/timeStamp')"/>
						</Timestamp>
						<Source>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/source')"/>
						</Source>
						<MessageID>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/messageID')"/>
						</MessageID>
						<Circuit>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/circuitId')"/>
						</Circuit>
						<TriggerTime>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/triggerTime')"/>
						</TriggerTime>
						<GroundDetectorStatus>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/groundDetectorStatus')"/>
						</GroundDetectorStatus>
						<Priority>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/priority')"/>
						</Priority>
						<countdownTimeFrameInHours>
							<xsl:value-of select="dp:variable('var://context/groundFaultReport/countdownTimeFrameInHours')"/>
						</countdownTimeFrameInHours>
					</sendGroundFaultEvent>
				</soap:Body>
			</soap:Envelope>
		</xsl:variable>
		<dp:set-variable name="'var://context/groundFaultReport/PayLoad'" value="$PayLoad"/>
	</xsl:template>
</xsl:stylesheet>
