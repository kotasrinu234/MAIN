<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions"
 xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig">

  <xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>

  <xsl:param name="dpconfig:EntryDescription" select="''"/>
  <xsl:variable name="EntryDescription" select="$dpconfig:EntryDescription"/>
  <xsl:param name="dpconfig:ExitDescription" select="''"/>
  <xsl:variable name="ExitDescription" select="$dpconfig:ExitDescription"/>
  <xsl:param name="dpconfig:messageType" select="''"/>
  <xsl:variable name="messageType" select="$dpconfig:messageType"/>
  <xsl:param name="dpconfig:StepExitDescription" select="''"/>
  <xsl:variable name="StepExitDescription" select="$dpconfig:StepExitDescription"/>
  
  
  <xsl:template match="/">
    <!-- Variable to store the correlation ID -->
    <xsl:variable name="correlationID" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='sendGroundFaultEvent']/*[local-name()='MessageID']" />


    <xsl:choose>
        <xsl:when test="$correlationID != ''">
       
            <!-- If MessageID is present, use its value -->
            <xsl:message>
  <xsl:text>Debug: TriggerTime value: </xsl:text>
  <xsl:value-of select="$correlationID"/>
</xsl:message>
            <dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID" />
        </xsl:when>
        <xsl:otherwise>
            <!-- If MessageID is not present, generate a UUID -->
            <xsl:variable name="generatedUUID" select="dp:generate-uuid()" />
            <xsl:value-of select="$generatedUUID" />
            <!-- Set the variable to generated UUID -->
            <dp:set-variable name="'var://context/ILS/correlationID'" value="$generatedUUID" />
        </xsl:otherwise>
    </xsl:choose>


    <dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)"/>

    <xsl:variable name="circuitId" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='sendGroundFaultEvent']/*[local-name()='Circuit'])"/>
    <dp:set-variable name="'var://context/ILS/CircuitDisplayID'" value="($circuitId)"/>

    <xsl:variable name="timeStamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='sendGroundFaultEvent']/*[local-name()='TriggerTime'])" />

<xsl:choose>
  <xsl:when test="$timeStamp != ''">
    <!-- If TriggerTime is present, use its value -->
    <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$timeStamp" />
  </xsl:when>
  <xsl:otherwise>
    <!-- If TriggerTime is not present, use the current timestamp -->
    <xsl:variable name="currentTime" select="date:date-time()" />
    <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$currentTime" />
  </xsl:otherwise>
</xsl:choose>


    <dp:set-variable name="'var://context/ILS/EntryDescription'" value="string($EntryDescription)"/>
    <dp:set-variable name="'var://context/ILS/StepExitDescription'" value="string($StepExitDescription)"/>

    <!-- Continue with other processing -->
    <xsl:apply-templates select="node()|@*" />
  </xsl:template>
</xsl:stylesheet>
