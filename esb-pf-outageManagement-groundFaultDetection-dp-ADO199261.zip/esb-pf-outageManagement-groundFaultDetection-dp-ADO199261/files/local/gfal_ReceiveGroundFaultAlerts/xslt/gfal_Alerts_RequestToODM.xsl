<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	
	<xsl:output method="text" omit-xml-declaration="yes"/>

	<xsl:template match="/">
	
		<xsl:variable name="circuitId" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Circuit']/text())"/>
		<xsl:variable name="verb" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Verb']/text())" />
		<xsl:variable name="noun" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Noun']/text())" />
		<xsl:variable name="timeStamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Timestamp']/text())" />
		<xsl:variable name="source" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Source']/text())" />
		<xsl:variable name="messageID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='MessageID']/text())" />
		<xsl:variable name="triggerTime" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='TriggerTime']/text())" />
		<xsl:variable name="groundDetectorStatus" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='GroundDetectorStatus']/text())" />
		<xsl:variable name="priority" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Priority']/text())" />
		<!-- <xsl:variable name="countdownTimeFrameInHours" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='countdownTimeFrameInHours']/text())" /> -->
		
		<xsl:message dp:type="all" dp:priority="debug">gfal_001:ODM REQUEST : <xsl:value-of select="concat('Circuit:',$circuitId,'Verb:', $verb,'Noun:',$noun,'Timestamp:',$timeStamp,'Source:',$source,'MessageID:',$messageID,'TriggerTime:',$triggerTime,'GroundDetectorStatus:',$groundDetectorStatus,'Priority:',$priority)"/></xsl:message>
		<xsl:message dp:type="all" dp:priority="debug">gfal_002:CircuitID : <xsl:value-of select="$circuitId"/></xsl:message>
		
		<xsl:choose>
			<xsl:when test ="string-length($circuitId) &gt; 0">
				<xsl:value-of select="$circuitId" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Circuit Id not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		
		<xsl:choose>
			<xsl:when test ="string-length($verb) &gt; 0">
				<xsl:value-of select="$verb" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Verb not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($noun) &gt; 0">
				<xsl:value-of select="$noun" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Noun not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($timeStamp) &gt; 0">
				<xsl:value-of select="$timeStamp" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>TimeStamp not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($source) &gt; 0">
				<xsl:value-of select="$source" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Source not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($messageID) &gt; 0">
				<xsl:value-of select="$messageID" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>MessageID not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($triggerTime) &gt; 0">
				<xsl:value-of select="$triggerTime" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>TriggerTime not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($groundDetectorStatus) &gt; 0">
				<xsl:value-of select="$groundDetectorStatus" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>GroundDetectorStatus not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($priority) &gt; 0">
				<xsl:value-of select="$priority" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Priority not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<!-- <xsl:choose>
			<xsl:when test ="string-length($countdownTimeFrameInHours) &gt; 0">
				<xsl:value-of select="$countdownTimeFrameInHours" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>CountdownTimeFrameInHours not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose> -->
		
		<dp:set-variable name="'var://context/groundFaultReport/circuitId'" value="$circuitId" />
		<dp:set-variable name="'var://context/groundFaultReport/verb'" value="$verb" />
		<dp:set-variable name="'var://context/groundFaultReport/noun'" value="$noun" />
		<dp:set-variable name="'var://context/groundFaultReport/timeStamp'" value="$timeStamp" />
		<dp:set-variable name="'var://context/groundFaultReport/source'" value="$source" />
		<dp:set-variable name="'var://context/groundFaultReport/messageID'" value="$messageID" />
		<dp:set-variable name="'var://context/groundFaultReport/triggerTime'" value="$triggerTime" />
		<dp:set-variable name="'var://context/groundFaultReport/groundDetectorStatus'" value="$groundDetectorStatus" />
		<dp:set-variable name="'var://context/groundFaultReport/priority'" value="$priority" />
		<!-- <dp:set-variable name="'var://context/groundFaultReport/countdownTimeFrameInHours'" value="$countdownTimeFrameInHours" /> -->
	</xsl:template>
</xsl:stylesheet>