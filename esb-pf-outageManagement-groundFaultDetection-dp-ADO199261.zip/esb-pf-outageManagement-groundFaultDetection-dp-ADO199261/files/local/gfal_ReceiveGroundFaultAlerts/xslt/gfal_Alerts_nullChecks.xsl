<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	
	<xsl:output method="text" omit-xml-declaration="yes"/>
	
	<xsl:param name="dpconfig:nullCheckRequired" />
	<xsl:template match="/">
		<!-- <xsl:variable name ="nullCheckValue" value="'yes'"/> -->
		<xsl:variable name="nullCheckValue" select="$dpconfig:nullCheckRequired" />
		<xsl:variable name="circuitId" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Circuit']/text())"/>
		<xsl:variable name="verb" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Verb']/text())" />
		<xsl:variable name="noun" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Noun']/text())" />
		<xsl:variable name="timeStamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Timestamp']/text())" />
		<xsl:variable name="source" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Source']/text())" />
		<xsl:variable name="messageID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='MessageID']/text())" />
		<xsl:variable name="triggerTime" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='TriggerTime']/text())" />
		<xsl:variable name="groundDetectorStatus" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='GroundDetectorStatus']/text())" />
		<xsl:variable name="priority" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[ local-name()='sendGroundFaultEvent']/*[local-name()='Priority']/text())" />
		
		 <dp:set-variable name="'var://context/groundFaultReport/ID'" value="$circuitId" /> 
		 <dp:set-variable name="'var://context/groundfaultReport/nullCheckRequired'" value="$nullCheckValue" /> 
		 
		<xsl:if test = "$nullCheckValue = 'yes'">
			<xsl:choose>
				<xsl:when test ="string-length($circuitId) &gt; 0">
					<xsl:value-of select="$circuitId" />
		        </xsl:when>	
				<xsl:otherwise>
					<dp:reject>Circuit Id not found</dp:reject>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:choose>
			<xsl:when test ="string-length($verb) &gt; 0">
				<xsl:value-of select="$verb" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Verb not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($noun) &gt; 0">
				<xsl:value-of select="$noun" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Noun not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($timeStamp) &gt; 0">
				<xsl:value-of select="$timeStamp" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>TimeStamp not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($source) &gt; 0">
				<xsl:value-of select="$source" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Source not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($messageID) &gt; 0">
				<xsl:value-of select="$messageID" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>MessageID not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($triggerTime) &gt; 0">
				<xsl:value-of select="$triggerTime" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>TriggerTime not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($groundDetectorStatus) &gt; 0">
				<xsl:value-of select="$groundDetectorStatus" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>GroundDetectorStatus not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test ="string-length($priority) &gt; 0">
				<xsl:value-of select="$priority" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>Priority not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>
		<!-- <xsl:choose>
			<xsl:when test ="string-length($circuitId) &gt; 0 or string-length($verb)&gt; 0 or string-length($noun)&gt;0 or string-length($timeStamp)&gt;0 or string-length($source)&gt;0 or string-length($messageID)&gt;0 or string-length($triggerTime)&gt;0 or string-length($groundDetectorStatus)&gt;0 or  string-length($priority)&gt; 0">
				<dp:reject>some required fields are not found</dp:reject>
	        </xsl:when>	
			<xsl:otherwise>
			</xsl:otherwise>
		</xsl:choose> -->
	</xsl:if>
 </xsl:template>
	
</xsl:stylesheet>
