var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
var ExitDescription = ilsctx.getVar("ExitDescription");
var exitStatus = ilsctx.getVar("exitStatus");

var urlIn = sm.getVar('var://service/routing-url');

var errmsg = sm.getVar('var://service/error-message')
//var errorinfo = "errror in reading response from 'odmcall' details are:"+urlIn;

		//var ctx = session.name('groundfaultReport') || session.createContext('groundfaultReport');
		if (errmsg == 'Failed to establish a backside connection') {
			var errorinfo = "errror in reading response from odmcall details are:" + urlIn + " " + errmsg;
			ilsctx.setVariable("statusdetail", errorinfo);
			ilsctx.setVariable("exitStatus", "500");
		}
		else if (ExitDescription) {
			ilsctx.setVariable("statusdetail", ExitDescription);
			//ilsctx.setVariable("exitStatus", exitStatus);
		}
		else {
			ilsctx.setVariable("statusdetail", errmsg);
		}
	
