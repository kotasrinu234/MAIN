var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
			var ctx = session.name("groundFaultReport")|| session.createContext("groundFaultReport");
			var streamuri =session.parameters.streamuri;
			var nullCheckRequired = session.parameters.nullCheckRequired;
			var Circuit = ctx.getVar("circuitId");
			
			ctx.setVariable("streamuri",streamuri);
			ctx.setVariable("nullCheckRequired",nullCheckRequired);
		
		var payload={
			  "__DecisionID__": Circuit
	              }
		   
			session.output.write(payload);
			ctx.setVariable("omsPayload", payload);
         }
});