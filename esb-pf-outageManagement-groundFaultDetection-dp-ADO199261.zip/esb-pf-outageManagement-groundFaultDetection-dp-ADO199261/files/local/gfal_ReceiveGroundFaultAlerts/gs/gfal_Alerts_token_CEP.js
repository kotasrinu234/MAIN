var urlopen = require('urlopen');
var sm = require('service-metadata')
var logger = console.options({ 'category': 'all' });
var ctx = session.name("groundFaultReport") || session.createContext("groundFaultReport");
var ilsctx = session.name("ILS") || session.createContext("ILS");
sm.setVar("var://service/mpgw/skip-backside", true)
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data as JSON : " + readAsJSONError;
		ctx.setVariable("exitDescription", errorinfo)
		ctx.setVariable("exitStatus", "500")
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {
		var eventHubURL = session.parameters.cepURL;
		var Token = ctx.getVar("Token");
		var json = ctx.getVar("PayLoad");
		var Options = {
			target: eventHubURL,
			sslClientProfile: 'gfal_tls_client_profile',
			method: 'POST',
			headers: {
				'Authorization': Token,
			},
			contentType: 'application/x-www-form-urlencoded',
			data: json
		}

		var info = " TargetURL :" + Options.target + "; Method :" + Options.method + "; Data :" + JSON.stringify(Options.data) + ". ";
		urlopen.open(Options, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'EventHub Call in gfal_ReceiveGroundFaultAlerts Service', details are :" + info + "; error info :" + error;
				ctx.setVariable("exitDescription", errorinfo);
				ctx.setVariable("exitStatus", "500");
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode === 200 || responseStatusCode === 201) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'EventHub Call in gfal_ReceiveGroundFaultAlerts Service' , details are : " + eventHubCallInfo + "; error info :" + error;
							ctx.setVariable("exitDescription", errorinfo);
							ctx.setVariable("exitStatus", "500");
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							logger.debug("response received :" + responseData);
							var exitDescription = session.parameters.ExitDescription;
							if (exitDescription !== null || exitDescription !== undefined || exitDescription !== '') {
								ilsctx.setVariable("ExitDescription", exitDescription);
							}
							if (eventHubURL !== null || eventHubURL !== undefined || eventHubURL !== '') {
								ilsctx.setVariable("exitDestination", eventHubURL);
							}
							ctx.setVariable("exitStatus", "0");
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'EventHub Call in gfal_ReceiveGroundFaultAlerts Service', details are : " + info + "; error info :" + error
							ctx.setVariable("exitDescription", errorinfo);
							ctx.setVariable("exitStatus", "500");
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "error response 'EventHub Call in gfal_ReceiveGroundFaultAlerts Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable("exitDescription", errorinfo);
							ctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		});
	}
});
