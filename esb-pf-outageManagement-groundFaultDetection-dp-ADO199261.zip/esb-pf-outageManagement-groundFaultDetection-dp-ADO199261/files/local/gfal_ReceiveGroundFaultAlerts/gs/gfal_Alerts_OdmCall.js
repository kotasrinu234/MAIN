var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("groundFaultReport") || session.createContext("groundFaultReport");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	var jsonInput = incomingdata;
	//console.log("incomingdata----"+incomingdata);
	ctx.setVariable("inputjson", incomingdata);
	var countdownTimeFrameInHours = incomingdata.groundFaultParameters.countdownTimeFrameInHours;
	ctx.setVariable("countdownTimeFrameInHours", countdownTimeFrameInHours);
	//ADO153680
	var getTokenUrl = session.parameters.getTokenUrl
	var Options = {
		target: getTokenUrl,
		method: 'GET',
		contentType: 'application/json',
	};
	var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
	urlopen.open(Options, function(error, response) {
		if (error) {
			var errorinfo = "url connection error 'Token Call in gfal_ReceiveGroundFaultAlerts Service', details are :" + info + "; error info :" + error;
			ctx.setVariable("exitDescription", errorinfo);
			ctx.setVariable("exitStatus", "500");
			ctx.setVariable("exitDestination", getTokenUrl);
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode === 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response 'Token Call in gfal_ReceiveGroundFaultAlerts Service', details are : " + info + "; error info :" + error
						ctx.setVariable("exitDescription", errorinfo);
						ctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var ms = require('multistep');
						ctx.setVariable("exitDestination", getTokenUrl);
						ctx.setVariable("tokenExitDescription", session.parameters.tokenExitDescription);
						ms.callRule('gfal_ReceiveGroundFaultAlerts_PP_ILS_Logging_rule', null, null, function(error) {
							if (error) {
								logger.error("Error in gfal_ReceiveGroundFaultAlerts_PP_ILS_Logging_rule" + error);
							}
						});
						var AccessToken = responseData.access_token;
						if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
							var errorinfo = "Invalid token revieved in gfal_ReceiveGroundFaultAlerts Service, details are : " + info
							ctx.setVariable("exitDescription", errorinfo);
							ctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var TokenType = responseData.token_type;
							var Token = TokenType + ' ' + AccessToken;
							ctx.setVariable("Token", Token);
						}
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response 'Token Call in gfal_ReceiveGroundFaultAlerts Service', details are : " + info + "; error info :" + error
						ctx.setVariable("exitDescription", errorinfo);
						ctx.setVariable("exitStatus", responseStatusCode);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "error response 'Token Call in gfal_ReceiveGroundFaultAlerts Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable("exitDescription", errorinfo);
						ctx.setVariable("exitStatus", responseStatusCode);
						ctx.setVariable("exitDestination", getTokenUrl);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		}
	});
});
