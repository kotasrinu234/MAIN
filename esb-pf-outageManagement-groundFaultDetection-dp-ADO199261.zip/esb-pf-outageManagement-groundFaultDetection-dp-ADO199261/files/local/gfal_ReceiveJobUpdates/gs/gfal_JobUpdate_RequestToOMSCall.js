var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var omsExternalURL = ctx.getVar("omsExternalURL");
var apiToken = ctx.getVar("apiToken");
var leadCallID = ctx.getVar("leadCallID");
var feederId = ctx.getVar("feederId");
var jobTypeID = ctx.getVar("jobTypeID");
var displayID = ctx.getVar("displayID");
var logger = console.options({
	'category': 'all'
});
var ExitDescription = session.parameters.JobupdateExitDescription;
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
	ctx.setVariable("odmresponse", incomingdata);
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data";
		logger.error("Error in reading incoming data");
		ilsctx.setVariable("exitStatus", "500");
		ilsctx.setVariable("ExitDescription", errorinfo);
		session.reject(errorinfo);
	} else {
		if (displayID != undefined) {
			// GET Call: externalCallCodeId /api/ServiceType/Electric/Call/{id} starts
			if (leadCallID === null || leadCallID === '' || leadCallID != undefined) {
				var Callapiuri = omsExternalURL + 'Call/' + leadCallID;
				var Callapi = {
					target: Callapiuri,
					sslClientProfile: 'gfal_OMS_SSL_ClientProfile',
					method: 'GET',
					contentType: 'application/json',
					headers: {
						'osiApiToken': apiToken
					},
				};
				var info = " TargetURL :" + Callapi.target + "; Method :" + Callapi.method   + ". ";
				urlopen.open(Callapi, function(error, response) {
					if (error) {
						var errorinfo = "gfal_008 : urlopen connect error with 'Callapi' details are : " + info + "; error info :" + error
						logger.error("gfal_008:urlopen connect error with Callapi");
						ilsctx.setVariable("exitStatus", "500");
						ilsctx.setVariable("ExitDescription", errorinfo);
						session.reject(errorinfo);
						//throw error;
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {

							//	if (responseStatusCode == 200){
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "gfal_007 : error in reading response from 'Callapi' details are : " + info + "; error info :" + error
									//dp:reject stop the transaction and go error rule with error code and description
									logger.error("gfal_007:failure in putting message to Callapi" + JSON.stringify(error));
									ilsctx.setVariable("exitStatus", responseStatusCode);
									ilsctx.setVariable("ExitDescription", errorinfo);
									session.reject(errorinfo);
								} else {
									ilsctx.setVariable("exitStatus", "0");
									ilsctx.setVariable("ExitDescription", ExitDescription);
									//store status code with response body in context variable
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from Callapi for leadCallID:" + leadCallID + "" + responseStatusCode);
									var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
									var Callapiresponse = JSON.parse(responseData);
									var externalCallCodeID = JSON.parse(responseData).externalCallCodeID;
									var createdAt = Callapiresponse.createdAt;
									ctx.setVariable("createdAt", createdAt);
									ctx.setVariable("callResp", Callapiresponse);
									ctx.setVariable("externalCallCodeID", externalCallCodeID);
								}
							});
						} else {
							//start 
							var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "gfal_008 : Error returned  from 'Callapi' details are : " + info + "; error info :" + responseStatusCode + error + "Unauthorized"
									logger.error("gfal_08:Error returned from Callapi with statusCode " + "  " + responseStatusCode);
									ilsctx.setVariable("exitStatus", responseStatusCode);
									ilsctx.setVariable("ExitDescription", errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "gfal_008 : Error returned  from 'Callapi' details are : " + info + "; error info :" + responseStatusCode  +"Unauthorized"
									logger.error("gfal_08:Error returned from Callapi with statusCode " + "  " + responseStatusCode);
									ilsctx.setVariable("exitStatus", responseStatusCode);
									ilsctx.setVariable("ExitDescription", errorinfo);
									session.reject(errorinfo);
								}
							});
							//end 
						}
					}
				});
			} else {
				logger.error("leadCallID is not present in input payload");
				session.reject('leadCallID not found');
			}
		}
		//else for displayid 
		else {
			logger.error("displayid is not passed in oms ipnut data");
			throw error("displayid is not passed in oms ipnut data");
		}
	}
});
