var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
//getting styleheet params
var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var lookupURL = ctx.getVar("lookupURL");
var omsExternalURL = ctx.getVar("omsExternalURL");
var apiToken = ctx.getVar("apiToken");
var exID = ctx.getVar("extrID");
var displayID = ctx.getVar("displayID");
var feederId = ctx.getVar("feederId");
var jobTypeID = ctx.getVar("jobTypeID");
//var displayID =ctx.getVar("displayID");
var Status = ctx.getVar("Status");

var logger = console.options({
	'category': 'all'
});

var ExitDescription = session.parameters.JobupdateExitDescription;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data"
		logger.error("Error in reading incoming data");
		ilsctx.setVariable("exitStatus", "500");
		ilsctx.setVariable("ExitDescription", errorinfo);
		session.reject(errorinfo);
	} else {

		if (displayID != undefined) {

			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "jobTypes.workflows",
							"id": jobTypeID,
							"status": Status,
							"label": "New"
						}
					]
				}
			}

			var LookupServiceResponse = {
				target: lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};

			ctx.setVariable("LookupRequest", lookupMessage);
			ctx.setVariable("LookupServiceResponse", LookupServiceResponse);

			var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
			urlopen.open(LookupServiceResponse, function(error, response) {

				if (error) {
					var errorinfo = "gfal_09 : urlopen connect error with LookupServiceResponse details are : " + info + "; error info :" + error
					logger.error("gfal_09:urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
					ilsctx.setVariable("exitStatus", "500");
					ilsctx.setVariable("ExitDescription", errorinfo);
					session.reject(errorinfo);
					//throw error;
				} else {
					var responseStatusCode = response.statusCode;

					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {

							if (error) {
								var errorinfo = "gfal_010 : error in reading response from 'LookupServiceResponse' details are : " + info + "; error info :" + responseStatusCode + error
								// error while reading response or transferring data to Buffer
								logger.error("gfal_010:failure in putting message to LookupServiceResponse" + JSON.stringify(error));
								ilsctx.setVariable("exitStatus", responseStatusCode);
								ilsctx.setVariable("ExitDescription", errorinfo);
								session.reject(errorinfo);
							} else {
								ilsctx.setVariable("exitStatus", "0");
								ilsctx.setVariable("ExitDescription", ExitDescription);
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from LookupServiceResponse " + responseData);
								var lookupResponse = JSON.parse(responseData);
								logger.debug("response" + LookupServiceResponse);

								if (lookupResponse.lookupRep.type[0].result == 0) {
									var lookuplabel = lookupResponse.lookupRep.type[0].label;
									if (lookuplabel == "New") {
										var jobStatus = "New";
									} else {
										session.reject("Response from lookuplabel" + lookuplabel);
										//console("inside response label");
									}
								} else {
									session.reject("Terminating if the Job is Not new ");
									logger.error("gfal_011:Terminating if the Job is Not new");
								}
								var jobStatus = "New";
								if (jobStatus == 'New') {
									var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
									var callCodesArray = [];
									//var externalIDfromCallAPI = ctx.getVar("externalCallCodeID");
									var codeFlag;
									for (var i = 0; i < incomingdata.groundFaultParameters.callCode.length; i++) {
										callCodesArray.push(incomingdata.groundFaultParameters.callCode[i]);
										var externalIDfromCallAPI = ctx.getVar("externalCallCodeID");
										if (callCodesArray[i] === externalIDfromCallAPI) {
											codeFlag = "true";
										}
									}
									ctx.setVariable("callCodesArray", callCodesArray);

									if (codeFlag == "true") {
										logger.debug("inside code flag true");
										var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
										ctx.setVariable("externalIDfromCallAPI", externalIDfromCallAPI);
										// Call: PATCH /api/ServiceType/Electric/Feeder/{id} # Job id from decoded payload
										var feeder_ID = ctx.getVar("feederId");
										var omsExternalURL = ctx.getVar("omsExternalURL");
										var feederUrl = omsExternalURL + 'Feeder/' + feeder_ID;
										var feederAPI = {
											target: feederUrl,
											sslClientProfile: 'gfal_OMS_SSL_ClientProfile',
											method: 'GET',
											contentType: 'application/json',
											headers: {
												'osiApiToken': apiToken
											}
										};
										var info = " TargetURL :" + feederAPI.target + "; Method :" + feederAPI.method + "; Data :" + JSON.stringify(feederAPI.data) + ". ";
										urlopen.open(feederAPI, function(error, response) {
											if (error) {
												var errorinfo = "gfal_012 : urlopen connect error with feederAPI details are : " + info + "; error info :" + error
												logger.error("gfal_012:urlopen connect error with feederAPI" + JSON.stringify(error));
												ilsctx.setVariable("exitStatus", "500");
												ilsctx.setVariable("ExitDescription", errorinfo);
												session.reject(errorinfo);
												//throw error;
											} else {
												// read response data
												// get the response status code
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "gfal_013 : error in reading response from 'feederAPI' details are : " + info + "; error info :" + error
															//dp:reject stop the transaction and go error rule with error code and description
															logger.error("gfal_013:failure in putting message to feederapi" + JSON.stringify(error));
															ilsctx.setVariable("exitStatus", responseStatusCode);
															ilsctx.setVariable("ExitDescription", errorinfo);
															session.reject(errorinfo);
														} else {
															ilsctx.setVariable("exitStatus", "0");
															ilsctx.setVariable("ExitDescription", ExitDescription);
															//store status code with response body in context variable
															hm.response.statusCode = responseStatusCode;
															logger.debug("response received from feederapi :" + feeder_ID + "" + responseStatusCode);
															var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
															var feederResp = JSON.parse(responseData);
															var externlID = JSON.parse(responseData).externalID;
															ctx.setVariable("feederResponse", feederResp);
															ctx.setVariable("externlID", externlID);
															//ADO153680
															var getTokenUrl = session.parameters.getTokenUrl
															var Options = {
																target: getTokenUrl,
																method: 'GET',
																contentType: 'application/json',
															};
															var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
															urlopen.open(Options, function(error, response) {
																if (error) {
																	var errorinfo = "url connection error 'Token Call in gfal_ReceiveJobUpdates Service', details are :" + info + "; error info :" + error;
																	ctx.setVariable("exitDescription", errorinfo);
																	ctx.setVariable("exitStatus", "500");
																	ctx.setVariable("exitDestination", getTokenUrl);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var responseStatusCode = response.statusCode;
																	if (responseStatusCode === 200) {
																		response.readAsJSON(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'Token Call in gfal_ReceiveJobUpdates Service', details are : " + info + "; error info :" + error
																				ctx.setVariable("exitDescription", errorinfo);
																				ctx.setVariable("exitStatus", "500");
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var ms = require('multistep');
																				ctx.setVariable("exitDestination", getTokenUrl);
																				ctx.setVariable("tokenExitDescription", session.parameters.tokenExitDescription);
																				ms.callRule('gfal_ReceiveJobUpdates_policy_ILS_Logging', null, null, function(error) {
																					if (error) {
																						logger.error("Error in 	gfal_ReceiveJobUpdates_policy_ILS_Logging" + error);
																					}
																				});
																				var AccessToken = responseData.access_token;
																				if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
																					var errorinfo = "Invalid token revieved in gfal_ReceiveJobUpdates Service, details are : " + info
																					ctx.setVariable("exitDescription", errorinfo);
																					ctx.setVariable("exitStatus", responseStatusCode);
																					logger.error(errorinfo);
																					session.reject(errorinfo);
																				} else {
																					var TokenType = responseData.token_type;
																					var Token = TokenType + ' ' + AccessToken;
																					ctx.setVariable("Token", Token);
																				}
																			}
																		});
																	} else {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'Token Call in gfal_ReceiveJobUpdates Service', details are : " + info + "; error info :" + error
																				ctx.setVariable("exitDescription", errorinfo);
																				ctx.setVariable("exitStatus", responseStatusCode);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var errorinfo = "error response 'Token Call in gfal_ReceiveJobUpdates Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																				ctx.setVariable("exitDescription", errorinfo);
																				ctx.setVariable("exitStatus", responseStatusCode);
																				ctx.setVariable("exitDestination", getTokenUrl);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			}
																		});
																	}
																}
															});
														}
													});

												} else {
													//start 
													var ctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "gfal_014 : Error returned from 'Jobfeeder' details are : " + info + "; error info :" + responseStatusCode + error
															logger.error("gfal_014:Error returned from Jobfeeder with statusCode " + " " + responseStatusCode);
															ilsctx.setVariable("exitStatus", responseStatusCode);
															ilsctx.setVariable("ExitDescription", errorinfo);
															session.reject(errorinfo);
														} else {
															var errorinfo = "gfal_014 : Error returned from 'Jobfeeder' details are : " + info + "; error info :" + responseStatusCode + JSON.stringify(responseData)
															logger.error("gfal_014:Error returned from Jobfeeder with statusCode " + " " + responseStatusCode);
															ilsctx.setVariable("exitStatus", responseStatusCode);
															ilsctx.setVariable("ExitDescription", errorinfo);
															session.reject(errorinfo);
														}
													});
													//end 
												}
											}
										});
									} else {
										//logger.debug("inside code flag else");
										session.reject("Call code from omasapi response is not matched");
									}
								}
							}

						});

					} else {
						logger.error("Lookup response is not 200");
						session.reject("Lookup response is not 200");
					}

				}

			});

		} else {
			logger.error("displayid is not passed in oms input data");
			session.reject("displayid is not passed in oms input data");
		}
	}


});
