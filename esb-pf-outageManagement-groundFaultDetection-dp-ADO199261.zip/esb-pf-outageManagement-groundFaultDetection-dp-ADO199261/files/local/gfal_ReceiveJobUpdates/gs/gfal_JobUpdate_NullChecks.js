var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
       'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
       // getting styleheet params
		var ctx = session.name("groundfaultReport")|| session.createContext("groundfaultReport");
		var lookupURL = ctx.getVar("lookupURL");
		var omsExternalURL = ctx.getVar("omsExternalURL");
		var apiToken= ctx.getVar("apiToken");
        var nullCheckRequired = ctx.getVar("nullCheckRequired");
       
       if(readAsJSONError) {
              logger.error("Error in reading incoming data");
              session.reject(readAsJSONError);
       } else {
				var leadCallID = incomingdata.data[0].leadCallID;
				var displayID = incomingdata.data[0].displayID;
				var id = incomingdata.data[0].id;
	              if(nullCheckRequired == 'yes'){
	            	  if(leadCallID === undefined || leadCallID === null ||leadCallID === '' ){
						  session.reject("leadCallID not found");
	                    }
						else{
							// valid data
						}
	            	  
	            	  if(displayID === undefined || displayID === null ||displayID === '' ){
						  session.reject("displayID not found");
	                    }
						else{
							// valid data
						}
	            	  
	            	  if(id === undefined || id === null ||id === '' ){
						  session.reject("JobId not found");
	                    }
						else{
							// valid data
						}
	            	  
	            	  if ((leadCallID == undefined && displayID == undefined) || (id == undefined && displayID == undefined) || (leadCallID == undefined && id == undefined)) {
	                      session.reject('some required fields are missing');
	                     // logger.error("some required fields are not found.");
	                  }
                 }
			}
             
       });
