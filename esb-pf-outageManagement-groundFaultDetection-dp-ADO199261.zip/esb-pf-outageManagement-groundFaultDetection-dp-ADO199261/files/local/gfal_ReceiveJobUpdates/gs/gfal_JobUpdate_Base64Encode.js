var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsBuffer(function(readAsJSONError, incomingdata) {
	//var ctx = session.name('myContext') || session.createContext('myContext');
	var ctx = session.name("groundfaultReport")|| session.createContext("groundfaultReport");
	var jsonInput = incomingdata;
	//ctx.setVariable("jsonReq", jsonInput);
	 ctx.setVariable("inputjson", incomingdata);
	 var convertedBase64Msg= incomingdata.toString('base64');
	 ctx.setVariable("convertbase64", convertedBase64Msg);
	 //logger.error("inputjson----" + incomingdata);
	 //logger.debug("Request----" + convertedBase64Msg);
	 logger.debug("gfal_006:ConvertedBase64Request::" + convertedBase64Msg);
});
