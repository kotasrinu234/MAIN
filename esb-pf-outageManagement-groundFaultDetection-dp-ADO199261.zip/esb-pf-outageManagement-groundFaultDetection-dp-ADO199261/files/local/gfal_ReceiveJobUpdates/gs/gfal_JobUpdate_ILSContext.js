//var ilsctx = session.name("ILS")|| session.createContext("ILS");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
//getting styleheet params
var ilsctx = session.name("ILS") || session.createContext("ILS");
var omsExternalURL = session.parameters.omsExternalURL
var apiToken = session.parameters.osiApiToken

var logger = console.options({
	'category': 'all'
});

var EntryDescription = session.parameters.JobupdateEntryDescription;
var ExitDescription = session.parameters.JobupdateExitDescription;
var StepExitDescription = session.parameters.JobupdateStepExitDescription;
var messageType = session.parameters.messageType;

if (messageType != undefined || messageType != null || messageType != '') {
	ilsctx.setVariable("messageType", messageType);
}
if (EntryDescription != undefined || EntryDescription != null || EntryDescription != '') {
	ilsctx.setVariable('EntryDescription', EntryDescription);
}
if (ExitDescription != undefined || ExitDescription != null || ExitDescription != '') {
	ilsctx.setVariable('ExitDescription', ExitDescription);
}
if (StepExitDescription != undefined || StepExitDescription != null || StepExitDescription != '') {
	ilsctx.setVariable('StepExitDescription', StepExitDescription);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {


		if (!(incomingdata.data[0].displayID === undefined || incomingdata.data[0].displayID === null || incomingdata.data[0].displayID === '')) {
			ilsctx.setVariable("jobDisplayID", incomingdata.data[0].displayID)
		}
		ilsctx.setVariable("sourceEventTimestamp", new Date().toISOString())


		if (!(incomingdata.data[0].feederID === undefined || incomingdata.data[0].feederID === null || incomingdata.data[0].feederID === '')) {

			var feederId = incomingdata.data[0].feederID;
			if (feederId === undefined || feederId === null || feederId === '') {
				session.reject("feederID not found");
			}
			else {
				var feederUrl = omsExternalURL + 'Feeder/' + feederId;
				var feederAPI = {
					target: feederUrl,
					sslClientProfile: 'gfal_OMS_SSL_ClientProfile',
					method: 'GET',
					contentType: 'application/json',
					headers: {
						'osiApiToken': apiToken
					}
				};
				var info = " TargetURL :" + feederAPI.target + "; Method :" + feederAPI.method + "; Data :" + JSON.stringify(feederAPI.data) + ". ";

				urlopen.open(feederAPI, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error with feederAPI details are : " + info + "; error info :" + error
						logger.error("urlopen connect error with feederAPI" + JSON.stringify(error));
						ilsctx.setVariable("exitStatus", "500");
						ilsctx.setVariable("ExitDescription", errorinfo);
						//session.reject(errorinfo);
						//throw error;
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = " error in reading response from 'feederAPI' details are : " + info + "; error info :" + error
									//dp:reject stop the transaction and go error rule with error code and description
									logger.error("failure in putting message to feederapi" + JSON.stringify(error));
									ilsctx.setVariable("exitStatus", responseStatusCode);
									ilsctx.setVariable("ExitDescription", errorinfo);
									//session.reject(errorinfo);
								} else {
									ilsctx.setVariable("exitStatus", "0");
									ilsctx.setVariable("ExitDescription", ExitDescription);
									//store status code with response body in context variable
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from feederapi :" + feederId + "" + responseStatusCode);
									//var ilsctx = session.name("groundfaultReport") || session.createContext("groundfaultReport");
									var feederResp = JSON.parse(responseData);
									var externlID = JSON.parse(responseData).externalID;
									ilsctx.setVariable("feederResponse", feederResp);
									ilsctx.setVariable("externlID", externlID);
									ilsctx.setVariable("CircuitDisplayID", externlID);
								}
							});

						} else {
							//start 

							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Error returned from 'Jobfeeder' details are : " + info + "; error info :" + responseStatusCode + error
									logger.error("Error returned from Jobfeeder with statusCode " + " " + responseStatusCode);
									ilsctx.setVariable("exitStatus", responseStatusCode);
									ilsctx.setVariable("ExitDescription", errorinfo);
									//session.reject(errorinfo);
								} else {
									var errorinfo = "Error returned from 'Jobfeeder' details are : " + info + "; error info :" + responseStatusCode + JSON.stringify(responseData)
									logger.error("Error returned from Jobfeeder with statusCode " + " " + responseStatusCode);
									ilsctx.setVariable("exitStatus", responseStatusCode);
									ilsctx.setVariable("ExitDescription", errorinfo);
									//session.reject(errorinfo);
								}
							});
							//end 
						}
					}
				});

			}
		}
	}
});
