var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category' : 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var ctx = session.name("groundfaultReport")|| session.createContext("groundfaultReport");
		var gfalReadMqUrl = session.parameters.gfalReadMqUrl;
		var omsExternalURL = session.parameters.omsExternalURL;
		var apiToken = session.parameters.osiApiToken;
		var lookupURL =session.parameters.lookupURL;
		var nullCheckRequired = session.parameters.nullCheckRequired;
		var displayID =incomingdata.data[0].displayID;
		var jobTypeID = incomingdata.data[0].jobTypeID;
		//var Status = incomingdata.data[0].status;
		 var feederId = incomingdata.data[0].feederID;
		 var leadCallID = incomingdata.data[0].leadCallID;
		 var Status = incomingdata.data[0].status;
		var id = incomingdata.data[0].id;
		var input = incomingdata;
		
		if(leadCallID === undefined || leadCallID === null ||leadCallID === '' ){
			  session.reject("leadCallID not found");
          }
			else{
				ctx.setVariable("leadCallID", leadCallID);
			}
		
		 if(displayID === undefined || displayID === null ||displayID === '' ){
			  session.reject("displayID not found");
           }
			else{
				ctx.setVariable("displayID",displayID);
			}
		 
		 if(id === undefined || id === null ||id === '' ){
			  session.reject("JobId not found");
           }
			else{
				ctx.setVariable("id",id);
			}
			
		 if(feederId === undefined || feederId === null ||feederId === '' ){
			  session.reject("feederID not found");
           }
			else{
				ctx.setVariable("feederId", feederId);
			}
			
		 if(jobTypeID === undefined || jobTypeID === null ||jobTypeID === '' ){
			  session.reject("jobTypeID not found");
           }
			else{
				ctx.setVariable("jobTypeID", jobTypeID);
			}	
		  if(Status === undefined || Status === null ||Status === '' ){
			  session.reject("Status not found");
           }
			else{
				ctx.setVariable("Status", Status);
			}	
		 
		 if ((leadCallID == undefined && displayID == undefined) || (id == undefined && displayID == undefined) || (leadCallID == undefined && id == undefined)) {
             session.reject('some required fields are missing');
             logger.error("some required fields are not found.");
         }
		 
		ctx.setVariable("omsExternalURL", omsExternalURL);
		ctx.setVariable("apiToken", apiToken);
		ctx.setVariable("gfalReadMqUrl", gfalReadMqUrl);
		ctx.setVariable("lookupURL",lookupURL);
		ctx.setVariable("nullCheckRequired",nullCheckRequired);
		//ctx.setVariable("feederId", feederId);
		//ctx.setVariable("jobTypeID", jobTypeID);
		ctx.setVariable("incomingdata", input);
		//ctx.setVariable("Status", Status);
		
		var payload={
				 "__DecisionID__": displayID
		              }
		
				session.output.write(payload);
				ctx.setVariable("omsPayload", payload);	
	}
});
