

<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	
	<xsl:output method="text" omit-xml-declaration="yes"/>
	
	<xsl:template match="/">
	
	<xsl:variable name="PayLoad">
	
	<xsl:variable name="jobType" select="/*[local-name()='object']/*[local-name()='object']/*[local-name()='array'][@name='callCode']/*[local-name()='string']"/>
	
		<soapenv:Envelope xmlns:typ="http://www.ibm.com/wbe/casoap/types" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xs="http://www.w3.org/2001/XMLSchema">
	       <soapenv:Header/>
		     <soapenv:Body>
		        <typ:ODMRestorationStatus>
		            <RestorationStatus>
		            	<CorrelationID>
							<xsl:value-of select="dp:generate-uuid()" />
						</CorrelationID>
						<xsl:variable name="date" select="date:date-time()"/>
						<xsl:message dp:priority="debug">Time format++++:<xsl:value-of select="$date"/></xsl:message>
						<xsl:variable name="year" select="substring($date,1,4)"/>
						<xsl:variable name="month" select="substring($date,6,2)"/>
						<xsl:variable name="day" select="substring($date,9,2)"/>
						<xsl:variable name="hour" select="substring($date,12,2)"/>
						<xsl:variable name="minute" select="substring($date,15,2)"/>
						<xsl:variable name="second" select="substring($date,18,2)"/>
						<xsl:variable name="dateTime" select="concat($year,'-',$month,'-',$day,'T',$hour,':', $minute,':',$second,'Z')"/>
						<xsl:message dp:priority="debug">final timestamp+++<xsl:value-of select="$final"/></xsl:message>
						
						<dp:set-variable name="'var://context/groundFaultReport/timeStamp'" value="$dateTime"></dp:set-variable>
						
						<xsl:variable name="createdAt" select="dp:variable('var://context/groundfaultReport/createdAt')"/>
						<Timestamp>
							<xsl:choose>
								<xsl:when test ="string-length($createdAt) &gt; 0">
									<xsl:value-of select="$createdAt" />
						        </xsl:when>	
							</xsl:choose>
						</Timestamp>
						
						<JobID>
							<xsl:choose>
								<xsl:when test ="string-length(dp:variable('var://context/groundfaultReport/displayID')) &gt; 0">
									<xsl:value-of select="dp:variable('var://context/groundfaultReport/displayID')" />
						        </xsl:when>	
								<xsl:otherwise>
									<dp:reject>JobID not found</dp:reject>
								</xsl:otherwise>
							</xsl:choose>
						</JobID>
						<TroubleCode>
						
						<xsl:choose>
							<xsl:when test ="string-length(dp:variable('var://context/groundfaultReport/externalIDfromCallAPI')) &gt; 0">
									<xsl:value-of select="dp:variable('var://context/groundfaultReport/externalIDfromCallAPI')" />
						        </xsl:when>
							<xsl:otherwise>
								<dp:reject>torublecode Id not found</dp:reject>
							</xsl:otherwise>
							</xsl:choose>
						</TroubleCode>
						<Circuit>
							<xsl:choose>
								<xsl:when test ="string-length(dp:variable('var://context/groundfaultReport/externlID')) &gt; 0">
									<xsl:value-of select="dp:variable('var://context/groundfaultReport/externlID')" />
						        </xsl:when>	
								<xsl:otherwise>
									<dp:reject>Circuit Id not found</dp:reject>
								</xsl:otherwise>
							</xsl:choose>
						</Circuit>
											
						<RestorationStatusPayload>
							<xsl:choose>
								<xsl:when test ="string-length(dp:variable('var://context/groundfaultReport/convertbase64')) &gt; 0">
									<xsl:value-of select="dp:variable('var://context/groundfaultReport/convertbase64')" />
						        </xsl:when>	
								<xsl:otherwise>
									<dp:reject>Unable to Encode the Payload</dp:reject>
								</xsl:otherwise>
							</xsl:choose>
						</RestorationStatusPayload> 
					</RestorationStatus>
				</typ:ODMRestorationStatus>
			</soapenv:Body>
	       </soapenv:Envelope>
	    </xsl:variable>
	    
	    <dp:set-variable name="'var://context/groundfaultReport/PayLoad'" value="$PayLoad" />
	</xsl:template>	
</xsl:stylesheet>
