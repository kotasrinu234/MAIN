<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:dp="http://www.datapower.com/extensions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:regexp="http://exslt.org/regular-expressions" extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp" version="1.0">
	<xsl:template match="/">
                <dp:set-variable name="'var://context/ServiceLog/CorrelationId'" value="''" />
                <dp:set-variable name="'var://context/ServiceLog/MessageId'" value="''" /> 
                <dp:set-variable name="'var://context/ServiceLog/LogMsgTimestamp'" value="''" /> 
                <dp:set-variable name="'var://context/ServiceLog/Type'" value="''" /> 
                <dp:set-variable name="'var://context/ServiceLog/Application'" value="'GorundFaultAlaram'" /> 
                <dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')" /> 
                <dp:set-variable name="'var://context/ServiceLog/System'" value="'DataPower'" /> 
                <dp:set-variable name="'var://context/ServiceLog/User'" value="''" /> 
                <dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="''" /> 
                <dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="''" />  	
                <dp:set-variable name="'var://context/ServiceLog/ContextElement3'" value="''" /> 
                <dp:set-variable name="'var://context/ServiceLog/ContextElement4'" value="''" /> 
                <dp:set-variable name="'var://context/ServiceLog/ContextElement5'" value="''" />
	</xsl:template>
</xsl:stylesheet>