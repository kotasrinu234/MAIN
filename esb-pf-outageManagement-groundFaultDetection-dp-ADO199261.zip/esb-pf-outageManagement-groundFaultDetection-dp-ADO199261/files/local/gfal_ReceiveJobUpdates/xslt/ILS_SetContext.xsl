<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpquery="http://www.datapower.com/param/query"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:regexp="http://exslt.org/regular-expressions"
	extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ser="http://dteco.com/DeviceManagement/ServiceOrder"
	version="1.0">
	
	<xsl:variable name="Delimiter" select="'_'" />
	
	<xsl:template match="/*[local-name()='object']/*[local-name()='array'][@name='data']">
	
		<xsl:variable name="Input">
			<xsl:copy-of select="dp:variable('var://context/dpvar6')" />
		</xsl:variable>
		
		<xsl:variable name="TransactoinID">
			<xsl:copy-of select="dp:variable('var://service/global-transaction-id')" />
		</xsl:variable>

		
		<xsl:variable name="jobID" select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='displayID']/text()" />

		<xsl:variable name="TimeStamp" select="date:date-time()"/>
		
        <xsl:choose>
			<xsl:when test ="string-length($jobID) &gt; 0">
				<xsl:value-of select="$jobID" />
	        </xsl:when>	
			<xsl:otherwise>
				<dp:reject>jobID not found</dp:reject>
			</xsl:otherwise>
		</xsl:choose>	
         
        <dp:set-variable name="'var://context/groundfaultReport/jobID'" value="string($jobID)" />

		<!-- custom logging -->
		<xsl:message dp:type="all" dp:priority="debug">
		GroundFaultAlert_ReceiveJobUpdates REQUEST: <xsl:value-of select="concat('TimeStamp:',$TimeStamp, 'jobID:',$jobID)" />
		</xsl:message>

		<xsl:call-template name="set_ILS_Context">
			<xsl:with-param name="jobID" select="$jobID" />
			<xsl:with-param name="TimeStamp" select="$TimeStamp" />
		</xsl:call-template>
		
	</xsl:template>

	<xsl:template name="set_ILS_Context">
		<xsl:param name="jobID" />
		<xsl:param name="TimeStamp" />

		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()" />
		<dp:set-variable name="'var://context/TimeStamp'" value="$TimeStamp" />
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'RECEIVED'" />
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'GroundFaultAlert_ReceiveJobUpdates'" />
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')" />
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))" />
		<dp:set-variable name="'var://context/ServiceLog/User'" value="' '" />
		 <dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="string($jobID)" />
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="''" />
		<dp:set-variable name="'var://context/ServiceLog/ContextElement3'" value="''" /> -->
		<dp:set-variable name="'var://context/ServiceLog/ContextElement4'" value="''" />
		<!-- <dp:set-variable name="'var://context/ServiceLog/ContextElement5'" 
			value="concat('TransactionId:',string(dp:variable('var://service/global-transaction-id')))"/> -->
	</xsl:template>
	
</xsl:stylesheet>