<!--
    This is the XSLT that generates all events for a succesful transaction
-->
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:dp="http://www.datapower.com/extensions"
    xmlns:dpconfig="http://www.datapower.com/param/config"
    xmlns:regexp="http://exslt.org/regular-expressions" 
    xmlns:com="http://comesb.pro.com"
    extension-element-prefixes="dp com regexp"
    exclude-result-prefixes="dp dpconfig"
>

  <xsl:output method="xml"/>

  <xsl:import href="com_UtilityFunctions.xsl"/>
  <!-- Initialize parameter for disable logging -->
  <xsl:param name="dpconfig:disableLog" select="''"/>    
  
  <!-- Get the value-of stylesheet parameter -->
  <xsl:variable name="disableLog" select="$dpconfig:disableLog"/> 
 
 <xsl:template match="/">

 <!-- for some reason dp:responding/dp:accepting is not working... Hence adding a check here for rule type -->
    <xsl:variable name="ruleType"><xsl:value-of select="dp:variable('var://service/transaction-rule-type')"/></xsl:variable>
<dp:set-variable name="'var://context/esb/destURL'" value="dp:variable('var://service/routing-url')"/>
    <xsl:if test="$ruleType = 'request'">
         <xsl:variable name="requestInTime"><xsl:value-of select="com:getRequestInTime()"/></xsl:variable>
         <xsl:variable name="requestInEvent">
             <xsl:value-of select="$requestInTime"/>|0|0|Success|<xsl:value-of select="com:getRequestDetails()"/>
         </xsl:variable>
		 <xsl:message dp:type="all" dp:priority="info">####<xsl:value-of select="$requestInEvent"/>####<xsl:value-of select="$disableLog"/>#### </xsl:message>
		 <xsl:variable name="ignore"><xsl:value-of select="com:genComEvent($requestInEvent,$disableLog)"/></xsl:variable>
        
        <dp:set-variable name="'var://context/esb/logstage'" value="'1'"/>

     </xsl:if>
	 
      <xsl:if test="$ruleType = 'response'">
        <xsl:variable name="requestOutTime"><xsl:value-of select="com:getRequestOutTime()"/></xsl:variable>
        <xsl:variable name="requestOutSize"><xsl:value-of select="dp:variable('var://service/mpgw/request-size')"/></xsl:variable>
  
         <!-- Request out log -->
         <xsl:variable name="requestOutComEvent"> 
             <xsl:value-of select="$requestOutTime"/>|0|1|Success|<xsl:value-of select="$requestOutSize"/>
         </xsl:variable>
         <xsl:variable name="ignore"><xsl:value-of select="com:genComEvent($requestOutComEvent, $disableLog)"/></xsl:variable>
<xsl:message dp:type="all" dp:priority="info">####<xsl:value-of select="$requestOutComEvent"/>####</xsl:message>

         <!-- Response in log -->
         <xsl:variable name="responseInComEvent"> 
                <xsl:variable name="responseSize"><xsl:value-of select="dp:variable('var://service/mpgw/response-size')"/></xsl:variable>
                <xsl:value-of select="dp:time-value()"/>|1|0|Success|<xsl:value-of select="$responseSize"/>
         </xsl:variable>
         <xsl:variable name="ignore"><xsl:value-of select="com:genComEvent($responseInComEvent, $disableLog)"/></xsl:variable>
<xsl:message dp:type="all" dp:priority="info">####<xsl:value-of select="$responseInComEvent"/>####</xsl:message>

         <!-- This indicates and error while both request in and response out events have been logged -->
         <dp:set-variable name="'var://context/esb/logstage'" value="'2'"/>
      </xsl:if> 

     <xsl:copy-of select="."/>
  </xsl:template>

</xsl:stylesheet>
