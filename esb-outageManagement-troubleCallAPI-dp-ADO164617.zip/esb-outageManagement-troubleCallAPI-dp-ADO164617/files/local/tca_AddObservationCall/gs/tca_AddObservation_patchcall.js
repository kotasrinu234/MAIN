var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var apiToken = session.parameters.apiToken;
var omsExternalURL = '';
var logger = console.options({
	'category': 'all'
});
var reqData = '';
var observations = '';
var ctx = session.name("respdata") || session.createContext("respdata");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ObservationArray = [];
		if (!(incomingdata.Observations === undefined || incomingdata.Observations === '' || incomingdata.Observations === null)) {
			ObservationArray = incomingdata.Observations;
			if (ObservationArray.length > 1) {
				for (var i = 0; i < ObservationArray.length; i++) {
					var Observation = ObservationArray[i];
					if (!(Observation.callID === undefined || Observation.callID === '' || Observation.callID === null)) {
						var CallID = ctx.getVariable("id_" + Observation.callID);
						if (!(CallID == undefined || CallID == '' || CallID == null)) {
							var Obsvt = ctx.getVariable("observations_" + Observation.callID)
							var CallPATCHapi = {
								target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + CallID,
								sslClientProfile: 'tca_AddObservationCall_ClientProfile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								},
								data: Obsvt
							};
							var info = " TargetURL :" + CallPATCHapi.target + "; Method :" + CallPATCHapi.method + "; Data :" + JSON.stringify(CallPATCHapi.data) + ". ";
							var OmsInvoke = OMSPatchCall(CallPATCHapi, Observation, info);
						}
					}

				}
			} else {
				var Observation = ObservationArray[0];
				if (!(Observation.callID === undefined || Observation.callID === '' || Observation.callID === null)) {
					var CallID = ctx.getVariable("id_" + Observation.callID);
					if (!(CallID == undefined || CallID == '' || CallID == null)) {
						var Obsvt = ctx.getVariable("observations_" + Observation.callID)
						session.output.write(Obsvt);
						var CallPATCHapi = {
							target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + CallID,
							sslClientProfile: 'tca_AddObservationCall_ClientProfile',
							method: 'PATCH',
							contentType: 'application/json',
							headers: {
								'osiApiToken': apiToken
							},
							data: Obsvt
						};
						var info = " TargetURL :" + CallPATCHapi.target + "; Method :" + CallPATCHapi.method + "; Data :" + JSON.stringify(CallPATCHapi.data) + ". ";
						try {
							urlopen.open(CallPATCHapi, function(error, response) {
								if (error) {
									var errorinfo = "Error invoking patch call api, details are : " + info + "; error :" + error + response;
									ctx.setVariable("errorResponse", errorinfo);
									ctx.setVariable("errorStatusCode", "500");
									ctx.setVariable("errorreasonPhrase", response.reasonPhrase);
									logger.error("tca_001 urlopen connect error with patch call api" + Observation.callID + JSON.stringify(errorinfo));
									session.reject("Error invoking patch call api" + JSON.stringify(errorinfo));
								} else {
									var responseStatusCode = response.statusCode;
									var responsePhrase = response.reasonPhrase;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												// error while reading response or transferring data to Buffer
												var errorinfo = "failure reading response from patch call api, details are : " + info + "; error :" + error + responseData;
												ctx.setVariable("errorResponse", errorinfo);
												ctx.setVariable("errorStatusCode", responseStatusCode);
												ctx.setVariable("errorreasonPhrase", responsePhrase);
												logger.info("tca_002 failure reading response from call api" + Observation.callID + JSON.stringify(errorinfo));
												session.reject("failure reading response from patch call api" + Observation.callID + JSON.stringify(errorinfo));
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.info("response received from patch call api " + Observation.callID + JSON.stringify(responseData));
											}
										});
									} else if ((responseStatusCode == 401)) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "tca_02 : Unauthorized error message while reading response from patch call api, details are : " + info + "; error info :" + JSON.stringify(error)
												ctx.setVariable("errormessage", errorinfo);
												ctx.setVariable('errorStatusCode', responseStatusCode);
												ctx.setVariable('errorResponse', errorinfo);
												logger.error("tca_02 : error message while reading response from patch call api , details are : " + info + "; error info :" + JSON.stringify(error));
												session.reject("tca_02 : error message while reading response from patch call api , details are : " + info + "; error info :" + JSON.stringify(error));
											} else {
												var errorinfo = "tca_02 : Unauthorized error message while reading response from patch call api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												ctx.setVariable("errormessage", errorinfo);
												ctx.setVariable('errorStatusCode', responseStatusCode);
												ctx.setVariable('errorResponse', errorinfo);
												logger.error("tca_02 : Unauthorized Error returned from patch call api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
												session.reject("tca_02 : Unauthorized Error returned from patch call api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
											}
										});
									} else if ((responseStatusCode == 403)) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "tca_03 :Forbidden error message while reading response from patch call api , details are : " + info + "; error info :" + JSON.stringify(error)
												ctx.setVariable('errorStatusCode', responseStatusCode);
												ctx.setVariable('errorResponse', errorinfo);
												ctx.setVariable("errormessage", errorinfo);
												logger.error("tca_03 :Forbidden error message while reading response from patch call api, details are : " + info + "; error info :" + JSON.stringify(error));
												session.reject("tca_03 :Forbidden error message while reading response from patch call api, details are : " + info + "; error info :" + JSON.stringify(error));
											} else {
												var errorinfo = "tca_03 :Forbidden error message while reading response from patch call api, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												ctx.setVariable("errormessage", errorinfo);
												ctx.setVariable('errorStatusCode', responseStatusCode);
												ctx.setVariable('errorResponse', errorinfo);
												logger.error("tca_03 :Forbidden error returned from patch call api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
												session.reject("tca_03 :Forbidden error returned from patch call api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
											}
										});
									}
									else {
										response.readAsBuffer(function(error, ErrorresponseData) {
											if (error) {
												// error while reading response or transferring data to Buffer
												var errorinfo = "failure reading response from patch call api, details are : " + info + "; error :" + error + ErrorresponseData;
												ctx.setVariable("errorResponse", errorinfo);
												ctx.setVariable("errorStatusCode", responseStatusCode);
												ctx.setVariable("errorreasonPhrase", responsePhrase);
												logger.info("failure reading response from call api" + Observation.callID + JSON.stringify(errorinfo));
												session.reject("failure reading response from patch call api" + JSON.stringify(errorinfo));
											} else {
												var errorinfo = "Error response code from patch call api, details are : " + info + "; error :" + error + ErrorresponseData;
												ctx.setVariable("errorResponse", errorinfo);
												ctx.setVariable('errorStatusCode', responseStatusCode);
												ctx.setVariable('errorreasonPhrase', responsePhrase);
												logger.error("tca_003 Error Response code from patch call api" + " " + Observation.callID + errorinfo + " Status code is " + responseStatusCode + " and the reason is " + JSON.stringify(ErrorresponseData));
												session.reject("Error response code from patch call api" + " " + responseStatusCode + " " + errorinfo);
											}
										});
									}
								}
							});
						} catch (err) {
							var errorinfo = "Error invoking patch call api, details are : " + info + "; error :" + err;
							ctx.setVariable("errorStatusCode", "500");
							ctx.setVariable("errorResponse", errorinfo);
							logger.error("tca_001 urlopen connect error with patch call api" + Observation.callID + JSON.stringify(errorinfo));
							session.reject("Error invoking patch call api" + JSON.stringify(errorinfo));
						}
					}
				}
			}
		}
	}
});
function OMSPatchCall(CallPATCHapi, Observation, info) {
	try {
		urlopen.open(CallPATCHapi, function(error, response) {
			if (error) {
				var errorinfo = "urlopen connect error with patch call api, details are : " + info + "; error info :" + error + response;
				ctx.setVariable("errorResponse", errorinfo);
				ctx.setVariable("errorStatusCode", response.statusCode);
				ctx.setVariable("errorreasonPhrase", response.reasonPhrase);
				logger.error("tca_001 urlopen connect error with patch call api" + Observation.callID + JSON.stringify(errorinfo));
				//session.reject("Error invoking patch call api");
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "failure reading response from call api, details are : " + info + "; error :" + error + responseData;
							ctx.setVariable("errorResponse", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorreasonPhrase", responsePhrase);
							logger.info("tca_002 failure reading response from call api" + Observation.callID + JSON.stringify(errorinfo));
							//session.reject("failure reading response from call api");
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.info("response received from patch call api " + Observation.callID + JSON.stringify(responseData));
						}

					});
				} else if ((responseStatusCode == 401)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "tca_04 : Unauthorized error message while reading response from OMSPatchCall api, details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable("errormessage", errorinfo);
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_04 : error message while reading response from OMSPatchCall api , details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("tca_04 : error message while reading response from OMSPatchCall api , details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "tca_04 : Unauthorized error message while reading response from OMSPatchCall api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable("errormessage", errorinfo);
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_04 : Unauthorized Error returned from OMSPatchCall api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
							session.reject("tca_04 : Unauthorized Error returned from OMSPatchCall api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				} else if ((responseStatusCode == 403)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "tca_05 :Forbidden error message while reading response from OMSPatchCall api , details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							ctx.setVariable("errormessage", errorinfo);
							logger.error("tca_05 :Forbidden error message while reading response from OMSPatchCall api, details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("tca_05 :Forbidden error message while reading response from OMSPatchCall api, details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "tca_05 :Forbidden error message while reading response from OMSPatchCall api, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable("errormessage", errorinfo);
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_05 :Forbidden error returned from OMSPatchCall api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
							session.reject("tca_05 :Forbidden error returned from OMSPatchCall api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				}
				else {
					response.readAsBuffer(function(error, ErrorresponseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "failure reading response from patch call api, details are : " + info + "; error :" + error + ErrorresponseData;
							ctx.setVariable("errorResponse", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorreasonPhrase", responsePhrase);
							logger.info("failure reading response from call api" + Observation.callID + JSON.stringify(errorinfo));
							//session.reject("failure reading response from patch call api");
						} else {
							//hm.response.statusCode = response.statusCode;
							var errorinfo = "Error invoking patch call api, details are : " + info + "; error :" + error + ErrorresponseData;
							ctx.setVariable("errorResponse", errorinfo);
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorreasonPhrase', responsePhrase);
							logger.error("tca_003 Error Response code from patch call api" + Observation.callID + " Status code is " + responseStatusCode + " and the reason is " + JSON.stringify(ErrorresponseData));
							//session.reject("Error invoking patch call api");
						}
					});
				}
			}
		});
	} catch (err) {
		var errorinfo = "urlopen connect error with patch call api, details are : " + info + "; error :" + err;
		ctx.setVariable("errorResponse", errorinfo);
		ctx.setVariable("errorStatusCode", "500");
		logger.error("tca_001 urlopen connect error with patch call api" + Observation.callID + JSON.stringify(err));
	}
}
