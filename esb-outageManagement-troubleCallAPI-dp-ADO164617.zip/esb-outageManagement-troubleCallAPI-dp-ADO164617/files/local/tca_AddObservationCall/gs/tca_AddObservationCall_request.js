var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var apiToken = session.parameters.apiToken;
var omsExternalURL = '';
var logger = console.options({
	'category': 'all'
});
var reqData = '';
var observations = '';
var ctx = session.name("respdata") || session.createContext("respdata");

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var ObservationArray = [];
		if (!(incomingdata.Observations === undefined || incomingdata.Observations === '' || incomingdata.Observations === null)) {
			ObservationArray = incomingdata.Observations;
			if (ObservationArray.length > 1) {
				for (var i = 0; i < ObservationArray.length; i++) {
					var Observation = ObservationArray[i];
					if (!(Observation.callID === undefined || Observation.callID === '' || Observation.callID === null)) {
						if (!(Observation.observations === undefined || Observation.observations === '' || Observation.observations === null)) {
							reqData = '["' + Observation.callID + '"]';
							observations = JSON.parse(JSON.stringify('{"observations" :[' + Observation.observations + ']}'));
							logger.info("observations for " + Observation.callID + observations);
							OMSCallQueryresponse(reqData, Observation, observations);
						} else {
							reqData = '["' + Observation.callID + '"]';
							observations = JSON.parse(JSON.stringify('{"observations" :[' + ']}'));
							logger.info("observations for " + Observation.callID + observations);
							OMSCallQueryresponse(reqData, Observation, observations);
						}
					} else {
						logger.error("tca_008 callID is not defined in input payload at " + JSON.stringify(Observation));
					}
				}
			} else {
				var Observation = ObservationArray[0];
				if (!(Observation.callID === undefined || Observation.callID === '' || Observation.callID === null)) {
					if (!(Observation.observations === undefined || Observation.observations === '' || Observation.observations === null)) {
						reqData = '["' + Observation.callID + '"]';
						observations = JSON.parse(JSON.stringify('{"observations" :[' + Observation.observations + ']}'));
						logger.info("observations for " + Observation.callID + observations);
						OMSCallQueryresp(reqData, Observation, observations);
					} else {
						reqData = '["' + Observation.callID + '"]';
						observations = JSON.parse(JSON.stringify('{"observations" :[' + ']}'));
						logger.info("observations for " + Observation.callID + observations);
						OMSCallQueryresp(reqData, Observation, observations);
					}
				} else {
					ctx.setVariable("errorStatusCode", '400');
					logger.error("tca_008 callID is not defined in input payload at " + JSON.stringify(Observation));
					session.reject("Bad Request");
				}
			}
		} else {
			ctx.setVariable("errorStatusCode", '400');
			logger.error("tca_009 Observations is not defined in input payload");
			session.reject("Observations is not defined in input payload");
		}
	}
});

function OMSCallQueryresponse(reqData, Observation, observations) {
	var ctx = session.name("respdata") || session.createContext("respdata");
	var apiToken = session.parameters.apiToken;
	var options = {
		target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/Query?isInternalIDs=false&historical=false',
		sslClientProfile: 'tca_AddObservationCall_ClientProfile',
		method: 'post',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: reqData
	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; CallID :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {

			if (error) {
				var errorinfo = "url connection error 'OMSCallQueryresponse', details are : " + info + "; error :" + error + response;
				ctx.setVariable("errorResponse", errorinfo);
				ctx.setVariable("errorStatusCode", "500");
				ctx.setVariable("errorreasonPhrase", response.reasonPhrase);
				logger.error("tca_004 urlopen connect error with OMS call queryAPI call " + JSON.stringify(error));
				//session.reject("urlopen connect error with OMS call query API call " + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				logger.error(response);
				logger.error(response.statusCode);
				if (response.body) {
					if (response.body.hexbin) {
						var hexbin = response.body.hexbin;
						ctx.setVariable("hexbin", hexbin);
					}
				}
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "failure reading response from call query api, details are : " + info + "; error :" + error + responseData;
							ctx.setVariable("errorResponse", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorreasonPhrase", responsePhrase);
							logger.info("tca_005 failure reading response from call query api" + Observation.callID + JSON.stringify(errorinfo));
							//session.reject("failure reading response from call query api");
						} else {
							if (!(responseData[0] == undefined || responseData[0] == '' || responseData[0] == null)) {
								ctx.setVariable("callQueryResponseData" + Observation.callID, responseData);
								ctx.setVariable("observations_" + Observation.callID, observations);
								ctx.setVariable("id_" + Observation.callID, responseData[0].id);
							} else if (responseData[0] === undefined || responseData[0] === '' || responseData[0] === null) {
								var errorinfo = "Response is empty, details are : " + info + "; error :" + error + responseData;
								ctx.setVariable("errorResponse", errorinfo);
								ctx.setVariable("errorStatusCode", "5b5d");
								logger.error("Response is empty" + " " + Observation.callID + " " + JSON.stringify(errorinfo));
								session.reject("Response is empty, details are : " + info + "; error :" + error + responseData);
							}
							else {
								response.readAsBuffer(function(error, ErrorresponseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										var errorinfo = "failure reading response from call query api, details are : " + info + "; error :" + error + ErrorresponseData;
										ctx.setVariable("errorResponse", errorinfo);
										ctx.setVariable("errorStatusCode", responseStatusCode);
										ctx.setVariable("errorreasonPhrase", responsePhrase);
										logger.error("failure reading response from call query api" + " " + Observation.callID + " " + JSON.stringify(errorinfo));
										//session.reject("failure reading response from call query api");
									} else {
										var errorinfo = "invalid response for call id, details are : " + info + "; error :" + error + ErrorresponseData;
										ctx.setVariable("errorResponse", errorinfo);
										ctx.setVariable('errorStatusCode', responseStatusCode);
										ctx.setVariable('errorreasonPhrase', responsePhrase);
										logger.error("tca_010 invalid response for call id " + Observation.callID + errorinfo + " Status code is " + responseStatusCode + " and the response is " + ErrorresponseData);
									}
								});
							}
						}
					});
				} else if ((responseStatusCode == 401)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "tca_06 : Unauthorized error message while reading response from post call query api, details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_06 : error message while reading response from post call query api , details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("tca_06 : error message while reading response from post call query api , details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "tca_06 : Unauthorized error message while reading response from post call query api, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_06 : Unauthorized Error returned from post call query api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
							session.reject("tca_06 : Unauthorized Error returned from post call query api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				} else if ((responseStatusCode == 403)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "tca_07 :Forbidden error message while reading response from post call query api , details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_07 :Forbidden error message while reading response from post call query api, details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("tca_07 :Forbidden error message while reading response from post call query api, details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "tca_07 :Forbidden error message while reading response from post call query api, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_07 :Forbidden error returned from post call query api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
							session.reject("tca_07 :Forbidden error returned from post call query api , details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				}
				else {
					response.readAsBuffer(function(error, ErrorresponseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "failure reading response from call query api, details are : " + info + "; error :" + error + ErrorresponseData;
							ctx.setVariable("errorResponse", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorreasonPhrase", responsePhrase);
							logger.error("failure reading response from call query api" + " " + Observation.callID + " " + JSON.stringify(errorinfo));
							//session.reject("failure reading response from call query api");
						} else {
							//hm.response.statusCode = response.statusCode;
							var errorinfo = "url connection error 'OMSCallQueryresponse', details are : " + info + "; error :" + error + ErrorresponseData;
							ctx.setVariable("errorResponse", errorinfo);
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorreasonPhrase', responsePhrase);
							logger.error("tca_006 Error response code  from call query api" + Observation.callID + " Status code is " + responseStatusCode + " and the reason is " + ErrorresponseData + errorinfo);
							//session.reject("Error invoking call query api");
						}
					});
				}
			}
		});
	} catch (err) {
		var errorinfo = "urlopen connect error with OMS call queryAPI call, details are : " + info + "; error info :" + err;
		ctx.setVariable("errorResponse", errorinfo);
		ctx.setVariable("errorStatusCode", "500");
		logger.error("tca_004 urlopen connect error with OMS call queryAPI call " + JSON.stringify(errorinfo));
	}
}

function OMSCallQueryresp(reqData, Observation, observations) {
	var ctx = session.name("respdata") || session.createContext("respdata");
	var apiToken = session.parameters.apiToken;
	var options = {
		target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/Query?isInternalIDs=false&historical=false',
		sslClientProfile: 'tca_AddObservationCall_ClientProfile',
		method: 'post',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		},
		data: reqData
	};
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; CallID :" + JSON.stringify(options.data) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				var errorinfo = "tca_004 urlopen connect error with OMS call query API call, details are : " + info + "; error :" + JSON.stringify(error);
				ctx.setVariable("errorResponse", errorinfo);
				ctx.setVariable("errorStatusCode", "500");
				//ctx.setVariable("errorreasonPhrase", response.reasonPhrase);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {

				var responseStatusCode = response.statusCode;
				var responsePhrase = response.reasonPhrase;
				if (response.body) {
					if (response.body.hexbin) {
						var hexbin = response.body.hexbin;
						ctx.setVariable("hexbin", hexbin);
					}
				}

				if (responseStatusCode == 200) {

					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "tca_005: failure reading response from call query api, details are : " + info + "; error :" + JSON.stringify(error);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorreasonPhrase", responsePhrase);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							if (!(responseData[0] == undefined || responseData[0] == '' || responseData[0] == null)) {
								ctx.setVariable("callQueryResponseData" + Observation.callID, responseData);
								ctx.setVariable("observations_" + Observation.callID, observations);
								ctx.setVariable("id_" + Observation.callID, responseData[0].id);
							} else if (responseData[0] == undefined || responseData[0] == '' || responseData[0] == null) {
								var errorinfo = "Response is empty, details are : " + info + "; error info :" + error + responseData;
								ctx.setVariable("errorResponse", errorinfo);
								ctx.setVariable("errorStatusCode", "5b5d");
								ctx.setVariable("errorreasonPhrase", errorinfo);
								logger.error("Response is empty" + " " + Observation.callID + " " + JSON.stringify(errorinfo));
								session.reject("Response is empty" + " " + Observation.callID + " " + JSON.stringify(errorinfo));
							}
							else {
								response.readAsBuffer(function(error, ErrorresponseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										var errorinfo = "failure reading response from call query api, details are : " + info + "; error :" + JSON.stringify(error);
										ctx.setVariable("errorResponse", errorinfo);
										ctx.setVariable("errorStatusCode", responseStatusCode);
										ctx.setVariable("errorreasonPhrase", responsePhrase);
										logger.error("failure reading response from call query api" + " " + Observation.callID + " " + JSON.stringify(errorinfo));
										session.reject("failure reading response from call query api" + + JSON.stringify(errorinfo));
									} else {
										var errorinfo = "Invalid response from call query api, details are : " + info + "; error :" + ErrorresponseData;
										ctx.setVariable("errorResponse", errorinfo);
										ctx.setVariable('errorStatusCode', responseStatusCode);
										ctx.setVariable('errorreasonPhrase', responsePhrase);
										logger.error("tca_010 invalid response for call id " + Observation.callID + " Status code is  " + responseStatusCode + " and the response is " + errorinfo);
										session.reject("Invalid response from call query api" + errorinfo);
									}
								});
							}
						}
					});
				} else if ((responseStatusCode == 401)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "tca_08 : Unauthorized error message while reading response from OMS postcall query API, details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_08 : error message while reading response from OMS postcall query API, details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("tca_08 : error message while reading response from OMS postcall query API, details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "tca_08 : Unauthorized error message while reading response from OMS postcall query API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_08 : Unauthorized Error returned from OMS postcall query API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
							session.reject("tca_08 : Unauthorized Error returned from OMS postcall query API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				} else if ((responseStatusCode == 403)) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "tca_09 :Forbidden error message while reading response from OMS postcall query API, details are : " + info + "; error info :" + JSON.stringify(error)
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_09 :Forbidden error message while reading response from OMS postcall query API, details are : " + info + "; error info :" + JSON.stringify(error));
							session.reject("tca_09 :Forbidden error message while reading response from OMS postcall query API, details are : " + info + "; error info :" + JSON.stringify(error));
						} else {
							var errorinfo = "tca_09 :Forbidden error message while reading response from OMS postcall query API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorResponse', errorinfo);
							logger.error("tca_09 :Forbidden error returned from OMS postcall query API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode)
							session.reject("tca_09 :Forbidden error returned from OMS postcall query API, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
						}
					});
				}
				else {
					response.readAsBuffer(function(error, ErrorresponseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "failure reading response from call query api, details are : " + info + "; error :" + error + ErrorresponseData;
							ctx.setVariable("errorResponse", errorinfo);
							ctx.setVariable("errorStatusCode", responseStatusCode);
							ctx.setVariable("errorreasonPhrase", responsePhrase);
							logger.error("failure reading response from call query api" + " " + Observation.callID + " " + JSON.stringify(errorinfo));
							session.reject("failure reading response from call query api" + JSON.stringify(errorinfo));
						} else {
							var errorinfo = "Error response code  from call query api, details are : " + info + "; error :" + error + ErrorresponseData;
							ctx.setVariable("errorResponse", errorinfo);
							ctx.setVariable('errorStatusCode', responseStatusCode);
							ctx.setVariable('errorreasonPhrase', responsePhrase);
							logger.error("tca_006 Error response code  from call query api" + " " + Observation.callID + " Status code is " + responseStatusCode + " and the reason is " + errorinfo);
							session.reject("Error invoking call query api" + " " + responseStatusCode + " and the reason is " + errorinfo);
						}

					});
				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error 'OMSCallQueryresp', details are : " + info + "; error :" + err;
		ctx.setVariable("errorResponse", errorinfo);
		ctx.setVariable("errorStatusCode", "500");
		logger.error("tca_004 urlopen connect error with OMS call queryAPI call " + JSON.stringify(errorinfo));
		session.reject("urlopen connect error with OMS call query API call " + JSON.stringify(errorinfo));
	}
}
