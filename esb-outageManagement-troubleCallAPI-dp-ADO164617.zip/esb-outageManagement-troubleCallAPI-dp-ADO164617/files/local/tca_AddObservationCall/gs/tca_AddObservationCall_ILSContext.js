var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
'category': 'all'
});
var ctx = session.name('ILSEntry') || session.createContext('ILSEntry');
var entryDescription = session.parameters.entrydescription;
var exitDescription = session.parameters.exitdescription;

var destination = session.parameters.omsExternalURL; 
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var messageType = session.parameters.messageType
ctx.setVariable("messageType",messageType)
ctx.setVariable('entryDescription',entryDescription);
ctx.setVariable('exitDescription',exitDescription);
ctx.setVariable('exitDestination',destination);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
if (readAsJSONError) {
	logger.error("Error in reading incoming data");
	session.reject(readAsJSONError);
} else {
var id = uuidv4()
ctx.setVariable("correlationID",id)
if(incomingdata.Observations[0].callID !== undefined || incomingdata.Observations[0].callID !==null || incomingdata.Observations[0].callID !== ''){
ctx.setVariable("callDisplayID",incomingdata.Observations[0].callID)}
ctx.setVariable("sourceEventTimestamp",incomingdata.Observations[0].timeStamp)

}
});
