/* This gateway script is used for error handling. 
Date :27-11-2020
Author :Bhulakshmi Ardalapudi */
var ctx = session.name("respdata") || session.createContext("respdata");
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var responseStatusCode = ctx.getVariable("errorStatusCode");
var responsePhrase = ctx.getVariable("errorreasonPhrase");
var errorSubcode = sm.getVar('var://service/error-subcode');
var errorCode = sm.getVar('var://service/error-code')
var errorDescription = ctx.getVariable("errorDescription")
var obj = {};
var errorMessage = sm.getVar('var://service/error-message')
var errorcodeResponse = {};
var errorResponse = {};
var WSM = session.name('WSM') || session.createContext('WSM');
var username = WSM.getVar('identity/username');
if (!(responseStatusCode === undefined) || !(responsePhrase === undefined)) {
	obj.errorCode = responseStatusCode + " " + responsePhrase;
	errorResponse.errorCode = responseStatusCode + " " + responsePhrase;
} else {
	if (errorMessage === "Rejected by policy.") {
		var errorinfo = `tca_01 : AAA failure for CR&B with, Username: ${username}, Errorstring: ${errorCode}, errorMessage: ${errorMessage}`;
		ctx.setVariable("errorStatusCode", '401')
		logger.error(errorinfo);
	}
	else if (errorCode === '0x00d30003' && errorSubcode === '0x01d30002') {
		hm.current.statusCode = '401';
		obj.errorCode = '401' + " " + 'unAuthorised';
		errorcodeResponse.errorCode = '401' + " " + 'Unauthorized';
	}
	else if (responsePhrase == 'Unauthorized') {
		obj.errorCode = '401' + " " + 'Unauthorized'
		errorcodeResponse.errorCode = '401' + " " + 'Unauthorized';

	}
	else if (responsePhrase == 'Bad Request') {
		obj.errorCode = '400' + " " + 'Bad Request';
		errorcodeResponse.errorCode = '400' + " " + 'Bad Request';
	} else {
		hm.current.statusCode = '500';
		obj.errorCode = '500' + " " + 'Internal Server Error';
		errorcodeResponse.errorCode = '500' + " " + 'Internal Server Error';
	}
}
if (errorcodeResponse.errorCode === null || errorcodeResponse.errorCode === '' || errorcodeResponse.errorCode === undefined) {

}
else {
	errorResponse.errorCode = errorcodeResponse.errorCode;
}
if (errorDescription === null || errorDescription === '' || errorDescription === undefined) {
	errorResponse = errorMessage;
}
else {
	errorResponse.errorDescription = errorDescription;
}
ctx.setVariable("errorResponse", errorResponse);
obj.errorMessage = sm.getVar('var://service/error-message');
obj.errorDescription = sm.getVar('var://service/error-message');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
session.output.write(obj);
