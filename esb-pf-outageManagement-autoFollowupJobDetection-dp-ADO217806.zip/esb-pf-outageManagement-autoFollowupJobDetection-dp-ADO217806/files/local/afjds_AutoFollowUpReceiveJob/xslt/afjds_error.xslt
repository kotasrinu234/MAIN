<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	extension-element-prefixes="dp" exclude-result-prefixes="dp">
<xsl:template match="/">
<xsl:variable name="TransactionID">
<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
</xsl:variable>
<xsl:choose>
<xsl:when test="contains(dp:variable('var://service/error-code'),'0x01130006' )">
<xsl:message dp:type="all" dp:priority="error">afjds_001 TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>
<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'500'" />
</xsl:when>
<xsl:when test="contains(dp:variable('var://service/error-code'),'0x0213000f' )">
<xsl:message dp:type="all" dp:priority="error">afjds_001 TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>
<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'500'" />
</xsl:when>
<xsl:when test="contains(dp:variable('var://service/error-code'),'0x00c30025')">
<xsl:message dp:type="all" dp:priority="error">afjds_001 TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>
<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'500'" />
</xsl:when>
<xsl:when test="contains(dp:variable('var://service/error-code'),'0x0213000e')">
<xsl:message dp:type="all" dp:priority="error">afjds_001 TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>
<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'500'" />
</xsl:when>
 
 <xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
<xsl:message dp:type="all" dp:priority="error">afjds_014 AAA failure for OMS username :<xsl:value-of select="dp:variable('var://context/WSM/identity/username')"/> with Statuscode 401 unauthorized with ,TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>
 
<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'401'" />
<dp:set-variable name="'var://service/error-protocol-response'" value="'401'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'" />
</xsl:when>
 
<xsl:otherwise>
<xsl:message dp:type="all" dp:priority="error"> TransactionID:<xsl:value-of select="$TransactionID"/> ErrorCode:<xsl:value-of select="dp:variable('var://service/error-headers')"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/></xsl:message>
<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'500'" />
</xsl:otherwise>
</xsl:choose>
 
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="concat('TransactionID:',$TransactionID,dp:variable('var://service/error-message'))" />
</xsl:template>
</xsl:stylesheet>
