//js is used to perform nullcheck for the input request
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ms = require('multistep');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var ilsctx = session.name('ILS') || session.createContext('ILS');
	var ctx = session.name("afjds")|| session.createContext("afjds");
	var nullCheckRequired = ctx.getVar("nullCheckRequired");
	
	if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		
		if(nullCheckRequired == 'yes'){
			var jobTypeID = incomingdata.data[0].jobTypeID;
			if (jobTypeID == null || jobTypeID == '' || jobTypeID == undefined) {
				logger.error('jobTypeID is not present in input job payload');
	            session.reject('jobTypeID is not present in input job payload');
	        }	
			var status = incomingdata.data[0].status;
			if (status == null || status == '' || status == undefined) {
				logger.error('status is not present in input job payload');
				session.reject('status is not present in input job payload');
	        }		
								
			var displayID = incomingdata.data[0].displayID;
			if (displayID == null || displayID == '' || displayID == undefined) {
	           logger.error('displayID is not present in input job payload');
				session.reject('displayID is not present in input job payload');
	        }	
				
			var id = incomingdata.data[0].id;
			if (id == null || id == '' || id == undefined) {
	           logger.error(' id is not present in input job payload');
				session.reject('id is not present in input job payload');
	        }	
			
		}
		
		//oms get call 
		var ExitDescription = session.parameters.ExitDescription;
		var apiToken = session.parameters.osiApiToken;
		var OMSurl = session.parameters.omsExternalURL + '/oms/external/api/ServiceType/Electric/SystemLevel?includeFields=customFieldValuesExt';
				var Options = {
					target: OMSurl,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'GET',
					headers: {
		'osiApiToken': apiToken
	},
					contentType: 'application/json'
				};

				var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
				urlopen.open(Options, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error of oms get call, details are: " + info + JSON.stringify(error)
						//ILSctx.setVariable("exitStatus", "500");
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading response of oms get call, details are: " + info + JSON.stringify(error)
									//ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = '200 OK';
									if (responseData.customFieldValuesExt.AutoFollowUpProcess == false){
										ilsctx.setVariable('ExitDescription', ExitDescription);
			sm.setVar('var://service/mpgw/skip-backside', true); 
			STEP_rule();
			return
		}
									ctx.setVariable("Responseget", responseData);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Error response received from oms get call, details are: " + info + JSON.stringify(error)
									//ILSctx.setVariable("exitStatus", responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									var errorinfo = " Error returned from oms get call, details are: " + info + ": with statusCode " + responseStatusCode + " " + responseData
									logger.error(errorinfo);
									//ILSctx.setVariable("exitStatus", responseStatusCode);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
		
		
		
		
		
		function STEP_rule() {
	ms.callRule('afjds_AutoFollowUpReceiveJob_Processing_Policy_Response_Rule', null, null, function(error) {
		if (error) {
			logger.error("Error in afjds_AutoFollowUpReceiveJob_Processing_Policy_Response_Rule");
		}
	});
}
		
		
		}
	
		
	}); 
