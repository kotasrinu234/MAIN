var sm = require('service-metadata');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsBuffer(function(error, buffer) {
	if (error) {
		session.reject("Unexpected error in readAsJSON(): " + error);
		return;
	}else{
	var ctx1 = session.name('ILS') || session.createContext('ILS');
	var ctx = session.name('myContext') || session.createContext('myContext');
	ctx.setVar("inputData", buffer.toString());
	var errorDescription = ctx1.getVariable('errormessage');
			var message = sm.getVar('var://service/error-message')
			var URL = sm.getVar('var://service/URL-out')
			if(message == 'Rejected by policy.'){
			ctx1.setVariable('errormessage', message);
			}else{
			ctx1.setVariable('errormessage', message + URL );
			}
			
}
});
