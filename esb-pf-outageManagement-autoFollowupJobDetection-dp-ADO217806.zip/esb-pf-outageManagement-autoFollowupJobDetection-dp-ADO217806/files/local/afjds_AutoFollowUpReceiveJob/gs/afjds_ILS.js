var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name('ILS') || session.createContext('ILS');
var EntryDescription = session.parameters.afjdsReceiveEntryDescription;
var ExitDescription = session.parameters.afjdsReceiveExitDescription;
var messageType = session.parameters.messageType;

if (messageType !== undefined || messageType !== null || messageType !== '') {
	ilsctx.setVariable("messageType", messageType);
}
if (EntryDescription !== undefined || EntryDescription !== null || EntryDescription !== '') {
	ilsctx.setVariable('EntryDescription', EntryDescription);
}
if (ExitDescription !== undefined || ExitDescription !== null || ExitDescription !== '') {
	ilsctx.setVariable('ExitDescription', ExitDescription);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		function uuidv4() {
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
				var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
				return v.toString(16);
			});
		}
		var correlationID = uuidv4();
		var payload = incomingdata;
		payload.messageID = correlationID
		ilsctx.setVariable('payload', payload)
		session.output.write(payload)
		if (correlationID !== undefined) {
			ilsctx.setVariable('correlationID', correlationID);
		}
		if (incomingdata.data[0].displayID !== undefined || incomingdata.data[0].displayID !== null || incomingdata.data[0].displayID !== '') {
			ilsctx.setVariable("jobDisplayID", incomingdata.data[0].displayID)
		}
		if (incomingdata.data[0].id !== undefined || incomingdata.data[0].id !== null || incomingdata.data[0].id !== '') {
			ilsctx.setVariable("jobID", incomingdata.data[0].id)
		}
		if (incomingdata.data[0].updatedAt !== undefined || incomingdata.data[0].updatedAt !== null || incomingdata.data[0].updatedAt !== '') {
			ilsctx.setVariable("sourceEventTimestamp", incomingdata.data[0].updatedAt)
		}
	}
});
