//js is used to set context variable values from stylesheet param
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

var ctx = session.name("afjds")|| session.createContext("afjds");
var nullCheckRequired = session.parameters.nullCheckRequired;
ctx.setVariable("nullCheckRequired", nullCheckRequired);
}
}); 
 
