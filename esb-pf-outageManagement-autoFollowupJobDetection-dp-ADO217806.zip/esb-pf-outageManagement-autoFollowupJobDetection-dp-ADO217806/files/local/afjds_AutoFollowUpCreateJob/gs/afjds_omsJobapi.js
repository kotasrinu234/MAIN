//js is used to invoke oms job api
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("afjds") || session.createContext("afjds");
var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
var apiToken = ctx.getVar("apiToken");
var lookupURL = ctx.getVar("lookupURL");


var logger = console.options({
	'category': 'all'
});
var ctx = session.name("afjds") || session.createContext("afjds");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("afjds") || session.createContext("afjds");
	var ExitDescription = session.parameters.afjdsReceiveExitDescription;
	ctx.setVariable("exitDestination", omsExternalURLV1)

	var retry = ctx.getVar("retry");
	if (retry != 'yes') {
		// getting styleheet params
		var ctx = session.name("afjds") || session.createContext("afjds");
		var ODMResponse = ctx.getVar("odmresponse");
		var ODMResponseCheck = JSON.stringify(ODMResponse);
		if (ODMResponseCheck == 'true') {
			var jobid = incomingdata.data[0].id;
			var jobtypeID = incomingdata.data[0].jobTypeID;
			if (readAsJSONError) {
				logger.error("Error in reading incoming data");
				session.reject("Error in reading incoming data");
			} else {

				// lookup for checking job is in pending or not
				var jobtypeID = incomingdata.data[0].jobTypeID;
				var status = incomingdata.data[0].status;
				var lookupMessagepending = {
					"lookupReq": {
						"type": [
							{
								"name": "jobTypes.workflows",
								"id": jobtypeID,
								"label": "pending"
							}
						]
					}
				}

				var url = lookupURL;
				var LookupServiceResponsepending = {
					target: url,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessagepending
				};
				var info = " TargetURL: " + LookupServiceResponsepending.target + "; Method: " + LookupServiceResponsepending.method + "; Data :" + JSON.stringify(LookupServiceResponsepending.data) + ". ";
				urlopen.open(LookupServiceResponsepending, function(error, response) {
					if (error) {
						var ctx = session.name("afjds") || session.createContext("afjds");
						var errorinfo = "afjds_005 urlopen connect error from afjds for jobtypeID LookupServiceResponsepending  : " + info + "; error info: " + error;
						logger.error(errorinfo);
						//session.reject(" urlopen connect error from afjds for jobtypeID LookupServiceResponsepending " + JSON.stringify(error));
						ctx.setVariable("ExitDescription", errorinfo)
						ctx.setVariable("exitStatus", "500")
						session.reject(errorinfo);
					} else {
						var ctx = session.name("afjds") || session.createContext("afjds");
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var ctx = session.name("afjds") || session.createContext("afjds");
									var errorinfo = "failure in reading message for jobtypeID   LookupServiceResponsepending  : " + info + "; error info: " + error;
									logger.error(errorinfo);
									//session.reject(" failure in reading message for jobtypeID   LookupServiceResponsepending " + JSON.stringify(error));
									ctx.setVariable("ExitDescription", errorinfo)
									ctx.setVariable("exitStatus", responseStatusCode)
									session.reject(errorinfo);
								} else {
									var ctx = session.name("afjds") || session.createContext("afjds");
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from LookupServiceResponsepending LookupServiceResponse " + responseData);
									ctx.setVariable("ExitDescription", ExitDescription)
									ctx.setVariable("exitStatus", "0")
									ctx.setVariable("exitDestination", omsExternalURLV1)
									var lookupResponse = JSON.parse(responseData);
									var lookupJobtypependingstatus;
									if (lookupResponse.lookupRep.type[0].result == 0) {
										lookupJobtypependingstatus = lookupResponse.lookupRep.type[0].status;
										logger.debug("lookupJobtypependingstatus is " + lookupJobtypependingstatus);
										ctx.setVariable("lookupJobtypependingstatus", lookupJobtypependingstatus);
										if (lookupJobtypependingstatus == status) {
											var lookupMessageinprogress = {
												"lookupReq": {
													"type": [
														{
															"name": "jobTypes.workflows",
															"id": jobtypeID,
															"label": "In Progress"
														}
													]
												}
											}
											var url = lookupURL;
											var LookupServiceResponseinprogress = {
												target: url,
												method: 'POST',
												contentType: 'application/json',
												data: lookupMessageinprogress
											};
											var info = " TargetURL: " + LookupServiceResponseinprogress.target + "; Method: " + LookupServiceResponseinprogress.method + "; Data :" + JSON.stringify(LookupServiceResponseinprogress.data) + ". ";
											urlopen.open(LookupServiceResponseinprogress, function(error, response) {
												if (error) {
													var ctx = session.name("afjds") || session.createContext("afjds");
													var errorinfo = "afjds_005 urlopen connect error from afjds for jobtypeID LookupServiceResponseinprogress : " + info + "; error info: " + error;
													logger.error(errorinfo);
													//session.reject(" urlopen connect error from afjds for jobtypeID LookupServiceResponseinprogress " + JSON.stringify(error));
													ctx.setVariable("ExitDescription", errorinfo)
													ctx.setVariable("exitStatus", "500")
													session.reject(errorinfo);
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var ctx = session.name("afjds") || session.createContext("afjds");
																var errorinfo = "failure in reading message for jobtypeID   LookupServiceResponseinprogress  : " + info + "; error info: " + error;
																logger.error(errorinfo);
																//session.reject(" failure in reading message for jobtypeID   LookupServiceResponseinprogress " + JSON.stringify(error));
																ctx.setVariable("ExitDescription", errorinfo)
																ctx.setVariable("exitStatus", responseStatusCode)
																ctx.setVariable("exitDestination", omsExternalURLV1)
																session.reject(errorinfo);
															} else {
																var ctx = session.name("afjds") || session.createContext("afjds");
																hm.response.statusCode = responseStatusCode;
																logger.debug("response received from LookupServiceResponseinprogress LookupServiceResponse " + responseData);
																ctx.setVariable("ExitDescription", ExitDescription)
																ctx.setVariable("exitStatus", "0")
																var lookupResponse = JSON.parse(responseData);
																var lookupJobtypeInProgressStatus;
																if (lookupResponse.lookupRep.type[0].result == 0) {
																	lookupJobtypeInProgressStatus = lookupResponse.lookupRep.type[0].status;
																	logger.debug("lookupJobtypeInProgressStatus is " + lookupJobtypeInProgressStatus);
																	ctx.setVariable("lookupJobtypeInProgressStatus", lookupJobtypeInProgressStatus);
																	// /api/v1/ServiceType/Electric/Job/{id}/WorkFlow
																	var jobid = incomingdata.data[0].id;
																	var workflowapiuri = omsExternalURLV1 + 'Job/' + jobid + '/WorkFlow';
																	var TokenValue = apiToken;
																	var statusvalue = lookupJobtypeInProgressStatus;
																	var jobworkflowapi = {
																		target: workflowapiuri,
																		sslClientProfile: 'OMS_Client_Profile',
																		method: 'POST',
																		contentType: 'application/json',
																		headers: {
																			'osiApiToken': TokenValue
																		},
																		data: statusvalue
																	};

																//	var info = " TargetURL: " + jobworkflowapi.target + "; Method: " + jobworkflowapi.method + "; Data :" + JSON.stringify(jobworkflowapi.data) + ". ";
																	urlopen.open(jobworkflowapi, function(error, response) {
																		if (error) {
																			var ctx = session.name("afjds") || session.createContext("afjds");
																			var errorinfo = "urlopen connect error with jobworkflowapi for jobid  : " + info + "; error info: " + error;
																			ctx.setVariable("retry", 'yes');
																			logger.error(errorinfo);
																			var ErrorTxt = "afjds_006 urlopen connect error with jobworkflowapi for jobid " + jobid + " " + JSON.stringify(error);
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																			ctx.setVariable("ExitDescription", errorinfo)
																			ctx.setVariable("exitStatus", "500")
																			session.reject(errorinfo);
																		} else {
																			// read response data
																			// get the response status code
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var ctx = session.name("afjds") || session.createContext("afjds");
																						var errorinfo = "error message from jobworkflowapi for jobid   : " + info + "; error info: " + error;
																						//dp:reject stop the transaction and go error rule with error code and description
																						logger.error(errorinfo);
																						//session.reject("error message from jobworkflowapi for jobid " + jobid + " " + JSON.stringify(error));
																						ctx.setVariable("ExitDescription", errorinfo)
																						ctx.setVariable("exitStatus", responseStatusCode)
																						session.reject(errorinfo);
																					} else {
																						var ctx = session.name("afjds") || session.createContext("afjds");
																						//store status code with response body in context variable
																						hm.response.statusCode = responseStatusCode;
																						hm.response.statusCode = responseStatusCode;
																						ctx.setVariable("ExitDescription", ExitDescription)
																						ctx.setVariable("exitDestination", omsExternalURLV1)
																						ctx.setVariable("exitStatus", "0")
																						var test = JobCompleted(jobtypeID, jobid);
																					}
																				});


																			} else if (responseStatusCode == 401 || responseStatusCode == 403) {
																				// Handle business error responses (HTTP 401 or 403)
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						// Handle error in reading response data
																						var errorinfo = "afjds_013: Unauthorized Error returned from omsExternalURLV1', details are : " + info + "; error info :" + error;
																						ctx.setVariable('ExitDescription', errorinfo);
																						ctx.setVariable('exitStatus', responsStatusCode);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "afjds_013: Unauthorized Error returned from omsExternalURLV1', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																						ctx.setVariable('ExitDescription', errorinfo);
																						ctx.setVariable('exitStatus', responseStatusCode);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					}
																				})
																			} else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var ctx = session.name("afjds") || session.createContext("afjds");
																						var errorinfo = "failure in reading message from jobworkflowapi for jobid    : " + info + "; error info: " + error;
																						//dp:reject stop the transaction and go error rule with error code and description
																						logger.error(errorinfo);
																						//session.reject("failure in reading message from jobworkflowapi for jobid  ");
																						ctx.setVariable("ExitDescription", errorinfo)
																						ctx.setVariable("exitStatus", responseStatusCode)
																						session.reject(errorinfo);
																					} else {
																						var ctx = session.name("afjds") || session.createContext("afjds");
																						//var errorinfo = "response code returned from jobworkflowapi for jobid   : " + info + "; error info: " + error;
																						var errorinfo = "response code returned from jobworkflowapi for jobid   : " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
																						logger.error(errorinfo);
																						//session.reject("response code returned from jobworkflowapi for jobid " + jobid + " " + responseStatusCode + " " + responseData);
																						ctx.setVariable("ExitDescription", errorinfo)
																						ctx.setVariable("exitStatus", responseStatusCode)
																						session.reject(errorinfo);
																					}
																				});
																			}
																		}
																	});
																	// work flow end
																} else {
																	var ctx = session.name("afjds") || session.createContext("afjds");
																	var errorinfo = "lookup result for inprogress is not 0   : " + info + "; error info: " + error;
																	logger.error("lookup result for inprogress is not 0 ");
																	//session.reject("lookup result for inprogress is not 0 ");
																	ctx.setVariable("ExitDescription", errorinfo)
																	ctx.setVariable("exitStatus", responseStatusCode)
																	session.reject(errorinfo);
																}
															}
														});
													} else if (responseStatusCode == 401 || responseStatusCode == 403) {
														// Handle business error responses (HTTP 401 or 403)
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																// Handle error in reading response data
																var errorinfo = "afjds_013: Unauthorized Error returned from , details are lookupURL: " + info + "; error info :" + error;
																ctx.setVariable('ExitDescription', errorinfo);
																ctx.setVariable('exitStatus', responseStatusCode);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var errorinfo = "afjds_013: Unauthorized  Error returned from  details are lookupURL : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																ctx.setVariable('ExitDescription', errorinfo);
																ctx.setVariable('exitStatus', responseStatusCode);
																logger.error(errorinfo);
																session.reject(errorinfo);
															}
														})
													} else {
														var ctx = session.name("afjds") || session.createContext("afjds");
														//var errorinfo = "lookup response code for inprogress is   : " + info + "; error info: " + error;
														var errorinfo = "lookup response code for inprogress is   : " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
														logger.error(errorinfo);
														//session.reject("lookup response code for inprogress is  " + responseStatusCode);
														ctx.setVariable("ExitDescription", errorinfo)
														ctx.setVariable("exitStatus", responseStatusCode)
														session.reject(errorinfo);

													}
												}
											});
										} else {
											logger.debug("++++status is not match");
											var test = JobCompleted(jobtypeID, jobid);
										}
									} else {
										var ctx = session.name("afjds") || session.createContext("afjds");
										var errorinfo = "lookup service jobtypeid label result code  is  : " + info + "; error info: " + error;
										logger.error(errorinfo);
										//session.reject("lookup service jobtypeid label result code  is" + lookupResponse.lookupRep.type[0].result);
										ctx.setVariable("ExitDescription", errorinfo)
										ctx.setVariable("exitStatus", responseStatusCode)
										session.reject(errorinfo);
									}

								}
							});
						} else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "afjds_013: Unauthorized Error returned from lookupURL details are  : " + info + "; error info :" + error;
									ctx.setVariable('ExitDescription', errorinfo);
									ctx.setVariable('exitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "afjds_013: Unauthorized Error returned from lookupURL details are  : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ctx.setVariable('ExitDescription', errorinfo);
									ctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							})
						} else {
							var ctx = session.name("afjds") || session.createContext("afjds");
							//var errorinfo = "lookup response code for  jobtypeID   LookupServiceResponsepending  : " + info + "; error info: " + error;
							var errorinfo = "lookup response code for  jobtypeID   LookupServiceResponsepending  :" +  + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
							logger.error(errorinfo);
							//session.reject("lookup response code for  jobtypeID   LookupServiceResponsepending  is  " + responseStatusCode);
							ctx.setVariable("ExitDescription", errorinfo)
							ctx.setVariable("exitStatus", responseStatusCode)
							session.reject(errorinfo);
						}
					}
				});

				// end lookup for checking job is in pending or not
			}
		}
	}
});

//function start


function JobCompleted(jobtypeID, jobid) {
	var ExitDescription = session.parameters.afjdsReceiveExitDescription;
	var jobtypeID = jobtypeID;
	var jobid = jobid;
	// remarks start call PATCH /api/ServiceType/Electric/Job/{id}  --use data.id from the trigger payload as the {id}
	var ctx = session.name("afjds") || session.createContext("afjds");
	var omsExternalURL = ctx.getVar("omsExternalURLV1");
	var jobRemarkuri = omsExternalURL + 'Job/' + jobid;
	var TokenValue = apiToken;
	var payload =
	{
		"customFieldValues": {
			"Remarks": "Completed Due to Auto Follow up Process"
		}
	}
	var jobapiRemark = {
		target: jobRemarkuri,
		sslClientProfile: 'OMS_Client_Profile',
		method: 'PATCH',
		contentType: 'application/json',
		headers: {
			'osiApiToken': TokenValue
		},
		data: payload
	};

	var info = " TargetURL: " + jobapiRemark.target + "; Method: " + jobapiRemark.method + "; Data :" + JSON.stringify(jobapiRemark.data) + ". ";
	urlopen.open(jobapiRemark, function(error, response) {
		if (error) {
			var ctx = session.name("afjds") || session.createContext("afjds");
			ctx.setVariable("retry", 'yes');
			var errorinfo = "urlopen connect error with jobapiRemark for jobid   : " + info + "; error info: " + error;
			logger.error(errorinfo);
			var ErrorTxt = "afjds_003 urlopen connect error with jobapiRemark for jobid " + jobid + " " + JSON.stringify(error);
			ctx.setVariable("ErrorTxt", ErrorTxt);
			ctx.setVariable("ExitDescription", errorinfo)
			ctx.setVariable("exitStatus", "500")
			session.reject(errorinfo);
		} else {
			// read response data
			// get the response status code
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var ctx = session.name("afjds") || session.createContext("afjds");
						var errorinfo = "error message from job jobapiRemark  api for jobid  : " + info + "; error info: " + error;
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error(errorinfo);
						//session.reject("error message from job jobapiRemark  api for jobid " + jobid + " " + JSON.stringify(error));
						ctx.setVariable("ExitDescription", errorinfo)
						ctx.setVariable("exitStatus", responseStatusCode)
						session.reject(errorinfo);
					} else {
						var ctx = session.name("afjds") || session.createContext("afjds");
						//store status code with response body in context variable
						hm.response.statusCode = responseStatusCode;
						hm.response.statusCode = responseStatusCode;
						ctx.setVariable("ExitDescription", ExitDescription)
						ctx.setVariable("exitStatus", "0")
						ctx.setVariable("exitDestination", omsExternalURLV1)
						//lookup start	
						var lookupMessage = {
							"lookupReq": {
								"type": [
									{
										"name": "jobTypes.workflows",
										"id": jobtypeID,
										"label": "Completed"
									}
								]
							}
						}
						var url = lookupURL;
						var LookupServiceResponse = {
							target: url,
							method: 'POST',
							contentType: 'application/json',
							data: lookupMessage
						};
						var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
						urlopen.open(LookupServiceResponse, function(error, response) {
							if (error) {
								var ctx = session.name("afjds") || session.createContext("afjds");
								var errorinfo = "afjds_005 urlopen connect error from afjds for jobtypeID LookupServiceResponse : " + info + "; error info: " + error;
								logger.error(errorinfo);
								//session.reject(" urlopen connect error from afjds for jobtypeID LookupServiceResponse " + JSON.stringify(error));
								ctx.setVariable("ExitDescription", errorinfo)
								ctx.setVariable("exitStatus", "500")
								session.reject(errorinfo);
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var ctx = session.name("afjds") || session.createContext("afjds");
											var errorinfo = "failure in reading message for jobtypeID   LookupServiceResponse : " + info + "; error info: " + error;
											logger.error(errorinfo);
											//session.reject(" failure in reading message for jobtypeID   LookupServiceResponse " + JSON.stringify(error));
											ctx.setVariable("ExitDescription", errorinfo)
											ctx.setVariable("exitStatus", responseStatusCode)
											session.reject(errorinfo);
										} else {
											var ctx = session.name("afjds") || session.createContext("afjds");
											hm.response.statusCode = responseStatusCode;
											ctx.setVariable("ExitDescription", ExitDescription)
											ctx.setVariable("exitStatus", "0")
											ctx.setVariable("exitDestination", omsExternalURLV1)
											var lookupResponse = JSON.parse(responseData);
											var lookupJobtypestatus;
											if (lookupResponse.lookupRep.type[0].result == 0) {
												lookupJobtypestatus = lookupResponse.lookupRep.type[0].status;
												var ctx = session.name("afjds") || session.createContext("afjds");
												logger.debug("lookupJobtypestatus is " + lookupJobtypestatus);
												ctx.setVariable("lookupJobtypestatus", lookupJobtypestatus);
											} else {
												var ctx = session.name("afjds") || session.createContext("afjds");
												var errorinfo = "lookup service jobtypeid label result code  is : " + info + "; error info: " + error;
												logger.error(errorinfo + lookupResponse.lookupRep.type[0].result);
												//session.reject("lookup service jobtypeid label result code  is" + lookupResponse.lookupRep.type[0].result);
												ctx.setVariable("ExitDescription", errorinfo)
												ctx.setVariable("exitStatus", "500")
												session.reject(errorinfo);
											}
											// workflow start
											var workflowapiuri = omsExternalURLV1 + 'Job/' + jobid + '/WorkFlow';
											var TokenValue = apiToken;
											var statusvalue = lookupJobtypestatus;
											var jobworkflowapi = {
												target: workflowapiuri,
												sslClientProfile: 'OMS_Client_Profile',
												method: 'POST',
												contentType: 'application/json',
												headers: {
													'osiApiToken': TokenValue
												},
												data: statusvalue
											};
											var info = " TargetURL: " + jobworkflowapi.target + "; Method: " + jobworkflowapi.method + "; Data :" + JSON.stringify(jobworkflowapi.data) + ". ";
											urlopen.open(jobworkflowapi, function(error, response) {
												if (error) {
													var ctx = session.name("afjds") || session.createContext("afjds");
													ctx.setVariable("retry", 'yes');
													var errorinfo = "urlopen connect error with jobworkflowapi for jobid : " + info + "; error info: " + error;
													logger.error(errorinfo);
													var ErrorTxt = "afjds_006 urlopen connect error with jobworkflowapi for jobid " + jobid + " " + JSON.stringify(error);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													ctx.setVariable("ExitDescription", errorinfo)
													ctx.setVariable("exitStatus", "500")
													session.reject(errorinfo);
												} else {
													// read response data
													// get the response status code
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var ctx = session.name("afjds") || session.createContext("afjds");
																var errorinfo = "error message from jobworkflowapi for jobid : " + info + "; error info: " + error;
																//dp:reject stop the transaction and go error rule with error code and description
																logger.error(errorinfo);
																//session.reject("error message from jobworkflowapi for jobid " + jobid + " " + JSON.stringify(error));
																ctx.setVariable("ExitDescription", errorinfo)
																ctx.setVariable("exitStatus", responseStatusCode)
																session.reject(errorinfo);
															} else {
																var ctx = session.name("afjds") || session.createContext("afjds");
																//store status code with response body in context variable
																hm.response.statusCode = responseStatusCode;
																hm.response.statusCode = responseStatusCode;
																ctx.setVariable("ExitDescription", ExitDescription)
																ctx.setVariable("exitStatus", "0")
																ctx.setVariable("exitDestination", omsExternalURLV1)

																//comments start
																logger.debug("jobid at comment level is " + jobid);
																if (jobid != undefined || jobid != '' || jobid != null) {
																	//	var jobid = jobid;
																	var jobcommentapiuri = omsExternalURLV1 + 'Job/' + jobid + '/Comment';
																	var ctx = session.name("afjds") || session.createContext("afjds");
																	var TokenValue = apiToken;
																	var jobapicomment = ctx.getVar("jobapicomment");
																	var payload =
																	{
																		"comment": jobapicomment
																	}
																	var jobapicomment = {
																		target: jobcommentapiuri,
																		sslClientProfile: 'OMS_Client_Profile',
																		method: 'POST',
																		contentType: 'application/json',
																		headers: {
																			'osiApiToken': TokenValue
																		},
																		data: payload
																	};
																	var info = " TargetURL: " + jobapicomment.target + "; Method: " + jobapicomment.method + "; Data :" + JSON.stringify(jobapicomment.data) + ". ";
																	urlopen.open(jobapicomment, function(error, response) {
																		if (error) {
																			var ctx = session.name("afjds") || session.createContext("afjds");
																			ctx.setVariable("retry", 'yes');
																			var errorinfo = "afjds_003 urlopen connect error with jobapicomment for jobid : " + info + "; error info: " + error;
																			logger.error(errorinfo);
																			var ErrorTxt = "afjds_003 urlopen connect error with jobapicomment for jobid " + jobid + " " + JSON.stringify(error);
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																			ctx.setVariable("ExitDescription", errorinfo)
																			ctx.setVariable("exitStatus", "500")
																			session.reject(errorinfo);
																		} else {
																			// read response data
																			// get the response status code
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var ctx = session.name("afjds") || session.createContext("afjds");
																						var errorinfo = "error message from job comment  api for jobid : " + info + "; error info: " + error;
																						//dp:reject stop the transaction and go error rule with error code and description
																						logger.error(errorinfo);
																						//session.reject("error message from job comment  api for jobid " + jobid + " " + JSON.stringify(error));
																						ctx.setVariable("ExitDescription", errorinfo)
																						ctx.setVariable("exitStatus", responseStatusCode)
																						session.reject(errorinfo);
																					} else {
																						var ctx = session.name("afjds") || session.createContext("afjds");
																						//store status code with response body in context variable
																						hm.response.statusCode = responseStatusCode;
																						hm.response.statusCode = responseStatusCode;
																						ctx.setVariable("ExitDescription", ExitDescription)
																						ctx.setVariable("exitStatus", "0")
																						ctx.setVariable("exitDestination", omsExternalURLV1)
																					}
																				});
																			} else if (responseStatusCode == 401 || responseStatusCode == 403) {
																				// Handle business error responses (HTTP 401 or 403)
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						// Handle error in reading response data
																						var errorinfo = "afjds_013: Unauthorized Error returned from lookupURL details are : " + info + "; error info :" + error;
																						ctx.setVariable('ExitDescription', errorinfo);
																						ctx.setVariable('exitStatus', responseStatusCode);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "afjds_013: Unauthorized Error returned from lookupURL details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																						ctx.setVariable('ExitDescription', errorinfo);
																						ctx.setVariable('exitStatus', responseStatusCode);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					}
																				})
																			}
																			else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var ctx = session.name("afjds") || session.createContext("afjds");
																						var errorinfo = "failure in reading message from Jobcommentsapi  for jobinternalid: " + info + "; error info: " + error;
																						logger.error(errorinfo);
																						//session.reject("failure in reading message from Jobcommentsapi for jobinternalid ");
																						ctx.setVariable("ExitDescription", errorinfo)
																						ctx.setVariable("exitStatus", responseStatusCode)
																						session.reject(errorinfo);
																					} else {
																						var ctx = session.name("afjds") || session.createContext("afjds");
																						//var errorinfo = "Error code returned from job comment api  for  jobid: " + info + "; error info: " + error;
																						var errorinfo = "Error code returned from job comment api  for  jobid:  " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
																						logger.error(errorinfo);
																						//session.reject("Error code returned from job comment api  for  jobid: " + jobid + " statusCode " + responseStatusCode + " " + responseData);
																						ctx.setVariable("ExitDescription", errorinfo)
																						ctx.setVariable("exitStatus", responseStatusCode)
																						session.reject(errorinfo);
																					}
																				});

																			}
																		}
																	});
																} else {
																	var ctx = session.name("afjds") || session.createContext("afjds");
																	var errorinfo = "id is not present in input payload " + info + "; error info: " + error;
																	logger.error(errorinfo);
																	//session.reject("id is not present in input payload");
																	ctx.setVariable("ExitDescription", errorinfo)
																	ctx.setVariable("exitStatus", responseStatusCode)
																	session.reject(errorinfo);
																}
																//comments end
															}
														});
													} else if (responseStatusCode == 401 || responseStatusCode == 403) {
														// Handle business error responses (HTTP 401 or 403)
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																// Handle error in reading response data
																var errorinfo = "afjds_013: Unauthorized Error returned from lookupURL details are: " + info + "; error info :" + error;
																ctx.setVariable('ExitDescription', errorinfo);
																ctx.setVariable('exitStatus', responseStatusCode);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var errorinfo = "afjds_013: Unauthorized Error returned from lookupURL details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																ctx.setVariable('ExitDescription', errorinfo);
																ctx.setVariable('exitStatus', responseStatusCode);
																logger.error(errorinfo);
																session.reject(errorinfo);
															}
														})
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var ctx = session.name("afjds") || session.createContext("afjds");
																var errorinfo = "failure in reading message from jobworkflowapi for jobid " + info + "; error info: " + error;
																logger.error(errorinfo);
																//session.reject("failure in reading message from jobworkflowapi for jobid ");
																ctx.setVariable("ExitDescription", errorinfo)
																ctx.setVariable("exitStatus", responseStatusCode)
																session.reject(errorinfo);
															} else {
																var ctx = session.name("afjds") || session.createContext("afjds");
																var errorinfo = "response code returned from jobworkflowapi for jobid " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
																logger.error(errorinfo);
																//session.reject("response code returned from jobworkflowapi for jobid " + jobid + " " + responseStatusCode + " " + responseData);
																ctx.setVariable("ExitDescription", errorinfo)
																ctx.setVariable("exitStatus", responseStatusCode)
																session.reject(errorinfo);
															}
														});
													}
												}
											});
											// workflow end
										}
									});
								} else if (responseStatusCode == 401 || responseStatusCode == 403) {
									// Handle business error responses (HTTP 401 or 403)
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											// Handle error in reading response data
											var errorinfo = "afjds_013: Unauthorized Error returned from lookupURL details are: " + info + "; error info :" + error;
											ctx.setVariable('ExitDescription', errorinfo);
											ctx.setVariable('exitStatus', responseStatusCode);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "afjds_013: Unauthorized Error returned from lookupURL details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
											ctx.setVariable('ExitDescription', errorinfo);
											ctx.setVariable('exitStatus', responseStatusCode);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									})
								} else {
									var ctx = session.name("afjds") || session.createContext("afjds");
									//var errorinfo = "response code returned from jobtypeID   LookupServiceResponse  " + info + "; error info: " + error;
									var errorinfo = " response code returned from jobtypeID  LookupServiceResponse  " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
									logger.error(errorinfo);
									//session.reject("response code returned from jobtypeID   LookupServiceResponse" + responseStatusCode);
									ctx.setVariable("ExitDescription", errorinfo)
									ctx.setVariable("exitStatus", responseStatusCode)
									session.reject(errorinfo);
								}
							}
						});
						// lookup end
					}
				});
			} else if (responseStatusCode == 401 || responseStatusCode == 403) {
				// Handle business error responses (HTTP 401 or 403)
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						// Handle error in reading response data
						var errorinfo = "afjds_013: Unauthorized Error returned from omsExternalURL details are : " + info + "; error info :" + error;
						ctx.setVariable('ExitDescription', errorinfo);
						ctx.setVariable('exitStatus', responseStatusCode);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "afjds_013: Unauthorized Error returned from omsExternalURL details are : " + info + "; error info :" + error;
						ctx.setVariable('ExitDescription', errorinfo);
						ctx.setVariable('exitStatus', responseStatusCode);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				})
			}
			else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var ctx = session.name("afjds") || session.createContext("afjds");
						var errorinfo = "failure in reading message from job remark api  for  jobid  " + info + "; error info: " + error;
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error(errorinfo);
						//session.reject("failure in reading message from job remark api  for  jobid ");
						ctx.setVariable("ExitDescription", errorinfo)
						ctx.setVariable("exitStatus", responseStatusCode)
						session.reject(errorinfo);
					} else {
						var ctx = session.name("afjds") || session.createContext("afjds");
						//var errorinfo = "Error code returned from job remark api  for  jobid: " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
						var errorinfo = "Error code returned from job remark api  for  jobid: " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
						logger.error(errorinfo);
						//session.reject("Error code returned from job remark api  for  jobid: " + jobid + " statusCode " + responseStatusCode + " " + responseData);
						ctx.setVariable("ExitDescription", errorinfo)
						ctx.setVariable("exitStatus", responseStatusCode)
						session.reject(errorinfo);
					}
				});

			}
		}

	});

}
