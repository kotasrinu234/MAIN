//js is used to create a link job
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var ExitDescription = session.parameters.ExitDescription;
	var ctx = session.name("afjds")|| session.createContext("afjds");
	var retry = ctx.getVar("retry");
	session.output.write(incomingdata);
	if (retry != 'yes'){
	var ODMResponse = ctx.getVar("odmresponse");
	var ODMResponseCheck = JSON.stringify(ODMResponse);
	if(ODMResponseCheck == 'true'){
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
	var apiToken= ctx.getVar("apiToken");
	var lookupJobtypeid = ctx.getVar("lookupJobtypeid");
	var linkTypesid = ctx.getVar("linkTypesid");
		if (readAsJSONError) {
			logger.error("Error in reading incoming data");
			session.reject("Error in reading incoming data");
		} else {
			var payload= 
			{
				  "addLinks": [
					    {

					    }
					  ]

					}
			payload.addLinks[0].linkedID = incomingdata.data[0].id;
			payload.address = incomingdata.data[0].address;
			payload.jobTypeID =lookupJobtypeid;
			payload.addLinks[0].linkTypeID = linkTypesid;
			payload.notes = incomingdata.data[0].notes;
			payload.notes = incomingdata.data[0].notes;
			if(incomingdata.data[0].commentAdds == undefined || incomingdata.data[0].commentAdds == '' || incomingdata.data[0].commentAdds == null){
				var jobapicomment = ctx.getVar("jobapicomment");
				var custommessage = [{
						"comment" : jobapicomment
				}];
				payload.commentAdds = custommessage;
		}else{
			var comments =[];
			//var comments = incomingdata.data[0].commentAdds;	
			var incomingcomment = {
					"comment" : incomingdata.data[0].commentAdds
			}
			comments.push(incomingcomment);
			var jobapicomment = ctx.getVar("jobapicomment");
			var custommessage = {
					"comment" : jobapicomment
			}
			comments.push(custommessage);
			payload.commentAdds = comments;
		}
			payload.title = incomingdata.data[0].title;
			
			if(incomingdata.data[0].operationEventIDs == undefined || incomingdata.data[0].operationEventIDs == null || incomingdata.data[0].operationEventIDs == ''){
			logger.debug("operationEventIDs is not present in input payload");
			}else{
			payload.operationEventIDs = new Array(); 
			payload.operationEventIDs.push(incomingdata.data[0].operationEventIDs[0]);
			//payload.operationEventIDs=incomingdata.data[0].operationEventIDs;
			}
			payload.voltage = incomingdata.data[0].voltage;
			payload.aorID = incomingdata.data[0].aorID;
			payload.substation = incomingdata.data[0].substation;
			payload.nominalFeeder = incomingdata.data[0].nominalFeeder;
			payload.location = incomingdata.data[0].location;
			payload.feederName = incomingdata.data[0].feederName;
			
			
			//Call "POST /api/v1/ServiceType/Electric/Job"
			var jobapiuri = omsExternalURLV1+"Job";
			var TokenValue = apiToken;

			var jobapi = {
				target: jobapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'POST',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
				data: payload
			};
			
			var info = " TargetURL :" + jobapi.target + "; Method :" + jobapi.method + "; Data :" + JSON.stringify(jobapi.data) + ". "; 

			urlopen.open(jobapi, function(error, response) {
				if (error) {	
					var ctx = session.name("afjds")|| session.createContext("afjds");
					var errorinfo = "urlopen connect error with jobapi post is: " + info + "; error info: " + error;
					ctx.setVariable("retry", 'yes');
					logger.error(" urlopen connect error with jobapi post is " + JSON.stringify(error));
					var ErrorTxt = "afjds_004 urlopen connect error with jobapi post is " + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("ExitDescription", errorinfo);
				    ctx.setVariable("exitStatus", "500");
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 )  {
						
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var ctx = session.name("afjds")|| session.createContext("afjds");
					            var errorinfo = "error message while reading from jobapi post call: " + info + "; error info: " + error;
								//dp:reject stop the transaction and go error rule with error code and description
								logger.error(" error message while reading from jobapi post call " +JSON.stringify(error));
								//session.reject("error message while reading from jobapi post call " +JSON.stringify(error));
								ctx.setVariable("ExitDescription", errorinfo);
				                ctx.setVariable("exitStatus", responseStatusCode);
								session.reject(errorinfo);
							} else {
								var ctx = session.name("afjds")|| session.createContext("afjds");
								hm.response.statusCode = responseStatusCode;
								logger.debug("response code recieved from call api is "+responseStatusCode);
								ctx.setVariable("ExitDescription", ExitDescription);
								ctx.setVariable("exitStatus", "0");
								ctx.setVariable("exitDestination", omsExternalURLV1)
								session.output.write(responseData);
							}
						});
					}else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var ctx = session.name("afjds")|| session.createContext("afjds");
									var errorinfo = "afjds_013: Unauthorized Error returned from omsExternalURLV1 details are : " + info + "; error info :" + error;
									ctx.setVariable('ExitDescription', errorinfo);
									ctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var ctx = session.name("afjds")|| session.createContext("afjds");
									var errorinfo = "afjds_013: Unauthorized Error returned from omsExternalURLV1 details are : " + info + "; error info :" + error;
									ctx.setVariable('ExitDescription', errorinfo);
									ctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							})
						}else{
						
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var ctx = session.name("afjds")|| session.createContext("afjds");
					            var errorinfo = "ailure in reading message from jobapi post call is: " + info + "; error info: " + error;
								//dp:reject stop the transaction and go error rule with error code and description
								logger.error("failure in reading message from jobapi post call is  " + JSON.stringify(error));
								//session.reject("failure in reading message from jobapi post call is ");
								ctx.setVariable("ExitDescription", errorinfo);
				                ctx.setVariable("exitStatus", responseStatusCode);
								session.reject(errorinfo);
							} else {
								var ctx = session.name("afjds")|| session.createContext("afjds");
					            //var errorinfo = "response returned from jobapi post call is: " + info + "; error info: " + error;
								var errorinfo = "response returned from jobapi post call is:  " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
								logger.error(" response returned from jobapi post call is "+responseStatusCode+" "+ responseData);
								//session.reject("response returned from jobapi post call is "+responseStatusCode+" "+ responseData);
								ctx.setVariable("ExitDescription", errorinfo);
				                ctx.setVariable("exitStatus", responseStatusCode);
								session.reject(errorinfo);
					}
						});
						
					}
				}
			});
			//call end
		}
	}
	}
});
