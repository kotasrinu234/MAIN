var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("afjds") || session.createContext("afjds");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("afjds") || session.createContext("afjds");
	var ExitDescription = session.parameters.afjdsReceiveExitDescription;
	var StepExitDescription = session.parameters.StepExitDescription;
	var retry = ctx.getVar("retry");
	if (retry != 'yes') {
		var ODMEndpoint = session.parameters.ODMEndpoint;
		if (readAsJSONError) {
			logger.error("Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {
			//checking displayid as null
			if (incomingdata.data[0].displayID != undefined || incomingdata.data[0].displayID != '' || incomingdata.data[0].displayID != null) {
				var displayID = incomingdata.data[0].displayID;
			} else {
				var displayID = '';
			}
			var ctx = session.name("afjds") || session.createContext("afjds");
			var externalCallCodeID = ctx.getVar("externalCallCodeID");
			var jobStatus = ctx.getVar("lookupJobtypeLabel");
			var dGroup = ctx.getVar("lookupAorIDlabel");
			var outageSubtypeslabel = ctx.getVar("outageSubtypeslabel");
			var jobSubType = outageSubtypeslabel;
			var jobType = externalCallCodeID;
			var jobId = incomingdata.data[0].displayID;
			var jobStatus = jobStatus.toUpperCase();
			var timestamp = incomingdata.data[0].updatedAt;
			var payload = {
				"request": {
					"auto99FollowUpInput": [
						{
							"jobStatus": jobStatus,
							"jobSubType": jobSubType,
							"callCode": jobType,
							"jobID": jobId,
							"dGroup": dGroup,
							"lastStatusUpdateTime": timestamp
						}
					]
				},
				"__DecisionID__": displayID
			}
			var odmuri = ODMEndpoint;
			var odmapi = {
				target: odmuri,
				sslClientProfile: 'ODM_Client_Profile',
				method: 'post',
				contentType: 'application/json',
				data: payload
			};
			ctx.setVariable("responseData", payload);
			var info = " TargetURL :" + odmapi.target + "; Method :" + odmapi.method + "; Data :" + JSON.stringify(odmapi.data) + ". ";
			urlopen.open(odmapi, function(error, response) {
				if (error) {
					var ctx = session.name("afjds") || session.createContext("afjds");
					var errorinfo = "afjds_003 urlopen connect error with odmapi for auto99FollowUp : " + info + "; error info: " + error;
					// an error occurred during request sending or response header parsing
					logger.error(errorinfo);
					//session.reject(" urlopen connect error with odmapi for  auto99FollowUp " + JSON.stringify(error));
					ctx.setVariable("ExitDescription", errorinfo)
					ctx.setVariable("exitStatus", "500")
					session.reject(errorinfo);
					//ctx.setVariable("odmresponse", true);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var ctx = session.name("afjds") || session.createContext("afjds");
								var errorinfo = "failure in reading message from odmapi  : " + info + "; error info: " + error;
								// error while reading response or transferring data to Buffer
								logger.error(errorinfo);
								//session.reject(" failure in reading message from odmapi " + JSON.stringify(error));
								ctx.setVariable("ExitDescription", errorinfo)
								ctx.setVariable("exitStatus", responseStatusCode)
								session.reject(errorinfo);
							} else {
								var ctx = session.name("afjds") || session.createContext("afjds");
								ctx.setVariable("ExitDescription", StepExitDescription)
								ctx.setVariable("exitStatus", "0")
								logger.debug('ODMEndpoint',ODMEndpoint)
								ctx.setVariable("stepexitDestination", ODMEndpoint);
								ms.callRule('afjds_AutoFollowUpCreateJob_ILSstepExit_Processing_Policy_rule_2', null, null, function(error) {
									if (error) {
										logger.error("Error in afjds_AutoFollowUpCreateJob_ILSstepExit_Processing_Policy_rule_2");
									}
								});

								var ctx = session.name("afjds") || session.createContext("afjds");

								hm.response.statusCode = '200 Message is received';
								//session.output.write(responseData);
								logger.debug("response code received from  trap_ReceiveJobStatus odmuri call: " + responseStatusCode);
								logger.debug("odm response is " + JSON.stringify(responseData));

								var odmresponse = responseData.response.auto99FollowUpOutput[0].eligibleForFollowUp;
								ctx.setVariable("odmresponse", odmresponse);

							}
						});
					} else {
						var ctx = session.name("afjds") || session.createContext("afjds");
						var errorinfo = "Error returned from  odm  with statusCode   : " + info + "; error info: " + error + responseStatusCode;
						logger.error(errorinfo);
						//session.reject("Error returned from  odm  with statusCode " + responseStatusCode);
						ctx.setVariable("ExitDescription", errorinfo)
						ctx.setVariable("exitStatus", responseStatusCode)
						session.reject(errorinfo);
					}
				}
				//odm end				
			});
		}
	}
});
