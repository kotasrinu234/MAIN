//js is used to set context variables from stylesheet params
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("afjds") || session.createContext("afjds");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

var ctx = session.name("afjds")|| session.createContext("afjds");
var lookupURL = session.parameters.lookUpURL;
var omsExternalURL = session.parameters.omsExternalURL;
var omsExternalURLV1 = session.parameters.omsExternalURLV1;
var apiToken = session.parameters.osiApiToken;
var followuplabel =session.parameters.followuplabel;
var DTEAssociatedlabel =session.parameters.DTEAssociatedlabel;
var jobapicomment = session.parameters.jobapicomment;
omsExternalURLV1 = omsExternalURL+'/oms/external/api/v1/ServiceType/Electric/';
omsExternalURL = omsExternalURL+'/oms/external/api/ServiceType/Electric/'; 

ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("omsExternalURLV1", omsExternalURLV1);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("followuplabel", followuplabel);
ctx.setVariable("DTEAssociatedlabel", DTEAssociatedlabel);
ctx.setVariable("jobapicomment", jobapicomment);
}
});
  
