var sm = require('service-metadata');
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});
var hm = require('header-metadata');
var ctx = session.name("afjds") || session.createContext("afjds");
var ODMResponsedata = ctx.getVariable("responseData")
session.output.write(ODMResponsedata);
