var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("afjds") || session.createContext("afjds");

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	var ExitDescription = session.parameters.ExitDescription;
	//ctx.setVariable("exitDestination", omsExternalURL)

	// getting styleheet params
	var ctx = session.name("afjds") || session.createContext("afjds");
	var retry = ctx.getVar("retry");

	if (retry != 'yes') {
		var ctx = session.name("afjds") || session.createContext("afjds");
		var lookupURL = ctx.getVar("lookupURL");
		var omsExternalURL = ctx.getVar("omsExternalURL");
		var apiToken = ctx.getVar("apiToken");
		var ExitDescription = session.parameters.ExitDescription;

		if (readAsJSONError) {
			logger.error("Error in reading incoming data");
			session.reject(readAsJSONError);
		} else {
			var jobtypeID = incomingdata.data[0].jobTypeID;
			var status = incomingdata.data[0].status;
			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "jobTypes.workflows",
							"id": jobtypeID,
							"status": status
						}
					]
				}
			}

			var url = lookupURL;
			var LookupServiceResponse = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var ctx = session.name("afjds") || session.createContext("afjds");
					var errorinfo = "urlopen connection error 'LookupServiceResponse' details are: " + info + "; error info: " + error;
					logger.error("urlopen connect error with  LookupServiceResponse" + JSON.stringify(error));
					//session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));

					ctx.setVariable("ExitDescription", errorinfo)
					ctx.setVariable("exitStatus", "500")
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var ctx = session.name("afjds") || session.createContext("afjds");
								var errorinfo = "failure in putting message to afjds 'LookupServiceResponse' details are: " + info + "; error info: " + error;
								logger.error("failure in putting message to afjds LookupServiceResponse" + JSON.stringify(error));
								//session.reject("failure in putting message to afjds LookupServiceResponse" + JSON.stringify(error));

								ctx.setVariable("ExitDescription", errorinfo)
								ctx.setVariable("exitStatus", responseStatusCode)
								session.reject(errorinfo);
							} else {
								var ctx = session.name("afjds") || session.createContext("afjds");
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from afjds LookupServiceResponse " + responseData);
								var lookupResponse = JSON.parse(responseData)

								ctx.setVariable("exitStatus", "0");
								ctx.setVariable("ExitDescription", ExitDescription);
								var lookupJobtypeLabel;
								if (lookupResponse.lookupRep.type[0].result == 0) {
									lookupJobtypeLabel = lookupResponse.lookupRep.type[0].label;
									ctx.setVariable("lookupJobtypeLabel", lookupJobtypeLabel);
									//inner lookup starts
									var aorId = incomingdata.data[0].aorID;
									var lookupMessage = {
										"lookupReq": {
											"type": [
												{
													"name": "aors",
													"id": aorId
												}
											]
										}
									}
									var url = lookupURL;
									var LookupServiceResponse = {
										target: url,
										method: 'POST',
										contentType: 'application/json',
										data: lookupMessage
									};

									var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
									urlopen.open(LookupServiceResponse, function(error, response) {
										if (error) {
											var ctx = session.name("afjds") || session.createContext("afjds");
											var errorinfo = "urlopen connect error with aors LookupService" + JSON.stringify(error) + info;
											logger.error("urlopen connect error with  LookupServiceResponse aors" + JSON.stringify(error));
											//session.reject("urlopen connect error with  LookupServiceResponse aors" + JSON.stringify(error));

											ctx.setVariable("exitStatus", "500");
											ctx.setVariable("ExitDescription", errorinfo);
											session.reject(errorinfo);
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var ctx = session.name("afjds") || session.createContext("afjds");
														var errorinfo = "failure in putting message to CrewType LookupServiceResponse " + JSON.stringify(error) + info;
														logger.error("failure in putting message to aorid LookupServiceResponse" + JSON.stringify(error));
														//session.reject("failure in putting message to aorid LookupServiceResponse" + JSON.stringify(error));
														ctx.setVariable("exitStatus", responseStatusCode);
														ctx.setVariable("ExitDescription", errorinfo);
														session.reject(errorinfo);
													} else {
														var ctx = session.name("afjds") || session.createContext("afjds");

														ctx.setVariable("exitStatus", "0");
														ctx.setVariable("ExitDescription", ExitDescription);
														hm.response.statusCode = responseStatusCode;
														logger.debug("response received from aorid LookupServiceResponse " + responseData);
														var lookupResponse = JSON.parse(responseData)
														var lookupAorIDlabel;
														if (lookupResponse.lookupRep.type[0].result == 0) {
															lookupAorIDlabel = lookupResponse.lookupRep.type[0].label;
															ctx.setVariable("lookupAorIDlabel", lookupAorIDlabel);

															//substypes lookup start
															var outageSubtypeID = incomingdata.data[0].outageSubtypeID;
															var lookupMessage = {
																"lookupReq": {
																	"type": [
																		{
																			"name": "outageSubtypes",
																			"id": outageSubtypeID
																		}
																	]
																}
															}

															var url = lookupURL;
															var LookupServiceResponse = {
																target: url,
																method: 'POST',
																contentType: 'application/json',
																data: lookupMessage
															};
															var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "Data: " + LookupServiceResponse + ". ";
															urlopen.open(LookupServiceResponse, function(error, response) {
																if (error) {
																	var ctx = session.name("afjds") || session.createContext("afjds");
																	var errorinfo = "urlopen connect error with outageSubtypes LookupServiceResponse" + JSON.stringify(error) + info;
																	logger.error("urlopen connect error with outageSubtypes LookupServiceResponse" + JSON.stringify(error));
																	//session.reject("urlopen connect error with outageSubtypes LookupServiceResponse" + JSON.stringify(error));

																	ctx.setVariable("exitStatus", "500");
																	ctx.setVariable("ExitDescription", errorinfo);
																	session.reject(errorinfo);
																} else {
																	var responseStatusCode = response.statusCode;
																	if (responseStatusCode == 200) {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var ctx = session.name("afjds") || session.createContext("afjds");
																				var errorinfo = "failure in putting message to outageSubtypes LookupServiceResponse" + JSON.stringify(error) + info;
																				logger.error("failure in putting message to outageSubtypes LookupServiceResponse" + JSON.stringify(error));
																				//session.reject("failure in putting message to outageSubtypes LookupServiceResponse" + JSON.stringify(error));

																				ctx.setVariable("exitStatus", responseStatusCode);
																				ctx.setVariable("ExitDescription", errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var ctx = session.name("afjds") || session.createContext("afjds");
																				hm.response.statusCode = responseStatusCode;
																				logger.debug("response received from outageSubtypes LookupServiceResponse " + responseData);
																				var lookupResponse = JSON.parse(responseData)

																				ctx.setVariable("exitStatus", "0");
																				ctx.setVariable("ExitDescription", ExitDescription);
																				var outageSubtypeslabel;
																				if (lookupResponse.lookupRep.type[0].result == 0) {
																					outageSubtypeslabel = lookupResponse.lookupRep.type[0].label;
																					logger.debug("outageSubtypeslabel is " + outageSubtypeslabel);

																					ctx.setVariable("outageSubtypeslabel", outageSubtypeslabel);
																				} else {
																					var ctx = session.name("afjds") || session.createContext("afjds");
																					var errorinfo = "lookup service outageSubtypeslabel result code " + info + " statusCode " + responseStatusCode + "; errorresponse info: " + responseData;
																					logger.error(" lookup service outageSubtypeslabel result code  is" + info + lookupResponse.lookupRep.type[0].result);
																					//session.reject(" lookup service outageSubtypeslabel result code  is" + lookupResponse.lookupRep.type[0].result);

																					ctx.setVariable("exitStatus", responseStatusCode);
																					ctx.setVariable("ExitDescription", errorinfo);
																					session.reject(errorinfo);
																				}
																			}
																		});
																	} else {
																		var ctx = session.name("afjds") || session.createContext("afjds");
																		var errorinfo = "lookup service responsecode outageSubtypeslabel label is " + JSON.stringify(error) + info;
																		logger.error(" lookup service responsecode outageSubtypeslabel label is " + info + outageSubtypeID + " " + responseStatusCode);
																		//session.reject("lookup service responsecode outageSubtypeslabel label is " + outageSubtypeID + " " + responseStatusCode);

																		ctx.setVariable("exitStatus", responseStatusCode);
																		ctx.setVariable("ExitDescription", errorinfo);
																		session.reject(errorinfo);
																	}
																}
															});
															//subtype lookup end
														}
														else {
															var ctx = session.name("afjds") || session.createContext("afjds");
															var errorinfo = "lookup service aorid result code  is " + JSON.stringify(error) + info;
															logger.error(" lookup service aorid result code  is" + info + lookupResponse.lookupRep.type[0].result);
															//session.reject(" lookup service aorid result code  is" + lookupResponse.lookupRep.type[0].result);
															ctx.setVariable("exitStatus", responseStatusCode);
															ctx.setVariable("ExitDescription", errorinfo);
															session.reject(errorinfo);
														}// lookup end;
													}
												});
											} else {
												var ctx = session.name("afjds") || session.createContext("afjds");
												//var errorinfo = "lookup service responsecode aorId label is  " + JSON.stringify(error) + info;
												var errorinfo = "lookup service responsecode aorId label is " + info + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
												logger.error(" lookup service responsecode aorId label is " + info + " " + responseStatusCode);
												//session.reject("lookup service responsecode aorId label is " + aorId + " " + responseStatusCode);

												ctx.setVariable("exitStatus", responseStatusCode);
												ctx.setVariable("ExitDescription", errorinfo);
												session.reject(errorinfo);
											}

										}
									});

									//inner lookup end		
								}
								else {
									var ctx = session.name("afjds") || session.createContext("afjds");
									var errorinfo = "lookup service jobtypeid label result code  is  " + JSON.stringify(error) + info;
									logger.error(" lookup service jobtypeid label result code  is" + lookupResponse.lookupRep.type[0].result);
									//session.reject(" lookup service jobtypeid label result code  is" + lookupResponse.lookupRep.type[0].result);

									ctx.setVariable("exitStatus", responseStatusCode);
									ctx.setVariable("ExitDescription", errorinfo);
									session.reject(errorinfo);
								}// lookup end;

							}
						});

					} else {
						var ctx = session.name("afjds") || session.createContext("afjds");
						//var errorinfo = "lookup service responsecode jobtypeid label is  " + JSON.stringify(error) + info;
						var errorinfo = "lookup service responsecode jobtypeid label is " + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
						logger.error(" lookup service responsecode jobtypeid label is " + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData);
						//session.reject("lookup service responsecode jobtypeid label is " + responseStatusCode);

						ctx.setVariable("exitStatus", responseStatusCode);
						ctx.setVariable("ExitDescription", errorinfo);
						session.reject(errorinfo);
					}
				}
			});
		}
	}
});
