var logger = console.options({
	'Category': 'all'
	
});
//var ctx = session.name("afjds") || session.createContext("afjds");
var ILSctx = session.name('afjds')|| session.createContext('afjds');
var EntryDescription = session.parameters.afjdsReceiveEntryDescription;
var ExitDescription = session.parameters.afjdsReceiveExitDescription;
var messageType = session.parameters.messageType;

if(messageType !== undefined || messageType !== null || messageType !==''){
	
	ILSctx.setVariable("messageType",messageType);
}
if(EntryDescription !== undefined || EntryDescription !== null || EntryDescription !== ''){
	ILSctx.setVariable("EntryDescription",EntryDescription);
}
if(ExitDescription !== undefined || ExitDescription !== null || ExitDescription !== ''){
	ILSctx.setVariable("ExitDescription",ExitDescription);
}
session.input.readAsJSON(function(readAsJSONError, incomingdata){
	if(readAsJSONError) {
		logger.error("Error in reading incomingdata");
		session.reject(readAsJSONError);
	} else {
		 
		  /* function uuidv4() {
	       return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		   var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		   return v.toString(16);
	    });

	       var correlationID = uuidv4();
	       if (correlationID !== undefined) {
		    ILSctx.setVariable('correlationID', correlationID);
		  }*/
		
		if (incomingdata.messageID !== undefined || incomingdata.messageID !== null || incomingdata.messageID !== '') {
				ILSctx.setVariable("correlationID", incomingdata.messageID);
			} 
			if (incomingdata.data[0].displayID !== undefined || incomingdata.data[0].displayID !== null || incomingdata.data[0].displayID !== '') {
				ILSctx.setVariable("jobDisplayID", incomingdata.data[0].displayID);
			}
			
			if (incomingdata.data[0].id !== undefined || incomingdata.data[0].id !== null || incomingdata.data[0].id !== '') {
				ILSctx.setVariable("jobID", incomingdata.data[0].id);
			}
			
			if (incomingdata.data[0].updatedAt !== undefined || incomingdata.data[0].updatedAt !== null || incomingdata.data[0].updatedAt !== '') {
				ILSctx.setVariable("sourceEventTimestamp", incomingdata.data[0].updatedAt);
			}
	}
	
	});
	
