var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("afjds") || session.createContext("afjds");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("afjds") || session.createContext("afjds");
	//var ILSctx = session.name("afjds") || session.createContext("afjds");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	var ExitDescription = session.parameters.afjdsReceiveExitDescription;

	//ctx.setVariable("exitDestination", omsExternalURL)
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {


		if (incomingdata.data[0].leadCallID != undefined) {
			var leadCallID = incomingdata.data[0].leadCallID;
			var Callapiuri = omsExternalURL + 'Call/' + leadCallID;
			var TokenValue = apiToken;

			var Callapi = {
				target: Callapiuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},

			};

			var info = " TargetURL: " + Callapi.target + "; Method: " + Callapi.method + ". ";
			urlopen.open(Callapi, function(error, response) {
				if (error) {
					var ctx = session.name("afjds") || session.createContext("afjds");
					var errorinfo = "urlopen connect error with GET Call api for leadCallID : " + info + "; error info: " + error;
					ctx.setVariable("ExitDescription", errorinfo);
					ctx.setVariable("exitStatus", "500")
					ctx.setVariable("retry", 'yes');
					logger.error(errorinfo);
					var ErrorTxt = "afjds_002 urlopen connect error with GET Call api for leadCallID " + leadCallID + " " + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var ctx = session.name("afjds") || session.createContext("afjds");
								//dp:reject stop the transaction and go error rule with error code and description
								var errorinfo = "error message from Callapi for leadCallID: " + info + "; error info: " + error;
								ctx.setVariable("ExitDescription", errorinfo);
								ctx.setVariable("exitStatus", responseStatusCode)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var ctx = session.name("afjds") || session.createContext("afjds");
								//store status code with response body in context variable
								ctx.setVariable("exitStatus", "0")
								ctx.setVariable("ExitDescription", ExitDescription)
								ctx.setVariable("exitDestination", omsExternalURL)
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from Callapi for leadCallID:" + leadCallID + "is :" + responseStatusCode);
								//var ctx = session.name("afjds") || session.createContext("afjds");
								var externalCallCodeID;
								if (responseData.externalCallCodeID != undefined || responseData.externalCallCodeID != '' || responseData.externalCallCodeID != null) {
									externalCallCodeID = JSON.parse(responseData).externalCallCodeID;
								} else {
									externalCallCodeID = '';
								}
								ctx.setVariable("externalCallCodeID", externalCallCodeID);
							}
						});
					} else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var ctx = session.name("afjds") || session.createContext("afjds");
									var errorinfo = "afjds_013: Unauthorized Error returned from Callapi with for LeadCallid' 'Authentication/Authentication Error', details are : " + info + "; error info :" + error;
									ctx.setVariable('ExitDescription', errorinfo);
									ctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var ctx = session.name("afjds") || session.createContext("afjds");
									var errorinfo = "afjds_013: Unauthorized  Error returned from Callapi with for LeadCallid' 'Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ctx.setVariable('ExitDescription', errorinfo);
									ctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							})
						}else {
						var ctx = session.name("afjds") || session.createContext("afjds");
						//var errorinfo = "Error returned from Callapi with for LeadCallid " + info + "; error info: " + error;
						var errorinfo = "Error returned from Callapi with for LeadCallid "+leadCallID+" statusCode " + responseStatusCode
						ctx.setVariable("ExitDescription", errorinfo);
						ctx.setVariable("exitStatus", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				}
			});
		} else {
			var ctx = session.name("afjds") || session.createContext("afjds");
			var externalCallCodeID = '';
			ctx.setVariable("externalCallCodeID", externalCallCodeID);
		}
	}

});
