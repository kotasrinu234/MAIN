//js is used to perform a lookup calls
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	var ctx = session.name("afjds") || session.createContext("afjds");
	var retry = ctx.getVar("retry");
	if (retry != 'yes') {
		var ODMResponse = ctx.getVar("odmresponse");
		var ODMResponseCheck = JSON.stringify(ODMResponse);
		if (ODMResponseCheck == 'true') {
			// getting styleheet params
			var ctx = session.name("afjds") || session.createContext("afjds");
			var lookupURL = ctx.getVar("lookupURL");
			var omsExternalURL = ctx.getVar("omsExternalURL");
			var apiToken = ctx.getVar("apiToken");

			if (readAsJSONError) {
				logger.error("Error in reading incoming data");
				session.reject(readAsJSONError);
			} else {

				var ctx = session.name("afjds") || session.createContext("afjds");
				var followuplabel = ctx.getVar("followuplabel");
				var lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "jobTypes",
								"label": followuplabel
							}
						]
					}
				}

				var url = lookupURL;
				var LookupServiceResponse = {
					target: url,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};

				var info = " TargetURL :" + url.target + "; Method :" + url.method + "; Data :" + JSON.stringify(url.data) + ". ";

				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var ctx = session.name("afjds") || session.createContext("afjds");
						var errorinfo = "afjds_011 urlopen connect error with jobTypes with label Followup LookupServiceResponse: " + info + "; error info: " + error;
						logger.error("afjds_011 urlopen connect error with jobTypes with label Followup LookupServiceResponse " + JSON.stringify(error));
						//session.reject("urlopen connect error with jobTypes with label Followup LookupServiceResponse " + JSON.stringify(error));
						ctx.setVariable("ExitDescription", errorinfo);
						ctx.setVariable("exitStatus", "500");
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var ctx = session.name("afjds") || session.createContext("afjds");
									var errorinfo = "failure in reading message from jobTypeid LookupServiceResponse: " + info + "; error info: " + error;
									logger.error("failure in reading message from jobTypeid LookupServiceResponse" + JSON.stringify(error));
									//session.reject(" failure in reading message from jobTypeid LookupServiceResponse" + JSON.stringify(error));
									ctx.setVariable("ExitDescription", errorinfo);
									ctx.setVariable("exitStatus", responseStatusCode);
									session.reject(errorinfo);

								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from jobTypeid LookupServiceResponse " + responseData);
									var lookupResponse = JSON.parse(responseData)

									var ctx = session.name("afjds") || session.createContext("afjds");
									var lookupJobtypeid;
									if (lookupResponse.lookupRep.type[0].result == 0) {
										lookupJobtypeid = lookupResponse.lookupRep.type[0].id;
										logger.debug("lookupJobtypeid is " + lookupJobtypeid);
										ctx.setVariable("lookupJobtypeid", lookupJobtypeid);

										//inner lookup starts
										var ctx = session.name("afjds") || session.createContext("afjds");
										var DTEAssociatedlabel = ctx.getVar("DTEAssociatedlabel");
										var lookupMessage = {
											"lookupReq": {
												"type": [
													{
														"name": "linkTypes",
														"label": DTEAssociatedlabel
													}
												]
											}
										}
										var url = lookupURL;
										var LookupServiceResponse = {
											target: url,
											method: 'POST',
											contentType: 'application/json',
											data: lookupMessage
										};
										var info = " TargetURL :" + url.target + "; Method :" + url.method + "; Data :" + JSON.stringify(url.data) + ". ";

										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												var ctx = session.name("afjds") || session.createContext("afjds");
												var errorinfo = "afjds_012 urlopen connect error for linkTypes with label DTE - Associated  is: " + info + "; error info: " + error;
												logger.error("afjds_012 urlopen connect error for linkTypes with label DTE - Associated  is " + JSON.stringify(error));
												//session.reject("urlopen connect error for linkTypes with label DTE - Associated  is " + JSON.stringify(error));
												ctx.setVariable("ExitDescription", errorinfo);
												ctx.setVariable("exitStatus", "500");
												session.reject(errorinfo);
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var ctx = session.name("afjds") || session.createContext("afjds");
															var errorinfo = "failure in reading message from linkTypes LookupServiceResponse: " + info + "; error info: " + error;
															logger.error(" failure in reading message from linkTypes LookupServiceResponse " + JSON.stringify(error));
															//session.reject(" failure in reading message from linkTypes LookupServiceResponse " + JSON.stringify(error));
															ctx.setVariable("ExitDescription", errorinfo);
															ctx.setVariable("exitStatus", responseStatusCode);
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response received from linkTypes LookupServiceResponse " + responseData);
															var lookupResponse = JSON.parse(responseData)

															var ctx = session.name("afjds") || session.createContext("afjds");
															var linkTypesid;
															if (lookupResponse.lookupRep.type[0].result == 0) {
																linkTypesid = lookupResponse.lookupRep.type[0].id;
																logger.debug("linkTypesid is " + linkTypesid);
																ctx.setVariable("linkTypesid", linkTypesid);
															}
															else {
																var ctx = session.name("afjds") || session.createContext("afjds");
																var errorinfo = "lookup service linkTypesid result code  is: " + info + "; error info: " + error;
																logger.error("lookup service linkTypesid result code  is " + lookupResponse.lookupRep.type[0].result);
																//session.reject ("lookup service linkTypesid result code  is "+lookupResponse.lookupRep.type[0].result);
																ctx.setVariable("ExitDescription", errorinfo);
																ctx.setVariable("exitStatus", "500");
																session.reject(errorinfo);
															}// lookup end;
														}
													});
												} else {
													var ctx = session.name("afjds") || session.createContext("afjds");
													//var errorinfo = "lookup service responsecode linkTypesid label is: " + info + "; error info: " + error;
													var errorinfo = "lookup service responsecode linkTypesid label is:" + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
													logger.error("lookup service responsecode linkTypesid label is " + responseStatusCode);
													//session.reject (" lookup service responsecode linkTypesid label is "+responseStatusCode);
													ctx.setVariable("ExitDescription", errorinfo);
													ctx.setVariable("exitStatus", responseStatusCode);
													session.reject(errorinfo);
												}

											}
										});

										//inner lookup end		
									}
									else {
										var ctx = session.name("afjds") || session.createContext("afjds");
										var errorinfo = "lookup service jobtypeid label result code  is: " + info + "; error info: " + error;
										logger.error(" lookup service jobtypeid label result code  is " + lookupResponse.lookupRep.type[0].result);
										//session.reject (" lookup service jobtypeid label result code  is "+lookupResponse.lookupRep.type[0].result);
										ctx.setVariable("ExitDescription", errorinfo);
										ctx.setVariable("exitStatus", responseStatusCode);
										session.reject(errorinfo);
									}// lookup end;

								}
							});

						} else {
							var ctx = session.name("afjds") || session.createContext("afjds");
							//var errorinfo = "lookup service responsecode jobtypeid label is: " + info + "; error info: " + error;
							var errorinfo = "lookup service responsecode jobtypeid label is: " + jobid + " statusCode " + responseStatusCode + "  " + info + "; errorresponse info: " + responseData;
							logger.error(" lookup service responsecode jobtypeid label is " + responseStatusCode);
							//session.reject ("lookup service responsecode jobtypeid label is "+responseStatusCode);
							ctx.setVariable("ExitDescription", errorinfo);
							ctx.setVariable("exitStatus", responseStatusCode);
							session.reject(errorinfo);
						}
					}
				});
			}
		}
	}
});
