# esb-pf-outageManagement-autoFollowupJobDetection-dp
Deployment instructions:

ESBMQ scripts are uploaded in esb-pf-outageManagement-autoFollowupJobDetection-mq repository.

MQCSP details will be given by DTE ESB team.

Password aliases will be created by DTE ESB team.

Private keys and certs need to be provided by DTE ESB team.

Backend Url's need to confirmed for oms and odm for load and prod

Properties file as per env are in the config folder of this repository.

Jenkins file as per env are also uploaded in this repository.
