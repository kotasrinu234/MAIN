<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:msg="http://esm.dteco.com/common/v1" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
	<xsl:param name="dpconfig:entryDescription" select="''" />
	<xsl:variable name="ILSEntryDescription" select="$dpconfig:entryDescription" />
	<xsl:param name="dpconfig:exitDescription" select="''" />
	<xsl:variable name="ILSExitDescription" select="$dpconfig:exitDescription" />
	
	
		<xsl:template match="/">
		<xsl:variable name="IncomingPayload">
			<xsl:copy-of select="."/>
		</xsl:variable>
		<dp:set-variable name="'var://context/PONPRN/IncomingPayload'" value="$IncomingPayload" />
		
		<xsl:variable name="MeterException" select="$IncomingPayload/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']"/>
		<xsl:variable name="CorrelationID" select="./*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='CorrelationID']"/>
		<xsl:variable name="ElectronicSerialNumber" select="$MeterException/*[local-name()='ElectronicSerialNumber']"/>
		<xsl:variable name="alarmType" select="$MeterException/*[local-name()='Name']"/>
		<xsl:variable name="sourceEventTimestamp" select="$MeterException/*[local-name()='Timestamp']" />
		
		<dp:set-variable name="'var://context/PONPRN/ElectronicSerialNumber'" value="string($ElectronicSerialNumber)" />
		<dp:set-variable name="'var://context/PONPRN/alarmType'" value="string($alarmType)" />
		<dp:set-variable name="'var://context/PONPRN/origEventTime'" value="string($sourceEventTimestamp)" />
		
		
		<xsl:variable name="entriesMQRFH2" select="dp:request-header('MQRFH2')" />
		<xsl:if test="normalize-space($entriesMQRFH2)!=''">
			<xsl:variable name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)" />
			<!-- Placing the MQMD headers in the context variables -->

			<dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value="$mqrfh2-headers" />
			<xsl:value-of select="$request" disable-output-escaping="yes" />
			<dp:set-http-request-header name="'Content-Type'" value="'application/json'" />
		</xsl:if>
		
		<xsl:if test="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')">
			<xsl:variable name="mqrfh2" select="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')" />
			<xsl:variable name="ProblemCode" select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='ProblemCode'])" />
			<xsl:variable name="EventType" select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='EventType'])" />

			<dp:set-variable name="'var://context/PONPRN/ProblemCode'" value="$ProblemCode" />
			<dp:set-variable name="'var://context/ILS/ILSProblemCode'" value="$ProblemCode" />
			<dp:set-variable name="'var://context/PONPRN/EventType'" value="$EventType" />
		</xsl:if>
	
		<xsl:choose>
			<xsl:when test="normalize-space($EventType) != ''">
				<dp:set-variable name="'var://context/ILS/ILSEventType'" value="string($EventType)"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:if test="$alarmType = 'Primary Power Down'">
					<dp:set-variable name="'var://context/ILS/ILSEventType'" value="'Outage'"/>
				</xsl:if>
				<xsl:if test="$alarmType = 'Primary Power Up'">
					<dp:set-variable name="'var://context/ILS/ILSEventType'" value="'Restoration'"/>
				</xsl:if>
			</xsl:otherwise>
		</xsl:choose>
		
		<xsl:variable name="ILSEventType" select="dp:variable('var://context/ILS/ILSEventType')"/>
		<xsl:variable name="ILSProblemCode" select="dp:variable('var://context/ILS/ILSProblemCode')"/>
		<xsl:variable name="ILSEntryDescription">
			<xsl:value-of select="concat($ILSEntryDescription ,' ', $ILSEventType, ': ', $ILSProblemCode)"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/ILSEntryDescription'" value="string($ILSEntryDescription)"/>
		<dp:set-variable name="'var://context/ILS/CorrelationID'" value="string($CorrelationID)" />
	    <dp:set-variable name="'var://context/ILS/ElectronicSerialNumber'" value="string($ElectronicSerialNumber)" />
		<dp:set-variable name="'var://context/ILS/alarmType'" value="string($alarmType)" />
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="string($sourceEventTimestamp)" />
		<dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)" />

	</xsl:template>
</xsl:stylesheet>