var ctx = session.name("PONPRN") || session.createContext("PONPRN");
var logAzurePayload = ctx.getVariable('logAzurePayload')
if (logAzurePayload === "yes") {
	var azurePaylodAsXML = "<azurePayload>" + JSON.stringify(ctx.getVariable('azurePayload')) + "</azurePayload>"
	session.output.write(azurePaylodAsXML)
}