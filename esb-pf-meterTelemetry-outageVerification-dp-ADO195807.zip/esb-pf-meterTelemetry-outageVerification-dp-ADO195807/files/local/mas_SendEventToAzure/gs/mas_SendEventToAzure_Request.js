var urlopen = require('urlopen');
var sm = require('service-metadata')
var logger = console.options({ 'category': 'all' });
var ctx = session.name("PONPRN") || session.createContext("PONPRN");
var ILSctx = session.name("ILS") || session.createContext("ILS");
sm.setVar("var://service/mpgw/skip-backside", true)

var ExitDescription = session.parameters.exitDescription;
var ILSEventType = ILSctx.getVariable("ILSEventType");
var ILSProblemCode = ILSctx.getVariable("ILSProblemCode");

var EventType = ''
var ProblemCode = ''
var Description = ''

if (ILSEventType === undefined || ILSEventType === null || ILSEventType === "") {
} else {
	EventType = ILSEventType
}
if (ILSProblemCode === undefined || ILSProblemCode === null || ILSProblemCode === "") {
} else {
	ProblemCode = ILSProblemCode
}
if (ExitDescription === undefined || ExitDescription === null || ExitDescription === "") {
} else {
	Description = ExitDescription
}

var ILSExitDescription = Description + ' ' + EventType + ": " + ProblemCode
var date = new Date();

var AzurePayload = {
	"eventType": "MeterAlarm",
	"eventTime": date.toISOString(),
	"data": {}
}

AzurePayload.data.meterId = ctx.getVariable("ElectronicSerialNumber")

if (ctx.getVariable("alarmType") != undefined || ctx.getVariable("alarmType") != '') {
	AzurePayload.data.alarmType = ctx.getVariable("alarmType")
}

if (ctx.getVariable("origEventTime") != undefined || ctx.getVariable("origEventTime") != '') {
	var origEventTime = ctx.getVariable("origEventTime")
	var trimmedOrigEventTime = origEventTime.substring(0, 19) + "Z"
	AzurePayload.data.origEventTime = trimmedOrigEventTime
}

AzurePayload.data.problemCode = "Normal"
if (ProblemCode != '') {
	AzurePayload.data.problemCode = ProblemCode
}

ctx.setVariable("azurePayload", AzurePayload)

var getTokenUrl = session.parameters.getTokenUrl
var Options = {
	target: getTokenUrl,
	method: 'GET',
	contentType: 'application/json',
};

var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
urlopen.open(Options, function(error, response) {
	if (error) {
		var errorinfo = "PONPRN_017 : url connection error 'Token Call', details are :" + info + "; error info :" + error;
		ILSctx.setVariable("exitDescription", errorinfo);
		ILSctx.setVariable("exitStatus", "500");
		ILSctx.setVariable("exitDestination", getTokenUrl);
		logger.error(errorinfo);
		ctx.setVariable("retry", 'yes');
		ctx.setVariable("ErrorTxt", errorinfo);
	} else {
		var responseStatusCode = response.statusCode;
		if (responseStatusCode === 200) {
			response.readAsJSON(function(error, responseData) {
				if (error) {
					var errorinfo = "error reading response 'Token Call', details are : " + info + "; error info :" + error
					ILSctx.setVariable("exitDescription", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var AccessToken = responseData.access_token;
					if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
						var errorinfo = "PONPRN_018 : Invalid token received, details are : " + info
						ILSctx.setVariable("exitDescription", errorinfo);
						ILSctx.setVariable("exitStatus", responseStatusCode);
						ILSctx.setVariable("exitDestination", getTokenUrl);
						logger.error(errorinfo);
						ctx.setVariable("retry", 'yes');
						ctx.setVariable("ErrorTxt", errorinfo);
					} else {
						var tokenRecieved = "<tokenRecieved>true</tokenRecieved>"
						ILSctx.setVariable("tokensExitDestination", getTokenUrl);
						ILSctx.setVariable("tokensExitDescription", session.parameters.tokensExitDescription);
						session.output.write(XML.parse(tokenRecieved))
						var azureURL = session.parameters.azureURL
						var TokenType = responseData.token_type;
						var Token = TokenType + ' ' + AccessToken;
						
						ctx.setVariable("logAzurePayload", "yes")
						
						var Options = {
							target: azureURL,
							sslClientProfile: 'mas_SendEventToAzure_tls_client_profile',
							method: 'POST',
							headers: {
								'Authorization': Token,
							},
							contentType: 'application/x-www-form-urlencoded',
							data: AzurePayload
						}

						var info = " TargetURL :" + Options.target + "; Method :" + Options.method + "; Data :" + JSON.stringify(Options.data) + ". ";
						urlopen.open(Options, function(error, response) {
							if (error) {
								var errorinfo = "PONPRN_019 : url connection error 'Azure Call', details are :" + info + "; error info :" + error;
								ILSctx.setVariable("exitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", "500");
								ILSctx.setVariable("exitDestination", azureURL);
								logger.error(errorinfo);
								ctx.setVariable("retry", 'yes');
								ctx.setVariable("ErrorTxt", errorinfo);
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode === 200 || responseStatusCode === 201) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'Azure Call' , details are : " + eventHubCallInfo + "; error info :" + error;
											ILSctx.setVariable("exitDescription", errorinfo);
											ILSctx.setVariable("exitStatus", "500");
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											ILSctx.setVariable("exitDestination", azureURL);
											ILSctx.setVariable("exitDescription", ILSExitDescription);
											ILSctx.setVariable("exitStatus", "0");
										}
									});
								} else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'Azure Call', details are : " + info + "; error info :" + error
											ILSctx.setVariable("exitDescription", errorinfo);
											ILSctx.setVariable("exitStatus", "500");
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "PONPRN_020 : error response 'Azure Call', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable("exitDescription", errorinfo);
											ILSctx.setVariable("exitStatus", responseStatusCode);
											ILSctx.setVariable("exitDestination", azureURL);
											logger.error(errorinfo);
											ctx.setVariable("retry", 'yes');
											ctx.setVariable("ErrorTxt", errorinfo);
										}
									});
								}
							}
						});
					}
				}
			});
		} else {
			response.readAsBuffer(function(error, responseData) {
				if (error) {
					var errorinfo = "error reading response 'Token Call', details are : " + info + "; error info :" + error
					ILSctx.setVariable("exitDescription", errorinfo);
					ILSctx.setVariable("exitStatus", "500");
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var errorinfo = "PONPRN_021 : error response 'Token Call', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable("exitDescription", errorinfo);
					ILSctx.setVariable("exitStatus", responseStatusCode);
					ILSctx.setVariable("exitDestination", getTokenUrl);
					logger.error(errorinfo);
					ctx.setVariable("retry", 'yes');
					ctx.setVariable("ErrorTxt", errorinfo);
				}
			});
		}
	}
});
