<!-- This xslt is used to invoke job oms api and get the response -->
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:msg="http://esm.dteco.com/common/v1"
	extension-element-prefixes="dp date"
	exclude-result-prefixes="dp dpconfig">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes" />
	
	<xsl:param name="dpconfig:Entrydescription" select="''" />
	<xsl:variable name="Entrydescription" select="$dpconfig:Entrydescription" />
    <xsl:param name="dpconfig:RMmessageType" select="''" />
	<xsl:variable name="RMmessageType" select="$dpconfig:RMmessageType" />

	<xsl:template match="/">
		<xsl:variable name="IncomingPayload">
			<xsl:copy-of select="." />
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/IncomingPayload'"
			value="$IncomingPayload" />
			<xsl:variable name="MeterException" select="$IncomingPayload/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']" />
		    <xsl:variable name="CorrelationID" select="./*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='CorrelationID']" />
			<xsl:variable name="ElectronicSerialNumber" select="$MeterException/*[local-name()='ElectronicSerialNumber']" />
			<xsl:variable name="alarmType" select="$MeterException/*[local-name()='Name']" />
			<xsl:variable name="sourceEventTimestamp" select="$MeterException/*[local-name()='Timestamp']" />
			
            <xsl:variable name="inputString" select="$ElectronicSerialNumber" />
            <xsl:variable name="delimiter" select="'.'" />
            <xsl:variable name="reversedString">
              <xsl:call-template name="reverse-string">
                <xsl:with-param name="string" select="$inputString" />
              </xsl:call-template>
            </xsl:variable>
            <xsl:variable name="reversedSplitString">
              <xsl:value-of select="substring-before($reversedString, $delimiter)" />
            </xsl:variable>
            <xsl:variable name="splitString">
               <xsl:call-template name="reverse-string">
                <xsl:with-param name="string" select="$reversedSplitString" />
               </xsl:call-template>
            </xsl:variable>

			<dp:set-variable name="'var://context/ILS/CorrelationID'" value="string($CorrelationID)" />
			<dp:set-variable name="'var://context/ILS/ElectronicSerialNumber'" value="string($ElectronicSerialNumber)" />
			<dp:set-variable name="'var://context/ILS/alarmType'" value="string($alarmType)" />
			<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="string($sourceEventTimestamp)" />
			<dp:set-variable name="'var://context/ILS/MeterID'" value="string($splitString)" />
			<dp:set-variable name="'var://context/ILS/description'" value="string($Entrydescription)" /> 
            <dp:set-variable name="'var://context/ILS/MessageType'" value="string($RMmessageType)" />
			<dp:set-variable name="'var://context/ILS/Exitdescription'" value="' '" />
			<dp:set-variable name="'var://context/PONPRN/MeterID'" value="string($splitString)" />

</xsl:template>
	
<xsl:template name="reverse-string">
  <xsl:param name="string" />
  <xsl:choose>
    <xsl:when test="string-length($string) = 0">
      <xsl:value-of select="$string" />
    </xsl:when>
    <xsl:otherwise>
      <xsl:call-template name="reverse-string">
        <xsl:with-param name="string" select="substring($string, 2)" />
      </xsl:call-template>
      <xsl:value-of select="substring($string, 1, 1)" />
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>
	
</xsl:stylesheet>