<!-- This xslt is used to invoke job oms api and get the response -->
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:msg="http://esm.dteco.com/common/v1"
	extension-element-prefixes="dp date"
	exclude-result-prefixes="dp dpconfig">

	<xsl:output method="xml" indent="yes"
		omit-xml-declaration="yes" />
    <xsl:param name="dpconfig:PowerDOWN" select="''" />
    <xsl:variable name="DefaultPowerDOWN" select="$dpconfig:PowerDOWN" />

	<xsl:template match="/">

		<xsl:variable name="IncomingPayload">
			<xsl:copy-of select="." />
		</xsl:variable>
		<dp:set-variable name="'var://context/PONPRN/IncomingPayload'"
			value="$IncomingPayload" />

			<xsl:variable name="IncomingTimeStamp">
			<xsl:value-of select="./*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']/*[local-name()='Timestamp']" />
		    </xsl:variable>
			<dp:set-variable name="'var://context/PONPRN/IncomingTimeStamp'"
			value="string($IncomingTimeStamp)" />
			<xsl:variable name="IncomingElectronicSerialNumber">
			<xsl:value-of select="./*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']/*[local-name()='ElectronicSerialNumber']" />
		    </xsl:variable>
			<dp:set-variable name="'var://context/PONPRN/IncomingElectronicSerialNumber'"
			value="string($IncomingElectronicSerialNumber)" />
			<xsl:variable name="IncomingPowerStatus">
			<xsl:value-of select="./*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']/*[local-name()='Name']" />
		    </xsl:variable>

        <xsl:variable name="MeterID">
            <xsl:value-of select="dp:variable('var://context/PONPRN/MeterID')" />
        </xsl:variable>
			<dp:set-variable name="'var://context/PONPRN/IncomingPowerStatus'"
			value="string($IncomingPowerStatus)" />

    <xsl:variable name="MeterException" select="$IncomingPayload/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']" />
          <xsl:choose>
            <xsl:when test="$IncomingPowerStatus = $DefaultPowerDOWN">
                        <xsl:variable name="Payload">
                            <s:Envelope
                                xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
                                <s:Header>
                                    <X-dynaTrace
                                        xmlns="http://ns.dynatrace.com/wcf">
                                        <xsl:value-of select="$IncomingPayload/*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='X-dynaTrace']" />
                                    </X-dynaTrace>
                                    <msg:CorrelationID
                                        xmlns:msg="http://esm.dteco.com/common/v1">
                                        <xsl:value-of select="$IncomingPayload/*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='CorrelationID']" />
                                    </msg:CorrelationID>
                                </s:Header>
                                <s:Body>
                                    <ExceptionsArrived
                                        xmlns="http://www.itron.com/ami/2009/08/subscriptions">
                                        <input
                                            xmlns:i="http://www.w3.org/2001/XMLSchema-instance">
                                            <MeterExceptionCollection>
                                                <MeterException>
                                                    <ElectronicSerialNumber>
                                                        <xsl:value-of select="$MeterID" />
                                                    </ElectronicSerialNumber>
                                                    <ReceivedWhen>
                                                        <xsl:value-of select="$MeterException/*[local-name()='ReceivedWhen']" />
                                                    </ReceivedWhen>
                                                    <ExceptionCategory>
                                                        <xsl:value-of select="$MeterException/*[local-name()='ExceptionCategory']" />
                                                    </ExceptionCategory>
                                                    <Name>
                                                        <xsl:value-of select="$MeterException/*[local-name()='Name']" />
                                                    </Name>
                                                    <ID>
                                                        <xsl:value-of select="$MeterException/*[local-name()='ID']" />
                                                    </ID>
                                                    <Arguments
                                                        xmlns:a="http://www.itron.com/ami/2008/10/events">
                                                        <a:Argument>
                                                            <a:Name>
                                                                <xsl:value-of select="$MeterException/*[local-name()='Arguments']/*[local-name()='Argument']/*[local-name()='Name']" />
                                                            </a:Name>
                                                            <a:Value
                                                                xmlns:b="http://www.w3.org/2001/XMLSchema"
																i:type="b:unsignedShort">
                                                                <xsl:value-of select="$MeterException/*[local-name()='Arguments']/*[local-name()='Argument']/*[local-name()='Value']" />
                                                            </a:Value>
                                                        </a:Argument>
                                                    </Arguments>
                                                    <Timestamp>
                                                        <xsl:value-of select="$MeterException/*[local-name()='Timestamp']" />
                                                    </Timestamp>
                                                </MeterException>
                                            </MeterExceptionCollection>
                                        </input>
                                    </ExceptionsArrived>
                                </s:Body>
                            </s:Envelope>
                        </xsl:variable>
                        <dp:set-variable name="'var://context/PONPRN/OMSQueuePayload'" value="$Payload" />
            </xsl:when>
        </xsl:choose>
	</xsl:template>
</xsl:stylesheet>