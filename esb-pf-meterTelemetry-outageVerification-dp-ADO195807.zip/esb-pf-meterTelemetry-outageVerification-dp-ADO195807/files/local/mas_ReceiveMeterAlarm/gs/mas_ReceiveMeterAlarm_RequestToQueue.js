var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("PONPRN") || session.createContext("PONPRN");
var ILSctx = session.name("ILS") || session.createContext("ILS");

var OMSQueuePayload = ctx.getVariable("OMSQueuePayload");
var DBQueuePayload = ctx.getVariable("IncomingPayload");
var OMSQueueURL = session.parameters.OMSQueueURL;
var DBQueueURL = session.parameters.DBQueueURL
var SMAExitdescription = session.parameters.SMAExitdescription
var STOExitdescription = session.parameters.STOExitdescription
var DeadbandDescription = session.parameters.DeadbandDescription

var IncomingPowerStatus = ctx.getVariable("IncomingPowerStatus")
var DefaultPowerUP = session.parameters.PowerUP
var DefaultPowerDOWN = session.parameters.PowerDOWN
var DefaultProblemCode = session.parameters.DefaultProblemCode;
var DefaultEventType = session.parameters.DefaultEventType;
var DBQueueCall;
var OMSQueueCall;
var QueueName;
const Y1 = session.parameters.Y1
const Y2 = session.parameters.Y2
const dateTime = new Date();
ctx.setVariable("dateTime", dateTime.toISOString())


if (IncomingPowerStatus !== null || IncomingPowerStatus !== undefined || IncomingPowerStatus !== "") {

	if (IncomingPowerStatus === DefaultPowerUP) {
		DBQueueCall = "Yes"
		QueueName = "MAS.FIELD.TO.CEP "
		ILSctx.setVariable("ExitDestination", DBQueueURL)
		ILSctx.setVariable("Exitdescription", SMAExitdescription)
	} else {
		if (IncomingPowerStatus === DefaultPowerDOWN) {
			const SubstractTime = subMinutesToZuluTime(dateTime, Y1)
			ctx.setVariable("SubstractTime", SubstractTime)

			const AddTime = addMinutesToZuluTime(dateTime, Y2)
			ctx.setVariable("AddTime", AddTime)

			const time = ctx.getVariable("IncomingTimeStamp")

			if (isTimeBetween(SubstractTime, AddTime, time)) {
				ctx.setVariable("TimeRange", "The time is within the specified range")
				DBQueueCall = "Yes"
				QueueName = "MAS.FIELD.TO.CEP "
				ILSctx.setVariable("ExitDestination", DBQueueURL)
				ILSctx.setVariable("Exitdescription", SMAExitdescription)
			} else {
				OMSQueueCall = "Yes"
				QueueName = "MAS.SEND.TO.OMS "
				var FinalDescription = STOExitdescription + DeadbandDescription
				ILSctx.setVariable("Exitdescription", FinalDescription)
				ILSctx.setVariable("ExitDestination", OMSQueueURL)
				ctx.setVariable("TimeRange", "The time is outside the specified range")
			}
		}
	}
}

if (OMSQueueCall === "Yes") {
	var mqmd = {
		MQMD: {
			StrucId: {
				$: 'MD  '
			},
			Format: {
				$: 'MQHRF2  '
			},
			MsgType: {
				$: '8'
			},
			Persistence: {
				$: '1'
			},
			ReplyToQ: {
				$: '  PlaceHolderReplyToQ  '
			}
		}
	};
	var mqrfh2 = {
		MQRFH2: {
			Version: {
				$: '2'
			},
			Format: {
				$: 'MQSTR'
			},
			NameValueData: {
				NameValue: [{
					usr: {
						ProblemCode: {
							$: DefaultProblemCode
						}, EventType: {
							$: DefaultEventType
						},
					}
				}]
			}
		}
	};
	var urlopenHeaders = {
		MQMD: mqmd,
		MQRFH2: mqrfh2

	};
	ctx.setVariable('urlopenHeaders', urlopenHeaders);
	var options = {
		target: OMSQueueURL,
		headers: urlopenHeaders,
		contentType: 'application/xml',
		method: 'POST',
		data: OMSQueuePayload,
	};
	QueueCall(options)
}
if (DBQueueCall == "Yes") {
	var options = {
		target: DBQueueURL,
		contentType: 'application/xml',
		method: 'POST',
		data: DBQueuePayload,
	};
	QueueCall(options)
}
function QueueCall(options) {
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				hm.response.statusCode = 500
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "PONPRN_001 : Error encountered while attempting to send a message to the queue named " + QueueName + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				logger.error("PONPRN_001 : Error encountered while attempting to send a message to the queue named " + QueueName + error);
				ILSctx.setVariable("Exitdescription", ErrorTxt)
				ILSctx.setVariable("ExitStatus", "500")
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							ILSctx.setVariable("Exitdescription", "Error returned form Queue response")
							ILSctx.setVariable("ExitStatus", "500")
						} else {
							ILSctx.setVariable("ExitStatus", "0")
						}
					});
				} else {
					hm.response.statusCode = 500
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = "PONPRN_001 : Error encountered while attempting to send a message to the queue named " + QueueName + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
					logger.error("PONPRN_001 : Error encountered while attempting to send a message to the queue named " + QueueName + "[MQRC=" + mqrc + "]");
					ILSctx.setVariable("Exitdescription", ErrorTxt)
					ILSctx.setVariable("ExitStatus", "500")
				}
			}
		});
	} catch (err) {
		hm.response.statusCode = 500
		var mqconnection = 'Forbidden';
		ctx.setVariable("mqconnection", mqconnection);
		ctx.setVariable("retry", 'yes');
		var ErrorTxt = "PONPRN_001 : Error encountered while attempting to send a message to the queue named " + QueueName + JSON.stringify(err);
		ctx.setVariable("ErrorTxt", ErrorTxt);
		logger.error("PONPRN_001 : Error encountered while attempting to send a message to the queue named " + QueueName + err);
		ILSctx.setVariable("Exitdescription", ErrorTxt)
		ILSctx.setVariable("ExitStatus", "500")
	}
}


function addMinutesToZuluTime(zuluTime, minutesToAdd) {
	const date = new Date(zuluTime);
	const newDate = new Date(date.getTime() + minutesToAdd * 60000);
	return newDate.toISOString();
}
function subMinutesToZuluTime(zuluTime, minutesToSub) {
	const date = new Date(zuluTime);
	const newDate = new Date(date.getTime() - minutesToSub * 60000);
	return newDate.toISOString();
}
function isTimeBetween(startTimestamp, endTimestamp, timeToCheck) {
	const start = Date.parse(startTimestamp);
	const end = Date.parse(endTimestamp);
	const time = Date.parse(timeToCheck);
	return time >= start && time <= end;
}
