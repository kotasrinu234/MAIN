// Create or retrieve the ILS context for session handling
var ILSctx = session.name('ILS') || session.createContext('ILS');

// Get the current date and time and set it as a variable in the ILS context
var dateTime = new Date();
ILSctx.setVariable("sourceEventTimestamp", dateTime.toISOString());

session.INPUT.readAsJSON(function(readAsJSONError, json) {
	if (readAsJSONError) {
		ILSctx.setVariable("ExitDescription", "Error in reading input json " + readAsJSONError)
		ILSctx.setVariable("ExitStatus", "500")
	} else {
		for (var i = 0; i < json.AMIServiceOrders.length; i++) {
			if (!(json.AMIServiceOrders[i].MessageID === null || json.AMIServiceOrders[i].MessageID === undefined || json.AMIServiceOrders[i].MessageID === '')) {
				ILSctx.setVariable("MessageID", json.AMIServiceOrders[i].MessageID)
				break;
			}
		}
	}
})
