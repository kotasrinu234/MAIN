var hm = require('header-metadata');
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("PONPRN") || session.createContext("PONPRN");
var sm = require('service-metadata');
var errorCode = sm.getVar('var://service/error-code');
var errorMessage = sm.getVar('var://service/error-message')
var formattedErrorMessage = sm.getVar('var://service/formatted-error-message')
var logger = console.options({
	'category': 'all'
});

var obj = {};
obj.errorCode = errorCode
obj.formattedErrorMessage = errorMessage
obj.errorMessage = sm.getVar('var://service/error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');


if (ctx.getVariable('returnFailedJson') === true) {
	var failedPayloads = ctx.getVariable('failedPayloads')
	hm.current.statusCode = 500
	session.output.write(failedPayloads);
} else if (ctx.getVariable('returnErrorJson') === true) {
	var invalidPayloads = ctx.getVariable('invalidPayloads')
	hm.current.statusCode = 400
	session.output.write(invalidPayloads);
} else {
	if (errorMessage === "Rejected by policy.") {
		var WSM = session.name('WSM') || session.createContext('WSM');
		var value = WSM.getVar('identity/username');
		var errorinfo = `PONPRN_006 : AAA failure for PONPRN service "mas_ReceivePlannedMeterWork" with, Username: ${value}, Errorstring: ${errorCode}, errorMessage: ${errorMessage}`;
		ILSctx.setVariable("ExitStatus", 401)
		ILSctx.setVariable("ExitDescription", errorinfo)
		logger.error(errorinfo);
		session.output.write(XML.parse(formattedErrorMessage));
	} else {
		if (ctx.getVariable('QueueCallFailed') === true) {
			ctx.setVariable('returnFailedJson', true)
		} else {
			if (ctx.getVariable('nullChecksFailed') === true) {
				ctx.setVariable('returnErrorJson', true)
			}
		}
		session.output.write(XML.parse(formattedErrorMessage));
	}
}
