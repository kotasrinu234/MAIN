var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var QueueURL = session.parameters.QueueURL;
var PMWExitDescription = session.parameters.PMWExitDescription;
var ctx = session.name("PONPRN") || session.createContext("PONPRN");
var ILSctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, json) {
	if (readAsJSONError) {
		ILSctx.setVariable("ExitDescription", "Error in reading input json")
		ILSctx.setVariable("ExitStatus", "500")
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {

		var rejectedPayloads = []
		var failedPayloads = []
		for (var i = 0; i < json.AMIServiceOrders.length; i++) {
			var jsonObj = {
				"AMIServiceOrders": [json.AMIServiceOrders[i]]
			}

			QueueCall(jsonObj, rejectedPayloads, failedPayloads)

			if ((failedPayloads.length !== 0) && (i + 1 === json.AMIServiceOrders.length)) {
				var erroredPayloads = {
					"AMIServiceOrders": failedPayloads
				}
				var errorinfo = "PONPRN_007 : Error encountered while attempting to send a message to the queue named MAS.PLANNED.METER.WORK.SEND : "
				ctx.setVariable("failedPayloads", erroredPayloads)
				ILSctx.setVariable("ExitDescription", errorinfo)
				ILSctx.setVariable("ExitStatus", "500")
				logger.error(errorinfo)
				session.reject("Errored Payloads : " + JSON.stringify(erroredPayloads))
			} else {
				if ((rejectedPayloads.length !== 0) && (i + 1 === json.AMIServiceOrders.length)) {
					var invalidPayloads = {
						"AMIServiceOrders": rejectedPayloads
					}
					var errorinfo = "PONPRN_008 : Null Check Rejected : 'AMIServiceOrders', one/more objects failed for Null Check : "
					ctx.setVariable("nullChecksFailed", true)
					ctx.setVariable("invalidPayloads", invalidPayloads)
					ILSctx.setVariable("ExitDescription", errorinfo)
					ILSctx.setVariable("ExitStatus", "400")
					logger.error(errorinfo)
					session.reject("Null Check Rejected Payloads: " + JSON.stringify(invalidPayloads))
				}
			}
		}

		function QueueCall(jsonObj, rejectedPayloads, failedPayloads) {
			var nullCheckReject;

			if (jsonObj.AMIServiceOrders[0] === null || jsonObj.AMIServiceOrders[0] === undefined || jsonObj.AMIServiceOrders[0] === '') {
				nullCheckReject = 'yes'
			}
			if (jsonObj.AMIServiceOrders[0].MessageID === null || jsonObj.AMIServiceOrders[0].MessageID === undefined || jsonObj.AMIServiceOrders[0].MessageID === '') {
				nullCheckReject = 'yes'

			}
			if (jsonObj.AMIServiceOrders[0].MeterID === null || jsonObj.AMIServiceOrders[0].MeterID === undefined || jsonObj.AMIServiceOrders[0].MeterID === '') {
				nullCheckReject = 'yes'
			}
			if (jsonObj.AMIServiceOrders[0].Operation === null || jsonObj.AMIServiceOrders[0].Operation === undefined || jsonObj.AMIServiceOrders[0].Operation === '') {
				nullCheckReject = 'yes'
			}
			if (jsonObj.AMIServiceOrders[0].StartTimestamp === null || jsonObj.AMIServiceOrders[0].StartTimestamp === undefined || jsonObj.AMIServiceOrders[0].StartTimestamp === '') {
				nullCheckReject = 'yes'
			}
			if (jsonObj.AMIServiceOrders[0].EndTimestamp === null || jsonObj.AMIServiceOrders[0].EndTimestamp === undefined || jsonObj.AMIServiceOrders[0].EndTimestamp === '') {
				nullCheckReject = 'yes'
			}

			if (nullCheckReject === 'yes') {
				rejectedPayloads.push(jsonObj.AMIServiceOrders[0])
			} else {
				var options = {
					target: QueueURL,
					contentType: 'application/json',
					method: 'POST',
					data: jsonObj,
				};

				try {
					urlopen.open(options, function(error, response) {
						if (error) {
							var errorinfo = "Error encountered while attempting to send a message to the queue named MAS.PLANNED.METER.WORK.SEND " + error;
							hm.response.statusCode = 500
							var mqconnection = 'Forbidden';
							ctx.setVariable("mqconnection", mqconnection);
							ILSctx.setVariable("ExitDescription", errorinfo)
							ILSctx.setVariable("ExitStatus", "500")
							ctx.setVariable("QueueCallFailed", true)
							failedPayloads.push(jsonObj.AMIServiceOrders[0])
						} else {
							var mqrc = response.statusCode;
							if (mqrc == 0) {
								var replyMQMD = response.get({
									type: 'mq'
								}, 'MQMD');
								var replyMQRFH2 = response.get({
									type: 'mq'
								}, 'MQRFH2');
								response.readAsBuffer(function(readError, responseData) {
									if (readError) {
										var errorinfo = "Error encountered while reading response from the queue named MAS.PLANNED.METER.WORK.SEND " + readError;
										ILSctx.setVariable("ExitDescription", errorinfo)
										ILSctx.setVariable("ExitStatus", "500")
										ctx.setVariable("QueueCallFailed", true)
										failedPayloads.push(jsonObj.AMIServiceOrders[0])
										hm.response.statusCode = 500
									} else {
										ILSctx.setVariable("ExitDescription", PMWExitDescription)
										ILSctx.setVariable("ExitStatus", "0")
										ILSctx.setVariable("ExitDestination", QueueURL)
									}
								});
							} else {
								hm.response.statusCode = 500
								var mqconnection = 'Forbidden';
								ctx.setVariable("mqconnection", mqconnection);
								var errorinfo = "Error encountered while attempting to send a message to the queue named MAS.PLANNED.METER.WORK.SEND " + JSON.stringify(response);
								ILSctx.setVariable("ExitDescription", errorinfo)
								ILSctx.setVariable("ExitStatus", "500")
								ctx.setVariable("QueueCallFailed", true)
								failedPayloads.push(jsonObj.AMIServiceOrders[0])
							}
						}
					});
				} catch (err) {
					hm.response.statusCode = 500
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					var errorinfo = "Error encountered while attempting to send a message to the queue named MAS.PLANNED.METER.WORK.SEND ::" + err;
					ILSctx.setVariable("ExitDescription", errorinfo)
					ILSctx.setVariable("ExitStatus", "500")
					ctx.setVariable("QueueCallFailed", true)
					failedPayloads.push(jsonObj.AMIServiceOrders[0])
				}
			}
		}
	}
});
