<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:msg="http://esm.dteco.com/common/v1" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
	<xsl:param name="dpconfig:RMAILSEntryDescription" select="''" />
	<xsl:variable name="ILSEntryDescription" select="$dpconfig:RMAILSEntryDescription" />
	
	<xsl:param name="dpconfig:RMAmessageType" select="''" />
	<xsl:variable name="messageType" select="$dpconfig:RMAmessageType" />
	
	<xsl:param name="dpconfig:RMAILSExitDescription" select="''" />
	<xsl:variable name="ILSExitDescription" select="$dpconfig:RMAILSExitDescription" />
	<!-- <xsl:param name="dpconfig:sourceUrl" select="''" /><xsl:variable name="sourceUrl" select="$dpconfig:sourceUrl" /> -->
	<xsl:template match="/">
	    <xsl:variable name="efcEvents" select="document('local:///mas_ReceiveMeterAlarmFromCEP/xml/efcEvents.xml')"/>
		<xsl:variable name="IncomingPayload">
			<xsl:copy-of select="."/>
		</xsl:variable>
		<dp:set-variable name="'var://context/PONPRN/IncomingPayload'" value="$IncomingPayload" />
		<xsl:variable name="MeterException" select="$IncomingPayload/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']"/>
		<xsl:variable name="CorrelationID" select="./*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='CorrelationID']"/>
		<xsl:variable name="ElectronicSerialNumber" select="$MeterException/*[local-name()='ElectronicSerialNumber']"/>
		<xsl:variable name="alarmType" select="$MeterException/*[local-name()='Name']"/>
		<xsl:variable name="sourceEventTimestamp" select="$MeterException/*[local-name()='Timestamp']" />

		<xsl:variable name="HTTPEventType">
			<xsl:choose>
				<xsl:when test="dp:responding()">
					<xsl:value-of select="dp:response-header('EventType')" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="dp:request-header('EventType')" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="HTTPProblemCode">
			<xsl:choose>
				<xsl:when test="dp:responding()">
					<xsl:value-of select="dp:response-header('ProblemCode')" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="dp:request-header('ProblemCode')" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		
		<dp:set-variable name="'var://context/PONPRN/HTTPEventType'" value="string($HTTPEventType)" />
		<dp:set-variable name="'var://context/PONPRN/HTTPProblemCode'" value="string($HTTPProblemCode)" />
	
		<!--description -->
		<xsl:variable name="EventType" select="dp:variable('var://context/PONPRN/HTTPEventType')"/>
		<xsl:choose>
			<xsl:when test="normalize-space($EventType) != ''">
				<dp:set-variable name="'var://context/ILS/ILSEventType'" value="string($EventType)"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:if test="$alarmType = 'Primary Power Down'">
					<dp:set-variable name="'var://context/ILS/ILSEventType'" value="'Outage'"/>
				</xsl:if>
				<xsl:if test="$alarmType = 'Primary Power Up'">
					<dp:set-variable name="'var://context/ILS/ILSEventType'" value="'Restoration'"/>
				</xsl:if>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:variable name="ProblemCode" select="dp:variable('var://context/PONPRN/HTTPProblemCode')"/>
		<xsl:if test="normalize-space($ProblemCode) != ''">
			<dp:set-variable name="'var://context/ILS/ILSProblemCode'" value="string($ProblemCode)"/>
		</xsl:if>
		<xsl:variable name="ILSEventType" select="dp:variable('var://context/ILS/ILSEventType')"/>
		<xsl:variable name="ILSProblemCode" select="dp:variable('var://context/ILS/ILSProblemCode')"/>
		<xsl:variable name="ILSEntryDescription">
			<xsl:value-of select="concat($ILSEntryDescription ,' ', $ILSEventType, ': ', $ILSProblemCode)"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/ILSEntryDescription'" value="string($ILSEntryDescription)"/>
		<dp:set-variable name="'var://context/ILS/CorrelationID'" value="string($CorrelationID)" />
	    <dp:set-variable name="'var://context/ILS/ElectronicSerialNumber'" value="string($ElectronicSerialNumber)" />
		<dp:set-variable name="'var://context/ILS/alarmType'" value="string($alarmType)" />
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="string($sourceEventTimestamp)" />
		<dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)" />
		
		<!-- Logic to find the match for eventType and problemCode -->
		
		<xsl:variable name="events" select="$efcEvents/EfcEvent/event"/>
        <xsl:variable name="count" select="count($events)"/>
		<dp:set-variable name="'var://context/PONPRN/eventsCount'" value="string($count)" />
		
        <xsl:for-each select="$events">
        <xsl:variable name="problemCodeFromFile" select="string(./*[local-name()='problemCode'])"/>
        <xsl:variable name="eventTypeFromFile" select="string(./*[local-name()='EventType'])"/>

		<dp:set-variable name="'var://context/PONPRN/problemCodeFromFile'" value="$problemCodeFromFile" />
		<dp:set-variable name="'var://context/PONPRN/eventTypeFromFile'" value="$eventTypeFromFile" />
        
        <xsl:if test="$HTTPProblemCode = $problemCodeFromFile and $HTTPEventType = $eventTypeFromFile">
          <dp:set-variable name="'var://context/PONPRN/eventMatchFound'" value="'yes'" />
        </xsl:if>
        </xsl:for-each>

	</xsl:template>
</xsl:stylesheet>
