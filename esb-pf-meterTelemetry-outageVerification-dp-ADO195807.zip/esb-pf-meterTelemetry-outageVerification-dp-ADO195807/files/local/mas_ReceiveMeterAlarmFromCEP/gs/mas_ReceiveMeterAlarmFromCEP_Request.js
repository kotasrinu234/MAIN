var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});

var OMSQueueURL = session.parameters.OMSQueueURL;
var EFCQueueURL = session.parameters.EFCQueueURL;
var ExitDescription = session.parameters.RMAILSExitDescription;
var StepExitDescription = session.parameters.RMAILSStepExitDescription

var ctx = session.name("PONPRN") || session.createContext("PONPRN");
var ILSctx = session.name("ILS") || session.createContext("ILS");

var ILSEventType = ILSctx.getVariable("ILSEventType");
var ILSProblemCode = ILSctx.getVariable("ILSProblemCode");
var IncomingPayload = ctx.getVariable("IncomingPayload");
var DefaultProblemCode = ctx.getVariable("HTTPProblemCode");
var DefaultEventType = ctx.getVariable("HTTPEventType");
ILSctx.setVariable("ExitDestination", OMSQueueURL)
ILSctx.setVariable("StepExitDestination", EFCQueueURL)

var EventType = ''
var ProblemCode = ''
var Description = ''
var StepDescription = ''
if (ILSEventType === undefined || ILSEventType === null || ILSEventType === "") {
} else {
	EventType = ILSEventType
}
if (ILSProblemCode === undefined || ILSProblemCode === null || ILSProblemCode === "") {
} else {
	ProblemCode = ILSProblemCode
}
if (ExitDescription === undefined || ExitDescription === null || ExitDescription === "") {
} else {
	Description = ExitDescription
}
if (StepExitDescription === undefined || StepExitDescription === null || StepExitDescription === "") {
} else {
	StepDescription = StepExitDescription
}



var ILSExitDescription = Description + ' ' + EventType + ": " + ProblemCode
var ILSStepExitDescription = StepDescription + ' ' + EventType + ": " + ProblemCode
ILSctx.setVariable("ILSExitDescription", ILSExitDescription)
ILSctx.setVariable("OMSExitDestination", ILSExitDescription)
ILSctx.setVariable("ILSStepExitDescription", ILSStepExitDescription)

var mqmd = {
	MQMD: {
		StrucId: {
			$: 'MD  '
		},
		Format: {
			$: 'MQHRF2  '
		},
		MsgType: {
			$: '8'
		},
		Persistence: {
			$: '1'
		},
		ReplyToQ: {
			$: '  PlaceHolderReplyToQ  '
		}
	}
};
var mqrfh2 = {
	MQRFH2: {
		Version: {
			$: '2'
		},
		Format: {
			$: 'MQSTR'
		},
		NameValueData: {
			NameValue: [{
				usr: {
					ProblemCode: {
						$: DefaultProblemCode
					}, EventType: {
						$: DefaultEventType
					},
				}
			}]
		}
	}
};
var urlopenHeaders = {
	MQMD: mqmd,
	MQRFH2: mqrfh2

};
ctx.setVariable('urlopenHeaders', urlopenHeaders);


 if (DefaultProblemCode.includes('with Delay'))
{
	
								var options = {
								target: EFCQueueURL,
								headers: urlopenHeaders,
								contentType: 'application/xml',
								method: 'POST',
								data: IncomingPayload,
							};

							try {
								urlopen.open(options, function(error, response) {
									if (error) {
										hm.response.statusCode = 500
										var mqconnection = 'Forbidden';
										ctx.setVariable("mqconnection", mqconnection);
										ms.callRule('mas_ReceiveMeterAlarmFromCEP_Processing_Policy_omsQueueILSExit', null, null, function(error) {
											if (error) {
												throw error;
											}
										});
										ILSctx.setVariable("exitStatus", "500")
										ILSctx.setVariable("ILSExitDescription", "PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC")
										logger.error("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is " + error);
										session.reject("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is " + error);

									} else {
										var mqrc = response.statusCode;
										if (mqrc == 0) {
											var replyMQMD = response.get({
												type: 'mq'
											}, 'MQMD');
											var replyMQRFH2 = response.get({
												type: 'mq'
											}, 'MQRFH2');
											response.readAsBuffer(function(readError, responseData) {
												if (readError) {
													hm.response.statusCode = 500
													ms.callRule('mas_ReceiveMeterAlarmFromCEP_Processing_Policy_omsQueueILSExit', null, null, function(error) {
														if (error) {
															throw error;
														}
													});
													ILSctx.setVariable("exitStatus", "500")
												} else {
													var logILSStepExit = "<logStepExit>true</logStepExit>"
													session.output.write(XML.parse(logILSStepExit))
													ILSctx.setVariable("exitStatus", "0")
												}
											});
										} else {
											hm.response.statusCode = 500
											var mqconnection = 'Forbidden';
											ctx.setVariable("mqconnection", mqconnection);
											ms.callRule('mas_ReceiveMeterAlarmFromCEP_Processing_Policy_omsQueueILSExit', null, null, function(error) {
												if (error) {
													throw error;
												}
											});
											ILSctx.setVariable("exitStatus", "500")
											ILSctx.setVariable("ILSExitDescription", "PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC")
											logger.error("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is  [MQRC=" + mqrc + "]");
											session.reject("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is  [MQRC=" + mqrc + "]");
										}
									}
								});
							} catch (err) {
								hm.response.statusCode = 500
								var mqconnection = 'Forbidden';
								ctx.setVariable("mqconnection", mqconnection);
								ms.callRule('mas_ReceiveMeterAlarmFromCEP_Processing_Policy_omsQueueILSExit', null, null, function(error) {
									if (error) {
										throw error;
									}
								});
								ILSctx.setVariable("exitStatus", "500")
								ILSctx.setVariable("ILSExitDescription", "PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC")
								logger.error("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is " + err);
								session.reject("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is " + err);
							}
	
}else
{
var options = {
	target: OMSQueueURL,
	headers: urlopenHeaders,
	contentType: 'application/xml',
	method: 'POST',
	data: IncomingPayload,
};

try {
	urlopen.open(options, function(error, response) {
		if (error) {
			hm.response.statusCode = 500
			var mqconnection = 'Forbidden';
			ctx.setVariable("mqconnection", mqconnection);
			logger.error("PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS is " + error);
			session.reject("PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS is " + error);
			ILSctx.setVariable("exitStatus", "500")
			ILSctx.setVariable("ILSExitDescription", "PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS")
		} else {
			var mqrc = response.statusCode;
			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						hm.response.statusCode = 500
						ILSctx.setVariable("exitStatus", "500")
					} else {
						logger.debug("MQResponseData" + responseData);
						ILSctx.setVariable("exitStatus", "0")

						if (ctx.getVariable('eventMatchFound') == 'yes') {
							var options = {
								target: EFCQueueURL,
								headers: urlopenHeaders,
								contentType: 'application/xml',
								method: 'POST',
								data: IncomingPayload,
							};

							try {
								urlopen.open(options, function(error, response) {
									if (error) {
										hm.response.statusCode = 500
										var mqconnection = 'Forbidden';
										ctx.setVariable("mqconnection", mqconnection);
										ms.callRule('mas_ReceiveMeterAlarmFromCEP_Processing_Policy_omsQueueILSExit', null, null, function(error) {
											if (error) {
												throw error;
											}
										});
										ILSctx.setVariable("exitStatus", "500")
										ILSctx.setVariable("ILSExitDescription", "PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC")
										logger.error("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is " + error);
										session.reject("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is " + error);

									} else {
										var mqrc = response.statusCode;
										if (mqrc == 0) {
											var replyMQMD = response.get({
												type: 'mq'
											}, 'MQMD');
											var replyMQRFH2 = response.get({
												type: 'mq'
											}, 'MQRFH2');
											response.readAsBuffer(function(readError, responseData) {
												if (readError) {
													hm.response.statusCode = 500
													ms.callRule('mas_ReceiveMeterAlarmFromCEP_Processing_Policy_omsQueueILSExit', null, null, function(error) {
														if (error) {
															throw error;
														}
													});
													ILSctx.setVariable("exitStatus", "500")
												} else {
													var logILSStepExit = "<logStepExit>true</logStepExit>"
													session.output.write(XML.parse(logILSStepExit))
													ILSctx.setVariable("exitStatus", "0")
												}
											});
										} else {
											hm.response.statusCode = 500
											var mqconnection = 'Forbidden';
											ctx.setVariable("mqconnection", mqconnection);
											ms.callRule('mas_ReceiveMeterAlarmFromCEP_Processing_Policy_omsQueueILSExit', null, null, function(error) {
												if (error) {
													throw error;
												}
											});
											ILSctx.setVariable("exitStatus", "500")
											ILSctx.setVariable("ILSExitDescription", "PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC")
											logger.error("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is  [MQRC=" + mqrc + "]");
											session.reject("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is  [MQRC=" + mqrc + "]");
										}
									}
								});
							} catch (err) {
								hm.response.statusCode = 500
								var mqconnection = 'Forbidden';
								ctx.setVariable("mqconnection", mqconnection);
								ms.callRule('mas_ReceiveMeterAlarmFromCEP_Processing_Policy_omsQueueILSExit', null, null, function(error) {
									if (error) {
										throw error;
									}
								});
								ILSctx.setVariable("exitStatus", "500")
								ILSctx.setVariable("ILSExitDescription", "PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC")
								logger.error("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is " + err);
								session.reject("PONPRN_016 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.EFC is " + err);
							}
						}
					}
				});
			} else {
				hm.response.statusCode = 500
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error("PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS is  [MQRC=" + mqrc + "]");
				session.reject("PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS is  [MQRC=" + mqrc + "]");
				ILSctx.setVariable("exitStatus", "500")
				ILSctx.setVariable("ILSExitDescription", "PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS")
			}
		}
	});
} catch (err) {
	hm.response.statusCode = 500
	var mqconnection = 'Forbidden';
	ctx.setVariable("mqconnection", mqconnection);
	logger.error("PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS is " + err);
	session.reject("PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS is " + err);
	ILSctx.setVariable("exitStatus", "500")
	ILSctx.setVariable("ILSExitDescription", "PONPRN_003 : Error encountered while attempting to send a message to the queue named MAS.SEND.TO.OMS")
}
}
