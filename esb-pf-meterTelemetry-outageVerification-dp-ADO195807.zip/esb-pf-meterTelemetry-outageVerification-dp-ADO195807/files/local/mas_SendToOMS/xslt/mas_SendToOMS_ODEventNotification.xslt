<xsl:stylesheet version="1.0" extension-element-prefixes="dp" exclude-result-prefixes="dp EDES dpconfig" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m="http://meteralarm.esm.dteco.com/v2#" xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:EDES="http://iec.ch/TC57/2011/EndDeviceEvents#" xmlns:dpfunc="http://www.datapower.com/extensions/functions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:dp="http://www.datapower.com/extensions">
   <xsl:output method="xml" encoding="utf-8" indent="no"/>
   <xsl:include href="store:///utilities.xsl"/>
   
   	<xsl:variable name="configurationProperties">
		<xsl:copy-of select="document('local:///OMS_ConfigurationProperties/XML/Configuration.xml')"/>
	</xsl:variable>
	<xsl:variable name="passwordProperties">
		<xsl:copy-of select="document('local:///OMS_ConfigurationProperties/XML/Password.xml')"/>
	</xsl:variable>
	
	<xsl:variable name="EventType">
	<xsl:value-of select="dp:variable('var://context/PONPRN/EventType')"/>
	   
	</xsl:variable>
	<xsl:variable name="ProblemCode">
	<xsl:value-of select="dp:variable('var://context/PONPRN/ProblemCode')"/>
	 </xsl:variable>
	
	<!--<xsl:variable name="EventTime" select= "/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']/*[local-name()='ReceivedWhen']"/>
	
	<xsl:variable name="TimeStamp" select="substring-before($EventTime, '.')" />
<xsl:variable name="MilliSeconds" select="substring-after($EventTime, '.')" />
<xsl:variable name="substringSec" select="substring($MilliSeconds, 1, 2)" />
<xsl:variable name="TripTimeStamp" select="concat($TimeStamp,'.',$substringSec,'Z')" />-->


	<!--<xsl:param name="dpconfig:OMSBackendUrl"/>
	<xsl:param name="dpconfig:OMSSOAPAction"/>-->
	
   <xsl:template match="/">
    <!--<dp:set-variable name="'var://service/routing-url'" value="$dpconfig:OMSBackendUrl"/> -->
	<!--<dp:set-http-request-header name="'content-type'" value="'text/xml;charset=UTF-8'"/>-->
     <!-- <dp:set-http-request-header name="'SOAPAction'" value="$dpconfig:OMSSOAPAction"/>-->
      <dp:remove-http-request-header name="MQMD"/>
	    <xsl:variable name="OMSRequest">
      <soap:Envelope xmlns:cpsm="cpsm_V4.1_Release" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
         <soap:Header>
            <ver:MultiSpeakMsgHeader>
               <xsl:attribute name="Company">
                  <xsl:value-of select="$configurationProperties/Configuration/System/Interface/Company/text()"/>
               </xsl:attribute>
               <xsl:attribute name="Pwd">
                  <xsl:value-of select="dp:decrypt-data($configurationProperties/Configuration/System/Interface/Algorithm/text(),$configurationProperties/Configuration/System/Interface/Key/text(),$passwordProperties/Password/System/Interface/EncryptedPwd/text())"/>
               </xsl:attribute>
               <xsl:attribute name="UserID">
                  <xsl:value-of select="$configurationProperties/Configuration/System/Interface/UserID/text()"/>
               </xsl:attribute>
               <xsl:attribute name="BuildString">
                  <xsl:value-of select="$configurationProperties/Configuration/System/Interface/BuildString/text()"/>
               </xsl:attribute>
               <xsl:attribute name="Build">
                  <xsl:value-of select="$configurationProperties/Configuration/System/Interface/Build/text()"/>
               </xsl:attribute>
               <xsl:attribute name="MinorVersion">
                  <xsl:value-of select="$configurationProperties/Configuration/System/Interface/MinorVersion/text()"/>
               </xsl:attribute>
               <xsl:attribute name="MajorVersion">
                  <xsl:value-of select="$configurationProperties/Configuration/System/Interface/MajorVersion/text()"/>
               </xsl:attribute>
            </ver:MultiSpeakMsgHeader>
         </soap:Header>
         <soap:Body>
            <ver:ODEventNotification>
               <!--Optional:-->
               <ver:ODEvents>
                  <!--Zero or more repetitions:-->
                  <ver:outageDetectionEvent>
                     <ver:eventTime>
                        <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']/*[local-name()='Timestamp']"/>
                     </ver:eventTime>
                     <xsl:choose>
                        <xsl:when test="string-length($EventType) &gt; 0">
                           <ver:outageEventType>
                              <xsl:value-of select="$EventType"/>
                           </ver:outageEventType>
                        </xsl:when>
                        <xsl:otherwise>
                           <xsl:choose>
                              <xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']/*[local-name()='Name']/text()='Primary Power Down'">
                                 <ver:outageEventType>Outage</ver:outageEventType>
                              </xsl:when>
                              <xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']/*[local-name()='Name']/text()='Primary Power Up'">
                                 <ver:outageEventType>Restoration</ver:outageEventType>
                              </xsl:when>
                              <xsl:otherwise>
                                 <dp:reject>Not a valid VendorAlarmName</dp:reject>
                              </xsl:otherwise>
                           </xsl:choose>
                        </xsl:otherwise>
                     </xsl:choose>
                     <ver:outageLocation>
                        <ver:meterID>
                           <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']/*[local-name()='ElectronicSerialNumber']"/>
                        </ver:meterID>
                     </ver:outageLocation>
                     <ver:priority>Normal</ver:priority>
					 <xsl:choose>
					 <xsl:when test="string-length($ProblemCode) &gt; 0">
				      <ver:problemCode>
					   <xsl:value-of select="$ProblemCode"/>
					  </ver:problemCode>
					   </xsl:when>
                        <xsl:otherwise>
						 </xsl:otherwise>
						    </xsl:choose>
                  </ver:outageDetectionEvent>
               </ver:ODEvents>
            </ver:ODEventNotification>
         </soap:Body>
      </soap:Envelope>
	  
	  </xsl:variable>
	
	 <xsl:copy-of select="$OMSRequest"/>
	  
   </xsl:template>
   <xsl:template match="//*[local-name()='Header']"/>
</xsl:stylesheet>
