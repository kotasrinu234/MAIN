<!--This xslt is used to call oms-->
<xsl:stylesheet version="1.0" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:msg="http://esm.dteco.com/common/v1">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
	<xsl:param name="dpconfig:OMSBackendUrl"/>
	<xsl:param name="dpconfig:OMSSOAPAction"/>

	<xsl:variable name="headerValues">
		<header name="Content-Type" value="'text/xml;charset=UTF-8'"/>
		<header name="SOAPAction" value="$dpconfig:OMSSOAPAction"/>
	</xsl:variable>
	<xsl:template match="/">
		<xsl:variable name="IncomingPayload">
			<xsl:copy-of select="."/>
		</xsl:variable>
		<xsl:variable name="OMSBackendCall">
			<dp:url-open target="{$dpconfig:OMSBackendUrl}" ssl-proxy="client:OMS_Client_Profile" http-headers="$headerValues" http-method="post" response="responsecode-binary">
				<xsl:copy-of select="$IncomingPayload"/>
			</dp:url-open>
		</xsl:variable>
		<xsl:variable name="responseCode">
			<xsl:value-of select="$OMSBackendCall/result/responsecode"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/PONPRN/OMSBackendCallResponseCode'" value="$responseCode"/>
		<xsl:choose>
			<xsl:when
                test="$responseCode='200'">
				<!--   <xsl:variable name="sourceUrl" select="dp:variable('var://service/URL-in')"/> -->
				<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'0'"/>
				<xsl:variable name="OMSBackendCallResponse">
					<xsl:copy-of select="(dp:decode(dp:binary-encode($OMSBackendCall/result/binary/node()),'base-64'))"/>
				</xsl:variable>
				<xsl:message dp:priority="debug">
					<xsl:value-of select="'Successfully processed the message to OMS '"/>
					<xsl:value-of select="$dpconfig:OMSBackendUrl"/>
				</xsl:message>
				<xsl:copy-of select="$OMSBackendCallResponse"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:priority="error">
					<xsl:value-of select="'PONPRN_009 : Error encountered while attempting to establish a connection with the OMS URL '"/>
					<xsl:value-of select="$dpconfig:OMSBackendUrl"/>
				</xsl:message>
				<xsl:variable name="ErrorTxt">
					<xsl:copy-of select="'PONPRN_009 : Error encountered while attempting to establish a connection with the OMS URL '"/>
					<xsl:value-of select="$dpconfig:OMSBackendUrl"/>
				</xsl:variable>
				<dp:set-variable name="'var://context/PONPRN/ErrorTxt'" value="string($ErrorTxt)"/>
				<dp:set-variable name="'var://context/PONPRN/retry'" value="'yes'"/>
				<dp:set-variable name="'var://context/ILS/ExitStatus'" value="''"/>
				<dp:set-variable name="'var://context/ILS/Exitdescription'" value="'PONPRN_009 : Error encountered while attempting to establish a connection with OMS URL'"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
