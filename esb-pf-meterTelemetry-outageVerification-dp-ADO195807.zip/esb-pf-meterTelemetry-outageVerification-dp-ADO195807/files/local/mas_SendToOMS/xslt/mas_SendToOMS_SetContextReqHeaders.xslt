<?xml version="1.0" encoding="utf-8"?>

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:output method="xml" encoding="utf-8" indent="yes"/>
	<xsl:template match="/">

		<!-- Fetching the MQMD headers -->
		<xsl:variable name="entriesMQMD" select="dp:request-header('MQMD')"/>
		<xsl:variable name="entriesMQRFH2" select="dp:request-header('MQRFH2')"/>


		<!-- Parsing the string MQMD headers to XML format -->
		<xsl:variable name="mqmd-headers" select="dp:parse($entriesMQMD)"/>
		<xsl:message dp:priority="debug">
			<xsl:value-of select="concat('The Request MQMD : ', $entriesMQMD)"/>
		</xsl:message>
		<dp:set-variable name="'var://context/MQMD/MQMDRequestHeaders'" value ="$mqmd-headers"/>
		<xsl:if test="normalize-space($entriesMQRFH2)!=''">
			<xsl:variable name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)"/>
			<xsl:message dp:priority="debug">
				<xsl:value-of select="concat('The Request MQRFH2 : ', $entriesMQRFH2)"/>
			</xsl:message>
			<!-- Placing the MQMD headers in the context variables -->
			<dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value ="$mqrfh2-headers"/>
			<xsl:if test="string-length($mqrfh2-headers//EventType) &gt; 0">
				<dp:set-variable name="'var://context/PONPRN/EventType'" value="string($mqrfh2-headers//EventType)" />
			</xsl:if>
			<xsl:if test="string-length($mqrfh2-headers//ProblemCode) &gt; 0">
				<dp:set-variable name="'var://context/PONPRN/ProblemCode'" value="string($mqrfh2-headers//ProblemCode)" />
			</xsl:if>
		</xsl:if>
		<xsl:copy-of select="."/>

	</xsl:template>
</xsl:stylesheet>