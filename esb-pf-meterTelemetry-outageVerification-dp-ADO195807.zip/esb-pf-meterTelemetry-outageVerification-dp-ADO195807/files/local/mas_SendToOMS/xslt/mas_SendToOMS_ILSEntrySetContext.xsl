<!-- This xslt is used to invoke job oms api and get the response -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:msg="http://esm.dteco.com/common/v1" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig">
    <xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
    <xsl:param name="dpconfig:STOILSEntryDescription" select="''"/>
    <xsl:variable name="ILSEntryDescription" select="$dpconfig:STOILSEntryDescription"/>
    <xsl:param name="dpconfig:STOILSExitDescription" select="''"/>
    <xsl:variable name="ILSExitDescription" select="$dpconfig:STOILSExitDescription"/>
    <xsl:param name="dpconfig:sourceUrl" select="''"/>
    <xsl:variable name="sourceUrl" select="$dpconfig:sourceUrl"/>
    <xsl:param name="dpconfig:STOmessageType" select="''"/>
    <xsl:variable name="messageType" select="$dpconfig:STOmessageType"/>
    <xsl:param name="dpconfig:OMSBackendUrl" select="''"/>
    <xsl:variable name="OMSBackendUrl" select="$dpconfig:OMSBackendUrl"/>
    <xsl:template match="/">
        <xsl:variable name="IncomingPayload">
            <xsl:copy-of select="."/>
        </xsl:variable>
        <dp:set-variable name="'var://context/ILS/IncomingPayload'" value="$IncomingPayload"/>
        <dp:set-variable name="'var://context/ILS/sourceUrl'" value="$sourceUrl"/>
        <xsl:variable name="MeterException" select="$IncomingPayload/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ExceptionsArrived']/*[local-name()='input']/*[local-name()='MeterExceptionCollection']/*[local-name()='MeterException']"/>
        <xsl:variable name="CorrelationID" select="./*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='CorrelationID']"/>
        <xsl:variable name="ElectronicSerialNumber" select="$MeterException/*[local-name()='ElectronicSerialNumber']"/>
        <xsl:variable name="alarmType" select="$MeterException/*[local-name()='Name']"/>
        <xsl:variable name="sourceEventTimestamp" select="$MeterException/*[local-name()='Timestamp']"/>
        <dp:set-variable name="'var://context/ILS/CorrelationID'" value="string($CorrelationID)"/>
        <dp:set-variable name="'var://context/ILS/ElectronicSerialNumber'" value="string($ElectronicSerialNumber)"/>
        <dp:set-variable name="'var://context/ILS/alarmType'" value="string($alarmType)"/>
        <dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="string($sourceEventTimestamp)"/>
        <xsl:variable
        name="entriesMQRFH2" select="dp:request-header('MQRFH2')"/>
        <!-- Parsing the string MQMD headers to XML format -->
        <xsl:if test="normalize-space($entriesMQRFH2)!=''">
            <xsl:variable
            name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)"/>
            <!-- Placing the MQMD headers in the context variables -->
            <dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value="$mqrfh2-headers"/>
            <xsl:if test="string-length($mqrfh2-headers//EventType) &gt; 0">
                <dp:set-variable name="'var://context/ILS/EventType'" value="string($mqrfh2-headers//EventType)"/>
            </xsl:if>
            <xsl:if test="string-length($mqrfh2-headers//ProblemCode) &gt; 0">
                <dp:set-variable name="'var://context/ILS/ProblemCode'" value="string($mqrfh2-headers//ProblemCode)"/>
            </xsl:if>
        </xsl:if>
        <!--description -->
        <xsl:variable name="EventType" select="dp:variable('var://context/ILS/EventType')"/>
        <xsl:choose>
            <xsl:when test="normalize-space($EventType) != ''">
                <dp:set-variable name="'var://context/ILS/ILSEventType'" value="string($EventType)"/>
            </xsl:when>
            <xsl:otherwise>
                <xsl:if test="$alarmType = 'Primary Power Down'">
                    <dp:set-variable name="'var://context/ILS/ILSEventType'" value="'Outage'"/>
                </xsl:if>
                <xsl:if test="$alarmType = 'Primary Power Up'">
                    <dp:set-variable name="'var://context/ILS/ILSEventType'" value="'Restoration'"/>
                </xsl:if>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:variable name="ProblemCode" select="dp:variable('var://context/ILS/ProblemCode')"/>
        <xsl:if test="normalize-space($ProblemCode) != ''">
            <dp:set-variable name="'var://context/ILS/ILSProblemCode'" value="string($ProblemCode)"/>
        </xsl:if>
        <xsl:variable name="ILSEventType" select="dp:variable('var://context/ILS/ILSEventType')"/>
        <xsl:variable name="ILSProblemCode" select="dp:variable('var://context/ILS/ILSProblemCode')"/>
        <xsl:variable name="Entrydescription">
            <xsl:value-of select="concat($ILSEntryDescription ,' ', $ILSEventType, ' : ', $ILSProblemCode)"/>
        </xsl:variable>
        <xsl:variable name="Exitdescription">
            <xsl:value-of select="concat($ILSExitDescription ,' ', $ILSEventType, ' : ', $ILSProblemCode)"/>
        </xsl:variable>
        <dp:set-variable name="'var://context/ILS/Entrydescription'" value="string($Entrydescription)"/>
        <dp:set-variable name="'var://context/ILS/Exitdescription'" value="string($Exitdescription)"/>
        <dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)"/>
        <dp:set-variable name="'var://context/ILS/exitDestination'" value="string($OMSBackendUrl)"/>
    </xsl:template>
</xsl:stylesheet>