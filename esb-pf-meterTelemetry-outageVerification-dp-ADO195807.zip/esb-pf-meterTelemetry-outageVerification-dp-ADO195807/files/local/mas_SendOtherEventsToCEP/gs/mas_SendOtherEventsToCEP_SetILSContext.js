var logger = console.options({ 'category': 'all' });

var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("PONPRN") || session.createContext("PONPRN");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data as JSON : " + readAsJSONError;
		ILSctx.setVariable("exitDescription", errorinfo)
		ILSctx.setVariable("exitStatus", "500")
		logger.error(errorinfo);
	} else {
		ILSctx.setVariable("incomingdata", incomingdata)
		if (incomingdata.response) {
			ILSctx.setVariable("correlationID", incomingdata.messageId)
			ILSctx.setVariable("entryDescription", session.parameters.MPEntryDescription)
			ILSctx.setVariable("exitDescription", session.parameters.MPExitDescription)
			ILSctx.setVariable("meterID", incomingdata.meterId)
			ILSctx.setVariable("sourceEventTimestamp", incomingdata.timesStamp)
			ILSctx.setVariable("MessageType", session.parameters.MPMessageType)
			var Status = incomingdata.response.status
			if (Status == "SUCCESS") {
				ILSctx.setVariable("sourceStatus", "0")
			} else {
				ILSctx.setVariable("sourceStatus", "1")
			}
		}
		if (incomingdata.AMIServiceOrders) {
			ILSctx.setVariable("incomingdata", incomingdata)
			ILSctx.setVariable("entryDescription", session.parameters.PMWEntryDescription)
			ILSctx.setVariable("exitDescription", session.parameters.PMWExitDescription)
			var dateTime = new Date();
			ILSctx.setVariable("sourceEventTimestamp", dateTime.toISOString());
			ILSctx.setVariable("MessageType", session.parameters.PMWMessageType)
			ILSctx.setVariable("sourceStatus", ' ')

			ilsNullCheck("correlationID", incomingdata.AMIServiceOrders[0].MessageID)
			ilsNullCheck("meterID", incomingdata.AMIServiceOrders[0].MeterID)
			ilsNullCheck("Operation", incomingdata.AMIServiceOrders[0].Operation)
			ilsNullCheck("StartTimestamp", incomingdata.AMIServiceOrders[0].StartTimestamp)
			ilsNullCheck("EndTimestamp", incomingdata.AMIServiceOrders[0].EndTimestamp)
		}
	}
})

function ilsNullCheck(name, parameter) {
	if (parameter === null || parameter === undefined || parameter === '') {
		ILSctx.setVariable(name, '')
	} else {
		ILSctx.setVariable(name, parameter)
	}
}