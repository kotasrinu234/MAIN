var ILSctx = session.name("ILS") || session.createContext("ILS");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var entryDescription = session.parameters.RPRILSEntryDescription;
var exitDescription = session.parameters.RPRILSExitDescription;
var messageType = session.parameters.RPRmessageType 

var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var urlIn = sm.getVar('var://service/URL-in');
		
		if(incomingData.messageId === undefined || incomingData.messageId === null || incomingData.messageId === ""){
			ILSctx.setVariable("correlationID", " ")
		} else {
			ILSctx.setVariable("correlationID", incomingData.messageId)
		}
		
		if(incomingData.timesStamp === undefined || incomingData.timesStamp === null || incomingData.timesStamp === ""){
			ILSctx.setVariable("sourceEventTimestamp", "")
		} else {
		
		ILSctx.setVariable("sourceEventTimestamp", incomingData.timesStamp)
		}
		
		ILSctx.setVariable("sourceUrl", urlIn)
		
		
		ILSctx.setVariable("entryDescription", entryDescription)
		ILSctx.setVariable("exitDescription", exitDescription)
		ILSctx.setVariable("messageType", messageType)


		if(incomingData.meterIds===undefined ||incomingData.meterIds=== null || incomingData.meterIds===""){	
		ILSctx.setVariable("ModifiedMeterIDs", " ")
		} else {
			var meterIdsArray = incomingData.meterIds.map(function(obj) {
			return obj.meterId;
		});

		var result = meterIdsArray.join(':');
		ILSctx.setVariable("ModifiedMeterIDs", result)
	}
}
});






