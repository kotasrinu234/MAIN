var ILSctx = session.name("ILS") || session.createContext("ILS");
var sm = require('service-metadata');
var errorCode = sm.getVar('var://service/error-code');
var errorMessage = sm.getVar('var://service/error-message')
var logger = console.options({ 'category': 'all' });

if (errorMessage === "Rejected by policy.") {
	var WSM = session.name('WSM') || session.createContext('WSM');
	var value = WSM.getVar('identity/username');
	var errorinfo = `PONPRN_004 : AAA failure for PONPRN service 'mas_ReceivePingRequestFromCEP' with, Username: ${value}, Errorstring: ${errorCode}, errorMessage: ${errorMessage}`;
	ILSctx.setVariable("exitDescription", errorinfo);
	ILSctx.setVariable("exitStatus", 401)
	logger.error(errorinfo);
}
