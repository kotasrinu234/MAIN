var ctx = session.name("PONPRN") || session.createContext("PONPRN");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var MeterPingQueueURL = session.parameters.MeterPingQueueURL
ILSctx.setVariable("ExitDestination", MeterPingQueueURL)
var ReplyToQName = session.parameters.ReplyToQ
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
//var Headers = ctx.getVariable("Headers")
var ReplyToQ = " " + ReplyToQName

session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var headers = hm.current;

		ctx.setVariable("Payload", JSON.stringify(incomingData))
		ILSctx.setVariable("ExitDestination", MeterPingQueueURL)

		var pushingToQueue = {
			target: MeterPingQueueURL,
			data: incomingData,
			headers: {
				MQMD: {
					"MQMD": {
						"MsgType": {
							"$": '8'
						},
						"Persistence": {
							"$": '1'
						},
						"ReplyToQ": { "$": ReplyToQ }
					}
				},
			}
		};
		try {
			urlopen.open(pushingToQueue, function(error, response) {
				var hm = require('header-metadata');
				if (error) {
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error("PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST is " + JSON.stringify(error));
					session.reject("PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST is " + error);
					ILSctx.setVariable("exitStatus", "500")
					ILSctx.setVariable("exitDescription", "PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST")
				} else {
					var mqrc = response.statusCode;
					if (mqrc == 0) {
						var replyMQMD = response.get({
							type: 'mq'
						}, 'MQMD');
						var replyMQRFH2 = response.get({
							type: 'mq'
						}, 'MQRFH2');
						response.readAsBuffer(function(readError, responseData) {
							if (readError) {
								hm.response.statusCode = 500
								session.reject("error while Reading response from the queue queue is " + error);
								ILSctx.setVariable("exitStatus", "500")
								ILSctx.setVariable("exitDescription", " ")

							} else {
								ILSctx.setVariable("exitStatus", "0")
							}
						});
					} else {
						var ctx = session.name("PONPRN") || session.createContext("PONPRN");
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						ILSctx.setVariable("exitStatus", "500")
						ILSctx.setVariable("exitDescription", "PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST")
						logger.error("PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST is [MQRC=" + mqrc + "]");
						session.reject("PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST is [MQRC=" + mqrc + "]");
					}
				}
			});
		} catch (err) {
			logger.error("PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST is " + JSON.stringify(err));
			session.reject("PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST is " + err);
			ILSctx.setVariable("exitStatus", "500")
			ILSctx.setVariable("exitDescription", "PONPRN_005 : Error encountered while attempting to send a message to the queue named MOPPNG.PING.REQUEST")
		}
	}
});
