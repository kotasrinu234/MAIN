var urlopen = require('urlopen');
var sm = require('service-metadata')
var logger = console.options({ 'category': 'all' });
var ctx = session.name("PONPRN") || session.createContext("PONPRN");
var ILSctx = session.name("ILS") || session.createContext("ILS");
sm.setVar("var://service/mpgw/skip-backside", true)

session.INPUT.readAsXML(function(readAsXMLError, xml) {
	if (readAsXMLError) {
		var errorinfo = "Error in reading incoming data as XML : " + readAsXMLError;
		ILSctx.setVariable("exitDescription", errorinfo)
		ILSctx.setVariable("exitStatus", "500")
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {

		var getTokenUrl = session.parameters.getTokenUrl
		var Options = {
			target: getTokenUrl,
			method: 'GET',
			contentType: 'application/json',
		};

		var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
		urlopen.open(Options, function(error, response) {
			if (error) {
				var errorinfo = "PONPRN_010 : url connection error 'Token Call', details are :" + info + "; error info :" + error;
				ILSctx.setVariable("exitDescription", errorinfo);
				ILSctx.setVariable("exitStatus", "500");
				ILSctx.setVariable("exitDestination", getTokenUrl);
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode === 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'Token Call', details are : " + info + "; error info :" + error
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", "500");
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var AccessToken = responseData.access_token;
							if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
								var errorinfo = "PONPRN_011 : Invalid token revieved, details are : " + info
								ILSctx.setVariable("exitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								ILSctx.setVariable("exitDestination", getTokenUrl);
								logger.error(errorinfo);
								ctx.setVariable("retry", 'yes');
								ctx.setVariable("ErrorTxt", errorinfo);
							} else {
								var tokenRecieved = "<tokenRecieved>true</tokenRecieved>"
								ILSctx.setVariable("tokensExitDestination", getTokenUrl);
								session.output.write(XML.parse(tokenRecieved))
								var eventHubURL = session.parameters.eventHubURL
								var TokenType = responseData.token_type;
								var Token = TokenType + ' ' + AccessToken;
								var Options = {
									target: eventHubURL,
									sslClientProfile: 'mas_SendMeterAlarmToCEP_tls_client_profile',
									method: 'POST',
									headers: {
										'Authorization': Token,
									},
									contentType: 'application/x-www-form-urlencoded',
									data: xml
								}

								var info = " TargetURL :" + Options.target + "; Method :" + Options.method + "; Data :" + XML.stringify(Options.data) + ". ";
								urlopen.open(Options, function(error, response) {
									if (error) {
										var errorinfo = "PONPRN_012 : url connection error 'EventHub Call', details are :" + info + "; error info :" + error;
										ILSctx.setVariable("exitDescription", errorinfo);
										ILSctx.setVariable("exitStatus", "500");
										ILSctx.setVariable("exitDestination", eventHubURL);
										logger.error(errorinfo);
										ctx.setVariable("retry", 'yes');
										ctx.setVariable("ErrorTxt", errorinfo);
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode === 200 || responseStatusCode === 201) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'EventHub Call' , details are : " + info + "; error info :" + error;
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", "500");
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													ILSctx.setVariable("exitDescription", session.parameters.exitDescription);
													ILSctx.setVariable("exitDestination", eventHubURL);
													ILSctx.setVariable("exitStatus", "0");
												}
											});
										} else {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'EventHub Call', details are : " + info + "; error info :" + error
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", "500");
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "PONPRN_012 : error response 'EventHub Call', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", responseStatusCode);
													ILSctx.setVariable("exitDestination", eventHubURL);
													logger.error(errorinfo);
													ctx.setVariable("retry", 'yes');
													ctx.setVariable("ErrorTxt", errorinfo);
												}
											});
										}
									}
								});
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'Token Call', details are : " + info + "; error info :" + error
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "PONPRN_010 : error response 'Token Call', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							ILSctx.setVariable("exitDestination", getTokenUrl);
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
						}
					});
				}
			}
		});
	}
});
