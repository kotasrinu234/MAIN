# INTERFACE 29.1&29.2 - AMI(PON-PRN)

📌 **PACKAGING INSTRUCTIONS**

✅ *Objects need to be selected while taking the export:*

**1. MULTIPROTOCOL GATEWAY:** mas_ReceiveMeterAlarm, mas_ReceiveMeterAlarmFromCEP, mas_ReceivePingRequestFromCEP, mas_ReceivePlannedMeterWork, mas_SendEventToAzure, mas_SendMeterAlarmToCEP, mas_SendOtherEventsToCEP, mas_SendToOMS

**2. IBM MQ QUEUE MANAGERS:** mas_ReceiveMeterAlarm_QM, mas_ReceiveMeterAlarm_QMgr, mas_ReceiveMeterAlarm_QMgr_ALT, mas_ReceiveMeterAlarm_QMgr_Retry, mas_ReceiveMeterAlarm_QMOMS, mas_ReceiveMeterAlarmFromCEP_QM, mas_ReceivePingRequestFromCEP_QM, mas_ReceivePlannedMeterWork_QM, mas_SendEventToAzure_Qmgr, mas_SendEventToAzure_Qmgr_ALT, mas_SendEventToAzure_Qmgr_Retry, mas_SendEventToAzure_Qmgr_Retry_ALT, mas_SendMeterAlarmToCEP_QMgr, mas_SendMeterAlarmToCEP_QMgr_ALT, mas_SendMeterAlarmToCEP_QMgr_Retry, mas_SendOtherEventsToCEP_MeterPing_QMgr, mas_SendOtherEventsToCEP_MeterPing_QMgr_ALT, mas_SendOtherEventsToCEP_MeterPing_QMgr_Retry, mas_SendOtherEventsToCEP_PlannedMeterWork_QMgr, mas_SendOtherEventsToCEP_PlannedMeterWork_QMgr_ALT, mas_SendOtherEventsToCEP_PlannedMeterWork_QMgr_Retry, mas_SendToOMS_ALT_QMGR, mas_SendToOMS_IIBRetry_QMGR, mas_SendToOMS_QMGR, mas_ReceiveMeterAlarm_QMgr_Retry_ALT, mas_SendMeterAlarmToCEP_QMgr_Retry_ALT, mas_SendOtherEventsToCEP_MeterPing_QMgr_Retry_ALT, mas_SendOtherEventsToCEP_PlannedMeterWork_QMgr_Retry_ALT, mas_SendToOMS_IIBRetry_QMGR_ALT

**3. TLS CLIENT PROFILES:** mas_AAA_AD_ClientProfile, mas_ReceivePlannedMeterWork_AD_Client_Profile, mas_SendEventToAzure_tls_client_profile, mas_SendMeterAlarmToCEP_tls_client_profile, mas_SendOtherEventsToCEP_tls_client_profile, OMS_Client_Profile

⚠️ **Note:::**
**_During deployment, certain stylesheet parameter values were either replaced with the placeholder 'sample' or had their spaces removed in both the baseDeploymentPolicy and export.xml files due to deployment failures.
Please review these fields carefully and update them as needed to ensure a smooth and valid deployment process._**

⚠️ **Note::: Instructions while creating new deployment policy/properties:**

**_AAA Properties for Deployment, Add Manually (Click on edit the readme file and copy as there are astrix, can't be copied directly.)_**

*1. Properties file:*
mas_AAA_Policy.aaa.auth.LDAP.BindDN=CN=esb-pnfcep-onp-dev,OU=Service,OU=Restricted Accounts,DC=dtenet,DC=com
mas_AAA_Policy.aaa.auth.LDAP.GroupDN=cn=onp-users-dev, OU=PF,OU=ESB,OU=DCA,OU=DTE Groups, DC=dtenet, DC=com
mas_ReceivePlannedMeterWork_AAA.aaa.auth.LDAP.BindDN=CN=dcas-crb-esb-oms-dev,OU=Service,OU=Restricted Accounts,DC=dtenet,DC=com
mas_ReceivePlannedMeterWork_AAA.aaa.auth.LDAP.GroupDN=CN=DCA_OmscrbUsers-dev,OU=ESB,OU=DCA,OU=DTE Groups,DC=dtenet,DC=com

*2. BaseDeploymentPolicy:*
           <ModifiedConfig>
						<Match>*/*/xml/aaapolicy?Name=mas_AAA_Policy&amp;Property=Authorize/AZLDAPGroup&amp;Value=.*</Match>
						<Type>change</Type>
						<Property/>
						<Value>@mas_AAA_Policy.aaa.auth.LDAP.GroupDN@</Value>
					</ModifiedConfig>
					<ModifiedConfig>
						<Match>*/*/xml/aaapolicy?Name=mas_AAA_Policy&amp;Property=Authorize/AZLDAPBindDN&amp;Value=.*</Match>
						<Type>change</Type>
						<Property/>
						<Value>@mas_AAA_Policy.aaa.auth.LDAP.BindDN@</Value>
					</ModifiedConfig>
					<ModifiedConfig>
						<Match>*/*/xml/aaapolicy?Name=mas_ReceivePlannedMeterWork_AAA&amp;Property=Authorize/AZLDAPGroup&amp;Value=.*</Match>
						<Type>change</Type>
						<Property/>
						<Value>@mas_ReceivePlannedMeterWork_AAA.aaa.auth.LDAP.GroupDN@</Value>
					</ModifiedConfig>
					<ModifiedConfig>
						<Match>*/*/xml/aaapolicy?Name=mas_ReceivePlannedMeterWork_AAA&amp;Property=Authorize/AZLDAPBindDN&amp;Value=.*</Match>
						<Type>change</Type>
						<Property/>
						<Value>@mas_ReceivePlannedMeterWork_AAA.aaa.auth.LDAP.BindDN@</Value>
					</ModifiedConfig>
