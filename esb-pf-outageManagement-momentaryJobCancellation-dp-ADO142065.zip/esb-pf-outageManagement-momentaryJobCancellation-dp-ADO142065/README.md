GIT Repo: esb-pf-outageManagement-momentaryJobCancellation-dp

Jenkins Pipelines:

ST - esb-pf-outageManagement-momentaryJobCancellation-dp-st
DEV - esb-pf-outageManagement-momentaryJobCancellation-dp-dev
INT - esb-pf-outageManagement-momentaryJobCancellation-dp-int
LOAD - esb-pf-outageManagement-momentaryJobCancellation-dp-load
PROD - esb-pf-outageManagement-momentaryJobCancellation-dp-prod

Domain: OutageManagement04

Services: 
1.mjcs_ReceiveMomentary   
2. mjcs_CancelMomentaryJob   

Tokens to be updated after Prod Deployment:
mjcs_CancelMomentaryJob --osiApiToken (stylesheet parameter name)

NOTE: Please validate if all objects are up. Password alias for MQ, ssl certs should be added.
