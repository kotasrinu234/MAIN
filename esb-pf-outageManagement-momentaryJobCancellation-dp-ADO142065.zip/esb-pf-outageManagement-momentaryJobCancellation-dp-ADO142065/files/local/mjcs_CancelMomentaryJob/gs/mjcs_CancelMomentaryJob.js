var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	// getting styleheet params
	var ctx = session.name("mas") || session.createContext("mas");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
	var apiToken = ctx.getVar("apiToken");
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var jobinternalid = incomingdata.data[0].id;
		// starts here /api/ServiceType/Electric/Job/{id}/Comment

		var now = new Date();
		var year = now.getFullYear();

		var month = now.getMonth() + 1;
		var month1 = month.toString();
		var strmonthlength = month1.length;
		var todaymonth;
		if (strmonthlength == 1) {
			todaymonth = '0' + month;
		} else {
			todaymonth = month;
		}

		var day = now.getDate();
		var day1 = day.toString();
		var strdaylength = day1.length;
		var todaydate;
		if (strdaylength == 1) {
			todaydate = '0' + day;
		} else {
			todaydate = day;
		}

		var hour = now.getHours();
		var todayhour = hour.toString();
		var strhourlength = todayhour.length;
		var todayhour;
		if (strhourlength == 1) {
			todayhour = '0' + hour;
		} else {
			todayhour = hour;
		}

		var minute = now.getMinutes();
		var todayminute = minute.toString();
		var strminutelength = todayminute.length;
		var todayminute;
		if (strminutelength == 1) {
			todayminute = '0' + minute;
		} else {
			todayminute = minute;
		}

		var second = now.getSeconds();
		var todaysecond = second.toString();
		var strsecondlength = todaysecond.length;
		var todaysecond;
		if (strsecondlength == 1) {
			todaysecond = '0' + todaysecond;
		} else {
			todaysecond = todaysecond;
		}

		var nowdate = year + '-' + todaymonth + '-' + todaydate
		var nowtime = todayhour + ':' + todayminute + ':' + todaysecond
		var ctx = session.name("mas") || session.createContext("mas");
		var Commentmessage = ctx.getVar("Commentmessage");
		var commentmessage = Commentmessage + ' ' + nowdate + ' AT ' + nowtime;
		var jobinternalid = incomingdata.data[0].id;
		var Jobcommenturi = omsExternalURL + 'Job/' + jobinternalid + '/Comment';
		var TokenValue = apiToken;

		var payload = {
			"comment": commentmessage
		}
		var jobcommentapi = {
			target: Jobcommenturi,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'POST',
			contentType: 'application/json',
			headers: {
				'osiApiToken': TokenValue
			},
			data: payload
		};
		var info = " TargetURL :" + jobcommentapi.target + "; Method :" + jobcommentapi.method + "; Data :" + JSON.stringify(jobcommentapi.data) + ". ";
		urlopen.open(jobcommentapi, function(error, response) {
			if (error) {
				var errorinfo = "mjcs_005 urlopen connect error with jobcommentapi for jobinternalid is :" + jobinternalid + " details are:   " + info + " error info : " + JSON.stringify(error);
				ilsctx.setVariable("ExitStatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "mjcs_010 failure in getting message jobcommentapi for jobinternalid:" + jobinternalid + " details are: " + info + " error info : " + JSON.stringify(error);
							ilsctx.setVariable("ExitStatus", "500")
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = responseStatusCode;
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from jobcommentapi for jobinternalid:" + jobinternalid + " " + responseStatusCode);
							/// patch starts
							ilsctx.setVariable("ExitStatus", "0");
							//ilsctx.setVariable("ExitDestination",Jobcommenturi);
							var ctx = session.name("mas") || session.createContext("mas");
							var Commentmessage = ctx.getVar("Commentmessage");
							var commentmessage = Commentmessage + ' ' + nowdate + ' AT ' + nowtime;
							var jobinternalid = incomingdata.data[0].id;
							var Jobcommenturi = omsExternalURL + 'Job/' + jobinternalid;


							var payload = {
								"customFieldValues": {
									"Remarks": commentmessage
								}
							}
							var jobcommentapi = {
								target: Jobcommenturi,
								sslClientProfile: 'OMS_Client_Profile',
								method: 'PATCH',
								contentType: 'application/json',
								headers: {
									'osiApiToken': TokenValue
								},
								data: payload
							};
							var info = " TargetURL :" + jobcommentapi.target + "; Method :" + jobcommentapi.method + "; Data :" + JSON.stringify(jobcommentapi.data) + ". ";
							urlopen.open(jobcommentapi, function(error, response) {
								if (error) {
									var errorinfo = "mjcs_006 urlopen connect error from JobPatch call for jobinternalid:" + jobinternalid + " details are :  " + info + "error info : " + JSON.stringify(error);
									ilsctx.setVariable("ExitStatus", "500")
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												var errorinfo = "mjcs_011 failure in gettimg message to JobPatch call , details are : " + info + " error info :" + JSON.stringify(error);
												ilsctx.setVariable("ExitStatus", "500")
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												hm.response.statusCode = responseStatusCode;
												hm.response.statusCode = responseStatusCode;
												logger.debug("response received from JobPatch call for jobinternalid:" + jobinternalid + " " + responseStatusCode);
												//workflow starts
												ilsctx.setVariable("ExitStatus", "0")
												//ilsctx.setVariable("ExitDestination",WorkFlowuri);
												var jobinternalid = incomingdata.data[0].id;
												var WorkFlowuri = omsExternalURLV1 + 'Job/' + jobinternalid + '/WorkFlow';
												var ctx = session.name("mas") || session.createContext("mas");
												var TokenValue = apiToken;
												var lookupstatus = ctx.getVar("lookupstatus");
												logger.debug("value is ++" + lookupstatus);

												var WorkFlowapi = {
													target: WorkFlowuri,
													sslClientProfile: 'OMS_Client_Profile',
													method: 'POST',
													contentType: 'application/json',
													headers: {
														'osiApiToken': TokenValue
													},
													data: lookupstatus
												};
												var info = " TargetURL :" + WorkFlowapi.target + "; Method :" + WorkFlowapi.method + "; Data :" + JSON.stringify(WorkFlowapi.data) + ". ";
												urlopen.open(WorkFlowapi, function(error, response) {
													if (error) {
														var errorinfo = "mjcs_004 urlopen connect error with WorkFlowapi post for job cancel with jobinternalid is: " + jobinternalid + " details are : " + info + " error info : " + JSON.stringify(error);
														ilsctx.setVariable("ExitStatus", "500")
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														var responseStatusCode = response.statusCode;
														if (responseStatusCode == 200) {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	//dp:reject stop the transaction and go error rule with error code and description
																	var errorinfo = "mjcs_009 failure in getting  message from WorkFlowapi post for job cancel, details are :  " + info + " error info :" + JSON.stringify(error);
																	ilsctx.setVariable("ExitStatus", "500")
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	ilsctx.setVariable("ExitStatus", "0")
																	ilsctx.setVariable("ExitDestination",WorkFlowuri);
																	hm.response.statusCode = responseStatusCode;
																	hm.response.statusCode = responseStatusCode;
																	logger.debug("response received from WorkFlowapi for jobinternalid " + jobinternalid + "is  " + responseStatusCode);
																}
															});
														} else if(responseStatusCode == 401 || responseStatusCode == 403){

															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	//dp:reject stop the transaction and go error rule with error code and description
																	var errorinfo = "failure in reading message from WorkFlowapi for jobinternalid, details are :  " + info + "error info :" + JSON.stringify(error);
																	ilsctx.setVariable("ExitStatus", "500")
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "mjcs_019 response received from WorkFlowapi for jobinternalid " + jobinternalid + " is  " + responseStatusCode + " " + responseData + "details are : " + info;
																	ilsctx.setVariable("ExitStatus", responseStatusCode)
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
															});

														} 
														else {

															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	//dp:reject stop the transaction and go error rule with error code and description
																	var errorinfo = "failure in reading message from WorkFlowapi for jobinternalid, details are :  " + info + "error info :" + JSON.stringify(error);
																	ilsctx.setVariable("ExitStatus", "500")
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = " response received from WorkFlowapi for jobinternalid " + jobinternalid + " is  " + responseStatusCode + " " + responseData + "details are : " + info;
																	ilsctx.setVariable("ExitStatus", responseStatusCode)
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
															});

														}
													}
												});


												//workflow ends	

											}
										});
									} else if(responseStatusCode == 401 || responseStatusCode == 403) {

										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												var errorinfo = "failure in reading message from JobPatch call for jobinternalid , details are  :  " + info + " error info :" + JSON.stringify(error);
												ilsctx.setVariable("ExitStatus", "500")
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "mjcs_018 response received from JobPatch call for jobinternalid:" + jobinternalid + " " + responseStatusCode + " " + responseData + "details are : " + info;
												ilsctx.setVariable("ExitStatus", responseStatusCode)
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});



									}
									 else {

										response.readAsBuffer(function(error, responseData) {
											if (error) {
												//dp:reject stop the transaction and go error rule with error code and description
												var errorinfo = "failure in reading message from JobPatch call for jobinternalid , details are  :  " + info + " error info :" + JSON.stringify(error);
												ilsctx.setVariable("ExitStatus", "500")
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = " response received from JobPatch call for jobinternalid:" + jobinternalid + " " + responseStatusCode + " " + responseData + "details are : " + info;
												ilsctx.setVariable("ExitStatus", responseStatusCode)
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});



									}
								}
							});

							// patch ends




						}
					});
				} else if (responseStatusCode == 401 || responseStatusCode == 403){

					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from Jobcommentsapi  for jobinternalid, details are :  " + info + " error info : " + JSON.stringify(error);
							ilsctx.setVariable("ExitStatus", "500")
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "mjcs_017 response received from jobcommentapi for jobinternalid:" + jobinternalid + " " + responseStatusCode + " " + responseData + " details are : " + info;
							ilsctx.setVariable("ExitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});

				}
				else {

					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "failure in reading message from Jobcommentsapi  for jobinternalid, details are :  " + info + " error info : " + JSON.stringify(error);
							ilsctx.setVariable("ExitStatus", "500")
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = " response received from jobcommentapi for jobinternalid:" + jobinternalid + " " + responseStatusCode + " " + responseData + " details are : " + info;
							ilsctx.setVariable("ExitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});

				}
			}
		});
	}

});								
