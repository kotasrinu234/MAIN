var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

var ctx = session.name("mas")|| session.createContext("mas");
//set stylesheet parameters to variable
var lookupURL = session.parameters.lookupURL;
var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.osiApiToken;
var nullCheckRequired = session.parameters.nullCheckRequired;
var omsExternalURLV1 = session.parameters.omsExternalURLV1;
var Commentmessage = session.parameters.Commentmessage;
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("nullCheckRequired", nullCheckRequired);
ctx.setVariable("omsExternalURLV1", omsExternalURLV1);
ctx.setVariable("Commentmessage", Commentmessage);
}
});
