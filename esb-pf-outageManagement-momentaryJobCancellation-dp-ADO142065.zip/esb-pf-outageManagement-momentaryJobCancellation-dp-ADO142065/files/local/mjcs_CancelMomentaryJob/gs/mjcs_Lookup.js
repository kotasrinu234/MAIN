var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("mas") || session.createContext("mas");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var jobtypeID = incomingdata.data[0].jobTypeID;

		var lookupMessage = {
			"lookupReq": {
				"type": [
					{
						"name": "jobTypes.workflows",
						"id": jobtypeID,
						"label": "Canceled"
					}
				]
			}
		}

		var url = lookupURL;
		var LookupServiceResponse = {
			target: url,
			method: 'POST',
			contentType: 'application/json',
			data: lookupMessage
		};
		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
		urlopen.open(LookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "mjcs_002 urlopen connect error with mjcs LookupServiceResponse for jobtypeID , details are : " + info + " error details : " + JSON.stringify(error)
				ilsctx.setVariable("ExitStatus", "500");
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "mjcs_015 failure in getting message from mjcs LookupServiceResponse for jobtypeID , details are :" + info + " error details : " + JSON.stringify(error)
							ilsctx.setVariable("ExitStatus", "500")
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from mas LookupServiceResponse " + responseData);
							var lookupResponse = JSON.parse(responseData)
							ilsctx.setVariable("ExitStatus", "0")
							var ctx = session.name("mas") || session.createContext("mas");
							var lookupstatus;
							if (lookupResponse.lookupRep.type[0].result == 0) {
								lookupstatus = lookupResponse.lookupRep.type[0].status;
								logger.debug("lookupstatus+++" + lookupstatus);
								ctx.setVariable("lookupstatus", lookupstatus);
							}
							else {
								var errorinfo = "mjcs_003 lookup service result code for mjcs LookupServiceResponse for jobtypeID  is " + lookupResponse.lookupRep.type[0].result + " details are :" + info;
								ilsctx.setVariable("ExitStatus", "500")
								logger.error(errorinfo);
								session.reject(errorinfo);
							}// lookup end;

						}
					});

				} else {
					var errorinfo = "mjcs_016 lookup service from mjcs LookupServiceResponse for jobtypeID responsecode is " + responseStatusCode + " details are :" + info;
					ilsctx.setVariable("ExitStatus", responseStatusCode)
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			}
		});
	}
});
