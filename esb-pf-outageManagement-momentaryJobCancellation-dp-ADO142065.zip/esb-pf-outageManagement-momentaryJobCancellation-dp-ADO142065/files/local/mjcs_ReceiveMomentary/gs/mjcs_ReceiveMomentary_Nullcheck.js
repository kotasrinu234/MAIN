var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var ctx = session.name("mas")|| session.createContext("mas");	
	var nullCheckRequired = ctx.getVar("nullCheckRequired");
	
	if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		
		if(nullCheckRequired == 'yes'){
	
			var jobTypeID = incomingdata.data[0].jobTypeID;
			if (jobTypeID === null || jobTypeID === '' || jobTypeID === undefined) {
				logger.error('mjcs_007 jobTypeID value is not present in job input payload');
	            session.reject('jobTypeID value is not present in job input payload');
	        }	
			var id = incomingdata.data[0].id;
			if (id === null || id === '' || id === undefined) {
				logger.error('mjcs_007 id is not present in job input payload');
				session.reject('id is not present in job input payload');
	        }		
			
			
		}
	}
	});
