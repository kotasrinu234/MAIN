var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entrydescription = session.parameters.entrydescription;
if (entrydescription !== undefined || entrydescription !== null || entrydescription !== '') {
	ctx.setVariable('entryDescription', entrydescription);
}
var messageType = session.parameters.messageType;
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var msgID = incomingdata.CallBackData.messageID;
		if (msgID === undefined || msgID === null || msgID === '') {
			ctx.setVariable("correlationID", "");
		}
		else {
			ctx.setVariable("correlationID", msgID);
		}
		var jobID = incomingdata.CreateJobRequest.JobIDGUID;
		if (jobID === undefined || jobID === null || jobID === '') {
			ctx.setVariable("jobID", "");
		}
		else {
			ctx.setVariable("jobID", jobID);
		}
		var jobType = incomingdata.CreateJobRequest.JobType;
		if (jobType === undefined || jobType === null || jobType === '') {
			ctx.setVariable("jobType", "");
		}
		else {
			ctx.setVariable("jobType", jobType);
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
	}
});
