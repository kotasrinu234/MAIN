var urlopen = require('urlopen');
var hm = require('header-metadata');
var ctx = session.name("jobCreation") || session.createContext("jobCreation");
var lookupURL = ctx.getVar("lookupURL");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var exitdescription = session.parameters.exitdescription;
var exitDestination = session.parameters.omsExternalURL;
if (exitDestination !== undefined || exitDestination !== null || exitDestination !== '') {
	ctx.setVariable("exitDestination", exitDestination);
}
var logger = console.options({
	'category': 'all'
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading Incoming Data" + JSON.stringify(error));
		session.reject(readAsJSONError);
	}
	else {
		var JobIDGUID = incomingdata.CreateJobRequest.JobIDGUID;
		ctx.setVariable("JobIDGUID", JobIDGUID);
		var jobType = incomingdata.CreateJobRequest.JobType;
		var linkType = incomingdata.CreateJobRequest.LinkType;
		var resourceNeeded = incomingdata.CreateJobRequest.ResourceNeeded;
		if (linkType === undefined && resourceNeeded === undefined) {
			var jobTypePay = [{
				"name": "jobTypes",
				"label": jobType
			}];
		}
		else if (linkType === undefined && resourceNeeded !== undefined) {
			var jobTypePay = [{
				"name": "jobTypes",
				"label": jobType
			},
			{
				"name": "jobCustomFields",
				"externalLabel": "Resource_Needed",
				"label": resourceNeeded
			}];
		}
		else if (linkType !== undefined && resourceNeeded === undefined) {
			var jobTypePay = [{
				"name": "linkTypes",
				"label": linkType
			},
			{
				"name": "jobTypes",
				"label": jobType
			}];
		}
		else {
			var jobTypePay = [
				{
					"name": "jobTypes",
					"label": jobType
				},
				{
					"name": "linkTypes",
					"label": linkType
				},
				{
					"name": "jobCustomFields",
					"externalLabel": "Resource_Needed",
					"label": resourceNeeded
				}];
		}
		ctx.setVariable("jobTypePay", jobTypePay);
		var lookupRequestForJob_Link_Resource = {
			"lookupReq": {
				"type":
					jobTypePay
			}
		};
		ctx.setVariable("lookupRequestForJob_Link_Resource", lookupRequestForJob_Link_Resource);
		var LookupServiceResponse = {
			target: lookupURL,
			method: 'POST',
			contentType: 'application/json',
			data: lookupRequestForJob_Link_Resource
		};
		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
		try {
			urlopen.open(LookupServiceResponse, function(error, response) {
				if (error) {
					var errorinfo = "urlopen connect error from Job LookupServiceResponse, details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatus", "500");
					logger.error("urlopen connect error from Job LookupServiceResponse" + JSON.stringify(errorinfo));
					session.reject("urlopen connect error from Job LookupServiceResponse" + JSON.stringify(errorinfo));
				}
				else {
					var responseStatusCode = response.statusCode;
					var responsePhrase = response.reasonPhrase;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in reading the message for Job LookupServiceResponse , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", "500");
								ilsctx.setVariable("errorPhrase", responsePhrase);
								logger.error("Failure in reading the message for Job LookupServiceResponse " + JSON.stringify(errorinfo));
								session.reject("Failure in reading the message for Job LookupServiceResponse " + JSON.stringify(errorinfo));
							}
							else {
								hm.response.statusCode = responseStatusCode;
								logger.debug("Response received from the LookupServiceResponse " + responseData);
								ctx.setVariable("res", responseData);
								var type = responseData.lookupRep.type
								for (var m = 0; m < type.length; m++) {
									if (responseData.lookupRep.type[m].name == 'jobTypes') {
										if (responseData.lookupRep.type[m].result == 1) {
											var errorinfo = "omsapiJob_002:Invalid jobType Lookup Response , details are : " + info + "; response info :" + responseData;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", "500");
											logger.error("omsapiJob_002:Invalid jobType Lookup Response :" + JSON.stringify(responseData))
											session.reject("Invalid jobType Lookup Response :" + JSON.stringify(responseData))
										}
										else {
											ilsctx.setVariable("exitDescription", exitdescription);
											ilsctx.setVariable("exitStatus", "0");
											var jobTypeId = responseData.lookupRep.type[m].id;
											ctx.setVariable("jobType_Id", jobTypeId);
										}
									}
									if (responseData.lookupRep.type[m].name == 'linkTypes') {
										if (responseData.lookupRep.type[m].result == 1) {
											var errorinfo = "omsapiJob_003:Invalid linkType Lookup Response , details are : " + info + "; response info :" + responseData;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", "500");
											logger.error("omsapiJob_003:Invalid linkType Lookup Response :" + JSON.stringify(responseData))
											session.reject("Invalid linkType Lookup Response :" + JSON.stringify(responseData))
										}
										else {
											ilsctx.setVariable("exitDescription", exitdescription);
											ilsctx.setVariable("exitStatus", "0");
											var linkTypeId = responseData.lookupRep.type[m].id
											ctx.setVariable("linkType_Id", linkTypeId);
										}
									}
									if (responseData.lookupRep.type[m].name == 'jobCustomFields') {
										if (responseData.lookupRep.type[m].result == 1) {
											var errorinfo = "omsapiJob_004:Invalid resource Lookup Response , details are : " + info + "; response info :" + responseData;
											ilsctx.setVariable("errorDescription", errorinfo);
											ilsctx.setVariable("errorStatus", "500");
											logger.error("omsapiJob_004:Invalid resource Lookup Response :" + JSON.stringify(responseData))
											session.reject("Invalid resource Lookup Response :" + JSON.stringify(responseData))
										}
										else {
											ilsctx.setVariable("exitDescription", exitdescription);
											ilsctx.setVariable("exitStatus", "0");
											var resourceId = responseData.lookupRep.type[m].status
											ctx.setVariable("resource_Id", resourceId);
										}
									}
								}
							}
						});
					}
					else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapiJob_005:Failure in reading the message for Job LookupServiceResponse , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", responseStatusCode);
								ilsctx.setVariable("errorPhrase", responsePhrase);
								logger.error("omsapiJob_005:Failure in reading the message for Job LookupServiceResponse " + JSON.stringify(errorinfo));
								session.reject("omsapiJob_005:Failure in reading the message for Job LookupServiceResponse " + JSON.stringify(errorinfo));
							} else {
								var errorinfo = "omsapiJob_005:Error received in reading lookup response data , details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", responseStatusCode);
								ilsctx.setVariable("errorPhrase", responsePhrase);
								logger.error("omsapiJob_005:Error received in reading lookup response data " + responseStatusCode + responseData);
								session.reject("Error received in reading lookup response data " + responseStatusCode + responseData);
							}
						})
					}
				}
			});
		}
		catch (error) {
			var errorinfo = "urlopen connect error from Job LookupServiceResponse, details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("urlopen connect error from Job LookupServiceResponse" + JSON.stringify(errorinfo));
			session.reject("urlopen connect error from Job LookupServiceResponse" + JSON.stringify(errorinfo));
		}
	}
});
