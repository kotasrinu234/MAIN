var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("jobCreation") || session.createContext("jobCreation");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var omsExternalURL = ctx.getVar("omsExternalURL");
var apiToken = ctx.getVar("apiToken");
var exitdescription = session.parameters.exitdescription;
var errorDesc = session.parameters.errorDesc;
var logger = console.options({
	'category': 'all'
});
var JobIDGUID = ctx.getVar("JobIDGUID")
if ((JobIDGUID === null) || (JobIDGUID === undefined) || (JobIDGUID === '')) {
}
else {
	session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			logger.error("Error in reading Incoming Data" + JSON.stringify(error));
			session.reject(readAsJSONError);
		} else {
			var JobIDGUID = incomingdata.CreateJobRequest.JobIDGUID;
			var jobUrl = omsExternalURL + '/api/ServiceType/Electric/Job/' + JobIDGUID;
			var getJobApi = {
				target: jobUrl,
				sslClientProfile: 'omsapiJob_ssl_ClientProfile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': apiToken
				},
			};
			var info = " TargetURL :" + getJobApi.target + "; Method :" + getJobApi.method;
			try {
				urlopen.open(getJobApi, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error with getJobApi, details are : " + info + "; error info :" + error;
						ilsctx.setVariable("exitDescription", errorinfo);
						ilsctx.setVariable("exitStatus", "500");
						ilsctx.setVariable("exitDestination", omsExternalURL);
						logger.error("urlopen connect error with getJobApi" + JSON.stringify(error));
						var ctx = session.name("jobCreation") || session.createContext("jobCreation");
						ctx.setVariable("retry", 'yes');
						var ErrorTxt = " urlopen connect error with getJobApi" + JSON.stringify(error);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						//session.reject("urlopen connect error with getJobApi");
					} else {
						var responseStatusCode = response.statusCode;
						var responsePhrase = response.reasonPhrase;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									var errorinfo = "failure in putting message to getJobApi, details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", responseStatusCode);
									ilsctx.setVariable("errorPhrase", responsePhrase);
									logger.error("failure in putting message to getJobApi" + JSON.stringify(error));
									session.reject("failure in putting message to getJobApi");
								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from getJobApi " + ":" + responseStatusCode);
									var getJobApiResponse = JSON.parse(responseData);
									var ctx = session.name("jobCreation") || session.createContext("jobCreation");
									if (exitdescription !== undefined || exitdescription !== null || exitdescription !== '') {
										ilsctx.setVariable('exitDescription', exitdescription);
									}
									ilsctx.setVariable("exitStatus", "0");
									ilsctx.setVariable("exitDestination", omsExternalURL);
									var operationEventIDs = getJobApiResponse.operationEventIDs;
									if (operationEventIDs == undefined) {
										operationEventIDs = '';
										ctx.setVariable("operationEventIDs", operationEventIDs);
									} else {
										ctx.setVariable("operationEventIDs", operationEventIDs);
									}


									var voltage = getJobApiResponse.voltage;
									if (voltage == undefined) {
										voltage = '';
										ctx.setVariable("voltage", voltage);
									} else {
										ctx.setVariable("voltage", voltage);
									}


									var substation = getJobApiResponse.substation;
									if (substation == undefined) {
										substation = '';
										ctx.setVariable("substation", substation);
									} else {
										ctx.setVariable("substation", substation);
									}

									var nominalFeeder = getJobApiResponse.nominalFeeder;
									if (nominalFeeder == undefined) {
										nominalFeeder = '';
										ctx.setVariable("nominalFeeder", nominalFeeder);
									} else {
										ctx.setVariable("nominalFeeder", nominalFeeder);
									}

									var feederName = getJobApiResponse.feederName;
									if (feederName == undefined) {
										feederName = '';
										ctx.setVariable("feederName", feederName);
									} else {
										ctx.setVariable("feederName", feederName);
									}

								}
							});
						} else if (responseStatusCode == 400 || responseStatusCode == 404 || responseStatusCode == 409) {
							var ctx = session.name("jobCreation") || session.createContext("jobCreation");
							ctx.setVariable("businessError", 'yes');
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading the response data from getJobAPI, details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", responseStatusCode);
									ilsctx.setVariable("errorPhrase", responsePhrase);
									logger.error("Failure in reading the response data from getJobAPI" + JSON.stringify(error));
									session.reject("Failure in reading the response data from getJobAPI");
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("omsapiJob_006:Error returned from getJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
									var res = responseData.toString();
									var QueueMessage = {
										"CallBackData": {
											"messageID": incomingdata.CallBackData.messageID,
											"Client": incomingdata.CallBackData.Client,
											"ServiceName": incomingdata.CallBackData.ServiceName,
											"ExternalRefID": incomingdata.CallBackData.ExternalRefID
										},
										"ErrorMessage": res
									}
								};
								var targetQueue = session.parameters.Queue;
								var options = {
									target: targetQueue,
									data: QueueMessage
								};
								var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
								try {
									urlopen.open(options, function(error, response) {
										var hm = require('header-metadata');
										if (error) {
											//logger.error(' Mqurlopen.open error');
											//session.reject('** Mqurlopen.open error');
											var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue, details are : " + info + "; error info :" + error + "response info" + res;
											ilsctx.setVariable("exitDescription", errorinfo);
											ilsctx.setVariable("exitStatus", "500");
											ilsctx.setVariable("exitDestination", targetQueue);
											hm.response.statusCode = 500;
											var ctx = session.name("jobCreation") || session.createContext("jobCreation");
											ctx.setVariable("retry", 'yes');
											logger.error("error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
											var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
											ctx.setVariable("ErrorTxt", ErrorTxt);
										} else {
											var mqrc = response.statusCode;
											if (mqrc == 0) {
												response.readAsBuffer(function(readError, responseData) {
													if (readError) {
														hm.response.statusCode = 500
														var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue, details are : " + info + "; error info :" + error + "response info" + res;
														ilsctx.setVariable("errorDescription", errorinfo);
														ilsctx.setVariable("errorStatus", "500");
														ilsctx.setVariable("errorPhrase", res);
													} else {
														console.log("MQResponseData " + responseData);
														if (errorDesc !== undefined || errorDesc !== null || errorDesc !== '') {
															ilsctx.setVariable('exitDescription', errorDesc);
														}
														ilsctx.setVariable("exitStatus", "0");
														ilsctx.setVariable("exitDestination", targetQueue);
													}
												});
											} else {
												//logger.error(' ** Mqurlopen.open error [MQRC=' + mqrc + ']');
												//session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
												hm.response.statusCode = 500
												var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue , details are : " + info + "; error info :" + error;
												ilsctx.setVariable("exitDescription", errorinfo);
												ilsctx.setVariable("exitDestination", targetQueue);
												ilsctx.setVariable("exitStatus", "500");
												var ctx = session.name("jobCreation") || session.createContext("jobCreation");
												ctx.setVariable("retry", 'yes');
												logger.error("error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
												var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
												ctx.setVariable("ErrorTxt", ErrorTxt);
											}
										}
									});
								}
								catch (error) {
									var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue, details are : " + info + "; error info :" + error + "response info" + res;
									ilsctx.setVariable("exitDescription", errorinfo);
									ilsctx.setVariable("exitStatus", "500");
									ilsctx.setVariable("exitDestination", targetQueue);
									hm.response.statusCode = 500;
									var ctx = session.name("jobCreation") || session.createContext("jobCreation");
									ctx.setVariable("retry", 'yes');
									logger.error("error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
									var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
								}
							});
						} else if (responseStatusCode == 401) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "omsapijob_014:Failure in reading the response data from getJobAPI, details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", "401");
									logger.error("omsapijob_014:Failure in reading the response data from getJobAPI" + JSON.stringify(error));
									session.reject("omsapijob_014:Failure in reading the response data from getJobAPI");
								} else {
									hm.current.statusCode = responseStatusCode;
									var errorinfo = "omsapijob_013:Error returned from getJobAPI " + ": with statusCode " + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", "401");
									logger.error("omsapijob_013:Error returned from getJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
									session.reject("omsapijob_013:Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading the response data from getJobAPI, details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", responseStatusCode);
									logger.error("Failure in reading the response data from getJobAPI" + JSON.stringify(error));
									session.reject("Failure in reading the response data from getJobAPI");
								} else {
									hm.current.statusCode = responseStatusCode;
									var errorinfo = "Error returned from getJobAPI " + ": with statusCode " + responseStatusCode + ", details are : " + info + "; response info :" + responseData;
									ilsctx.setVariable("exitDescription", errorinfo);
									ilsctx.setVariable("exitStatus", responseStatusCode);
									ilsctx.setVariable("exitDestination", omsExternalURL);
									logger.error("Error returned from getJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
									ctx.setVariable("retry", 'yes');
									var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
									//session.reject("Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}
					}
				});
			}
			catch (error) { 
				var errorinfo = "urlopen connect error with getJobApi, details are : " + info + "; error info :" + error;
				ilsctx.setVariable("exitDescription", errorinfo);
				ilsctx.setVariable("exitStatus", "500");
				ilsctx.setVariable("exitDestination", omsExternalURL);
				logger.error("urlopen connect error with getJobApi" + JSON.stringify(error));
				var ctx = session.name("jobCreation") || session.createContext("jobCreation");
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = " urlopen connect error with getJobApi" + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
			}
		}
	});
}
