var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("jobCreation") || session.createContext("jobCreation");
var omsExternalURL = ctx.getVar("omsExternalURL");
var apiToken = ctx.getVar("apiToken");
var jobType_Id = ctx.getVar("jobType_Id");
var linkType_Id = ctx.getVar("linkType_Id");
var resource_Id = ctx.getVar("resource_Id");
var feederName = ctx.getVar("feederName");
var nominalFeeder = ctx.getVar("nominalFeeder");
var substation = ctx.getVar("substation");
var voltage = ctx.getVar("voltage");
var operationEventIDs = ctx.getVar("operationEventIDs");
var payload = {};
var ilsctx = session.name("ILS") || session.createContext("ILS");
var exitdescription = session.parameters.exitdescription;
var errorDesc = session.parameters.errorDesc;
var logger = console.options({
	'category': 'all'
});
var retry = ctx.getVariable("retry");
var businessError = ctx.getVariable("businessError");

if (retry !== 'yes' && businessError !== 'yes') {
	session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
		if (readAsJSONError) {
			logger.error("Error in reading Incoming Data" + JSON.stringify(error));
			session.reject(readAsJSONError);
		} else {
			var ctx = session.name("jobCreation") || session.createContext("jobCreation");
			var JobIDGUID = incomingdata.CreateJobRequest.JobIDGUID;
			var jobAddress = incomingdata.CreateJobRequest.JobAddress;
			var longitude = incomingdata.CreateJobRequest.Longitude;
			var latitude = incomingdata.CreateJobRequest.Latitude;
			var jobType = incomingdata.CreateJobRequest.JobType;
			var linkType = incomingdata.CreateJobRequest.LinkType;
			var resourceNeeded = incomingdata.CreateJobRequest.ResourceNeeded;
			var devId = incomingdata.CreateJobRequest.DeviceId;
			var notes = incomingdata.CreateJobRequest.Notes;
			var JobTypePay = {
				"jobTypeID": jobType_Id
			}
			payload = {
				...payload,
				...JobTypePay
			};
			ctx.setVariable("payload1", payload);
			if ((JobIDGUID === null) || (JobIDGUID === undefined) || (JobIDGUID === '')) {

			}
			else {
				if (linkType !== undefined) {
					var LinkIdPay = {
						"addLinks": [{
							"linkedID": JobIDGUID,
							"linkTypeID": linkType_Id
						}]
					}
				}
				else {
					var LinkIdPay = {
						"addLinks": [{
							"linkedID": JobIDGUID
						}]
					}
				}
				var jobPayload = {
					"operationEventIDs": operationEventIDs,
					"voltage": voltage,
					"substation": substation,
					"nominalFeeder": nominalFeeder,
					"feederName": feederName
				}
				payload = {
					...payload,
					...LinkIdPay
				}
				ctx.setVariable("payload2", payload)
				payload = {
					...payload,
					...jobPayload
				}
				ctx.setVariable("payload3", payload)
			}
			if ((jobAddress === '') || (jobAddress === undefined) || (jobAddress === null)) {

			}
			else {
				var jobaddressPayLoad = {
					"address": jobAddress
				}
				payload = {
					...payload,
					...jobaddressPayLoad
				}
				ctx.setVariable("payload4", payload)

			}
			if ((devId !== '') && (devId !== undefined) && (devId !== null)) {
				var devIdPayload = {
					"networkModelExternalID": devId
				}
				payload = {
					...payload,
					...devIdPayload
				}
				ctx.setVariable("payload5", payload)
			}


			var locpayload = {
				"location": {
					"coordinates": [
						longitude,
						latitude
					],
					"type": "POINT"
				}
			}
			payload = {
				...payload,
				...locpayload
			};
			ctx.setVariable("payload6", payload);
			if (resource_Id !== undefined) {
				var resNeededPayload = {
					"customFieldValues": {
						"Resource_Needed": resource_Id
					}
				}
				payload = { ...payload, ...resNeededPayload }
				ctx.setVariable("payload7", payload)
			}
			var createJobAPIUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job';
			var createJobAPI = {
				target: createJobAPIUrl,
				sslClientProfile: 'omsapiJob_ssl_ClientProfile',
				method: 'POST',
				contentType: 'application/json',
				data: payload,
				headers: {
					'osiApiToken': apiToken
				}
			};
			var info = " TargetURL :" + createJobAPI.target + "; Method :" + createJobAPI.method + "; Data :" + JSON.stringify(createJobAPI.data) + ". ";
			try {
				urlopen.open(createJobAPI, function(error, response) {
					if (error) {
						var errorinfo = "omsapijob_012:urlopen connect error with POST call for OMS api, details are : " + info + "; error info :" + error;
						logger.error("urlopen connect error with OMS" + JSON.stringify(errorinfo));
						ilsctx.setVariable("exitDescription", errorinfo);
						ilsctx.setVariable("exitStatus", "500");
						ilsctx.setVariable("exitDestination", omsExternalURL);
						var ctx = session.name("jobCreation") || session.createContext("jobCreation");
						ctx.setVariable("retry", 'yes');
						var ErrorTxt = "omsapijob_012:urlopen connect error with POST call for OMS api" + JSON.stringify(error);
						ctx.setVariable("ErrorTxt", ErrorTxt);
						//session.reject("urlopen connect error with OMS" + JSON.stringify(error));
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting the response from createJobAPI, details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", "500");
									logger.error("Failure in getting the response from createJobAPI" + JSON.stringify(error));
									session.reject("Failure in getting the response from createJobAPI" + JSON.stringify(error));
								} else {
									hm.response.statusCode = '200 OK';
									logger.debug("Response received from createJobAPI :" + responseData);
									if ((notes === null) || (notes === undefined) || (notes === '')) { } else {
										//Start Comment Call
										var jobId = responseData.id;
										var commentUrl = omsExternalURL + '/api/ServiceType/Electric/Job/' + jobId + '/Comment';
										var Comment = notes;
										var CommentPayload = {
											"comment": Comment
										};
										var commentApi = {
											target: commentUrl,
											sslClientProfile: 'omsapiJob_ssl_ClientProfile',
											method: 'POST',
											contentType: 'application/json',
											data: CommentPayload,
											headers: {
												'osiApiToken': apiToken
											},
										};
										var info = " TargetURL :" + commentApi.target + "; Method :" + commentApi.method + "; Data :" + JSON.stringify(commentApi.data) + ". ";
										try {
											urlopen.open(commentApi, function(error, response) {
												if (error) {
													var errorinfo = "omsapijob_012:urlopen connect error with commentApi, details are : " + info + "; error info :" + error;
													ilsctx.setVariable("exitDescription", errorinfo);
													ilsctx.setVariable("exitStatus", "500");
													ilsctx.setVariable("exitDestination", omsExternalURL);
													logger.error("urlopen connect error with commentApi" + JSON.stringify(errorinfo));
													//session.reject("urlopen connect error with commentApi");
													var ctx = session.name("jobCreation") || session.createContext("jobCreation");
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = "omsapijob_012:urlopen connect error with POST call for OMS api" + JSON.stringify(errorinfo);
													ctx.setVariable("ErrorTxt", ErrorTxt);
												} else {
													var responseStatusCode = response.statusCode;
													var responsePhrase = response.reasonPhrase;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																//dp:reject stop the transaction and go error rule with error code and description
																var errorinfo = "failure in putting message to commentApi, details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", "500");
																logger.error("failure in putting message to commentApi" + JSON.stringify(error));
																session.reject("failure in putting message to commentApi");
															} else {
																ilsctx.setVariable("exitDescription", exitdescription);
																ilsctx.setVariable("exitStatus", "0");
																ilsctx.setVariable("exitDestination", omsExternalURL);
																hm.response.statusCode = responseStatusCode;
																logger.debug("response received from commentApi " + ":" + responseStatusCode);
																var getCommentApiResponse = JSON.parse(responseData);
																var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																ctx.setVariable('getCommentApiResponse', getCommentApiResponse);
															}
														});
													} else if (responseStatusCode == 400 || responseStatusCode == 404) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "Failure in reading the response data from commentApi, details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", responseStatusCode);
																ilsctx.setVariable("errorPhrase", responsePhrase);
																logger.error("Failure in reading the response data from commentApi" + JSON.stringify(error));
																session.reject("Failure in reading the response data from commentApi");
															} else {
																hm.current.statusCode = responseStatusCode;
																logger.error("omsapiJob_008:Error returned from commentApi " + ": with statusCode " + responseStatusCode + " " + responseData);
																var res = responseData.toString();
																var QueueMessage = {
																	"CallBackData": {
																		"messageID": incomingdata.CallBackData.messageID,
																		"Client": incomingdata.CallBackData.Client,
																		"ServiceName": incomingdata.CallBackData.ServiceName,
																		"ExternalRefID": incomingdata.CallBackData.ExternalRefID
																	},
																	"ErrorMessage": res
																}
															};
															var targetQueue = session.parameters.Queue;
															var options = {
																target: targetQueue,
																data: QueueMessage
															};
															var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
															try {
																urlopen.open(options, function(error, response) {
																	var hm = require('header-metadata');
																	if (error) {
																		var errorinfo = "url connection error 'callQueryTrue', details are : " + info + "; error info :" + error + res;
																		ilsctx.setVariable("exitDescription", errorinfo);
																		ilsctx.setVariable("exitStatus", "500");
																		ilsctx.setVariable("exitDestination", targetQueue);
																		var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																		ctx.setVariable("retry", 'yes');
																		logger.error("error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + errorinfo);
																		var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + errorinfo);
																		ctx.setVariable("ErrorTxt", ErrorTxt);
																		hm.response.statusCode = 500;
																	} else {
																		var mqrc = response.statusCode;
																		if (mqrc == 0) {
																			var replyMQMD = response.get({
																				type: 'mq'
																			}, 'MQMD');
																			var replyMQRFH2 = response.get({
																				type: 'mq'
																			}, 'MQRFH2');
																			response.readAsBuffer(function(readError, responseData) {
																				if (readError) {
																					hm.response.statusCode = 500
																					var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue , details are : " + info + "; error info :" + error + res;
																					ilsctx.setVariable("exitDescription", errorinfo);
																					ilsctx.setVariable("exitStatus", "500");
																					ilsctx.setVariable("exitDestination", targetQueue);
																					var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																					ctx.setVariable("retry", 'yes');
																					logger.debug("error omsapijob_sendJobCreation while keeping message to queue is " + errorinfo);
																					var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + errorinfo);
																					ctx.setVariable("ErrorTxt", ErrorTxt);
																				} else {
																					ilsctx.setVariable("exitDescription", errorDesc);
																					ilsctx.setVariable("exitStatus", "0");
																					ilsctx.setVariable("exitDestination", targetQueue);
																					console.log("MQResponseData " + responseData);
																				}
																			});
																		} else {
																			//logger.error(' ** Mqurlopen.open error [MQRC=' + mqrc + ']');
																			//session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
																			hm.response.statusCode = 500
																			var errorinfo = "response code for omsapijob_sendJobCreation , details are : " + info + "; error info :" + error + " urlopen.open error [MQRC=" + mqrc + "]" + res;
																			ilsctx.setVariable("exitDescription", errorinfo);
																			ilsctx.setVariable("exitStatus", "500");
																			ilsctx.setVariable("exitDestination", targetQueue);
																			var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																			ctx.setVariable("retry", 'yes');
																			logger.error("response code for omsapijob_sendJobCreation " + targetQueue + " urlopen.open error [MQRC=" + mqrc + "]");
																			var ErrorTxt = ("response code for omsapijob_sendJobCreation " + targetQueue + " urlopen.open error [MQRC=" + mqrc + "]");
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																		}
																	}
																});
															}
															catch (error) {
																var errorinfo = "url connection error 'callQueryTrue', details are : " + info + "; error info :" + error + res;
																ilsctx.setVariable("exitDescription", errorinfo);
																ilsctx.setVariable("exitStatus", "500");
																ilsctx.setVariable("exitDestination", targetQueue);
																var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																ctx.setVariable("retry", 'yes');
																logger.error("error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + errorinfo);
																var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + errorinfo);
																ctx.setVariable("ErrorTxt", ErrorTxt);
																hm.response.statusCode = 500;
															}
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "omsapijob_015:Failure in reading the response data from commentApi, details are : " + info + "; error info :" + error;
																ilsctx.setVariable("errorDescription", errorinfo);
																ilsctx.setVariable("errorStatus", responseStatusCode);
																ilsctx.setVariable("errorPhrase", responsePhrase);
																logger.error("omsapijob_015:Failure in reading the response data from commentApi" + JSON.stringify(error));
																session.reject("omsapijob_015:Failure in reading the response data from commentApi");
															} else {
																hm.current.statusCode = responseStatusCode;
																var errorinfo = "omsapiJob_008:Error returned from commentApi " + responseStatusCode + responsePhrase + ", details are : " + info + "; response info :" + responseData;
																ilsctx.setVariable("exitDescription", errorinfo);
																ilsctx.setVariable("exitStatus", responseStatusCode);
																ilsctx.setVariable("exitDestination", omsExternalURL);
																logger.error("omsapiJob_008:Error returned from commentApi " + ": with statusCode " + responseStatusCode + " " + responseData);
																//session.reject("Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " " + responseData);
															}
														});
													}
												}
											});
										}
										catch (error) {
											var errorinfo = "omsapijob_012:urlopen connect error with commentApi, details are : " + info + "; error info :" + error;
											ilsctx.setVariable("exitDescription", errorinfo);
											ilsctx.setVariable("exitStatus", "500");
											ilsctx.setVariable("exitDestination", omsExternalURL);
											logger.error("urlopen connect error with commentApi" + JSON.stringify(errorinfo));
											//session.reject("urlopen connect error with commentApi");
											var ctx = session.name("jobCreation") || session.createContext("jobCreation");
											ctx.setVariable("retry", 'yes');
											var ErrorTxt = "omsapijob_012:urlopen connect error with POST call for OMS api" + JSON.stringify(errorinfo);
											ctx.setVariable("ErrorTxt", ErrorTxt);
										}
									}
								}
							});
						} else if (responseStatusCode == 400 || responseStatusCode == 404 || responseStatusCode == 409) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in reading the response data from createJobAPI , details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", responseStatusCode);
									ilsctx.setVariable("errorPhrase", responsePhrase);
									logger.error("Failure in reading the response data from createJobAPI" + JSON.stringify(errorinfo));
									session.reject("Failure in reading the response data from createJobAPI");
								} else {
									hm.current.statusCode = responseStatusCode;
									logger.error("omsapiJob_007:Error returned from createJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
									var res = responseData.toString();
									var QueueMessage = {
										"CallBackData": {
											"messageID": incomingdata.CallBackData.messageID,
											"Client": incomingdata.CallBackData.Client,
											"ServiceName": incomingdata.CallBackData.ServiceName,
											"ExternalRefID": incomingdata.CallBackData.ExternalRefID
										},
										"ErrorMessage": res
									}
								};
								var targetQueue = session.parameters.Queue;
								var options = {
									target: targetQueue,
									data: QueueMessage
								};
								var info = " TargetURL :" + options.target + "; Data :" + JSON.stringify(options.data) + ". ";
								try {
									urlopen.open(options, function(error, response) {
										var hm = require('header-metadata');
										if (error) {
											//logger.error(' Mqurlopen.open error');
											//session.reject('** Mqurlopen.open error');
											hm.response.statusCode = 500;
											var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue , details are : " + info + "; error info :" + error + res;
											ilsctx.setVariable("exitDescription", errorinfo);
											ilsctx.setVariable("exitStatus", "500");
											ilsctx.setVariable("exitDestination", targetQueue);
											var ctx = session.name("jobCreation") || session.createContext("jobCreation");
											ctx.setVariable("retry", 'yes');
											logger.error("error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
											var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
											ctx.setVariable("ErrorTxt", ErrorTxt);
										} else {
											var mqrc = response.statusCode;
											if (mqrc == 0) {
												response.readAsBuffer(function(readError, responseData) {
													if (readError) {
														var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue , details are : " + info + "; error info :" + error + res;
														ilsctx.setVariable("errorDescription", errorinfo);
														ilsctx.setVariable("errorStatus", "500");
														hm.response.statusCode = 500
													} else {
														ilsctx.setVariable("exitDescription", errorDesc);
														ilsctx.setVariable("exitStatus", "0");
														ilsctx.setVariable("exitDestination", targetQueue);
														console.log("MQResponseData " + responseData);
													}
												});
											} else {
												//logger.error(' ** Mqurlopen.open error [MQRC=' + mqrc + ']');
												//session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
												hm.response.statusCode = 500
												var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue , details are : " + info + "; error info :" + error + res;
												ilsctx.setVariable("exitDescription", errorinfo);
												ilsctx.setVariable("exitStatus", "500");
												ilsctx.setVariable("exitDestination", targetQueue);
												var ctx = session.name("jobCreation") || session.createContext("jobCreation");
												ctx.setVariable("retry", 'yes');
												logger.error("error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + errorinfo);
												var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + errorinfo);
												ctx.setVariable("ErrorTxt", ErrorTxt);
											}
										}
									});
								}
								catch (error) {
									hm.response.statusCode = 500;
									var errorinfo = "omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue , details are : " + info + "; error info :" + error + res;
									ilsctx.setVariable("exitDescription", errorinfo);
									ilsctx.setVariable("exitStatus", "500");
									ilsctx.setVariable("exitDestination", targetQueue);
									var ctx = session.name("jobCreation") || session.createContext("jobCreation");
									ctx.setVariable("retry", 'yes');
									logger.error("error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
									var ErrorTxt = ("omsapijob_010:error omsapijob_sendJobCreation while keeping message to queue " + targetQueue + " is " + error);
									ctx.setVariable("ErrorTxt", ErrorTxt);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "omsapijob_016:Failure in reading the response data from createJobAPI, details are : " + info + "; error info :" + error;
									ilsctx.setVariable("errorDescription", errorinfo);
									ilsctx.setVariable("errorStatus", responseStatusCode);
									ilsctx.setVariable("errorPhrase", responsePhrase);
									logger.error("omsapijob_016:Failure in reading the response data from createJobAPI" + JSON.stringify(errorinfo));
									session.reject("omsapijob_016:Failure in reading the response data from createJobAPI" + JSON.stringify(errorinfo));
								} else {
									hm.current.statusCode = responseStatusCode;
									var errorinfo = "omsapijob_017:Error returned from createJobAPI " + responseStatusCode + responsePhrase + ", details are : " + info + "; response info :" + responseData;
									ilsctx.setVariable("exitDescription", errorinfo);
									ilsctx.setVariable("exitStatus", responseStatusCode);
									ilsctx.setVariable("exitDestination", omsExternalURL);
									logger.error("omsapijob_017:Error returned from createJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
									//session.reject("Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " " + responseData);
								}
							});
						}
					}
				});
			}
			catch (error) {
				var errorinfo = "omsapijob_012:urlopen connect error with POST call for OMS api, details are : " + info + "; error info :" + error;
				logger.error("urlopen connect error with OMS" + JSON.stringify(errorinfo));
				ilsctx.setVariable("exitDescription", errorinfo);
				ilsctx.setVariable("exitStatus", "500");
				ilsctx.setVariable("exitDestination", omsExternalURL);
				var ctx = session.name("jobCreation") || session.createContext("jobCreation");
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "omsapijob_012:urlopen connect error with POST call for OMS api" + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
			}
		}
	});
}
