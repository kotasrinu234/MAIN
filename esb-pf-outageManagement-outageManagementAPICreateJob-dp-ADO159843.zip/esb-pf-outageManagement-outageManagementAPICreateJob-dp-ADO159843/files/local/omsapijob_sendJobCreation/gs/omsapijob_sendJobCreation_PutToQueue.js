var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("jobCreation") || session.createContext("jobCreation");
var omsExternalURL = ctx.getVar("omsExternalURL");
var apiToken= ctx.getVar("apiToken");
var lookupURL = ctx.getVar("lookupURL")
var logger = console.options({
	'category': 'all'
});


session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading Incoming Data" + JSON.stringify(error));
		session.reject(readAsJSONError);
	} else {
		if ((omsExternalURL == undefined) || (omsExternalURL == ' ') || (omsExternalURL == null)) {
			logger.error("Error in connection with OMSUrl" + JSON.stringify(error));
			session.reject("Error in connection with OMSUrl" + JSON.stringify(error));
		} else {
					var Client = incomingdata.CallBackData.Client;
					var ServiceName = incomingdata.CallBackData.ServiceName;
					var ExternalRefID = incomingdata.CallBackData.ExternalRefID;
					var jobType = incomingdata.CreateJobRequest.JobType;
					var linkType = incomingdata.CreateJobRequest.LinkType;
					var resourceNeeded = incomingdata.CreateJobRequest.ResourceNeeded;
					var notes = incomingdata.CreateJobRequest.Notes;
					var JobIDGUID = incomingdata.CreateJobRequest.JobIDGUID;
					var jobAddress = incomingdata.CreateJobRequest.JobAddress;
					var longitude = incomingdata.CreateJobRequest.Longitude;
					var latitude = incomingdata.CreateJobRequest.Latitude;
					
					var lookupRequestForJob_Link_Resource = {
							"lookupReq": {
								"type": [
									{
										"name": "jobTypes",
						                "label": jobType
		
									},
									{
										"name": "linkTypes",
							            "label": linkType
		
		
									},
									{
										 "name": "jobCustomFields",
								    	 "externalLabel":"Resource_Needed",
							             "label": resourceNeeded
		
									}
		
								]
							}
						};
					
					var LookupServiceResponse = {
		
							target: lookupURL,
							method: 'POST',
							contentType: 'application/json',
							data: lookupRequestForJob_Link_Resource
		
						};
					
					urlopen.open(LookupServiceResponse, function(error, response) {
						if (error) {
							logger.error("urlopen connect error from Job LookupServiceResponse" + JSON.stringify(error));
							session.reject("urlopen connect error from Job LookupServiceResponse" + JSON.stringify(error));
							
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										logger.error("Failure in reading the message for Job LookupServiceResponse " + JSON.stringify(error));
										session.reject("Failure in reading the message for Job LookupServiceResponse " + JSON.stringify(error));
									} else {
										hm.response.statusCode = responseStatusCode;
										logger.debug("Response received from the LookupServiceResponse " + responseData);
										ctx.setVariable("res", responseData);
										if (responseData.lookupRep.type[0].result == 1) {
											logger.error("omsapiJob_005:Invalid jobType Lookup Response :" + JSON.stringify(responseData))
											session.reject("Invalid jobType Lookup Response :" + JSON.stringify(responseData))
										} else if(responseData.lookupRep.type[1].result == 1){
											session.reject("Invalid linkType Lookup Response :" + JSON.stringify(responseData))
											logger.error("omsapiJob_006:Invalid linkType Lookup Response :" + JSON.stringify(responseData))
										}else if(responseData.lookupRep.type[2].result == 1){
											session.reject("Invalid resource Lookup Response :" + JSON.stringify(responseData))
											logger.error("omsapiJob_007:Invalid resource Lookup Response :" + JSON.stringify(responseData))
										} else {
											var jobTypeId = responseData.lookupRep.type[0].id;
											var linkTypeId = responseData.lookupRep.type[1].id;
											var resourceId = responseData.lookupRep.type[2].status;
											ctx.setVariable("jobType_Id", jobTypeId);
											ctx.setVariable("linkType_Id", linkTypeId);
											ctx.setVariable("resource_Id", resourceId);
											
											//Start GET:/api/ServiceType/Electric/Job/6229c465ebeb0f1d75f4221a
											
											var jobUrl = omsExternalURL + '/api/ServiceType/Electric/Job/' + JobIDGUID;
											var getJobApi = {
													target: jobUrl,
													sslClientProfile: 'omsapiJob_ssl_ClientProfile',
													method: 'GET',
													contentType: 'application/json',
													headers: {
														'osiApiToken': apiToken
													},
												};
											
											urlopen.open(getJobApi, function(error, response) {
												if (error) {
													logger.error("omsapijob_014:urlopen connect error with getJobApi" + JSON.stringify(error));
													var ctx = session.name("jobCreation") || session.createContext("jobCreation");
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = " urlopen connect error with getJobApi" + JSON.stringify(error);
													ctx.setVariable("ErrorTxt", ErrorTxt);
													//session.reject("urlopen connect error with getJobApi");
												} else {
													var responseStatusCode = response.statusCode;
													var responsePhrase = response.reasonPhrase;
													if (responseStatusCode == 200 )  {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																//dp:reject stop the transaction and go error rule with error code and description
																logger.error("failure in putting message to getJobApi" + JSON.stringify(error));
																session.reject("failure in putting message to getJobApi");
															} else {
																hm.response.statusCode = responseStatusCode;
																logger.debug("response received from getJobApi "+":"+ responseStatusCode);		
																var getJobApiResponse = JSON.parse(responseData);
																var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																
																var operationEventIDs = getJobApiResponse.operationEventIDs;
																if (operationEventIDs == undefined) {
																	operationEventIDs ='';
																	ctx.setVariable("operationEventIDs", operationEventIDs);
															    }
																else{
																	ctx.setVariable("operationEventIDs", operationEventIDs);
																}
																
																
																var voltage = getJobApiResponse.voltage;
																if (voltage == undefined) {
																	voltage ='';
																	ctx.setVariable("voltage", voltage);
															    }
																else{
																	ctx.setVariable("voltage", voltage);
																}
																
																
																var substation = getJobApiResponse.substation;
																if (substation == undefined) {
																	substation ='';
																	ctx.setVariable("substation", substation);
															    }
																else{
																	ctx.setVariable("substation", substation);
																}
																
																var nominalFeeder = getJobApiResponse.nominalFeeder;
																if (nominalFeeder == undefined) {
																	nominalFeeder ='';
																	ctx.setVariable("nominalFeeder", nominalFeeder);
															    }
																else{
																	ctx.setVariable("nominalFeeder", nominalFeeder);
																}
																
																var feederName = getJobApiResponse.feederName;
																if (feederName == undefined) {
																	feederName ='';
																	ctx.setVariable("feederName", feederName);
															    }
																else{
																	ctx.setVariable("feederName", feederName);
																}
																
																//Start POST:/api/v1/ServiceType/Electric/Job
																var createJobAPIUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job' ;
																if((jobAddress === '') || (jobAddress === undefined) || (jobAddress === null)){
																	var payload = {
																		 "jobTypeID" : jobTypeId,
																		 "addLinks": [{
																		     "linkedID"   :  JobIDGUID,
																 		     "linkTypeID" :  linkTypeId
																		 }],
																		 "location": {
																		        "coordinates": [
																		        	longitude,               
																		          latitude               
																		        ],
																		        "type": "POINT"
																		      },
																		  "customFieldValues": {
																		    "Resource_Needed": resourceId        
																		  },

																		   //"Notes": notes,
																		  "operationEventIDs": operationEventIDs,
																		  "voltage"           :  voltage,
																		  "substation"        :  substation,
																		  "nominalFeeder"     :  nominalFeeder,
																		  "feederName"        :  feederName
																		}
																}
																else{
																	var payload = {
																		 "jobTypeID" : jobTypeId,
																		 "addLinks": [{
																		     "linkedID"   :  JobIDGUID,
																 		     "linkTypeID" :  linkTypeId
																		 }],
																		 "address": jobAddress,
																		 "location": {
																		        "coordinates": [
																		        	longitude,               
																		          latitude               
																		        ],
																		        "type": "POINT"
																		      },
																		  "customFieldValues": {
																		    "Resource_Needed": resourceId        
																		  },

																		   //"Notes": notes,
																		  "operationEventIDs": operationEventIDs,
																		  "voltage"           :  voltage,
																		  "substation"        :  substation,
																		  "nominalFeeder"     :  nominalFeeder,
																		  "feederName"        :  feederName
																		}
																}
																var createJobAPI =  {

																		target: createJobAPIUrl,
																		sslClientProfile: 'omsapiJob_ssl_ClientProfile',
																		method: 'POST',
																		contentType: 'application/json',
																		data: payload,
																		headers: {
																			'osiApiToken': apiToken
																		}
																	};
																urlopen.open(createJobAPI, function(error, response) {
																	if (error) {
																		logger.error("urlopen connect error with OMS" + JSON.stringify(error));
																		var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																		ctx.setVariable("retry", 'yes');
																		var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
																		ctx.setVariable("ErrorTxt", ErrorTxt);
																		//session.reject("urlopen connect error with OMS" + JSON.stringify(error));
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200) {
																			response.readAsJSON(function(error, responseData) {
																				if (error) {
																					logger.error("Failure in getting the response from createJobAPI" + JSON.stringify(error));
																					session.reject("Failure in getting the response from createJobAPI" + JSON.stringify(error));

																				} else {

																					hm.response.statusCode = '200 OK';
																					logger.debug("Response received from createJobAPI :" + JSON.stringify(responseData));
																					//Start Comment Call
																					var commentUrl = omsExternalURL + '/api/ServiceType/Electric/Job/'+JobIDGUID+'/Comment';
																					var Comment = incomingdata.CreateJobRequest.Notes;
																					var CommentPayload = {
																						"comment": Comment
																					};
																					var commentApi = {
																						target: commentUrl,
																						sslClientProfile: 'omsapiJob_ssl_ClientProfile',
																						method: 'POST',
																						contentType: 'application/json',
																						data :CommentPayload,
																						headers: {
																							'osiApiToken': apiToken
																						},
																					};
																					
																					urlopen.open(commentApi, function(error, response) {
																						if (error) {
																							logger.error("urlopen connect error with commentApi" + JSON.stringify(error));
																							//session.reject("urlopen connect error with commentApi");
																							var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																							ctx.setVariable("retry", 'yes');
																							var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
																							ctx.setVariable("ErrorTxt", ErrorTxt);
																						} else {
																							var responseStatusCode = response.statusCode;
																							 var responsePhrase = response.reasonPhrase;
																							 if (responseStatusCode == 200 )  {
																								 response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											//dp:reject stop the transaction and go error rule with error code and description
																											logger.error("failure in putting message to commentApi" + JSON.stringify(error));
																											session.reject("failure in putting message to commentApi");
																										} else {
																											hm.response.statusCode = responseStatusCode;
																											logger.debug("response received from commentApi "+":"+ responseStatusCode);		
																											var getCommentApiResponse = JSON.parse(responseData);
																											var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																											ctx.setVariable('getCommentApiResponse', getCommentApiResponse);
																										}
																							 });
																						} else if (responseStatusCode !== 200) {
																							response.readAsBuffer(function(error, responseData) {
																								
																								if (error) {
																									logger.error("Failure in reading the response data from commentApi" + JSON.stringify(error));
																									session.reject("Failure in reading the response data from commentApi");
																								} else {
																									hm.current.statusCode = responseStatusCode;
																									logger.error("Error returned from commentApi " + ": with statusCode " + responseStatusCode + " " + responseData);
																									var res = responseData.toString();
																									var QueueMessage = {
																										"CallBackData": {
																											"Client": Client,
																											"ServiceName": incomingdata.CallBackData.ServiceName,
																											"ExternalRefID": ExternalRefID
																										},
																										"ErrorMessage": res

																									}
																								};
																								var targetQueue = session.parameters.Queue;
																								var options = {
																									target: targetQueue,
																									data: QueueMessage
																								};
																								
																								urlopen.open(options, function(error, response) {
																									var hm = require('header-metadata');
																									if (error) {
																										var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																										ctx.setVariable("retry", 'yes');
																										logger.error("error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																										var ErrorTxt = ("omsapijob_014:error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																										ctx.setVariable("ErrorTxt", ErrorTxt);
																										hm.response.statusCode = 500;
																									} else {
																										var mqrc = response.statusCode;
																										if (mqrc == 0) {
																											var replyMQMD = response.get({
																						                          type: 'mq'
																						                      }, 'MQMD');
																						                      var replyMQRFH2 = response.get({
																						                          type: 'mq'
																						                      }, 'MQRFH2');
																											response.readAsBuffer(function(readError, responseData) {
																												if (readError) {
																													hm.response.statusCode = 500
																													var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																													ctx.setVariable("retry", 'yes');
																													logger.debug("error omsapijob_sendJobCreation while keeping message to queue is "+error);
																													var ErrorTxt = ("omsapijob_014:error omsapijob_sendJobCreation while keeping message to queue "+error);
																													ctx.setVariable("ErrorTxt", ErrorTxt);
																												} else {
																													console.log("MQResponseData " + responseData);
																												}
																											});
																										} else {
																											//logger.error(' ** Mqurlopen.open error [MQRC=' + mqrc + ']');
																											//session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
																											hm.response.statusCode = 500
																											var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																											ctx.setVariable("retry", 'yes');
																											logger.error("response code for omsapijob_sendJobCreation "+targetQueue+" urlopen.open error [MQRC=" + mqrc + "]");
																											var ErrorTxt = ("response code for omsapijob_sendJobCreation "+targetQueue+" urlopen.open error [MQRC=" + mqrc + "]");
																											ctx.setVariable("ErrorTxt", ErrorTxt); 
																										}
																									}
																								});
																								
																								
																							});
																							
																						} else {

																							response.readAsBuffer(function(error, responseData) {

																								if (error) {
																									logger.error("Failure in reading the response data from commentApi" + JSON.stringify(error));
																									session.reject("Failure in reading the response data from commentApi");
																								} else {
																									hm.current.statusCode = responseStatusCode;
																									logger.error("Error returned from commentApi " + ": with statusCode " + responseStatusCode + " " + responseData);
																									//session.reject("Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " " + responseData);

																								}
																							});
																						  }
																						}
																					});
																					
																				}
																			});
																		} else if (responseStatusCode !== 200) {
																				response.readAsBuffer(function(error, responseData) {
																					
																					if (error) {
																						logger.error("Failure in reading the response data from createJobAPI" + JSON.stringify(error));
																						session.reject("Failure in reading the response data from createJobAPI");
																					} else {
																						hm.current.statusCode = responseStatusCode;
																						logger.error("omsapiJob_009:Error returned from createJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
																						var res = responseData.toString();
																						var QueueMessage = {
																							"CallBackData": {
																								"Client": Client,
																								"ServiceName": incomingdata.CallBackData.ServiceName,
																								"ExternalRefID": ExternalRefID
																							},
																							"ErrorMessage": res

																						}
																					};
																					var targetQueue = session.parameters.Queue;
																					var options = {
																						target: targetQueue,
																						data: QueueMessage
																					};
																					
																					urlopen.open(options, function(error, response) {
																						var hm = require('header-metadata');
																						if (error) {
																							//logger.error(' Mqurlopen.open error');
																							//session.reject('** Mqurlopen.open error');
																							hm.response.statusCode = 500;
																							var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																							ctx.setVariable("retry", 'yes');
																							logger.error("error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																							var ErrorTxt = ("omsapijob_014:error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																							ctx.setVariable("ErrorTxt", ErrorTxt);
																						} else {
																							var mqrc = response.statusCode;
																							if (mqrc == 0) {
																								response.readAsBuffer(function(readError, responseData) {
																									if (readError) {
																										hm.response.statusCode = 500
																									} else {
																										console.log("MQResponseData " + responseData);
																									}
																								});
																							} else {
																								//logger.error(' ** Mqurlopen.open error [MQRC=' + mqrc + ']');
																								//session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
																								hm.response.statusCode = 500
																								var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																								ctx.setVariable("retry", 'yes');
																								logger.error("error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																								var ErrorTxt = ("omsapijob_014:error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																								ctx.setVariable("ErrorTxt", ErrorTxt);
																							}
																						}
																					});
																					
																					
																				});
																				
																			} else {
																				response.readAsBuffer(function(error, responseData) {

																					if (error) {
																						logger.error("Failure in reading the response data from createJobAPI" + JSON.stringify(error));
																						session.reject("Failure in reading the response data from createJobAPI");
																					} else {
																						hm.current.statusCode = responseStatusCode;
																						logger.error("Error returned from createJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
																						//session.reject("Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " " + responseData);

																					}
																				});
																			}
																		
																	}
																});
																
															}
														});
													} else if (responseStatusCode !== 200) {
															response.readAsBuffer(function(error, responseData) {
																
																if (error) {
																	logger.error("Failure in reading the response data from getJobAPI" + JSON.stringify(error));
																	session.reject("Failure in reading the response data from getJobAPI");
																} else {
																	hm.current.statusCode = responseStatusCode;
																	logger.error("omsapiJob_008:Error returned from getJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
																	
																	var res = responseData.toString();
																	var QueueMessage = {
																		"CallBackData": {
																			"Client": Client,
																			"ServiceName": incomingdata.CallBackData.ServiceName,
																			"ExternalRefID": ExternalRefID
																		},
																		"ErrorMessage": res

																	}
																};
																var targetQueue = session.parameters.Queue;
																var options = {
																	target: targetQueue,
																	data: QueueMessage
																};
																
																urlopen.open(options, function(error, response) {
																	var hm = require('header-metadata');
																	if (error) {
																		//logger.error(' Mqurlopen.open error');
																		//session.reject('** Mqurlopen.open error');
																		hm.response.statusCode = 500;
																		var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																		ctx.setVariable("retry", 'yes');
																		logger.error("error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																		var ErrorTxt = ("omsapijob_014:error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																		ctx.setVariable("ErrorTxt", ErrorTxt);
																	} else {
																		var mqrc = response.statusCode;
																		if (mqrc == 0) {
																			response.readAsBuffer(function(readError, responseData) {
																				if (readError) {
																					hm.response.statusCode = 500
																				} else {
																					console.log("MQResponseData " + responseData);
																				}
																			});
																		} else {
																			//logger.error(' ** Mqurlopen.open error [MQRC=' + mqrc + ']');
																			//session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
																			hm.response.statusCode = 500
																			var ctx = session.name("jobCreation") || session.createContext("jobCreation");
																			ctx.setVariable("retry", 'yes');
																			logger.error("error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																			var ErrorTxt = ("omsapijob_014:error omsapijob_sendJobCreation while keeping message to queue "+targetQueue+" is "+error);
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																		}
																	}
																});
																
																
															});
															
														} else {
															response.readAsBuffer(function(error, responseData) {

																if (error) {
																	logger.error("Failure in reading the response data from getJobAPI" + JSON.stringify(error));
																	session.reject("Failure in reading the response data from getJobAPI");
																} else {
																	hm.current.statusCode = responseStatusCode;
																	logger.error("Error returned from getJobAPI " + ": with statusCode " + responseStatusCode + " " + responseData);
																	ctx.setVariable("retry", 'yes');
																	var ErrorTxt = " urlopen connect error with POST call for OMS api" + JSON.stringify(error);
																	ctx.setVariable("ErrorTxt", ErrorTxt);
																	//session.reject("Error returned from CrewAssignment " + ": with statusCode " + responseStatusCode + " " + responseData);

																}
															});
														}
														
													
												}
											});
										}
									}
								});
							} else {
								
									logger.error("Error received in reading lookup response data " + responseStatusCode);
									session.reject("Error received in reading lookup response data " + responseStatusCode);
								
							}
						}
					});
			
		}
	}
	
});
