var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("jobCreation") || session.createContext("jobCreation");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(error, incomingdata) {
    if (error) {
    	session.reject("Invalid Request Json" );
    } else {
	    	var ctx = session.name("jobCreation") || session.createContext("jobCreation");
		    var jobType = incomingdata.CreateJobRequest.JobType;
		    var longitude = incomingdata.CreateJobRequest.Longitude;
		    var latitude = incomingdata.CreateJobRequest.Latitude;
		    var notes = incomingdata.CreateJobRequest.Notes;
		    
		    ctx.setVariable("incomingdata", incomingdata);
		    
		    
		    if (jobType == null || jobType == '' || jobType == undefined) {
		    	session.reject("jobType cannot be empty in incoming request");
		    	logger.error("omsapiJob_001:jobType cannot be empty in incoming request");
		    	ilsctx.setVariable("errorDescription", "omsapiJob_001:jobType cannot be empty in incoming request");
		    } else{
				ctx.setVariable("jobType", jobType);
			}
		    
		    if (longitude == null || longitude == '' || longitude == undefined) {
		    	logger.debug("longitude cannot be empty in incoming request");
		    } else {
				ctx.setVariable("longitude", longitude);
			}
		    
		    if (latitude == null || latitude == '' || latitude == undefined) {
		    	logger.debug("latitude cannot be empty in incoming request");
		    } else {
				ctx.setVariable("latitude", latitude);
			}
		  
		    if (notes == null || notes == '' || notes == undefined) {
		    	logger.debug("notes cannot be empty in incoming request");
		    } else {
				ctx.setVariable("notes", notes);
			}
		   
    }    
		    
});
