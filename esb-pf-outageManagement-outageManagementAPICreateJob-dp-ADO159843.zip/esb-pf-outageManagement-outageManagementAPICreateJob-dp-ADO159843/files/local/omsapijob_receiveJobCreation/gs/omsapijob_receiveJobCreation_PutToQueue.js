var ctx = session.name("jobCreation") || session.createContext("jobCreation");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {
		var StandaloneMQurl = session.parameters.MQUrl;
		var pushingToQueue = {
			target: StandaloneMQurl,
			data: incomingData
		};
		var info = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";
		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "error while keeping receivecall message to queue is , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVar("errorStatus", "500");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(" error while keeping receivecall message to queue is " + error);
				session.reject(" error while keeping receivecall message to queue is " + error);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							hm.response.statusCode = 500
							var errorinfo = "error while keeping message receivecall to queue is [MQRC=" + mqrc + "], details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVar("errorStatus", "500");
							session.reject("error while keeping message receivecall to queue is " + error);
						} else {
							logger.debug("MQResponsecode " + mqrc + responseData);
						}
					});
				} else {
					var errorinfo = "response code receivecall urlopen.open error [MQRC=" + mqrc + "], details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVar("errorStatus","500");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(" response code receivecall urlopen.open error [MQRC=" + mqrc + "]");
					session.reject(" response code receivecall is urlopen.open error [MQRC=" + mqrc + "]");

				}
			}
		});

	}
});
