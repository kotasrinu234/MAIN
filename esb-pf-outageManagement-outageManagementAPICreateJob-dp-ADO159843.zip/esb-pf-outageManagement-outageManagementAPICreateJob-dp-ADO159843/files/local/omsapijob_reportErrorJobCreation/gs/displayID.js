var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var ilsctx = session.name("ILS") || session.createContext("ILS");
var exitdescription = session.parameters.exitdescription;
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("jobCreation") || session.createContext("jobCreation");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading Incoming Data" + JSON.stringify(error));
		session.reject(readAsJSONError);
	} else {
		var ExternalRefID = incomingdata.CallBackData.ExternalRefID;
		var ExternalRefIDSplit = ExternalRefID.split(":");
		var crewAssignmentID = ExternalRefIDSplit[1];
		var OMSUrl = session.parameters.OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + crewAssignmentID + '?includeFields=displayID';
		var Token = session.parameters.OMSToken;
		var oms = {
			target: OMSUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': Token
			}
		};
		var info = " TargetURL :" + oms.target + "; Method :" + oms.method;
		try {
			urlopen.open(oms, function(error, response) {
				if (error) {
					var errorinfo = "error in oms urlopen GET call, details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatus", "500");
					logger.error("error in oms urlopen GET call" + JSON.stringify(errorinfo));
					session.reject("error in oms urlopen GET call, " + JSON.stringify(errorinfo));
				}

				else {
					var rescode = response.statusCode;
					if (rescode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure in getting response message from omsapi Get calls by job , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", rescode);
								logger.error("failure in getting response message from omsapi Get calls by job " + JSON.stringify(errorinfo));

							} else {
								hm.response.statusCode = '200 OK';
								logger.debug("response received from OMS Get calls by job:" + JSON.stringify(responseData));
								ilsctx.setVariable("exitDescription", exitdescription);
								ilsctx.setVariable("exitstatus", "0");
								ctx.setVariable("omsResponse", responseData);
								ctx.setVariable("displayID", responseData.displayID);
							}
						})
					}
					else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapijob_018:failure in reading response from fse create call , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", rescode);
								logger.error("omsapijob_018:failure in reading response from fse create call " + JSON.stringify(error));
								session.reject("omsapijob_018:failure in reading response from fse call ");
							} else {
								var errorinfo = "omsapijob_011:unable to get display ID from OMS API" + " with statusCode " + rescode + ", details are : " + info + "; errorresponse info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", rescode);
								logger.error("omsapijob_011:unable to get display ID from OMS API" + " with statusCode " + rescode + " and with error: " + responseData);
								session.reject("unable to get displayID from OMS API" + " with statusCode " + rescode + "and with error: " + responseData);
							}
						})
					}
				}
			})
		}
		catch (error) {
			var errorinfo = "error in oms urlopen GET call, details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("error in oms urlopen GET call" + JSON.stringify(errorinfo));
			session.reject("error in oms urlopen GET call, " + JSON.stringify(errorinfo));
		}
	}
})
