var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ilsctx = session.name("ILS") || session.createContext("ILS");
var exitdescription = session.parameters.exitdescription;
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("jobCreation") || session.createContext("jobCreation");
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading Incoming Data" + JSON.stringify(error));
		session.reject(readAsJSONError);
	} else {
		//var Auth = "Basic "+session.parameters.FSEToken;
		var data = incomingdata;
		var id = ctx.getVariable("displayID");
		data.CallBackData.CallID = id;
		data.CallBackData.Number = '0';
		var FSECall = {
			target: session.parameters.FacadeUrl,
			sslClientProfile: 'omsapijob_reportErrorJobCreation_TLS_ClientProfile',
			method: 'post',
			contentType: 'application/json',
			data: incomingdata
		};
		var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";
		try {
			urlopen.open(FSECall, function(error, response) {
				if (error) {
					// an error occurred during request sending or response header parsing
					var errorinfo = "omsapiJob_009:urlopen connect error while doing FSECall , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatus", "500");
					logger.error("omsapiJob_009:urlopen connect error while doing FSECall" + JSON.stringify(errorinfo));
					session.reject("urlopen connect error while doing FSECall" + JSON.stringify(errorinfo));
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure in reading message from FSECall , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", "500");
								logger.error(" failure in reading message from FSECall" + JSON.stringify(errorinfo));
								session.reject("failure in reading message from FSECall" + JSON.stringify(errorinfo));
							}
							else {
								ilsctx.setVariable("exitDescription", exitdescription);
								ilsctx.setVariable("exitstatus", "0");
								logger.debug("Business error sent to FSE" + responseData);
							}
						})
					}
					else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "omsapijob_019:failure in sending response to fse call , details are : " + info + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", responseStatusCode);
								logger.error("omsapijob_019:failure in sending response to fse call  " + JSON.stringify(error));
								session.reject("omsapijob_019:failure in sending response to fse call " + JSON.stringify(error));
							} else {
								var responseStatusCode = response.statusCode;
								var responsePhrase = response.reasonPhrase;
								var errorinfo = "omsapijob_020:failure in sending response to fse call with statusCode " + responseStatusCode + " " + responsePhrase + ", details are : " + info + "; response info :" + responseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", responseStatusCode);
								logger.error("omsapijob_020:failure in sending response to fse call " + " with statusCode " + responseStatusCode + " " + responsePhrase + " and with error: " + responseData);
								session.reject("omsapijob_020:failure in sending response to fse call " + " with statusCode " + responseStatusCode + " " + responsePhrase + " and with error: " + responseData);
							}
						})

					}
				}
			})
		}
		catch (error) {
			// an error occurred during request sending or response header parsing
			var errorinfo = "omsapiJob_009:urlopen connect error while doing FSECall , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("omsapiJob_009:urlopen connect error while doing FSECall" + JSON.stringify(errorinfo));
			session.reject("urlopen connect error while doing FSECall" + JSON.stringify(errorinfo));
		}
	}
})
