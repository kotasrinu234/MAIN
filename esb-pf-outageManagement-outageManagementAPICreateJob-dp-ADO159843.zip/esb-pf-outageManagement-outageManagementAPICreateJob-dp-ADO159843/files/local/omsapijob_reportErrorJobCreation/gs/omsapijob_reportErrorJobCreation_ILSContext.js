var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entrydescription = session.parameters.entrydescription;
if (entrydescription !== undefined || entrydescription !== null || entrydescription !== '') {
	ctx.setVariable('entryDescription', entrydescription);
}
var messageType = session.parameters.messageType;
if (messageType !== undefined || messageType !== null || messageType !== '') {
	ctx.setVariable("messageType", messageType);
}
var exitDestination = session.parameters.FacadeUrl;
if (exitDestination !== undefined || exitDestination !== null || exitDestination !== '') {
	ctx.setVariable("exitDestination", exitDestination);
}
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var msgID = incomingdata.CallBackData.messageID;
		if (msgID === undefined || msgID === null || msgID === '') {
			ctx.setVariable("correlationID", "");
		}
		else {
			ctx.setVariable("correlationID", msgID);
		}
		var message = incomingdata.ErrorMessage;
		if (message === undefined || message === null || message === '') {
			ctx.setVariable("message", "");
		}
		else {
			ctx.setVariable("message", message);
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
	}
});
