# esb-pf-switchOrderManagement-SomSwitchOrder-dp


Deployment instructions:

deploy IIBMQ scripts and iibflow are uploaded in dteenergy/esb-pf-switchOrderManagement-SomSwitchOrder-mq

MQCSP details will be given by DTE ESB team.

Password aliases will be created by DTE ESB team.

For Retry ,IIb retry repo is updated retry queue names. need to run iib retry pipeline ,when ever code moved to higher environment

Private keys and certs need to be provided by DTE ESB team.

Backend Url's need to confirmed for SOM and MAximo for prod

Properties file as per env are in the config folder of this repository.

Jenkins file as per env are also uploaded in this repository.


Packaging details:

•	Interface#32ab -- SOM service request & update(Maximo Initiated)

•	Services:
•	SOM_AMReceiveSwitchOrder(#1)
•	SOM_AMCreateUpdateSwitchOrder_Seq(#2) – ADO86362
•	SOM_AMCreateUpdateSwitchOrder(#3)
•	SOM_AMStatusUpdateSwitchOrder(#4)


•	Domain :  Switch Order Management Domain

•	Updated Git Repo:
    1. esb-pf-switchOrderManagement-SomSwitchOrder-dp

•	Objects:
              
                AAA Policy:
1)  SOM_AMReceiveSwitchOrder_AAA_Policy
               user: 
               password: SOM_AMReceiveSwitchOrder_AAA_PasswordAlias

2)  SOM_AMReceiveSwithOrder_AAA_Policy
              user: 
               password: SOM_AMReceiveSwithOrder_AAA_PasswordAlias

•	HTTPS Handler:   SOM_AMReceiveSwitchOrder_Https_FSH
             Port: 1412

•	IBM MQ Handler: 
                SOM_AMCreateUpdateSwitchOrder_IIB_Retry_MQ_FSH
                SOM_AMCreateUpdateSwitchOrder_MQ_FSH
                SOM_AMCreateUpdateSwitchOrder_MQ_FSH_ALT
                 SOM_AMCreateUpdateSwitchOrder_Seq_IIB_Retry_MQFSH
                 SOM_AMCreateUpdateSwitchOrder_Seq_MQFSH
                 SOM_AMCreateUpdateSwitchOrder_Seq_MQFSH_ALT
                 SOM_AMStatusUpdateSwitchOrder_FSH_MQ_ALT
SOM_AMStatusUpdateSwitchOrder_Retry_MQFSH
SOM_AMStatusUpdateSwitchOrderFSH_MQ


                

               MQ Queue Manager: 
                          SOM_AMCreateUpdateSwitchOrder_IIB_Retry_Qmgr
                           SOM_AMCreateUpdateSwitchOrder_Qmgr
                            SOM_AMCreateUpdateSwitchOrder_Qmgr_ALT
                           SOM_AMCreateUpdateSwitchOrder_Seq_IIB_Retry_Qmgr
                           SOM_AMCreateUpdateSwitchOrder_Seq_Qmgr
                          SOM_AMCreateUpdateSwitchOrder_Seq_Qmgr_ALT
                          SOM_AMStatusUpdateSwitchOrder_Qmgr_ALT
                        SOM_AMStatusUpdateSwitchOrder_Retry_Qmgr
                      SOM_AMStatusUpdateSwitchOrder_Qmgr
                      SOM_AMReceiveSwitchOrder_Qmgr

                           
                          
              
•	XML Manager
  SOM_AMCreateUpdateSwitchOrder_Seq_XmlMgr
SOM_AMCreateUpdateSwitchOrder_Xml_Mgr
SOM_AMCreateUpdateSwithOrder_Xml_Mgr
SOM_AMReceiveSwitchOrder_Xml_Mgr
SOM_AMReceiveSwithOrder_Xml_Mgr
SOM_AMStatusUpdateSwitchOrder_Xml_Mgr
SOM_AMStatusUpdateSwithOrder_Xml_Mgr


•	TLS Server Profile: 
1)	SOM_AMReceiveSwitchOrder_FSH_SSSL_Server_Profile
2)	SOM_AMReceiveSwithOrder_FSH_SSSL_Server_Profile

•	Crypto Identification Credentials: 
                 SOM_AMReceiveSwitchOrder_FSH_Identification_Cred



•	Cryptokey: 
1)   SOM_AMReceiveSwitchOrder_FSH_CryptoKey

                  filename: sharedcert:///esbst.p12
                  passwordalias: esbstkeypass

2)SOM_AMReceiveSwithOrder_FSH_Identification_Cred
                          filename: sharedcert:///esbst.p12
                  passwordalias: esbstkeypass


•	Crypto Certificate:1) SOM_AMReceiveSwitchOrder_FSH_Crypto_Cert
                   filename: sharedcert:///esbst.p12
                   passwordalias:esbstkeypass

2) SOM_AMReceiveSwithOrder_FSH_Crypto_Cert
                   filename: sharedcert:///esbst.p12
                   passwordalias:esbstkeypass

•	TLS Client Profile:  

1)	SOM_AMReceiveSwitchOrder_AAA_Client_Policy 
2)	SOM_AMReceiveSwithOrder_AAA_Client_Policy
3)	SOM_AMStatusUpdateSwitchOrder_Client_Profile
4)	SOM_AMStatusUpdateSwithOrder_Client_Profile
  

SSL Client Profile : 

OMS_SOM_Client_Profile
SOM_AMStatusUpdateSwitchOrder_Client_Profile






