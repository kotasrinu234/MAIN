//js is used for checking the timestamp if update is required 
// doing lookpup to get the switchOrderTypeObjectID and also for determining which switchordertypeobject it is
//for mapping maximo status to som status
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("SOM") || session.createContext("SOM");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctxSeq = session.name("SOM_CreateUpdate_seq") || session.createContext("SOM_CreateUpdate_seq");
var checkretry = ctx.getVar("retry");
var ExitDescription = session.parameters.ExitDescription;
var MaximoResponseExitDescription = session.parameters.MaximoResponseExitDescription;
var SeqconfExitDescription = session.parameters.SeqconfExitDescription;
var omsExternalURL = session.parameters.omsExternalURL;
var Queueurl = session.parameters.BackendMQurl;
ILSctx.setVariable('exitDestination', omsExternalURL);
var toState = '';
var LookupMaximoResponse = ctx.getVar("LookupMaximoResponse");
if (LookupMaximoResponse != 'yes') {
	if (checkretry != 'yes') {
		var ctx = session.name("SOM") || session.createContext("SOM");
		var responsecode = ctx.getVar("GetSwitchOrderResponseCode");
		var GetSwitchOrderResponseData;
		var GetSwitchOrderUpdateStatus = ctx.getVar("GetSwitchOrderUpdateStatus");
		if (GetSwitchOrderUpdateStatus == 'Updateoperation') {
			var IncomingCreationDateTime = ctx.getVar("IncomingCreationDateTime");
			var statusissue = ctx.getVar("StatusIssue");
			var messageId = ctxSeq.getVariable("messageId");
			var TicketId = ctx.getVar("TICKETID");
			var orderType = ctx.getVar("CLASSIFICATIONID");
			
			
			
			var somID = ctx.getVariable("DTE_EXTERNALID2");
			
			if (ctx.getVariable("DTE_EXTERNALID2") === undefined || ctx.getVariable("DTE_EXTERNALID2") === null || ctx.getVariable("DTE_EXTERNALID2") === '') {
			somID = "";
			ILSctx.setVariable("somID", "")
				}
			else {
			somID = ctx.getVariable("DTE_EXTERNALID2")
			ILSctx.setVariable("somID", ctx.getVariable("DTE_EXTERNALID2"))
			}

var label = ctx.getVariable("label");
if (ctx.getVariable("label") === undefined || ctx.getVariable("label") === null || ctx.getVariable("label") === '') {
			label = "";
			ILSctx.setVariable("label", "")
				}
			else {
			label = ctx.getVariable("label")
			ILSctx.setVariable("label", ctx.getVariable("label"))
			}
			
			
			
			if (statusissue == 'no') {
			/*	var PayloadAddon = {

					"maximoID": TicketId,
					"timeStamp": IncomingCreationDateTime,
					"orderType": orderType,
					"orderStatus": toState,
					"messageID": messageId,
					"somID": somID

				}

				ILSctx.setVariable("PayloadAddon", PayloadAddon)*/
				const date = new Date(IncomingCreationDateTime);
				var IncomingCreationDateTimeUTC1 = date.toISOString();
				var beforePlus = IncomingCreationDateTimeUTC1.split('.').shift();
				var IncomingCreationDateTimeUTC = beforePlus + 'Z';
				var responsecode = ctx.getVar("GetSwitchOrderResponseCode");
				if (responsecode == '200') {
					GetSwitchOrderResponseData = JSON.parse(ctx.getVar("GetSwitchOrderResponseData"));
				} else {
					GetSwitchOrderResponseData = ctx.getVar("GetSwitchOrderResponseData");
				}
				ctx.setVar("GetSwitchOrderResponseDataJsonPayload", GetSwitchOrderResponseData);
				var GetSwitchOrderResponseDataTime;
				//	var GetSwitchOrderResponseDataId = GetSwitchOrderResponseData.id;
				if (GetSwitchOrderResponseData.customFieldValuesExt === undefined || GetSwitchOrderResponseData.customFieldValuesExt === '' || GetSwitchOrderResponseData.customFieldValuesExt === null) {
				} else {
					if (GetSwitchOrderResponseData.customFieldValuesExt.Updated_At === undefined || GetSwitchOrderResponseData.customFieldValuesExt.Updated_At === '' || GetSwitchOrderResponseData.customFieldValuesExt.Updated_At === null) {
						GetSwitchOrderResponseDataTime = GetSwitchOrderResponseData.updatedAt;
					} else {
						GetSwitchOrderResponseDataTime = GetSwitchOrderResponseData.customFieldValuesExt.Updated_At;
					}
				}
				logger.debug("GetSwitchOrderResponseDataTime+++" + GetSwitchOrderResponseDataTime + "::::IncomingCreationDateTimeUTC+++" + IncomingCreationDateTimeUTC);
				//this is for update where we are doing the date comparsion
				var doupdate = 'no';
				ctx.setVar('doupdate', doupdate)
				if (Date.parse(GetSwitchOrderResponseDataTime) < Date.parse(IncomingCreationDateTimeUTC)) {
					//doupdate isused in payload.js file to do update operation based on timestamp decision taken here
					ctx.setVar('doupdate', 'yes')
					//  ctx.setVar('UpdateRequired','yes');
					//121
					var switchOrderTypeObjectID = GetSwitchOrderResponseData.switchOrderTypeObjectID;
					ctx.setVar('switchOrderTypeObjectID', switchOrderTypeObjectID);

					var lookupMessage = {
						"lookupReq": {
							"type": [
								{
									"name": "switchOrderTypeObjectID",
									"id": switchOrderTypeObjectID
								}
							]
						}
					}
					var url = session.parameters.lookupUrl;
					var LookupServiceResponse = {
						target: url,
						method: 'POST',
						contentType: 'application/json',
						data: lookupMessage
					};
					var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
					urlopen.open(LookupServiceResponse, function(error, response) {
						if (error) {
							var errorinfo = "url connection error 'LookUp switchOrderTypeObjectID', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ErrorDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'LookUp switchOrderTypeObjectID', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ErrorDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										ILSctx.setVariable('ExitStatus', '0');
										ILSctx.setVariable('ExitDescription', ExitDescription);
										hm.response.statusCode = responseStatusCode;
										logger.debug("response received from LookupServiceResponse for switchOrderTypeObjectID " + responseStatusCode);
										var lookupResponse = JSON.parse(responseData);
										var switchOrderWorkFlowID;
										//87
										if (lookupResponse.lookupRep.type[0].result == 0) {

											switchOrderWorkFlowID = lookupResponse.lookupRep.type[0].switchOrderWorkFlowID;
											var ctx = session.name("SOM") || session.createContext("SOM");
											ctx.setVariable("switchOrderWorkFlowID_LookupUpdate", switchOrderWorkFlowID);
											var switchOrderType_Label = lookupResponse.lookupRep.type[0].label;
											ctx.setVariable("switchOrderType_Label", switchOrderType_Label);

											//164 maximo status
											var toState = '';
											//var://context/SOM/MaximoStatus
											var ctx = session.name("SOM") || session.createContext("SOM");
											var MaximoStatus = ctx.getVar("MaximoStatus");
											if (MaximoStatus.length > 0) {
												var toState = '';
												//logger.error("line no 121"+MaximoStatus);
												if (switchOrderType_Label == 'RSD') {
													//logger.error("lin no 173"+switchOrderType_Label);
													var MaximoLookupMap = new Map([
														['NEW', 'New'],
														['INPROG', 'In Progress'],
														['CAN', 'Cancelled'],
														['FDCOMP', 'Completed'],
														['CLOSED', 'Closed'],
														['EXTEND', 'Extend'],
														['ONHOLD', 'On Hold'],
														['NEEDASGN', 'OCC Review'],
														['OCCREVISE', 'OCC Review'],
														['QUEUED', 'OCC Review'],
														['REVISE', 'OCC Review']
													]);

													if (MaximoLookupMap.has(MaximoStatus)) {
														toState = MaximoLookupMap.get(MaximoStatus);
														ctx.setVariable('toState', MaximoLookupMap.get(MaximoStatus));
													}else {
														toState = null;
													}
												}

												if (switchOrderType_Label == 'RECL' || switchOrderType_Label == 'TRSD' || switchOrderType_Label == 'ETO') {
													//logger.error("lin no 194"+switchOrderType_Label);
													var MaximoLookupMap = new Map([
														['NEW', 'New'],
														['INPROG', 'In Progress'],
														['CAN', 'Cancelled'],
														['FDCOMP', 'Completed'],
														['CLOSED', 'Closed']
													]);

													if (MaximoLookupMap.has(MaximoStatus)) {
														toState = MaximoLookupMap.get(MaximoStatus);
														ctx.setVariable('toState', MaximoLookupMap.get(MaximoStatus));
													} else {
														toState = null;
													}
												}
												//208 getting id for tostatecall start
												//if(toState == new or close or maximostatus>0 and tostate= empty)
												if (toState == 'New' || toState == 'Closed' || (MaximoStatus.length > 0 && toState == null)) {
													if (toState == 'New' || toState == 'Closed') {
														var ctx = session.name("SOM") || session.createContext("SOM");
														var TicketId = ctx.getVar("TICKETID");
														var responsemessage = '500 Workflow/Status field value ' + MaximoStatus + ' is not valid status for the switch order type ' + switchOrderType_Label;
														var np_statusmemo = responsemessage.slice(0, 99);
														var orderType = ctx.getVar("CLASSIFICATIONID");
														var PayloadAddon = {

															"maximoID": TicketId,
															"timeStamp": IncomingCreationDateTime,
															"orderType": orderType,
															"orderStatus": toState,
															"messageID": messageId,
															"somID": somID

														}
														var MaximoNegativeUpdateResponsePayload = {
															"ticketid": TicketId,
															"status": "NegativeAcknowledge",
															"np_statusmemo": np_statusmemo,
															"esbData": PayloadAddon
														}

														ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
														ctx.setVar("LookupMaximoResponse", 'yes');
														ctx.setVar("StatusIssue", 'yes');
														//start calling maximoResponsecall api
														var Queueurl = session.parameters.BackendMQurl;
														logger.error("SOM_AM_009 " + np_statusmemo);
														var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
													} else if (MaximoStatus.length > 0 && toState == null) {
														var ctx = session.name("SOM") || session.createContext("SOM");
														var TicketId = ctx.getVar("TICKETID");
														var responsemessage = '500 Workflow/Status field value ' + MaximoStatus + ' is not valid status for the switch order type ' + switchOrderType_Label;
														var np_statusmemo = responsemessage.slice(0, 99);
														var orderType = ctx.getVar("CLASSIFICATIONID");
														var PayloadAddon = {

															"maximoID": TicketId,
															"timeStamp": IncomingCreationDateTime,
															"orderType": orderType,
															"orderStatus": toState,
															"messageID": messageId,
															"somID": somID

														}
														var MaximoNegativeUpdateResponsePayload = {
															"ticketid": TicketId,
															"status": "NegativeAcknowledge",
															"np_statusmemo": np_statusmemo,
															"esbData": PayloadAddon
														}

														ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
														ctx.setVar("LookupMaximoResponse", 'yes');
														ctx.setVar("StatusIssue", 'yes');
														//start calling maximoResponsecall api
														var Queueurl = session.parameters.BackendMQurl;
														logger.error("SOM_AM_009 " + np_statusmemo);
														var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
													}

												} else if (toState.length > 0) {
													var lookupMessage = {
														"lookupReq": {
															"type": [
																{
																	"name": "switchOrder.WorkFlow",
																	"id": switchOrderWorkFlowID,
																	"label": toState
																}]
														}
													}
													var url = session.parameters.lookupUrl;
													var LookupServiceResponse = {
														target: url,
														method: 'POST',
														contentType: 'application/json',
														data: lookupMessage
													};
													var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
													urlopen.open(LookupServiceResponse, function(error, response) {
														if (error) {
															var errorinfo = "url connection error 'switchOrderWorkFlowID', details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', '500');
															ILSctx.setVariable('ErrorDescription', errorinfo);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															var responseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'switchOrderWorkFlowID', details are : " + info + "; error info :" + error
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		ILSctx.setVariable('ExitStatus', '0');
																		ILSctx.setVariable('ExitDescription', ExitDescription);
																		hm.response.statusCode = responseStatusCode;
																		logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID " + switchOrderWorkFlowID);
																		var lookupResponse = JSON.parse(responseData);
																		var toStateID_LookupUpdate;
																		if (lookupResponse.lookupRep.type[0].result == 0) {
																			//242
																			toStateID_LookupUpdate = lookupResponse.lookupRep.type[0].id;
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			ctx.setVariable("toStateID_LookupUpdate", toStateID_LookupUpdate);
																			// making change for reason for  reject
																			var DTE_Reason_Reject_val = ctx.getVar("DTE_Reason_Reject");
																			var isANumber = isNaN(DTE_Reason_Reject_val) == false;
																			if (DTE_Reason_Reject_val.length > 0 && (DTE_Reason_Reject_val !== undefined || DTE_Reason_Reject_val !== '' || DTE_Reason_Reject_val !== null) && (isANumber == false)) {
																				//	if(DTE_Reason_Reject_val !== undefined || DTE_Reason_Reject_val !== '' || DTE_Reason_Reject_val !== null){
																				//if (isANumber == false){
																				var DTE_Reason_Reject_Lookup_Payload = {
																					"lookupReq": {
																						"type": [
																							{
																								"name": "switchOrderDescription",
																								"label": DTE_Reason_Reject_val
																							}
																						]
																					}
																				}

																				var url = session.parameters.lookupUrl;;
																				//var test = DTE_Reason_Reject_Lookup(url, DTE_Reason_Reject_Lookup_Payload);

																				var LookupServiceResponse = {
																					target: url,
																					method: 'POST',
																					contentType: 'application/json',
																					data: DTE_Reason_Reject_Lookup_Payload
																				};

																				var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																				urlopen.open(LookupServiceResponse, function(error, response) {
																					if (error) {
																						var errorinfo = "url connection error 'LookUp DTE_Reason_Reject_val', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', '500');
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var responseStatusCode = response.statusCode;
																						if (responseStatusCode == 200) {
																							response.readAsBuffer(function(error, responseData) {
																								if (error) {
																									var errorinfo = "error reading response 'LookUp DTE_Reason_Reject_val', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									ILSctx.setVariable('ExitStatus', '0');
																									ILSctx.setVariable('ExitDescription', ExitDescription);
																									hm.response.statusCode = responseStatusCode;
																									logger.debug("response received from LookupServiceResponse for DTE_Reason_Reject_Lookup_Payload " + responseStatusCode);
																									var lookupResponse = JSON.parse(responseData);
																									var switchOrderWorkFlowID;
																									if (lookupResponse.lookupRep.type[0].result == 0) {

																										var DTE_Reason_Reject = lookupResponse.lookupRep.type[0].status;
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										ctx.setVariable("DTE_Reason_Reject", DTE_Reason_Reject);
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										var Incoming_DESCRIPTION = ctx.getVar('DESCRIPTION');
																										var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																										//Incoming_DTE_WORKLOCATION
																										if (Incoming_DESCRIPTION == undefined || Incoming_DESCRIPTION == null || Incoming_DESCRIPTION == '') {
																											var CharacterOfWorkSelection_DESCRIPTION = '';
																											var ctx = session.name("SOM") || session.createContext("SOM");
																											ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																											var ctx = session.name("SOM") || session.createContext("SOM");
																											var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																											//Incoming_DTE_WORKLOCATION
																											if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

																												var Responsible_Service_Center_DTE_WORKLOCATION = '';
																												var ctx = session.name("SOM") || session.createContext("SOM");
																												ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																											} else {
																												var lookupMessage = {
																													"lookupReq": {
																														"type": [
																															{
																																"name": "switchOrderDescription",
																																"label": Incoming_DTE_WORKLOCATION
																															}]
																													}
																												}
																												var url = session.parameters.lookupUrl;
																												var LookupServiceResponse = {
																													target: url,
																													method: 'POST',
																													contentType: 'application/json',
																													data: lookupMessage
																												};

																												var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																												urlopen.open(LookupServiceResponse, function(error, response) {
																													if (error) {
																														var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																														ILSctx.setVariable('ExitStatus', '500');
																														ILSctx.setVariable('ErrorDescription', errorinfo);
																														logger.error(errorinfo);
																														session.reject(errorinfo);
																													} else {
																														var responseStatusCode = response.statusCode;
																														if (responseStatusCode == 200) {
																															response.readAsBuffer(function(error, responseData) {
																																if (error) {
																																	var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																																	ILSctx.setVariable('ErrorDescription', errorinfo);
																																	logger.error(errorinfo);
																																	session.reject(errorinfo);
																																} else {
																																	ILSctx.setVariable('ExitStatus', '0');
																																	ILSctx.setVariable('ExitDescription', ExitDescription);
																																	hm.response.statusCode = responseStatusCode;
																																	//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																																	var lookupResponse = JSON.parse(responseData);
																																	//	var toStateID_LookupUpdate;	
																																	if (lookupResponse.lookupRep.type[0].result == 0) {
																																		var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																																		var ctx = session.name("SOM") || session.createContext("SOM");
																																		ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																																	} else {
																																		var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DTE_WORKLOCATION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																		ILSctx.setVariable('ExitStatus', '1');
																																		ILSctx.setVariable('ExitDescription', invalidresp);
																																		logger.error(invalidresp)
																																		//			logger.error("result 1 for Lookup DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																																		//			session.reject("result is 1 for LookupServiceResponse Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																																		var ctx = session.name("SOM") || session.createContext("SOM");
																																		var TicketId = ctx.getVar("TICKETID");
																																		var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";

																																		var np_statusmemo = responsemessage.slice(0, 99);
																																		var orderType = ctx.getVar("CLASSIFICATIONID");
																																		var PayloadAddon = {

																																			"maximoID": TicketId,
																																			"timeStamp": IncomingCreationDateTime,
																																			"orderType": orderType,
																																			"orderStatus": toState,
																																			"messageID": messageId,
																																			"somID": somID

																																		}
																																		var MaximoNegativeUpdateResponsePayload = {
																																			"ticketid": TicketId,
																																			"status": "NegativeAcknowledge",
																																			"np_statusmemo": np_statusmemo,
																																			"esbData": PayloadAddon
																																		}

																																		ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																																		ctx.setVar("LookupMaximoResponse", 'yes');
																																		//start calling maximoResponsecall api
																																		var Queueurl = session.parameters.BackendMQurl;
																																		var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																																	}
																																}
																															});
																														} else {
																															//Added readAsBuffer 4
																															response.readAsBuffer(function(error, responseData) {
																																if (error) {
																																	var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																																	ILSctx.setVariable('ErrorDescription', errorinfo);
																																	logger.error(errorinfo);
																																	session.reject(errorinfo);
																																} else {
																																	var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																																	ILSctx.setVariable('ErrorDescription', errorinfo);
																																	logger.error(errorinfo);
																																	session.reject(errorinfo);
																																}
																															})
																														}
																													}
																												});
																											}
																										} else {
																											//338
																											var lookupMessage = {
																												"lookupReq": {
																													"type": [
																														{
																															"name": "switchOrderDescription",
																															"label": Incoming_DESCRIPTION
																														}]
																												}
																											}
																											var url = session.parameters.lookupUrl;
																											var LookupServiceResponse = {
																												target: url,
																												method: 'POST',
																												contentType: 'application/json',
																												data: lookupMessage
																											};
																											var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																											urlopen.open(LookupServiceResponse, function(error, response) {
																												if (error) {
																													var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																													ILSctx.setVariable('ExitStatus', '500');
																													ILSctx.setVariable('ErrorDescription', errorinfo);
																													logger.error(errorinfo);
																													session.reject(errorinfo);
																												} else {
																													var responseStatusCode = response.statusCode;
																													if (responseStatusCode == 200) {
																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error

																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ErrorDescription', errorinfo);
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															} else {
																																ILSctx.setVariable('ExitStatus', '0');
																																ILSctx.setVariable('ExitDescription', ExitDescription);
																																hm.response.statusCode = responseStatusCode;
																																//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																																var lookupResponse = JSON.parse(responseData);
																																//	var toStateID_LookupUpdate;	
																																if (lookupResponse.lookupRep.type[0].result == 0) {
																																	var CharacterOfWorkSelection_DESCRIPTION = lookupResponse.lookupRep.type[0].status;
																																	var ctx = session.name("SOM") || session.createContext("SOM");
																																	ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																																} else {
																																	var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DESCRIPTION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																	ILSctx.setVariable('ExitStatus', '1');
																																	ILSctx.setVariable('ErrorDescription', invalidresp);
																																	logger.error(invalidresp)
																																	//logger.error("Lookup result 1 for DESCRIPTION "+Incoming_DESCRIPTION);
																																	//session.reject("LookupServiceResponse result 1 for Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																																	var ctx = session.name("SOM") || session.createContext("SOM");
																																	var TicketId = ctx.getVar("TICKETID");
																																	var responsemessage = "500 Lookup Response for given DESCRIPTION/Character_Of_Work_Selection field value is invalid";
																																	var orderType = ctx.getVar("CLASSIFICATIONID");
																																	var PayloadAddon = {

																																		"maximoID": TicketId,
																																		"timeStamp": IncomingCreationDateTime,
																																		"orderType": orderType,
																																		"orderStatus": toState,
																																		"messageID": messageId,
																																		"somID": somID

																																	}
																																	var np_statusmemo = responsemessage.slice(0, 99);
																																	var MaximoNegativeUpdateResponsePayload = {
																																		"ticketid": TicketId,
																																		"status": "NegativeAcknowledge",
																																		"np_statusmemo": np_statusmemo,
																																		"esbData": PayloadAddon
																																	}
																																	//MaximoNegativeUpdateResponsePayload.esbData = PayloadAddon
																																	ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																																	ctx.setVar("LookupMaximoResponse", 'yes');
																																	//start calling maximoResponsecall api
																																	var Queueurl = session.parameters.BackendMQurl;
																																	var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																																}

																																var ctx = session.name("SOM") || session.createContext("SOM");
																																var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																																//Incoming_DTE_WORKLOCATION
																																if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

																																	var Responsible_Service_Center_DTE_WORKLOCATION = '';
																																	var ctx = session.name("SOM") || session.createContext("SOM");
																																	ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																																} else {
																																	var lookupMessage = {
																																		"lookupReq": {
																																			"type": [
																																				{
																																					"name": "switchOrderDescription",
																																					"label": Incoming_DTE_WORKLOCATION
																																				}]
																																		}
																																	}
																																	var url = session.parameters.lookupUrl;
																																	var LookupServiceResponse = {
																																		target: url,
																																		method: 'POST',
																																		contentType: 'application/json',
																																		data: lookupMessage
																																	};
																																	var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

																																	urlopen.open(LookupServiceResponse, function(error, response) {
																																		if (error) {
																																			var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error

																																			ILSctx.setVariable('ExitStatus', '500');
																																			ILSctx.setVariable('ErrorDescription', errorinfo);
																																			logger.error(errorinfo);
																																			session.reject(errorinfo);
																																		} else {
																																			var responseStatusCode = response.statusCode;
																																			if (responseStatusCode == 200) {
																																				response.readAsBuffer(function(error, responseData) {
																																					if (error) {
																																						var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																																						ILSctx.setVariable('ErrorDescription', errorinfo);
																																						logger.error(errorinfo);
																																						session.reject(errorinfo);
																																					} else {
																																						hm.response.statusCode = responseStatusCode;
																																						ILSctx.setVariable('ExitStatus', '0');
																																						ILSctx.setVariable('ExitDescription', ExitDescription);
																																						//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																																						var lookupResponse = JSON.parse(responseData);
																																						//	var toStateID_LookupUpdate;	
																																						if (lookupResponse.lookupRep.type[0].result == 0) {
																																							var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																																							var ctx = session.name("SOM") || session.createContext("SOM");
																																							ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																																						} else {
																																							var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DTE_WORKLOCATION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																							ILSctx.setVariable('ExitStatus', '1');
																																							ILSctx.setVariable('ExitDescription', invalidresp);
																																							logger.error(invalidresp)

																																							//logger.error("Result 1 for lookup for DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																																							//session.reject("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																																							var ctx = session.name("SOM") || session.createContext("SOM");
																																							var TicketId = ctx.getVar("TICKETID");
																																							var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																																							
																																							var orderType = ctx.getVar("CLASSIFICATIONID");
																																							var PayloadAddon = {

																																								"maximoID": TicketId,
																																								"timeStamp": IncomingCreationDateTime,
																																								"orderType": orderType,
																																								"orderStatus": toState,
																																								"messageID": messageId,
																																								"somID": somID

																																							}
																																							var np_statusmemo = responsemessage.slice(0, 99);
																																							var MaximoNegativeUpdateResponsePayload = {
																																								"ticketid": TicketId,
																																								"status": "NegativeAcknowledge",
																																								"np_statusmemo": np_statusmemo,
																																								"esbData": PayloadAddon
																																							}
																																							ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																																							ctx.setVar("LookupMaximoResponse", 'yes');
																																							//start calling maximoResponsecall api
																																							var Queueurl = session.parameters.BackendMQurl;
																																							var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																																						}
																																					}
																																				});
																																			} else {
																																				//Added readAsBuffer 6
																																				response.readAsBuffer(function(error, responseData) {
																																					if (error) {
																																						var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																																						ILSctx.setVariable('ErrorDescription', errorinfo);
																																						logger.error(errorinfo);
																																						session.reject(errorinfo);
																																					} else {
																																						var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																																						ILSctx.setVariable('ErrorDescription', errorinfo);
																																						logger.error(errorinfo);
																																						session.reject(errorinfo);
																																					}
																																				})
																																			}
																																		}
																																	});
																																}

																															}
																														});
																													} else {
																														//Added readAsBuffer 5
																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ErrorDescription', errorinfo);
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															} else {
																																var errorinfo = "error response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ErrorDescription', errorinfo);
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															}
																														})
																													}
																												}
																											});
																											//338		
																										}
																										//242
																									} else {
																										var invalidresp = "Invalid Lookup Request 'LookUp DTE_Reason_Reject_val', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																										ILSctx.setVariable('ExitStatus', '1');
																										ILSctx.setVariable('ErrorDescription', invalidresp);
																										logger.error(invalidresp)
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										var DTE_Reason_Reject_val = ctx.getVar("DTE_Reason_Reject");
																										var TicketId = ctx.getVar("TICKETID");
																										var responsemessage = "500 Lookup Response for given DTE_REASON_REJECT/Reason_For_Action field value is invalid";
																										//	session.reject("response received from LookupServiceResponse for DTE_Reason_Reject_Lookup_Payload for label "+DTE_Reason_Reject_val+" is result 1");
																										var np_statusmemo = responsemessage.slice(0, 99);
																										
																										var orderType = ctx.getVar("CLASSIFICATIONID");
																										var PayloadAddon = {

																											"maximoID": TicketId,
																											"timeStamp": IncomingCreationDateTime,
																											"orderType": orderType,
																											"orderStatus": toState,
																											"messageID": messageId,
																											"somID": somID

																										}
																										var MaximoNegativeUpdateResponsePayload = {
																											"ticketid": TicketId,
																											"status": "NegativeAcknowledge",
																											"np_statusmemo": np_statusmemo,
																											"esbData": PayloadAddon
																										}

																										ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																										ctx.setVar("LookupMaximoResponse", 'yes');
																										//start calling maximoResponsecall api
																										var Queueurl = session.parameters.BackendMQurl;
																										var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);

																									}
																								}
																							});
																						} else {
																							//Added readAsBuffer 3
																							response.readAsBuffer(function(error, responseData) {
																								if (error) {
																									var errorinfo = "error reading response 'LookUp DTE_Reason_Reject_val', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									var errorinfo = "error response 'LookUp DTE_Reason_Reject_val', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								}
																							})
																						}
																					}
																				});
																			} else {
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				var Incoming_DESCRIPTION = ctx.getVar('DESCRIPTION');
																				var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																				//Incoming_DTE_WORKLOCATION
																				if (Incoming_DESCRIPTION == undefined || Incoming_DESCRIPTION == null || Incoming_DESCRIPTION == '') {
																					var CharacterOfWorkSelection_DESCRIPTION = '';
																					var ctx = session.name("SOM") || session.createContext("SOM");
																					ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																					var ctx = session.name("SOM") || session.createContext("SOM");
																					var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																					//Incoming_DTE_WORKLOCATION
																					if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

																						var Responsible_Service_Center_DTE_WORKLOCATION = '';
																						var ctx = session.name("SOM") || session.createContext("SOM");
																						ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																					} else {
																						var lookupMessage = {
																							"lookupReq": {
																								"type": [
																									{
																										"name": "switchOrderDescription",
																										"label": Incoming_DTE_WORKLOCATION
																									}]
																							}
																						}
																						var url = session.parameters.lookupUrl;
																						var LookupServiceResponse = {
																							target: url,
																							method: 'POST',
																							contentType: 'application/json',
																							data: lookupMessage
																						};
																						var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																						urlopen.open(LookupServiceResponse, function(error, response) {
																							if (error) {
																								var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																								ILSctx.setVariable('ExitStatus', '500');
																								ILSctx.setVariable('ErrorDescription', errorinfo);
																								logger.error(errorinfo);
																								session.reject(errorinfo);
																							} else {
																								var responseStatusCode = response.statusCode;
																								if (responseStatusCode == 200) {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																											ILSctx.setVariable('ExitStatus', responseStatusCode);
																											ILSctx.setVariable('ErrorDescription', errorinfo);
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										} else {
																											hm.response.statusCode = responseStatusCode;
																											ILSctx.setVariable('ExitStatus', '0');
																											ILSctx.setVariable('ExitDescription', ExitDescription);
																											//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																											var lookupResponse = JSON.parse(responseData);
																											//	var toStateID_LookupUpdate;	
																											if (lookupResponse.lookupRep.type[0].result == 0) {
																												var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																												var ctx = session.name("SOM") || session.createContext("SOM");
																												ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																											} else {
																												var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DESCRIPTION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																												ILSctx.setVariable('ExitStatus', '1');
																												ILSctx.setVariable('ExitDescription', invalidresp);
																												logger.error(invalidresp)
																												//			logger.error("result 1 for Lookup DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																												//			session.reject("result is 1 for LookupServiceResponse Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																												var ctx = session.name("SOM") || session.createContext("SOM");
																												var TicketId = ctx.getVar("TICKETID");
																												var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																											
																												var orderType = ctx.getVar("CLASSIFICATIONID");
																												var PayloadAddon = {

																													"maximoID": TicketId,
																													"timeStamp": IncomingCreationDateTime,
																													"orderType": orderType,
																													"orderStatus": toState,
																													"messageID": messageId,
																													"somID": somID

																												}
																												var np_statusmemo = responsemessage.slice(0, 99);
																												var MaximoNegativeUpdateResponsePayload = {
																													"ticketid": TicketId,
																													"status": "NegativeAcknowledge",
																													"np_statusmemo": np_statusmemo,
																													"esbData": PayloadAddon
																												}

																												ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																												ctx.setVar("LookupMaximoResponse", 'yes');
																												//start calling maximoResponsecall api
																												var Queueurl = session.parameters.BackendMQurl;
																												var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																											}
																										}
																									});
																								} else {
																									//Added readAsBuffer 7
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																											ILSctx.setVariable('ExitStatus', responseStatusCode);
																											ILSctx.setVariable('ErrorDescription', errorinfo);
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										} else {
																											var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																											ILSctx.setVariable('ExitStatus', responseStatusCode);
																											ILSctx.setVariable('ErrorDescription', errorinfo);
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										}
																									})
																								}
																							}
																						});
																					}
																				} else {
																					//338
																					var lookupMessage = {
																						"lookupReq": {
																							"type": [
																								{
																									"name": "switchOrderDescription",
																									"label": Incoming_DESCRIPTION
																								}]
																						}
																					}
																					var url = session.parameters.lookupUrl;
																					var LookupServiceResponse = {
																						target: url,
																						method: 'POST',
																						contentType: 'application/json',
																						data: lookupMessage
																					};
																					var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																					urlopen.open(LookupServiceResponse, function(error, response) {
																						if (error) {
																							var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('ExitStatus', '500');
																							ILSctx.setVariable('ErrorDescription', errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							var responseStatusCode = response.statusCode;
																							if (responseStatusCode == 200) {
																								response.readAsBuffer(function(error, responseData) {
																									if (error) {
																										var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																										ILSctx.setVariable('ExitStatus', responseStatusCode);
																										ILSctx.setVariable('ErrorDescription', errorinfo);
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									} else {
																										ILSctx.setVariable('ExitStatus', '0');
																										ILSctx.setVariable('ExitDescription', ExitDescription);
																										hm.response.statusCode = responseStatusCode;
																										//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																										var lookupResponse = JSON.parse(responseData);
																										//	var toStateID_LookupUpdate;	
																										if (lookupResponse.lookupRep.type[0].result == 0) {

																											var CharacterOfWorkSelection_DESCRIPTION = lookupResponse.lookupRep.type[0].status;
																											var ctx = session.name("SOM") || session.createContext("SOM");
																											ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																										} else {
																											var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DESCRIPTION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																											ILSctx.setVariable('ExitStatus', '1');
																											ILSctx.setVariable('ErrorDescription', invalidresp);
																											logger.error(invalidresp)

																											//logger.error("Lookup result 1 for DESCRIPTION "+Incoming_DESCRIPTION);
																											//session.reject("LookupServiceResponse result 1 for Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																											var ctx = session.name("SOM") || session.createContext("SOM");
																											var TicketId = ctx.getVar("TICKETID");
																											var responsemessage = "500 Lookup Response for given DESCRIPTION/Character_Of_Work_Selection field value is invalid";
																											
																											var orderType = ctx.getVar("CLASSIFICATIONID");
																											var PayloadAddon = {

																												"maximoID": TicketId,
																												"timeStamp": IncomingCreationDateTime,
																												"orderType": orderType,
																												"orderStatus": toState,
																												"messageID": messageId,
																												"somID": somID

																											}
																											var np_statusmemo = responsemessage.slice(0, 99);
																											var MaximoNegativeUpdateResponsePayload = {
																												"ticketid": TicketId,
																												"status": "NegativeAcknowledge",
																												"np_statusmemo": np_statusmemo,
																												"esbData": PayloadAddon
																											}

																											ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																											ctx.setVar("LookupMaximoResponse", 'yes');
																											//start calling maximoResponsecall api
																											var Queueurl = session.parameters.BackendMQurl;
																											var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																										}

																										var ctx = session.name("SOM") || session.createContext("SOM");
																										var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																										//Incoming_DTE_WORKLOCATION
																										if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

																											var Responsible_Service_Center_DTE_WORKLOCATION = '';
																											var ctx = session.name("SOM") || session.createContext("SOM");
																											ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																										} else {
																											var lookupMessage = {
																												"lookupReq": {
																													"type": [
																														{
																															"name": "switchOrderDescription",
																															"label": Incoming_DTE_WORKLOCATION
																														}]
																												}
																											}
																											var url = session.parameters.lookupUrl;
																											var LookupServiceResponse = {
																												target: url,
																												method: 'POST',
																												contentType: 'application/json',
																												data: lookupMessage
																											};
																											var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																											urlopen.open(LookupServiceResponse, function(error, response) {
																												if (error) {
																													var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																													ILSctx.setVariable('ExitStatus', '500');
																													ILSctx.setVariable('ErrorDescription', errorinfo);
																													logger.error(errorinfo);
																													session.reject(errorinfo);
																												} else {
																													var responseStatusCode = response.statusCode;
																													if (responseStatusCode == 200) {
																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ErrorDescription', errorinfo);
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															} else {
																																ILSctx.setVariable('ExitStatus', '0');
																																ILSctx.setVariable('ExitDescription', ExitDescription);
																																hm.response.statusCode = responseStatusCode;
																																//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																																var lookupResponse = JSON.parse(responseData);
																																//	var toStateID_LookupUpdate;	
																																if (lookupResponse.lookupRep.type[0].result == 0) {
																																	var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																																	var ctx = session.name("SOM") || session.createContext("SOM");
																																	ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																																} else {
																																	var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DTE_WORKLOCATION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																	ILSctx.setVariable('ExitStatus', '1');
																																	ILSctx.setVariable('ExitDescription', invalidresp);
																																	logger.error(invalidresp)
																																	//logger.error("Result 1 for lookup for DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																																	//session.reject("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																																	var ctx = session.name("SOM") || session.createContext("SOM");
																																	var TicketId = ctx.getVar("TICKETID");
																																	var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																																	
																																	var orderType = ctx.getVar("CLASSIFICATIONID");
																																	var PayloadAddon = {

																																		"maximoID": TicketId,
																																		"timeStamp": IncomingCreationDateTime,
																																		"orderType": orderType,
																																		"orderStatus": toState,
																																		"messageID": messageId,
																																		"somID": somID

																																	}
																																	var np_statusmemo = responsemessage.slice(0, 99);
																																	var MaximoNegativeUpdateResponsePayload = {
																																		"ticketid": TicketId,
																																		"status": "NegativeAcknowledge",
																																		"np_statusmemo": np_statusmemo,
																																		"esbData": PayloadAddon
																																	}

																																	ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																																	ctx.setVar("LookupMaximoResponse", 'yes');
																																	//start calling maximoResponsecall api
																																	var Queueurl = session.parameters.BackendMQurl;
																																	var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																																}
																															}
																														});
																													} else {
																														//Added readAsBuffer 9
																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ErrorDescription', errorinfo);
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															} else {
																																var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ErrorDescription', errorinfo);
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															}
																														})
																													}
																												}
																											});
																										}
																									}
																								});
																							} else {
																								//Added readAsBuffer 8
																								response.readAsBuffer(function(error, responseData) {
																									if (error) {
																										var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																										ILSctx.setVariable('ExitStatus', responseStatusCode);
																										ILSctx.setVariable('ErrorDescription', errorinfo);
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									} else {
																										var errorinfo = "error response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																										ILSctx.setVariable('ExitStatus', responseStatusCode);
																										ILSctx.setVariable('ErrorDescription', errorinfo);
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									}
																								})
																							}
																						}
																					});
																					//338		
																				}
																				//242
																			}
																			//making changes for reasonfor reject
																		} else {
																			//logger.error("Result 1 for lookup for switchOrderWorkFlowID"+switchOrderWorkFlowID);
																			//session.reject("Result is not 0 for lookup for switchOrderWorkFlowID"+switchOrderWorkFlowID);
																			//468
																			var invalidresp = "Invalid Lookup Request 'LookUp switchOrderWorkFlowID', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', '1');
																			ILSctx.setVariable('ErrorDescription', invalidresp);
																			logger.error(invalidresp)
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var TicketId = ctx.getVar("TICKETID");
																			var responsemessage = "500 Lookup Response for given WorkFlow STATUS/ToStateId field value is invalid";
																			var np_statusmemo = responsemessage.slice(0, 99);
																			var orderType = ctx.getVar("CLASSIFICATIONID");
																			var PayloadAddon = {

																				"maximoID": TicketId,
																				"timeStamp": IncomingCreationDateTime,
																				"orderType": orderType,
																				"orderStatus": toState,
																				"messageID": messageId,
																				"somID": somID

																			}
																			var MaximoNegativeUpdateResponsePayload = {
																				"ticketid": TicketId,
																				"status": "NegativeAcknowledge",
																				"np_statusmemo": np_statusmemo,
																				"esbData": PayloadAddon
																			}

																			ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																			ctx.setVar("LookupMaximoResponse", 'yes');
																			//start calling maximoResponsecall api
																			var Queueurl = session.parameters.BackendMQurl;
																			var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																			//468
																		}
																	}
																});
															} else {
																//Added readAsBuffer 2
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'LookUp switchOrderTypeObjectID', details are : " + info + "; error info :" + error
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = "error response 'LookUp switchOrderTypeObjectID', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																})
															}
														}
													});
												} else {
													//else if maximo status match is not found .. no tosatelookup done 
													//242
													var ctx = session.name("SOM") || session.createContext("SOM");
													var Incoming_DESCRIPTION = ctx.getVar('DESCRIPTION');
													var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
													//Incoming_DTE_WORKLOCATION
													if (Incoming_DESCRIPTION == undefined || Incoming_DESCRIPTION == null || Incoming_DESCRIPTION == '') {
														var CharacterOfWorkSelection_DESCRIPTION = '';
														var ctx = session.name("SOM") || session.createContext("SOM");
														ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
														var ctx = session.name("SOM") || session.createContext("SOM");
														var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
														//Incoming_DTE_WORKLOCATION
														if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

															var Responsible_Service_Center_DTE_WORKLOCATION = '';
															var ctx = session.name("SOM") || session.createContext("SOM");
															ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
														} else {
															var lookupMessage = {
																"lookupReq": {
																	"type": [
																		{
																			"name": "switchOrderDescription",
																			"label": Incoming_DTE_WORKLOCATION
																		}]
																}
															}
															var url = session.parameters.lookupUrl;
															var LookupServiceResponse = {
																target: url,
																method: 'POST',
																contentType: 'application/json',
																data: lookupMessage
															};
															var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

															urlopen.open(LookupServiceResponse, function(error, response) {
																if (error) {
																	var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus', '500');
																	ILSctx.setVariable('ErrorDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var responseStatusCode = response.statusCode;
																	if (responseStatusCode == 200) {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus', responseStatusCode);
																				ILSctx.setVariable('ErrorDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				ILSctx.setVariable('ExitStatus', '0');
																				ILSctx.setVariable('ExitDescription', ExitDescription);
																				hm.response.statusCode = responseStatusCode;
																				var lookupResponse = JSON.parse(responseData);
																				//	var toStateID_LookupUpdate;	
																				if (lookupResponse.lookupRep.type[0].result == 0) {
																					var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																					var ctx = session.name("SOM") || session.createContext("SOM");
																					ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																				} else {
																					var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DTE_WORKLOCATION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																					ILSctx.setVariable('ExitStatus', '1');
																					ILSctx.setVariable('ErrorDescription', invalidresp);
																					logger.error(invalidresp)
																					//logger.error("result 1 from Lookup DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																					//			session.reject("result is 1 for LookupServiceResponse Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																					var ctx = session.name("SOM") || session.createContext("SOM");
																					var TicketId = ctx.getVar("TICKETID");
																					var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																					
																					var orderType = ctx.getVar("CLASSIFICATIONID");
																					var PayloadAddon = {

																						"maximoID": TicketId,
																						"timeStamp": IncomingCreationDateTime,
																						"orderType": orderType,
																						"orderStatus": toState,
																						"messageID": messageId,
																						"somID": somID

																					}
																					var np_statusmemo = responsemessage.slice(0, 99);
																					var MaximoNegativeUpdateResponsePayload = {
																						"ticketid": TicketId,
																						"status": "NegativeAcknowledge",
																						"np_statusmemo": np_statusmemo,
																						"esbData": PayloadAddon
																					}

																					ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																					ctx.setVar("LookupMaximoResponse", 'yes');
																					//start calling maximoResponsecall api
																					var Queueurl = session.parameters.BackendMQurl;
																					var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																				}
																			}
																		});
																	} else {
																		//Added readAsBuffer 10
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus',responseStatusCode);
																				ILSctx.setVariable('ErrorDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																				ILSctx.setVariable('ExitStatus', responseStatusCode);
																				ILSctx.setVariable('ErrorDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			}
																		})
																	}
																}
															});
														}
													} else {
														//338
														var lookupMessage = {
															"lookupReq": {
																"type": [
																	{
																		"name": "switchOrderDescription",
																		"label": Incoming_DESCRIPTION
																	}]
															}
														}
														var url = session.parameters.lookupUrl;
														var LookupServiceResponse = {
															target: url,
															method: 'POST',
															contentType: 'application/json',
															data: lookupMessage
														};
														var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
														urlopen.open(LookupServiceResponse, function(error, response) {
															if (error) {
																var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ErrorDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var responseStatusCode = response.statusCode;
																if (responseStatusCode == 200) {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			ILSctx.setVariable('ExitStatus', '0');
																			ILSctx.setVariable('ExitDescription', ExitDescription);
																			hm.response.statusCode = responseStatusCode;
																			var lookupResponse = JSON.parse(responseData);
																			//	var toStateID_LookupUpdate;	
																			if (lookupResponse.lookupRep.type[0].result == 0) {

																				var CharacterOfWorkSelection_DESCRIPTION = lookupResponse.lookupRep.type[0].status;
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																			} else {
																				var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DESCRIPTION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																				ILSctx.setVariable('ExitStatus', '1');
																				ILSctx.setVariable('ErrorDescription', invalidresp);
																				logger.error(invalidresp)
																				//logger.error("Lookup result 1 for DESCRIPTION "+Incoming_DESCRIPTION);
																				//session.reject("LookupServiceResponse result 1 for Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				var TicketId = ctx.getVar("TICKETID");
																				var responsemessage = "500 Lookup Response for given DESCRIPTION/Character_Of_Work_Selection field value is invalid";
																				
																				var orderType = ctx.getVar("CLASSIFICATIONID");
																				var PayloadAddon = {

																					"maximoID": TicketId,
																					"timeStamp": IncomingCreationDateTime,
																					"orderType": orderType,
																					"orderStatus": toState,
																					"messageID": messageId,
																					"somID": somID

																				}
																				var np_statusmemo = responsemessage.slice(0, 99);
																				var MaximoNegativeUpdateResponsePayload = {
																					"ticketid": TicketId,
																					"status": "NegativeAcknowledge",
																					"np_statusmemo": np_statusmemo,
																					"esbData": PayloadAddon
																				}

																				ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																				ctx.setVar("LookupMaximoResponse", 'yes');
																				//start calling maximoResponsecall api
																				var Queueurl = session.parameters.BackendMQurl;
																				var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																			}

																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																			//Incoming_DTE_WORKLOCATION
																			if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {
																				var Responsible_Service_Center_DTE_WORKLOCATION = '';
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																			} else {
																				var lookupMessage = {
																					"lookupReq": {
																						"type": [
																							{
																								"name": "switchOrderDescription",
																								"label": Incoming_DTE_WORKLOCATION
																							}]
																					}
																				}
																				var url = session.parameters.lookupUrl;
																				var LookupServiceResponse = {
																					target: url,
																					method: 'POST',
																					contentType: 'application/json',
																					data: lookupMessage
																				};
																				var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																				urlopen.open(LookupServiceResponse, function(error, response) {
																					if (error) {
																						var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', '500');
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var responseStatusCode = response.statusCode;
																						if (responseStatusCode == 200) {
																							response.readAsBuffer(function(error, responseData) {
																								if (error) {
																									var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus',responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									ILSctx.setVariable('ExitStatus', '0');
																									ILSctx.setVariable('ExitDescription', ExitDescription);
																									hm.response.statusCode = responseStatusCode;
																									var lookupResponse = JSON.parse(responseData);
																									//	var toStateID_LookupUpdate;	
																									if (lookupResponse.lookupRep.type[0].result == 0) {
																										var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																									} else {
																										var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DTE_WORKLOCATION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																										ILSctx.setVariable('ExitStatus', '1');
																										ILSctx.setVariable('ErrorDescription', invalidresp);
																										logger.error(invalidresp)

																										//logger.error("Result 1 from lookup DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																										//session.reject("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										var TicketId = ctx.getVar("TICKETID");
																										var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																										
																										var orderType = ctx.getVar("CLASSIFICATIONID");
																										var PayloadAddon = {

																											"maximoID": TicketId,
																											"timeStamp": IncomingCreationDateTime,
																											"orderType": orderType,
																											"orderStatus": toState,
																											"messageID": messageId,
																											"somID": somID

																										}
																										var np_statusmemo = responsemessage.slice(0, 99);
																										var MaximoNegativeUpdateResponsePayload = {
																											"ticketid": TicketId,
																											"status": "NegativeAcknowledge",
																											"np_statusmemo": np_statusmemo,
																											"esbData": PayloadAddon
																										}

																										ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																										ctx.setVar("LookupMaximoResponse", 'yes');
																										//start calling maximoResponsecall api
																										var Queueurl = session.parameters.BackendMQurl;
																										var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																									}
																								}
																							});
																						} else {
																							//Added readAsBuffer 12
																							response.readAsBuffer(function(error, responseData) {
																								if (error) {
																									var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								}
																							})
																						}
																					}
																				});
																			}
																		}
																	});
																} else {
																	//Added readAsBuffer 11
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}
																	})
																}
															}
														});
														//338		
													}
													//242
												}	//208 getting id for tostatecall end
											} else {
												// making change for reason for  reject
												var DTE_Reason_Reject_val = ctx.getVar("DTE_Reason_Reject");
												var isANumber = isNaN(DTE_Reason_Reject_val) == false;
												if (DTE_Reason_Reject_val.length > 0 && (DTE_Reason_Reject_val !== undefined || DTE_Reason_Reject_val !== '' || DTE_Reason_Reject_val !== null) && (isANumber == false)) {
													//	if(DTE_Reason_Reject_val !== undefined || DTE_Reason_Reject_val !== '' || DTE_Reason_Reject_val !== null){
													//if (isANumber == false){
													var DTE_Reason_Reject_Lookup_Payload = {
														"lookupReq": {
															"type": [
																{
																	"name": "switchOrderDescription",
																	"label": DTE_Reason_Reject_val
																}
															]
														}
													}

													var url = session.parameters.lookupUrl;;
													//var test = DTE_Reason_Reject_Lookup(url, DTE_Reason_Reject_Lookup_Payload);

													var LookupServiceResponse = {
														target: url,
														method: 'POST',
														contentType: 'application/json',
														data: DTE_Reason_Reject_Lookup_Payload
													};
													var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
													urlopen.open(LookupServiceResponse, function(error, response) {
														if (error) {
															var errorinfo = "url connection error 'LookUp DTE_Reason_Reject_Lookup_Payload', details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', '500');
															ILSctx.setVariable('ErrorDescription', errorinfo);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															var responseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																ILSctx.setVariable('ExitStatus', '0');
																ILSctx.setVariable('ExitDescription', ExitDescription);
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'LookUp DTE_Reason_Reject_Lookup_Payload', details are : " + info + "; error info :" + error
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		hm.response.statusCode = responseStatusCode;
																		logger.debug("response received from LookupServiceResponse for DTE_Reason_Reject_Lookup_Payload " + responseStatusCode);
																		var lookupResponse = JSON.parse(responseData);
																		var switchOrderWorkFlowID;
																		if (lookupResponse.lookupRep.type[0].result == 0) {

																			var DTE_Reason_Reject = lookupResponse.lookupRep.type[0].status;
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			ctx.setVariable("DTE_Reason_Reject", DTE_Reason_Reject);
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var Incoming_DESCRIPTION = ctx.getVar('DESCRIPTION');
																			var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																			//Incoming_DTE_WORKLOCATION
																			if (Incoming_DESCRIPTION == undefined || Incoming_DESCRIPTION == null || Incoming_DESCRIPTION == '') {
																				var CharacterOfWorkSelection_DESCRIPTION = '';
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																				//Incoming_DTE_WORKLOCATION
																				if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

																					var Responsible_Service_Center_DTE_WORKLOCATION = '';
																					var ctx = session.name("SOM") || session.createContext("SOM");
																					ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																				} else {
																					var lookupMessage = {
																						"lookupReq": {
																							"type": [
																								{
																									"name": "switchOrderDescription",
																									"label": Incoming_DTE_WORKLOCATION
																								}]
																						}
																					}
																					var url = session.parameters.lookupUrl;
																					var LookupServiceResponse = {
																						target: url,
																						method: 'POST',
																						contentType: 'application/json',
																						data: lookupMessage
																					};
																					var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

																					urlopen.open(LookupServiceResponse, function(error, response) {
																						if (error) {
																							var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('ExitStatus', '500');
																							ILSctx.setVariable('ErrorDescription', errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							var responseStatusCode = response.statusCode;
																							if (responseStatusCode == 200) {
																								response.readAsBuffer(function(error, responseData) {
																									if (error) {
																										var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																										ILSctx.setVariable('ExitStatus', responseStatusCode);
																										ILSctx.setVariable('ErrorDescription', errorinfo);
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									} else {
																										ILSctx.setVariable('ExitStatus', '0');
																										ILSctx.setVariable('ExitDescription', ExitDescription);
																										hm.response.statusCode = responseStatusCode;
																										//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																										var lookupResponse = JSON.parse(responseData);
																										//	var toStateID_LookupUpdate;	
																										if (lookupResponse.lookupRep.type[0].result == 0) {
																											var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																											var ctx = session.name("SOM") || session.createContext("SOM");
																											ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																										} else {
																											//			logger.error("result 1 for Lookup DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																											//			session.reject("result is 1 for LookupServiceResponse Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																											var ctx = session.name("SOM") || session.createContext("SOM");
																											var TicketId = ctx.getVar("TICKETID");
																											var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																											
																											var orderType = ctx.getVar("CLASSIFICATIONID");
																											var PayloadAddon = {

																												"maximoID": TicketId,
																												"timeStamp": IncomingCreationDateTime,
																												"orderType": orderType,
																												"orderStatus": toState,
																												"messageID": messageId,
																												"somID": somID

																											}
																											var np_statusmemo = responsemessage.slice(0, 99);
																											var MaximoNegativeUpdateResponsePayload = {
																												"ticketid": TicketId,
																												"status": "NegativeAcknowledge",
																												"np_statusmemo": np_statusmemo,
																												"esbData": PayloadAddon
																											}

																											ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																											ctx.setVar("LookupMaximoResponse", 'yes');
																											//start calling maximoResponsecall api
																											var Queueurl = session.parameters.BackendMQurl;
																											var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																										}
																									}
																								});
																							} else {
																								//Added readAsBuffer 14
																								response.readAsBuffer(function(error, responseData) {
																									if (error) {
																										var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																										ILSctx.setVariable('ExitStatus', responseStatusCode);
																										ILSctx.setVariable('ErrorDescription', errorinfo);
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									} else {
																										var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																										ILSctx.setVariable('ExitStatus', responseStatusCode);
																										ILSctx.setVariable('ErrorDescription', errorinfo);
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									}
																								})
																							}
																						}
																					});
																				}
																			} else {
																				//338
																				var lookupMessage = {
																					"lookupReq": {
																						"type": [
																							{
																								"name": "switchOrderDescription",
																								"label": Incoming_DESCRIPTION
																							}]
																					}
																				}
																				var url = session.parameters.lookupUrl;
																				var LookupServiceResponse = {
																					target: url,
																					method: 'POST',
																					contentType: 'application/json',
																					data: lookupMessage
																				};
																				var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																				urlopen.open(LookupServiceResponse, function(error, response) {
																					if (error) {
																						var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', '500');
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var responseStatusCode = response.statusCode;
																						if (responseStatusCode == 200) {
																							response.readAsBuffer(function(error, responseData) {
																								if (error) {
																									var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									ILSctx.setVariable('ExitStatus', '0');
																									ILSctx.setVariable('ExitDescription', ExitDescription);
																									hm.response.statusCode = responseStatusCode;
																									//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																									var lookupResponse = JSON.parse(responseData);
																									//	var toStateID_LookupUpdate;	
																									if (lookupResponse.lookupRep.type[0].result == 0) {
																										var CharacterOfWorkSelection_DESCRIPTION = lookupResponse.lookupRep.type[0].status;
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																									} else {

																										//logger.error("Lookup result 1 for DESCRIPTION "+Incoming_DESCRIPTION);
																										//session.reject("LookupServiceResponse result 1 for Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										var TicketId = ctx.getVar("TICKETID");
																										var responsemessage = "500 Lookup Response for given DESCRIPTION/Character_Of_Work_Selection field value is invalid";
																										
																										var orderType = ctx.getVar("CLASSIFICATIONID");
																										var PayloadAddon = {

																											"maximoID": TicketId,
																											"timeStamp": IncomingCreationDateTime,
																											"orderType": orderType,
																											"orderStatus": toState,
																											"messageID": messageId,
																											"somID": somID

																										}
																										var np_statusmemo = responsemessage.slice(0, 99);
																										var MaximoNegativeUpdateResponsePayload = {
																											"ticketid": TicketId,
																											"status": "NegativeAcknowledge",
																											"np_statusmemo": np_statusmemo,
																											"esbData": PayloadAddon
																										}

																										ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																										ctx.setVar("LookupMaximoResponse", 'yes');
																										//start calling maximoResponsecall api
																										var Queueurl = session.parameters.BackendMQurl;
																										var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																									}

																									var ctx = session.name("SOM") || session.createContext("SOM");
																									var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																									//Incoming_DTE_WORKLOCATION
																									if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

																										var Responsible_Service_Center_DTE_WORKLOCATION = '';
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																									} else {
																										var lookupMessage = {
																											"lookupReq": {
																												"type": [
																													{
																														"name": "switchOrderDescription",
																														"label": Incoming_DTE_WORKLOCATION
																													}]
																											}
																										}
																										var url = session.parameters.lookupUrl;
																										var LookupServiceResponse = {
																											target: url,
																											method: 'POST',
																											contentType: 'application/json',
																											data: lookupMessage
																										};
																										var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

																										urlopen.open(LookupServiceResponse, function(error, response) {
																											if (error) {
																												var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																												ILSctx.setVariable('ExitStatus', '500');
																												ILSctx.setVariable('ErrorDescription', errorinfo);
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											} else {
																												var responseStatusCode = response.statusCode;
																												if (responseStatusCode == 200) {
																													response.readAsBuffer(function(error, responseData) {
																														if (error) {
																															var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																															ILSctx.setVariable('ExitStatus', responseStatusCode);
																															ILSctx.setVariable('ErrorDescription', errorinfo);
																															logger.error(errorinfo);
																															session.reject(errorinfo);
																														} else {
																															ILSctx.setVariable('ExitStatus', '0');
																															ILSctx.setVariable('ExitDescription', ExitDescription);
																															hm.response.statusCode = responseStatusCode;
																															//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																															var lookupResponse = JSON.parse(responseData);
																															//	var toStateID_LookupUpdate;	
																															if (lookupResponse.lookupRep.type[0].result == 0) {
																																var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																																var ctx = session.name("SOM") || session.createContext("SOM");
																																ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																															} else {

																																//logger.error("Result 1 for lookup for DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																																//session.reject("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																																var ctx = session.name("SOM") || session.createContext("SOM");
																																var TicketId = ctx.getVar("TICKETID");
																																var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																																
																																var orderType = ctx.getVar("CLASSIFICATIONID");
																																var PayloadAddon = {

																																	"maximoID": TicketId,
																																	"timeStamp": IncomingCreationDateTime,
																																	"orderType": orderType,
																																	"orderStatus": toState,
																																	"messageID": messageId,
																																	"somID": somID

																																}
																																var np_statusmemo = responsemessage.slice(0, 99);
																																var MaximoNegativeUpdateResponsePayload = {
																																	"ticketid": TicketId,
																																	"status": "NegativeAcknowledge",
																																	"np_statusmemo": np_statusmemo,
																																	"esbData": PayloadAddon
																																}

																																ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																																ctx.setVar("LookupMaximoResponse", 'yes');
																																//start calling maximoResponsecall api
																																var Queueurl = session.parameters.BackendMQurl;
																																var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																															}
																														}
																													});
																												} else {
																													//Added readAsBuffer 16
																													response.readAsBuffer(function(error, responseData) {
																														if (error) {
																															var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																															ILSctx.setVariable('ExitStatus', responseStatusCode);
																															ILSctx.setVariable('ErrorDescription', errorinfo);
																															logger.error(errorinfo);
																															session.reject(errorinfo);
																														} else {
																															var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																															ILSctx.setVariable('ExitStatus', responseStatusCode);
																															ILSctx.setVariable('ErrorDescription', errorinfo);
																															logger.error(errorinfo);
																															session.reject(errorinfo);
																														}
																													})
																												}
																											}
																										});
																									}
																								}
																							});
																						} else {
																							//Added readAsBuffer 15
																							response.readAsBuffer(function(error, responseData) {
																								if (error) {
																									var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									var errorinfo = "error response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								}
																							})
																						}
																					}
																				});
																				//338		
																			}
																			//242
																		} else {
																			var invalidresp = "Invalid Lookup Request 'LookUp DTE_Reason_Reject_Lookup_Payload', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', '1');
																			ILSctx.setVariable('ErrorDescription', invalidresp);
																			logger.error(invalidresp)
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var DTE_Reason_Reject_val = ctx.getVar("DTE_Reason_Reject");
																			var TicketId = ctx.getVar("TICKETID");
																			var responsemessage = "500 Lookup Response for given DTE_REASON_REJECT/Reason_For_Action field value is invalid";
																			//	session.reject("response received from LookupServiceResponse for DTE_Reason_Reject_Lookup_Payload for label "+DTE_Reason_Reject_val+" is result 1");
																			var np_statusmemo = responsemessage.slice(0, 99);
																			
																			var orderType = ctx.getVar("CLASSIFICATIONID");
																			var PayloadAddon = {

																				"maximoID": TicketId,
																				"timeStamp": IncomingCreationDateTime,
																				"orderType": orderType,
																				"orderStatus": toState,
																				"messageID": messageId,
																				"somID": somID

																			}
																			var MaximoNegativeUpdateResponsePayload = {
																				"ticketid": TicketId,
																				"status": "NegativeAcknowledge",
																				"np_statusmemo": np_statusmemo,
																				"esbData": PayloadAddon
																			}

																			ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																			ctx.setVar("LookupMaximoResponse", 'yes');
																			//start calling maximoResponsecall api
																			var Queueurl = session.parameters.BackendMQurl;
																			var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																		}
																	}
																});
															} else {
																//Added readAsBuffer 13
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'LookUp DTE_Reason_Reject_Lookup_Payload', details are : " + info + "; error info :" + error
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = "error response 'LookUp DTE_Reason_Reject_Lookup_Payload', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																})
															}
														}
													});
												} else {
													var ctx = session.name("SOM") || session.createContext("SOM");
													var Incoming_DESCRIPTION = ctx.getVar('DESCRIPTION');
													var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
													//Incoming_DTE_WORKLOCATION
													if (Incoming_DESCRIPTION == undefined || Incoming_DESCRIPTION == null || Incoming_DESCRIPTION == '') {
														var CharacterOfWorkSelection_DESCRIPTION = '';
														var ctx = session.name("SOM") || session.createContext("SOM");
														ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
														var ctx = session.name("SOM") || session.createContext("SOM");
														var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
														//Incoming_DTE_WORKLOCATION
														if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

															var Responsible_Service_Center_DTE_WORKLOCATION = '';
															var ctx = session.name("SOM") || session.createContext("SOM");
															ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
														} else {
															var lookupMessage = {
																"lookupReq": {
																	"type": [
																		{
																			"name": "switchOrderDescription",
																			"label": Incoming_DTE_WORKLOCATION
																		}]
																}
															}
															var url = session.parameters.lookupUrl;
															var LookupServiceResponse = {
																target: url,
																method: 'POST',
																contentType: 'application/json',
																data: lookupMessage
															};
															var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
															urlopen.open(LookupServiceResponse, function(error, response) {
																if (error) {
																	var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus', '500');
																	ILSctx.setVariable('ErrorDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var responseStatusCode = response.statusCode;
																	if (responseStatusCode == 200) {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus', responseStatusCode);
																				ILSctx.setVariable('ErrorDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				ILSctx.setVariable('ExitStatus', '0');
																				ILSctx.setVariable('ExitDescription', ExitDescription);
																				hm.response.statusCode = responseStatusCode;
																				//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																				var lookupResponse = JSON.parse(responseData);
																				//	var toStateID_LookupUpdate;	
																				if (lookupResponse.lookupRep.type[0].result == 0) {
																					var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																					var ctx = session.name("SOM") || session.createContext("SOM");
																					ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																				} else {

																					var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DTE_WORKLOCATION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																					ILSctx.setVariable('ExitStatus', '1');
																					ILSctx.setVariable('ErrorDescription', invalidresp);
																					logger.error(invalidresp)
																					//			logger.error("result 1 for Lookup DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																					//			session.reject("result is 1 for LookupServiceResponse Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																					var ctx = session.name("SOM") || session.createContext("SOM");
																					var TicketId = ctx.getVar("TICKETID");
																					var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																					
																					var orderType = ctx.getVar("CLASSIFICATIONID");
																					var PayloadAddon = {

																						"maximoID": TicketId,
																						"timeStamp": IncomingCreationDateTime,
																						"orderType": orderType,
																						"orderStatus": toState,
																						"messageID": messageId,
																						"somID": somID

																					}
																					var np_statusmemo = responsemessage.slice(0, 99);
																					var MaximoNegativeUpdateResponsePayload = {
																						"ticketid": TicketId,
																						"status": "NegativeAcknowledge",
																						"np_statusmemo": np_statusmemo,
																						"esbData": PayloadAddon
																					}

																					ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																					ctx.setVar("LookupMaximoResponse", 'yes');
																					//start calling maximoResponsecall api
																					var Queueurl = session.parameters.BackendMQurl;
																					var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																				}
																			}
																		});
																	} else {
																		//Added readAsBuffer 17
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus', responseStatusCode);
																				ILSctx.setVariable('ErrorDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																				ILSctx.setVariable('ExitStatus', responseStatusCode);
																				ILSctx.setVariable('ErrorDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			}
																		})
																	}
																}
															});
														}
													} else {
														var lookupMessage = {
															"lookupReq": {
																"type": [
																	{
																		"name": "switchOrderDescription",
																		"label": Incoming_DESCRIPTION
																	}]
															}
														}
														var url = session.parameters.lookupUrl;
														var LookupServiceResponse = {
															target: url,
															method: 'POST',
															contentType: 'application/json',
															data: lookupMessage
														};
														var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
														urlopen.open(LookupServiceResponse, function(error, response) {
															if (error) {
																var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ErrorDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var responseStatusCode = response.statusCode;
																if (responseStatusCode == 200) {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			ILSctx.setVariable('ExitStatus', '0');
																			ILSctx.setVariable('ExitDescription', ExitDescription);
																			hm.response.statusCode = responseStatusCode;
																			//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																			var lookupResponse = JSON.parse(responseData);
																			//	var toStateID_LookupUpdate;	
																			if (lookupResponse.lookupRep.type[0].result == 0) {

																				var CharacterOfWorkSelection_DESCRIPTION = lookupResponse.lookupRep.type[0].status;
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																			} else {
																				var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DESCRIPTION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																				ILSctx.setVariable('ExitStatus', '1');
																				ILSctx.setVariable('ErrorDescription', invalidresp);
																				logger.error(invalidresp)
																				//logger.error("Lookup result 1 for DESCRIPTION "+Incoming_DESCRIPTION);
																				//session.reject("LookupServiceResponse result 1 for Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				var TicketId = ctx.getVar("TICKETID");
																				var responsemessage = "500 Lookup Response for given DESCRIPTION/Character_Of_Work_Selection field value is invalid";
																			
																				var orderType = ctx.getVar("CLASSIFICATIONID");
																				var PayloadAddon = {

																					"maximoID": TicketId,
																					"timeStamp": IncomingCreationDateTime,
																					"orderType": orderType,
																					"orderStatus": toState,
																					"messageID": messageId,
																					"somID": somID

																				}
																				var np_statusmemo = responsemessage.slice(0, 99);
																				var MaximoNegativeUpdateResponsePayload = {
																					"ticketid": TicketId,
																					"status": "NegativeAcknowledge",
																					"np_statusmemo": np_statusmemo,
																					"esbData": PayloadAddon
																				}

																				ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																				ctx.setVar("LookupMaximoResponse", 'yes');
																				//start calling maximoResponsecall api
																				var Queueurl = session.parameters.BackendMQurl;
																				var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																			}

																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																			//Incoming_DTE_WORKLOCATION
																			if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

																				var Responsible_Service_Center_DTE_WORKLOCATION = '';
																				var ctx = session.name("SOM") || session.createContext("SOM");
																				ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																			} else {
																				var lookupMessage = {
																					"lookupReq": {
																						"type": [
																							{
																								"name": "switchOrderDescription",
																								"label": Incoming_DTE_WORKLOCATION
																							}]
																					}
																				}
																				var url = session.parameters.lookupUrl;
																				var LookupServiceResponse = {
																					target: url,
																					method: 'POST',
																					contentType: 'application/json',
																					data: lookupMessage
																				};
																				var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																				urlopen.open(LookupServiceResponse, function(error, response) {
																					if (error) {
																						var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', '500');
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var responseStatusCode = response.statusCode;
																						if (responseStatusCode == 200) {
																							response.readAsBuffer(function(error, responseData) {
																								if (error) {
																									var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									hm.response.statusCode = responseStatusCode;
																									//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																									var lookupResponse = JSON.parse(responseData);
																									//	var toStateID_LookupUpdate;	
																									if (lookupResponse.lookupRep.type[0].result == 0) {
																										var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																									} else {
																										var invalidresp = "Invalid Lookup Request 'LookUp Incoming_DTE_WORKLOCATION', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																										ILSctx.setVariable('ExitStatus', '1');
																										ILSctx.setVariable('ExitDescription', invalidresp);
																										logger.error(invalidresp)
																										//logger.error("Result 1 for lookup for DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																										//session.reject("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																										var ctx = session.name("SOM") || session.createContext("SOM");
																										var TicketId = ctx.getVar("TICKETID");
																										var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																										
																										var orderType = ctx.getVar("CLASSIFICATIONID");
																										var PayloadAddon = {

																											"maximoID": TicketId,
																											"timeStamp": IncomingCreationDateTime,
																											"orderType": orderType,
																											"orderStatus": toState,
																											"messageID": messageId,
																											"somID": somID

																										}
																										var np_statusmemo = responsemessage.slice(0, 99);
																										var MaximoNegativeUpdateResponsePayload = {
																											"ticketid": TicketId,
																											"status": "NegativeAcknowledge",
																											"np_statusmemo": np_statusmemo,
																											"esbData": PayloadAddon
																										}
																										ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																										ctx.setVar("LookupMaximoResponse", 'yes');
																										//start calling maximoResponsecall api
																										var Queueurl = session.parameters.BackendMQurl;
																										var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																									}
																								}
																							});
																						} else {
																							//Added readAsBuffer 19
																							response.readAsBuffer(function(error, responseData) {
																								if (error) {
																									var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																									ILSctx.setVariable('ExitStatus', responseStatusCode);
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								}
																							})
																						}
																					}
																				});
																			}
																		}
																	});
																} else {
																	//Added readAsBuffer 18
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var errorinfo = "error response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}
																	})
																}
															}
														});
														//338		
													}
													//242
												}
												//making changes for reasonfor reject
											}
											//164 maximo status

										} else {
											//need to check  what should be done at this case should we log and leave it or any message need to be passed
											//logger.error("Result 1 for lookup switchOrderTypeObjectID"+switchOrderTypeObjectID);
											//session.reject("Result is not 0 for lookup for switchOrderTypeObjectID"+switchOrderTypeObjectID);
											//887
											var invalidresp = "Invalid Lookup Request 'LookUp switchOrderTypeObjectID', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', '1');
											ILSctx.setVariable('ErrorDescription', invalidresp);
											logger.error(invalidresp)

											var ctx = session.name("SOM") || session.createContext("SOM");
											var TicketId = ctx.getVar("TICKETID");
											var responsemessage = "500 Lookup Response for given CLASSIFICATIONID/switchOrderTypeObjectID field value is invalid";
											var np_statusmemo = responsemessage.slice(0, 99);
											var orderType = ctx.getVar("CLASSIFICATIONID");
											var PayloadAddon = {

												"maximoID": TicketId,
												"timeStamp": IncomingCreationDateTime,
												"orderType": orderType,
												"orderStatus": toState,
												"messageID": messageId,
												"somID": somID

											}
											var MaximoNegativeUpdateResponsePayload = {
												"ticketid": TicketId,
												"status": "NegativeAcknowledge",
												"np_statusmemo": np_statusmemo,
												"esbData": PayloadAddon
											}

											ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
											ctx.setVar("LookupMaximoResponse", 'yes');
											//start calling maximoResponsecall api
											var Queueurl = session.parameters.BackendMQurl;
											var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
										}
									}
								});
							} else {
								//Added readAsBuffer 1
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'LookUp switchOrderTypeObjectID', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ErrorDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var errorinfo = "error response 'LookUp switchOrderTypeObjectID', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ErrorDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
								})

							}
						}
					});
				} else {
					var ctx = session.name("SOM") || session.createContext("SOM");
					var TicketIdVal = ctx.getVar("TICKETID");
					logger.error("It is an older update for TicketId " + TicketIdVal + " with GetSwitchOrderResponseDataTime" + GetSwitchOrderResponseDataTime + "and IncomingCreationDateTimeUTC " + IncomingCreationDateTimeUTC);
				}
			} else {
				var ctx = session.name("SOM") || session.createContext("SOM");
				var TicketId = ctx.getVar("TICKETID");
				var responsemessage = "500 Workflow/Status field value is empty";
				var np_statusmemo = responsemessage.slice(0, 99);
				var orderType = ctx.getVar("CLASSIFICATIONID");
				var PayloadAddon = {

					"maximoID": TicketId,
					"timeStamp": IncomingCreationDateTime,
					"orderType": orderType,
					"orderStatus": toState,
					"messageID": messageId,
					"somID": somID

				}
				var MaximoNegativeUpdateResponsePayload = {
					"ticketid": TicketId,
					"status": "NegativeAcknowledge",
					"np_statusmemo": np_statusmemo,
					"esbData": PayloadAddon
				}

				ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
				ctx.setVar("LookupMaximoResponse", 'yes');
				//start calling maximoResponsecall api
				var Queueurl = session.parameters.BackendMQurl;
				logger.error("SOM_AM_009 500 Workflow/Status field value is empty");
				var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);

			}
		} else if (GetSwitchOrderUpdateStatus != 'Updateoperation') {
			var DTE_Reason_Reject_val = ctx.getVar("DTE_Reason_Reject");
			var isANumber = isNaN(DTE_Reason_Reject_val) == false;
			if (DTE_Reason_Reject_val.length > 0 && (DTE_Reason_Reject_val !== undefined || DTE_Reason_Reject_val !== '' || DTE_Reason_Reject_val !== null) && (isANumber == false)) {
				var DTE_Reason_Reject_Lookup_Payload = {
					"lookupReq": {
						"type": [
							{
								"name": "switchOrderDescription",
								"label": DTE_Reason_Reject_val
							}
						]
					}
				}

				var url = session.parameters.lookupUrl;;
				//var test = DTE_Reason_Reject_Lookup(url, DTE_Reason_Reject_Lookup_Payload);

				var LookupServiceResponse = {
					target: url,
					method: 'POST',
					contentType: 'application/json',
					data: DTE_Reason_Reject_Lookup_Payload
				};
				var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'LookUp DTE_Reason_Reject_Lookup_Payload', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ErrorDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'LookUp DTE_Reason_Reject_Lookup_Payload', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDescription', ExitDescription);
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from LookupServiceResponse for DTE_Reason_Reject_Lookup_Payload " + responseStatusCode);
									var lookupResponse = JSON.parse(responseData);
									if (lookupResponse.lookupRep.type[0].result == 0) {

										var DTE_Reason_Reject = lookupResponse.lookupRep.type[0].status;
										var ctx = session.name("SOM") || session.createContext("SOM");
										ctx.setVariable("DTE_Reason_Reject", DTE_Reason_Reject);
										var label = ctx.getVar("CLASSIFICATIONID");

										var lookupMessage = {
											"lookupReq": {
												"type": [
													{
														"name": "switchOrderTypes",
														"label": label
													}
												]
											}
										}
										var url = session.parameters.lookupUrl;
										var LookupServiceResponse = {
											target: url,
											method: 'POST',
											contentType: 'application/json',
											data: lookupMessage
										};
										var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												var errorinfo = "url connection error 'LookUp switchOrderTypes', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error reading response 'LookUp switchOrderTypes', details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', responseStatusCode);
															ILSctx.setVariable('ErrorDescription', errorinfo);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															ILSctx.setVariable('ExitStatus', '0');
															ILSctx.setVariable('ExitDescription', ExitDescription);
															hm.response.statusCode = responseStatusCode;
															logger.debug("response received from LookupServiceResponse for switchOrderTypeObjectID " + responseStatusCode);
															var lookupResponse = JSON.parse(responseData);
															if (lookupResponse.lookupRep.type[0].result == 0) {
																var switchOrderTypeObjectID = lookupResponse.lookupRep.type[0].id;
																var ctx = session.name("SOM") || session.createContext("SOM");
																ctx.setVariable("switchOrderTypeObjectID", switchOrderTypeObjectID);

																var ctx = session.name("SOM") || session.createContext("SOM");
																var Incoming_DESCRIPTION = ctx.getVar('DESCRIPTION');
																var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																//Incoming_DTE_WORKLOCATION
																if (Incoming_DESCRIPTION === undefined || Incoming_DESCRIPTION === null || Incoming_DESCRIPTION === '') {
																	var CharacterOfWorkSelection_DESCRIPTION = '';
																	var ctx = session.name("SOM") || session.createContext("SOM");
																	ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																	var ctx = session.name("SOM") || session.createContext("SOM");
																	var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																	//Incoming_DTE_WORKLOCATION
																	if (Incoming_DTE_WORKLOCATION === undefined || Incoming_DTE_WORKLOCATION === null || Incoming_DTE_WORKLOCATION === '') {
																		var Responsible_Service_Center_DTE_WORKLOCATION = '';
																		var ctx = session.name("SOM") || session.createContext("SOM");
																		ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																	} else {
																		var lookupMessage = {
																			"lookupReq": {
																				"type": [
																					{
																						"name": "switchOrderDescription",
																						"label": Incoming_DTE_WORKLOCATION
																					}]
																			}
																		}
																		var url = session.parameters.lookupUrl;
																		var LookupServiceResponse = {
																			target: url,
																			method: 'POST',
																			contentType: 'application/json',
																			data: lookupMessage
																		};
																		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

																		urlopen.open(LookupServiceResponse, function(error, response) {
																			if (error) {
																				var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus', '500');
																				ILSctx.setVariable('ErrorDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var responseStatusCode = response.statusCode;
																				if (responseStatusCode == 200) {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('ExitStatus', responseStatusCode);
																							ILSctx.setVariable('ErrorDescription', errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							hm.response.statusCode = responseStatusCode;
																							var lookupResponse = JSON.parse(responseData);
																							//	var toStateID_LookupUpdate;	
																							if (lookupResponse.lookupRep.type[0].result == 0) {
																								var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																								var ctx = session.name("SOM") || session.createContext("SOM");
																								ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																							} else {

																								//logger.error("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																								//session.reject("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																								var ctx = session.name("SOM") || session.createContext("SOM");
																								var TicketId = ctx.getVar("TICKETID");
																								var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																								
																								var orderType = ctx.getVar("CLASSIFICATIONID");
																								var PayloadAddon = {

																									"maximoID": TicketId,
																									"timeStamp": IncomingCreationDateTime,
																									"orderType": orderType,
																									"orderStatus": toState,
																									"messageID": messageId,
																									"somID": somID

																								}
																								var np_statusmemo = responsemessage.slice(0, 99);
																								var MaximoNegativeUpdateResponsePayload = {
																									"ticketid": TicketId,
																									"status": "NegativeAcknowledge",
																									"np_statusmemo": np_statusmemo,
																									"esbData": PayloadAddon
																								}

																								ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																								ctx.setVar("LookupMaximoResponse", 'yes');
																								//start calling maximoResponsecall api
																								var Queueurl = session.parameters.BackendMQurl;
																								var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																							}
																						}
																					});
																				} else {
																					//Added readAsBuffer 21
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('ExitStatus', responseStatusCode);
																							ILSctx.setVariable('ErrorDescription', errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																							ILSctx.setVariable('ExitStatus', responseStatusCode);
																							ILSctx.setVariable('ErrorDescription', errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						}
																					})
																				}
																			}
																		});
																	}
																} else {
																	var lookupMessage = {
																		"lookupReq": {
																			"type": [
																				{
																					"name": "switchOrderDescription",
																					"label": Incoming_DESCRIPTION
																				}]
																		}
																	}
																	var url = session.parameters.lookupUrl;
																	var LookupServiceResponse = {
																		target: url,
																		method: 'POST',
																		contentType: 'application/json',
																		data: lookupMessage
																	};
																	var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																	urlopen.open(LookupServiceResponse, function(error, response) {
																		if (error) {
																			var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', '500');
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						ILSctx.setVariable('ExitStatus', '0');
																						ILSctx.setVariable('ExitDescription', ExitDescription);
																						hm.response.statusCode = responseStatusCode;
																						//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																						var lookupResponse = JSON.parse(responseData);
																						//	var toStateID_LookupUpdate;	
																						if (lookupResponse.lookupRep.type[0].result == 0) {
																							var CharacterOfWorkSelection_DESCRIPTION = lookupResponse.lookupRep.type[0].status;
																							var ctx = session.name("SOM") || session.createContext("SOM");
																							ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																						} else {
																							//logger.error("Result is not 0 for lookup Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																							//session.reject("Result is not 0 for lookup Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																							var ctx = session.name("SOM") || session.createContext("SOM");
																							var TicketId = ctx.getVar("TICKETID");
																							var responsemessage = "500 Lookup Response for given DESCRIPTION/Character_Of_Work_Selection field value is invalid";
																						
																							var orderType = ctx.getVar("CLASSIFICATIONID");
																							var PayloadAddon = {

																								"maximoID": TicketId,
																								"timeStamp": IncomingCreationDateTime,
																								"orderType": orderType,
																								"orderStatus": toState,
																								"messageID": messageId,
																								"somID": somID

																							}
																							var np_statusmemo = responsemessage.slice(0, 99);
																							var MaximoNegativeUpdateResponsePayload = {
																								"ticketid": TicketId,
																								"status": "NegativeAcknowledge",
																								"np_statusmemo": np_statusmemo,
																								"esbData": PayloadAddon
																							}

																							ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																							ctx.setVar("LookupMaximoResponse", 'yes');
																							//start calling maximoResponsecall api
																							var Queueurl = session.parameters.BackendMQurl;
																							var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																						}

																						var ctx = session.name("SOM") || session.createContext("SOM");
																						var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																						//Incoming_DTE_WORKLOCATION
																						if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {

																							var Responsible_Service_Center_DTE_WORKLOCATION = '';
																							var ctx = session.name("SOM") || session.createContext("SOM");
																							ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																						} else {
																							var lookupMessage = {
																								"lookupReq": {
																									"type": [
																										{
																											"name": "switchOrderDescription",
																											"label": Incoming_DTE_WORKLOCATION
																										}]
																								}
																							}
																							var url = session.parameters.lookupUrl;
																							var LookupServiceResponse = {
																								target: url,
																								method: 'POST',
																								contentType: 'application/json',
																								data: lookupMessage
																							};
																							var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
																							urlopen.open(LookupServiceResponse, function(error, response) {
																								if (error) {
																									var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																									ILSctx.setVariable('ExitStatus', '500');
																									ILSctx.setVariable('ErrorDescription', errorinfo);
																									logger.error(errorinfo);
																									session.reject(errorinfo);
																								} else {
																									var responseStatusCode = response.statusCode;
																									if (responseStatusCode == 200) {
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																												ILSctx.setVariable('ExitStatus', responseStatusCode);
																												ILSctx.setVariable('ErrorDescription', errorinfo);
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											} else {
																												ILSctx.setVariable('ExitStatus', '0');
																												ILSctx.setVariable('ExitDescription', ExitDescription);
																												hm.response.statusCode = responseStatusCode;
																												//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																												var lookupResponse = JSON.parse(responseData);
																												//	var toStateID_LookupUpdate;	
																												if (lookupResponse.lookupRep.type[0].result == 0) {
																													var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																													var ctx = session.name("SOM") || session.createContext("SOM");
																													ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																												} else {
																													//logger.error("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																													//session.reject("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																													var ctx = session.name("SOM") || session.createContext("SOM");
																													var TicketId = ctx.getVar("TICKETID");
																													var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																												
																													var orderType = ctx.getVar("CLASSIFICATIONID");
																													var PayloadAddon = {

																														"maximoID": TicketId,
																														"timeStamp": IncomingCreationDateTime,
																														"orderType": orderType,
																														"orderStatus": toState,
																														"messageID": messageId,
																														"somID": somID

																													}
																													var np_statusmemo = responsemessage.slice(0, 99);
																													var MaximoNegativeUpdateResponsePayload = {
																														"ticketid": TicketId,
																														"status": "NegativeAcknowledge",
																														"np_statusmemo": np_statusmemo,
																														"esbData": PayloadAddon
																													}

																													ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																													ctx.setVar("LookupMaximoResponse", 'yes');
																													//start calling maximoResponsecall api
																													var Queueurl = session.parameters.BackendMQurl;
																													var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);

																												}
																											}
																										});
																									} else {
																										//Added readAsBuffer 23
																										response.readAsBuffer(function(error, responseData) {
																											if (error) {
																												var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																												ILSctx.setVariable('ExitStatus', responseStatusCode);
																												ILSctx.setVariable('ErrorDescription', errorinfo);
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											} else {
																												var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																												ILSctx.setVariable('ExitStatus', responseStatusCode);
																												ILSctx.setVariable('ErrorDescription', errorinfo);
																												logger.error(errorinfo);
																												session.reject(errorinfo);
																											}
																										})
																									}
																								}
																							});
																						}

																					}
																				});
																			} else {
																				//Added readAsBuffer 22
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "error response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					}
																				})
																			}
																		}
																	});
																}
															} else {
																//need to check  what should be done at this case should we log and leave it or any message need to be passed switchordertypeobject
																//			logger.error("Result 1 for switchOrderTypes lookup for label "+label);
																//			session.reject("Result is not 0 for lookup for label"+label);
																var ctx = session.name("SOM") || session.createContext("SOM");
																var TicketId = ctx.getVar("TICKETID");
																var responsemessage = "500 Lookup Response for given CLASSIFICATIONID/switchOrderTypeObjectID field value is invalid";
																
																var orderType = ctx.getVar("CLASSIFICATIONID");
																var PayloadAddon = {

																	"maximoID": TicketId,
																	"timeStamp": IncomingCreationDateTime,
																	"orderType": orderType,
																	"orderStatus": toState,
																	"messageID": messageId,
																	"somID": somID

																}
																var np_statusmemo = responsemessage.slice(0, 99);
																var MaximoNegativeUpdateResponsePayload = {
																	"ticketid": TicketId,
																	"status": "NegativeAcknowledge",
																	"np_statusmemo": np_statusmemo,
																	"esbData": PayloadAddon
																}

																ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																ctx.setVar("LookupMaximoResponse", 'yes');
																//start calling maximoResponsecall api
																var Queueurl = session.parameters.BackendMQurl;
																var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
															}
														}
													});
												} else {
													//Added readAsBuffer 20
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error reading response 'LookUp switchOrderTypes', details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', responseStatusCode);
															ILSctx.setVariable('ErrorDescription', errorinfo);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															var errorinfo = "error response 'LookUp switchOrderTypes', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
															ILSctx.setVariable('ExitStatus', responseStatusCode);
															ILSctx.setVariable('ErrorDescription', errorinfo);
															logger.error(errorinfo);
															session.reject(errorinfo);
														}
													})
												}
											}
										});
									} else {
										var invalidresp = "Invalid Lookup Request 'LookUp DTE_Reason_Reject_Lookup_Payload', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', '1');
										ILSctx.setVariable('ErrorDescription', invalidresp);
										logger.error(invalidresp)
										var ctx = session.name("SOM") || session.createContext("SOM");
										var DTE_Reason_Reject_val = ctx.getVar("DTE_Reason_Reject");
										var TicketId = ctx.getVar("TICKETID");
										var responsemessage = "500 Lookup Response for given DTE_REASON_REJECT/Reason_For_Action field value is invalid";
										//	session.reject("response received from LookupServiceResponse for DTE_Reason_Reject_Lookup_Payload for label "+DTE_Reason_Reject_val+" is result 1");
										var np_statusmemo = responsemessage.slice(0, 99);
										var orderType = ctx.getVar("CLASSIFICATIONID");
										var PayloadAddon = {

											"maximoID": TicketId,
											"timeStamp": IncomingCreationDateTime,
											"orderType": orderType,
											"orderStatus": toState,
											"messageID": messageId,
											"somID": somID

										}
										var MaximoNegativeUpdateResponsePayload = {
											"ticketid": TicketId,
											"status": "NegativeAcknowledge",
											"np_statusmemo": np_statusmemo,
											"esbData": PayloadAddon
										}

										ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
										ctx.setVar("LookupMaximoResponse", 'yes');
										//start calling maximoResponsecall api
										var Queueurl = session.parameters.BackendMQurl;
										var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);

									}
								}
							});
						} else {
							//Added readAsBuffer 19
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'LookUp DTE_Reason_Reject_Lookup_Payload', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error response 'LookUp DTE_Reason_Reject_Lookup_Payload', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							})
						}
					}
				});
			} else {
				var label = ctx.getVar("CLASSIFICATIONID");
				var lookupMessage = {
					"lookupReq": {
						"type": [
							{
								"name": "switchOrderTypes",
								"label": label
							}
						]
					}
				}
				var url = session.parameters.lookupUrl;
				var LookupServiceResponse = {
					target: url,
					method: 'POST',
					contentType: 'application/json',
					data: lookupMessage
				};
				var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'LookUp switchOrderTypes', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ErrorDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'LookUp switchOrderTypes', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDescription', ExitDescription);
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from LookupServiceResponse for switchOrderTypeObjectID " + responseStatusCode);
									var lookupResponse = JSON.parse(responseData);
									//325
									if (lookupResponse.lookupRep.type[0].result == 0) {
										var switchOrderTypeObjectID = lookupResponse.lookupRep.type[0].id;
										var ctx = session.name("SOM") || session.createContext("SOM");
										ctx.setVariable("switchOrderTypeObjectID", switchOrderTypeObjectID);

										var ctx = session.name("SOM") || session.createContext("SOM");
										var Incoming_DESCRIPTION = ctx.getVar('DESCRIPTION');
										var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
										//Incoming_DTE_WORKLOCATION
										if (Incoming_DESCRIPTION == undefined || Incoming_DESCRIPTION == null || Incoming_DESCRIPTION == '') {
											var CharacterOfWorkSelection_DESCRIPTION = '';
											var ctx = session.name("SOM") || session.createContext("SOM");
											ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
											var ctx = session.name("SOM") || session.createContext("SOM");
											var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
											//Incoming_DTE_WORKLOCATION
											if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {
												var Responsible_Service_Center_DTE_WORKLOCATION = '';
												var ctx = session.name("SOM") || session.createContext("SOM");
												ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
											} else {

												var lookupMessage = {
													"lookupReq": {
														"type": [
															{
																"name": "switchOrderDescription",
																"label": Incoming_DTE_WORKLOCATION
															}]
													}
												}
												var url = session.parameters.lookupUrl;
												var LookupServiceResponse = {
													target: url,
													method: 'POST',
													contentType: 'application/json',
													data: lookupMessage
												};
												var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

												urlopen.open(LookupServiceResponse, function(error, response) {
													if (error) {
														var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('ErrorDescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														var responseStatusCode = response.statusCode;
														if (responseStatusCode == 200) {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																	ILSctx.setVariable('ErrorDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	hm.response.statusCode = responseStatusCode;
																	var lookupResponse = JSON.parse(responseData);
																	//	var toStateID_LookupUpdate;	
																	if (lookupResponse.lookupRep.type[0].result == 0) {
																		var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																		var ctx = session.name("SOM") || session.createContext("SOM");
																		ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																	} else {

																		//logger.error("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																		//session.reject("Result is not 0 for lookup for Incoming_DTE_WORKLOCATION" +Incoming_DTE_WORKLOCATION);
																		var ctx = session.name("SOM") || session.createContext("SOM");
																		var TicketId = ctx.getVar("TICKETID");
																		var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																		
																		var orderType = ctx.getVar("CLASSIFICATIONID");
																		var PayloadAddon = {

																			"maximoID": TicketId,
																			"timeStamp": IncomingCreationDateTime,
																			"orderType": orderType,
																			"orderStatus": toState,
																			"messageID": messageId,
																			"somID": somID

																		}
																		var np_statusmemo = responsemessage.slice(0, 99);
																		var MaximoNegativeUpdateResponsePayload = {
																			"ticketid": TicketId,
																			"status": "NegativeAcknowledge",
																			"np_statusmemo": np_statusmemo,
																			"esbData": PayloadAddon

																		}

																		ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																		ctx.setVar("LookupMaximoResponse", 'yes');
																		//start calling maximoResponsecall api
																		var Queueurl = session.parameters.BackendMQurl;
																		var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																	}
																}
															});
														} else {
															//Added readAsBuffer 24
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus',responseStatusCode);
																	ILSctx.setVariable('ErrorDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	ILSctx.setVariable('ExitStatus',responseStatusCode);
																	ILSctx.setVariable('ErrorDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
															})
														}
													}
												});
											}
										} else {
											var lookupMessage = {
												"lookupReq": {
													"type": [
														{
															"name": "switchOrderDescription",
															"label": Incoming_DESCRIPTION
														}]
												}
											}
											var url = session.parameters.lookupUrl;
											var LookupServiceResponse = {
												target: url,
												method: 'POST',
												contentType: 'application/json',
												data: lookupMessage
											};
											var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

											urlopen.open(LookupServiceResponse, function(error, response) {
												if (error) {
													var errorinfo = "url connection error 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ErrorDescription', errorinfo);
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', responseStatusCode);
																ILSctx.setVariable('ErrorDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																ILSctx.setVariable('ExitStatus', '0');
																ILSctx.setVariable('ExitDescription', ExitDescription);
																hm.response.statusCode = responseStatusCode;
																//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																var lookupResponse = JSON.parse(responseData);
																//	var toStateID_LookupUpdate;	
																if (lookupResponse.lookupRep.type[0].result == 0) {
																	var CharacterOfWorkSelection_DESCRIPTION = lookupResponse.lookupRep.type[0].status;
																	var ctx = session.name("SOM") || session.createContext("SOM");
																	ctx.setVariable("CharacterOfWorkSelection_DESCRIPTION", CharacterOfWorkSelection_DESCRIPTION);
																} else {

																	//logger.error("Result is not 0 for lookup Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																	//session.reject("Result is not 0 for lookup Incoming_DESCRIPTION "+Incoming_DESCRIPTION);
																	var ctx = session.name("SOM") || session.createContext("SOM");
																	var TicketId = ctx.getVar("TICKETID");
																	var responsemessage = "500 Lookup Response for given DESCRIPTION/Character_Of_Work_Selection field value is invalid";
																	
																	var orderType = ctx.getVar("CLASSIFICATIONID");
																	var PayloadAddon = {

																		"maximoID": TicketId,
																		"timeStamp": IncomingCreationDateTime,
																		"orderType": orderType,
																		"orderStatus": toState,
																		"messageID": messageId,
																		"somID": somID

																	}
																	var np_statusmemo = responsemessage.slice(0, 99);
																	var MaximoNegativeUpdateResponsePayload = {
																		"ticketid": TicketId,
																		"status": "NegativeAcknowledge",
																		"np_statusmemo": np_statusmemo,
																		"esbData": PayloadAddon
																	}

																	ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																	ctx.setVar("LookupMaximoResponse", 'yes');
																	//start calling maximoResponsecall api
																	var Queueurl = session.parameters.BackendMQurl;
																	var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																}

																var ctx = session.name("SOM") || session.createContext("SOM");
																var Incoming_DTE_WORKLOCATION = ctx.getVar('DTE_WORKLOCATION');
																//Incoming_DTE_WORKLOCATION
																if (Incoming_DTE_WORKLOCATION == undefined || Incoming_DTE_WORKLOCATION == null || Incoming_DTE_WORKLOCATION == '') {
																	var Responsible_Service_Center_DTE_WORKLOCATION = '';
																	var ctx = session.name("SOM") || session.createContext("SOM");
																	ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																} else {
																	var lookupMessage = {
																		"lookupReq": {
																			"type": [
																				{
																					"name": "switchOrderDescription",
																					"label": Incoming_DTE_WORKLOCATION
																				}]
																		}
																	}
																	var url = session.parameters.lookupUrl;
																	var LookupServiceResponse = {
																		target: url,
																		method: 'POST',
																		contentType: 'application/json',
																		data: lookupMessage
																	};
																	var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";

																	urlopen.open(LookupServiceResponse, function(error, response) {
																		if (error) {
																			var errorinfo = "url connection error 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', '500');
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						ILSctx.setVariable('ExitStatus', '0');
																						ILSctx.setVariable('ExitDescription', ExitDescription);
																						hm.response.statusCode = responseStatusCode;
																						//logger.debug("response received from LookupServiceResponse for switchOrderWorkFlowID "+ switchOrderWorkFlowID);			
																						var lookupResponse = JSON.parse(responseData);
																						//	var toStateID_LookupUpdate;	
																						if (lookupResponse.lookupRep.type[0].result == 0) {
																							var Responsible_Service_Center_DTE_WORKLOCATION = lookupResponse.lookupRep.type[0].status;
																							var ctx = session.name("SOM") || session.createContext("SOM");
																							ctx.setVariable("Responsible_Service_Center_DTE_WORKLOCATION", Responsible_Service_Center_DTE_WORKLOCATION);
																						} else {
																							var ctx = session.name("SOM") || session.createContext("SOM");
																							var TicketId = ctx.getVar("TICKETID");
																							var responsemessage = "500 Lookup Response for given DTE_WORKLOCATION/Responsible_Service_Center field value is invalid";
																							var messageId = ctxSeq.getVariable("messageId");
																							var orderType = ctx.getVar("CLASSIFICATIONID");
																							var PayloadAddon = {

																								"maximoID": TicketId,
																								"timeStamp": IncomingCreationDateTime,
																								"orderType": orderType,
																								"orderStatus": toState,
																								"messageID": messageId,
																								"somID": somID

																							}
																							var np_statusmemo = responsemessage.slice(0, 99);
																							var MaximoNegativeUpdateResponsePayload = {
																								"ticketid": TicketId,
																								"status": "NegativeAcknowledge",
																								"np_statusmemo": np_statusmemo,
																								"esbData": PayloadAddon
																							}

																							ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																							ctx.setVar("LookupMaximoResponse", 'yes');
																							//start calling maximoResponsecall api
																							var Queueurl = session.parameters.BackendMQurl;
																							var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																						}
																					}
																				});
																			} else {
																				//Added readAsBuffer 26
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error reading response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "error response 'LookUp Incoming_DTE_WORKLOCATION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ErrorDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					}
																				})
																			}
																		}
																	});
																}
															}
														});
													} else {
														//Added readAsBuffer 25
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', responseStatusCode);
																ILSctx.setVariable('ErrorDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var errorinfo = "error response 'LookUp Incoming_DESCRIPTION', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																ILSctx.setVariable('ExitStatus', responseStatusCode);
																ILSctx.setVariable('ErrorDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															}
														})
													}
												}
											});
										}
									} else {
										var invalidresp = "Invalid Lookup Request 'LookUp switchOrderTypes', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', '1');
										ILSctx.setVariable('ErrorDescription', invalidresp);
										logger.error(invalidresp)
										//need to check  what should be done at this case should we log and leave it or any message need to be passed switchordertypeobject
										//			logger.error("Result 1 for switchOrderTypes lookup for label "+label);
										//			session.reject("Result is not 0 for lookup for label"+label);
										var ctx = session.name("SOM") || session.createContext("SOM");
										var TicketId = ctx.getVar("TICKETID");
										var responsemessage = "500 Lookup Response for given CLASSIFICATIONID/switchOrderTypeObjectID field value is invalid";
										
										var orderType = ctx.getVar("CLASSIFICATIONID");
										var PayloadAddon = {

											"maximoID": TicketId,
											"timeStamp": IncomingCreationDateTime,
											"orderType": orderType,
											"orderStatus": toState,
											"messageID": messageId,
											"somID": somID

										}
										var np_statusmemo = responsemessage.slice(0, 99);
										var MaximoNegativeUpdateResponsePayload = {
											"ticketid": TicketId,
											"status": "NegativeAcknowledge",
											"np_statusmemo": np_statusmemo,
											"esbData": PayloadAddon
										}

										ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
										ctx.setVar("LookupMaximoResponse", 'yes');
										//start calling maximoResponsecall api
										var Queueurl = session.parameters.BackendMQurl;
										var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
									}
								}
							});
						} else {
							//Added readAsBuffer 23
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'LookUp switchOrderTypes', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error response 'LookUp switchOrderTypes', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ErrorDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							})
						}
					}
				});
			}
		}
		function maximoResponsecall(url, Data) {
			var ctx = session.name("SOM") || session.createContext("SOM");
			var StandaloneMQurl = url;
			var payload = Data;
			var MaximoResponseApi = {
				target: StandaloneMQurl,
				data: payload
			};
			var info = " TargetURL: " + MaximoResponseApi.target + "; Data: " + JSON.stringify(MaximoResponseApi.data) + ". ";
			try {
				urlopen.open(MaximoResponseApi, function(error, response) {
					var hm = require('header-metadata');
					if (error) {
						var errorinfo = "url connection error 'MaximoResponseApi', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ErrorDescription', errorinfo);
						logger.error(errorinfo);
						var ctx = session.name("SOM") || session.createContext("SOM");
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						session.reject(errorinfo);
					} else {
						var mqrc = response.statusCode;
						if (mqrc == 0) {
							var replyMQMD = response.get({
								type: 'mq'
							}, 'MQMD');
							var replyMQRFH2 = response.get({
								type: 'mq'
							}, 'MQRFH2');
							response.readAsBuffer(function(readError, responseData) {
								if (readError) {
									var errorinfo = "error reading response 'MaximoResponseApi', details are : " + info + "; error info :" + readError
									hm.response.statusCode = 500
									ILSctx.setVariable('ExitStatus', mqrc);
									ILSctx.setVariable('ErrorDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('StepExitDescription', MaximoResponseExitDescription);
									ILSctx.setVariable('exitDestination', MaximoResponseApi.target);
									ms.callRule('SOM_AMCreateUpdateSwitchOrder_Processing_Policy_StepExit', null, null, function(error) {
										if (error) {
										}
									});
									logger.debug("MQResponsecode " + mqrc);
								}
							});
						} else {
							var errorinfo = "error response 'MaximoResponseApi', details are : " + info + "; response info :" + JSON.stringify(response) + "; ResponseStatusCode :" + mqrc
							ILSctx.setVariable('ExitStatus', mqrc);
							ILSctx.setVariable('ErrorDescription', errorinfo);
							logger.error(errorinfo);
							var ctx = session.name("SOM") || session.createContext("SOM");
							var mqconnection = 'Forbidden';
							ctx.setVariable("mqconnection", mqconnection);
							session.reject(errorinfo);
						}
					}
				});
			} catch (err) {
				var errorinfo = "url connection error 'MaximoResponseApi', details are : " + info + "; error info :" + err
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo);
				logger.error(errorinfo);
				var ctx = session.name("SOM") || session.createContext("SOM");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				session.reject(errorinfo);
			}
		}
	}
} 
