var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("SOM") || session.createContext("SOM");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ExitDescription = session.parameters.ExitDescription;
var MaximoResponseExitDescription = session.parameters.MaximoResponseExitDescription;
var SeqconfExitDescription = session.parameters.SeqconfExitDescription;
var omsExternalURL = session.parameters.omsExternalURL;
var Queueurl = session.parameters.BackendMQurl;
var toState = ctx.getVariable("toState");
//var identifier = ctx.getVariable("identifier");


var label = ctx.getVariable("label");
if (ctx.getVariable("label") === undefined || ctx.getVariable("label") === null || ctx.getVariable("label") === '') {
	label = "";
	ILSctx.setVariable("label", "")
}
else {
	label = ctx.getVariable("label")
	ILSctx.setVariable("label", ctx.getVariable("label"))
}
var somID = ctx.getVariable("DTE_EXTERNALID2");
if (ctx.getVariable("DTE_EXTERNALID2") === undefined || ctx.getVariable("DTE_EXTERNALID2") === null || ctx.getVariable("DTE_EXTERNALID2") === '') {
	somID = "";
	ILSctx.setVariable("somID", "")
}
else {
	somID = ctx.getVariable("DTE_EXTERNALID2")
	ILSctx.setVariable("somID", ctx.getVariable("DTE_EXTERNALID2"))
}

var ctxSeq = session.name("SOM_CreateUpdate_seq") || session.createContext("SOM_CreateUpdate_seq");
/*var SeqConfirmation = session.parameters.SeqConfirmationURL;
var messageId = ctxSeq.getVariable("messageId");
var eventType = ctxSeq.getVariable("eventType");
var serviceName = ctxSeq.getVariable("serviceName");
var dateTime = new Date();
var sendTimeStamp = dateTime.toISOString();
var eventContext = ctxSeq.getVariable("eventContext");
var EventTimeStamp = ctxSeq.getVariable("EventTimeStamp");
Sequance Confirmation req 
					
								var seqResponse ={
									"messageId" : messageId,
									"eventType" : eventType,
									"serviceName" : serviceName,
										"sendTimeStamp" : sendTimeStamp
								}
								if(eventContext != undefined || eventContext != null || eventContext != ''){
								seqResponse.eventContext = eventContext	
								}
								if(EventTimeStamp != undefined || EventTimeStamp != null || EventTimeStamp != ''){
								seqResponse.EventTimeStamp = EventTimeStamp	
								}*/

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		var ctx = session.name("SOM") || session.createContext("SOM");
		var checkretry = ctx.getVar("retry");
		var LookupMaximoResponse = ctx.getVar("LookupMaximoResponse");
		session.output.write(incomingdata)
		if (LookupMaximoResponse != 'yes') {
			if (checkretry != 'yes') {
				var ctx = session.name("SOM") || session.createContext("SOM");
				var GetSwitchOrderResponseCode = ctx.getVar("GetSwitchOrderResponseCode");
				var GetSwitchOrderUpdateStatus = ctx.getVar("GetSwitchOrderUpdateStatus");
				if (GetSwitchOrderResponseCode == '200') {
					var GetSwitchOrderResponseData = JSON.parse(ctx.getVar("GetSwitchOrderResponseData"));
					ctx.setVar("GetSwitchOrderResponseDataJsonPayload", GetSwitchOrderResponseData);
				}
				if (GetSwitchOrderUpdateStatus != 'Updateoperation') {
					var CLASSIFICATIONID = ctx.getVar("CLASSIFICATIONID");
					var payload;
					var Work_Order_Status = undefined;
					var Work_Order_Number = undefined;
					var Work_Order_Summary = undefined;
					var Memo_Detail = undefined;
					var Memo_Date = undefined;
					if (incomingdata.switchOrder.customTableValues.Maximo_Work_Orders) {
						Work_Order_Status = incomingdata.switchOrder.customTableValues.Maximo_Work_Orders;
						Work_Order_Number = incomingdata.switchOrder.customTableValues.Maximo_Work_Orders;
						Work_Order_Summary = incomingdata.switchOrder.customTableValues.Maximo_Work_Orders;
					}


					var Memo_Detail = undefined;
					var Memo_Date = undefined;
					if (incomingdata.switchOrder.customTableValues.Maximo_Related_Logs == undefined) {
					} else {
						if (incomingdata.switchOrder.customTableValues.Maximo_Related_Logs != undefined) {
							if (incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date !== undefined && incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Detail !== undefined) {
								Memo_Detail = incomingdata.switchOrder.customTableValues.Maximo_Related_Logs;
								Memo_Date = incomingdata.switchOrder.customTableValues.Maximo_Related_Logs;
							}
							if (incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Detail !== undefined) {
								Memo_Detail = incomingdata.switchOrder.customTableValues.Maximo_Related_Logs;
							}
							if (incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date !== undefined) {
								Memo_Date = incomingdata.switchOrder.customTableValues.Maximo_Related_Logs;
							}
						}
					}

					var Maximo_Related_Logs;
					var Maximo_Work_Orders;
					if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'RECL') {
						if ((Work_Order_Status !== undefined || Work_Order_Number !== undefined || Work_Order_Summary !== undefined) && (Memo_Detail !== undefined || Memo_Date !== undefined)) {
							Maximo_Related_Logs = 'yes';
							Maximo_Work_Orders = 'yes';
							payload = {
								"switchOrder": {
									"customFieldValues": {},
									"customTableValues": {
										"Maximo_Related_Logs": [{

										}],
										"Maximo_Work_Orders": [
											{
												"Work_Order_Status": '',
												"Work_Order_Number": '',
												"Work_Order_Summary": ''
											}]
									}
								}
							}
						} else if ((Work_Order_Status !== undefined || Work_Order_Number !== undefined || Work_Order_Summary !== undefined) && (Memo_Detail == undefined || Memo_Date == undefined)) {
							Maximo_Work_Orders = 'yes';
							payload = {
								"switchOrder": {
									"customFieldValues": {},
									"customTableValues": {
										"Maximo_Work_Orders": [
											{
												"Work_Order_Status": '',
												"Work_Order_Number": '',
												"Work_Order_Summary": ''
											}]
									}
								}
							}
						} else if ((Work_Order_Status == undefined && Work_Order_Number == undefined && Work_Order_Summary == undefined) && (Memo_Detail == undefined && Memo_Date == undefined)) {
							payload = {
								"switchOrder": {
									"customFieldValues": {},
								}
							}
						} else if ((Work_Order_Status == undefined || Work_Order_Number == undefined || Work_Order_Summary == undefined) && (Memo_Detail !== undefined || Memo_Date !== undefined)) {
							Maximo_Related_Logs = 'yes';
							payload = {
								"switchOrder": {
									"customFieldValues": {},
									"customTableValues": {
										"Maximo_Related_Logs": [{

										}]
									}
								}
							}
						}

					}//RSD RECL
					else {
						//
						if (Work_Order_Status !== undefined || Work_Order_Number !== undefined || Work_Order_Summary !== undefined) {
							Maximo_Work_Orders = 'yes';
							payload = {
								"switchOrder": {
									"customFieldValues": {},
									"customTableValues": {
										"Maximo_Work_Orders": [{
											"Work_Order_Status": '',
											"Work_Order_Number": '',
											"Work_Order_Summary": ''
										}]
									}
								}
							}
						} else {
							payload = {
								"switchOrder": {
									"customFieldValues": {},
								}
							}

						}

						//
					}

					if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD' || CLASSIFICATIONID == 'RECL' || CLASSIFICATIONID == 'ETO') {
						if (incomingdata.switchOrder.customFieldValues.Updated_At === undefined || incomingdata.switchOrder.customFieldValues.Updated_At === '' || incomingdata.switchOrder.customFieldValues.Updated_At === null) {
							//payload.switchOrder.customFieldValues.Updated_At ='none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Updated_At);
							var Updated_AtDate = date.toISOString();
							var beforePlus = Updated_AtDate.split('.').shift();
							var updated_AtdateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Updated_At = updated_AtdateUTC;
						}

						/*var identifier = ctx.getVariable("identifier");
						logger.error(identifier);
												if(incomingdata.switchOrder.customFieldValues != undefined){
													if(incomingdata.switchOrder.customFieldValues.identifier != undefined){
														payload.switchOrder.customFieldValues.identifier = identifier;
													}
												}*/

						var Job_Status = incomingdata.switchOrder.customFieldValues.Job_Status;
						if (Job_Status === null || Job_Status === '') {
							payload.switchOrder.customFieldValues.Job_Status = null;
						} else { payload.switchOrder.customFieldValues.Job_Status = Job_Status; }
						if (!(CLASSIFICATIONID == 'TRSD')) {
							if (!(CLASSIFICATIONID == 'ETO')) {
								var officeNumber = incomingdata.switchOrder.officeNumber;
								if (officeNumber === null || officeNumber === '') {
									payload.switchOrder.officeNumber = null;
								} else { payload.switchOrder.officeNumber = officeNumber; }
							}
						}
						var Responsible_Organization = incomingdata.switchOrder.customFieldValues.Responsible_Organization;
						if (Responsible_Organization === null || Responsible_Organization === '') {
							payload.switchOrder.customFieldValues.Responsible_Organization = null;
						} else { payload.switchOrder.customFieldValues.Responsible_Organization = Responsible_Organization; }
						var Character_Of_Work_Description = incomingdata.switchOrder.customFieldValues.Character_Of_Work_Description;
						if (Character_Of_Work_Description === null || Character_Of_Work_Description === '') {
							payload.switchOrder.customFieldValues.Character_Of_Work_Description = null;
						} else { payload.switchOrder.customFieldValues.Character_Of_Work_Description = Character_Of_Work_Description; }
						var Character_Of_Work_Selection = incomingdata.switchOrder.customFieldValues.Character_Of_Work_Selection;
						if (Character_Of_Work_Selection === null || Character_Of_Work_Selection === '') {
							payload.switchOrder.customFieldValues.Character_Of_Work_Selection = null;
						} else { payload.switchOrder.customFieldValues.Character_Of_Work_Selection = Character_Of_Work_Selection; }
						var Maximo_Request_Number = incomingdata.switchOrder.customFieldValues.Maximo_Request_Number;
						if (Maximo_Request_Number === null || Maximo_Request_Number === '') {
							payload.switchOrder.customFieldValues.Maximo_Request_Number = null;
						} else { payload.switchOrder.customFieldValues.Maximo_Request_Number = Maximo_Request_Number; }
						var Voltage_Class = incomingdata.switchOrder.customFieldValues.Voltage_Class;
						if (Voltage_Class === null || Voltage_Class === '') {
							payload.switchOrder.customFieldValues.Voltage_Class = null;
						} else { payload.switchOrder.customFieldValues.Voltage_Class = Voltage_Class; }
						var switchOrderTypeObjectID = incomingdata.switchOrder.switchOrderTypeObjectID;
						if (switchOrderTypeObjectID === null || switchOrderTypeObjectID === '') {
							payload.switchOrder.switchOrderTypeObjectID = null;
						} else { payload.switchOrder.switchOrderTypeObjectID = switchOrderTypeObjectID; }
						var Desk_Assignment = incomingdata.switchOrder.customFieldValues.Desk_Assignment;
						if (Desk_Assignment === null || Desk_Assignment === '') {
							payload.switchOrder.customFieldValues.Desk_Assignment = null;
						} else { payload.switchOrder.customFieldValues.Desk_Assignment = Desk_Assignment; }
						var Desk_Assignment_Description = incomingdata.switchOrder.customFieldValues.Desk_Assignment_Description;
						if (Desk_Assignment_Description === null || Desk_Assignment_Description === '') {
							payload.switchOrder.customFieldValues.Desk_Assignment_Description = null;
						} else { payload.switchOrder.customFieldValues.Desk_Assignment_Description = Desk_Assignment_Description; }
						var Maximo_Reference_Requests = incomingdata.switchOrder.customFieldValues.Maximo_Reference_Requests;
						if (Maximo_Reference_Requests === null || Maximo_Reference_Requests === '') {
							payload.switchOrder.customFieldValues.Maximo_Reference_Requests = null;
						} else { payload.switchOrder.customFieldValues.Maximo_Reference_Requests = Maximo_Reference_Requests; }

						if (!(CLASSIFICATIONID == 'TRSD')) {
							if (!(CLASSIFICATIONID == 'ETO')) {
								//	logger.error("CLASSIFICATIONID "+CLASSIFICATIONID);
								var location = incomingdata.switchOrder.location;
								if (location === null || location === '') {
									payload.switchOrder.location = null;
								} else { payload.switchOrder.location = location; }
							}
						}
						var New_location = incomingdata.switchOrder.New_location;
						if (New_location === null || New_location === '') {
							payload.switchOrder.customFieldValues.Maximo_Location = null;
						} else { payload.switchOrder.customFieldValues.Maximo_Location = New_location; }


						if (Maximo_Work_Orders == 'yes') {
							var Maximo_Work_Orders_Incoming_Payload = incomingdata.switchOrder.customTableValues.Maximo_Work_Orders;
							var myarray = [];
							if (Maximo_Work_Orders_Incoming_Payload == undefined || Maximo_Work_Orders_Incoming_Payload === null || Maximo_Work_Orders_Incoming_Payload === '') {
							} else {
								var Maximo_Work_Orders_Incoming_Payload_length = incomingdata.switchOrder.customTableValues.Maximo_Work_Orders.length;
								for (var len = 0; len < Maximo_Work_Orders_Incoming_Payload_length; len++) {
									myarray.push(incomingdata.switchOrder.customTableValues.Maximo_Work_Orders[len]);
								}
								//myarray.push(Maximo_Work_Orders);
							}
							//myarray.push(Maximo_Work_Orders_Incoming_Payload);
							var Work_Order_Number = incomingdata.switchOrder.customTableValues.Maximo_Work_Orders;
							if (Work_Order_Number === null || Work_Order_Number === '') {
								payload.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Number = null;
							} else if (Work_Order_Number === undefined) {

							} else { payload.switchOrder.customTableValues.Maximo_Work_Orders = myarray; }

						}
						//				if(Maximo_Work_Orders == 'yes'){
						//				var Work_Order_Number= incomingdata.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Number;
						//			   if(Work_Order_Number === null || Work_Order_Number === ''){
						//				  payload.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Number=null;
						//				}else{payload.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Number= Work_Order_Number;}				
						//				var Work_Order_Summary= incomingdata.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Summary;
						//			   if(Work_Order_Summary === null || Work_Order_Summary === ''){
						//				  payload.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Summary=null;
						//				}else{payload.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Summary= Work_Order_Summary;}				
						//				var Work_Order_Status= incomingdata.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Status;
						//			   if(Work_Order_Status === null ||  Work_Order_Status === ''){
						//				  payload.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Status=null;
						//				}else{payload.switchOrder.customTableValues.Maximo_Work_Orders[0].Work_Order_Status= Work_Order_Status;}
						//							}	
						var Responsible_Service_Center = incomingdata.switchOrder.customFieldValues.Responsible_Service_Center;
						if (Responsible_Service_Center === null || Responsible_Service_Center === '') {
							payload.switchOrder.customFieldValues.Responsible_Service_Center = null;
						} else { payload.switchOrder.customFieldValues.Responsible_Service_Center = Responsible_Service_Center; }
						var Priority = incomingdata.switchOrder.customFieldValues.Priority;
						if (Priority === null || Priority === '') {
							// payload.switchOrder.customFieldValues.Priority='none';
						} else { payload.switchOrder.customFieldValues.Priority = Priority; }
						//Work_Start
						if (incomingdata.switchOrder.customFieldValues.Work_Start == undefined || incomingdata.switchOrder.customFieldValues.Work_Start == '' || incomingdata.switchOrder.customFieldValues.Work_Start == null) {
							//payload.switchOrder.customFieldValues.Work_Start = 'none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Work_Start);
							var Work_Startdate = date.toISOString();
							var beforePlus = Work_Startdate.split('.').shift();
							var Work_StartdateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Work_Start = Work_StartdateUTC;
						}


						/*var identifier = ctx.getVariable("identifier");
						
						if (identifier === null || identifier === '') {
							payload.customFieldValues.identifier = null;
						} else { 
							payload.switchOrder.customFieldValues.identifier = identifier; 
							}*/
						//Work_Start
						//Work_End
						if (incomingdata.switchOrder.customFieldValues.Work_End === undefined || incomingdata.switchOrder.customFieldValues.Work_End === '' || incomingdata.switchOrder.customFieldValues.Work_End === null) {
							//payload.switchOrder.customFieldValues.Work_End = 'none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Work_End);
							var Work_Enddate = date.toISOString();
							var beforePlus = Work_Enddate.split('.').shift();
							var Work_EnddateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Work_End = Work_EnddateUTC;
						}
						//Work_End
					}

					if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'RECL') {
						var Ready_To_Process = incomingdata.switchOrder.customFieldValues.Ready_To_Process;
						if (Ready_To_Process === null || Ready_To_Process === '') {
							payload.switchOrder.customFieldValues.Ready_To_Process = null;
						} else { payload.switchOrder.customFieldValues.Ready_To_Process = Ready_To_Process; }
						//		
						//		if(Maximo_Related_Logs == 'yes'){
						//				var Memo_Detail= incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Detail;
						//			   if(Memo_Detail === null ||  Memo_Detail === ''){
						//				  payload.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Detail=null;
						//				}else{payload.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Detail= Memo_Detail;}
						//				}
						var Interconnection = incomingdata.switchOrder.customFieldValues.Interconnection;
						if (Interconnection === null || Interconnection === '') {
							payload.switchOrder.customFieldValues.Interconnection = null;
						} else { payload.switchOrder.customFieldValues.Interconnection = Interconnection; }

						var Customer_Arrangements = incomingdata.switchOrder.customFieldValues.Customer_Arrangements;
						if (Customer_Arrangements === null || Customer_Arrangements === '') {
							payload.switchOrder.customFieldValues.Customer_Arrangements = null;
						} else { payload.switchOrder.customFieldValues.Customer_Arrangements = Customer_Arrangements; }

						var Prearranger_Name = incomingdata.switchOrder.customFieldValues.Prearranger_Name;
						if (Prearranger_Name === null || Prearranger_Name === '') {
							payload.switchOrder.customFieldValues.Prearranger_Name = null;
						} else { payload.switchOrder.customFieldValues.Prearranger_Name = Prearranger_Name; }

						var Request_Created_For = incomingdata.switchOrder.customFieldValues.Request_Created_For;
						if (Request_Created_For === null || Request_Created_For === '') {
							payload.switchOrder.customFieldValues.Request_Created_For = null;
						} else { payload.switchOrder.customFieldValues.Request_Created_For = Request_Created_For; }

						var Reason_For_Action = incomingdata.switchOrder.customFieldValues.Reason_For_Action;
						if (Reason_For_Action === 'null') {
							payload.switchOrder.customFieldValues.Reason_For_Action = null;
						} else { payload.switchOrder.customFieldValues.Reason_For_Action = Reason_For_Action; }

						var Provisional = incomingdata.switchOrder.customFieldValues.Provisional;
						if (Provisional === null || Provisional === '') {
							payload.switchOrder.customFieldValues.Provisional = null;
						} else { payload.switchOrder.customFieldValues.Provisional = Provisional; }
						//plannedStart
						if (incomingdata.switchOrder.plannedStart === null || incomingdata.switchOrder.plannedStart === undefined || incomingdata.switchOrder.plannedStart === '') {
							//payload.switchOrder.plannedStart = 'none';
						} else {
							const date = new Date(incomingdata.switchOrder.plannedStart);
							var plannedStartdate = date.toISOString();
							var beforePlus = plannedStartdate.split('.').shift();
							var plannedStartdateUTC = beforePlus + 'Z';
							payload.switchOrder.plannedStart = plannedStartdateUTC;
						}
						//plannedStart
						//plannedEnd
						if (incomingdata.switchOrder.plannedEnd === null || incomingdata.switchOrder.plannedEnd === undefined || incomingdata.switchOrder.plannedEnd === '') {
							//payload.switchOrder.plannedEnd = 'none';
						} else {
							const date = new Date(incomingdata.switchOrder.plannedEnd);
							var plannedEnddate = date.toISOString();
							var beforePlus = plannedEnddate.split('.').shift();
							var plannedEnddateUTC = beforePlus + 'Z';
							payload.switchOrder.plannedEnd = plannedEnddateUTC;
						}
						//plannedEnd
						//Memo_Date
						if (Maximo_Related_Logs == 'yes') {

							var Maximo_Related_Log = incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0];
							if (Maximo_Related_Log === null || Maximo_Related_Log === '') {
								payload.switchOrder.customeTables.Maximo_Work_Orders[0].Work_Order_Number = null;
							} else if (Maximo_Related_Log === undefined) {
							} else {
								var Maximo_Related_Logs_array = [];
								if (incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date === undefined || incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date === '' || incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date === null) {
									var incomingdata_Maximo_Related_Logs_length = incomingdata.switchOrder.customTableValues.Maximo_Related_Logs.length;
									var memoPayload;
									for (var len = 0; len < incomingdata_Maximo_Related_Logs_length; len++) {
										memoPayload = {
											"Memo_Detail": incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[len].Memo_Detail,
											//"Memo_Date":''
										}
										Maximo_Related_Logs_array.push(memoPayload);
									}
									//Maximo_Related_Logs_array.push(memoPayload);
									payload.switchOrder.customTableValues.Maximo_Related_Logs = Maximo_Related_Logs_array;
								} else {

									var incoming_Maximo_Relate_Log_Length = incomingdata.switchOrder.customTableValues.Maximo_Related_Logs.length;
									var memoPayload;
									for (var k = 0; k < incoming_Maximo_Relate_Log_Length; k++) {

										const date = new Date(incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[k].Memo_Date);
										var Memo_Date = date.toISOString();
										var beforePlus = Memo_Date.split('.').shift();
										var Memo_DateUTC = beforePlus + 'Z';
										memoPayload = {
											"Memo_Detail": incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[k].Memo_Detail,
											"Memo_Date": Memo_DateUTC
										}

										Maximo_Related_Logs_array.push(memoPayload);
									}
									payload.switchOrder.customTableValues.Maximo_Related_Logs = Maximo_Related_Logs_array;
								}
							}


							//			if(incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date === undefined || incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date ==='' || incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date ===null)
							//			{
							//				//payload.switchOrder.customeTables.Maximo_Related_Logs[0].Memo_Date ='none';
							//				}else{
							//			const date = new Date(incomingdata.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date);
							//			var Memo_Date = date.toISOString();
							//var beforePlus = Memo_Date.split('.').shift();
							//var Memo_DateUTC= beforePlus+'Z';
							//			payload.switchOrder.customTableValues.Maximo_Related_Logs[0].Memo_Date = Memo_DateUTC;
							//			}

						}
						//Memo_Date
					}
					if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD' || CLASSIFICATIONID == 'ETO') {
						var Job_Status_Details = incomingdata.switchOrder.customFieldValues.Job_Status_Details;
						if (Job_Status_Details === null || Job_Status_Details === '') {
							payload.switchOrder.customFieldValues.Job_Status_Details = null;
						} else { payload.switchOrder.customFieldValues.Job_Status_Details = Job_Status_Details; }

						var OE_Comments = incomingdata.switchOrder.customFieldValues.OE_Comments;
						if (OE_Comments === null || OE_Comments === '') {
							payload.switchOrder.customFieldValues.OE_Comments = null;
						} else { payload.switchOrder.customFieldValues.OE_Comments = OE_Comments; }

						var Customers_Affected = incomingdata.switchOrder.customFieldValues.Customers_Affected;
						if (Customers_Affected === null || Customers_Affected === '') {
							payload.switchOrder.customFieldValues.Customers_Affected = null;
						} else { payload.switchOrder.customFieldValues.Customers_Affected = Customers_Affected; }

						var Customer_Minutes = incomingdata.switchOrder.customFieldValues.Customer_Minutes;
						if (Customer_Minutes === null || Customer_Minutes === '') {
							payload.switchOrder.customFieldValues.Customer_Minutes = null;
						} else { payload.switchOrder.customFieldValues.Customer_Minutes = Customer_Minutes; }

						var SAIDI = incomingdata.switchOrder.customFieldValues.SAIDI;
						if (SAIDI === null || SAIDI === '') {
							payload.switchOrder.customFieldValues.SAIDI = null;
						} else { payload.switchOrder.customFieldValues.SAIDI = SAIDI; }

						var Restore_Before_System_Load = incomingdata.switchOrder.customFieldValues.Restore_Before_System_Load;
						if (Restore_Before_System_Load === null || Restore_Before_System_Load === '') {
							payload.switchOrder.customFieldValues.Restore_Before_System_Load = null;
						} else { payload.switchOrder.customFieldValues.Restore_Before_System_Load = Restore_Before_System_Load; }

						var Load_Restriction = incomingdata.switchOrder.customFieldValues.Load_Restriction;
						if (Load_Restriction === null || Load_Restriction === '') {
							payload.switchOrder.customFieldValues.Load_Restriction = null;
						} else { payload.switchOrder.customFieldValues.Load_Restriction = Load_Restriction; }

						var Recommend_Restore_By = incomingdata.switchOrder.customFieldValues.Recommend_Restore_By;
						if (Recommend_Restore_By === null || Recommend_Restore_By === '') {
							payload.switchOrder.customFieldValues.Recommend_Restore_By = null;
						} else { payload.switchOrder.customFieldValues.Recommend_Restore_By = Recommend_Restore_By; }

						var ctx = session.name("SOM") || session.createContext("SOM");
						var DTE_AFFTDBYPERDISPNAME = ctx.getVar("DTE_AFFTDBYPERDISPNAME");
						var DTE_REPBYDISPNAME = ctx.getVar("DTE_REPBYDISPNAME");
						var DTE_SUPERDISPNAME = ctx.getVar("DTE_SUPERDISPNAME");
						if (DTE_AFFTDBYPERDISPNAME == undefined) {
						} else if (DTE_AFFTDBYPERDISPNAME === null || DTE_AFFTDBYPERDISPNAME === '') {
							payload.switchOrder.customFieldValues.Affected_By_Person = null;
						} else { payload.switchOrder.customFieldValues.Affected_By_Person = DTE_AFFTDBYPERDISPNAME; }
						if (DTE_REPBYDISPNAME == undefined) {
						} else if (DTE_REPBYDISPNAME === null || DTE_REPBYDISPNAME === '') {
							payload.switchOrder.customFieldValues.Reported_By_Person = null;
						} else { payload.switchOrder.customFieldValues.Reported_By_Person = DTE_REPBYDISPNAME; }
						if (DTE_SUPERDISPNAME == undefined) {
						} else if (DTE_SUPERDISPNAME === null || DTE_SUPERDISPNAME === '') {
							payload.switchOrder.customFieldValues.Supersior_Person = null;
						} else { payload.switchOrder.customFieldValues.Supersior_Person = DTE_SUPERDISPNAME; }


					}
					if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD' || CLASSIFICATIONID == 'RECL' || CLASSIFICATIONID == 'ETO') {
						var Special_Notes_And_Instructions = incomingdata.switchOrder.customFieldValues.Special_Notes_And_Instructions;
						if (Special_Notes_And_Instructions === null || Special_Notes_And_Instructions === '') {
							payload.switchOrder.customFieldValues.Special_Notes_And_Instructions = null;
						} else {
							payload.switchOrder.customFieldValues.Special_Notes_And_Instructions = Special_Notes_And_Instructions;
						}
					}
					
					if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD' || CLASSIFICATIONID == 'RECL') {

						/*var Special_Notes_And_Instructions = incomingdata.switchOrder.customFieldValues.Special_Notes_And_Instructions;
						if (Special_Notes_And_Instructions === null || Special_Notes_And_Instructions === '') {
							payload.switchOrder.customFieldValues.Special_Notes_And_Instructions = null;
						} else { payload.switchOrder.customFieldValues.Special_Notes_And_Instructions = Special_Notes_And_Instructions; }*/

						var Equipment_to_be_Shutdown = incomingdata.switchOrder.customFieldValues.Equipment_to_be_Shutdown;
						if (Equipment_to_be_Shutdown === null || Equipment_to_be_Shutdown === '') {
							payload.switchOrder.customFieldValues.Equipment_to_be_Shutdown = null;
						} else { payload.switchOrder.customFieldValues.Equipment_to_be_Shutdown = Equipment_to_be_Shutdown; }

						var Protection_Limits = incomingdata.switchOrder.customFieldValues.Protection_Limits;
						if (Protection_Limits === null || Protection_Limits === '') {
							payload.switchOrder.customFieldValues.Protection_Limits = null;
						} else { payload.switchOrder.customFieldValues.Protection_Limits = Protection_Limits; }

						var Protection_Limits_Description = incomingdata.switchOrder.customFieldValues.Protection_Limits_Description;
						if (Protection_Limits_Description === null || Protection_Limits_Description === '') {
							payload.switchOrder.customFieldValues.Protection_Limits_Description = null;
						} else { payload.switchOrder.customFieldValues.Protection_Limits_Description = Protection_Limits_Description; }

					}
					if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD') {


						if (incomingdata.switchOrder.customFieldValues.Resource_Requirements !== undefined) {
							var Resource_Requirements = incomingdata.switchOrder.customFieldValues.Resource_Requirements;
							if (Resource_Requirements.length > 0) {
								if (Resource_Requirements === null || Resource_Requirements === undefined || Resource_Requirements === '') {
									payload.switchOrder.customFieldValues.Resource_Requirements = null;
								} else { payload.switchOrder.customFieldValues.Resource_Requirements = Resource_Requirements; }
							}
						}

						//				var Resource_Requirements= incomingdata.switchOrder.customFieldValues.Resource_Requirements;
						//				logger.error("Resource_Requirements+++"+Resource_Requirements);
						//			   if(Resource_Requirements === null ||  Resource_Requirements === '' ){
						//				//if(Resource_Requirements.length<0){
						//				 payload.switchOrder.customFieldValues.Resource_Requirements=null;
						//				}else if(Resource_Requirements === undefined){}
						//				else{payload.switchOrder.customFieldValues.Resource_Requirements= Resource_Requirements;}
						//			//	}
						var Protection_Class = incomingdata.switchOrder.customFieldValues.Protection_Class;
						if (Protection_Class === null || Protection_Class === '') {
							payload.switchOrder.customFieldValues.Protection_Class = null;
						} else { payload.switchOrder.customFieldValues.Protection_Class = Protection_Class; }

						var Protection_Required = incomingdata.switchOrder.customFieldValues.Protection_Required;
						if (Protection_Required === null || Protection_Required === '') {
							payload.switchOrder.customFieldValues.Protection_Required = null;
						} else { payload.switchOrder.customFieldValues.Protection_Required = Protection_Required; }

						var Assignment_Of_Request = incomingdata.switchOrder.customFieldValues.Assignment_Of_Request;
						if (Assignment_Of_Request === null || Assignment_Of_Request === '') {
							payload.switchOrder.customFieldValues.Assignment_Of_Request = null;
						} else { payload.switchOrder.customFieldValues.Assignment_Of_Request = Assignment_Of_Request; }

						var Emergency_Clearance_Time = incomingdata.switchOrder.customFieldValues.Emergency_Clearance_Time;
						if (Emergency_Clearance_Time === null || Emergency_Clearance_Time === '') {
							payload.switchOrder.customFieldValues.Emergency_Clearance_Time = null;
						} else { payload.switchOrder.customFieldValues.Emergency_Clearance_Time = Emergency_Clearance_Time; }

						var Must = incomingdata.switchOrder.customFieldValues.Must;
						if (Must === null || Must === '') {
							payload.switchOrder.customFieldValues.Must = null;
						} else { payload.switchOrder.customFieldValues.Must = Must; }

						var Managed_Must = incomingdata.switchOrder.customFieldValues.Managed_Must;
						if (Managed_Must === null || Managed_Must === '') {
							payload.switchOrder.customFieldValues.Managed_Must = null;
						} else { payload.switchOrder.customFieldValues.Managed_Must = Managed_Must; }

					}
					if (CLASSIFICATIONID == 'RSD') {

						var phoneNumber = incomingdata.switchOrder.phoneNumber;
						if (phoneNumber === null || phoneNumber === '') {
							payload.switchOrder.phoneNumber = null;
						} else { payload.switchOrder.phoneNumber = phoneNumber; }

						//Pre_Switch_Date 
						if (incomingdata.switchOrder.customFieldValues.Pre_Switch_Date === undefined || incomingdata.switchOrder.customFieldValues.Pre_Switch_Date === '' || incomingdata.switchOrder.customFieldValues.Pre_Switch_Date === null) {
							//payload.switchOrder.customFieldValues.Pre_Switch_Date ='none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Pre_Switch_Date);
							var Pre_Switch_Datedate = date.toISOString();
							var beforePlus = Pre_Switch_Datedate.split('.').shift();
							var Pre_Switch_DatedateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Pre_Switch_Date = Pre_Switch_DatedateUTC;
						}
						//Pre_Switch_Date
						var Lead_Name = incomingdata.switchOrder.customFieldValues.Lead_Name;
						if (Lead_Name === null || Lead_Name === '') {
							payload.switchOrder.customFieldValues.Lead_Name = null;
						} else { payload.switchOrder.customFieldValues.Lead_Name = Lead_Name; }

						//Switching_Start
						if (incomingdata.switchOrder.customFieldValues.Switching_Start === undefined || incomingdata.switchOrder.customFieldValues.Switching_Start === '' || incomingdata.switchOrder.customFieldValues.Switching_Start === null) {
							//	payload.switchOrder.customFieldValues.Switching_Start ='none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Switching_Start);
							var Switching_Startdate = date.toISOString();
							var beforePlus = Switching_Startdate.split('.').shift();
							var Switching_StartdateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Switching_Start = Switching_StartdateUTC;
						}
						//Switching_Start
						//Switching_End
						if (incomingdata.switchOrder.customFieldValues.Switching_End === undefined || incomingdata.switchOrder.customFieldValues.Switching_End === '' || incomingdata.switchOrder.customFieldValues.Switching_End === null) {
							//payload.switchOrder.customFieldValues.Switching_End ='none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Switching_End);
							var Switching_Enddate = date.toISOString();
							var beforePlus = Switching_Enddate.split('.').shift();
							var Switching_EnddateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Switching_End = Switching_EnddateUTC;
						}
						//Switching_End
					}


					if (CLASSIFICATIONID == 'RECL') {

						if (incomingdata.switchOrder.customFieldValues.Pre_Switch_Date === undefined || incomingdata.switchOrder.customFieldValues.Pre_Switch_Date === '' || incomingdata.switchOrder.customFieldValues.Pre_Switch_Date === null) {
							//payload.switchOrder.customFieldValues.Pre_Switch_Date ='none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Pre_Switch_Date);
							var Pre_Switch_Datedate = date.toISOString();
							var beforePlus = Pre_Switch_Datedate.split('.').shift();
							var Pre_Switch_DatedateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Pre_Switch_Date = Pre_Switch_DatedateUTC;
						}
						//Pre_Switch_Date
						var Lead_Name = incomingdata.switchOrder.customFieldValues.Lead_Name;
						if (Lead_Name === null || Lead_Name === '') {
							payload.switchOrder.customFieldValues.Lead_Name = null;
						} else { payload.switchOrder.customFieldValues.Lead_Name = Lead_Name; }

						//Switching_Start
						if (incomingdata.switchOrder.customFieldValues.Switching_Start === undefined || incomingdata.switchOrder.customFieldValues.Switching_Start === '' || incomingdata.switchOrder.customFieldValues.Switching_Start === null) {
							//	payload.switchOrder.customFieldValues.Switching_Start ='none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Switching_Start);
							var Switching_Startdate = date.toISOString();
							var beforePlus = Switching_Startdate.split('.').shift();
							var Switching_StartdateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Switching_Start = Switching_StartdateUTC;
						}
						//Switching_Start
						//Switching_End
						if (incomingdata.switchOrder.customFieldValues.Switching_End === undefined || incomingdata.switchOrder.customFieldValues.Switching_End === '' || incomingdata.switchOrder.customFieldValues.Switching_End === null) {
							//payload.switchOrder.customFieldValues.Switching_End ='none';
						} else {
							const date = new Date(incomingdata.switchOrder.customFieldValues.Switching_End);
							var Switching_Enddate = date.toISOString();
							var beforePlus = Switching_Enddate.split('.').shift();
							var Switching_EnddateUTC = beforePlus + 'Z';
							payload.switchOrder.customFieldValues.Switching_End = Switching_EnddateUTC;
						}
					}


					var ctx = session.name('SOM') || session.createContext('SOM');
					ctx.setVar("CreateSomRequest", payload);
					//https://adms-test.dteco.com:443/somplanner/external/api/v1/switch-order
					var omsExternalURL = session.parameters.omsExternalURL + 'api/v1/switch-order';
					var apiToken = session.parameters.osiApiToken;
					var SOMCreateuri = omsExternalURL;
					var TokenValue = apiToken;

					var SOMCreateapi = {
						target: SOMCreateuri,
						sslClientProfile: 'OMS_SOM_Client_Profile',
						method: 'POST',
						contentType: 'application/json',
						data: payload,
						headers: {
							'osiApiToken': TokenValue
						},

					};
					session.output.write(payload);
					var info = " TargetURL :" + SOMCreateapi.target + "; Method :" + SOMCreateapi.method + "; Data :" + JSON.stringify(SOMCreateapi.data) + ". ";
					try {
						urlopen.open(SOMCreateapi, function(error, response) {
							if (error) {
								var errorinfo = "SOM_AM_005 : url connection error 'SOMCreateuri', details are : " + info + "; error info :" + error
								var ctx = session.name("SOM") || session.createContext("SOM");
								ILSctx.setVariable('ExitStatus', '500');
								ILSctx.setVariable('ErrorDescription', errorinfo);
								//	logger.error(errorinfo);
								ctx.setVariable("retry", 'yes');
								var ErrorTxt = "SOM_AM_005 in service SOM_AMCreateUpdateSwithOrder urlopen connect error with post call for  SOMCreateapi " + JSON.stringify(error);
								ctx.setVariable("ErrorTxt", errorinfo);
							} else {
								var responseStatusCode = response.statusCode;
								var ServerErrorCode = session.parameters.ServerErrorCode;
								var ErrorCodeList = ServerErrorCode.split(',');
								var flagvalue;

								for (var i = 0; i < ErrorCodeList.length; i++) {
									var numberval = Number(ErrorCodeList[i]);
									// Convert responseStatusCode to string and check if it includes the numberval
									if (String(responseStatusCode).includes(String(numberval))) {
										flagvalue = 'yes';
										//logger.error("line no 68"+flagvalue)
									}
								}

								if (responseStatusCode == 200) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											//dp:reject stop the transaction and go error rule with error code and description
											var errorinfo = "error reading response 'SOMCreateuri', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											//store status code with response body in context variable
											ILSctx.setVariable('ExitStatus', '0');
											ILSctx.setVariable('ExitDescription', ExitDescription);
											hm.response.statusCode = responseStatusCode;
											hm.response.statusCode = responseStatusCode;
											var displayID = JSON.parse(responseData).switchOrder.displayID;
											var ctx = session.name("SOM") || session.createContext("SOM");
											var TicketId = ctx.getVar("TICKETID");
											var IncomingCreationDateTime = ctx.getVar("IncomingCreationDateTime");
											var statusissue = ctx.getVar("StatusIssue");
											var messageId = ctxSeq.getVariable("messageId");
											var orderType = ctx.getVar("CLASSIFICATIONID");

											var PayloadAddon = {

												"maximoID": TicketId,
												"timeStamp": IncomingCreationDateTime,
												"orderType": orderType,
												"orderStatus": toState,
												"messageID": messageId,
												"somID": somID

											}

											var MaximoPositiveCreateResponsePayload = {
												"ticketid": TicketId,
												"status": "PositiveAcknowledge",
												"dte_ticket": [
													{
														"dte_externalid2": displayID
													}
												],
												"esbData": PayloadAddon
											}
											ctx.setVar("MaximoPositiveCreateResponsePayload", MaximoPositiveCreateResponsePayload);
											//start calling maximoResponsecall api
											var Queueurl = session.parameters.BackendMQurl;
											var test = maximoResponsecall(Queueurl, MaximoPositiveCreateResponsePayload);
											//end calling maximoResponsecall api 


										}
									});
								} else if ((responseStatusCode == 401)) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "SOM_AM_05 : Unauthorized error message while reading response for post call 'SOMCreateuri', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "SOM_AM_05 : Unauthorized error response for post call 'SOMCreateuri', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});

								} else if ((responseStatusCode == 403)) {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "SOM_AM_06 : Forbidden error message while reading response for post call 'SOMCreateuri', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "SOM_AM_06 : Forbidden error message response for post call 'SOMCreateuri', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});

								}
								else if (flagvalue === 'yes') {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var ctx = session.name("SOM") || session.createContext("SOM");
											var errorinfo = "error reading response 'Callapi', details are: " + info + "; error info: " + error;
											ILSctx.setVariable('ErrorDescription', errorinfo);
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ctx.setVariable("retry", 'yes');
											var ErrorTxt = "SOM_AM_003 in service SOM_AMCreateUpdateSwithOrder urlopen connect error returned from Get Switch order api " + JSON.stringify(error);
											ctx.setVariable("ErrorTxt", errorinfo);
											logger.error(errorinfo);
										} else {
											var ctx = session.name("SOM") || session.createContext("SOM");
											var errorinfo = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData)
											ILSctx.setVariable('ErrorDescription', errorinfo);
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ctx.setVariable("retry", 'yes');
											var ErrorTxt = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData);
											ctx.setVariable("ErrorTxt", errorinfo);
											logger.error(errorinfo);
										}
									});
								}


								else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'SOMCreateuri', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {

											var errorinfo = "error response 'SOMCreateuri', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ErrorDescription', errorinfo);
											logger.error(errorinfo);
											var ctx = session.name("SOM") || session.createContext("SOM");
											var TicketId = ctx.getVar("TICKETID");
											var IncomingCreationDateTime = ctx.getVar("IncomingCreationDateTime");
											var statusissue = ctx.getVar("StatusIssue");
											var messageId = ctxSeq.getVariable("messageId");
											var orderType = ctx.getVar("CLASSIFICATIONID");
											//logger.error(somID)
											//	logger.error(ctx.getVar("DTE_EXTERNALID2"))
											var PayloadAddon = {

												"maximoID": TicketId,
												"timeStamp": IncomingCreationDateTime,
												"orderType": orderType,
												"orderStatus": toState,
												"messageID": messageId,
												"somID": somID

											}
											var MaximoNegativeUpdateResponsePayload;
											if (responseData == undefined || responseData === null || responseData == '') {
												MaximoNegativeUpdateResponsePayload = {
													"ticketid": TicketId,
													"status": "NegativeAcknowledge",
													"np_statusmemo": responseStatusCode + ' ' + response._response.reasonPhrase,
													"esbData": PayloadAddon
												}
											} else {
												var responseData_Negavetive = responseStatusCode + ' ' + responseData;
												var np_statusmemo = responseData_Negavetive.slice(0, 99);
												MaximoNegativeUpdateResponsePayload = {
													"ticketid": TicketId,
													"status": "NegativeAcknowledge",
													"np_statusmemo": np_statusmemo,
													"esbData": PayloadAddon
												}
											}
											ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
											//logger.debug(" Error returned from SOMCreateapi with  statusCode " + responseStatusCode+" "+ response._response.reasonPhrase);
											//start calling maximoResponsecall api
											var Queueurl = session.parameters.BackendMQurl;
											var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);

										}
									});
								}
							}
						});
					} catch (err) {
						var errorinfo = "SOM_AM_005 : url connection error 'SOMCreateuri', details are : " + info + "; error info :" + err
						var ctx = session.name("SOM") || session.createContext("SOM");
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ErrorDescription', errorinfo);
						//logger.error(errorinfo);
						ctx.setVariable("retry", 'yes');
						var ErrorTxt = "SOM_AM_005 in service SOM_AMCreateUpdateSwithOrder urlopen connect error with post call for  SOMCreateapi " + JSON.stringify(error);
						ctx.setVariable("ErrorTxt", errorinfo);
					}

					//
				} else if (GetSwitchOrderUpdateStatus == 'Updateoperation') {
					var ctx = session.name("SOM") || session.createContext("SOM");
					var GetSwitchOrderResponseData;
					if (responsecode == '200') {
						GetSwitchOrderResponseData = JSON.parse(ctx.getVar("GetSwitchOrderResponseData"));
					} else {
						GetSwitchOrderResponseData = ctx.getVar("GetSwitchOrderResponseData");
					}
					//	

					var GetSwitchOrderResponseDataId = GetSwitchOrderResponseData.id;

					var doupdate = ctx.getVar('doupdate');

					if (doupdate == 'yes') {

						var payload;
						//below value will be decided from lookup need to be changed dynamically

						var CLASSIFICATIONID = ctx.getVar("switchOrderType_Label");
						var Work_Order_Status = undefined;
						var Work_Order_Number = undefined;
						var Work_Order_Summary = undefined;
						if (incomingdata.customTableValues.Maximo_Work_Orders == undefined) {
						}
						else {
							Work_Order_Status = incomingdata.customTableValues.Maximo_Work_Orders;
							Work_Order_Number = incomingdata.customTableValues.Maximo_Work_Orders;
							Work_Order_Summary = incomingdata.customTableValues.Maximo_Work_Orders;
						}

						var Memo_Detail = undefined;
						var Memo_Date = undefined;
						if (incomingdata.customTableValues.Maximo_Related_Logs == undefined) {
						} else {
							if (incomingdata.customTableValues.Maximo_Related_Logs != undefined) {
								if (incomingdata.customTableValues.Maximo_Related_Logs[0].Memo_Date !== undefined && incomingdata.customTableValues.Maximo_Related_Logs[0].Memo_Detail !== undefined) {
									Memo_Detail = incomingdata.customTableValues.Maximo_Related_Logs;
									Memo_Date = incomingdata.customTableValues.Maximo_Related_Logs;
								}
								if (incomingdata.customTableValues.Maximo_Related_Logs[0].Memo_Detail !== undefined) {
									Memo_Detail = incomingdata.customTableValues.Maximo_Related_Logs;
								}
								if (incomingdata.customTableValues.Maximo_Related_Logs[0].Memo_Date !== undefined) {
									Memo_Date = incomingdata.customTableValues.Maximo_Related_Logs;
								}
							}
						}

						var Maximo_Related_Logs;
						var Maximo_Work_Orders;
						if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'RECL') {
							if ((Work_Order_Status !== undefined || Work_Order_Number !== undefined || Work_Order_Summary !== undefined) && (Memo_Detail !== undefined || Memo_Date !== undefined)) {
								Maximo_Related_Logs = 'yes';
								Maximo_Work_Orders = 'yes';
								payload = {

									"customFieldValues": {},
									"customTableValues": {
										"Maximo_Related_Logs": [{
										}],
										"Maximo_Work_Orders": [
											{
												"Work_Order_Status": '',
												"Work_Order_Number": '',
												"Work_Order_Summary": ''
											}]
									}
								}
							} else if ((Work_Order_Status !== undefined || Work_Order_Number !== undefined || Work_Order_Summary !== undefined) && (Memo_Detail == undefined || Memo_Date == undefined)) {
								Maximo_Work_Orders = 'yes';

								payload = {

									"customFieldValues": {},
									"customTableValues": {
										"Maximo_Work_Orders": [
											{
												"Work_Order_Status": '',
												"Work_Order_Number": '',
												"Work_Order_Summary": ''
											}]
									}
								}
							} else if ((Work_Order_Status == undefined && Work_Order_Number == undefined && Work_Order_Summary == undefined) && (Memo_Detail == undefined && Memo_Date == undefined)) {

								payload = {

									"customFieldValues": {}

								}
							} else if ((Work_Order_Status == undefined || Work_Order_Number == undefined || Work_Order_Summary == undefined) && (Memo_Detail !== undefined || Memo_Date !== undefined)) {
								Maximo_Related_Logs = 'yes';
								payload = {

									"customFieldValues": {},
									"customTableValues": {
										"Maximo_Related_Logs": [{
										}]
									}
								}
							}

						}//RSD RECL
						else {
							//
							if (Work_Order_Status !== undefined || Work_Order_Number !== undefined || Work_Order_Summary !== undefined) {
								Maximo_Work_Orders = 'yes';
								payload = {

									"customFieldValues": {},
									"customTableValues": {
										"Maximo_Work_Orders": [{
											"Work_Order_Status": '',
											"Work_Order_Number": '',
											"Work_Order_Summary": ''
										}]
									}
								}
							} else {
								payload = {

									"customFieldValues": {}
								}
							}



							//
						}

						if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD' || CLASSIFICATIONID == 'RECL' || CLASSIFICATIONID == 'ETO') {

							if (CLASSIFICATIONID == 'ETO' || CLASSIFICATIONID == 'TRSD') {
								//ado 114284 12/1/2023
								var identifier = ctx.getVariable("identifier");
								if (identifier === undefined || identifier === '' || identifier === null) {
									//	payload.customFieldValues.Position_in_Manual = "";
								} else {
									payload.customFieldValues.Position_in_Manual = identifier;
								}
								//ado 114284 12/1/2023
							}
							if (incomingdata.customFieldValues.Updated_At === undefined || incomingdata.customFieldValues.Updated_At === '' || incomingdata.customFieldValues.Updated_At === null) {
								//payload.customFieldValues.Updated_At ='none';
							} else {
								const date = new Date(incomingdata.customFieldValues.Updated_At);
								var Updated_AtDate = date.toISOString();
								var beforePlus = Updated_AtDate.split('.').shift();
								var Updated_AtDateUTC = beforePlus + 'Z';
								payload.customFieldValues.Updated_At = Updated_AtDateUTC;
							}
							var responsecode = ctx.getVar("GetSwitchOrderResponseCode");
							var GetSwitchOrderResponse;
							if (responsecode == '200') {
								GetSwitchOrderResponse = JSON.parse(ctx.getVar("GetSwitchOrderResponseData"));
							} else {
								GetSwitchOrderResponse = ctx.getVar("GetSwitchOrderResponseData");
							}
							if (Maximo_Work_Orders == 'yes') {
								var Maximo_Work_Orders = GetSwitchOrderResponse.customTableValuesExt.Maximo_Work_Orders;

								var Maximo_Work_Orders_Incoming_Payload = incomingdata.customTableValues.Maximo_Work_Orders;

								var myarray = [];
								if (Maximo_Work_Orders == undefined || Maximo_Work_Orders === null || Maximo_Work_Orders === '') {
								} else {

									var Maximo_Work_Orders_length = GetSwitchOrderResponse.customTableValuesExt.Maximo_Work_Orders.length;
									for (var len = 0; len < Maximo_Work_Orders_length; len++) {
										myarray.push(GetSwitchOrderResponse.customTableValuesExt.Maximo_Work_Orders[len]);
									}

									//myarray.push(Maximo_Work_Orders);
								}

								if (Maximo_Work_Orders_Incoming_Payload == undefined || Maximo_Work_Orders_Incoming_Payload === null || Maximo_Work_Orders_Incoming_Payload === '') {
								} else {
									var Maximo_Work_Orders_Incoming_Payload_length = incomingdata.customTableValues.Maximo_Work_Orders.length;
									for (var len = 0; len < Maximo_Work_Orders_Incoming_Payload_length; len++) {
										myarray.push(incomingdata.customTableValues.Maximo_Work_Orders[len]);
									}

									//myarray.push(Maximo_Work_Orders);
								}
								//myarray.push(Maximo_Work_Orders_Incoming_Payload);
								var Work_Order_Number = incomingdata.customTableValues.Maximo_Work_Orders;
								if (Work_Order_Number === null || Work_Order_Number === '') {
									payload.customeTables.Maximo_Work_Orders[0].Work_Order_Number = null;
								} else if (Work_Order_Number === undefined) {

								} else { payload.customTableValues.Maximo_Work_Orders = myarray; }

							}
							if (!(CLASSIFICATIONID == 'TRSD')) {
								if (!(CLASSIFICATIONID == 'ETO')) {
									var officeNumber = incomingdata.officeNumber;
									if (officeNumber === null || officeNumber === '') {
										payload.officeNumber = null;
									} else if (officeNumber === undefined) {

									} else { payload.officeNumber = officeNumber; }
								}
							}
							//Work_Start
							if (incomingdata.customFieldValues.Work_Start == '' || incomingdata.customFieldValues.Work_Start == null) {
								payload.customFieldValues.Work_Start = null;
							} else if (incomingdata.customFieldValues.Work_Start == undefined) {

							} else {
								const date = new Date(incomingdata.customFieldValues.Work_Start);
								var Work_Startdate = date.toISOString();
								var beforePlus = Work_Startdate.split('.').shift();
								var Work_StartdateUTC = beforePlus + 'Z';
								payload.customFieldValues.Work_Start = Work_StartdateUTC;
							}
							//Work_Start
							//Work_End
							if (incomingdata.customFieldValues.Work_End === '' || incomingdata.customFieldValues.Work_End === null) {
								payload.customFieldValues.Work_End = null;
							} else if (incomingdata.customFieldValues.Work_End === undefined) {

							}
							else {
								const date = new Date(incomingdata.customFieldValues.Work_End);
								var Work_Enddate = date.toISOString();
								var beforePlus = Work_Enddate.split('.').shift();
								var Work_EnddateUTC = beforePlus + 'Z';
								payload.customFieldValues.Work_End = Work_EnddateUTC;
							}
							//Work_End
							var Priority = incomingdata.customFieldValues.Priority;
							if (Priority === null || Priority === '') {
								payload.customFieldValues.Priority = null;
							} else if (Priority === undefined) {

							} else { payload.customFieldValues.Priority = Priority; }

							var Job_Status = incomingdata.customFieldValues.Job_Status;
							if (Job_Status === null || Job_Status === '') {
								payload.customFieldValues.Job_Status = null;
							} else if (Job_Status === undefined) {

							} else { payload.customFieldValues.Job_Status = Job_Status; }

							var Voltage_Class = incomingdata.customFieldValues.Voltage_Class;
							if (Voltage_Class === null || Voltage_Class === '') {
								payload.customFieldValues.Voltage_Class = null;
							} else if (Voltage_Class === undefined) {

							} else { payload.customFieldValues.Voltage_Class = Voltage_Class; }
							var Reason_For_Action = incomingdata.customFieldValues.Reason_For_Action;
							if (Reason_For_Action !== 'null') {
								payload.customFieldValues.Reason_For_Action = Reason_For_Action;
							} else if (Reason_For_Action == undefined) {

							} else {
								payload.customFieldValues.Reason_For_Action = null;
							}

							var Desk_Assignment = incomingdata.customFieldValues.Desk_Assignment;
							if (Desk_Assignment === null || Desk_Assignment === '') {
								payload.customFieldValues.Desk_Assignment = null;
							} else if (Desk_Assignment === undefined) {

							} else { payload.customFieldValues.Desk_Assignment = Desk_Assignment; }

							var Desk_Assignment_Description = incomingdata.customFieldValues.Desk_Assignment_Description;
							if (Desk_Assignment_Description === null || Desk_Assignment_Description === '') {
								payload.customFieldValues.Desk_Assignment_Description = null;
							} else if (Desk_Assignment_Description === undefined) {

							} else { payload.customFieldValues.Desk_Assignment_Description = Desk_Assignment_Description; }

							var Maximo_Reference_Requests = incomingdata.customFieldValues.Maximo_Reference_Requests;
							if (Maximo_Reference_Requests === null || Maximo_Reference_Requests === '') {
								payload.customFieldValues.Maximo_Reference_Requests = null;
							} else if (Maximo_Reference_Requests === undefined) {

							} else { payload.customFieldValues.Maximo_Reference_Requests = Maximo_Reference_Requests; }
							if (!(CLASSIFICATIONID == 'TRSD')) {
								if (!(CLASSIFICATIONID == 'ETO')) {
									//	logger.error("CLASSIFICATIONID "+CLASSIFICATIONID);
									var location = incomingdata.location;
									if (location === null || location === '') {
										payload.location = null;
									} else if (location === undefined) {

									} else { payload.location = location; }
								}
							}
							var New_location = incomingdata.New_location;
							if (New_location === null || New_location === '') {
								payload.customFieldValues.Maximo_Location = null;
							} else if (New_location === undefined) {

							} else { payload.customFieldValues.Maximo_Location = New_location; }

							var Character_Of_Work_Selection = incomingdata.customFieldValues.Character_Of_Work_Selection;
							if (Character_Of_Work_Selection === null || Character_Of_Work_Selection === '') {
								payload.customFieldValues.Character_Of_Work_Selection = null;
							} else if (Character_Of_Work_Selection === undefined) {

							} else { payload.customFieldValues.Character_Of_Work_Selection = Character_Of_Work_Selection; }

							var Responsible_Organization = incomingdata.customFieldValues.Responsible_Organization;
							if (Responsible_Organization === null || Responsible_Organization === '') {
								payload.customFieldValues.Responsible_Organization = null;
							} else if (Responsible_Organization === undefined) {

							} else { payload.customFieldValues.Responsible_Organization = Responsible_Organization; }

							var Character_Of_Work_Description = incomingdata.customFieldValues.Character_Of_Work_Description;
							if (Character_Of_Work_Description === null || Character_Of_Work_Description === '') {
								payload.customFieldValues.Character_Of_Work_Description = null;
							} else if (Character_Of_Work_Description === undefined) {

							} else { payload.customFieldValues.Character_Of_Work_Description = Character_Of_Work_Description; }

							var Responsible_Service_Center = incomingdata.customFieldValues.Responsible_Service_Center;
							if (Responsible_Service_Center === null || Responsible_Service_Center === '') {
								payload.customFieldValues.Responsible_Service_Center = null;
							} else if (Responsible_Service_Center === undefined) {

							} else { payload.customFieldValues.Responsible_Service_Center = Responsible_Service_Center; }

						}//
						if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD' || CLASSIFICATIONID == 'RECL' || CLASSIFICATIONID == 'ETO') {
						
						var Special_Notes_And_Instructions = incomingdata.customFieldValues.Special_Notes_And_Instructions;
							if (Special_Notes_And_Instructions === null || Special_Notes_And_Instructions === '') {
								payload.customFieldValues.Special_Notes_And_Instructions = null;
							} else if (Special_Notes_And_Instructions === undefined) {

							} else { payload.customFieldValues.Special_Notes_And_Instructions = Special_Notes_And_Instructions; }
						}
						if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD' || CLASSIFICATIONID == 'RECL') {
							var Equipment_to_be_Shutdown = incomingdata.customFieldValues.Equipment_to_be_Shutdown;
							if (Equipment_to_be_Shutdown === null || Equipment_to_be_Shutdown === '') {
								payload.customFieldValues.Equipment_to_be_Shutdown = null;
							} else if (Equipment_to_be_Shutdown === undefined) {

							} else { payload.customFieldValues.Equipment_to_be_Shutdown = Equipment_to_be_Shutdown; }

							var Protection_Limits = incomingdata.customFieldValues.Protection_Limits;
							if (Protection_Limits === null || Protection_Limits === '') {
								payload.customFieldValues.Protection_Limits = null;
							} else if (Protection_Limits === undefined) {

							} else { payload.customFieldValues.Protection_Limits = Protection_Limits; }

							var Protection_Limits_Description = incomingdata.customFieldValues.Protection_Limits_Description;
							if (Protection_Limits_Description === null || Protection_Limits_Description === '') {
								payload.customFieldValues.Protection_Limits_Description = null;
							} else if (Protection_Limits_Description === undefined) {

							} else { payload.customFieldValues.Protection_Limits_Description = Protection_Limits_Description; }

							/*var Special_Notes_And_Instructions = incomingdata.customFieldValues.Special_Notes_And_Instructions;
							if (Special_Notes_And_Instructions === null || Special_Notes_And_Instructions === '') {
								payload.customFieldValues.Special_Notes_And_Instructions = null;
							} else if (Special_Notes_And_Instructions === undefined) {

							} else { payload.customFieldValues.Special_Notes_And_Instructions = Special_Notes_And_Instructions; }*/
						}//

						if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD') {

							var Must = incomingdata.customFieldValues.Must;
							if (Must === null || Must === '') {
								payload.customFieldValues.Must = null;
							} else if (Must === undefined) {

							} else { payload.customFieldValues.Must = Must; }

							var Managed_Must = incomingdata.customFieldValues.Managed_Must;
							if (Managed_Must === null || Managed_Must === '') {
								payload.customFieldValues.Managed_Must = null;
							} else if (Managed_Must === undefined) {

							} else { payload.customFieldValues.Managed_Must = Managed_Must; }

							if (incomingdata.customFieldValues.Resource_Requirements !== undefined) {
								var Resource_Requirements = incomingdata.customFieldValues.Resource_Requirements;
								if (Resource_Requirements.length > 0) {
									if (Resource_Requirements === null || Resource_Requirements === undefined || Resource_Requirements === '') {
										// payload.customFieldValues.Resource_Requirements=''none'';
									} else { payload.customFieldValues.Resource_Requirements = Resource_Requirements; }
								}
							}
							var Protection_Class = incomingdata.customFieldValues.Protection_Class;
							if (Protection_Class === null || Protection_Class === '') {
								payload.customFieldValues.Protection_Class = null;
							} else if (Protection_Class === undefined) {

							} else { payload.customFieldValues.Protection_Class = Protection_Class; }

							var Protection_Required = incomingdata.customFieldValues.Protection_Required;
							if (Protection_Required === null || Protection_Required === '') {
								payload.customFieldValues.Protection_Required = null;
							} else if (Protection_Required === undefined) {

							} else { payload.customFieldValues.Protection_Required = Protection_Required; }

							var Assignment_Of_Request = incomingdata.customFieldValues.Assignment_Of_Request;
							if (Assignment_Of_Request === null || Assignment_Of_Request === '') {
								payload.customFieldValues.Assignment_Of_Request = null;
							} else if (Assignment_Of_Request === undefined) {

							} else { payload.customFieldValues.Assignment_Of_Request = Assignment_Of_Request; }

							var Emergency_Clearance_Time = incomingdata.customFieldValues.Emergency_Clearance_Time;
							if (Emergency_Clearance_Time === null || Emergency_Clearance_Time === '') {
								payload.customFieldValues.Emergency_Clearance_Time = null;
							} else if (Emergency_Clearance_Time === undefined) {

							} else { payload.customFieldValues.Emergency_Clearance_Time = Emergency_Clearance_Time; }
						}//
						if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'TRSD' || CLASSIFICATIONID == 'ETO') {

							var Job_Status_Details = incomingdata.customFieldValues.Job_Status_Details;
							if (Job_Status_Details === null || Job_Status_Details === '') {
								payload.customFieldValues.Job_Status_Details = null;
							} else if (Job_Status_Details === undefined) {

							} else { payload.customFieldValues.Job_Status_Details = Job_Status_Details; }

							var OE_Comments = incomingdata.customFieldValues.OE_Comments;
							if (OE_Comments === null || OE_Comments === '') {
								payload.customFieldValues.OE_Comments = null;
							} else if (OE_Comments === undefined) {

							} else { payload.customFieldValues.OE_Comments = OE_Comments; }

							var Customers_Affected = incomingdata.customFieldValues.Customers_Affected;
							if (Customers_Affected === null || Customers_Affected === '') {
								payload.customFieldValues.Customers_Affected = null;
							} else if (Customers_Affected === undefined) {

							} else { payload.customFieldValues.Customers_Affected = Customers_Affected; }

							var Customer_Minutes = incomingdata.customFieldValues.Customer_Minutes;
							if (Customer_Minutes === null || Customer_Minutes === '') {
								payload.customFieldValues.Customer_Minutes = null;
							} else if (Customer_Minutes === undefined) {

							} else { payload.customFieldValues.Customer_Minutes = Customer_Minutes; }

							var SAIDI = incomingdata.customFieldValues.SAIDI;
							if (SAIDI === null || SAIDI === '') {
								payload.customFieldValues.SAIDI = null;
							} else if (SAIDI === undefined) {

							} else { payload.customFieldValues.SAIDI = SAIDI; }

							var Restore_Before_System_Load = incomingdata.customFieldValues.Restore_Before_System_Load;
							if (Restore_Before_System_Load === null || Restore_Before_System_Load === '') {
								payload.customFieldValues.Restore_Before_System_Load = null;
							} else if (Restore_Before_System_Load === undefined) {

							} else { payload.customFieldValues.Restore_Before_System_Load = Restore_Before_System_Load; }

							var Load_Restriction = incomingdata.customFieldValues.Load_Restriction;
							if (Load_Restriction === null || Load_Restriction === '') {
								payload.customFieldValues.Load_Restriction = null;
							} else if (Load_Restriction === undefined) {

							} else { payload.customFieldValues.Load_Restriction = Load_Restriction; }

							var Recommend_Restore_By = incomingdata.customFieldValues.Recommend_Restore_By;
							if (Recommend_Restore_By === null || Recommend_Restore_By === '') {
								payload.customFieldValues.Recommend_Restore_By = null;
							} else if (Recommend_Restore_By === undefined) {

							} else { payload.customFieldValues.Recommend_Restore_By = Recommend_Restore_By; }

							var Job_Status_Details = incomingdata.customFieldValues.Job_Status_Details;
							if (Job_Status_Details === null || Job_Status_Details === '') {
								payload.customFieldValues.Job_Status_Details = null;
							} else if (Job_Status_Details === undefined) {

							} else { payload.customFieldValues.Job_Status_Details = Job_Status_Details; }

							var ctx = session.name("SOM") || session.createContext("SOM");
							var DTE_AFFTDBYPERDISPNAME = ctx.getVar("DTE_AFFTDBYPERDISPNAME");
							var DTE_REPBYDISPNAME = ctx.getVar("DTE_REPBYDISPNAME");
							var DTE_SUPERDISPNAME = ctx.getVar("DTE_SUPERDISPNAME");
							if (DTE_AFFTDBYPERDISPNAME == undefined) {
							} else if (DTE_AFFTDBYPERDISPNAME === null || DTE_AFFTDBYPERDISPNAME === '') {
								payload.customFieldValues.Affected_By_Person = null;
							} else { payload.customFieldValues.Affected_By_Person = DTE_AFFTDBYPERDISPNAME; }
							if (DTE_REPBYDISPNAME == undefined) {
							} else if (DTE_REPBYDISPNAME === null || DTE_REPBYDISPNAME === '') {
								payload.customFieldValues.Reported_By_Person = null;
							} else { payload.customFieldValues.Reported_By_Person = DTE_REPBYDISPNAME; }
							if (DTE_SUPERDISPNAME == undefined) {
							} else if (DTE_SUPERDISPNAME === null || DTE_SUPERDISPNAME === '') {
								payload.customFieldValues.Supersior_Person = null;
							} else { payload.customFieldValues.Supersior_Person = DTE_SUPERDISPNAME; }
						}//
						if (CLASSIFICATIONID == 'RSD') {
							var phoneNumber = incomingdata.phoneNumber;
							if (phoneNumber === null || phoneNumber === '') {
								payload.phoneNumber = null;
							} else if (phoneNumber === undefined) {

							} else { payload.phoneNumber = phoneNumber; }
							//Switching_Start
							if (incomingdata.customFieldValues.Switching_Start === '' || incomingdata.customFieldValues.Switching_Start === null) {
								payload.customFieldValues.Switching_Start = null;
							} else if (incomingdata.customFieldValues.Switching_Start === undefined) {

							} else {
								const date = new Date(incomingdata.customFieldValues.Switching_Start);
								var Switching_Startdate = date.toISOString();
								var beforePlus = Switching_Startdate.split('.').shift();
								var Switching_StartdateUTC = beforePlus + 'Z';
								payload.customFieldValues.Switching_Start = Switching_StartdateUTC;
							}
							//Switching_Start
							//Switching_End
							if (incomingdata.customFieldValues.Switching_End === '' || incomingdata.customFieldValues.Switching_End === null) {
								payload.customFieldValues.Switching_End = null;
							} else if (incomingdata.customFieldValues.Switching_End === undefined) {

							} else {
								const date = new Date(incomingdata.customFieldValues.Switching_End);
								var Switching_Enddate = date.toISOString();
								var beforePlus = Switching_Enddate.split('.').shift();
								var Switching_EnddateUTC = beforePlus + 'Z';
								payload.customFieldValues.Switching_End = Switching_EnddateUTC;
							}
							//Switching_End
							//Pre_Switch_Date 
							if (incomingdata.customFieldValues.Pre_Switch_Date === '' || incomingdata.customFieldValues.Pre_Switch_Date === null) {
								payload.customFieldValues.Pre_Switch_Date = null;
							} else if (incomingdata.customFieldValues.Pre_Switch_Date === undefined) {

							} else {
								const date = new Date(incomingdata.customFieldValues.Pre_Switch_Date);
								var Pre_Switch_Datedate = date.toISOString();
								var beforePlus = Pre_Switch_Datedate.split('.').shift();
								var Pre_Switch_DatedateUTC = beforePlus + 'Z';
								payload.customFieldValues.Pre_Switch_Date = Pre_Switch_DatedateUTC;
							}
							//Pre_Switch_Date

							var Lead_Name = incomingdata.customFieldValues.Lead_Name;
							if (Lead_Name === null || Lead_Name === '') {
								payload.customFieldValues.Lead_Name = null;
							} else if (Lead_Name === undefined) {

							} else { payload.customFieldValues.Lead_Name = Lead_Name; }
						}//RSD





						if (CLASSIFICATIONID == 'RSD' || CLASSIFICATIONID == 'RECL') {
							//
							var GetSwitchOrderResponse = ctx.getVar("GetSwitchOrderResponseDataJsonPayload");
							//	  

							if (Maximo_Related_Logs == 'yes') {

								var Maximo_Related_Logs = GetSwitchOrderResponse.customTableValuesExt.Maximo_Related_Logs;
								var Maximo_Related_Log = incomingdata.customTableValues.Maximo_Related_Logs[0];
								if (Maximo_Related_Log === null || Maximo_Related_Log === '') {
									payload.customeTables.Maximo_Work_Orders[0].Work_Order_Number = null;
								} else if (Maximo_Related_Log === undefined) {
								} else {
									var Maximo_Related_Logs_array = [];
									if (incomingdata.customTableValues.Maximo_Related_Logs[0].Memo_Date === undefined || incomingdata.customTableValues.Maximo_Related_Logs[0].Memo_Date === '' || incomingdata.customTableValues.Maximo_Related_Logs[0].Memo_Date === null) {

										var incomingdata_Maximo_Related_Logs_length = incomingdata.customTableValues.Maximo_Related_Logs.length;
										var memoPayload;
										for (var len = 0; len < incomingdata_Maximo_Related_Logs_length; len++) {

											memoPayload = {
												"Memo_Detail": incomingdata.customTableValues.Maximo_Related_Logs[len].Memo_Detail,
												//"Memo_Date":''
											}
											Maximo_Related_Logs_array.push(memoPayload);
										}
										if (Maximo_Related_Logs === undefined || Maximo_Related_Logs === null || Maximo_Related_Logs === '') {
										} else {
											var Maximo_Related_Logs_length = GetSwitchOrderResponse.customTableValuesExt.Maximo_Related_Logs.length;
											for (var len = 0; len < Maximo_Related_Logs_length; len++) {
												Maximo_Related_Logs_array.push(GetSwitchOrderResponse.customTableValuesExt.Maximo_Related_Logs[len]);
											}
											//Maximo_Related_Logs_array.push(Maximo_Related_Logs);
										}
										//Maximo_Related_Logs_array.push(memoPayload);
										payload.customTableValues.Maximo_Related_Logs = Maximo_Related_Logs_array;
									} else {

										if (Maximo_Related_Logs === undefined || Maximo_Related_Logs === null || Maximo_Related_Logs === '') {
										} else {

											//Maximo_Related_Logs_array.push(Maximo_Related_Logs);
											var Maximo_Related_Logs_length = GetSwitchOrderResponse.customTableValuesExt.Maximo_Related_Logs.length;
											for (var len = 0; len < Maximo_Related_Logs_length; len++) {

												Maximo_Related_Logs_array.push(GetSwitchOrderResponse.customTableValuesExt.Maximo_Related_Logs[len]);
											}
										}
										var incoming_Maximo_Relate_Log_Length = incomingdata.customTableValues.Maximo_Related_Logs.length;
										var memoPayload;
										for (var k = 0; k < incoming_Maximo_Relate_Log_Length; k++) {

											const date = new Date(incomingdata.customTableValues.Maximo_Related_Logs[k].Memo_Date);
											var Memo_Date = date.toISOString();
											var beforePlus = Memo_Date.split('.').shift();
											var Memo_DateUTC = beforePlus + 'Z';
											memoPayload = {
												"Memo_Detail": incomingdata.customTableValues.Maximo_Related_Logs[k].Memo_Detail,
												"Memo_Date": Memo_DateUTC
											}

											Maximo_Related_Logs_array.push(memoPayload);
										}

										payload.customTableValues.Maximo_Related_Logs = Maximo_Related_Logs_array;
									}
								}
							}
							//Memo_Date
							var Request_Created_For = incomingdata.customFieldValues.Request_Created_For;
							if (Request_Created_For === null || Request_Created_For === '') {
								payload.customFieldValues.Request_Created_For = null;
							} else if (Request_Created_For === undefined) {

							} else { payload.customFieldValues.Request_Created_For = Request_Created_For; }
							//plannedStart
							if (incomingdata.plannedStart === null || incomingdata.plannedStart === '') {
								payload.plannedStart = null;
							} else if (incomingdata.plannedStart === undefined) {

							} else {
								const date = new Date(incomingdata.plannedStart);
								var plannedStartdate = date.toISOString();
								var beforePlus = plannedStartdate.split('.').shift();
								var plannedStartdateUTC = beforePlus + 'Z';
								payload.plannedStart = plannedStartdateUTC;
							}
							//plannedStart
							//plannedEnd
							if (incomingdata.plannedEnd === null || incomingdata.plannedEnd === '') {
								payload.plannedEnd = null;
							} else if (incomingdata.plannedEnd === undefined) {

							} else {
								const date = new Date(incomingdata.plannedEnd);
								var plannedEnddate = date.toISOString();
								var beforePlus = plannedEnddate.split('.').shift();
								var plannedEnddateUTC = beforePlus + 'Z';
								payload.plannedEnd = plannedEnddateUTC;
							}
							//plannedEnd
							var Ready_To_Process = incomingdata.customFieldValues.Ready_To_Process;
							if (Ready_To_Process === null || Ready_To_Process === '') {
								payload.customFieldValues.Ready_To_Process = null;
							} else if (Ready_To_Process === undefined) {

							} else { payload.customFieldValues.Ready_To_Process = Ready_To_Process; }

							var Interconnection = incomingdata.customFieldValues.Interconnection;
							if (Interconnection === null || Interconnection === '') {
								payload.customFieldValues.Interconnection = null;
							} else if (Interconnection === undefined) {

							} else { payload.customFieldValues.Interconnection = Interconnection; }
							var Provisional = incomingdata.customFieldValues.Provisional;
							if (Provisional === null || Provisional === '') {
								payload.customFieldValues.Provisional = null;
							} else if (Provisional === undefined) {

							} else { payload.customFieldValues.Provisional = Provisional; }

							var Customer_Arrangements = incomingdata.customFieldValues.Customer_Arrangements;
							if (Customer_Arrangements === null || Customer_Arrangements === '') {
								payload.customFieldValues.Customer_Arrangements = null;
							} else if (Customer_Arrangements === undefined) {

							} else { payload.customFieldValues.Customer_Arrangements = Customer_Arrangements; }

							var Prearranger_Name = incomingdata.customFieldValues.Prearranger_Name;
							if (Prearranger_Name === null || Prearranger_Name === '') {
								payload.customFieldValues.Prearranger_Name = null;
							} else if (Prearranger_Name === undefined) {

							} else { payload.customFieldValues.Prearranger_Name = Prearranger_Name; }
						}//
						//						var identifier = ctx.getVariable("identifier");
						//						if(identifier === undefined || identifier === '' || identifier === null){
						//						//	payload.customFieldValues.Position_in_Manual = "";
						//						} else {
						//							payload.customFieldValues.Position_in_Manual = identifier;
						//						}
						if (incomingdata.customFieldValues.Switching_Start === '' || incomingdata.customFieldValues.Switching_Start === null) {
							payload.customFieldValues.Switching_Start = null;
						} else if (incomingdata.customFieldValues.Switching_Start === undefined) {

						} else {
							const date = new Date(incomingdata.customFieldValues.Switching_Start);
							var Switching_Startdate = date.toISOString();
							var beforePlus = Switching_Startdate.split('.').shift();
							var Switching_StartdateUTC = beforePlus + 'Z';
							payload.customFieldValues.Switching_Start = Switching_StartdateUTC;
						}
						//Switching_Start
						//Switching_End
						if (incomingdata.customFieldValues.Switching_End === '' || incomingdata.customFieldValues.Switching_End === null) {
							payload.customFieldValues.Switching_End = null;
						} else if (incomingdata.customFieldValues.Switching_End === undefined) {

						} else {
							const date = new Date(incomingdata.customFieldValues.Switching_End);
							var Switching_Enddate = date.toISOString();
							var beforePlus = Switching_Enddate.split('.').shift();
							var Switching_EnddateUTC = beforePlus + 'Z';
							payload.customFieldValues.Switching_End = Switching_EnddateUTC;
						}
						//Switching_End
						//Pre_Switch_Date 
						if (incomingdata.customFieldValues.Pre_Switch_Date === '' || incomingdata.customFieldValues.Pre_Switch_Date === null) {
							payload.customFieldValues.Pre_Switch_Date = null;
						} else if (incomingdata.customFieldValues.Pre_Switch_Date === undefined) {

						} else {
							const date = new Date(incomingdata.customFieldValues.Pre_Switch_Date);
							var Pre_Switch_Datedate = date.toISOString();
							var beforePlus = Pre_Switch_Datedate.split('.').shift();
							var Pre_Switch_DatedateUTC = beforePlus + 'Z';
							payload.customFieldValues.Pre_Switch_Date = Pre_Switch_DatedateUTC;
						}

						var ctx = session.name('SOM') || session.createContext('SOM');
						ctx.setVar("PatchSomRequest", payload);

						session.output.write(payload);

						///api/v1/switch-order/{id}
						var GetSwitchOrderResponseData;
						if (responsecode == '200') {
							GetSwitchOrderResponseData = JSON.parse(ctx.getVar("GetSwitchOrderResponseData"));
						} else {
							GetSwitchOrderResponseData = ctx.getVar("GetSwitchOrderResponseData");
						}
						var GetSwitchOrderResponseDataId = GetSwitchOrderResponseData.id;
						var omsExternalURL = session.parameters.omsExternalURL + 'api/v1/switch-order/' + GetSwitchOrderResponseDataId;
						//var omsExternalURL = 'https://adms-test1.dteco.com:443/somplanner/external/'+'api/v1/switch-order/'+GetSwitchOrderResponseDataId;
						var apiToken = session.parameters.osiApiToken;
						var SOMCreateuri = omsExternalURL;
						var TokenValue = apiToken;
						var SOMCreateapi = {
							target: SOMCreateuri,
							sslClientProfile: 'OMS_SOM_Client_Profile',
							method: 'PATCH',
							contentType: 'application/json',
							data: payload,
							headers: {
								'osiApiToken': TokenValue
							},
						};
						session.output.write(payload);
						var info = " TargetURL :" + SOMCreateapi.target + "; Method :" + SOMCreateapi.method + "; Data :" + JSON.stringify(SOMCreateapi.data) + ". ";
						try {
							urlopen.open(SOMCreateapi, function(error, response) {
								if (error) {
									var errorinfo = "SOM_AM_007 : url connection error 'SOMCreateuri', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ErrorDescription', errorinfo);
									//logger.error(errorinfo);
									var ctx = session.name("SOM") || session.createContext("SOM");
									ctx.setVariable("retry", 'yes');
									var ErrorTxt = "SOM_AM_007 urlopen in service SOM_AMCreateUpdateSwithOrderconnect error with Patch call for  SOMPatchpi " + JSON.stringify(error);
									ctx.setVariable("ErrorTxt", errorinfo);
								} else {
									var responseStatusCode = response.statusCode;
									var ServerErrorCode = session.parameters.ServerErrorCode;
									var ErrorCodeList = ServerErrorCode.split(',');
									var flagvalue;

									for (var i = 0; i < ErrorCodeList.length; i++) {
										var numberval = Number(ErrorCodeList[i]);
								
										// Convert responseStatusCode to string and check if it includes the numberval
										if (String(responseStatusCode).includes(String(numberval))) {
											flagvalue = 'yes';
											//logger.error("line no 68"+flagvalue)
										}
									}
									var ctx = session.name("SOM") || session.createContext("SOM");
									var statusID = GetSwitchOrderResponseData.statusID;
									var tostate_value = ctx.getVar("toStateID_LookupUpdate");
									var WorkflowRequired;

									if (statusID == tostate_value) {

										WorkflowRequired = 'yes';

									} else {
										WorkflowRequired = 'no';
									}
									if (responseStatusCode == 200) {
										var errorinfo = "error reading response 'SOMCreateuri', details are : " + info + "; error info :" + error
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												ILSctx.setVariable('ExitStatus', '0');
												ILSctx.setVariable('ExitDescription', ExitDescription);
												hm.response.statusCode = responseStatusCode;
												hm.response.statusCode = responseStatusCode;

												var ctx = session.name("SOM") || session.createContext("SOM");
												var statusID = GetSwitchOrderResponseData.statusID;
												var tostate_value = ctx.getVar("toStateID_LookupUpdate");
												if (statusID == tostate_value || tostate_value == undefined) {
													var displayID;
													var ctx = session.name("SOM") || session.createContext("SOM");
													var customId = GetSwitchOrderResponseData.customId;
													displayID = ctx.getVar("DTE_EXTERNALID2");
													if (displayID == undefined || displayID == '' || displayID == null) {
														displayID = customId;
													} else {
														displayID = ctx.getVar("DTE_EXTERNALID2");
													}
													var ctx = session.name("SOM") || session.createContext("SOM");
													var IncomingCreationDateTime = ctx.getVar("IncomingCreationDateTime");
													var statusissue = ctx.getVar("StatusIssue");
													var messageId = ctxSeq.getVariable("messageId");
													var TicketId = ctx.getVar("TICKETID");
													var orderType = ctx.getVar("CLASSIFICATIONID");

													var PayloadAddon = {

														"maximoID": TicketId,
														"timeStamp": IncomingCreationDateTime,
														"orderType": orderType,
														"orderStatus": toState,
														"messageID": messageId,
														"somID": somID

													}
													var MaximoPositiveUpdateResponsePayload = {
														"ticketid": TicketId,
														"status": "PositiveAcknowledge",
														"dte_ticket": [
															{
																"dte_externalid2": displayID
															}
														],
														"esbData": PayloadAddon
													}
													ctx.setVar("MaximoPositiveUpdateResponsePayload", MaximoPositiveUpdateResponsePayload);
													//start calling maximoResponsecall api
													var Queueurl = session.parameters.BackendMQurl;
													var test = maximoResponsecall(Queueurl, MaximoPositiveUpdateResponsePayload);
													//var incomingPayload = ctxSeq.getVariable("IncomingPayload");
													//SEQResponse(seqResponse);		
												} else {
													//post workflow start /api/v1/switch-order/{id}/workflow
													var ctx = session.name("SOM") || session.createContext("SOM");
													var tostate_value = ctx.getVar("toStateID_LookupUpdate");

													var customId = JSON.parse(responseData).customId;
													var id = GetSwitchOrderResponseData.id;
													var payload = {
														"toStateID": tostate_value
													}
													var omsExternalURL = session.parameters.omsExternalURL + 'api/v1/switch-order/' + id + '/workflow';
													var apiToken = session.parameters.osiApiToken;
													var SOMPosturi = omsExternalURL;
													var TokenValue = apiToken;
													var SOMPostapi = {
														target: SOMPosturi,
														sslClientProfile: 'OMS_SOM_Client_Profile',
														method: 'POST',
														contentType: 'application/json',
														data: payload,
														headers: {
															'osiApiToken': TokenValue
														},
													};

													var info = " TargetURL :" + SOMPostapi.target + "; Method :" + SOMPostapi.method + "; Data :" + JSON.stringify(SOMPostapi.data) + ". ";
													try {
														urlopen.open(SOMPostapi, function(error, response) {
															if (error) {
																var errorinfo = "SOM_AM_006 : url connection error 'SOMPosturi', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ErrorDescription', errorinfo);
																//	logger.error(errorinfo);
																var ctx = session.name("SOM") || session.createContext("SOM");
																ctx.setVariable("retry", 'yes');
																logger.debug("urlopen connect error with post call for  SOMUpdatePostapi " + JSON.stringify(error));
																var ErrorTxt = "SOM_AM_006 in service SOM_AMCreateUpdateSwithOrder urlopen connect error with workflow post call for  SOMUpdatePostapi " + JSON.stringify(error);
																ctx.setVariable("ErrorTxt", errorinfo);
															} else {
																var responseStatusCode = response.statusCode;
																var ServerErrorCode = session.parameters.ServerErrorCode;
																var ErrorCodeList = ServerErrorCode.split(',');
																var flagvalue;

																for (var i = 0; i < ErrorCodeList.length; i++) {
																	var numberval = Number(ErrorCodeList[i]);
																		// Convert responseStatusCode to string and check if it includes the numberval
																	if (String(responseStatusCode).includes(String(numberval))) {
																		flagvalue = 'yes';
																		//logger.error("line no 68"+flagvalue)
																	}
																}

																if (responseStatusCode == 200) {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'SOMPosturi', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			ILSctx.setVariable('ExitStatus', '0');
																			ILSctx.setVariable('ExitDescription', ExitDescription);
																			//store status code with response body in context variable
																			hm.response.statusCode = responseStatusCode;
																			hm.response.statusCode = responseStatusCode;
																			var displayID;
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			displayID = ctx.getVar("DTE_EXTERNALID2");
																			var customId = GetSwitchOrderResponseData.customId;
																			if (displayID == undefined || displayID == '' || displayID == null) {
																				displayID = customId;
																			} else {
																				displayID = ctx.getVar("DTE_EXTERNALID2");
																			}
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var TicketId = ctx.getVar("TICKETID");
																			var IncomingCreationDateTime = ctx.getVar("IncomingCreationDateTime");
																			var statusissue = ctx.getVar("StatusIssue");
																			var messageId = ctxSeq.getVariable("messageId");
																			var orderType = ctx.getVar("CLASSIFICATIONID");

																			var PayloadAddon = {

																				"maximoID": TicketId,
																				"timeStamp": IncomingCreationDateTime,
																				"orderType": orderType,
																				"orderStatus": toState,
																				"messageID": messageId,
																				"somID": somID

																			}
																			var MaximoPositiveUpdateResponsePayload = {
																				"ticketid": TicketId,
																				"status": "PositiveAcknowledge",
																				"dte_ticket": [
																					{
																						"dte_externalid2": displayID
																					}
																				],
																				"esbData": PayloadAddon
																			}
																			ctx.setVar("MaximoPositiveUpdateResponsePayload", MaximoPositiveUpdateResponsePayload);
																			//start calling maximoResponsecall api
																			var Queueurl = session.parameters.BackendMQurl;
																			var test = maximoResponsecall(Queueurl, MaximoPositiveUpdateResponsePayload);
																			//var incomingPayload = ctxSeq.getVariable("IncomingPayload");
																			//SEQResponse(seqResponse);
																			//end calling maximoResponsecall api
																			//
																		}
																	});
																} else if (flagvalue === 'yes') {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var errorinfo = "error reading response 'SOM POST api', details are: " + info + "; error info: " + error;
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ctx.setVariable("retry", 'yes');
																			//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
																			var ErrorTxt = "SOM_AM_003 in service SOM_AMCreateUpdateSwithOrder urlopen connect error returned from Get Switch order api " + JSON.stringify(error);
																			ctx.setVariable("ErrorTxt", errorinfo);
																			logger.error(errorinfo);
																			//	session.reject(errorinfo);
																		} else {
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var errorinfo = "error response 'SOM POST API', details are : " + info + "; response info :" + JSON.stringify(responseData)
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ctx.setVariable("retry", 'yes');
																			//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
																			var ErrorTxt = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData);
																			ctx.setVariable("ErrorTxt", errorinfo);
																			logger.error(errorinfo);
																			//	session.reject(errorinfo);
																		}
																	});
																} else if ((responseStatusCode == 401)) {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "SOM_AM_09 : Unauthorized error message while reading response for post call 'SOMPosturi', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var errorinfo = "SOM_AM_09 : Unauthorized error message response for post call 'SOMPosturi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			var reasonphrase = response.reasonphrase;
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);;
																		}
																	});

																} else if ((responseStatusCode == 403)) {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "SOM_AM_10 : Forbidden error message while reading response for poat call 'SOMPosturi', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var errorinfo = "SOM_AM_10 : Forbidden error message response for post call 'SOMPosturi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}
																	});

																} else {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'SOMPosturi', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var errorinfo = "error response 'SOMCreateuri', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ErrorDescription', errorinfo);
																			logger.error(errorinfo);
																			var ctx = session.name("SOM") || session.createContext("SOM");
																			var TicketId = ctx.getVar("TICKETID");

																			var IncomingCreationDateTime = ctx.getVar("IncomingCreationDateTime");
																			var statusissue = ctx.getVar("StatusIssue");
																			var messageId = ctxSeq.getVariable("messageId");
																			var orderType = ctx.getVar("CLASSIFICATIONID");
																			//		var somID = ctx.getVar("DTE_EXTERNALID2");
																			var PayloadAddon = {

																				"maximoID": TicketId,
																				"timeStamp": IncomingCreationDateTime,
																				"orderType": orderType,
																				"orderStatus": toState,
																				"messageID": messageId,
																				"somID": somID

																			}
																			var MaximoNegativeUpdateResponsePayload;
																			if (responseData == undefined || responseData === null || responseData == '') {
																				MaximoNegativeUpdateResponsePayload = {
																					"ticketid": TicketId,
																					"status": "NegativeAcknowledge",
																					"np_statusmemo": responseStatusCode + ' ' + response._response.reasonPhrase,
																					"esbData": PayloadAddon
																				}
																			} else {
																				var responseData_Negavetive = responseStatusCode + ' ' + responseData;
																				var np_statusmemo = responseData_Negavetive.slice(0, 99);
																				MaximoNegativeUpdateResponsePayload = {
																					"ticketid": TicketId,
																					"status": "NegativeAcknowledge",
																					"np_statusmemo": np_statusmemo,
																					"esbData": PayloadAddon
																				}
																			}
																			ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
																			//logger.debug(" Error returned from SOMCreateapi with  statusCode " + responseStatusCode+" "+ response._response.reasonPhrase);
																			//start calling maximoResponsecall api
																			var Queueurl = session.parameters.BackendMQurl;
																			var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
																			//var incomingPayload = ctxSeq.getVariable("IncomingPayload");
																			//SEQResponse(seqResponse);
																			//end calling maximoResponsecall api
																		}
																	});
																}
															}
														});
													} catch (err) {
														var errorinfo = "SOM_AM_006 : url connection error 'SOMPosturi', details are : " + info + "; error info :" + err
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('ErrorDescription', errorinfo);
														logger.error(errorinfo);
														var ctx = session.name("SOM") || session.createContext("SOM");
														ctx.setVariable("retry", 'yes');
														logger.debug("urlopen connect error with post call for  SOMUpdatePostapi " + JSON.stringify(error));
														var ErrorTxt = "SOM_AM_006 in service SOM_AMCreateUpdateSwithOrder urlopen connect error with workflow post call for  SOMUpdatePostapi " + JSON.stringify(error);
														ctx.setVariable("ErrorTxt", errorinfo);
													}
												}//else closing
												//post workflow end
											}
										});
									} else if ((responseStatusCode == 401)) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "SOM_AM_07 : Unauthorized error message while reading response for patch call 'SOMCreateuri', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "SOM_AM_07 : Unauthorized error message response for patch call 'SOMCreateuri', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												var reasonphrase = response.reasonphrase;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});

									} else if ((responseStatusCode == 403)) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "SOM_AM_08 : Forbidden error message while reading response for patch call 'SOMCreateuri', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "SOM_AM_08 : Forbidden error message response for patch call 'SOMCreateuri', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});
									} else if (flagvalue === 'yes') {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var ctx = session.name("SOM") || session.createContext("SOM");
												var errorinfo = "error reading response 'SOMCreateuri', details are: " + info + "; error info: " + error;
												ILSctx.setVariable('ErrorDescription', errorinfo);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ctx.setVariable("retry", 'yes');
												//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
												var ErrorTxt = "SOM_AM_003 in service SOM_AMCreateUpdateSwithOrder urlopen connect error returned from PATCH Switch order api " + JSON.stringify(error);
												ctx.setVariable("ErrorTxt", errorinfo);
												logger.error(errorinfo);
												//	session.reject(errorinfo);
											} else {
												var ctx = session.name("SOM") || session.createContext("SOM");
												var errorinfo = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData)
												ILSctx.setVariable('ErrorDescription', errorinfo);
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ctx.setVariable("retry", 'yes');
												//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
												var ErrorTxt = "error response 'PATCHapi', details are : " + info + "; response info :" + JSON.stringify(responseData);
												ctx.setVariable("ErrorTxt", errorinfo);
												logger.error(errorinfo);
												//	session.reject(errorinfo);
											}
										});
									} else if ((responseStatusCode == 409 || responseStatusCode == 404)) {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'SOMCreateuri', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "error response 'SOMCreateuri', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												var ctx = session.name("SOM") || session.createContext("SOM");
												var IncomingCreationDateTime = ctx.getVar("IncomingCreationDateTime");
												var statusissue = ctx.getVar("StatusIssue");
												var messageId = ctxSeq.getVariable("messageId");
												var TicketId = ctx.getVar("TICKETID");
												var orderType = ctx.getVar("CLASSIFICATIONID");

												var PayloadAddon = {

													"maximoID": TicketId,
													"timeStamp": IncomingCreationDateTime,
													"orderType": orderType,
													"orderStatus": toState,
													"messageID": messageId,
													"somID": somID

												}
												var MaximoNegativeUpdateResponsePayload;
												if (responseData == undefined || responseData === null || responseData == '') {
													MaximoNegativeUpdateResponsePayload = {
														"ticketid": TicketId,
														"status": "NegativeAcknowledge",
														"np_statusmemo": responseStatusCode + ' ' + response._response.reasonPhrase,
														"esbData": PayloadAddon
													}
												} else {
													var responseData_Negavetive = responseStatusCode + ' ' + responseData;
													var np_statusmemo = responseData_Negavetive.slice(0, 99);
													MaximoNegativeUpdateResponsePayload = {
														"ticketid": TicketId,
														"status": "NegativeAcknowledge",
														"np_statusmemo": np_statusmemo,
														"esbData": PayloadAddon
													}
												}
												ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
												//logger.debug(" Error returned from SOMCreateapi with  statusCode " + responseStatusCode+" "+ response._response.reasonPhrase);
												//start calling maximoResponsecall api
												var Queueurl = session.parameters.BackendMQurl;
												var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
												//var incomingPayload = ctxSeq.getVariable("IncomingPayload");
												//SEQResponse(seqResponse);
											}
										});


									}
									else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'SOMCreateuri', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "error response 'SOMCreateuri', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ErrorDescription', errorinfo);
												logger.error(errorinfo);
												var ctx = session.name("SOM") || session.createContext("SOM");
												var IncomingCreationDateTime = ctx.getVar("IncomingCreationDateTime");
												var statusissue = ctx.getVar("StatusIssue");
												var messageId = ctxSeq.getVariable("messageId");
												var TicketId = ctx.getVar("TICKETID");
												var orderType = ctx.getVar("CLASSIFICATIONID");
												//	var somID = ctx.getVar("DTE_EXTERNALID2");
												var PayloadAddon = {

													"maximoID": TicketId,
													"timeStamp": IncomingCreationDateTime,
													"orderType": orderType,
													"orderStatus": toState,
													"messageID": messageId,
													"somID": somID

												}
												var MaximoNegativeUpdateResponsePayload;
												if (responseData == undefined || responseData === null || responseData == '') {
													MaximoNegativeUpdateResponsePayload = {
														"ticketid": TicketId,
														"status": "NegativeAcknowledge",
														"np_statusmemo": responseStatusCode + ' ' + response._response.reasonPhrase,
														"esbData": PayloadAddon
													}
												} else {
													var responseData_Negavetive = responseStatusCode + ' ' + responseData;
													var np_statusmemo = responseData_Negavetive.slice(0, 99);
													MaximoNegativeUpdateResponsePayload = {
														"ticketid": TicketId,
														"status": "NegativeAcknowledge",
														"np_statusmemo": np_statusmemo,
														"esbData": PayloadAddon
													}
												}
												ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
												//logger.debug(" Error returned from SOMCreateapi with  statusCode " + responseStatusCode+" "+ response._response.reasonPhrase);
												//start calling maximoResponsecall api
												var Queueurl = session.parameters.BackendMQurl;
												var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
												//var incomingPayload = ctxSeq.getVariable("IncomingPayload");

												//SEQResponse(seqResponse);
											}
										});
										//				var ctx = session.name("SOM")|| session.createContext("SOM");
										//								var TicketId = ctx.getVar("TICKETID");
										//								var MaximoNegativeUpdateResponsePayload = {
										//																"ticketid":TicketId,
										//																"status":"NegativeAcknowledge",
										//																"np_statusmemo": responseStatusCode+' '+responseData
										//															}
										//									 ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);	
										//								logger.debug(" Error returned from SOMCreateapi with  statusCode " + responseStatusCode+" "+ responseData);
										//											  //start calling maximoResponsecall api
										//        			var Queueurl = session.parameters.BackendMQurl;
										//        			var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
									}
								}
							});
						} catch (err) {
							var errorinfo = "SOM_AM_007 : url connection error 'SOMCreateuri', details are : " + info + "; error info :" + err
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ErrorDescription', errorinfo);
							logger.error(errorinfo);
							var ctx = session.name("SOM") || session.createContext("SOM");
							ctx.setVariable("retry", 'yes');
							var ErrorTxt = "SOM_AM_007 urlopen in service SOM_AMCreateUpdateSwithOrderconnect error with Patch call for  SOMPatchpi " + JSON.stringify(error);
							ctx.setVariable("ErrorTxt", errorinfo);
						}
					}//if time condition
				}//200
			}//if retry check
		}//if maximoresponse label check
	}
});
function maximoResponsecall(url, Data) {
	var ctx = session.name("SOM") || session.createContext("SOM");
	var StandaloneMQurl = url;
	var payload = Data;
	var MaximoResponseApi = {
		target: StandaloneMQurl,
		data: payload
	};
	var info = " TargetURL: " + MaximoResponseApi.target + "; Data: " + JSON.stringify(MaximoResponseApi.data) + ". ";
	try {
		urlopen.open(MaximoResponseApi, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error 'MaximoResponseApi', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				ILSctx.setVariable('ExitDestination', StandaloneMQurl);
				var ctx = session.name("SOM") || session.createContext("SOM");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "error reading response 'MaximoResponseApi', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', mqrc);
							ILSctx.setVariable('ErrorDescription', errorinfo)
							ILSctx.setVariable('ExitDestination', StandaloneMQurl);
							hm.response.statusCode = 500
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							ILSctx.setVariable('ExitStatus', '0');
							ILSctx.setVariable('StepExitDescription', MaximoResponseExitDescription);
							ILSctx.setVariable('exitDestination', MaximoResponseApi.target);
							ms.callRule('SOM_AMCreateUpdateSwitchOrder_Processing_Policy_StepExit', null, null, function(error) {
								if (error) {
								}
							});
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var errorinfo = "error response 'MaximoResponseApi', details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitStatus', mqrc);
					ILSctx.setVariable('ErrorDescription', errorinfo)
					ILSctx.setVariable('ExitDestination', StandaloneMQurl);
					var ctx = session.name("SOM") || session.createContext("SOM");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error 'MaximoResponseApi', details are : " + info + "; error info :" + err
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		ILSctx.setVariable('ExitDestination', StandaloneMQurl);
		var ctx = session.name("SOM") || session.createContext("SOM");
		var mqconnection = 'Forbidden';
		ctx.setVariable("mqconnection", mqconnection);
		logger.error(errorinfo);
		session.reject(errorinfo);
	}
}

/*
function SEQResponse(seqResponse){
	var targetQueue = session.parameters.SeqConfirmationURL;
	var options = {
			target:targetQueue,
			data: seqResponse
	};
	urlopen.open(options, function(error, response){
		var hm = require('header-metadata');
		if(error){
			logger.error('SOM 32ab:SOM_AMCreateUpdateSwitchOrder Seq Confirmation Mqurlopen.open error');
			var ErrorTxt = "Mqurlopen.open error";
			ctx.setVariable("ErrorTxt", ErrorTxt);
			ctx.setVariable("retry", 'yes');
			//session.reject('** Mqurlopen.open error');
			hm.response.statusCode = 500;
		} else {
			var mqrc = response.statusCode;
			if(mqrc == 0){
				response.readAsBuffer(function(readError, responseData){
					if(readError){
						hm.response.statusCode = 500
						logger.error('SOM 32ab:SOM_AMCreateUpdateSwitchOrder Seq Confirmation Mqurlopen.open error '+readError);
						session.reject( 'Mqurlopen.open error');
					} else {
						console.log("MQResponseData "+ responseData);
					}
				});
			} else {
				logger.error('SOM 32ab:SOM_AMCreateUpdateSwitchOrder Seq Confirmation Mqurlopen.open error [MQRC=' + mqrc + ']');
				session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
				hm.response.statusCode = 500
			}
		}
	});
}*/
