// Import required modules
var urlopen = require('urlopen');
var logger = console.options({
	'category': 'all'
});

// Create contexts
var ctx = session.name("SOM") || session.createContext("SOM");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var DTE_POSITION_IN_MANUAL = ctx.getVariable("DTE_POSITION_IN_MANUAL");
var DTE_AFFTDBYPERDISPNAMECheck = ctx.getVariable("DTE_AFFTDBYPERDISPNAMECheck");
// Define a label variable
var label;

// Extract DTE_POSITION_IN_MANUAL from incomingData

if((DTE_POSITION_IN_MANUAL == undefined )){
	}else{
if (DTE_POSITION_IN_MANUAL === 'Y') {
	label = "Yes";
	ctx.setVariable('label', 'Yes');
} else if(DTE_POSITION_IN_MANUAL === 'N') {
	label = "No";
	ctx.setVariable('label', 'No');
}
else{
	ctx.setVariable('label', '');
}
// Define the Positionlookup object
var Positionlookup = {
	"lookupReq": {
		"type": [{
			"name": "Position_in_Manual",
			"label": label
		}]
	}
};

if(DTE_POSITION_IN_MANUAL !=undefined || DTE_POSITION_IN_MANUAL !='' || DTE_POSITION_IN_MANUAL !=null){

// Define the URL for the lookup service
var url = session.parameters.lookupUrl;

// Define the LookupServiceResponse
var LookupServiceResponse = {
	target: url,
	method: 'POST',
	contentType: 'application/json',
	data: Positionlookup
};

// Prepare info for logging
var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "; Data: " + JSON.stringify(LookupServiceResponse.data) + ". ";

// Open the URL using urlopen
urlopen.open(LookupServiceResponse, function(error, response) {
	if (error) {
		var errorinfo = "URL open connection error 'LookupServiceResponse', details are: " + info + "; error info: " + error;
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo);
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {
		var responseStatusCode = response.statusCode;
		if (responseStatusCode === 200) {
			response.readAsBuffer(function(error, responseData) {
				if (error) {
					var errorinfo = "Error in reading response from 'LookupServiceResponse', details are: " + info + "; error info: " + error;
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ErrorDescription', responseStatusCode);
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					// Process the response data
					var lookupResponse = JSON.parse(responseData);

					if (lookupResponse.lookupRep.type[0].result == 0) {
						var resplabel = lookupResponse.lookupRep.type[0].status;
						if (!(resplabel === undefined || resplabel === null || resplabel === '')) {
							if (resplabel === 0) {
								// Handle the case where resplabel is 0
								ctx.setVariable("identifier", resplabel);
							}
							else {
							// Set the "identifier" variable to '1'
							ctx.setVariable("identifier", resplabel);
						}
						} 
					}
				}
			});
		}
	}
});
}
}
