var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("SOM") || session.createContext("SOM");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var respdata = ctx.getVariable("GetSwitchOrderResponseData");
var ExitDescription = session.parameters.ExitDescription
if (!(respdata === undefined || respdata === null || respdata === '')) {
	if (!(respdata.status === undefined || respdata.status === null || respdata.status === '')) {
		var status = respdata.status;
		var statusid = respdata.statusID;
		var Statuslookup = {
			"lookupReq": {
				"type": [
					{
						"name": "switchOrder.WorkFlowStatus",
						"id": statusid,
						"status": status
					}
				]
			}
		}
		var url = session.parameters.lookupUrl;
		var LookupServiceResponse = {
			target: url,
			method: 'POST',
			contentType: 'application/json',
			data: Statuslookup
		};
		var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
		urlopen.open(LookupServiceResponse, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'Statuslookup', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ErrorDescription', errorinfo);
				//session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'LookUp Statuslookup', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ErrorDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							// hm.response.statusCode = responseStatusCode;
							ILSctx.setVariable('ExitStatus', '0');
							ILSctx.setVariable('ExitDescription', ExitDescription);
							logger.debug("response received from LookupServiceResponse " + responseStatusCode);
							var lookupResponse = JSON.parse(responseData);
							var resplabel = lookupResponse.lookupRep.type[0].label;
							if (resplabel == undefined || resplabel == null || resplabel == '') {
								ctx.setVariable("label", '');
							} else {
								ctx.setVariable("label", resplabel);

							}

						}
					});
				}
			}
		});
	}
}
