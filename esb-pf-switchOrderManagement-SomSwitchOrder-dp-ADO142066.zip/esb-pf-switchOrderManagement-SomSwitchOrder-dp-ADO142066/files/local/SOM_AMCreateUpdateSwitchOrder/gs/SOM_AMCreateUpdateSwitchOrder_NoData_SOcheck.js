//js is used for lookup calls, please check mapping sheet for complete details
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ms = require('multistep');
var logger = console;
logger.options({
	'category': 'all'
});
var ctx = session.name("SOM") || session.createContext("SOM");
var ILSctx = session.name("ILS") || session.createContext("ILS");

//SOM Sequence confirmation call
var ctxSeq = session.name("SOM_CreateUpdate_seq") || session.createContext("SOM_CreateUpdate_seq");
var SeqConfirmation = session.parameters.SeqConfirmationURL;
var messageId = ctxSeq.getVariable("messageId");
var eventType = ctxSeq.getVariable("eventType");
var serviceName = ctxSeq.getVariable("serviceName");
var dateTime = new Date();
var sendTimeStamp = dateTime.toISOString();
var eventContext = ctxSeq.getVariable("eventContext");
var EventTimeStamp = ctxSeq.getVariable("EventTimeStamp");
var ExitDescription = session.parameters.ExitDescription;
var MaximoResponseExitDescription = session.parameters.MaximoResponseExitDescription;
var SeqConfExitDescription = session.parameters.SeqConfExitDescription;
var omsExternalURL = session.parameters.omsExternalURL;
var Queueurl = session.parameters.BackendMQurl;
var messageType = ctxSeq.getVar("messageType");
ILSctx.setVariable('exitDestination', omsExternalURL);
//Sequence Confirmation req
var seqResponse = {
	"messageId": messageId,
	"eventType": eventType,
	"serviceName": serviceName,
	"sendTimeStamp": sendTimeStamp,
	"messageType": messageType,
	"confirmation": 'Y'
};
if (eventContext != undefined || eventContext != null || eventContext != '') {
	seqResponse.eventContext = eventContext;
}
if (EventTimeStamp != undefined || EventTimeStamp != null || EventTimeStamp != '') {
	seqResponse.EventTimeStamp = EventTimeStamp;
}
var targetQueue = session.parameters.SeqConfirmationURL;
var options = {
	target: targetQueue,
	data: seqResponse
};
var info = " TargetURL: " + options.target + "; Data: " + JSON.stringify(options.data) + ". ";
try {
	urlopen.open(options, function(error, response) {
		var hm = require('header-metadata');
		if (error) {
			var errorinfo = "SOM 32ab: url connection error 'Seq Confirmation', details are: " + info + "; error info: " + error;
			logger.error(errorinfo);
			ctx.setVariable("ErrorTxt", errorinfo);
			ctx.setVariable("retry", 'yes');
			//session.reject('** Mqurlopen.open error');
			hm.response.statusCode = 500;
			ILSctx.setVariable('ErrorDescription', errorinfo);
			ILSctx.setVariable('ExitStatus', '500');
		} else {
			var mqrc = response.statusCode;
			if (mqrc == 0) {
				response.readAsBuffer(function(readError, responseData) {
					var errorinfo = "SOM 32ab: error reading response 'Seq Confirmation', details are: " + info + "; error info: " + readError;
					if (readError) {
						hm.response.statusCode = 500;
						logger.error(errorinfo);
						ILSctx.setVariable('ErrorDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', mqrc);
						session.reject(errorinfo);
					} else {
						//console.log("MQResponseData " + responseData);
						ILSctx.setVariable('ExitStatus', '0');
						ILSctx.setVariable('StepExitDescription', SeqConfExitDescription);
						ILSctx.setVariable('exitDestination', options.target);
						ms.callRule('SOM_AMCreateUpdateSwitchOrder_Processing_Policy_StepExit', null, null, function(error) {
							if (error) {
							}
						});
					}
				});
			} else {
				var info = " TargetURL: " + options.target + "; Data: " + JSON.stringify(options.data) + ". ";
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						var errorinfo = "SOM 32ab: error reading response 'Seq Confirmation', details are: " + info + "; error info: " + readError;
						hm.response.statusCode = 500;
						logger.error(errorinfo);
						ILSctx.setVariable('ErrorDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', mqrc);
						session.reject(errorinfo);
					} else {
						var errorinfo = "SOM 32ab: error response 'Seq Confirmation', details are: " + info + "; response info: " + JSON.stringify(response);
						logger.error(errorinfo);
						ILSctx.setVariable('ErrorDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						session.reject(errorinfo);
						console.log("MQResponseData " + responseData);
						//ILSctx.setVariable('ExitDescription', errorinfo);
					}
				});
			}
		}
	});
} catch (err) {
	var errorinfo = "SOM 32ab: url connection error 'Seq Confirmation', details are: " + info + "; error info: " + err;
	logger.error(errorinfo);
	ctx.setVariable("ErrorTxt", errorinfo);
	ctx.setVariable("retry", 'yes');
	//session.reject('** Mqurlopen.open error');
	hm.response.statusCode = 500;
	ILSctx.setVariable('ErrorDescription', errorinfo);
	ILSctx.setVariable('ExitStatus', '500');
}

var execute = ctx.getVar("DTE_EXTERNALID2_Present");
var checkretry = ctx.getVar("retry");
var StatusIssue = ctx.getVar("StatusIssue");

if (checkretry != 'yes') {
	if (StatusIssue != 'yes') {
		if (execute == 'no') {
			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "switchOrderinternalId",
							"label": "Maximo_Request_Number"
						}
					]
				}
			};
			var url = session.parameters.lookupUrl;
			//logger.error("+++27");
			var LookupServiceResponse = {
				target: url,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};

			var info = " TargetURL: " + LookupServiceResponse.target + "; Method: " + LookupServiceResponse.method + "; Data: " + JSON.stringify(LookupServiceResponse.data) + ". ";
			try {
				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error with 'Maximo_Request_Number' details are: " + info + "; error info: " + error;
						ILSctx.setVariable('ErrorDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {

							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'Maximo_Request_Number', details are: " + info + "; error info: " + error;
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									ILSctx.setVariable('ExitDescription', ExitDescription);
									ILSctx.setVariable('ExitStatus', '0');
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from Maximo_Request_Number " + responseStatusCode);
									var lookupResponse = JSON.parse(responseData);
									if (lookupResponse.lookupRep.type[0].result == 0) {
										var Maximo_Request_Number_Lookup_id = lookupResponse.lookupRep.type[0].id;
										var ctx = session.name("SOM") || session.createContext("SOM");
										ctx.setVariable("Maximo_Request_Number_Lookup_id", Maximo_Request_Number_Lookup_id);
										var Callapiuri = session.parameters.omsExternalURL + 'api/v1/switch-order?includeFields=customFieldValues,id';
										//logger.error("+++54");
										var test = SwitchOrderGetresponse(Callapiuri, Maximo_Request_Number_Lookup_id);
									} else {
										var invalidresp = "Invalid Lookup Request 'LookUp Maximo_Request_Number', details are: " + info + "; response info: " + responseData + "; ResponseStatusCode: " + responseStatusCode;
										ILSctx.setVariable('ExitStatus', '1');
										ILSctx.setVariable('ErrorDescription', invalidresp);
										logger.error(invalidresp);
										//logger.error("Result 1 for lookup Maximo_Request_Number");
										//session.reject("Result is not 0 for lookup");
										var ctx = session.name("SOM") || session.createContext("SOM");
										var TicketId = ctx.getVar("TICKETID");
										var responsemessage = "500 Lookup Response for given Maximo_Request_Number field value is invalid";
										var np_statusmemo = responsemessage.slice(0, 99);
										MaximoNegativeUpdateResponsePayload = {
											"ticketid": TicketId,
											"status": "NegativeAcknowledge",
											"np_statusmemo": np_statusmemo
										};
										ctx.setVar("MaximoNegativeUpdateResponsePayload", MaximoNegativeUpdateResponsePayload);
										ctx.setVar("LookupMaximoResponse", 'yes');
										//start calling maximoResponsecall api
										var Queueurl = session.parameters.BackendMQurl;
										var test = maximoResponsecall(Queueurl, MaximoNegativeUpdateResponsePayload);
									}
								}
							});
						} else {
							response.readAsBuffer(function(readError, responseData) {
								if (error) {
									var errorinfo = "error reading response 'Maximo_Request_Number', details are: " + info + "; error info: " + readError;
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error reading response 'Maximo_Request_Number', details are: " + info + "; error info: " + responseData;
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			} catch (err) {
				var errorinfo = "urlopen connect error with 'Maximo_Request_Number' details are: " + info + "; error info: " + err;
				ILSctx.setVariable('ErrorDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		} // execute close

		function SwitchOrderGetresponse(url, Maximo_Request_Number_Lookup_id) {
			var TokenValue = session.parameters.osiApiToken;
			var Callapi = {
				target: url,
				sslClientProfile: 'OMS_SOM_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				}
			};
			var info = " TargetURL: " + Callapi.target + "; Method: " + Callapi.method + ". ";
			try {
				urlopen.open(Callapi, function(error, response) {
					if (error) {
						var errorinfo = "SOM_AM_003: urlopen connection error 'Callapi' details are: " + info + "; error info: " + error;
						var ctx = session.name("SOM") || session.createContext("SOM");
						ctx.setVariable("retry", 'yes');
						//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
						var ErrorTxt = "SOM_AM_003 in service SOM_AMCreateUpdateSwithOrder urlopen connect error returned from Get Switch order api " + JSON.stringify(error);
						ctx.setVariable("ErrorTxt", errorinfo);
						ILSctx.setVariable('ErrorDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						//throw error;
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						var ServerErrorCode = session.parameters.ServerErrorCode;
						var ErrorCodeList = ServerErrorCode.split(',');
						var flagvalue;

						for (var i = 0; i < ErrorCodeList.length; i++) {
							var numberval = Number(ErrorCodeList[i]);
							// Convert responseStatusCode to string and check if it includes the numberval
							if (String(responseStatusCode).includes(String(numberval))) {
								flagvalue = 'yes';
								//logger.error("line no 68"+flagvalue)
							}
						}

						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'Callapi' details are: " + info + "; error info: " + error;
									logger.error(errorinfo);
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									session.reject(errorinfo);
								} else {
									//logger.error("+++109");
									//store status code with response body in context variable
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									var ServerErrorCode = session.parameters.ServerErrorCode;
									var ErrorCodeList = ServerErrorCode.split(',');
									var flagvalue;

									for (var i = 0; i < ErrorCodeList.length; i++) {
										var numberval = Number(ErrorCodeList[i]);
										// Convert responseStatusCode to string and check if it includes the numberval
										if (String(responseStatusCode).includes(String(numberval))) {
											flagvalue = 'yes';
											//logger.error("line no 68"+flagvalue)
										}
									}

									logger.debug("response received from SwitchOrdereapi call is " + responseStatusCode);
									var ctx = session.name("SOM") || session.createContext("SOM");
									var SwitchOrderGetresponse = JSON.parse(responseData);
									ctx.setVariable("GetAllSwitchOrderResponse", SwitchOrderGetresponse);
									var GetAllSwitchOrderResponse_length = SwitchOrderGetresponse.data.length;
									ctx.setVariable("GetAllSwitchOrderResponse_length", GetAllSwitchOrderResponse_length);
									ILSctx.setVariable('ExitDescription', ExitDescription);
									ILSctx.setVariable('ExitStatus', '0');

									for (var i = 0; i < GetAllSwitchOrderResponse_length; i++) {
										var internalid = Maximo_Request_Number_Lookup_id;
										var isEmpty = Object.entries(SwitchOrderGetresponse.data[i].customFieldValues).length > 0;
										if (isEmpty == true) {
											var searchpath = SwitchOrderGetresponse.data[i].customFieldValues;
											if (searchpath.hasOwnProperty(internalid)) {
												var myStr = searchpath[internalid];
												//  logger.info(internalid, myStr)
												var TicketId = ctx.getVar("TICKETID");
												if (myStr == TicketId) {
													//logger.error("++++128");
													var id = SwitchOrderGetresponse.data[i].id;
													var GetcallUrl = session.parameters.omsExternalURL + 'api/v1/switch-order/' + id;
													var TokenValue = session.parameters.osiApiToken;

													var GetCallApi = {
														target: GetcallUrl,
														sslClientProfile: 'OMS_SOM_Client_Profile',
														method: 'GET',
														contentType: 'application/json',
														headers: {
															'osiApiToken': TokenValue
														}
													};
													var info = " TargetURL: " + GetCallApi.target + "; Method: " + GetCallApi.method + ". ";
													urlopen.open(GetCallApi, function(error, response) {
														if (error) {
															var errorinfo = "SOM_AM_004: url connection error 'GetCallApi', details are: " + info + "; error info: " + error;
															var ctx = session.name("SOM") || session.createContext("SOM");
															ctx.setVariable("retry", 'yes');
															logger.error(errorinfo);
															var ErrorTxt = "SOM_AM_004 in service SOM_AMCreateUpdateSwithOrder urlopen errorr for get call using id" + id + " is " + JSON.stringify(error);
															ctx.setVariable("ErrorTxt", ErrorTxt);
															ILSctx.setVariable('ErrorDescription', errorinfo);
															ILSctx.setVariable('ExitStatus', '500');
															//logger.error("urlopen errorr for get call using id"+id+ "is "+JSON.stringify(error));
															//session.reject("urlopen errorr for get call using id"+id+ "is "+JSON.stringify(error));
														} else {
															var responseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'GetCallApi', details are: " + info + "; error info: " + error;
																		//dp:reject stop the transaction and go error rule with error code and description
																		logger.error(errorinfo);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		session.reject(errorinfo);
																	} else {
																		//store status code with response body in context variable
																		hm.response.statusCode = responseStatusCode;
																		hm.response.statusCode = responseStatusCode;
																		var ctx = session.name("SOM") || session.createContext("SOM");
																		var GetSwitchOrderResponseData = JSON.parse(responseData);
																		ctx.setVar("GetSwitchOrderResponseData", GetSwitchOrderResponseData);
																		ctx.setVar("GetSwitchOrderUpdateStatus", "Updateoperation");
																		ILSctx.setVariable('ExitDescription', ExitDescription);
																		ILSctx.setVariable('ExitStatus', '0');
																	}
																});
															} else if ((responseStatusCode == 401)) {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "SOM_AM_03 : Unauthorized error message while reading response from SOM GET Callapi , details are : " + info + "; error info :" + JSON.stringify(error)
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = "SOM_AM_03 : Unauthorized error message while reading response from SOM GET Callapi , details are : " + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																});
															} else if ((responseStatusCode == 403)) {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "SOM_AM_04 : Forbidden error message while reading response from SOM GET Callapi , details are : " + info + "; error info :" + JSON.stringify(error)
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = "SOM_AM_04 : Forbidden error message while reading response from SOM GET Callapi , details are : " + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	}
																});
															}
															else if (flagvalue === 'yes') {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var ctx = session.name("SOM") || session.createContext("SOM");
																		var errorinfo = "error reading response 'Callapi', details are: " + info + "; error info: " + error;
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ctx.setVariable("retry", 'yes');
																		//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
																		var ErrorTxt = "SOM_AM_003 in service SOM_AMCreateUpdateSwithOrder urlopen connect error returned from Get Switch order api " + JSON.stringify(error);
																		ctx.setVariable("ErrorTxt", errorinfo);
																		logger.error(errorinfo);
																		//	session.reject(errorinfo);
																	} else {
																		var ctx = session.name("SOM") || session.createContext("SOM");
																		var errorinfo = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData)
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ctx.setVariable("retry", 'yes');
																		//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
																		var ErrorTxt = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData);
																		ctx.setVariable("ErrorTxt", errorinfo);
																		logger.error(errorinfo);
																		//	session.reject(errorinfo);
																	}
																});
															} else {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'GetCallApi' details are" + info + "; error info: " + error;
																		logger.error(errorinfo);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = "error response 'GetCallApi', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		logger.error(errorinfo);
																		ILSctx.setVariable('ErrorDescription', errorinfo);
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		session.reject(errorinfo);
																	}
																});
															}
														}
													});
													//
													//we found a match here with id as internal id nd ticket so breaking and stopping the transaction
													break;
												}
											}
										} //if custom field check
										//logger.error("++++++"+i);
									} //for loop closing
								}
							});
						} else if ((responseStatusCode == 401)) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "SOM_AM_01 : Unauthorized error message while reading response from SOM GET Callapi , details are : " + info + "; error info :" + JSON.stringify(error)
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "SOM_AM_01 : Unauthorized error message while reading response from SOM GET Callapi , details are : " + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						} else if ((responseStatusCode == 403)) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "SOM_AM_02 : Forbidden error message while reading response from SOM GET Callapi , details are : " + info + "; error info :" + JSON.stringify(error)
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "SOM_AM_02 : Forbidden error message while reading response from SOM GET Callapi , details are : " + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
						else if (flagvalue === 'yes') {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var ctx = session.name("SOM") || session.createContext("SOM");
									var errorinfo = "error reading response 'Callapi', details are: " + info + "; error info: " + error;
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ctx.setVariable("retry", 'yes');
									//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
									var ErrorTxt = "SOM_AM_003 in service SOM_AMCreateUpdateSwithOrder urlopen connect error returned from Get Switch order api " + JSON.stringify(error);
									ctx.setVariable("ErrorTxt", errorinfo);
									logger.error(errorinfo);
									//	session.reject(errorinfo);
								} else {
									var ctx = session.name("SOM") || session.createContext("SOM");
									var errorinfo = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData)
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ctx.setVariable("retry", 'yes');
									//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
									var ErrorTxt = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData);
									ctx.setVariable("ErrorTxt", errorinfo);
									logger.error(errorinfo);
									//	session.reject(errorinfo);
								}
							});
						}

						else {
							//execute if not 200
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'Callapi', details are: " + info + "; error info: " + error;
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {

									var errorinfo = "error response 'Callapi', details are : " + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode + " Unauthorized"
									ILSctx.setVariable('ErrorDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			} catch (err) {
				var errorinfo = "SOM_AM_003: urlopen connection error 'Callapi' details are: " + info + "; error info: " + err;
				var ctx = session.name("SOM") || session.createContext("SOM");
				ctx.setVariable("retry", 'yes');
				//logger.debug("urlopen connect error returned from Get Switch order api " + JSON.stringify(error));
				var ErrorTxt = "SOM_AM_003 in service SOM_AMCreateUpdateSwithOrder urlopen connect error returned from Get Switch order api " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", errorinfo);
				ILSctx.setVariable('ErrorDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
			}
		}
		//Main logic close
	} //status issue close
} //retry close
