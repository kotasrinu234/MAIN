<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">
		
		<xsl:variable name="payload">
                          <dp:serialize select="." omit-xml-decl="yes"/>
                        </xsl:variable>
		<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/deflatedPayload'" value="dp:deflate($payload)"/>
		
	
		
       <dp:set-variable name="'var://context/SOM_CreateUpdate_seq/eventContext'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TICKETID']/text())" /> 
		
		
		<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/EventTimeStamp'" value="concat(string(/*[local-name()='PublishDTEMAXSOMSROUT']/@creationDateTime),'')" />
		
	</xsl:template>

</xsl:stylesheet>
