<!-- Xslt is used to perform a GET operation on oms customer api  -->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:param name="dpconfig:osiApiToken"/>
	<xsl:param name="dpconfig:omsExternalURL"/>
	<xsl:template match="/">
		<xsl:variable name="TransactoinID">
			<xsl:copy-of select="dp:variable('var://service/global-transaction-id')"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/OrderStatus'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='STATUS']/text())"/>
		<dp:set-variable name="'var://context/SOM/MaximoStatus'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='STATUS']/text())"/>
		<dp:set-variable name="'var://context/SOM/TICKETID'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TICKETID']/text())"/>
		<dp:set-variable name="'var://context/SOM/IncomingCreationDateTime'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/@creationDateTime)"/>
		<!-- below CLASSIFICATIONID is used in SOM_AMCreateUpdateSwithOrder_lookup.js file for doing lookup in case of create operation -->
		<dp:set-variable name="'var://context/SOM/CLASSIFICATIONID'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='CLASSSTRUCTURE']/*[local-name()='CLASSIFICATIONID']/text())"/>
		<!-- below CLASSIFICATIONID is used in SOM_AMCreateUpdateSwithOrder_lookup.js file for doing lookup in case of create and update operation -->
		<dp:set-variable name="'var://context/SOM/DESCRIPTION'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DESCRIPTION']/text())"/>
		<dp:set-variable name="'var://context/SOM/DTE_WORKLOCATION'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_WORKLOCATION']/text())"/>
		<dp:set-variable name="'var://context/SOM/DTE_Reason_Reject'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REASON_REJECT']/text())"/>
		<xsl:if test="string-length(normalize-space(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_POSITION_IN_MANUAL']/text()))&gt; 0">
			<dp:set-variable name="'var://context/SOM/DTE_POSITION_IN_MANUAL'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_POSITION_IN_MANUAL']/text())"/>
			<dp:set-variable name="'var://context/SOM/DTE_AFFTDBYPERDISPNAMECheck'" value="'yes'"/>
		</xsl:if>
		<!-- DTE_AFFTDBYPERDISPNAME -->
		<xsl:if test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_AFFTDBYPERDISPNAME']">
			<dp:set-variable name="'var://context/SOM/DTE_AFFTDBYPERDISPNAME'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_AFFTDBYPERDISPNAME']/text())"/>
		</xsl:if>
		<!-- DTE_REPBYDISPNAME -->
		<xsl:if test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_REPBYDISPNAME']">
			<dp:set-variable name="'var://context/SOM/DTE_REPBYDISPNAME'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_REPBYDISPNAME']/text())"/>
		</xsl:if>
		<!-- DTE_SUPERDISPNAME -->
		<xsl:if test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_SUPERDISPNAME']">
			<dp:set-variable name="'var://context/SOM/DTE_SUPERDISPNAME'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_SUPERDISPNAME']/text())"/>
		</xsl:if>
		<xsl:variable name="DTE_EXTERNALID2_Present_check">
			<xsl:choose>
				<xsl:when test="string-length(normalize-space(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_EXTERNALID2']/text()))&gt; 0">
					<dp:set-variable name="'var://context/SOM/DTE_EXTERNALID2'" value="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_EXTERNALID2']/text())"/>
					<dp:set-variable name="'var://context/SOM/DTE_EXTERNALID2_Present'" value="string('yes')"/>
					<xsl:value-of select="'yes'"/>
				</xsl:when>
				<xsl:otherwise>
					<dp:set-variable name="'var://context/SOM/DTE_EXTERNALID2_Present'" value="string('no')"/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<dp:set-variable name="'var://context/SOM/DTE_EXTERNALID2_Present_check'" value="string($DTE_EXTERNALID2_Present_check)"/>
		<xsl:if test="contains($DTE_EXTERNALID2_Present_check,'yes')">
			<xsl:variable name="headerValues">
				<header name="Content-Type">application/json</header>
				<header name="osiApiToken">
					<xsl:value-of select="$dpconfig:osiApiToken"/>
				</header>
			</xsl:variable>
			<xsl:variable name="id">
				<xsl:value-of select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_EXTERNALID2']/text()"/>
			</xsl:variable>
			<dp:set-variable name="'var://context/SOM/id'" value="string($id)"/>
			<xsl:variable name="url">
				<xsl:value-of select="concat($dpconfig:omsExternalURL,'api/v1/switch-order/',$id)"/>
			</xsl:variable>
			<!-- $dpconfig:omsExternalURL,'/',$id -->
			<!-- $dpconfig:omsExternalURL,'?searchID=',$id -->
			<xsl:variable name="SwitchOrderApi">
				<dp:url-open target="{$url}" ssl-proxy="client:OMS_SOM_Client_Profile" http-headers="$headerValues" http-method="get" response="responsecode-binary">
			</dp:url-open>
			</xsl:variable>
			<xsl:variable name="responseCode">
				<xsl:value-of select="$SwitchOrderApi/result/responsecode"/>
			</xsl:variable>
			<dp:set-variable name="'var://context/SOM/GetSwitchOrderResponseCode'" value="string($responseCode)"/>
			<xsl:choose>
				<xsl:when test="$responseCode='200'">
					<xsl:variable name="SwitchOrderApiResponse">
						<xsl:copy-of select="(dp:decode(dp:binary-encode($SwitchOrderApi/result/binary/node()),'base-64'))" disable-output-escaping="yes" omit-xml-declaration="yes"/>
					</xsl:variable>
					<dp:set-variable name="'var://context/SOM/GetSwitchOrderUpdateStatus'" value="'Updateoperation'"/>
					<dp:set-variable name="'var://context/SOM/GetSwitchOrderResponseData'" value="string($SwitchOrderApiResponse)"/>
					<!-- status field check starts -->
					<xsl:choose>
						<xsl:when test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='STATUS']">
							<xsl:choose>
								<xsl:when test="string-length(normalize-space(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='STATUS']))&gt; 0">
									<dp:set-variable name="'var://context/SOM/StatusIssue'" value="'no'"/>
								</xsl:when>
								<xsl:otherwise>
									<!-- if status tag is present but no value then set the flag for maximo nack -->
									<dp:set-variable name="'var://context/SOM/StatusIssue'" value="'yes'"/>
									<dp:set-variable name="'var://context/SOM/StatusMessage'" value="'Workflow/Status field valueis empty'"/>
								</xsl:otherwise>
							</xsl:choose>
						</xsl:when>
						<xsl:otherwise>
							<!-- 			if status tag is not present then set the flag for maximo nack  -->
							<dp:set-variable name="'var://context/SOM/StatusIssue'" value="'no'"/>
							<dp:set-variable name="'var://context/SOM/StatusMessage'" value="'Workflow/Status field valueis empty'"/>
						</xsl:otherwise>
					</xsl:choose>
					<!-- status field check ends -->
				</xsl:when>
				<xsl:when test="$responseCode='404'">
					<xsl:variable name="SwitchOrderApiResponse">
						<xsl:copy-of select="(dp:decode(dp:binary-encode($CustomerApi/result/binary/node()),'base-64'))" disable-output-escaping="yes"/>
					</xsl:variable>
					<dp:set-variable name="'var://context/SOM/GetSwitchOrderUpdateStatus'" value="'CreationOperation'"/>
					<dp:set-variable name="'var://context/SOM/GetSwitchOrderResponseData'" value="string($SwitchOrderApiResponse)"/>
				</xsl:when>
				<xsl:when test="$responseCode='401'">
					<xsl:variable name="SwitchOrderApiResponse">
						<xsl:copy-of select="(dp:decode(dp:binary-encode($CustomerApi/result/binary/node()),'base-64'))" disable-output-escaping="yes"/>
					</xsl:variable>
					<xsl:variable name="reasonphrase">
						<xsl:value-of select="$SwitchOrderApi/result/reasonphrase"/>
					</xsl:variable>
					<xsl:message dp:type="all" dp:priority="error">SOM_AM_002 service SOM_AMCreateUpdateSwithOrder SwitchOrderApi  Call Response code:<xsl:value-of select="$responseCode"/> for id :<xsl:value-of select="$id"/> and reason is <xsl:value-of select="$reasonphrase"/>
					</xsl:message>
					<xsl:variable name="ErrorTxt">SOM_AM_002 service SOM_AMCreateUpdateSwithOrder SwitchOrderApi Call: <xsl:value-of select="$url"/> Response code:<xsl:value-of select="$responseCode"/> for id :<xsl:value-of select="$id"/> and reason is <xsl:value-of select="$reasonphrase"/></xsl:variable>
					<!-- <dp:set-variable name="'var://context/SOM/retry'" value="string('yes')"/> -->
					<dp:set-variable name="'var://context/ILS/ExitStatus'" value="'401'"/>
<dp:set-variable name="'var://context/ILS/ErrorDescription'" value="$ErrorTxt"/>
					<dp:reject>TransactionID:<xsl:value-of select="$TransactoinID"/> SwitchOrderApi  Call Response code:<xsl:value-of select="$responseCode"/> for id:<xsl:value-of select="$id"/> and reason is <xsl:value-of select="$reasonphrase"/>
					</dp:reject>
				</xsl:when>
				<xsl:otherwise>
					<xsl:choose>
						<xsl:when test="string-length(normalize-space($responseCode))&gt; 0">
							<xsl:variable name="SwitchOrderApiResponse">
								<xsl:copy-of select="(dp:decode(dp:binary-encode($SwitchOrderApi/result/binary/node()),'base-64'))" disable-output-escaping="yes"/>
							</xsl:variable>
							<dp:set-variable name="'var://context/SOM/retry'" value="string('yes')"/>
							<xsl:variable name="ErrorTxt">SOM_AM_002 in service SOM_AMCreateUpdateSwithOrder SwitchOrderApi Call: <xsl:value-of select="$url"/> Response code:<xsl:value-of select="$responseCode"/> for externalid :<xsl:value-of select="$SwitchOrderApi"/> and reason is <xsl:value-of select="$SwitchOrderApiResponse"/>
							</xsl:variable>
							<dp:set-variable name="'var://context/SOM/ErrorTxt'" value="string($ErrorTxt)"/>
							<dp:set-variable name="'var://context/ILS/ExitDescription'" value="string($ErrorTxt)"/>
							<!-- 				<xsl:message dp:type="all" dp:priority="error">SOM_AM_002 in service SOM_AMCreateUpdateSwithOrder SwitchOrderApi  Call Response code:<xsl:value-of select="$responseCode"/> for externalid :<xsl:value-of select="$SwitchOrderApi"/> and reason is <xsl:value-of select="$SwitchOrderApiResponse" /></xsl:message> -->
							<!-- 		        <dp:reject>TransactionID:<xsl:value-of select="$TransactoinID"/> SwitchOrderApi  Call Response code:<xsl:value-of select="$responseCode"/> for id:<xsl:value-of select="$id"/> and reason is <xsl:value-of select="$SwitchOrderApiResponse" /></dp:reject> -->
						</xsl:when>
						<xsl:otherwise>
							<xsl:variable name="errorstatuscode">
								<xsl:value-of select="$SwitchOrderApi/result/errorstatuscode"/>
							</xsl:variable>
							<xsl:variable name="errorstring">
								<xsl:value-of select="$SwitchOrderApi/result/errorstring"/>
							</xsl:variable>
							<dp:set-variable name="'var://context/SOM/retry'" value="string('yes')"/>
							<xsl:variable name="ErrorTxt">SOM_AM_002 in service SOM_AMCreateUpdateSwithOrder SwitchOrderApi Call: <xsl:value-of select="$url"/> Response for  or external id :<xsl:value-of select="$id"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/>
							</xsl:variable>
							<dp:set-variable name="'var://context/SOM/ErrorTxt'" value="string($ErrorTxt)"/>
							<dp:set-variable name="'var://context/ILS/ExitDescription'" value="string($ErrorTxt)"/>
							<!-- 		<xsl:message dp:type="all" dp:priority="error">SOM_AM_002 in service SOM_AMCreateUpdateSwithOrder SwitchOrderApi  Call Response for  or external id :<xsl:value-of select="$id"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></xsl:message> -->
							<!-- 		        <dp:reject>TransactionID:<xsl:value-of select="$TransactoinID"/> SwitchOrderApi  Call Response for SwitchOrderApi:<xsl:value-of select="$id"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></dp:reject> -->
						</xsl:otherwise>
					</xsl:choose>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>
