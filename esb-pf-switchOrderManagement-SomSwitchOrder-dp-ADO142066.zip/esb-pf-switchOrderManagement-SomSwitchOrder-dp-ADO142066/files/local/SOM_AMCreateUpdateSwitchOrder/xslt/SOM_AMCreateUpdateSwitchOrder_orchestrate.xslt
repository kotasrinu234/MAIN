<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"

	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:param name="dpconfig:nullCheckRequired" />

	<xsl:template match="/">

		<xsl:variable name="GetSwitchOrderUpdateStatus">
			<xsl:copy-of
				select="dp:variable('var://context/SOM/GetSwitchOrderUpdateStatus')" />
		</xsl:variable>
		<xsl:variable name="retry">
			<xsl:copy-of
				select="dp:variable('var://context/SOM/retry')" />
		</xsl:variable>
		<xsl:variable name="LookupMaximoResponse">
			<xsl:copy-of
				select="dp:variable('var://context/SOM/LookupMaximoResponse')" />
		</xsl:variable>

		<xsl:if
			test="not($retry ='yes') and not($LookupMaximoResponse ='yes')">
			<xsl:choose>
				<xsl:when
					test="contains($GetSwitchOrderUpdateStatus,'Updateoperation')">
					<xsl:variable name="PatchCall_Jsonx_Message">
						<json:object
							xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
							xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
							xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">

							<!-- custom field start -->
							<json:object name="customFieldValues">

								<json:string name="Voltage_Class">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_VOLTTYPE']" />
								</json:string>

								<xsl:choose>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REASON_REJECT']">
										<xsl:variable name="Reason_For_Action">
											<xsl:copy-of
												select="dp:variable('var://context/SOM/DTE_Reason_Reject')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when
												test="string-length(normalize-space($Reason_For_Action))&gt; 0">
												<json:string name="Reason_For_Action">
													<xsl:value-of select="$Reason_For_Action" />
												</json:string>
											</xsl:when>
											<xsl:otherwise>
												<json:string name="Reason_For_Action">
													<xsl:value-of select="'null'" />
												</json:string>
											</xsl:otherwise>
										</xsl:choose>
									</xsl:when>
								</xsl:choose>

								<!-- <json:string name="Reason_For_Action"> -->
								<!-- <xsl:value-of select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REASON_REJECT']"/> -->
								<!-- </json:string> -->

								<json:string name="Desk_Assignment">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='OWNERGROUP']" />
								</json:string>
								<json:string name="Desk_Assignment_Description">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='PERSONGROUP']/*[local-name()='DESCRIPTION']" />
								</json:string>
								<json:string name="Maximo_Reference_Requests">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REFERENCE_RSD']" />
								</json:string>
								<json:string name="Equipment_to_be_Shutdown">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REMARKDESC']" />
								</json:string>
								<xsl:variable name="DTE_SOC_PROTECTION">
									<xsl:choose>
										<xsl:when
											test="string-length(normalize-space(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_PROTECTION']))&gt; 0">
											<xsl:value-of
												select="concat('Class',' ',/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_PROTECTION'])" />
										</xsl:when>
										<xsl:otherwise>
											<xsl:value-of select="''" />
										</xsl:otherwise>
									</xsl:choose>
								</xsl:variable>
								<json:string name="Protection_Class">
									<xsl:value-of select="$DTE_SOC_PROTECTION" />
								</json:string>
								<json:string name="Protection_Limits">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_LIMITS']" />
								</json:string>

								<xsl:variable name="lowercase"
									select="'abcdefghijklmnopqrstuvwxyz'" />
								<xsl:variable name="uppercase"
									select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
								<xsl:variable name="DTE_PROTECTION_REQ_Upper">
									<xsl:value-of
										select="translate(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PROTECTION_REQ'], $lowercase, $uppercase)" />
								</xsl:variable>
								<json:string name="Protection_Required">
									<xsl:choose>
										<xsl:when
											test="contains($DTE_PROTECTION_REQ_Upper,'Y' )">
											<xsl:value-of select="'0'" />
										</xsl:when>
										<xsl:when
											test="contains($DTE_PROTECTION_REQ_Upper,'N' )">
											<xsl:value-of select="'1'" />
										</xsl:when>
									</xsl:choose>
								</json:string>

								<json:string name="Protection_Limits_Description">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REMARKDESC_LONGDESCRIPTION']" />
								</json:string>
								<json:string name="Assignment_Of_Request">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_ASSIGN_OF_REQ']" />
								</json:string>
								<json:string name="Emergency_Clearance_Time">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_EM_CLEAR_TIME']" />
								</json:string>
								<json:string name="Special_Notes_And_Instructions">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_SPECIALNOTES_LONGDESCRIPTION']" />
								</json:string>
								<!-- <json:string name="Character_Of_Work_Selection"> -->
								<!-- <xsl:value-of select="dp:variable('var://context/SOM/CharacterOfWorkSelection_DESCRIPTION')"/> -->
								<!-- </json:string> -->

								<xsl:variable name="Character_Of_Work_Selection">
									<xsl:value-of
										select="dp:variable('var://context/SOM/CharacterOfWorkSelection_DESCRIPTION')" />
								</xsl:variable>

								<xsl:choose>
									<xsl:when
										test="string-length(normalize-space(dp:variable('var://context/SOM/CharacterOfWorkSelection_DESCRIPTION')))&gt; 0">
										<json:string name="Character_Of_Work_Selection">
											<xsl:value-of
												select="dp:variable('var://context/SOM/CharacterOfWorkSelection_DESCRIPTION')" />
										</json:string>
									</xsl:when>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DESCRIPTION']">
										<json:string name="Character_Of_Work_Selection">
											<xsl:value-of select="''" />
										</json:string>
									</xsl:when>
								</xsl:choose>

								<json:string name="Character_Of_Work_Description">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DESCRIPTION_LONGDESCRIPTION']" />
								</json:string>
								<json:string name="Responsible_Organization">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_DISCIPLINE']" />
								</json:string>

								<xsl:variable name="Responsible_Service_Center">
									<xsl:value-of
										select="dp:variable('var://context/SOM/Responsible_Service_Center_DTE_WORKLOCATION')" />
								</xsl:variable>

								<xsl:choose>
									<xsl:when
										test="string-length(normalize-space(dp:variable('var://context/SOM/Responsible_Service_Center_DTE_WORKLOCATION')))&gt; 0">
										<json:string name="Responsible_Service_Center">
											<xsl:value-of
												select="dp:variable('var://context/SOM/Responsible_Service_Center_DTE_WORKLOCATION')" />
										</json:string>
									</xsl:when>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_WORKLOCATION']">
										<json:string name="Responsible_Service_Center">
											<xsl:value-of select="''" />
										</json:string>
									</xsl:when>
								</xsl:choose>

								<json:string name="Special_Notes_And_Instructions">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_SPECIALNOTES_LONGDESCRIPTION']" />
								</json:string>
								<json:string name="Job_Status">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_JOBSTATUS']" />
								</json:string>
								<json:string name="Job_Status_Details">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_JOBSTATUS_LONGDESCRIPTION']" />
								</json:string>


								<xsl:choose>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']">
										<json:array name="Resource_Requirements">

											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_OPR'],'1' )">
												<json:string>
													<xsl:value-of select="'OPER'" />
												</json:string>
											</xsl:if>


											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_OHL'],'1' )">
												<json:string>
													<xsl:value-of select="'OHL'" />
												</json:string>
											</xsl:if>
											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_UGL'],'1' )">
												<json:string>
													<xsl:value-of select="'UGL'" />
												</json:string>
											</xsl:if>
											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_SMM'],'1' )">
												<json:string>
													<xsl:value-of select="'SMM'" />
												</json:string>
											</xsl:if>
											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_CBT'],'1' )">
												<json:string>
													<xsl:value-of select="'CBT'" />
												</json:string>
											</xsl:if>
											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_PRT'],'1' )">
												<json:string>
													<xsl:value-of select="'PERT'" />
												</json:string>
											</xsl:if>
											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_PSR'],'1' )">
												<json:string>
													<xsl:value-of select="'PSR'" />
												</json:string>
											</xsl:if>
											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_OTHER'],'1' )">
												<json:string>
													<xsl:value-of select="'OTHER'" />
												</json:string>
											</xsl:if>
											<xsl:if
												test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_MAPUPDATEREQa'],'1' )">
												<json:string>
													<xsl:value-of select="'Map Update'" />
												</json:string>
											</xsl:if>
										</json:array>

									</xsl:when>
								</xsl:choose>

								<json:string name="Lead_Name">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']" />
								</json:string>
								<json:string name="Prearranger_Name">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']" />
								</json:string>
								<json:string name="Pre_Switch_Date">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHDATE']" />
								</json:string>
								<json:string name="Switching_Start">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHSTART']" />
								</json:string>
								<json:string name="Switching_End">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHFINISH']" />
								</json:string>

								<json:string name="Customer_Arrangements">
									<xsl:choose>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTARRANG'],'0')">
											<xsl:value-of select="'false'" />
										</xsl:when>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTARRANG'],'1')">
											<xsl:value-of select="'true'" />
										</xsl:when>
									</xsl:choose>
								</json:string>

								<json:string name="Provisional">
									<xsl:choose>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PROVISIONAL'],'0')">
											<xsl:value-of select="'false'" />
										</xsl:when>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PROVISIONAL'],'1')">
											<xsl:value-of select="'true'" />
										</xsl:when>
									</xsl:choose>
								</json:string>

								<json:string name="Interconnection">
									<xsl:choose>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_INTERCONNECTION'],'0')">
											<xsl:value-of select="'false'" />
										</xsl:when>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_INTERCONNECTION'],'1')">
											<xsl:value-of select="'true'" />
										</xsl:when>
									</xsl:choose>
								</json:string>

								<json:string name="Ready_To_Process">
									<xsl:choose>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_READYTOPROCESS'],'0')">
											<xsl:value-of select="'false'" />
										</xsl:when>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_READYTOPROCESS'],'1')">
											<xsl:value-of select="'true'" />
										</xsl:when>
									</xsl:choose>
								</json:string>

                               <xsl:choose>
									<xsl:when
										test="string-length(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY'] &gt; 0)">
										
											<xsl:choose>
											
<!-- 								 <xsl:message dp:type="all" dp:priority="error">####<xsl:value-of select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY']"/></xsl:message> -->
											
											
								<xsl:when test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY'] = ''" >
<!-- 											or contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY'],'')"> -->
										<json:string name="Priority">
											<xsl:value-of select= "''" />
										</json:string>
									</xsl:when>
											
									<xsl:when
										test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MUST'],'1') or contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MNGMUST'],'1')">
										<json:string name="Priority">
											<xsl:value-of select="'1'" />
										</json:string>
									</xsl:when>
									<xsl:otherwise>
										<json:string name="Priority">
											<xsl:value-of
												select="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY'])" />
										</json:string>
									</xsl:otherwise>
								</xsl:choose>
										
									</xsl:when>
									</xsl:choose>

								

								<json:string name="Work_Start">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='ACTUALSTART']" />
								</json:string>
								<json:string name="Work_End">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='ACTUALFINISH']" />
								</json:string>

								<json:string name="Must">
									<xsl:choose>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MUST'],'0')">
											<xsl:value-of select="'false'" />
										</xsl:when>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MUST'],'1')">
											<xsl:value-of select="'true'" />
										</xsl:when>
									</xsl:choose>
								</json:string>
								<json:string name="Managed_Must">
									<xsl:choose>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MNGMUST'],'0')">
											<xsl:value-of select="'false'" />
										</xsl:when>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MNGMUST'],'1')">
											<xsl:value-of select="'true'" />
										</xsl:when>
									</xsl:choose>
								</json:string>

								<json:string name="Request_Created_For">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']" />
								</json:string>


								<json:string name="OE_Comments">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_OPECOMMENTS']" />
								</json:string>

								<json:string name="Customers_Affected">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTOMERSAFF']" />
								</json:string>
								<json:string name="Customer_Minutes">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_EXPECTEDMIN']" />
								</json:string>
								<json:string name="SAIDI">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_SAIDI']" />
								</json:string>
								<json:string name="Restore_Before_System_Load">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESTORSYSLOAD']" />
								</json:string>
								<json:string name="Load_Restriction">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_LOADRESTRICTION']" />
								</json:string>
								<json:string name="Recommend_Restore_By">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESTOREBYDATE']" />
								</json:string>
								<json:string name="Updated_At">
									<xsl:value-of
										select="/*[local-name()='PublishDTEMAXSOMSROUT']/@creationDateTime" />
								</json:string>

							</json:object>
							<!-- custom field end -->
							<json:string name="phoneNumber">
								<xsl:value-of
									select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='AFFECTEDPHONE']" />
							</json:string>
							<json:string name="officeNumber">
								<xsl:value-of
									select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REPORTEDPHONE']" />
							</json:string>

							<json:string name="plannedStart">
								<xsl:value-of
									select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TARGETSTART']" />
							</json:string>
							<json:string name="plannedEnd">
								<xsl:value-of
									select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TARGETFINISH']" />
							</json:string>

							<json:string name="location">
								<xsl:value-of
									select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='LOCATIONS']/*[local-name()='DESCRIPTION']" />
							</json:string>

							<xsl:choose>
								<xsl:when
									test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='LOCATION']">
									<json:string name="New_location">
										<xsl:value-of
											select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='LOCATION']" />
									</json:string>
								</xsl:when>
							</xsl:choose>

							<!-- custom field end -->

							<json:object name="customTableValues">
								<xsl:choose>

									<xsl:when
										test="(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']/*[local-name()='CREATEDATE']) and (/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']/*[local-name()='DESCRIPTION_LONGDESCRIPTION'])">
										<json:array name="Maximo_Related_Logs">

											<xsl:for-each
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']">

												<xsl:if test="./*[local-name()='CREATEDATE']">
													<json:object>
														<json:string name="Memo_Date">
															<xsl:value-of
																select="./*[local-name()='CREATEDATE']" />
														</json:string>
														<json:string name="Memo_Detail">
															<xsl:value-of
																select="./*[local-name()='DESCRIPTION_LONGDESCRIPTION']" />
														</json:string>
													</json:object>
												</xsl:if>
											</xsl:for-each>
										</json:array>
									</xsl:when>

									<xsl:when
										test="(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']/*[local-name()='CREATEDATE'])">
										<json:array name="Maximo_Related_Logs">
											<xsl:for-each
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']">
												<json:object>
													<json:string name="Memo_Date">
														<xsl:value-of
															select="./*[local-name()='CREATEDATE']" />
													</json:string>
												</json:object>
											</xsl:for-each>
										</json:array>
									</xsl:when>

									<xsl:when
										test="(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']/*[local-name()='DESCRIPTION_LONGDESCRIPTION'])">
										<json:array name="Maximo_Related_Logs">
											<xsl:for-each
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']">
												<json:object>
													<json:string name="Memo_Detail">
														<xsl:value-of
															select="./*[local-name()='DESCRIPTION_LONGDESCRIPTION']" />
													</json:string>
												</json:object>
											</xsl:for-each>
										</json:array>
									</xsl:when>
								</xsl:choose>

								<xsl:if
									test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKORDER']">
									<json:array name="Maximo_Work_Orders">
										<xsl:for-each
											select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKORDER']">

											<json:object>
												<xsl:if test="./*[local-name()='STATUS']">
													<json:string name="Work_Order_Status">
														<xsl:value-of
															select="./*[local-name()='STATUS']" />
													</json:string>
												</xsl:if>
												<xsl:if test="./*[local-name()='WONUM']">
													<json:string name="Work_Order_Number">
														<xsl:value-of
															select="./*[local-name()='WONUM']" />
													</json:string>
												</xsl:if>
												<xsl:if test="./*[local-name()='DESCRIPTION']">
													<json:string name="Work_Order_Summary">
														<xsl:value-of
															select="./*[local-name()='DESCRIPTION']" />
													</json:string>
												</xsl:if>
											</json:object>
										</xsl:for-each>
									</json:array>
								</xsl:if>

							</json:object>
						</json:object>
					</xsl:variable>
					<xsl:copy-of select="$PatchCall_Jsonx_Message" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:variable name="CLASSIFICATIONID">
						<xsl:value-of
							select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='CLASSSTRUCTURE']/*[local-name()='CLASSIFICATIONID']" />
					</xsl:variable>
					<dp:set-variable
						name="'var://context/SOM/CLASSIFICATIONID'"
						value="string($CLASSIFICATIONID)" />

					<xsl:variable name="Jsonx_Message">
						<json:object
							xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
							xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
							xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">
							<json:object name="switchOrder">

								<xsl:choose>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='LOCATIONS']/*[local-name()='DESCRIPTION']">
										<json:string name="location">
											<xsl:value-of
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='LOCATIONS']/*[local-name()='DESCRIPTION']" />
										</json:string>
									</xsl:when>
								</xsl:choose>

								<xsl:choose>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='LOCATION']">
										<json:string name="New_location">
											<xsl:value-of
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='LOCATION']" />
										</json:string>
									</xsl:when>
								</xsl:choose>

								<xsl:choose>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='AFFECTEDPHONE']">
										<json:string name="phoneNumber">
											<xsl:value-of
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='AFFECTEDPHONE']" />
										</json:string>
									</xsl:when>
								</xsl:choose>

								<xsl:choose>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REPORTEDPHONE']">
										<json:string name="officeNumber">
											<xsl:value-of
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REPORTEDPHONE']" />
										</json:string>
									</xsl:when>
								</xsl:choose>




								<!-- lookup -->
								<json:string name="switchOrderTypeObjectID">
									<xsl:copy-of
										select="dp:variable('var://context/SOM/switchOrderTypeObjectID')" />
								</json:string>


								<xsl:choose>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TARGETSTART']">
										<json:string name="plannedStart">
											<xsl:value-of
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TARGETSTART']" />
										</json:string>
										
									</xsl:when>
								</xsl:choose>

								<xsl:choose>
									<xsl:when
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TARGETFINISH']">
										<json:string name="plannedEnd">
											<xsl:value-of
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TARGETFINISH']" />
										</json:string>
									</xsl:when>
								</xsl:choose>




								<!-- custom field start -->
								<json:object name="customFieldValues">
									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='ACTUALSTART']">
											<json:string name="Work_Start">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='ACTUALSTART']" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='ACTUALFINISH']">
											<json:string name="Work_End">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='ACTUALFINISH']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TICKETID']">
											<json:string name="Maximo_Request_Number">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TICKETID']" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_VOLTTYPE']">
											<json:string name="Voltage_Class">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_VOLTTYPE']" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REASON_REJECT']">
											<xsl:variable name="Reason_For_Action">
												<xsl:copy-of
													select="dp:variable('var://context/SOM/DTE_Reason_Reject')" />
											</xsl:variable>
											<xsl:choose>
												<xsl:when
													test="string-length(normalize-space($Reason_For_Action))&gt; 0">
													<json:string name="Reason_For_Action">
														<xsl:value-of select="$Reason_For_Action" />
													</json:string>
												</xsl:when>
												<xsl:otherwise>
													<json:string name="Reason_For_Action">
														<xsl:value-of select="'null'" />
													</json:string>
												</xsl:otherwise>
											</xsl:choose>
										</xsl:when>
									</xsl:choose>
									<!-- <xsl:choose> -->
									<!-- <xsl:when test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REASON_REJECT']"> -->
									<!-- <json:string name="Reason_For_Action"> -->
									<!-- <xsl:value-of select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REASON_REJECT']"/> -->
									<!-- </json:string> -->
									<!-- </xsl:when> -->
									<!-- </xsl:choose> -->


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='OWNERGROUP']">
											<json:string name="Desk_Assignment">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='OWNERGROUP']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DESCRIPTION']">
											<json:string name="Desk_Assignment_Description">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='PERSONGROUP']/*[local-name()='DESCRIPTION']" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REFERENCE_RSD']">
											<json:string name="Maximo_Reference_Requests">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_REFERENCE_RSD']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REMARKDESC']">
											<json:string name="Equipment_to_be_Shutdown">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REMARKDESC']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_PROTECTION']">
											<xsl:variable name="DTE_SOC_PROTECTION">
												<xsl:choose>
													<xsl:when
														test="string-length(normalize-space(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_PROTECTION']))&gt; 0">
														<xsl:value-of
															select="concat('Class',' ',/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_PROTECTION'])" />
													</xsl:when>
													<xsl:otherwise>
														<xsl:value-of select="''" />
													</xsl:otherwise>
												</xsl:choose>
											</xsl:variable>
											<json:string name="Protection_Class">
												<xsl:value-of select="$DTE_SOC_PROTECTION" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_LIMITS']">
											<json:string name="Protection_Limits">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_LIMITS']" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PROTECTION_REQ']">
											<xsl:variable name="lowercase"
												select="'abcdefghijklmnopqrstuvwxyz'" />
											<xsl:variable name="uppercase"
												select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
											<xsl:variable name="DTE_PROTECTION_REQ_Upper">
												<xsl:value-of
													select="translate(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PROTECTION_REQ'], $lowercase, $uppercase)" />
											</xsl:variable>
											<json:string name="Protection_Required">
												<xsl:choose>
													<xsl:when
														test="contains($DTE_PROTECTION_REQ_Upper,'Y' )">
														<xsl:value-of select="'0'" />
													</xsl:when>
													<xsl:when
														test="contains($DTE_PROTECTION_REQ_Upper,'N' )">
														<xsl:value-of select="'1'" />
													</xsl:when>
												</xsl:choose>
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REMARKDESC_LONGDESCRIPTION']">
											<json:string name="Protection_Limits_Description">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='REMARKDESC_LONGDESCRIPTION']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_ASSIGN_OF_REQ']">
											<json:string name="Assignment_Of_Request">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_ASSIGN_OF_REQ']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_EM_CLEAR_TIME']">
											<json:string name="Emergency_Clearance_Time">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_EM_CLEAR_TIME']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DESCRIPTION_LONGDESCRIPTION']">
											<json:string name="Character_Of_Work_Description">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DESCRIPTION_LONGDESCRIPTION']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_DISCIPLINE']">
											<json:string name="Responsible_Organization">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_DISCIPLINE']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<!--  <xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_DISCIPLINE']/*[local-name()='DTE_SPECIALNOTES_LONGDESCRIPTION']">
											<json:string
												name="Special_Notes_And_Instructions">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_DISCIPLINE']/*[local-name()='DTE_SPECIALNOTES_LONGDESCRIPTION']" />
											</json:string>
										</xsl:when>
									</xsl:choose>-->
									
									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_SPECIALNOTES_LONGDESCRIPTION']">
											<json:string
												name="Special_Notes_And_Instructions">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_SPECIALNOTES_LONGDESCRIPTION']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_JOBSTATUS']">
											<json:string name="Job_Status">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_JOBSTATUS']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_JOBSTATUS_LONGDESCRIPTION']">
											<json:string name="Job_Status_Details">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_JOBSTATUS_LONGDESCRIPTION']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']">
											<json:array name="Resource_Requirements">

												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_OPR'],'1' )">
													<json:string>
														<xsl:value-of select="'OPER'" />
													</json:string>
												</xsl:if>


												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_OHL'],'1' )">
													<json:string>
														<xsl:value-of select="'OHL'" />
													</json:string>
												</xsl:if>
												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_UGL'],'1' )">
													<json:string>
														<xsl:value-of select="'UGL'" />
													</json:string>
												</xsl:if>
												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_SMM'],'1' )">
													<json:string>
														<xsl:value-of select="'SMM'" />
													</json:string>
												</xsl:if>
												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_CBT'],'1' )">
													<json:string>
														<xsl:value-of select="'CBT'" />
													</json:string>
												</xsl:if>
												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_PRT'],'1' )">
													<json:string>
														<xsl:value-of select="'PERT'" />
													</json:string>
												</xsl:if>
												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_PSR'],'1' )">
													<json:string>
														<xsl:value-of select="'PSR'" />
													</json:string>
												</xsl:if>
												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESRC_OTHER'],'1' )">
													<json:string>
														<xsl:value-of select="'OTHER'" />
													</json:string>
												</xsl:if>
												<xsl:if
													test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_MAPUPDATEREQa'],'1' )">
													<json:string>
														<xsl:value-of select="'Map Update'" />
													</json:string>
												</xsl:if>
											</json:array>

										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']">
											<json:string name="Lead_Name">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']">
											<json:string name="Prearranger_Name">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<!-- timestamp start -->

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHDATE']">
											<json:string name="Pre_Switch_Date">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHDATE']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHSTART']">
											<json:string name="Switching_Start">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHSTART']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHFINISH']">
											<json:string name="Switching_End">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PRESWITCHFINISH']" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<!-- timestamp pending end -->
									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTARRANG']">
											<json:string name="Customer_Arrangements">
												<xsl:choose>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTARRANG'],'0')">
														<xsl:value-of select="'false'" />
													</xsl:when>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTARRANG'],'1')">
														<xsl:value-of select="'true'" />
													</xsl:when>
												</xsl:choose>
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PROVISIONAL']">
											<json:string name="Provisional">
												<xsl:choose>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PROVISIONAL'],'0')">
														<xsl:value-of select="'false'" />
													</xsl:when>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_PROVISIONAL'],'1')">
														<xsl:value-of select="'true'" />
													</xsl:when>
												</xsl:choose>
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_INTERCONNECTION']">
											<json:string name="Interconnection">
												<xsl:choose>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_INTERCONNECTION'],'0')">
														<xsl:value-of select="'false'" />
													</xsl:when>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_INTERCONNECTION'],'1')">
														<xsl:value-of select="'true'" />
													</xsl:when>
												</xsl:choose>
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_READYTOPROCESS']">
											<json:string name="Ready_To_Process">
												<xsl:choose>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_READYTOPROCESS'],'0')">
														<xsl:value-of select="'false'" />
													</xsl:when>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_READYTOPROCESS'],'1')">
														<xsl:value-of select="'true'" />
													</xsl:when>
												</xsl:choose>
											</json:string>
										</xsl:when>
									</xsl:choose>
<xsl:choose>
<xsl:when
										test="string-length(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY'] &gt; 0)">
									<xsl:choose>
<!-- 						 <xsl:message dp:type="all" dp:priority="info">####<xsl:value-of select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY']"/></xsl:message>			 -->
									<xsl:when test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY'] = ''" >
<!-- 									or contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY'],'')"> -->
									<json:string>
											<xsl:value-of select= "''" />
										</json:string>
									</xsl:when>
										<xsl:when
											test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MUST'],'1') or contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MNGMUST'],'1')">
											<json:string name="Priority">
												<xsl:value-of select="'1'" />
											</json:string>
										</xsl:when>

										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY']">
											<json:string name="Priority">
												<xsl:value-of
													select="string(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='INTERNALPRIORITY'])" />
											</json:string>
										</xsl:when>
									</xsl:choose>
									</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MUST']">
											<json:string name="Must">
												<xsl:choose>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MUST'],'0')">
														<xsl:value-of select="'false'" />
													</xsl:when>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MUST'],'1')">
														<xsl:value-of select="'true'" />
													</xsl:when>
												</xsl:choose>
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MNGMUST']">
											<json:string name="Managed_Must">
												<xsl:choose>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MNGMUST'],'0')">
														<xsl:value-of select="'false'" />
													</xsl:when>
													<xsl:when
														test="contains(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOC_MNGMUST'],'1')">
														<xsl:value-of select="'true'" />
													</xsl:when>
												</xsl:choose>
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']">
											<json:string name="Request_Created_For">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='PERSON']/*[local-name()='DISPLAYNAME']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_OPECOMMENTS']">
											<json:string name="OE_Comments">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_OPECOMMENTS']" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTOMERSAFF']">
											<json:string name="Customers_Affected">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTOMERSAFF']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTOMERSAFF']">
											<json:string name="Customers_Affected">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_CUSTOMERSAFF']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_EXPECTEDMIN']">
											<json:string name="Customer_Minutes">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_EXPECTEDMIN']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_SAIDI']">
											<json:string name="SAIDI">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_SAIDI']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESTORSYSLOAD']">
											<json:string name="Restore_Before_System_Load">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESTORSYSLOAD']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_LOADRESTRICTION']">
											<json:string name="Load_Restriction">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_LOADRESTRICTION']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESTOREBYDATE']">
											<json:string name="Recommend_Restore_By">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_SOCSR']/*[local-name()='DTE_RESTOREBYDATE']" />
											</json:string>
										</xsl:when>
									</xsl:choose>

									<xsl:choose>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/@creationDateTime">
											<json:string name="Updated_At">
												<xsl:value-of
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/@creationDateTime" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<!-- for lookup -->


									<xsl:variable name="Character_Of_Work_Selection">
										<xsl:value-of
											select="dp:variable('var://context/SOM/CharacterOfWorkSelection_DESCRIPTION')" />
									</xsl:variable>

									<xsl:choose>
										<xsl:when
											test="string-length(normalize-space(dp:variable('var://context/SOM/CharacterOfWorkSelection_DESCRIPTION')))&gt; 0">
											<json:string name="Character_Of_Work_Selection">
												<xsl:value-of
													select="dp:variable('var://context/SOM/CharacterOfWorkSelection_DESCRIPTION')" />
											</json:string>
										</xsl:when>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DESCRIPTION']">
											<json:string name="Character_Of_Work_Selection">
												<xsl:value-of select="''" />
											</json:string>
										</xsl:when>
									</xsl:choose>


									<xsl:variable name="Responsible_Service_Center">
										<xsl:value-of
											select="dp:variable('var://context/SOM/Responsible_Service_Center_DTE_WORKLOCATION')" />
									</xsl:variable>

									<xsl:choose>
										<xsl:when
											test="string-length(normalize-space(dp:variable('var://context/SOM/Responsible_Service_Center_DTE_WORKLOCATION')))&gt; 0">
											<json:string name="Responsible_Service_Center">
												<xsl:value-of
													select="dp:variable('var://context/SOM/Responsible_Service_Center_DTE_WORKLOCATION')" />
											</json:string>
										</xsl:when>
										<xsl:when
											test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_WORKLOCATION']">
											<json:string name="Responsible_Service_Center">
												<xsl:value-of select="''" />
											</json:string>
										</xsl:when>
									</xsl:choose>

								</json:object>
								<!-- custom field end -->


								<json:object name="customTableValues">

									<xsl:choose>
										<xsl:when
											test="(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']/*[local-name()='CREATEDATE']) and (/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']/*[local-name()='DESCRIPTION_LONGDESCRIPTION'])">
											<json:array name="Maximo_Related_Logs">
												<xsl:for-each
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']">
													<xsl:if test="./*[local-name()='CREATEDATE']">
														<json:object>

															<json:string name="Memo_Date">
																<xsl:value-of
																	select="./*[local-name()='CREATEDATE']" />
															</json:string>
															<json:string name="Memo_Detail">
																<xsl:value-of
																	select="./*[local-name()='DESCRIPTION_LONGDESCRIPTION']" />
															</json:string>
														</json:object>
													</xsl:if>
												</xsl:for-each>
											</json:array>
										</xsl:when>

										<xsl:when
											test="(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']/*[local-name()='CREATEDATE'])">
											<json:array name="Maximo_Related_Logs">
												<xsl:for-each
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']">
													<json:object>
														<json:string name="Memo_Date">
															<xsl:value-of
																select="./*[local-name()='CREATEDATE']" />
														</json:string>
													</json:object>
												</xsl:for-each>
											</json:array>
										</xsl:when>
										<xsl:when
											test="(/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']/*[local-name()='DESCRIPTION_LONGDESCRIPTION'])">
											<json:array name="Maximo_Related_Logs">
												<xsl:for-each
													select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKLOG']">
													<json:object>
														<json:string name="Memo_Detail">
															<xsl:value-of
																select="./*[local-name()='DESCRIPTION_LONGDESCRIPTION']" />
														</json:string>
													</json:object>
												</xsl:for-each>
											</json:array>
										</xsl:when>
									</xsl:choose>



									<xsl:if
										test="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKORDER']">
										<json:array name="Maximo_Work_Orders">
											<xsl:for-each
												select="/*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='WORKORDER']">

												<json:object>
													<xsl:if test="./*[local-name()='STATUS']">
														<json:string name="Work_Order_Status">
															<xsl:value-of
																select="./*[local-name()='STATUS']" />
														</json:string>
													</xsl:if>
													<xsl:if test="./*[local-name()='WONUM']">
														<json:string name="Work_Order_Number">
															<xsl:value-of
																select="./*[local-name()='WONUM']" />
														</json:string>
													</xsl:if>
													<xsl:if test="./*[local-name()='DESCRIPTION']">
														<json:string name="Work_Order_Summary">
															<xsl:value-of
																select="./*[local-name()='DESCRIPTION']" />
														</json:string>
													</xsl:if>
												</json:object>
											</xsl:for-each>
										</json:array>
									</xsl:if>

								</json:object>
							</json:object>
						</json:object>
					</xsl:variable>
					<xsl:copy-of select="$Jsonx_Message" />


				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
		<xsl:if
			test="($retry ='yes') or ($LookupMaximoResponse ='yes') ">
			<xsl:variable name="Jsonx_Message">
				<json:object
					xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
					xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
					xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">
				</json:object>
			</xsl:variable>
			<xsl:copy-of select="$Jsonx_Message" />
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>
