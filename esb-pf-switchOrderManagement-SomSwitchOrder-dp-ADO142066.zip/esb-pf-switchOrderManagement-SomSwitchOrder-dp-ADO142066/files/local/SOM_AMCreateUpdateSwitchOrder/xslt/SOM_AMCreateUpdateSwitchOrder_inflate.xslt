<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" extension-element-prefixes="dp" exclude-result-prefixes="dp">
<xsl:output method="xml"/>

 

<xsl:template match="@*|node()">
<xsl:apply-templates select="@*|node()"/>
</xsl:template>

<xsl:template match="/">
<xsl:variable name="IncomingPayload" >
<xsl:copy-of select="."/>
</xsl:variable>
<dp:set-variable name="'var://context/ILS/messageId'" value="string(//json:string[@name='messageId'])"/>
<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/messageId'" value="string(//json:string[@name='messageId'])"/>
<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/eventType'" value="string(//json:string[@name='eventType'])"/>
<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/serviceName'" value="string(//json:string[@name='serviceName'])"/>
<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/messageType'" value="string(//json:string[@name='messageType'])"/>

<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/eventContext'" value="string(//json:string[@name='eventContext'])"/>
<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/EventTimeStamp'" value="string(//json:string[@name='EventTimeStamp'])"/>

<xsl:variable name="inflated" select="dp:inflate(//json:string[@name='payload'])"/>
<xsl:variable name="parsed" select="dp:parse($inflated)"/>

<xsl:copy-of select="$parsed"/>
<xsl:message dp:type="all" dp:priority="debug">inflated: <xsl:value-of select="$parsed"/> </xsl:message>
<dp:set-variable name="'var://context/SOM_CreateUpdate_seq/inflated'" value="$inflated"/>


<xsl:choose>
  <xsl:when test="//json:string[@name='DTE_EXTERNALID2']">
   <dp:set-variable name="'var://context/SOM_CreateUpdate_seq/DTE_EXTERNALID2'" value="string(//json:string[@name='DTE_EXTERNALID2'])"/>
  </xsl:when>
  
  <xsl:otherwise>
    <dp:set-variable name="'var://context/SOM_CreateUpdate_seq/DTE_EXTERNALID2'" value="''"/>

  </xsl:otherwise>
</xsl:choose>
</xsl:template>

</xsl:stylesheet>

 
