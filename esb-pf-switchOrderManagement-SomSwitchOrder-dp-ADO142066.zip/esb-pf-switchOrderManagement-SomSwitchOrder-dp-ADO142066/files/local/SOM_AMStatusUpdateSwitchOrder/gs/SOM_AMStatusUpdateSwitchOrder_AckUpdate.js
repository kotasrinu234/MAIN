// js is used to perform oms call
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var ilsctx = session.name("ILS") || session.createContext("ILS");

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		// Getting stylesheet params
		var Backendurl = session.parameters.MaximoBackendurl;
		var MaximoAPIKey = session.parameters.MaximoAPIKey;
		var ExitDescription = session.parameters.ExitDescription;

		// Remove the "esbData" property
		delete incomingdata.esbData;

		var backendapicall = {
			target: Backendurl + '&apikey=' + MaximoAPIKey,
			sslClientProfile: 'SOM_AMStatusUpdateSwitchOrder_Client_Profile',
			method: 'POST',
			contentType: 'application/json',
			data: incomingdata
		};

		var info = "TargetURL: " + backendapicall.target + "; Method: " + backendapicall.method + "; Data: " + JSON.stringify(backendapicall.data) + ". ";
		try{
		urlopen.open(backendapicall, function(error, response) {
			if (error) {
				var errorinfo = "SOM_AM_008:urlopen connect error with backendapicall details are : " + info + "; error info: " + error;
				var ctx = session.name("SOM") || session.createContext("SOM");
				ctx.setVariable("retry", 'yes');
				logger.debug("urlopen connect error with connecting to backend maximo is API " + JSON.stringify(error));
				var ErrorTxt = "SOM_AM_008 in SOM_AMStatusUpdateSwithOrder service is urlopen connect error with connecting to backend maximo is API " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ilsctx.setVariable("exitDestination", Backendurl);
				ilsctx.setVariable("exitStatus", "500");
				ilsctx.setVariable("ErrorDescription", errorinfo);
			} else {
				// Read response data
				// Get the response status code
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error message while reading response from backend maximo is details are: " + info + "; error info: " + error;
							// dp:reject stops the transaction and goes to the error rule with error code and description
							logger.error("error message while reading response from backend maximo is " + JSON.stringify(error));
							session.reject("error message while reading response from backend maximo is " + JSON.stringify(error));
							ilsctx.setVariable("exitDestination", Backendurl);
							ilsctx.setVariable("exitStatus",responseStatusCode);
							ilsctx.setVariable("ErrorDescription", errorinfo);
						} else {
							// Store status code with response body in context variable
							hm.response.statusCode = responseStatusCode;
							ilsctx.setVariable("exitDestination", Backendurl);
							ilsctx.setVariable("exitStatus", "0");
							ilsctx.setVariable("description", ExitDescription);
						}
					});
				} else if (responseStatusCode == 401) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error message while reading response from backend maximo is details are: " + info + "; error info: " + error + responseStatusCode + " Unauthorized";
							logger.error("error message while reading response from maximo " + JSON.stringify(error));
							ilsctx.setVariable("exitStatus",responseStatusCode);
							ilsctx.setVariable("ErrorDescription", errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "error message while reading response from backend maximo is details are: " + info + "; error info: " + responseData + responseStatusCode + " Unauthorized";
							logger.error("Error returned while doing post for backend API maximo is statusCode " + responseStatusCode + " Unauthorized");
							session.reject("Error returned while doing post for backend API maximo is statusCode " + responseStatusCode + " Unauthorized");
							ilsctx.setVariable("exitStatus",responseStatusCode);
							ilsctx.setVariable("ErrorDescription", errorinfo);
							session.reject(errorinfo);
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error message while reading response from backend maximo is details are: " + info + "; error info: " + error;
							// dp:reject stops the transaction and goes to the error rule with error code and description
							logger.error("Error returned while doing post for backend API maximo is " + JSON.stringify(error));
							session.reject("Error returned while post for backend API maximo is " + JSON.stringify(error));
							ilsctx.setVariable("exitStatus",responseStatusCode);
							ilsctx.setVariable("ErrorDescription", errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "error message while reading response from backend maximo is details are: " + info + "; error info: " + responseData;
							logger.error("Error returned while updating backend API statusCode " + responseStatusCode + " " + responseData);
							// session.reject("Error returned while updating backend API " + responseStatusCode+" "+ responseData);
							ilsctx.setVariable("exitStatus",responseStatusCode);
							ilsctx.setVariable("ErrorDescription", errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		});
		} catch(err){
			var errorinfo = "SOM_AM_008:urlopen connect error with backendapicall details are : " + info + "; error info: " + err;
				var ctx = session.name("SOM") || session.createContext("SOM");
				ctx.setVariable("retry", 'yes');
				logger.debug("urlopen connect error with connecting to backend maximo is API " + JSON.stringify(error));
				var ErrorTxt = "SOM_AM_008 in SOM_AMStatusUpdateSwithOrder service is urlopen connect error with connecting to backend maximo is API " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ilsctx.setVariable("exitDestination", Backendurl);
				ilsctx.setVariable("exitStatus", "500");
				ilsctx.setVariable("ErrorDescription", errorinfo);
		}
	}
});
