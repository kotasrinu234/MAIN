		
var ilsCtx = session.name('ILS') || session.createContext('ILS');

 

function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { 
var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
 return v.toString(16); }); }
var uuid = uuidv4();
ilsCtx.setVariable("id", uuid)
