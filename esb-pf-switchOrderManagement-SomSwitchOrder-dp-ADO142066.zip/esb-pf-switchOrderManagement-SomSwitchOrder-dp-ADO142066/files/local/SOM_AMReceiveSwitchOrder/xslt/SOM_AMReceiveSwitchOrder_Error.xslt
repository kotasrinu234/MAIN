<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" extension-element-prefixes="dp" exclude-result-prefixes="dp">
    <xsl:template match="/">
        <xsl:variable name="TransactionID">
            <xsl:copy-of select="dp:variable('var://service/global-transaction-id')"/>
        </xsl:variable>
                        <xsl:variable name="errorMessage" select="normalize-space(concat('SOM_AM_001 AAA failure for maximo username:', dp:variable('var://context/WSM/identity/username'), ' with Statuscode 401, TransactionID: ', $TransactionID, ' ErrorMessage:', dp:variable('var://service/error-message')))"/>
        <xsl:variable name="customErrorMessage"> SOM_AM_001 <xsl:value-of select="dp:variable('var://service/error-message')"/> in service SOM_AMReceiveSwithOrder with error code
                    <xsl:value-of select="dp:variable('var://service/error-code')"/>
                </xsl:variable>
                <xsl:variable name="customMessage">
                    SOM_AM_001
                    <xsl:value-of select="dp:variable('var://service/error-message')"/>
                    in service SOM_AMReceiveSwithOrder with error code
                    <xsl:value-of select="dp:variable('var://service/error-code')"/>
                </xsl:variable>
                <xsl:variable name="customError">
                    TransactionID:<xsl:value-of select="$TransactionID"/>
                    ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
                </xsl:variable>
                <xsl:variable name="serverErrorMessage">
                    TransactionID:<xsl:value-of select="$TransactionID"/>
                    ErrorCode:<xsl:value-of select="dp:variable('var://service/error-headers')"/>
                    ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
                </xsl:variable>
        <xsl:choose>
            <xsl:when test="contains(dp:variable('var://service/error-message'), 'Rejected by policy')">
                <dp:set-variable name="'var://service/error-protocol-response'" value="'401'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'"/>
                <xsl:message dp:type="all" dp:priority="error">
                    <xsl:value-of select="$errorMessage"/>
                </xsl:message>
                <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'401'"/>
                <dp:set-variable name="'var://context/ILS/ErrorDescription'" value="concat(dp:variable('var://service/error-protocol-response'), ', ', dp:variable('var://service/error-protocol-reason-phrase'), ', ', $errorMessage)"/>
            </xsl:when>
            <xsl:when test="contains(dp:variable('var://service/error-code'), '0x00230001')">
                <dp:set-variable name="'var://service/error-protocol-response'" value="'400'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Request'"/>
                <xsl:message dp:type="all" dp:priority="error">
                    <xsl:value-of select="$customErrorMessage"/>
                </xsl:message>
                <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'400'"/>
                <dp:set-variable name="'var://context/ILS/ErrorDescription'" value="concat(dp:variable('var://service/error-protocol-response'), ', ', dp:variable('var://service/error-protocol-reason-phrase'), ', ', $customErrorMessage)"/>
            </xsl:when>
            <xsl:when test="contains(dp:variable('var://service/error-code'), '0x00030001')">
                <dp:set-variable name="'var://service/error-protocol-response'" value="'400'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Request'"/>
                <xsl:message dp:type="all" dp:priority="error">
                    <xsl:value-of select="$customMessage"/>
                </xsl:message>
                <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'400'"/>
                <dp:set-variable name="'var://context/ILS/ErrorDescription'" value="concat(dp:variable('var://service/error-protocol-response'), ', ', dp:variable('var://service/error-protocol-reason-phrase'), ', ', $customMessage)"/>            
            </xsl:when>
            <!-- <xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
            <xsl:message dp:type="all" dp:priority="error">TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
            </xsl:message>
            <dp:set-variable name="'var://service/error-protocol-response'" value="'401'" />
            <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'" />
            </xsl:when> -->
            <xsl:when test="contains(dp:variable('var://service/error-code'), '0x01130006')">
                <xsl:message dp:type="all" dp:priority="error">
                    <xsl:value-of select="$customError"/>
                </xsl:message>
                <dp:set-variable name="'var://context/ILS/ErrorDescription'" value="concat(dp:variable('var://service/error-protocol-response'), ', ', dp:variable('var://service/error-protocol-reason-phrase'), ', ', $customError)"/>
                <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'502'"/>
                <dp:set-variable name="'var://service/error-protocol-response'" value="'502'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Gateway'"/>
            </xsl:when>
            <xsl:otherwise>
                <xsl:message dp:type="all" dp:priority="error">
                    <xsl:value-of select="$serverErrorMessage"/>
                </xsl:message>
                <dp:set-variable name="'var://context/ILS/ErrorDescription'" value="concat(dp:variable('var://service/error-protocol-response'), ', ', dp:variable('var://service/error-protocol-reason-phrase'), ', ', $serverErrorMessage)"/>
                <dp:set-variable name="'var://context/ILS/ExitStatus'" value="'500'"/>
                <dp:set-variable name="'var://service/error-protocol-response'" value="'500'"/>
                <dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Interval Server Error (General Error)'"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
</xsl:stylesheet>
