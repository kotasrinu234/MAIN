<!-- This xslt is used to invoke job oms api and get the response -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:msg="http://esm.dteco.com/common/v1" extension-element-prefixes="dp date" exclude-result-prefixes="dp dpconfig">
<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>

 

 <xsl:param name="dpconfig:EntryDescription" select="''"/>
<xsl:variable name="EntryDescription" select="$dpconfig:EntryDescription"/>
<xsl:param name="dpconfig:ExitDescription" select="''"/>
<xsl:variable name="ExitDescription" select="$dpconfig:ExitDescription"/>
<xsl:param name="dpconfig:messageType" select="''"/>
<xsl:variable name="messageType" select="$dpconfig:messageType"/>
<xsl:param name="dpconfig:BackendUrl" select="''"/>
<xsl:variable name="BackendUrl" select="$dpconfig:BackendUrl"/> 

 

 

<xsl:template match="/">
<xsl:variable name="IncomingPayload" select = '.' />

 

<dp:set-variable name="'var://context/ILS/IncomingPayload'" value="$IncomingPayload"/>

 

<xsl:variable name = 'messageID' select = "string(/*[local-name()='PublishDTEMAXSOMSROUT']/@*[local-name()='messageID'])"/>

<dp:set-variable name ="'var://context/ILS/messageID'" value = "$messageID" />

  <xsl:variable name="somID" select="./*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='DTE_TICKET']/*[local-name()='DTE_EXTERNALID2']"/>
<xsl:variable name="maximoID" select="./*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='TICKETID']"/>
<xsl:variable name="orderType" select="./*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='CLASSSTRUCTURE']/*[local-name()='CLASSIFICATIONID']"/>
<xsl:variable name="orderStatus" select="./*[local-name()='PublishDTEMAXSOMSROUT']/*[local-name()='DTEMAXSOMSROUTSet']/*[local-name()='SR']/*[local-name()='STATUS']"/>
<xsl:variable name="sourceEventTimestamp" select="./*[local-name()='PublishDTEMAXSOMSROUT']/@*[local-name()='creationDateTime']"/>

  <dp:set-variable name="'var://context/ILS/somID'" value="($somID)"/>
<dp:set-variable name="'var://context/ILS/maximoID'" value="($maximoID)"/>
<dp:set-variable name="'var://context/ILS/orderType'" value="($orderType)"/>
<dp:set-variable name="'var://context/ILS/orderStatus'" value="($orderStatus)"/>
<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="string($sourceEventTimestamp)"/>
<dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)"/>

 <dp:set-variable name="'var://context/ILS/EntryDescription'" value="string($EntryDescription)"/>
<dp:set-variable name="'var://context/ILS/ExitDescription'" value="string($ExitDescription)"/>
  <dp:set-variable name="'var://context/ILS/exitDestination'" value="string($BackendUrl)"/>

 

 

<xsl:apply-templates select="node()|@*" />

 

</xsl:template>
<xsl:template match="*[local-name()='PublishDTEMAXSOMSROUT']/@*[local-name()='messageID']">

<xsl:attribute name="messageID">
<xsl:choose>
<xsl:when test=". != '' ">
<xsl:value-of select="." />
</xsl:when>
<xsl:otherwise><xsl:value-of select="dp:generate-uuid()" /></xsl:otherwise>
</xsl:choose>
</xsl:attribute>
</xsl:template>

 

<xsl:template match="@*|node()">
<xsl:copy>
<xsl:apply-templates select="@*|node()"/>
</xsl:copy>
</xsl:template>

 

</xsl:stylesheet>
