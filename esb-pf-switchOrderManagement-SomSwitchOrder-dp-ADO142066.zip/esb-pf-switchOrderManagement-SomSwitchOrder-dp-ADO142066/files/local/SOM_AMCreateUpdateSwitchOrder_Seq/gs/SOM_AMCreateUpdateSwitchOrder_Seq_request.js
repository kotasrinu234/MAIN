var ctx = session.name("SOM_CreateUpdate_seq") || session.createContext("SOM_CreateUpdate_seq");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });

var ILSctx = session.name('ILS') || session.createContext('ILS');
function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var dateTime = new Date();
var conversionVal, GMTDate, ESTDateVar, ESTDate, localOffset, offset, utc, finalESTDate, dateArray;
var currentTime = dateTime.toISOString();
var EventTimeStamp = ctx.getVariable("EventTimeStamp");
var eventContext = ctx.getVariable("eventContext");
var ESTTimeStamp = DateConversion(EventTimeStamp);
var deflatedPayload = ctx.getVariable("deflatedPayload");
var ExitDescription  = session.parameters.ExitDescription 
 

var payload =
{
	"messageId": ctx.getVariable("messageID"),
	"serviceName": "maxOrder",
	"expiry": session.parameters.expiry,
	"eventType": "maximoSwithOrderEvent",
	"eventContext": eventContext,
	"payload": deflatedPayload,
	"EventTimeStamp": ESTTimeStamp,
	"sendTimeStamp": currentTime,
	"waitTime": session.parameters.waitTime,
    "messageType": "maximoSwithOrderEvent",
	"destQueueName": 'SOM.AM.RECEIVE.SWITCH.ORDER.SEQ'
}

ctx.setVar('payload', payload);
//pushing to queue start

var StandaloneMQurl = session.parameters.SOM_AMCreateUpdateSwitchOrder_SeqMQSequanceUrl;
ILSctx.setVariable('exitDestination', StandaloneMQurl);
var publishuri = {
	target: StandaloneMQurl,
	data: payload
};
var info = " TargetURL: " + publishuri.target + "; Data: " + JSON.stringify(publishuri.data) + ". ";
try {
	urlopen.open(publishuri, function(error, response) {
		var hm = require('header-metadata');
		if (error) {
			var errorinfo = "SOM_AM_004: url connection error 'Sequence Request', details are : " + info + "; error info :" + error
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ErrorDescription', errorinfo);
			logger.error(errorinfo);
			var mqconnection = 'Forbidden';
			ctx.setVariable("mqconnection", mqconnection);
			var ErrorTxt = "SOM_AM_004: SOM_CreateUpdate_sequence error while keeping message to queue is " + error;
			ctx.setVariable("ErrorTxt", errorinfo);
			ctx.setVariable("retry", 'yes');
		} else {
			var mqrc = response.statusCode;
			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						hm.response.statusCode = 403
						var errorinfo = "SOM_AM_005: error reading in response from 'Sequence Request', details are : " + info + "; error info :" + readError
						ILSctx.setVariable('ExitStatus',mqrc);
						ILSctx.setVariable('ErrorDescription', errorinfo);
						logger.error(errorinfo);
						var ErrorTxt = "SOM_AM_005: SOM_CreateUpdate_sequence error while keeping message to queue is " + readError;
						ctx.setVariable("ErrorTxt", errorinfo);
						ctx.setVariable("retry", 'yes');

					} else {
						logger.debug("MQResponsecode " + mqrc);
						ILSctx.setVariable('ExitStatus', '0');
				ILSctx.setVariable('ExitDescription', ExitDescription);
					}
				});
			} else {
				
				var errorinfo = "SOM_AM_006:error response 'Sequence Request', details are : " + info + "; response info :" +JSON.stringify(response) + "; ResponseStatusCode :" + mqrc
				ILSctx.setVariable('ExitStatus',mqrc);
				ILSctx.setVariable('ErrorDescription', errorinfo);
				logger.error(errorinfo);
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				var ErrorTxt = "SOM_AM_006: SOM_CreateUpdate_sequence response code is urlopen.open error [MQRC=" + mqrc + "]";
				ctx.setVariable("ErrorTxt", errorinfo);
				ctx.setVariable("retry", 'yes');
			}
		}
		//pushing to queue end
	});
} catch (err) {
	var mqconnection = 'Forbidden';
	ctx.setVariable("mqconnection", mqconnection);
	var errorinfo = "SOM_AM_004: url connection error 'Sequence Request', details are : " + info + "; error info :" + err
	ILSctx.setVariable('ExitStatus', '500');
	ILSctx.setVariable('ErrorDescription', errorinfo);
	ctx.setVariable("ErrorTxt", errorinfo);
	ctx.setVariable("retry", 'yes');
}

function DateConversion(incomingDateTime) {
	var finalutcDate;

	var GMTDate = new Date(incomingDateTime);
	var ESTDateVar = GMTDate.getTime();
	var localOffset = GMTDate.getTimezoneOffset() * 60000;
	var datestrng = GMTDate.toString();
	//var offset;
	//									if(datestrng.includes(edt)){
	//									offset = +4;
	//										} else {
	//									offset = +5;
	//									}
	//var utc = ESTDateVar + (3600000*offset);
	var utc = ESTDateVar
	var ctx = session.name("omsapijob") || session.createContext("omsapijob");
	ctx.setVariable("utc", utc);
	var ESTDate = new Date(utc).toISOString();
	ctx.setVariable("ESTDate", ESTDate);
	var finalutcDate = ESTDate;
	return finalutcDate;

}
