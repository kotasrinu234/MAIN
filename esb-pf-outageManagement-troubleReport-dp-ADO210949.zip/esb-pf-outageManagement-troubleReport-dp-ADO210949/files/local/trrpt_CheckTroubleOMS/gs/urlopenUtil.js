//This Gateway script is a common for all the api calls
var ctx = session.name("Trouble") || session.createContext("Trouble");
var hm = require('header-metadata');
var sm = require('service-metadata');
var apiToken = ctx.getVariable("apiToken");
var urlopen = require('urlopen');
var Id = ctx.getVariable("Id");
var callType = ctx.getVariable("callType");
var premiseid = ctx.getVariable("premiseid");
var logger = console.options({
	'category': 'all'
});

function getURLResponse(url, myctx) {
	var options = {
		target: url,
		method: "get",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "trrpt_CheckTroubleOMS_ssl_client_profile"

	};
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				var ctx = session.name("Trouble") || session.createContext("Trouble");
				var trrpt = ctx.getVariable("trrpt");
				logger.error(trrpt + " urlopen error " + JSON.stringify(error));
				session.reject("urlopen error: " + JSON.stringify(error));
				hm.current.statusCode = '500';
			} else {
				var responseStatusCode = response.statusCode;
				var ctx = session.name("Trouble") || session.createContext("Trouble");
				ctx.setVariable("responseStatusCode", responseStatusCode);
				logger.debug("response code" + responseStatusCode);
				var responsePhrase = response.reasonPhrase;
				ctx.setVariable("responsePhrase", responsePhrase);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							hm.current.statusCode = '500';
							session.output.write("readAsJSON error: " + JSON.stringify(error));
						} else {
							var ctx = session.name("Trouble") || session.createContext("Trouble");
							if (myctx === "URLResponse") {
								var TestArray = ctx.getVariable("testArray")
								if (responseData === null || responseData === '' || responseData === undefined) {
									var externalCallCodeID = '';
									logger.debug("externalCallCodeID  " + externalCallCodeID);
								} else {
									var externalCallCodeID = responseData.externalCallCodeID;
									if (externalCallCodeID === null || externalCallCodeID === '' || externalCallCodeID === undefined) {
										var externalCallCodeID = '';
									} else {
										var externalCallCodeID = {
											"externalCallCodeID": externalCallCodeID,
											"id": responseData.id,
										}

										TestArray.push(externalCallCodeID)
										ctx.setVariable("testArray", TestArray)
										logger.debug("externalCallCodeID  " + externalCallCodeID);
									}
								}
							}
							ctx.setVariable(myctx, responseData);
							logger.debug("response data" + JSON.stringify(responseData));
						}
					})
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error("failure in reading message from " + url + " " + JSON.stringify(error));
							session.reject("failure in reading message from " + url + " " + JSON.stringify(error));
						} else {
							logger.error("Error code returned from Api " + url + ' ' + responseStatusCode + ' ' + responseData);
							session.reject("Error code returned from Api " + url + ' ' + responseStatusCode + ' ' + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		logger.error(trrpt + " urlopen error " + JSON.stringify(error));
		session.reject("urlopen error: " + JSON.stringify(error));
	}
}

module.exports = getURLResponse;
