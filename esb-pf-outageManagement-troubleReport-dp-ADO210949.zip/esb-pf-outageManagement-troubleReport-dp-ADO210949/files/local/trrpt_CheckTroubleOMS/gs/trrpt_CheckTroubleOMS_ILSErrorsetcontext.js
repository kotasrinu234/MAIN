var ctx = session.name('ILSExit') || session.createContext('ILSExit');
var errorResponse = ctx.getVariable("errorResponse")
if (errorResponse) {
	if (errorResponse !== undefined || errorResponse !== null || errorResponse !== '') {
		ctx.setVariable("action", "Error")
		ctx.setVariable("okToProceed", "False")
		ctx.setVariable("callID", "")
	}
}
