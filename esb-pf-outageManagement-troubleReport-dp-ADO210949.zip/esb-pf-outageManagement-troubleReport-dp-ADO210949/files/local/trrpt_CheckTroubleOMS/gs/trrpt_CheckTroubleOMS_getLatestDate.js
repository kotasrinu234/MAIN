/* This gateway script is used to get the id of the latest date from premise call and perform api call
Date :14-May-2020
Author :Alekya Jaggannagari */
var getURLResponse = require('./urlopenUtil.js');
var ctx = session.name('Trouble') || session.createContext('Trouble');
var logger = console.options({
    'category': 'all'
});
/* Extracting the Latest date from premise call*/
var premiseActiveCallURLResp = ctx.getVariable("premiseActiveCallURLResp");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var activeIdArr = [];
if(premiseActiveCallURLResp!== undefined && premiseActiveCallURLResp!==null && premiseActiveCallURLResp.length!== 0){
	for(var i=0; i<premiseActiveCallURLResp.length; i++){
		if(premiseActiveCallURLResp[i].status === "ACTIVE"){
			var Id = premiseActiveCallURLResp[i].id;
			activeIdArr.push(Id);
			ctx.setVariable("activeIdArr", activeIdArr);
		}
		
	}
	for(var i=0; i<activeIdArr.length; i++){
		var URL = omsExternalURL + '/api/ServiceType/Electric/Call/' + activeIdArr[i];
		getURLResponse(URL, 'URLResponse');
	}
}

//var URL = omsExternalURL + '/api/ServiceType/Electric/Call/' + id;
//getURLResponse(URL, 'URLResponse');

	var obj = premiseActiveCallURLResp.filter(function(premiseActiveCallURLResp) {
    return premiseActiveCallURLResp.status === "ACTIVE";
	});
	for(var a=0, b=1; a<obj.length&&b<obj.length-1; a++,b++){
		obj.sort(function compare(a, b) {
			var dateA = new Date(a.updatedAt);
			var dateB = new Date(b.updatedAt);
			return dateA - dateB;
		});
	}
	

var latestUpdatedDate = obj;
if (latestUpdatedDate === null || latestUpdatedDate === '' || latestUpdatedDate === undefined) {
    logger.debug("latest updated date is undefined ");
} else {
    ctx.setVariable("latestUpdatedDate", latestUpdatedDate);
    /*var id = latestUpdatedDate.id;
    logger.debug("latest updated Id " + JSON.stringify(id));
	var ctx = session.name('Trouble') || session.createContext('Trouble');
    ctx.setVariable("trrpt", 'trrpt_003');
	doing oms api call*/
	
}
