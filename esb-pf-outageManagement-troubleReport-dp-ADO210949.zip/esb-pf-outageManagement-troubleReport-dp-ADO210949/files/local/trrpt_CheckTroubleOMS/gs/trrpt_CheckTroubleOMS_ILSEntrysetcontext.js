var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILSEntry') || session.createContext('ILSEntry');
var description = session.parameters.entrydescription;
var messageType = session.parameters.messageType
ctx.setVariable("messageType", messageType)
ctx.setVariable('entryDescription', description);
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var id = incomingdata.Id;
		if (id !== undefined || id !== null || id !== '') {
			ctx.setVariable("correlationID", id)
		}
		if (incomingdata.premiseId !== undefined || incomingdata.premiseId !== null || incomingdata.premiseId !== '') {
			ctx.setVariable("premiseID", incomingdata.premiseId)
		}
		ctx.setVariable("sourceEventTimestamp", new Date().toISOString())
		if (incomingdata.callType !== undefined || incomingdata.callType !== null || incomingdata.callType !== '') {
			ctx.setVariable("callCode", incomingdata.callType)
		}
	}
});
