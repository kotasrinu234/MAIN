/* This gateway script is used to set the url for customerType and premsie calls and get the respective responses
Date :14-May-2020
Author :Alekya Jaggannagari */
var getURLResponse = require('./urlopenUtil.js');
var ctx = session.name('Trouble') || session.createContext('Trouble');
var omsExternalURL = ctx.getVariable("omsExternalURL");
var premiseid = ctx.getVariable("premiseid");
/*var premiseStatusResponseJson = ctx.getVariable("PremiseDataURLResp");
var customer = premiseStatusResponseJson.customer;
if (customer === null || customer === '' || customer === undefined) {
    ctx.setVariable("customerId", "");
} else {
	var customerId = customer.externalID;
    ctx.setVariable("customerId", customerId);
}*/

/* doing customertype api call*/
/* var customerTypeURL = omsExternalURL + '/api/v1/Customer/' + customerId;
getURLResponse(customerTypeURL, 'customerTypeURLResp');
 */

/* doing Activepremise api call*/
var premiseActiveCallURL = omsExternalURL + '/api/Premise/' + premiseid + '/Call?includeFields=id%2CdisplayID%2Cstatus%2CupdatedAt%2CcreatedAt&activeOnly=true&ignoreHistorical=true';
ctx.setVariable("trrpt",'trrpt_002');
getURLResponse(premiseActiveCallURL, 'premiseActiveCallURLResp');
