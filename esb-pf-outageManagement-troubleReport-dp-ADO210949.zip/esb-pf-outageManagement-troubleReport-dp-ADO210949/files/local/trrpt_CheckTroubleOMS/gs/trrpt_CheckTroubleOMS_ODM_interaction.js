/* This gateway script is used for the ODM interaction and send the response.
Date :14-May-2020
Author :Alekya Jaggannagari */
var ctx = session.name('Trouble') || session.createContext('Trouble');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var urlopen = require('urlopen');
var URLResponse = ctx.getVariable("URLResponse");
var premiseStatusResponseJson = ctx.getVariable("PremiseDataURLResp");
var latestUpdatedDate = ctx.getVariable("latestUpdatedDate");
var premiseActiveCallURLResp = ctx.getVariable("premiseActiveCallURLResp");
var ctx = session.name('Trouble') || session.createContext('Trouble');
var Id = ctx.getVariable("Id");
var callType = ctx.getVariable("callType");
var premiseid = ctx.getVariable("premiseid");
var odmuri = ctx.getVar("ODMEndpoint");

if (premiseStatusResponseJson === null || premiseStatusResponseJson === '' || premiseStatusResponseJson === undefined) {
	var inputPriority = '';
}
else {
	var premiseResponse = premiseStatusResponseJson.premise.customFieldValuesExt;
	var inputPriority = premiseResponse.Site_Priority_Code;
}

logger.debug("inputPriority  " + inputPriority);
if (inputPriority === null || inputPriority === '' || inputPriority === undefined) {
	var inputPriority = '';
	logger.debug("inputPriority  " + inputPriority);
} else {
	var inputPriority = inputPriority;
	logger.debug("inputPriority  " + inputPriority);
}
var callCodeIdArr = ctx.getVariable("testArray");
if (callCodeIdArr !== null && callCodeIdArr !== undefined && callCodeIdArr.length !== 0) {
	for (var i = 0; i < callCodeIdArr.length; i++) {
		/* input data for ODM*/
		var payload = {
			"request": {

				/* "inputCallCode": externalCallCodeID,
				"existingCallCode":callType , */
				"inputCallCode": callType,
				"existingCallCode": callCodeIdArr[i].externalCallCodeID,
				"inputPriority": inputPriority,
				"premisesID": premiseid
			},
			"__DecisionID__": Id,
		}

		var jobId = callCodeIdArr[i].id
		odmcall(payload, jobId)
	}

}
else {
	var payload = {
		"request": {

			/* "inputCallCode": externalCallCodeID,
			"existingCallCode":callType , */
			"inputCallCode": callType,
			"existingCallCode": "",
			"inputPriority": inputPriority,
			"premisesID": premiseid
		},
		"__DecisionID__": Id,
	}

	var jobId = "";
	odmcall(payload, jobId)
}
session.output.write(payload);
logger.debug("payload" + JSON.stringify(payload));
/* Performing ODM call*/

function odmcall(odmapi, id) {

	var odmapi = {
		target: odmuri,
		sslClientProfile: 'ODM_Client_Profile',
		method: 'post',
		contentType: 'application/json',
		headers: {

		},
		data: payload,
	};
	try {
		urlopen.open(odmapi, function(error, response) {
			if (error) {
				// an error occurred during request sending or response header parsing
				logger.error("trrpt_004 ODM urlopen connect error with odmapi" + JSON.stringify(error));
				session.reject("ODM urlopen connect error with odmapi" + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable("responseStatusCode", responseStatusCode);
				logger.debug("response code of odmapi " + responseStatusCode);
				var responsePhrase = response.reasonPhrase;
				ctx.setVariable("responsePhrase", responsePhrase);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// an error occurred during reading the response
							logger.error("readAsJSON error:" + JSON.stringify(error));

						} else {
							hm.response.statusCode = '200 Message is received';
							var odmresponse = {
								"responseData": responseData,
								"id": id
							};
							if (responseData.response.action === 'DUP') {
								var DUPArray = ctx.getVariable("DUPArray");
								DUPArray.push(odmresponse);
								ctx.setVariable("DUPArray", DUPArray);
							}
							else if (responseData.response.action === 'CHG') {
								var CHGArray = ctx.getVariable("CHGArray");
								CHGArray.push(odmresponse);
								ctx.setVariable("CHGArray", CHGArray);
							}
							else {
								var CREArray = ctx.getVariable("CREArray");
								CREArray.push(odmresponse);
								ctx.setVariable("CREArray", CREArray);
							}
							var odmresponseArray = ctx.getVariable("odmresponseArray");
							odmresponseArray.push(odmresponse);
							ctx.setVariable("odmresponseArray", odmresponseArray);
							var currentTimeStamp = new Date().toISOString();
							var premiseID = odmresponse.responseData.response.premisesID
							var action = odmresponse.responseData.response.action
							var existingCallCode;
							if (callCodeIdArr !== null && callCodeIdArr !== undefined && callCodeIdArr.length !== 0) {
								for (var i = 0; i < callCodeIdArr.length; i++) {
									if (callCodeIdArr[i].externalCallCodeID !== null && callCodeIdArr[i].externalCallCodeID !== undefined && callCodeIdArr[i].externalCallCodeID !== '') {
										existingCallCode = callCodeIdArr[i].externalCallCodeID;
									}
								}
							}
							else {
								existingCallCode = '';
							}
							var payloadLog = {
								"timestamp": currentTimeStamp,
								"inputCallCode": callType,
								"existingCallCode": existingCallCode,
								"inputPriority": inputPriority,
								"premisesID": premiseID,
								"action": action
							};
							ctx.setVariable("payloadLog", payloadLog);
							logger.info(JSON.stringify(payloadLog));
						}
					});
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							logger.error("failure in reading message from " + odmuri + " " + JSON.stringify(error));
							session.reject("failure in reading message from " + odmuri + " " + JSON.stringify(error));
						} else {
							logger.error("Error returned from odmuri " + " : with statusCode " + responseStatusCode + ' ' + responseData);
							session.reject("Error returned from odmuri " + " : with statusCode " + responseStatusCode + ' ' + responseData);
						}
					});
				}
			}
			//odm end

		});
	}
	catch (error) {
		logger.error("ODM urlopen connect error with odmapi" + JSON.stringify(error));
		session.reject("ODM urlopen connect error with odmapi" + JSON.stringify(error));
	}
}
