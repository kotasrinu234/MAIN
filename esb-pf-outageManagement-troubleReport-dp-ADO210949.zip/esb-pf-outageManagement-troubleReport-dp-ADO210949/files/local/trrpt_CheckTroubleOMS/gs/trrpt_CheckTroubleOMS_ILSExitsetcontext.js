var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name('ILSExit') || session.createContext('ILSExit');
var ctx1 = session.name('Trouble') || session.createContext('Trouble');
var Response = ctx1.getVariable("OdmresponseData");
if (Response) {
	if (Response.existingCallCode) {
		var existingCallCode = Response.existingCallCode;
		if (existingCallCode === undefined || existingCallCode === null || existingCallCode === '') {
			ctx.setVariable("existingCallCode", "")
		}
		else {
			ctx.setVariable("existingCallCode", existingCallCode)
		}
	}
	if (Response.action) {
		var action = Response.action;
		if (action !== undefined || action !== null || action !== '') {
			ctx.setVariable("action", action)
		}
	}
	if (Response.okToProceed) {
		var okToProceed = Response.okToProceed;
		if (okToProceed !== undefined || okToProceed !== null || okToProceed !== '') {
			ctx.setVariable("okToProceed", okToProceed)
		}
	}
	if (Response.callId) {
		var callID = Response.callId;
		if (callID === undefined || callID === null || callID === '') {
			ctx.setVariable("callID", "")
		}
		else {
			ctx.setVariable("callID", callID)
		}
	}
}
var description = session.parameters.exitdescription;
ctx.setVariable('exitDescription', description);
