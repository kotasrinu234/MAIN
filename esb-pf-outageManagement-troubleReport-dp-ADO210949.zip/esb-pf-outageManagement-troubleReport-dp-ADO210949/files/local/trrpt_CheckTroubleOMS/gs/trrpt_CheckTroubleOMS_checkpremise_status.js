/* This gateway script is used to do validation,do the lookup call and does the premise status call. 
Date :14-May-2020
Author :Alekya Jaggannagari */
var getURLResponse = require('./urlopenUtil.js');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("Trouble") || session.createContext("Trouble");
var omsExternalURL = ctx.getVariable("omsExternalURL");
var lookupURL = ctx.getVariable("lookupURL");
var nullcheck = ctx.getVariable("nullcheck");
var PremiseDataURLResp = '';
var logger = console.options({
    'category': 'all'
});
session.input.readAsJSON(function(error, json) {
    if (error) {
        // an error occurred when parsing the content, e.g. invalid JSON object
        // uncatched error will stop the processing and the error will be logged
        logger.error("Error in reading incoming data");
    } else {
        /* validation of input data*/
        if (nullcheck == 'yes') {
            var premiseid = json.premiseId;
            if (premiseid != undefined) {
                ctx.setVariable("premiseid", premiseid);
            } else {
                logger.error("premiseid not found.");
                session.reject('premiseid not found.');
            }
            var Id = json.Id;
            if (Id === null || Id === '' || Id === undefined) {
                logger.error("id not found.");
                session.reject('id type not found.');
            } else {
                ctx.setVariable("Id", Id);
            }

            var callType = json.callType;
            if (callType != undefined) {
                ctx.setVariable("callType", callType);
            } else {
                logger.error("callType not found.");
                session.reject('callType is not found');

            }
            if ((Id == undefined && premiseid == undefined) || (callType == undefined && premiseid == undefined) || (Id == undefined && callType == undefined)) {
                logger.error("some required fields are not found.");
                session.reject('some required fields are missing');

            }
        }
        if (premiseid != undefined && Id != undefined && callType != undefined) {
			/* doing Premise api call*/
            var PremiseCallURL = omsExternalURL + '/api/v1/ServiceType/Electric/Premise/' + premiseid;
            ctx.setVariable("trrpt", 'trrpt_001');
            getURLResponse(PremiseCallURL, 'PremiseDataURLResp');
			//commented for ALM 4010
            //Performing lookUp call
            /*var lookupMessage = {
                "lookupReq": {
                    "type": [{
                        "name": "callCodesJobTypeID",
                        "label": callType
                    }]
                }
            }
            var LookupServiceResponse = {
                target: lookupURL,
                method: 'POST',
                contentType: 'application/json',
                data: lookupMessage
            };

            urlopen.open(LookupServiceResponse, function(error, response) {
                if (error) {
                    logger.error("trrpt_005 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
                    session.reject("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
                } else {
                    // read response data
                    // get the response status code
                    var responseStatusCode = response.statusCode;
                    if (responseStatusCode == 200) {
                        response.readAsJSON(function(error, responseData) {
                            if (error) {
                                // error while reading response or transferring data to Buffer
                                logger.error("failure in putting message to LookupServiceResponse" + JSON.stringify(error));
                            } else {
                                hm.response.statusCode = responseStatusCode;
                                logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
                                if (responseData.lookupRep.type[0].result == 0) {
                                    var jobTypeID = responseData.lookupRep.type[0].id;
                                    logger.debug("jobTypeID:" + jobTypeID);
                                } else {
                                    ctx.setVariable("jobTypeID", '');
                                    var jobTypeID = '';
                                    logger.error("trrpt_006 response received from LookupServiceResponse is 1 ")
                                    session.reject('CallType is Non Valid.');
                                }
                                if (jobTypeID != '') {
                                    var checkforOutage = {
                                        "lookupReq": {
                                            "type": [{
                                                "name": "jobOutageTypes",
                                                "id": jobTypeID
                                            }]
                                        }
                                    }
                                    logger.debug("request" + JSON.stringify(checkforOutage));
                                    var OutageLookupResponse = {
                                        target: lookupURL,
                                        method: 'POST',
                                        contentType: 'application/json',
                                        data: checkforOutage
                                    };
                                    urlopen.open(OutageLookupResponse, function(error, response) {
                                        if (error) {
                                            logger.error("trrpt_007 urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
                                            session.reject("urlopen connect error with OutageLookupResponse" + JSON.stringify(error));
                                        } else {
                                            // read response data
                                            // get the response status code
                                            var responseStatusCode = response.statusCode;
                                            if (responseStatusCode == 200) {
                                                response.readAsJSON(function(error, responseData) {
                                                    if (error) {
                                                        // error while reading response or transferring data to Buffer
                                                        logger.error("failure in reading message to OutageLookupResponse " + JSON.stringify(error));
                                                    } else {
                                                        hm.response.statusCode = responseStatusCode;
                                                        logger.debug("response received from OutageLookupResponse " + JSON.stringify(responseData));
                                                        var ctx = session.name("Trouble") || session.createContext("Trouble");
                                                        ctx.setVariable("responseData", responseData);
                                                        if (responseData.lookupRep.type[0].result == 0) {
                                                            var outageType = responseData.lookupRep.type[0].label;
                                                            if (outageType == 'UNPLANNED_OUTAGE') {
                                                                
                                                            }
                                                            else {
                                                                                                                           session.reject('Request is Non Outage.');
                                                                                                                       }
                                                        } //lookup end
                                                        else {
                                                            logger.error("trrpt_008 premise is outageType " + outageType);
                                                            session.reject('jobTypeID is Non Valid.');
                                                        }
                                                    }
                                                });
                                            } else {
                                                response.readAsBuffer(function(error, responseData) {
                                                    if (error) {
                                                        //dp:reject stop the transaction and go error rule with error code and description
                                                        logger.error("failure in reading message from Outagelookup" + JSON.stringify(error));
                                                        session.reject("failure in reading message from Outagelookup");
                                                    } else {
                                                        logger.error("trrpt_009 Outagelookup response is  " + responseStatusCode + " " + responseData);
                                                        session.reject("Outagelookup response is " + responseStatusCode + " " + responseData);
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }
                            }
                        });
                    } else {
                        response.readAsBuffer(function(error, responseData) {
                            if (error) {
                                //dp:reject stop the transaction and go error rule with error code and description
                                logger.error("failure in reading message from lookupresponse" + JSON.stringify(error));
                                session.reject("failure in reading message from lookupresponse");
                            } else {
                                logger.error("trrpt_010 lookup response is  " + responseStatusCode + " " + responseData);
                                session.reject("lookup response is " + responseStatusCode + " " + responseData);
                            }
                        });
                    }
                }
            });*/
        }
    }
})
