var ctx = session.name('Trouble') || session.createContext('Trouble');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var latestUpdatedDate = ctx.getVariable("latestUpdatedDate");
var premiseActiveCallURLResp = ctx.getVariable("premiseActiveCallURLResp");
var ctx = session.name('Trouble') || session.createContext('Trouble');
var DUPArray = ctx.getVariable("DUPArray");
var CHGArray = ctx.getVariable("CHGArray");
var CREArray = ctx.getVariable("CREArray");
var callCodeIdArr = ctx.getVariable("testArray");
var existingCallCode = "";

if (DUPArray.length != 0) {
	for (var i = 0; i < DUPArray.length; i++) {
		for (var j = latestUpdatedDate.length - 1; j >= 0; j--) {
			if (latestUpdatedDate[j].id === DUPArray[i].id) {
				var OdmresponseData = {};
				OdmresponseData.id = DUPArray[i].responseData.__DecisionID__;
				OdmresponseData.premiseId = DUPArray[i].responseData.response.premisesID;
				OdmresponseData.callType = DUPArray[i].responseData.response.newCallCode;
				OdmresponseData.okToProceed = "true";
				OdmresponseData.action = DUPArray[i].responseData.response.action;
				OdmresponseData.premiseStatus = "";
				if (latestUpdatedDate === null || latestUpdatedDate === '' || latestUpdatedDate === undefined) {
					OdmresponseData.callId = '';
				}
				else {
					OdmresponseData.callId = latestUpdatedDate[j].displayID;
					if (latestUpdatedDate[j].id) {
						if (latestUpdatedDate[j].id == null || latestUpdatedDate[j].id == undefined || latestUpdatedDate[j].id == '') {

						}
						else {
							OdmresponseData.callInternalId = latestUpdatedDate[j].id;
						}
					}
				}
				OdmresponseData.ErrorDescription = "";
				for (var m = 0; m < callCodeIdArr.length; m++) {
					if (callCodeIdArr[m].id === DUPArray[i].id) {
						existingCallCode = callCodeIdArr[m].externalCallCodeID;
					}
				}
				if (existingCallCode === null || existingCallCode === '' || existingCallCode === undefined) {
				}
				else {
					OdmresponseData.existingCallCode = existingCallCode;
				}
				session.output.write(OdmresponseData);
				var odmresponseStatus = 'yes';
				ctx.setVariable("odmresponseStatus", odmresponseStatus);
				ctx.setVariable("OdmresponseData", OdmresponseData);
			}
		}
	}
	logger.info("Decision is DUP")
}
else if (CHGArray.length != 0) {
	for (var i = 0; i < CHGArray.length; i++) {
		for (var j = latestUpdatedDate.length - 1; j >= 0; j--) {
			if (latestUpdatedDate[j].id === CHGArray[i].id) {
				var OdmresponseData = {};
				OdmresponseData.id = CHGArray[i].responseData.__DecisionID__;
				OdmresponseData.premiseId = CHGArray[i].responseData.response.premisesID;
				OdmresponseData.callType = CHGArray[i].responseData.response.newCallCode;
				OdmresponseData.okToProceed = "true";
				OdmresponseData.action = CHGArray[i].responseData.response.action;
				OdmresponseData.premiseStatus = "";
				OdmresponseData.changeFromNonOutageToOutage = CHGArray[i].responseData.response.changeFromNonOutageToOutage;
				ctx.setVar("changeFromNonOutageToOutage", CHGArray[i].responseData.response.changeFromNonOutageToOutage);
				if (latestUpdatedDate === null || latestUpdatedDate === '' || latestUpdatedDate === undefined) {
					OdmresponseData.callId = '';
				}
				else {
					OdmresponseData.callId = latestUpdatedDate[j].displayID;
					if (latestUpdatedDate[j].id) {
						if (latestUpdatedDate[j].id == null || latestUpdatedDate[j].id == undefined || latestUpdatedDate[j].id == '') {

						}
						else {
							OdmresponseData.callInternalId = latestUpdatedDate[j].id;
						}
					}
				}
				OdmresponseData.ErrorDescription = "";
				for (var m = 0; m < callCodeIdArr.length; m++) {
					if (callCodeIdArr[m].id === CHGArray[i].id) {
						existingCallCode = callCodeIdArr[m].externalCallCodeID
					}
				}
				if (existingCallCode === null || existingCallCode === '' || existingCallCode === undefined) {
				}
				else {
					OdmresponseData.existingCallCode = existingCallCode;
				}
				session.output.write(OdmresponseData);
				var odmresponseStatus = 'yes';
				ctx.setVariable("odmresponseStatus", odmresponseStatus);
				ctx.setVariable("OdmresponseData", OdmresponseData);
			}
		}
	}
	logger.info("Decision is CHG")
}
else {
	if (premiseActiveCallURLResp !== undefined && premiseActiveCallURLResp !== null && premiseActiveCallURLResp.length !== 0) {
		for (var i = 0; i < CREArray.length; i++) {
			for (var j = latestUpdatedDate.length - 1; j >= 0; j--) {
				if (latestUpdatedDate[j].id === CREArray[i].id) {
					var OdmresponseData = {};
					OdmresponseData.id = CREArray[i].responseData.__DecisionID__;
					OdmresponseData.premiseId = CREArray[i].responseData.response.premisesID;
					OdmresponseData.callType = CREArray[i].responseData.response.newCallCode;
					OdmresponseData.okToProceed = "true";
					OdmresponseData.action = CREArray[i].responseData.response.action;
					OdmresponseData.premiseStatus = "";
					OdmresponseData.ErrorDescription = "";
					for (var m = 0; m < callCodeIdArr.length; m++) {
						if (callCodeIdArr[m].id === CREArray[i].id) {
							existingCallCode = callCodeIdArr[m].externalCallCodeID
						}
					}
					if (existingCallCode === null || existingCallCode === '' || existingCallCode === undefined) {
					}
					else {
						OdmresponseData.existingCallCode = existingCallCode;
					}
					session.output.write(OdmresponseData);
					var odmresponseStatus = 'yes';
					ctx.setVariable("odmresponseStatus", odmresponseStatus);
					ctx.setVariable("OdmresponseData", OdmresponseData);
				}
			}
		}
		logger.info("Decision is CRE")
	}
	else {
		var OdmresponseData = {};
		OdmresponseData.id = CREArray[0].responseData.__DecisionID__;
		OdmresponseData.premiseId = CREArray[0].responseData.response.premisesID;
		OdmresponseData.callType = CREArray[0].responseData.response.newCallCode;
		OdmresponseData.okToProceed = "true";
		OdmresponseData.action = CREArray[0].responseData.response.action;
		OdmresponseData.premiseStatus = "";
		OdmresponseData.ErrorDescription = "";
		OdmresponseData.existingCallCode = "";
		session.output.write(OdmresponseData);
		var odmresponseStatus = 'yes';
		ctx.setVariable("odmresponseStatus", odmresponseStatus);
		ctx.setVariable("OdmresponseData", OdmresponseData);
		logger.info("Decision is CRE")
	}
}
