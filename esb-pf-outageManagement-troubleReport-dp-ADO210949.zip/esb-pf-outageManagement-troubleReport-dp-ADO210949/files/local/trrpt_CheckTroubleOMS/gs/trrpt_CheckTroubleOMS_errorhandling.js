/* This gateway script is used for Error Handling.
Date :14-May-2020
Author :Alekya Jaggannagari */
var ctx = session.name("Trouble") || session.createContext("Trouble");
var ilsctx = session.name('ILSExit') || session.createContext('ILSExit');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var jobTypeID = ctx.getVariable("jobTypeID");
var Id = ctx.getVariable("Id");
var callType = ctx.getVariable("callType");
var premiseid = ctx.getVariable("premiseid");
var premiseStatusResponseJson = ctx.getVariable("PremiseDataURLResp");
var responseStatusCode = ctx.getVariable("responseStatusCode");
var responsePhrase = ctx.getVariable("responsePhrase");
if (responseStatusCode == 404 || responseStatusCode == 400 || responseStatusCode == 401 || responseStatusCode == 403) {
	var premiseStatus = '';
	if (premiseStatusResponseJson === '' || premiseStatusResponseJson === undefined || premiseStatusResponseJson === null) {
		var premiseStatus = "NOTEXIST";
	}
	else {
		var premiseStatus = "";
	}
	var obj =
	{
		"Id": Id,
		"premiseId": premiseid,
		"callType": callType,
		"okToProceed": "False",
		"action": "Error",
		"premiseStatus": premiseStatus,
		"callId": "",
		"ErrorDescription": (responseStatusCode + responsePhrase)
	}
	hm.current.statusCode = responseStatusCode;
	session.output.write(obj);
	logger.debug("call api error " + JSON.stringify(obj));
	ilsctx.setVariable("errorResponse", obj)
}
else {
	var obj = {};
	obj.errorMessage = sm.getVar('var://service/error-message');
	if (premiseid == undefined || Id == undefined || callType == undefined || jobTypeID == '') {
		obj.errorCode = '400 Bad Request';
		hm.current.statusCode = '400'
		logger.error("trrpt_011 400 bad request error " + obj);
	}
	else {
		obj.errorCode = sm.getVar('var://service/error-code');
		obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
		obj.errorHeaders = sm.getVar('var://service/error-headers');
		hm.current.statusCode = '500'
	}

	session.output.write(obj);
}
