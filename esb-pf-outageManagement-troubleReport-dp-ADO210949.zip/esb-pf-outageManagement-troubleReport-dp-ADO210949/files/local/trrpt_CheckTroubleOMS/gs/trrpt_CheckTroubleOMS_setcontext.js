var ctx = session.name("Trouble")|| session.createContext("Trouble");
//set stylesheet parameters to variable

var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.apiToken;
var ODMEndpoint =session.parameters.ODMEndpoint;
var lookupURL = session.parameters.lookUpURL;
var nullcheck= session.parameters.nullcheck;
var testArray = [];
var odmresponseArray = [];
var DUPArray = [];
var CHGArray = [];
var CREArray = [];


//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js

ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("ODMEndpoint", ODMEndpoint);
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("nullcheck", nullcheck);
//written for ALM5385
ctx.setVariable("testArray", testArray);
ctx.setVariable("odmresponseArray", odmresponseArray);
ctx.setVariable("CREArray", CREArray);
ctx.setVariable("CHGArray", CHGArray);
ctx.setVariable("DUPArray", DUPArray);
