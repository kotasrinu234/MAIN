var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name('input');
var descriptionVal = ctx.getVar('descriptionVal');	// "myValue"
var contactMethodctx = session.name("contactMethod") || session.createContext("contactMethod");
var ILSctx = session.name("ILSExit") || session.createContext("ILSExit");
if (!(descriptionVal === 'N')) {
	if (ctx.getVar('description')) {
		var myContextVar1 = ctx.getVar('description');	// "myValue"
		if (myContextVar1 !== null || myContextVar1 !== undefined || myContextVar1 !== '') {
			var logger = console.options({
				'category': 'all'
			});
			var lookupMessage = {
				"lookupReq": {
					"type": [
						{
							"name": "contactMethodTypes",
							"label": myContextVar1
						}
					]
				}
			}


			var LookupServiceResponse = {
				target: session.parameters.lookupURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupMessage
			};
			var info = " TargetURL :" + LookupServiceResponse.target + "; Method :" + LookupServiceResponse.method + "; Data :" + JSON.stringify(LookupServiceResponse.data) + ". ";
			try {
				urlopen.open(LookupServiceResponse, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error with LookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error);
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('errorDescription', errorinfo);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "failure in putting message to LookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('errorDescription', errorinfo);
									logger.error(errorinfo);
								} else {
									contactMethodctx.setVariable("contactMethodLookup_invoked", 'Yes');
									contactMethodctx.setVariable("contactMethodLookup", responseData);
									contactMethodctx.setVariable("contactMethodLookup_status", responseData.lookupRep.type[0].status);
									logger.info("Response recived form the contact method lookup is " + JSON.stringify(responseData));
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "urlopen connect error with LookupServiceResponse, details are : " + info + "; error info :" + JSON.stringify(error);
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('errorDescription', errorinfo);
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	}
} else {
	contactMethodctx.setVariable("contactMethodLookup_invoked", 'No');
}
