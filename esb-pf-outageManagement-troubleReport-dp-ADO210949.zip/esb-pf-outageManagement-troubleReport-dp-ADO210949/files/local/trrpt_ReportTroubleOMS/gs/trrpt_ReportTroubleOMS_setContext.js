var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
'category' : 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
if (readAsJSONError) {
logger.error("Error in reading incoming data");
session.reject(readAsJSONError);
} else {

var ctx = session.name("Trouble")|| session.createContext("Trouble");
var callCheckctx = session.name("callCheckResponse") || session.createContext("callCheckResponse");
var omsExternalURL = session.parameters.omsExternalURL;
var lookupURL = session.parameters.lookupURL;
var logger = console.options({
    'category': 'all'
});
var CallCheckResp = {};
CallCheckResp = JSON.parse(callCheckctx.getVariable("Response"));

session.output.write(CallCheckResp);
}
});
