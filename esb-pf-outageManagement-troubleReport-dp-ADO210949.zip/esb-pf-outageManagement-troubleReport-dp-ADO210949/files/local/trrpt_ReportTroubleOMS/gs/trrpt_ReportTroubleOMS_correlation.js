var ctx = session.name("Trouble") || session.createContext("Trouble");
var ilsectx = session.name("ilsEntry") || session.createContext("ilsEntry");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var exitilsctx = session.name("ILSExit") || session.createContext("ILSExit");
var callCheckctx = session.name("callCheckResponse") || session.createContext("callCheckResponse");
var messageID = ilsectx.getVar("CorrelationID");
var eventTimeStamp = ilsectx.getVar("sourceEventTimestamp");
var uid = ilsctx.getVar("uniqueId");
var urlopen = require('urlopen');
var troubleId = exitilsctx.getVar("callDisplayID");
var imgeExitDescription = session.parameters.imgeExitDescription;
var callCheckResponse = JSON.parse(callCheckctx.getVar("Response"));
var action = callCheckResponse.action;
var omsResp = ctx.getVar("OMSresponseData");
var msgID;
var hm = require('header-metadata');
var logger = console.options({
	'category': 'all'
});
var attachments = ctx.getVar("attachments");
if ((omsResp && omsResp !== '' && omsResp !== null) || action === 'CHG') {
	if (attachments) {
		if (!(attachments == undefined || attachments == '' || attachments == null)) {
			function pushToArray(parameter) {
				var customArray = [];
				var splitParameter = parameter.split(',');
				for (var i = 0; i < splitParameter.length; i++) {
					customArray.push(splitParameter[i])
				}
				return customArray;
			}
			session.input.readAsJSON(function(readAsJSONError, incomingdata) {
				if (readAsJSONError) {
					logger.error("Error in reading incoming data");
					session.reject(readAsJSONError);
				}
				var json = incomingdata;
				if (messageID) {
					if (messageID !== undefined || messageID !== null || messageID !== '') {
						msgID = messageID;
					} else {
						msgID = uid;
					}
				}
				var eventTypeCorrelation = session.parameters.eventTypeCorrelation;
				var eventTypeToRelease = session.parameters.eventTypeRelease;
				var eventType = session.parameters.eventType;
				if (!(eventType === undefined || eventType === null || eventType === '')) {
					exitilsctx.setVar("eventType", eventType);
				}
				if (!(eventTypeCorrelation === undefined || eventTypeCorrelation === null || eventTypeCorrelation === '')) {
					var eventTypeCorrelationFun = pushToArray(eventTypeCorrelation)
				}
				if (!(eventTypeToRelease === undefined || eventTypeToRelease === null || eventTypeToRelease === '')) {
					var eventTypeToReleaseFun = pushToArray(eventTypeToRelease)
				}
				var payload = {
					"messageID": msgID,
					"serviceName": session.parameters.serviceName,
					"expiry": session.parameters.expiry,
					"eventTimeStamp": new Date().toISOString(),
					"sendTimeStamp": new Date().toISOString(),
					"eventType": session.parameters.eventType,
					"eventKey": troubleId,
					"waitTime": session.parameters.waitTime,
					"destQueueName": session.parameters.destQueueName,
					"eventTypeCorrelation": eventTypeCorrelationFun,
					"eventTypeToRelease": eventTypeToReleaseFun,
					"dataMappingRequirement": [
						{
							"mapping": {
								"sourceEventType": session.parameters.sourceEventType,
								"sourceField": session.parameters.sourceField,
								"destinationEventType": session.parameters.destinationEventType,
								"destinationField": session.parameters.destinationField
							}
						}
					],
					"payload": {
						"messageID": msgID,
						"jobID": session.parameters.jobID,
						"eventType": session.parameters.eventType,
						"eventKey": troubleId,
						"attachments":
							json.customFieldValues.attachments
					}
				}
				var ctx = session.name("Trouble") || session.createContext("Trouble");
				ctx.setVar("payload", payload);
				var StandaloneMQurl = session.parameters.MQUrl;
				var pushingToQueue = {
					target: StandaloneMQurl,
					data: payload
				};
				try {
					urlopen.open(pushingToQueue, function(error, response) {
						if (error) {
							var ctx = session.name("receivecall") || session.createContext("receivecall");
							var mqconnection = 'Forbidden';
							ctx.setVariable("mqconnection", mqconnection);
							logger.error("Error while keeping receivecall message to queue is " + error);
							session.reject("error while keeping receivecall message to queue is " + error);
						} else {
							var mqrc = response.statusCode;
							if (mqrc == 0) {
								var replyMQMD = response.get({
									type: 'mq'
								}, 'MQMD');
								var replyMQRFH2 = response.get({
									type: 'mq'
								}, 'MQRFH2');
								response.readAsBuffer(function(readError, responseData) {
									if (readError) {
										hm.response.statusCode = 500
										session.reject("error while keeping message receivecall to queue is " + error);
									} else {
										ilsctx.setVariable("reportTroubleImgExitDescription", imgeExitDescription);
										ilsctx.setVariable("reportTroubleImgExitDestination", StandaloneMQurl);
										var ms = require('multistep');
										ms.callRule('trrpt_ReportTroubleOMS_ImageUpload_rule', null, null, function(error) {
											if (error) {
												logger.error("Error in trrpt_ReportTroubleOMS_CrossSecretLookupCall_rule");
											}
										});
										logger.debug("MQResponsecode " + mqrc + responseData);
									}
								});
							} else {
								var ctx = session.name("Trouble") || session.createContext("Trouble");
								var mqconnection = 'Forbidden';
								ctx.setVariable("mqconnection", mqconnection);
								logger.error(" response code receivecall urlopen.open error [MQRC=" + mqrc + "]");
								session.reject(" response code receivecall is urlopen.open error [MQRC=" + mqrc + "]");

							}
						}
					});
				}
				catch (error) {
					var ctx = session.name("receivecall") || session.createContext("receivecall");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error("Error while keeping receivecall message to queue is " + error);
					session.reject("error while keeping receivecall message to queue is " + error);
				}
			});
		}
	}
}
