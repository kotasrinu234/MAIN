var ctx = session.name('Trouble') || session.createContext("Trouble");
var imagePayload = ctx.getVar("payload");
session.output.write(imagePayload);
