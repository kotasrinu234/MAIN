var ctx = session.name("Trouble") || session.createContext("Trouble");
var errorctx = session.name("error") || session.createContext("error");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var remarks = ctx.getVariable("remarks");
var omsExternalURL = session.parameters.omsExternalURL;
var logger = console.options({
    'category': 'all'
});
var incomingUrl = sm.getVar('var://service/routing-url');
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var incomingUser = currentUser;
var apiToken;
if (incomingUser === 'dcas-wismo-esb-dev' || incomingUser === 'dcas-wismo-esb-test' || incomingUser === 'dcas-wismo-esb-prod') {
	apiToken = session.parameters.ppsToken;
} else if (incomingUser === 'dcas-crb-esb-oms-dev' || incomingUser === 'dcas-crb-esb-oms-tst' || incomingUser === 'dcas-crb-esb-oms-prd' || incomingUser === 'tlab-esb-oms-dev' || incomingUser === 'tlab-esb-oms-test') {
/*else if (incomingUser === 'dcas-crb-esb-oms-dev' || incomingUser === 'dcas-crb-esb-oms-tst' || incomingUser === 'dcas-crb-esb-oms-prd') {*/
	apiToken = session.parameters.apiToken;
}
else if (incomingUser === 'atlas-esb-dev' || incomingUser === 'atlas-esb-test') {
	apiToken = session.parameters.atlasToken;
}
else if (incomingUser === 'dcas-oms-esb-ami-dev' || incomingUser === 'dcas-oms-esb-ami-tst' || incomingUser === 'dcas-oms-esb-ami-prd') {
	apiToken = session.parameters.compassToken;
}
else if(incomingUrl.includes('4671')){
	apiToken = session.parameters.FSEToken;
}
if ((apiToken === null || apiToken === undefined || apiToken === '')) { }
else {
	ctx.setVar("apiToken", apiToken);
}
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {
        var callCheckctx = session.name("callCheckResponse") || session.createContext("callCheckResponse");
        var CallChckResponse;
        var CallCheckResp = {};
        CallChckResponse = callCheckctx.getVariable("Response");
        if (!(CallChckResponse == undefined || CallChckResponse == '' || CallChckResponse == null)) {
            CallCheckResp = JSON.parse(CallChckResponse);
            var action = CallCheckResp.action;
            if (!(action == 'DUP' || action == 'CHG' || action == undefined || action == '' || action == null)) {
                var OMSRequest = incomingdata;
                if (!(incomingdata.observations == undefined)) {
                    var ObservationsArray = incomingdata.observations;

                    function removeDuplicates(DataArray) {
                        return DataArray.filter((value, index) => DataArray.indexOf(value) === index);
                    }
                    var OMSRequest = incomingdata;
                    OMSRequest.observations = removeDuplicates(ObservationsArray);
                    logger.debug("observations data is " + JSON.stringify(removeDuplicates(ObservationsArray)));
                    logger.debug("OMSRequest data is " + JSON.stringify(OMSRequest));
                }
                var omsapi = omsExternalURL + '/api/ServiceType/Electric/Call';
                var options = {
                    target: omsapi,
                    sslClientProfile: 'trrpt_ReportTroubleOMS_ClientProfile',
                    method: 'post',
                    contentType: 'application/json',
                    headers: {
                        'osiApiToken': apiToken
                    },
                    data: OMSRequest
                };

                logger.debug("options" + JSON.stringify(options));
                // open connection to target and send data over
                urlopen.open(options, function(error, response) {
                    if (error) {
                        // an error occurred during request sending or response header parsing
                        logger.error("trrpt_ReportTroubleOMS_003 urlopen connection error " + JSON.stringify(error));
                        session.reject("urlopen connection error");
                    } else {
                        // read response data
                        // get the response status code
                        var responseStatusCode = response.statusCode;
                        var responseReasonPhrase = response.reasonPhrase;
                        if (responseStatusCode == 200) {
                            response.readAsJSON(function(error, responseData) {
                                if (error) {
                                    // error while reading response or transferring data to Buffer
                                    logger.error("trrpt_ReportTroubleOMS_011: Error reading response from OMS: " + JSON.stringify(error));
                                } else {
                                    ctx.setVariable("OMSresponseData", responseData);
                                    var jobID = responseData.jobID;
									var jobDisplayID = responseData.jobDisplayID;
									if(!(jobID ==="" || jobID ===undefined || jobID ===null)){
										ctx.setVariable("CREJobId", jobID);
									}
									else{
										ctx.setVariable("CREJobId", '');
									}
									if(!(jobDisplayID ==="" || jobDisplayID ===undefined || jobDisplayID ===null)){
										ctx.setVariable("CREjobDisplayID", jobDisplayID);
									}
									else{
										ctx.setVariable("CREjobDisplayID", '');
									}
                                    session.output.write(responseData);
                                    logger.debug(responseData);
                                }
                            });
                        } else {
                            response.readAsBuffer(function(error, responseData) {
                                if (error) {
                                    // error while reading response or transferring data to Buffer
                                    logger.error("failure reading response from OMS api" + JSON.stringify(error));
                                    session.output.write("failure reading response from OMS api");
                                } else {
                                    hm.response.statusCode = responseStatusCode;
                                    var response = session.createContext('ReporteTroubleOMS');
                                    response.setVar('omsstatuscode', responseStatusCode);
                                    response.setVar('omsresponse', responseData.toString());
                                    errorctx.setVar('errorURLMessage', (response.statusCode + response.reasonPhrase));
                                    sm.setVar('var://service/error-protocol-reason-phrase', responseData.toString());
                                    logger.error("trrpt_ReportTroubleOMS_004: Error response returned from OMS is : " + responseData + "  with status code : " + responseStatusCode);
                                    session.reject("Error response returned from OMS is : " + responseData + "  with status code : " + responseStatusCode);
                                };
                            });
                        }
                    }
                }); // end of urlopen.open()

            } else {
                var obj = {
                    "case": " other than DUP or CHG",
                    "process": "continue with CRE request"
                }
                session.output.write(obj);
            }
        }
    }
});
