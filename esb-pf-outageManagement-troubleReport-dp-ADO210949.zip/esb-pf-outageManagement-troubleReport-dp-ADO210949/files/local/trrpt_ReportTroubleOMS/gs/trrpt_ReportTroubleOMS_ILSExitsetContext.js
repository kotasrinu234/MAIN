var logger = console.options({
	'category': 'all'
});
var ctx1 = session.name('Trouble') || session.createContext('Trouble');
var premiseID = ctx1.getVariable("premiseId");
var CrossStreetLookupURL = ctx1.getVariable("CrossStreetLookupURL");
var ctx2 = session.name('callCheckResponse') || session.createContext('callCheckResponse');
var callCheckResponse = ctx2.getVariable("Response");
var ctx = session.name('ILSExit') || session.createContext('ILSExit');
if (!(premiseID)) {
	var exitDescription = session.parameters.reportTroubleExitCSDescription;
	ctx.setVariable("exitDescription", exitDescription);
	var exitDestination = CrossStreetLookupURL;
	ctx.setVariable("exitDestination", exitDestination);
	var ms = require('multistep');
	ms.callRule('trrpt_ReportTroubleOMS_CrossSecretLookupCall_rule', null, null, function(error) {
		if (error) {
			logger.error("Error in trrpt_ReportTroubleOMS_CrossSecretLookupCall_rule");
		}
	});
}
else {
	if (premiseID !== undefined || premiseID !== null || premiseID !== '') {
		var incomingdata = JSON.parse(callCheckResponse);
		var callID = incomingdata.callId;
		var action = incomingdata.action;
		var okToProceed = incomingdata.okToProceed;
		if (!(incomingdata.existingCallCode == undefined || incomingdata.existingCallCode == '' || incomingdata.existingCallCode == null)) {
			var existingCallCode = incomingdata.existingCallCode;
			ctx.setVariable("existingCallCode", existingCallCode);
		}
		if (action == 'CRE') {
			ctx.setVariable("callID", '');
		} else {
			ctx.setVariable("callID", callID);
		}
		var exitDescription = session.parameters.reportTroubleExitCCDescription;
		ctx.setVariable("exitDescription", exitDescription);
		if (action !== undefined || action !== null || action !== '') {
			ctx.setVariable("action", action);
		}
		if (okToProceed !== undefined || okToProceed !== null || okToProceed !== '') {
			ctx.setVariable("okToProceed", okToProceed);
		}
		var exitDestination = session.parameters.CheckTroubleUrl;
		ctx.setVariable("exitDestination", exitDestination);
		var ms = require('multistep');
		ms.callRule('trrpt_ReportTroubleOMS_callcheck_rule', null, null, function(error) {
			if (error) {
				logger.error("Error in trrpt_ReportTroubleOMS_callcheck_rule");
			}
		});
	}
}
