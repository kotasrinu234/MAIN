var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var patchURLResponse = require('./urlOpenUtils.js');
var ctx = session.name("Trouble") || session.createContext("Trouble");
var ctxpatch = session.name("patchCallRes") || session.createContext("patchCallRes");
var ctxp = session.name("patchReslookup") || session.createContext("patchReslookup");
var callCheckctx = session.name("callCheckResponse") || session.createContext("callCheckResponse");
var ctxi = session.name("ilsEntry") || session.createContext("ilsEntry");
var callIDTBTFlag = ctxi.getVar("callIDTBTFlag");
var callIDTBT = ctxi.getVar("callIDTBT");
var contactPhone = ctxi.getVar("contactPhone");
var attachments = ctxi.getVar("attachments");
var patchPayloadDUP = {};
var patchPayloadCHG = {};
var displayID = '';
var omsExternalURL = session.parameters.omsExternalURL;
var lookupURL = session.parameters.lookupURL;
var troubleCode = ctx.getVariable("troubleCode");
var premiseId = ctx.getVariable("premiseId");
var callType = ctx.getVariable("callType");
var remarks = ctxi.getVar("remarks");
var logger = console.options({
	'category': 'all'
});
var incomingUrl = sm.getVar('var://service/routing-url');
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var incomingUser = currentUser;
var apiToken;

if (incomingUser === 'dcas-wismo-esb-dev' || incomingUser === 'dcas-wismo-esb-test' || incomingUser === 'dcas-wismo-esb-prod') {
	apiToken = session.parameters.ppsToken;
} else if (incomingUser === 'dcas-crb-esb-oms-dev' || incomingUser === 'dcas-crb-esb-oms-tst' || incomingUser === 'dcas-crb-esb-oms-prd' || incomingUser === 'tlab-esb-oms-dev' || incomingUser === 'tlab-esb-oms-test') {
/*else if (incomingUser === 'dcas-crb-esb-oms-dev' || incomingUser === 'dcas-crb-esb-oms-tst' || incomingUser === 'dcas-crb-esb-oms-prd') {*/
	apiToken = session.parameters.apiToken;
}
else if (incomingUser === 'atlas-esb-dev' || incomingUser === 'atlas-esb-test') {
	apiToken = session.parameters.atlasToken;
}
else if (incomingUser === 'dcas-oms-esb-ami-dev' || incomingUser === 'dcas-oms-esb-ami-tst' || incomingUser === 'dcas-oms-esb-ami-prd') {
	apiToken = session.parameters.compassToken;
}
else if (incomingUrl.includes('4671')) {
	apiToken = session.parameters.FSEToken;
}
if ((apiToken === null || apiToken === undefined || apiToken === '')) { }
else {
	ctx.setVar("apiToken", apiToken);
}

var CallCheckResp = JSON.parse(callCheckctx.getVariable("Response"));
logger.info("CallCheckResp incoming data" + JSON.stringify(CallCheckResp));
if (!(CallCheckResp == undefined || CallCheckResp == '' || CallCheckResp == null || CallCheckResp.action == "NoPremiseID")) {
	if (CallCheckResp.okToProceed) {
		var incomingdata = CallCheckResp;
		var callId = incomingdata.callId;
		var action = incomingdata.action;
		var callType = incomingdata.callType;
		if (!(incomingdata.existingCallCode == undefined || incomingdata.existingCallCode == '' || incomingdata.existingCallCode == null)) {
			var existingCallCode = incomingdata.existingCallCode;
		}
		if (!(incomingdata.callInternalId == undefined || incomingdata.callInternalId == '' || incomingdata.callInternalId == null)) {
			var callInternalId = incomingdata.callInternalId;
		}
		if (!(incomingdata.changeFromNonOutageToOutage == undefined || incomingdata.changeFromNonOutageToOutage == '' || incomingdata.changeFromNonOutageToOutage == null)) {
			var changeFromNonOutageToOutage = incomingdata.changeFromNonOutageToOutage;
		}
		ctx.setVariable("action", action);
		/* ctx.setVariable("callId", callId); */
		ctx.setVariable("callType", callType);
		if (action == 'CRE') {
			ctx.setVariable("callId", '');
		} else {
			ctx.setVariable("callId", callId);
		}
		if (action == 'CRE') {

		} else if (action == 'DUP') {
			var optionsCall = {
				target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/' + callInternalId,
				method: "GET",
				headers: {
					"osiApiToken": apiToken
				},
				contentType: "application/json",
				sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
			};
			urlopen.open(optionsCall, function(error, response) {
				if (error) {
					logger.error("urlopen connect error with get call api DUP" + JSON.stringify(error));
					session.reject("urlopen connect error with get call api DUP" + JSON.stringify(error));
				}
				else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, Response) {
							if (error) {
								// error while reading response or transferring data to Buffer
								logger.error("failure reading response from get call api DUP" + JSON.stringify(error));
								session.reject("failure reading response from get call api DUP" + JSON.stringify(error));
							} else {
								if (Response) {
									var callResponse = JSON.parse(Response);
									ctx.setVar("callResponseData", callResponse);
									if (!(callResponse.jobID === "" || callResponse.jobID === undefined || callResponse.jobID === null)) {
										ctx.setVariable("DUPJobId", callResponse.jobID);
									}
									if (!(callResponse.displayID === '' || callResponse.displayID === undefined || callResponse.displayID === null)) {
										ctx.setVariable("displayID", callResponse.displayID);

									} else {
										ctx.setVariable("displayID", '');
									}

									if (!(callResponse.externalCallCodeID === undefined || callResponse.externalCallCodeID === '' || callResponse.externalCallCodeID === null)) {
										ctx.setVariable("externalCallCodeID", callResponse.externalCallCodeID);

									} else {
										ctx.setVariable("externalCallCodeID", '');
									}

									if (callResponse.notes === null || callResponse.notes === '' || callResponse.notes === undefined) {
										ctx.setVariable("notes", '');

									} else {
										ctx.setVariable("notes", callResponse.notes);
									}
									if (!(callResponse.externalPremiseID === undefined || callResponse.externalPremiseID === '' || callResponse.externalPremiseID === null)) {
										ctx.setVariable("externalPremiseID", callResponse.externalPremiseID);

									} else {
										ctx.setVariable("externalPremiseID", '');
									}
									if (!(callResponse.address === undefined || callResponse.address === '' || callResponse.address === null)) {
										ctx.setVariable("address", callResponse.address);

									} else {
										ctx.setVariable("address", '');
									}
									if (!(callResponse.startedTime === undefined || callResponse.startedTime === '' || callResponse.startedTime === null)) {
										ctx.setVariable("offDate", callResponse.startedTime);
									} else {
										ctx.setVariable("offDate", '');
									}
									if (!(callResponse.customFieldValuesExt === null || callResponse.customFieldValuesExt === '' || callResponse.customFieldValuesExt === undefined)) {
										var CustomFieldValuesExt = callResponse.customFieldValuesExt;
										if (!(CustomFieldValuesExt.Municipality === null || CustomFieldValuesExt.Municipality === '' || CustomFieldValuesExt.Municipality === undefined)) {
											ctx.setVariable("Municipality", CustomFieldValuesExt.Municipality);
										} else {
											ctx.setVariable("Municipality", '');
										}
									} else {
										ctx.setVariable("Municipality", '');
									}
									if (callResponse.jobID) {
										if (!(callResponse.jobID === null || callResponse.jobID === '' || callResponse.jobID === undefined)) {
											var Joboptions = {
												target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + callResponse.jobID,
												method: "get",
												headers: {
													"osiApiToken": apiToken
												},
												contentType: "application/json",
												sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
											};
											logger.info("urlopen::" + JSON.stringify(Joboptions));
											urlopen.open(Joboptions, function(error, Jobresponse) {
												if (error) {
													// an error occurred during reading the file
													logger.debug("urlopen error invoking Job API for ID " + callResponse.jobID);
												} else {
													var responseStatusCode = Jobresponse.statusCode;
													ctx.setVariable("responseStatusCode", responseStatusCode);
													logger.debug("response code" + responseStatusCode);
													var responsePhrase = Jobresponse.reasonPhrase;
													ctx.setVariable("responsePhrase", responsePhrase);
													if (responseStatusCode == 200) {
														Jobresponse.readAsJSON(function(error, jobIDResponseData) {
															if (error) {
																// error while reading response or transferring data to Buffer
																logger.debug("error reading response from Job API for ID " + callResponse.jobID);
															} else {
																if (!(jobIDResponseData === '' || jobIDResponseData === null || jobIDResponseData === undefined)) {
																	ctx.setVariable("jobIDResponse", jobIDResponseData);
																	if (!(jobIDResponseData.displayID === undefined || jobIDResponseData.displayID === '' || jobIDResponseData.displayID === null)) {
																		ctx.setVariable("jobDisplayID", jobIDResponseData.displayID);
																	} else {
																		ctx.setVariable("jobDisplayID", '');
																	}
																	if (!(jobIDResponseData.nominalFeeder === undefined || jobIDResponseData.nominalFeeder === '' || jobIDResponseData.nominalFeeder === null)) {
																		ctx.setVariable("nominalFeeder", jobIDResponseData.nominalFeeder);
																	} else {
																		ctx.setVariable("nominalFeeder", '');
																	}
																	if (!(jobIDResponseData.etr === undefined || jobIDResponseData.etr === '' || jobIDResponseData.etr === null)) {
																		var EtVal = jobIDResponseData.etr;
																		if (!(EtVal.value === undefined || EtVal.value === '' || EtVal.value === null)) {
																			ctx.setVariable("etrvalue", EtVal.value);
																		} else {
																			ctx.setVariable("etrvalue", '');
																		}
																	} else {
																		ctx.setVariable("etrvalue", '');
																	}
																	// logic for businessexception in response to CRM
																	fs.readAsJSON("local:///trrpt_ReportTroubleOMS/gs/NoEstimateForListofTroubleCodes.json", function(error, TroubleCodeRes) {
																		if (error) {
																			logger.debug("error reading troublecodes file" + error)
																		} else {
																			logger.debug("TroubleCode array is" + JSON.stringify(TroubleCodeRes));
																			var isTroubleCodeIncludes = false;
																			var TroubleCodes = [];
																			TroubleCodes = TroubleCodeRes.TroubleCodes;
																			var TroubleCodesLength = TroubleCodes.length;
																			var TroubleCodeVal = callResponse.externalCallCodeID;
																			for (var h = 0; h < TroubleCodesLength; h++) {
																				if (TroubleCodes[h] === TroubleCodeVal) {
																					isTroubleCodeIncludes = true;
																				}
																			}
																			//var isTroubleCodeIncludes = TroubleCodes.includes(ctx.getVariable("externalCallCodeID"));
																			logger.debug("isTroubleCodeIncludes" + isTroubleCodeIncludes);
																			if (isTroubleCodeIncludes) {
																				ctx.setVariable("BusinessException", "No Estimated restoration times are given for a trouble code of :" + callResponse.externalCallCodeID);
																			} else if (!(jobIDResponseData.etr === undefined || jobIDResponseData.etr === '' || jobIDResponseData.etr === null)) {
																				var ETValue = jobIDResponseData.etr;
																				if (ETValue.value === undefined || ETValue.value === '' || ETValue.value === null) {
																					ctx.setVariable("BusinessException", "No estimate is available");
																				} else {
																					var ETValue = jobIDResponseData.etr;
																					var CurrentTime = new Date().toISOString();
																					logger.info("current time is " + CurrentTime);
																					logger.info("ETR value is " + ETValue.value);
																					var etrValue = ETValue.value;
																					if (CurrentTime > etrValue) {
																						ctx.setVariable("BusinessException", "Estimate is expired");
																					}
																				}
																			} else {
																				ctx.setVariable("BusinessException", "No estimate is available");
																			}

																		}
																	});
																	if (!(jobIDResponseData.customFieldValuesExt === undefined || jobIDResponseData.customFieldValuesExt === '' || jobIDResponseData.customFieldValuesExt === null)) {
																		var CustomFieldValuesExt = jobIDResponseData.customFieldValuesExt;
																		if (!(CustomFieldValuesExt.cause === undefined || CustomFieldValuesExt.cause === '' || CustomFieldValuesExt.cause === null)) {
																			ctx.setVariable("cause", CustomFieldValuesExt.cause);
																		} else {
																			ctx.setVariable("cause", '');
																		}
																	} else {
																		ctx.setVariable("cause", '');
																	}
																	if (!(jobIDResponseData.networkModelName === undefined || jobIDResponseData.networkModelName === '' || jobIDResponseData.networkModelName === null)) {
																		ctx.setVariable("networkModelName", jobIDResponseData.networkModelName);
																	} else {
																		ctx.setVariable("networkModelName", '');
																	}
																	if (!(jobIDResponseData.regionName === null || jobIDResponseData.regionName === '' || jobIDResponseData.regionName === undefined)) {
																		ctx.setVariable("regionName", jobIDResponseData.regionName);
																	} else {
																		ctx.setVariable("regionName", '');
																	}
																	if (!(jobIDResponseData.totalAffected === undefined || jobIDResponseData.totalAffected === '' || jobIDResponseData.totalAffected === null)) {
																		ctx.setVariable("totalAffected", jobIDResponseData.totalAffected);
																	} else {
																		ctx.setVariable("totalAffected", '');
																	}
																	if (!(jobIDResponseData.currentAffected === undefined || jobIDResponseData.currentAffected === '' || jobIDResponseData.currentAffected === null)) {
																		ctx.setVariable("currentAffected", jobIDResponseData.currentAffected);
																	} else {
																		ctx.setVariable("currentAffected", '');
																	}
																	var lookupMessage = {
																		"lookupReq": {
																			"type": [{
																				"name": "jobTypes.workflows",
																				"id": jobIDResponseData.jobTypeID,
																				"status": jobIDResponseData.status
																			}, {
																				"name": "operationModes",
																				"id": jobIDResponseData.createdOperationModeID,
																				"status": "none"
																			}, {
																				"name": "aors",
																				"id": jobIDResponseData.aorID,
																				"status": "none"
																			}, {
																				"name": "callCodesJobTypeID",
																				"label": incomingdata.callType
																			}]
																		}
																	}
																	logger.info("url look up request" + JSON.stringify(lookupMessage));
																	var LookupServiceResponse = {
																		target: session.parameters.lookupURL,
																		method: 'POST',
																		contentType: 'application/json',
																		data: lookupMessage
																	};
																	urlopen.open(LookupServiceResponse, function(error, Lookupresponse) {
																		if (error) {
																			logger.debug("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
																		} else {
																			var responseStatusCode = Lookupresponse.statusCode;
																			if (responseStatusCode == 200) {
																				Lookupresponse.readAsJSON(function(error, responseData) {
																					if (error) {
																						// error while reading response or transferring data to Buffer
																						logger.debug("failure in putting message to LookupServiceResponse" + JSON.stringify(error));
																					} else {
																						hm.response.statusCode = responseStatusCode;
																						logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
																						var lookupResp = [];
																						lookupResp = responseData.lookupRep.type;
																						var lookupRespLength = lookupResp.length;
																						logger.debug("response length received is " + lookupResp.length);
																						for (var i = 0; i < lookupRespLength; i++) {
																							if (responseData.lookupRep.type[i].result == 0) {
																								var ctx = session.name("Trouble") || session.createContext("Trouble");
																								if (responseData.lookupRep.type[i].name == "jobTypes.workflows") {
																									ctx.setVariable("jobStatus", responseData.lookupRep.type[i].label);
																								} else if (responseData.lookupRep.type[i].name == "operationModes") {
																									ctx.setVariable("stormMode", responseData.lookupRep.type[i].label);
																								} else if (responseData.lookupRep.type[i].name == "aors") {
																									ctx.setVariable("dispatchGroup", responseData.lookupRep.type[i].label);
																								} else if (responseData.lookupRep.type[i].name == "callCodesJobTypeID") {
																									var checkforOutage = {
																										"lookupReq": {
																											"type": [{
																												"name": "jobOutageTypes",
																												"id": responseData.lookupRep.type[i].id
																											}]
																										}

																									}
																									var OutageLookupResponse = {
																										target: session.parameters.lookupURL,
																										method: 'POST',
																										contentType: 'application/json',
																										data: checkforOutage
																									};
																									urlopen.open(OutageLookupResponse, function(error, response) {
																										if (error) {
																											logger.debug("urlopen connect error with OutageLookupResponse" + JSON.stringify(error));
																											//throw error;
																										} else {
																											var responseStatusCode = response.statusCode;
																											if (responseStatusCode == 200) {
																												response.readAsJSON(function(error, responseData) {
																													if (error) {
																														// error while reading response or transferring data to Buffer
																														logger.debug("failure in putting message to OutageLookupResponse " + JSON.stringify(error));
																													} else {
																														hm.response.statusCode = responseStatusCode;
																														logger.debug("response received from OutageLookupResponse " + JSON.stringify(responseData));
																														ctx.setVariable("responseData", responseData);
																														if (responseData.lookupRep.type[0].result == 0) {
																															ctx.setVariable("outage", responseData.lookupRep.type[0].label);

																														} //lookup end
																														else {
																															//session.reject('jobTypeID is Non Valid.');
																															logger.debug("outageType " + outageType);
																														}
																													}
																												});
																											} else {
																												logger.debug("Outagelookup response is not 200");
																												//session.reject("Outagelookup response is not 200");
																											}
																										}
																									});


																								}

																							} else {
																								if (responseData.lookupRep.type[i].name == "jobTypes.workflows") {
																									ctx.setVariable("jobStatus", '');
																								} else if (responseData.lookupRep.type[i].name == "operationModes") {
																									ctx.setVariable("stormMode", '');
																								} else if (responseData.lookupRep.type[i].name == "aors") {
																									ctx.setVariable("dispatchGroup ", '');
																								} else if (responseData.lookupRep.type[i].name == "callCodesJobTypeID") {
																									ctx.setVariable("callCodesJobTypeID", '');
																								}
																							}

																						}
																					}
																				});
																			}
																		}
																	});
																	// new change
																	//ADO91545
																	var CommentApiUri = omsExternalURL + '/api/ServiceType/Electric/Call/' + callInternalId + '/Comment'; // As per ADO 152134 callResponse.jobID changed to callInternalId
																	var Comment = {
																		"comment": 'Customer is also trying to report ' + troubleCode + ' Customer Remarks:' + remarks + ' Premise No: ' + premiseId
																	}
																	var options = {
																		target: CommentApiUri,
																		method: "post",
																		headers: {
																			"osiApiToken": apiToken
																		},
																		contentType: "application/json",
																		sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile",
																		data: Comment
																	};
																	urlopen.open(options, function(error, response) {
																		if (error) {
																			logger.info("urlopen error at GetCrewAssignmentApiUri : " + JSON.stringify(error));
																			//hm.current.statusCode = '500';
																		} else {
																			var responseStatusCode = response.statusCode;
																			ctx.setVariable("responseStatusCode", responseStatusCode);
																			logger.info("response code" + responseStatusCode);
																			var responsePhrase = response.reasonPhrase;
																			ctx.setVariable("responsePhrase", responsePhrase);
																			if (responseStatusCode == 200 || responseStatusCode == 400) {
																				response.readAsJSON(function(error, responseData) {
																					logger.info("comment call is successful");
																				});
																			} else {
																				response.readAsBuffer(function(error, ErrorresponseData) {
																					if (error) {
																						// error while reading response or transferring data to Buffer
																						logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																						session.output.write("failure reading response from CommentApi api");
																					} else {
																						hm.response.statusCode = response.statusCode;
																						logger.error("  Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																						session.reject("Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																					}
																				});

																			}
																		}
																	});
																	if (contactPhone) {
																		if (contactPhone !== undefined || contactPhone !== '' || contactPhone !== null) {
																			var phnNumPayload = {
																				"phoneNumber": contactPhone
																			};
																		}

																	}
																	patchPayloadDUP = {
																		...patchPayloadDUP,
																		...phnNumPayload
																	}
																	ctxi.setVar("patchPayloadDUPPN", patchPayloadDUP);
																	if (callIDTBTFlag) {
																		if (callIDTBTFlag !== undefined || callIDTBTFlag !== '' || callIDTBTFlag !== null) {
																			if (callIDTBT) {
																				if (callIDTBT !== undefined || callIDTBT !== '' || callIDTBT !== null) {
																					var callIDTBT_FlagPayload = {
																						"customFieldValues": {
																							"TBTOriginalCallNumber": callIDTBT,
																							"TBT": callIDTBTFlag
																						}

																					};
																					patchPayloadDUP = {
																						...patchPayloadDUP,
																						...callIDTBT_FlagPayload
																					}
																				}
																			}
																			else {
																				var callIDTBTFlagPayload = {
																					"customFieldValues": {
																						"TBT": callIDTBTFlag
																					}

																				};
																				patchPayloadDUP = {
																					...patchPayloadDUP,
																					...callIDTBTFlagPayload
																				}
																			}

																		}

																	}
																	else if (callIDTBT) {
																		if (callIDTBT !== undefined || callIDTBT !== '' || callIDTBT !== null) {
																			var callIDTBTPayload = {
																				"customFieldValues": {
																					"TBTOriginalCallNumber": callIDTBT
																				}

																			};
																			patchPayloadDUP = {
																				...patchPayloadDUP,
																				...callIDTBTPayload
																			}
																		}
																	}
																	ctxi.setVar("patchPayloadDUPCallIDTBTFlag", patchPayloadDUP);
																	var patchUrlDUP = session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/' + callInternalId
																	patchURLResponse(patchUrlDUP, "patchCallDUP", patchPayloadDUP);
																	/*var CommentApiUri = omsExternalURL + '/api/ServiceType/Electric/Job/' + callResponse.jobID + '/Comment'; // As per ADO 152134 callResponse.jobID changed to callInternalId
																	var Comment = {
																		"comment": 'Customer is also trying to report ' + troubleCode + ' Customer Remarks:' + remarks + ' Premise No: ' + premiseId
																	}
																	var options = {
																		target: CommentApiUri,
																		method: "post",
																		headers: {
																			"osiApiToken": apiToken
																		},
																		contentType: "application/json",
																		sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile",
																		data: Comment
																	};
																	urlopen.open(options, function(error, response) {
																		if (error) {
																			logger.info("urlopen error at GetCrewAssignmentApiUri : " + JSON.stringify(error));
																			//hm.current.statusCode = '500';
																		} else {
																			var responseStatusCode = response.statusCode;
																			ctx.setVariable("responseStatusCode", responseStatusCode);
																			logger.info("response code" + responseStatusCode);
																			var responsePhrase = response.reasonPhrase;
																			ctx.setVariable("responsePhrase", responsePhrase);
																			if (responseStatusCode == 200 || responseStatusCode == 400) {
																				response.readAsJSON(function(error, responseData) {
																					logger.info("comment call is successful");
																				});
																			} else {
																				response.readAsBuffer(function(error, ErrorresponseData) {
																					if (error) {
																						// error while reading response or transferring data to Buffer
																						logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																						session.output.write("failure reading response from CommentApi api");
																					} else {
																						hm.response.statusCode = response.statusCode;
																						logger.error("  Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																						session.reject("Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																					}
																				});

																			}
																		}
																	});*/
																} else logger.info("response received from Job API  " + JSON.stringify(jobIDResponseData));

															}
														});
													} else {
														response.readAsBuffer(function(error, ErrorresponseData) {
															if (error) {
																// error while reading response or transferring data to Buffer
																logger.error("failure reading response from Job API api" + JSON.stringify(error));
																session.output.write("failure reading response from Job API api");
															} else {
																logger.info("response code received from Job API  " + callResponse.jobID + "Status code is " + responseStatusCode + "and the reason is " + ErrorresponseData);
															}
														});
													}

												}
											});

										}
									}
								}
							}
						});
					}
					else {
						response.readAsBuffer(function(error, ErrorresponseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								logger.error("failure reading response from get call api" + JSON.stringify(error));
								session.reject("failure reading response from get call api" + JSON.stringify(error));
							} else {
								hm.response.statusCode = response.statusCode;
								logger.error("error response from get call api DUP" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								session.reject("error response from get call api DUP" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
							}
						});
					}
				}
			});
		}
		else if (action == 'CHG') {
			if (changeFromNonOutageToOutage === 'Y') {
				var optionsCall = {
					target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/' + callInternalId + '?includeFields=jobDisplayID,jobID',
					method: "GET",
					headers: {
						"osiApiToken": apiToken
					},
					contentType: "application/json",
					sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
				};
				urlopen.open(optionsCall, function(error, response) {
					if (error) {
						logger.error("urlopen connect error with get call api CHG" + JSON.stringify(error));
						session.reject("urlopen connect error with get call api CHG" + JSON.stringify(error));
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, response) {
								if (error) {
									// error while reading response or transferring data to Buffer
									logger.error("failure reading response from get call api CHG" + JSON.stringify(error));
									session.reject("failure reading response from get call api CHG" + JSON.stringify(error));
								} else {
									hm.response.statusCode = '200 OK';
									var responseData = JSON.parse(response);
									var jobDisplayID = responseData.jobDisplayID;
									var jobID1 = responseData.jobID;
									ctx.setVar("getCallResponse", responseData);
									var optionsJob = {
										target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Job/' + jobID1 + '?includeFields=outageSubtypeID',
										method: "GET",
										headers: {
											"osiApiToken": apiToken
										},
										contentType: "application/json",
										sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
									};
									urlopen.open(optionsJob, function(error, response) {
										if (error) {
											logger.error("urlopen connect error with get call api CHG" + JSON.stringify(error));
											session.reject("urlopen connect error with get call api CHG" + JSON.stringify(error));
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseOutage) {
													if (error) {
														// error while reading response or transferring data to Buffer
														logger.error("failure reading response from get call api CHG" + JSON.stringify(error));
														session.reject("failure reading response from get call api CHG" + JSON.stringify(error));
													} else {
														hm.response.statusCode = '200 OK';
														var responseData = JSON.parse(responseOutage);
														var outageSubtypeID = responseData.outageSubtypeID;
														ctx.setVar("getCallResponse", responseData);
														var CommentApiUri = omsExternalURL + '/api/ServiceType/Electric/Job/' + jobID1 + '/Comment';
														var Comment = {
															"comment": 'Changed call code from ' + existingCallCode + ' to ' + troubleCode + ' due to customer reporting ' + troubleCode + " Customer Remarks: " + remarks + " Premise No : " + premiseId
														}
														var options = {
															target: CommentApiUri,
															method: "post",
															headers: {
																"osiApiToken": apiToken
															},
															contentType: "application/json",
															sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile",
															data: Comment
														};
														urlopen.open(options, function(error, response) {
															if (error) {
																logger.error("urlopen error at CommentApiUri : " + JSON.stringify(error));
																session.reject("urlopen error at CommentApiUri : " + JSON.stringify(error));
																//hm.current.statusCode = '500';
															} else {
																var responseStatusCode = response.statusCode;
																var responsePhrase = response.reasonPhrase;
																if (responseStatusCode == 200 || responseStatusCode == 400) {
																	response.readAsJSON(function(error, responseData) {
																		if (error) {
																			logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																			session.reject("failure reading response from CommentApi api");
																		}
																		else {
																			var lookupcallType = incomingdata.callType;
																			var lookupMessage = {
																				"lookupReq": {
																					"type": [{
																						"name": "callCodes",
																						"label": lookupcallType
																					}]
																				}
																			}
																			var crewsTypelookupResponse = {
																				target: lookupURL,
																				method: 'POST',
																				contentType: 'application/json',
																				data: lookupMessage
																			};
																			urlopen.open(crewsTypelookupResponse, function(error, response) {
																				if (error) {
																					logger.error("urlopen connect error from crewsTypelookupResponse" + JSON.stringify(error));
																					session.reject("urlopen connect error from crewsTypelookupResponse" + JSON.stringify(error));
																				}
																				else {
																					var responseStatusCode = response.statusCode;
																					if (responseStatusCode == 200) {
																						response.readAsJSON(function(error, responseData) {
																							if (error) {
																								logger.error("Failure in reading the message for crewsTypelookupResponse" + JSON.stringify(error));
																								session.reject("Failure in reading the message for crewsTypelookupResponse" + JSON.stringify(error));
																							}
																							else {
																								hm.response.statusCode = responseStatusCode;
																								ctx.setVariable("res", responseData);
																								if (responseData.lookupRep.type[0].result == 0) {
																									var id = responseData.lookupRep.type[0].id;
																									var callCodeIDdata = {
																										"callCodeID": id
																									}
																									var CallPATCHapi = {
																										target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + callInternalId,
																										sslClientProfile: 'trrpt_ReportTroubleOMS_ClientProfile',
																										method: 'PATCH',
																										contentType: 'application/json',
																										headers: {
																											'osiApiToken': apiToken
																										},
																										data: callCodeIDdata
																									};
																									urlopen.open(CallPATCHapi, function(error, response) {
																										if (error) {
																											logger.error("trrpt_ReportTroubleOMS_008 urlopen connect error with patch call api CHG" + id + JSON.stringify(error));
																											session.reject("Error invoking patch call api CHG");
																										} else {
																											var responseStatusCode = response.statusCode;
																											if (responseStatusCode == 200) {
																												response.readAsBuffer(function(error, responsePatch) {
																													if (error) {
																														// error while reading response or transferring data to Buffer
																														logger.error(" trrpt_ReportTroubleOMS_009 failure reading response Wfrom patch call api CHG" + id + JSON.stringify(error));
																														session.reject("failure reading response from patch call api CHG");
																													} else {
																														var responseData = JSON.parse(responsePatch);
																														var CallPATCHapi_response = JSON.parse(responsePatch);
																														if (!(CallPATCHapi_response.displayID === null || CallPATCHapi_response.displayID === undefined || CallPATCHapi_response.displayID === '')) {
																															ctxpatch.setVariable("CallPATCHapi_res_displayID", CallPATCHapi_response.displayID);
																														} else {
																															ctxpatch.setVariable("CallPATCHapi_res_displayID", '');
																														}
																														if (!(CallPATCHapi_response.jobID === null || CallPATCHapi_response.jobID === undefined || CallPATCHapi_response.jobID === '')) {
																															ctxpatch.setVariable("CallPATCHapi_res_jobID", CallPATCHapi_response.jobID);
																														} else {
																															ctxpatch.setVariable("CallPATCHapi_res_jobID", '');
																														}

																														if (!(CallPATCHapi_response.jobDisplayID === null || CallPATCHapi_response.jobDisplayID === undefined || CallPATCHapi_response.jobDisplayID === '')) {
																															ctxpatch.setVariable("jobDisplayID", CallPATCHapi_response.jobDisplayID);
																														} else {
																															ctxpatch.setVariable("jobDisplayID", '');
																														}

																														if (!(CallPATCHapi_response.externalCallCodeID === null || CallPATCHapi_response.externalCallCodeID === undefined || CallPATCHapi_response.externalCallCodeID === '')) {
																															ctxpatch.setVariable("externalCallCodeID", CallPATCHapi_response.externalCallCodeID);
																														} else {
																															ctxpatch.setVariable("externalCallCodeID", '');
																														}

																														if (!(CallPATCHapi_response.startedTime === null || CallPATCHapi_response.startedTime === undefined || CallPATCHapi_response.startedTime === '')) {
																															ctxpatch.setVariable("startedTime", CallPATCHapi_response.startedTime);
																														} else {
																															ctxpatch.setVariable("startedTime", '');
																														}

																														if (!(CallPATCHapi_response.notes === null || CallPATCHapi_response.notes === undefined || CallPATCHapi_response.notes === '')) {
																															ctxpatch.setVariable("notes", CallPATCHapi_response.notes);
																														} else {
																															ctxpatch.setVariable("notes", '');
																														}

																														if (!(CallPATCHapi_response.externalPremiseID === null || CallPATCHapi_response.externalPremiseID === undefined || CallPATCHapi_response.externalPremiseID === '')) {
																															ctxpatch.setVariable("externalPremiseID", CallPATCHapi_response.externalPremiseID);
																														} else {
																															ctxpatch.setVariable("externalPremiseID", '');
																														}

																														if (!(CallPATCHapi_response.customFieldValuesExt.Municipality === null || CallPATCHapi_response.customFieldValuesExt.Municipality === undefined || CallPATCHapi_response.customFieldValuesExt.Municipality === '')) {
																															ctxpatch.setVariable("customFieldValuesExtMunicipality", CallPATCHapi_response.customFieldValuesExt.Municipality);
																														} else {
																															ctxpatch.setVariable("customFieldValuesExtMunicipality", '');
																														}

																														if (!(CallPATCHapi_response.address === null || CallPATCHapi_response.address === undefined || CallPATCHapi_response.address === '')) {
																															ctxpatch.setVariable("address", CallPATCHapi_response.address);
																														} else {
																															ctxpatch.setVariable("address", '');
																														}
																														var newId = responseData.id;
																														var options = {
																															target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/' + newId,
																															method: "GET",
																															headers: {
																																"osiApiToken": apiToken
																															},
																															contentType: "application/json",
																															sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
																														};
																														urlopen.open(options, function(error, response) {
																															if (error) {
																																logger.error("urlopen connect error with get call api CHG" + JSON.stringify(error));
																																session.reject("urlopen connect error with get call api CHG" + JSON.stringify(error));
																															} else {
																																var responseStatusCode = response.statusCode;
																																if (responseStatusCode == 200) {
																																	response.readAsJSON(function(error, getCallResponseData) {
																																		if (error) {
																																			logger.error("urlopen connect error with get call api CHG" + JSON.stringify(error));
																																			session.reject("urlopen connect error with get call api CHG" + JSON.stringify(error));
																																		} else {
																																			var jobId2 = getCallResponseData.jobID;
																																			if (!(getCallResponseData.jobID === null || getCallResponseData.jobID === '' || getCallResponseData.jobID === undefined)) {
																																				ctxp.setVariable("displayIdqueryAPI_res_jobID", getCallResponseData.jobID);
																																			} else {
																																				ctxp.setVariable("displayIdqueryAPI_res_jobID", '');
																																			}

																																			if (!(getCallResponseData.jobDisplayID === null || getCallResponseData.jobDisplayID === undefined || getCallResponseData.jobDisplayID === '')) {
																																				ctxp.setVariable("jobDisplayID", getCallResponseData.jobDisplayID);
																																			} else {
																																				ctxp.setVariable("jobDisplayID", '');
																																			}
																																			if (!(getCallResponseData.externalCallCodeID === null || getCallResponseData.externalCallCodeID === undefined || getCallResponseData.externalCallCodeID === '')) {
																																				ctxp.setVariable("externalCallCodeID", getCallResponseData.externalCallCodeID);
																																			} else {
																																				ctxp.setVariable("externalCallCodeID", '');
																																			}
																																			if (!(getCallResponseData.startedTime === null || getCallResponseData.startedTime === undefined || getCallResponseData.startedTime === '')) {
																																				ctxp.setVariable("startedTime", getCallResponseData.startedTime);
																																			} else {
																																				ctxp.setVariable("startedTime", '');
																																			}
																																			if (!(getCallResponseData.notes === null || getCallResponseData.notes === undefined || getCallResponseData.notes === '')) {
																																				ctxp.setVariable("notes", getCallResponseData.notes);
																																			} else {
																																				ctxp.setVariable("notes", '');
																																			}

																																			if (!(getCallResponseData.externalPremiseID === null || getCallResponseData.externalPremiseID === undefined || getCallResponseData.externalPremiseID === '')) {
																																				ctxp.setVariable("externalPremiseID", getCallResponseData.externalPremiseID);
																																			} else {
																																				ctxp.setVariable("externalPremiseID", '');
																																			}

																																			if (!(getCallResponseData.customFieldValuesExt.Municipality === null || getCallResponseData.customFieldValuesExt.Municipality === undefined || getCallResponseData.customFieldValuesExt.Municipality === '')) {
																																				ctxp.setVariable("customFieldValuesExtMunicipality", getCallResponseData.customFieldValuesExt.Municipality);
																																			} else {
																																				ctxp.setVariable("customFieldValuesExtMunicipality", '');
																																			}

																																			if (!(getCallResponseData.address === null || getCallResponseData.address === undefined || getCallResponseData.address === '')) {
																																				ctxp.setVariable("address", getCallResponseData.address);
																																			} else {
																																				ctxp.setVariable("address", '');
																																			}
																																			if (getCallResponseData.jobID) {
																																				var jobIdLookup = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + getCallResponseData.jobID;
																																				var jobDetailsLookupAPI = {
																																					target: jobIdLookup,
																																					method: 'GET',
																																					contentType: 'application/json',
																																					headers: {
																																						"osiApiToken": apiToken
																																					},
																																					sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
																																				};
																																				urlopen.open(jobDetailsLookupAPI, function(error, response) {
																																					if (error) {
																																						logger.error("urlopen connect error with jobDetailsLookupAPI " + JSON.stringify(error));
																																						session.reject("urlopen connect error with jobDetailsLookupAPI " + JSON.stringify(error));
																																					} else {
																																						var responseStatusCode = response.statusCode;
																																						if (responseStatusCode == 200) {
																																							logger.info("jobDetailsLookupAPI response status code 200 djobID_ " + getCallResponseData.jobID);
																																							response.readAsBuffer(function(error, responseData) {
																																								if (error) {
																																									logger.error("Failure in reading message to jobDetailsLookupAPI Response for jobID_ " + JSON.stringify(error));
																																									session.reject("Failure in reading message to jobDetailsLookupAPI Response for jobID_ " + JSON.stringify(error));
																																								} else {
																																									var jobDetailslookupRes = JSON.parse(responseData);
																																									if (!(jobDetailslookupRes.jobTypeID === null || jobDetailslookupRes.jobTypeID === undefined || jobDetailslookupRes.jobTypeID === '')) {
																																										ctxp.setVariable("jobTypeID", jobDetailslookupRes.jobTypeID);
																																									} else {
																																										ctxp.setVariable("jobTypeID", '');
																																									}

																																									if (!(jobDetailslookupRes.status === null || jobDetailslookupRes.status === undefined || jobDetailslookupRes.status === '')) {
																																										ctxp.setVariable("status", jobDetailslookupRes.status);
																																									} else {
																																										ctxp.setVariable("status", '');
																																									}

																																									if (!(jobDetailslookupRes.customFieldValues.cause === null || jobDetailslookupRes.customFieldValues.cause === undefined || jobDetailslookupRes.customFieldValues.cause === '')) {
																																										ctxp.setVariable("customFieldValues", jobDetailslookupRes.customFieldValues.cause);
																																									} else {
																																										ctxp.setVariable("customFieldValues", '');
																																									}

																																									if (!(jobDetailslookupRes.nominalFeeder === undefined || jobDetailslookupRes.nominalFeeder === '' || jobDetailslookupRes.nominalFeeder === null)) {
																																										ctxp.setVariable("nominalFeeder", jobDetailslookupRes.nominalFeeder);
																																									} else {
																																										ctxp.setVariable("nominalFeeder", '');
																																									}

																																									if (jobDetailslookupRes.regionName === null || jobDetailslookupRes.regionName === '' || jobDetailslookupRes.regionName === undefined) {
																																										ctxp.setVariable("regionName", '');
																																									} else {
																																										ctxp.setVariable("regionName", jobDetailslookupRes.regionName);
																																									}

																																									if (!(jobDetailslookupRes.aorID === null || jobDetailslookupRes.aorID === undefined || jobDetailslookupRes.aorID === '')) {
																																										ctxp.setVariable("aorID", jobDetailslookupRes.aorID);
																																									} else {
																																										ctxp.setVariable("aorID", '');
																																									}

																																									if (!(jobDetailslookupRes.currentAffected === null || jobDetailslookupRes.currentAffected === '' || jobDetailslookupRes.currentAffected === undefined)) {
																																										ctxp.setVariable("currentAffected", jobDetailslookupRes.currentAffected);
																																									} else {
																																										ctxp.setVariable("currentAffected", '');
																																									}

																																									if (!(jobDetailslookupRes.totalAffected === null || jobDetailslookupRes.totalAffected === '' || jobDetailslookupRes.totalAffected === undefined)) {
																																										ctxp.setVariable("totalAffected", jobDetailslookupRes.totalAffected);
																																									} else {
																																										ctxp.setVariable("totalAffected", '');
																																									}

																																									if (!(jobDetailslookupRes.customFieldValues === null || jobDetailslookupRes.customFieldValues === '' || jobDetailslookupRes.customFieldValues === undefined)) {
																																										if (!(jobDetailslookupRes.customFieldValues.cause === null || jobDetailslookupRes.customFieldValues.cause === '' || jobDetailslookupRes.customFieldValues.cause === undefined)) {
																																											ctxp.setVariable("customFieldValuesCause", jobDetailslookupRes.customFieldValues.cause);
																																										} else {
																																											ctxp.setVariable("customFieldValuesCause", '');
																																										}
																																									}
																																									if (!(jobDetailslookupRes.customFieldValues.etr === null || jobDetailslookupRes.customFieldValues.etr === '' || jobDetailslookupRes.customFieldValues.etr === undefined)) {
																																										if (!(jobDetailslookupRes.etr.value === null || jobDetailslookupRes.etr.value === '' || jobDetailslookupRes.etr.value === undefined)) {
																																											ctxp.setVariable("etrvalue", jobDetailslookupRes.etr.value);
																																										} else {
																																											ctxp.setVariable("etrvalue", '');
																																										}
																																									}
																																									fs.readAsJSON("local:///trrpt_ReportTroubleOMS/gs/NoEstimateForListofTroubleCodes.json", function(error, TroubleCodeRes) {
																																										if (error) {
																																											logger.debug("error reading troublecodes file" + error)
																																										} else {
																																											logger.info("TroubleCode array is" + JSON.stringify(TroubleCodeRes));
																																											var isTroubleCodeIncludes = false;
																																											var TroubleCodes = [];
																																											TroubleCodes = TroubleCodeRes.TroubleCodes;
																																											var TroubleCodesLength = TroubleCodes.length;
																																											var TroubleCodeVal = getCallResponseData.externalCallCodeID;
																																											for (var h = 0; h < TroubleCodesLength; h++) {
																																												if (TroubleCodes[h] === TroubleCodeVal) {
																																													isTroubleCodeIncludes = true;
																																												}
																																											}
																																											logger.info("isTroubleCodeIncludes" + isTroubleCodeIncludes);
																																											if (isTroubleCodeIncludes) {
																																												ctxp.setVariable("BusinessException", "No Estimated restoration times are given for a trouble code of :" + getCallResponseData.externalCallCodeID);
																																											} else if (!(jobDetailslookupRes.etr === undefined || jobDetailslookupRes.etr === '' || jobDetailslookupRes.etr === null)) {
																																												var ETValue = jobDetailslookupRes.etr;
																																												if (ETValue.value === undefined || ETValue.value === '' || ETValue.value === null) {
																																													ctxp.setVariable("BusinessException", "No estimate is available");
																																												} else {
																																													var ETValue = jobDetailslookupRes.etr;
																																													var CurrentTime = new Date().toISOString();
																																													logger.info("current time is " + CurrentTime);
																																													logger.info("ETR value is " + ETValue.value);
																																													var etrValue = ETValue.value;
																																													if (CurrentTime > etrValue) {
																																														ctxp.setVariable("BusinessException", "Estimate is expired");
																																													}
																																												}
																																											}
																																											else {
																																												ctxp.setVariable("BusinessException", "No estimate is available");
																																											}
																																										}
																																									});
																																									if (!(jobDetailslookupRes.etr === 0 || jobDetailslookupRes.etr === null || jobDetailslookupRes.etr === undefined)) {
																																										var lookupMessage = {
																																											"lookupReq": {
																																												"type": [
																																													{
																																														"name": "jobTypes.workflows",
																																														"id": jobDetailslookupRes.jobTypeID,
																																														"status": jobDetailslookupRes.status
																																													},
																																													{
																																														"name": "aors",
																																														"id": jobDetailslookupRes.aorID,
																																														"status": "none"
																																													},
																																													{
																																														"name": "operationModes",
																																														"id": jobDetailslookupRes.createdOperationModeID,
																																														"status": "none"
																																													},
																																													{
																																														"name": "callCodesJobTypeID",
																																														"label": callType
																																													},
																																													{
																																														"name": "operationModes",
																																														"id": jobDetailslookupRes.etr.value,
																																														"status": "none"
																																													}
																																												]
																																											}
																																										}
																																									} else {
																																										var lookupMessage = {
																																											"lookupReq": {
																																												"type": [
																																													{
																																														"name": "jobTypes.workflows",
																																														"id": jobDetailslookupRes.jobTypeID,
																																														"status": jobDetailslookupRes.status
																																													},
																																													{
																																														"name": "aors",
																																														"id": jobDetailslookupRes.aorID,
																																														"status": "none"
																																													},
																																													{
																																														"name": "operationModes",
																																														"id": jobDetailslookupRes.createdOperationModeID,
																																														"status": "none"
																																													},
																																													{
																																														"name": "callCodesJobTypeID",
																																														"label": callType
																																													}
																																												]
																																											}
																																										}
																																									}
																																									logger.info("url look up request" + JSON.stringify(lookupMessage));
																																									var LookupServiceResponse = {
																																										target: session.parameters.lookupURL,
																																										method: 'POST',
																																										contentType: 'application/json',
																																										data: lookupMessage
																																									};
																																									urlopen.open(LookupServiceResponse, function(error, response) {
																																										if (error) {
																																											logger.debug("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
																																										} else {
																																											var responseStatusCode = response.statusCode;
																																											if (responseStatusCode == 200) {
																																												response.readAsJSON(function(error, responseData) {
																																													if (error) {
																																														// error while reading response or transferring data to Buffer
																																														logger.debug("failure in putting message to LookupServiceResponse" + JSON.stringify(error));
																																													} else {
																																														hm.response.statusCode = responseStatusCode;
																																														logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
																																														var LookupRespo = [];
																																														LookupRespo = responseData.lookupRep.type;
																																														for (var i = 0; i < LookupRespo.length; i++) {
																																															if (responseData.lookupRep.type[i].result == 0) {
																																																if (responseData.lookupRep.type[i].name == "jobTypes.workflows") {
																																																	ctx.setVariable("jobStatusLabel", responseData.lookupRep.type[i].label);
																																																}
																																																if (responseData.lookupRep.type[i].name == "operationModes") {
																																																	ctx.setVariable("stormMode", responseData.lookupRep.type[i].label);
																																																}
																																																if (responseData.lookupRep.type[i].name == "aors") {
																																																	ctx.setVariable("aorLabel", responseData.lookupRep.type[i].label);
																																																}
																																																if (responseData.lookupRep.type[i].name == "callCodesJobTypeID") {
																																																	var checkforOutage = {
																																																		"lookupReq": {
																																																			"type": [{
																																																				"name": "jobOutageTypes",
																																																				"id": responseData.lookupRep.type[i].id
																																																			}]
																																																		}

																																																	}
																																																	var OutageLookupResponse = {
																																																		target: session.parameters.lookupURL,
																																																		method: 'POST',
																																																		contentType: 'application/json',
																																																		data: checkforOutage
																																																	};
																																																	urlopen.open(OutageLookupResponse, function(error, response) {
																																																		if (error) {
																																																			logger.debug("urlopen connect error with OutageLookupResponse" + JSON.stringify(error));
																																																			//throw error;
																																																		} else {
																																																			// read response data
																																																			// get the response status code
																																																			var responseStatusCode = response.statusCode;
																																																			if (responseStatusCode == 200) {
																																																				response.readAsJSON(function(error, responseData) {
																																																					if (error) {
																																																						// error while reading response or transferring data to Buffer
																																																						logger.debug("failure in putting message to OutageLookupResponse " + JSON.stringify(error));
																																																					} else {
																																																						hm.response.statusCode = responseStatusCode;
																																																						logger.debug("response received from OutageLookupResponse " + JSON.stringify(responseData));
																																																						ctxp.setVariable("responseData", responseData);
																																																						if (responseData.lookupRep.type[0].result == 0) {
																																																							ctxp.setVariable("outage", responseData.lookupRep.type[0].label);

																																																						} //lookup end
																																																						else {
																																																							logger.debug("outageType " + outageType);
																																																							//session.reject('jobTypeID is Non Valid.');
																																																						}
																																																					}
																																																				});
																																																			} else {
																																																				logger.debug("Outagelookup response is not 200");
																																																				//session.reject("Outagelookup response is not 200");
																																																			}
																																																		}
																																																	});

																																																}
																																															} else {
																																																if (responseData.lookupRep.type[i].name == "jobTypes.workflows") {
																																																	ctxp.setVariable("jobStatus", '');
																																																}
																																																else if (responseData.lookupRep.type[i].name == "operationModes") {
																																																	ctxp.setVariable("stormMode", '');
																																																}
																																																else if (responseData.lookupRep.type[i].name == "aors") {
																																																	ctxp.setVariable("dispatchGroup ", '');
																																																} else if (responseData.lookupRep.type[i].name == "callCodesJobTypeID") {
																																																	ctxp.setVariable("callCodesJobTypeID", '');
																																																}
																																															}
																																														}

																																													}
																																												});
																																											}
																																										}
																																									});
																																								}
																																							});
																																						} else {
																																							logger.error("jobIdLookupAPI response status code is not 200 to fetch jobID_ " + jobID + " responseCode_" + responseStatusCode);
																																						}
																																					}
																																				});
																																			}
																																			if (jobId2 && jobID1) {
																																				if (jobID1 !== jobId2) {
																																					var patchPayload = {
																																						"outageSubtypeID": outageSubtypeID
																																					}
																																					var CallPATCHapi = {
																																						target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobId2,
																																						sslClientProfile: 'trrpt_ReportTroubleOMS_ClientProfile',
																																						method: 'PATCH',
																																						contentType: 'application/json',
																																						headers: {
																																							'osiApiToken': apiToken
																																						},
																																						data: patchPayload
																																					};
																																					urlopen.open(CallPATCHapi, function(error, response) {
																																						if (error) {
																																							logger.error("trrpt_ReportTroubleOMS_008 urlopen connect error with patch call api CHG" + JSON.stringify(error));
																																							session.reject("Error invoking patch call api CHG");
																																						} else {
																																							var responseStatusCode = response.statusCode;
																																							if (responseStatusCode == 200) {
																																								response.readAsBuffer(function(error, responseData) {
																																									if (error) {
																																										// error while reading response or transferring data to Buffer
																																										logger.error(" trrpt_ReportTroubleOMS_009 failure reading response from patch call api CHG" + JSON.stringify(error));
																																										session.reject("failure reading response from patch call api CHG");
																																									} else {
																																									}
																																								});
																																							}
																																							else {
																																								response.readAsBuffer(function(error, responseData) {
																																									if (error) {
																																										logger.error("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																																										session.reject("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																																									} else {
																																										logger.error("Error received in reading lookup response data " + responseStatusCode + responseData);
																																										session.reject("Error received in reading lookup response data " + responseStatusCode + responseData);

																																									}
																																								})
																																							}
																																						}
																																					});
																																				}
																																				else if (callInternalId !== newId) {
																																					var mqPayload = {
																																						"messageID": incomingdata.id,
																																						"callIdNew": newId,
																																						"outageSubtypeID": outageSubtypeID,
																																						"timestamp": new Date().toISOString()
																																					}
																																					var StandaloneMQurl = session.parameters.outageMQUrl;
																																					var pushingToQueue = {
																																						target: StandaloneMQurl,
																																						data: mqPayload
																																					};
																																					try {
																																						urlopen.open(pushingToQueue, function(error, response) {
																																							if (error) {
																																								var ctx = session.name("receivecall") || session.createContext("receivecall");
																																								var mqconnection = 'Forbidden';
																																								ctx.setVariable("mqconnection", mqconnection);
																																								logger.error("Error while keeping receivecall message to queue is " + error);
																																								session.reject("error while keeping receivecall message to queue is " + error);
																																							} else {
																																								var mqrc = response.statusCode;
																																								if (mqrc == 0) {
																																									var replyMQMD = response.get({
																																										type: 'mq'
																																									}, 'MQMD');
																																									var replyMQRFH2 = response.get({
																																										type: 'mq'
																																									}, 'MQRFH2');
																																									response.readAsBuffer(function(readError, responseData) {
																																										if (readError) {
																																											hm.response.statusCode = 500
																																											session.reject("error while keeping message receivecall to queue is " + error);
																																										} else {
																																											logger.debug("MQResponsecode " + mqrc + responseData);
																																										}
																																									});
																																								} else {
																																									var ctx = session.name("Trouble") || session.createContext("Trouble");
																																									var mqconnection = 'Forbidden';
																																									ctx.setVariable("mqconnection", mqconnection);
																																									logger.error(" response code receivecall urlopen.open error [MQRC=" + mqrc + "]");
																																									session.reject(" response code receivecall is urlopen.open error [MQRC=" + mqrc + "]");

																																								}
																																							}
																																						});
																																					}
																																					catch (error) {
																																						var ctx = session.name("receivecall") || session.createContext("receivecall");
																																						var mqconnection = 'Forbidden';
																																						ctx.setVariable("mqconnection", mqconnection);
																																						logger.error("Error while keeping receivecall message to queue is " + error);
																																						session.reject("error while keeping receivecall message to queue is " + error);
																																					}
																																				}
																																			}
																																			else if (callInternalId !== newId) {
																																				var mqPayload = {
																																					"messageID": incomingdata.id,
																																					"callIdNew": newId,
																																					"outageSubtypeID": outageSubtypeID,
																																					"timestamp": new Date().toISOString()
																																				}
																																				var StandaloneMQurl = session.parameters.outageMQUrl;
																																				var pushingToQueue = {
																																					target: StandaloneMQurl,
																																					data: mqPayload
																																				};
																																				try {
																																					urlopen.open(pushingToQueue, function(error, response) {
																																						if (error) {
																																							var ctx = session.name("receivecall") || session.createContext("receivecall");
																																							var mqconnection = 'Forbidden';
																																							ctx.setVariable("mqconnection", mqconnection);
																																							logger.error("Error while keeping receivecall message to queue is " + error);
																																							session.reject("error while keeping receivecall message to queue is " + error);
																																						} else {
																																							var mqrc = response.statusCode;
																																							if (mqrc == 0) {
																																								var replyMQMD = response.get({
																																									type: 'mq'
																																								}, 'MQMD');
																																								var replyMQRFH2 = response.get({
																																									type: 'mq'
																																								}, 'MQRFH2');
																																								response.readAsBuffer(function(readError, responseData) {
																																									if (readError) {
																																										hm.response.statusCode = 500
																																										session.reject("error while keeping message receivecall to queue is " + error);
																																									} else {
																																										logger.debug("MQResponsecode " + mqrc + responseData);
																																									}
																																								});
																																							} else {
																																								var ctx = session.name("Trouble") || session.createContext("Trouble");
																																								var mqconnection = 'Forbidden';
																																								ctx.setVariable("mqconnection", mqconnection);
																																								logger.error(" response code receivecall urlopen.open error [MQRC=" + mqrc + "]");
																																								session.reject(" response code receivecall is urlopen.open error [MQRC=" + mqrc + "]");

																																							}
																																						}
																																					});
																																				}
																																				catch (error) {
																																					var ctx = session.name("receivecall") || session.createContext("receivecall");
																																					var mqconnection = 'Forbidden';
																																					ctx.setVariable("mqconnection", mqconnection);
																																					logger.error("Error while keeping receivecall message to queue is " + error);
																																					session.reject("error while keeping receivecall message to queue is " + error);
																																				}
																																			}
																																			var CommentApiUri = omsExternalURL + '/api/ServiceType/Electric/Call/' + newId + '/Comment';
																																			var Comment = {
																																				"comment": 'Changed call code from ' + existingCallCode + ' to ' + troubleCode + ' due to customer reporting ' + troubleCode + " Customer Remarks: " + remarks + " Premise No : " + premiseId
																																			}
																																			var options = {
																																				target: CommentApiUri,
																																				method: "post",
																																				headers: {
																																					"osiApiToken": apiToken
																																				},
																																				contentType: "application/json",
																																				sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile",
																																				data: Comment
																																			};
																																			urlopen.open(options, function(error, response) {
																																				if (error) {
																																					logger.error("urlopen error at CommentApiUri : " + JSON.stringify(error));
																																					session.reject("urlopen error at CommentApiUri : " + JSON.stringify(error));
																																					//hm.current.statusCode = '500';
																																				} else {
																																					var responseStatusCode = response.statusCode;
																																					var responsePhrase = response.reasonPhrase;
																																					if (responseStatusCode == 200 || responseStatusCode == 400) {
																																						response.readAsJSON(function(error, responseData) {
																																							if (error) {
																																								logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																																								session.reject("failure reading response from CommentApi api");
																																							}
																																							else {
																																								var payload = {
																																									"startedAt": new Date().toISOString()
																																								}
																																								var CallPATCHapi = {
																																									target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + newId,
																																									sslClientProfile: 'trrpt_ReportTroubleOMS_ClientProfile',
																																									method: 'PATCH',
																																									contentType: 'application/json',
																																									headers: {
																																										'osiApiToken': apiToken
																																									},
																																									data: payload
																																								};
																																								urlopen.open(CallPATCHapi, function(error, response) {
																																									if (error) {
																																										logger.error("trrpt_ReportTroubleOMS_008 urlopen connect error with patch call api CHG" + JSON.stringify(error));
																																										session.reject("Error invoking patch call api CHG");
																																									} else {
																																										var responseStatusCode = response.statusCode;
																																										if (responseStatusCode == 200 || responseStatusCode == 400) {
																																											response.readAsBuffer(function(error, responseData) {
																																												if (error) {
																																													// error while reading response or transferring data to Buffer
																																													logger.error(" trrpt_ReportTroubleOMS_009 failure reading response from patch call api CHG" + JSON.stringify(error));
																																													session.reject("failure reading response from patch call api CHG");
																																												} else {
																																													if (attachments) {
																																														var atPatchUrl = session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + newId;
																																														var payload = {
																																															"customFieldValues": {
																																																"Attachment_Available_Flag": true
																																															}
																																														}
																																														callURL(atPatchUrl, payload);
																																													}
																																												}
																																											});
																																										}
																																										else {
																																											response.readAsBuffer(function(error, responseData) {
																																												if (error) {
																																													logger.error("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																																													session.reject("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																																												} else {
																																													logger.error("Error received in reading lookup response data " + responseStatusCode + responseData);
																																													session.reject("Error received in reading lookup response data " + responseStatusCode + responseData);

																																												}
																																											})
																																										}
																																									}
																																								});

																																							}
																																						});
																																					} else {
																																						response.readAsBuffer(function(error, ErrorresponseData) {
																																							if (error) {
																																								// error while reading response or transferring data to Buffer
																																								logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																																								session.output.write("failure reading response from CommentApi api");
																																							} else {
																																								hm.response.statusCode = response.statusCode;
																																								logger.error("  Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																																								session.reject("Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																																							}
																																						});

																																					}
																																				}
																																			});
																																		}
																																	})
																																} else {
																																	response.readAsBuffer(function(error, ErrorresponseData) {
																																		if (error) {
																																			// error while reading response or transferring data to Buffer
																																			logger.error("failure reading response from get call api" + JSON.stringify(error));
																																			session.reject("failure reading response from get call api" + JSON.stringify(error));
																																		} else {
																																			hm.response.statusCode = response.statusCode;
																																			logger.error("error response from get call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																																			session.reject("error response from patch call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																																		}
																																	});
																																}
																															}
																														});
																													}
																												});
																											}
																										}
																									});
																								}
																								else {
																									logger.error("Lookup response is not success" + JSON.stringify(responseData))
																									session.reject("Lookup response is not success" + JSON.stringify(responseData));
																								}
																							}
																						});
																					}
																					else {
																						response.readAsBuffer(function(error, responseData) {
																							if (error) {
																								logger.error("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																								session.reject("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																							} else {
																								logger.error("Error received in reading lookup response data " + responseStatusCode + responseData);
																								session.reject("Error received in reading lookup response data " + responseStatusCode + responseData);

																							}
																						})
																					}
																				}
																			});
																		}
																	});
																} else {
																	response.readAsBuffer(function(error, ErrorresponseData) {
																		if (error) {
																			// error while reading response or transferring data to Buffer
																			logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																			session.output.write("failure reading response from CommentApi api");
																		} else {
																			hm.response.statusCode = response.statusCode;
																			logger.error("  Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																			session.reject("Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																		}
																	});

																}
															}
														});
													}
												});
											}
											else {
												response.readAsBuffer(function(error, ErrorresponseData) {
													if (error) {
														// error while reading response or transferring data to Buffer
														logger.error("failure reading response from get call api" + JSON.stringify(error));
														session.reject("failure reading response from get call api" + JSON.stringify(error));
													} else {
														hm.response.statusCode = response.statusCode;
														logger.error("error response from get call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
														session.reject("error response from patch call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
													}
												});
											}
										}
									});
								}
							});
						}
						else {
							response.readAsBuffer(function(error, ErrorresponseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									logger.error("failure reading response from get call api" + JSON.stringify(error));
									session.reject("failure reading response from get call api" + JSON.stringify(error));
								} else {
									hm.response.statusCode = response.statusCode;
									logger.error("error response from get call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
									session.reject("error response from patch call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								}
							});
						}
					}
				});
			}
			else {
				var optionsCall = {
					target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/' + callInternalId,
					method: "GET",
					headers: {
						"osiApiToken": apiToken
					},
					contentType: "application/json",
					sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
				};
				urlopen.open(optionsCall, function(error, response) {
					if (error) {
						logger.error("urlopen connect error with get call api CHG" + JSON.stringify(error));
						session.reject("urlopen connect error with get call api CHG" + JSON.stringify(error));
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, response) {
								if (error) {
									// error while reading response or transferring data to Buffer
									logger.error("failure reading response from get call api CHG" + JSON.stringify(error));
									session.reject("failure reading response from get call api CHG" + JSON.stringify(error));
								} else {
									hm.response.statusCode = '200 OK';
									var responseData = JSON.parse(response);
									var jobDisplayID = responseData.jobDisplayID;
									var jobID1 = responseData.jobID;
									ctx.setVar("getCallResponse", responseData);
									var optionsJob = {
										target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Job/' + jobID1 + '?includeFields=outageSubtypeID',
										method: "GET",
										headers: {
											"osiApiToken": apiToken
										},
										contentType: "application/json",
										sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
									};
									urlopen.open(optionsJob, function(error, response) {
										if (error) {
											logger.error("urlopen connect error with get call api CHG" + JSON.stringify(error));
											session.reject("urlopen connect error with get call api CHG" + JSON.stringify(error));
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseOutage) {
													if (error) {
														// error while reading response or transferring data to Buffer
														logger.error("failure reading response from get call api CHG" + JSON.stringify(error));
														session.reject("failure reading response from get call api CHG" + JSON.stringify(error));
													} else {
														hm.response.statusCode = '200 OK';
														var responseData = JSON.parse(responseOutage);
														var outageSubtypeID = responseData.outageSubtypeID;
														ctx.setVar("getCallResponse", responseData);
														var CommentApiUri = omsExternalURL + '/api/ServiceType/Electric/Job/' + jobID1 + '/Comment';
														var Comment = {
															"comment": 'Changed call code from ' + existingCallCode + ' to ' + troubleCode + ' due to customer reporting ' + troubleCode + " Customer Remarks: " + remarks + " Premise No : " + premiseId
														}
														var options = {
															target: CommentApiUri,
															method: "post",
															headers: {
																"osiApiToken": apiToken
															},
															contentType: "application/json",
															sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile",
															data: Comment
														};
														urlopen.open(options, function(error, response) {
															if (error) {
																logger.error("urlopen error at CommentApiUri : " + JSON.stringify(error));
																session.reject("urlopen error at CommentApiUri : " + JSON.stringify(error));
																//hm.current.statusCode = '500';
															} else {
																var responseStatusCode = response.statusCode;
																var responsePhrase = response.reasonPhrase;
																if (responseStatusCode == 200 || responseStatusCode == 400) {
																	response.readAsJSON(function(error, responseData) {
																		if (error) {
																			logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																			session.reject("failure reading response from CommentApi api");
																		}
																		else {
																			logger.debug(responseData);
																			var lookupcallType = incomingdata.callType;
																			var lookupMessage = {
																				"lookupReq": {
																					"type": [{
																						"name": "callCodes",
																						"label": lookupcallType
																					}]
																				}
																			}
																			var crewsTypelookupResponse = {
																				target: lookupURL,
																				method: 'POST',
																				contentType: 'application/json',
																				data: lookupMessage
																			};
																			urlopen.open(crewsTypelookupResponse, function(error, response) {
																				if (error) {
																					logger.error("urlopen connect error from crewsTypelookupResponse" + JSON.stringify(error));
																					session.reject(errorinfo);
																				}
																				else {
																					var responseStatusCode = response.statusCode;
																					if (responseStatusCode == 200) {
																						response.readAsJSON(function(error, responseData) {
																							if (error) {
																								logger.error("Failure in reading the message for crewsTypelookupResponse" + JSON.stringify(error));
																								session.reject(errorinfo);
																							}
																							else {
																								hm.response.statusCode = responseStatusCode;
																								ctx.setVariable("res", responseData);
																								if (responseData.lookupRep.type[0].result == 0) {
																									var id = responseData.lookupRep.type[0].id;
																									var callCodeIDdata = {
																										"callCodeID": id
																									}
																									var CallPATCHapi = {
																										target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + callInternalId,
																										sslClientProfile: 'trrpt_ReportTroubleOMS_ClientProfile',
																										method: 'PATCH',
																										contentType: 'application/json',
																										headers: {
																											'osiApiToken': apiToken
																										},
																										data: callCodeIDdata
																									};
																									urlopen.open(CallPATCHapi, function(error, response) {
																										if (error) {
																											logger.error("trrpt_ReportTroubleOMS_008 urlopen connect error with patch call api CHG" + id + JSON.stringify(error));
																											session.reject("Error invoking patch call api CHG");
																										} else {
																											var responseStatusCode = response.statusCode;
																											if (responseStatusCode == 200 || responseStatusCode == 400) {
																												response.readAsBuffer(function(error, patchCallresponse) {
																													if (error) {
																														// error while reading response or transferring data to Buffer
																														logger.error(" trrpt_ReportTroubleOMS_009 failure reading response from patch call api CHG" + id + JSON.stringify(error));
																														session.reject("failure reading response from patch call api CHG");
																													} else {
																														if (patchCallresponse.includes("No updates")) {
																														}
																														else {
																															var responseData = JSON.parse(patchCallresponse);
																															var CallPATCHapi_response = JSON.parse(patchCallresponse);
																															if (!(CallPATCHapi_response.displayID === null || CallPATCHapi_response.displayID === undefined || CallPATCHapi_response.displayID === '')) {
																																displayID = CallPATCHapi_response.displayID;
																																ctxpatch.setVariable("CallPATCHapi_res_displayID", displayID);
																															} else {
																																displayID = '';
																																ctxpatch.setVariable("CallPATCHapi_res_displayID", '');
																															}
																															if (!(CallPATCHapi_response.jobID === null || CallPATCHapi_response.jobID === undefined || CallPATCHapi_response.jobID === '')) {
																																ctxpatch.setVariable("CallPATCHapi_res_jobID", CallPATCHapi_response.jobID);
																															} else {
																																ctxpatch.setVariable("CallPATCHapi_res_jobID", '');
																															}

																															if (!(CallPATCHapi_response.jobDisplayID === null || CallPATCHapi_response.jobDisplayID === undefined || CallPATCHapi_response.jobDisplayID === '')) {
																																ctxpatch.setVariable("jobDisplayID", CallPATCHapi_response.jobDisplayID);
																															} else {
																																ctxpatch.setVariable("jobDisplayID", '');
																															}

																															if (!(CallPATCHapi_response.externalCallCodeID === null || CallPATCHapi_response.externalCallCodeID === undefined || CallPATCHapi_response.externalCallCodeID === '')) {
																																ctxpatch.setVariable("externalCallCodeID", CallPATCHapi_response.externalCallCodeID);
																															} else {
																																ctxpatch.setVariable("externalCallCodeID", '');
																															}

																															if (!(CallPATCHapi_response.startedTime === null || CallPATCHapi_response.startedTime === undefined || CallPATCHapi_response.startedTime === '')) {
																																ctxpatch.setVariable("startedTime", CallPATCHapi_response.startedTime);
																															} else {
																																ctxpatch.setVariable("startedTime", '');
																															}

																															if (!(CallPATCHapi_response.notes === null || CallPATCHapi_response.notes === undefined || CallPATCHapi_response.notes === '')) {
																																ctxpatch.setVariable("notes", CallPATCHapi_response.notes);
																															} else {
																																ctxpatch.setVariable("notes", '');
																															}

																															if (!(CallPATCHapi_response.externalPremiseID === null || CallPATCHapi_response.externalPremiseID === undefined || CallPATCHapi_response.externalPremiseID === '')) {
																																ctxpatch.setVariable("externalPremiseID", CallPATCHapi_response.externalPremiseID);
																															} else {
																																ctxpatch.setVariable("externalPremiseID", '');
																															}

																															if (!(CallPATCHapi_response.customFieldValuesExt.Municipality === null || CallPATCHapi_response.customFieldValuesExt.Municipality === undefined || CallPATCHapi_response.customFieldValuesExt.Municipality === '')) {
																																ctxpatch.setVariable("customFieldValuesExtMunicipality", CallPATCHapi_response.customFieldValuesExt.Municipality);
																															} else {
																																ctxpatch.setVariable("customFieldValuesExtMunicipality", '');
																															}

																															if (!(CallPATCHapi_response.address === null || CallPATCHapi_response.address === undefined || CallPATCHapi_response.address === '')) {
																																ctxpatch.setVariable("address", CallPATCHapi_response.address);
																															} else {
																																ctxpatch.setVariable("address", '');
																															}
																															var newId = responseData.id;
																															var options = {
																																target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/' + newId,
																																method: "GET",
																																headers: {
																																	"osiApiToken": apiToken
																																},
																																contentType: "application/json",
																																sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
																															};
																															urlopen.open(options, function(error, response) {
																																if (error) {
																																	logger.error("urlopen connect error with get call api CHG" + JSON.stringify(error));
																																	session.reject("urlopen connect error with get call api CHG" + JSON.stringify(error));
																																} else {
																																	var responseStatusCode = response.statusCode;
																																	if (responseStatusCode == 200) {
																																		response.readAsJSON(function(error, getCallResponseData) {
																																			if (error) {
																																				logger.error("urlopen connect error with get call api CHG" + JSON.stringify(error));
																																				session.reject("urlopen connect error with get call api CHG" + JSON.stringify(error));
																																			} else {
																																				var jobId2 = getCallResponseData.jobID;
																																				if (!(getCallResponseData.jobID === null || getCallResponseData.jobID === '' || getCallResponseData.jobID === undefined)) {
																																					ctxp.setVariable("displayIdqueryAPI_res_jobID", getCallResponseData.jobID);
																																				} else {
																																					ctxp.setVariable("displayIdqueryAPI_res_jobID", '');
																																				}

																																				if (!(getCallResponseData.jobDisplayID === null || getCallResponseData.jobDisplayID === undefined || getCallResponseData.jobDisplayID === '')) {
																																					ctxp.setVariable("jobDisplayID", getCallResponseData.jobDisplayID);
																																				} else {
																																					ctxp.setVariable("jobDisplayID", '');
																																				}
																																				if (!(getCallResponseData.externalCallCodeID === null || getCallResponseData.externalCallCodeID === undefined || getCallResponseData.externalCallCodeID === '')) {
																																					ctxp.setVariable("externalCallCodeID", getCallResponseData.externalCallCodeID);
																																				} else {
																																					ctxp.setVariable("externalCallCodeID", '');
																																				}
																																				if (!(getCallResponseData.startedTime === null || getCallResponseData.startedTime === undefined || getCallResponseData.startedTime === '')) {
																																					ctxp.setVariable("startedTime", getCallResponseData.startedTime);
																																				} else {
																																					ctxp.setVariable("startedTime", '');
																																				}
																																				if (!(getCallResponseData.notes === null || getCallResponseData.notes === undefined || getCallResponseData.notes === '')) {
																																					ctxp.setVariable("notes", getCallResponseData.notes);
																																				} else {
																																					ctxp.setVariable("notes", '');
																																				}

																																				if (!(getCallResponseData.externalPremiseID === null || getCallResponseData.externalPremiseID === undefined || getCallResponseData.externalPremiseID === '')) {
																																					ctxp.setVariable("externalPremiseID", getCallResponseData.externalPremiseID);
																																				} else {
																																					ctxp.setVariable("externalPremiseID", '');
																																				}

																																				if (!(getCallResponseData.customFieldValuesExt.Municipality === null || getCallResponseData.customFieldValuesExt.Municipality === undefined || getCallResponseData.customFieldValuesExt.Municipality === '')) {
																																					ctxp.setVariable("customFieldValuesExtMunicipality", getCallResponseData.customFieldValuesExt.Municipality);
																																				} else {
																																					ctxp.setVariable("customFieldValuesExtMunicipality", '');
																																				}

																																				if (!(getCallResponseData.address === null || getCallResponseData.address === undefined || getCallResponseData.address === '')) {
																																					ctxp.setVariable("address", getCallResponseData.address);
																																				} else {
																																					ctxp.setVariable("address", '');
																																				}
																																				if (getCallResponseData.jobID) {
																																					var jobIdLookup = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + getCallResponseData.jobID;
																																					var jobDetailsLookupAPI = {
																																						target: jobIdLookup,
																																						method: 'GET',
																																						contentType: 'application/json',
																																						headers: {
																																							"osiApiToken": apiToken
																																						},
																																						sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
																																					};
																																					urlopen.open(jobDetailsLookupAPI, function(error, response) {
																																						if (error) {
																																							logger.error("urlopen connect error with jobDetailsLookupAPI " + JSON.stringify(error));
																																							session.reject("urlopen connect error with jobDetailsLookupAPI " + JSON.stringify(error));
																																						} else {
																																							var responseStatusCode = response.statusCode;
																																							if (responseStatusCode == 200) {
																																								response.readAsBuffer(function(error, responseData) {
																																									if (error) {
																																										logger.error("Failure in reading message to jobDetailsLookupAPI Response for jobID_ " + JSON.stringify(error));
																																										session.reject("Failure in reading message to jobDetailsLookupAPI Response for jobID_ " + JSON.stringify(error));
																																									} else {
																																										var jobDetailslookupRes = JSON.parse(responseData);

																																										if (!(jobDetailslookupRes.jobTypeID === null || jobDetailslookupRes.jobTypeID === undefined || jobDetailslookupRes.jobTypeID === '')) {
																																											ctxp.setVariable("jobTypeID", jobDetailslookupRes.jobTypeID);
																																										} else {
																																											ctxp.setVariable("jobTypeID", '');
																																										}

																																										if (!(jobDetailslookupRes.status === null || jobDetailslookupRes.status === undefined || jobDetailslookupRes.status === '')) {
																																											ctxp.setVariable("status", jobDetailslookupRes.status);
																																										} else {
																																											ctxp.setVariable("status", '');
																																										}

																																										if (!(jobDetailslookupRes.customFieldValues.cause === null || jobDetailslookupRes.customFieldValues.cause === undefined || jobDetailslookupRes.customFieldValues.cause === '')) {
																																											ctxp.setVariable("customFieldValues", jobDetailslookupRes.customFieldValues.cause);
																																										} else {
																																											ctxp.setVariable("customFieldValues", '');
																																										}

																																										if (!(jobDetailslookupRes.nominalFeeder === undefined || jobDetailslookupRes.nominalFeeder === '' || jobDetailslookupRes.nominalFeeder === null)) {
																																											ctxp.setVariable("nominalFeeder", jobDetailslookupRes.nominalFeeder);
																																										} else {
																																											ctxp.setVariable("nominalFeeder", '');
																																										}

																																										if (jobDetailslookupRes.regionName === null || jobDetailslookupRes.regionName === '' || jobDetailslookupRes.regionName === undefined) {
																																											ctxp.setVariable("regionName", '');
																																										} else {
																																											ctxp.setVariable("regionName", jobDetailslookupRes.regionName);
																																										}

																																										if (!(jobDetailslookupRes.aorID === null || jobDetailslookupRes.aorID === undefined || jobDetailslookupRes.aorID === '')) {
																																											ctxp.setVariable("aorID", jobDetailslookupRes.aorID);
																																										} else {
																																											ctxp.setVariable("aorID", '');
																																										}

																																										if (!(jobDetailslookupRes.currentAffected === null || jobDetailslookupRes.currentAffected === '' || jobDetailslookupRes.currentAffected === undefined)) {
																																											ctxp.setVariable("currentAffected", jobDetailslookupRes.currentAffected);
																																										} else {
																																											ctxp.setVariable("currentAffected", '');
																																										}

																																										if (!(jobDetailslookupRes.totalAffected === null || jobDetailslookupRes.totalAffected === '' || jobDetailslookupRes.totalAffected === undefined)) {
																																											ctxp.setVariable("totalAffected", jobDetailslookupRes.totalAffected);
																																										} else {
																																											ctxp.setVariable("totalAffected", '');
																																										}

																																										if (!(jobDetailslookupRes.customFieldValues === null || jobDetailslookupRes.customFieldValues === '' || jobDetailslookupRes.customFieldValues === undefined)) {
																																											if (!(jobDetailslookupRes.customFieldValues.cause === null || jobDetailslookupRes.customFieldValues.cause === '' || jobDetailslookupRes.customFieldValues.cause === undefined)) {
																																												ctxp.setVariable("customFieldValuesCause", jobDetailslookupRes.customFieldValues.cause);
																																											} else {
																																												ctxp.setVariable("customFieldValuesCause", '');
																																											}
																																										}
																																										if (!(jobDetailslookupRes.customFieldValues.etr === null || jobDetailslookupRes.customFieldValues.etr === '' || jobDetailslookupRes.customFieldValues.etr === undefined)) {
																																											if (!(jobDetailslookupRes.etr.value === null || jobDetailslookupRes.etr.value === '' || jobDetailslookupRes.etr.value === undefined)) {
																																												ctxp.setVariable("etrvalue", jobDetailslookupRes.etr.value);
																																											} else {
																																												ctxp.setVariable("etrvalue", '');
																																											}
																																										}
																																										fs.readAsJSON("local:///trrpt_ReportTroubleOMS/gs/NoEstimateForListofTroubleCodes.json", function(error, TroubleCodeRes) {
																																											if (error) {
																																												logger.debug("error reading troublecodes file" + error)
																																											} else {
																																												logger.info("TroubleCode array is" + JSON.stringify(TroubleCodeRes));
																																												var isTroubleCodeIncludes = false;
																																												var TroubleCodes = [];
																																												TroubleCodes = TroubleCodeRes.TroubleCodes;
																																												var TroubleCodesLength = TroubleCodes.length;
																																												var TroubleCodeVal = getCallResponseData.externalCallCodeID;
																																												for (var h = 0; h < TroubleCodesLength; h++) {
																																													if (TroubleCodes[h] === TroubleCodeVal) {
																																														isTroubleCodeIncludes = true;
																																													}
																																												}
																																												logger.info("isTroubleCodeIncludes" + isTroubleCodeIncludes);
																																												if (isTroubleCodeIncludes) {
																																													ctxp.setVariable("BusinessException", "No Estimated restoration times are given for a trouble code of :" + getCallResponseData.externalCallCodeID);
																																												} else if (!(jobDetailslookupRes.etr === undefined || jobDetailslookupRes.etr === '' || jobDetailslookupRes.etr === null)) {
																																													var ETValue = jobDetailslookupRes.etr;
																																													if (ETValue.value === undefined || ETValue.value === '' || ETValue.value === null) {
																																														ctxp.setVariable("BusinessException", "No estimate is available");
																																													} else {
																																														var ETValue = jobDetailslookupRes.etr;
																																														var CurrentTime = new Date().toISOString();
																																														logger.info("current time is " + CurrentTime);
																																														logger.info("ETR value is " + ETValue.value);
																																														var etrValue = ETValue.value;
																																														if (CurrentTime > etrValue) {
																																															ctxp.setVariable("BusinessException", "Estimate is expired");
																																														}
																																													}
																																												}
																																												else {
																																													ctxp.setVariable("BusinessException", "No estimate is available");
																																												}
																																											}
																																										});
																																										if (!(jobDetailslookupRes.etr === 0 || jobDetailslookupRes.etr === null || jobDetailslookupRes.etr === undefined)) {
																																											var lookupMessage = {
																																												"lookupReq": {
																																													"type": [
																																														{
																																															"name": "jobTypes.workflows",
																																															"id": jobDetailslookupRes.jobTypeID,
																																															"status": jobDetailslookupRes.status
																																														},
																																														{
																																															"name": "aors",
																																															"id": jobDetailslookupRes.aorID,
																																															"status": "none"
																																														},
																																														{
																																															"name": "operationModes",
																																															"id": jobDetailslookupRes.createdOperationModeID,
																																															"status": "none"
																																														},
																																														{
																																															"name": "callCodesJobTypeID",
																																															"label": callType
																																														},
																																														{
																																															"name": "operationModes",
																																															"id": jobDetailslookupRes.etr.value,
																																															"status": "none"
																																														}
																																													]
																																												}
																																											}
																																										} else {
																																											var lookupMessage = {
																																												"lookupReq": {
																																													"type": [
																																														{
																																															"name": "jobTypes.workflows",
																																															"id": jobDetailslookupRes.jobTypeID,
																																															"status": jobDetailslookupRes.status
																																														},
																																														{
																																															"name": "aors",
																																															"id": jobDetailslookupRes.aorID,
																																															"status": "none"
																																														},
																																														{
																																															"name": "operationModes",
																																															"id": jobDetailslookupRes.createdOperationModeID,
																																															"status": "none"
																																														},
																																														{
																																															"name": "callCodesJobTypeID",
																																															"label": callType
																																														}
																																													]
																																												}
																																											}
																																										}
																																										logger.info("url look up request" + JSON.stringify(lookupMessage));
																																										var LookupServiceResponse = {
																																											target: session.parameters.lookupURL,
																																											method: 'POST',
																																											contentType: 'application/json',
																																											data: lookupMessage
																																										};
																																										urlopen.open(LookupServiceResponse, function(error, response) {
																																											if (error) {
																																												logger.debug("urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
																																											} else {
																																												var responseStatusCode = response.statusCode;
																																												if (responseStatusCode == 200) {
																																													response.readAsJSON(function(error, responseData) {
																																														if (error) {
																																															// error while reading response or transferring data to Buffer
																																															logger.debug("failure in putting message to LookupServiceResponse" + JSON.stringify(error));
																																														} else {
																																															hm.response.statusCode = responseStatusCode;
																																															logger.debug("response received from LookupServiceResponse " + JSON.stringify(responseData));
																																															var LookupRespo = [];
																																															LookupRespo = responseData.lookupRep.type;
																																															var lookupRespLength = LookupRespo.length;
																																															logger.debug("response length received is " + LookupRespo.length);
																																															for (var i = 0; i < LookupRespo.length; i++) {
																																																if (responseData.lookupRep.type[i].result == 0) {
																																																	if (responseData.lookupRep.type[i].name == "jobTypes.workflows") {
																																																		ctxp.setVariable("jobStatusLabel", responseData.lookupRep.type[i].label);
																																																	}
																																																	if (responseData.lookupRep.type[i].name == "operationModes") {
																																																		ctxp.setVariable("stormMode", responseData.lookupRep.type[i].label);
																																																	}
																																																	if (responseData.lookupRep.type[i].name == "aors") {
																																																		ctxp.setVariable("aorLabel", responseData.lookupRep.type[i].label);
																																																	}
																																																	if (responseData.lookupRep.type[i].name == "callCodesJobTypeID") {
																																																		var checkforOutage = {
																																																			"lookupReq": {
																																																				"type": [{
																																																					"name": "jobOutageTypes",
																																																					"id": responseData.lookupRep.type[i].id
																																																				}]
																																																			}

																																																		}
																																																		var OutageLookupResponse = {
																																																			target: session.parameters.lookupURL,
																																																			method: 'POST',
																																																			contentType: 'application/json',
																																																			data: checkforOutage
																																																		};
																																																		urlopen.open(OutageLookupResponse, function(error, response) {
																																																			if (error) {
																																																				logger.debug("urlopen connect error with OutageLookupResponse" + JSON.stringify(error));
																																																				//throw error;
																																																			} else {
																																																				// read response data
																																																				// get the response status code
																																																				var responseStatusCode = response.statusCode;
																																																				if (responseStatusCode == 200) {
																																																					response.readAsJSON(function(error, responseData) {
																																																						if (error) {
																																																							// error while reading response or transferring data to Buffer
																																																							logger.debug("failure in putting message to OutageLookupResponse " + JSON.stringify(error));
																																																						} else {
																																																							hm.response.statusCode = responseStatusCode;
																																																							logger.debug("response received from OutageLookupResponse " + JSON.stringify(responseData));
																																																							ctxp.setVariable("responseData", responseData);
																																																							if (responseData.lookupRep.type[0].result == 0) {
																																																								ctxp.setVariable("outage", responseData.lookupRep.type[0].label);

																																																							} //lookup end
																																																							else {
																																																								logger.debug("outageType " + outageType);
																																																								//session.reject('jobTypeID is Non Valid.');
																																																							}
																																																						}
																																																					});
																																																				} else {
																																																					logger.debug("Outagelookup response is not 200");
																																																					//session.reject("Outagelookup response is not 200");
																																																				}
																																																			}
																																																		});

																																																	}
																																																} else {
																																																	if (responseData.lookupRep.type[i].name == "jobTypes.workflows") {
																																																		ctxp.setVariable("jobStatus", '');
																																																	}
																																																	else if (responseData.lookupRep.type[i].name == "operationModes") {
																																																		ctxp.setVariable("stormMode", '');
																																																	}
																																																	else if (responseData.lookupRep.type[i].name == "aors") {
																																																		ctxp.setVariable("dispatchGroup ", '');
																																																	} else if (responseData.lookupRep.type[i].name == "callCodesJobTypeID") {
																																																		ctxp.setVariable("callCodesJobTypeID", '');
																																																	}
																																																}
																																															}

																																														}
																																													});
																																												}
																																											}
																																										});
																																									}
																																								});
																																							} else {
																																								logger.error("jobIdLookupAPI response status code is not 200 to fetch jobID_ " + jobID + " responseCode_" + responseStatusCode);
																																							}
																																						}
																																					});
																																				}
																																				if (jobId2 && jobID1) {
																																					if (jobID1 !== jobId2) {
																																						var patchPayload = {
																																							"outageSubtypeID": outageSubtypeID
																																						}
																																						var CallPATCHapi = {
																																							target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobId2,
																																							sslClientProfile: 'trrpt_ReportTroubleOMS_ClientProfile',
																																							method: 'PATCH',
																																							contentType: 'application/json',
																																							headers: {
																																								'osiApiToken': apiToken
																																							},
																																							data: patchPayload
																																						};
																																						urlopen.open(CallPATCHapi, function(error, response) {
																																							if (error) {
																																								logger.error("trrpt_ReportTroubleOMS_008 urlopen connect error with patch call api CHG" + id + JSON.stringify(error));
																																								session.reject("Error invoking patch call api CHG");
																																							} else {
																																								var responseStatusCode = response.statusCode;
																																								if (responseStatusCode == 200 || responseStatusCode == 400) {
																																									response.readAsBuffer(function(error, responseData) {
																																										if (error) {
																																											// error while reading response or transferring data to Buffer
																																											logger.error(" trrpt_ReportTroubleOMS_009 failure reading response from patch call api CHG" + id + JSON.stringify(error));
																																											session.reject("failure reading response from patch call api CHG");
																																										} else {
																																										}
																																									});
																																								}
																																								else {
																																									response.readAsBuffer(function(error, responseData) {
																																										if (error) {
																																											logger.error("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																																											session.reject("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																																										} else {
																																											logger.error("Error received in reading lookup response data " + responseStatusCode + responseData);
																																											session.reject("Error received in reading lookup response data " + responseStatusCode + responseData);

																																										}
																																									})
																																								}
																																							}
																																						});
																																					}
																																					else if (callInternalId !== newId) {
																																						var mqPayload = {
																																							"messageID": incomingdata.id,
																																							"callIdNew": newId,
																																							"outageSubtypeID": outageSubtypeID,
																																							"timestamp": new Date().toISOString()
																																						}
																																						var StandaloneMQurl = session.parameters.outageMQUrl;
																																						var pushingToQueue = {
																																							target: StandaloneMQurl,
																																							data: mqPayload
																																						};
																																						try {
																																							urlopen.open(pushingToQueue, function(error, response) {
																																								if (error) {
																																									var ctx = session.name("receivecall") || session.createContext("receivecall");
																																									var mqconnection = 'Forbidden';
																																									ctx.setVariable("mqconnection", mqconnection);
																																									logger.error("Error while keeping receivecall message to queue is " + error);
																																									session.reject("error while keeping receivecall message to queue is " + error);
																																								} else {
																																									var mqrc = response.statusCode;
																																									if (mqrc == 0) {
																																										var replyMQMD = response.get({
																																											type: 'mq'
																																										}, 'MQMD');
																																										var replyMQRFH2 = response.get({
																																											type: 'mq'
																																										}, 'MQRFH2');
																																										response.readAsBuffer(function(readError, responseData) {
																																											if (readError) {
																																												hm.response.statusCode = 500
																																												session.reject("error while keeping message receivecall to queue is " + error);
																																											} else {
																																												logger.debug("MQResponsecode " + mqrc + responseData);
																																											}
																																										});
																																									} else {
																																										var ctx = session.name("Trouble") || session.createContext("Trouble");
																																										var mqconnection = 'Forbidden';
																																										ctx.setVariable("mqconnection", mqconnection);
																																										logger.error(" response code receivecall urlopen.open error [MQRC=" + mqrc + "]");
																																										session.reject(" response code receivecall is urlopen.open error [MQRC=" + mqrc + "]");

																																									}
																																								}
																																							});
																																						}
																																						catch (error) {
																																							var ctx = session.name("receivecall") || session.createContext("receivecall");
																																							var mqconnection = 'Forbidden';
																																							ctx.setVariable("mqconnection", mqconnection);
																																							logger.error("Error while keeping receivecall message to queue is " + error);
																																							session.reject("error while keeping receivecall message to queue is " + error);
																																						}
																																					}
																																				}
																																				else if (callInternalId !== newId) {
																																					var mqPayload = {
																																						"messageID": incomingdata.id,
																																						"callIdNew": newId,
																																						"outageSubtypeID": outageSubtypeID,
																																						"timestamp": new Date().toISOString()
																																					}
																																					var StandaloneMQurl = session.parameters.outageMQUrl;
																																					var pushingToQueue = {
																																						target: StandaloneMQurl,
																																						data: mqPayload
																																					};
																																					try {
																																						urlopen.open(pushingToQueue, function(error, response) {
																																							if (error) {
																																								var ctx = session.name("receivecall") || session.createContext("receivecall");
																																								var mqconnection = 'Forbidden';
																																								ctx.setVariable("mqconnection", mqconnection);
																																								logger.error("Error while keeping receivecall message to queue is " + error);
																																								session.reject("error while keeping receivecall message to queue is " + error);
																																							} else {
																																								var mqrc = response.statusCode;
																																								if (mqrc == 0) {
																																									var replyMQMD = response.get({
																																										type: 'mq'
																																									}, 'MQMD');
																																									var replyMQRFH2 = response.get({
																																										type: 'mq'
																																									}, 'MQRFH2');
																																									response.readAsBuffer(function(readError, responseData) {
																																										if (readError) {
																																											hm.response.statusCode = 500
																																											session.reject("error while keeping message receivecall to queue is " + error);
																																										} else {
																																											logger.debug("MQResponsecode " + mqrc + responseData);
																																										}
																																									});
																																								} else {
																																									var ctx = session.name("Trouble") || session.createContext("Trouble");
																																									var mqconnection = 'Forbidden';
																																									ctx.setVariable("mqconnection", mqconnection);
																																									logger.error(" response code receivecall urlopen.open error [MQRC=" + mqrc + "]");
																																									session.reject(" response code receivecall is urlopen.open error [MQRC=" + mqrc + "]");

																																								}
																																							}
																																						});
																																					}
																																					catch (error) {
																																						var ctx = session.name("receivecall") || session.createContext("receivecall");
																																						var mqconnection = 'Forbidden';
																																						ctx.setVariable("mqconnection", mqconnection);
																																						logger.error("Error while keeping receivecall message to queue is " + error);
																																						session.reject("error while keeping receivecall message to queue is " + error);
																																					}
																																				}
																																				var CommentApiUri = omsExternalURL + '/api/ServiceType/Electric/Call/' + newId + '/Comment';
																																				var Comment = {
																																					"comment": 'Changed call code from ' + existingCallCode + ' to ' + troubleCode + ' due to customer reporting ' + troubleCode + " Customer Remarks: " + remarks + " Premise No : " + premiseId
																																				}
																																				var options = {
																																					target: CommentApiUri,
																																					method: "post",
																																					headers: {
																																						"osiApiToken": apiToken
																																					},
																																					contentType: "application/json",
																																					sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile",
																																					data: Comment
																																				};
																																				urlopen.open(options, function(error, response) {
																																					if (error) {
																																						logger.error("urlopen error at CommentApiUri : " + JSON.stringify(error));
																																						session.reject("urlopen error at CommentApiUri : " + JSON.stringify(error));
																																						//hm.current.statusCode = '500';
																																					} else {
																																						var responseStatusCode = response.statusCode;
																																						var responsePhrase = response.reasonPhrase;
																																						if (responseStatusCode == 200 || responseStatusCode == 400) {
																																							response.readAsJSON(function(error, responseData) {
																																								if (error) {
																																									logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																																									session.reject("failure reading response from CommentApi api");
																																								}
																																								else {
																																									var payload = {
																																										"startedAt": new Date().toISOString()
																																									}
																																									logger.error("payload", payload);
																																									var CallPATCHapi = {
																																										target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + newId,
																																										sslClientProfile: 'trrpt_ReportTroubleOMS_ClientProfile',
																																										method: 'PATCH',
																																										contentType: 'application/json',
																																										headers: {
																																											'osiApiToken': apiToken
																																										},
																																										data: payload
																																									};
																																									urlopen.open(CallPATCHapi, function(error, response) {
																																										if (error) {
																																											logger.error("urlopen connect error with patch call api CHG" + JSON.stringify(error));
																																											session.reject("Error invoking patch call api CHG");
																																										} else {
																																											var responseStatusCode = response.statusCode;
																																											if (responseStatusCode == 200 || responseStatusCode == 400) {
																																												response.readAsBuffer(function(error, responseData) {
																																													if (error) {
																																														// error while reading response or transferring data to Buffer
																																														logger.error("failure reading response from patch call api CHG" + JSON.stringify(error));
																																														session.reject("failure reading response from patch call api CHG");
																																													} else {
																																														if (attachments) {
																																															var atPatchUrl = session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Call/' + newId;
																																															var payload = {
																																																"customFieldValues": {
																																																	"Attachment_Available_Flag": true
																																																}
																																															}
																																															callURL(atPatchUrl, payload);
																																														}
																																														if (contactPhone) {
																																															if (contactPhone !== undefined || contactPhone !== '' || contactPhone !== null) {
																																																var phnNumPayload = {
																																																	"phoneNumber": contactPhone
																																																};
																																															}
																																														}
																																														patchPayloadCHG = {
																																															...patchPayloadCHG,
																																															...phnNumPayload
																																														}
																																														ctxi.setVar("patchPayloadCHGPN", patchPayloadCHG);
																																														if (callIDTBTFlag) {
																																															if (callIDTBTFlag !== undefined || callIDTBTFlag !== '' || callIDTBTFlag !== null) {
																																																if (callIDTBT) {
																																																	if (callIDTBT !== undefined || callIDTBT !== '' || callIDTBT !== null) {
																																																		var callIDTBT_FlagPayload = {
																																																			"customFieldValues": {
																																																				"TBTOriginalCallNumber": callIDTBT,
																																																				"TBT": callIDTBTFlag
																																																			}
																																																		};
																																																		patchPayloadCHG = {
																																																			...patchPayloadCHG,
																																																			...callIDTBT_FlagPayload
																																																		}
																																																	}
																																																}
																																																else {
																																																	var callIDTBT_FlagPayload = {
																																																		"customFieldValues": {
																																																			"TBT": callIDTBTFlag
																																																		}

																																																	};
																																																	patchPayloadCHG = {
																																																		...patchPayloadCHG,
																																																		...callIDTBT_FlagPayload
																																																	}
																																																}

																																															}

																																														}
																																														else if (callIDTBT) {
																																															if (callIDTBT !== undefined || callIDTBT !== '' || callIDTBT !== null) {
																																																var callIDTBT_FlagPayload = {
																																																	"customFieldValues": {
																																																		"TBTOriginalCallNumber": callIDTBT
																																																	}

																																																};
																																																patchPayloadCHG = {
																																																	...patchPayloadCHG,
																																																	...callIDTBT_FlagPayload
																																																}
																																															}
																																														}
																																														ctxi.setVar("patchPayloadCHGCallIDTBTFlag", patchPayloadCHG);
																																														var patchUrlCHG = session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/' + newId;
																																														if (patchPayloadCHG) {
																																															if (patchPayloadCHG !== null || patchPayloadCHG !== undefined || patchPayloadCHG !== '') {
																																																patchURLResponse(patchUrlCHG, "patchCallCHG", patchPayloadCHG);
																																															}
																																														}
																																													}
																																												});
																																											}
																																											else {
																																												response.readAsBuffer(function(error, responseData) {
																																													if (error) {
																																														logger.error("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																																														session.reject("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																																													} else {
																																														logger.error("Error received in reading lookup response data " + responseStatusCode + responseData);
																																														session.reject("Error received in reading lookup response data " + responseStatusCode + responseData);

																																													}
																																												})
																																											}
																																										}
																																									});

																																								}
																																							});
																																						} else {
																																							response.readAsBuffer(function(error, ErrorresponseData) {
																																								if (error) {
																																									// error while reading response or transferring data to Buffer
																																									logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																																									session.output.write("failure reading response from CommentApi api");
																																								} else {
																																									hm.response.statusCode = response.statusCode;
																																									logger.error("  Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																																									session.reject("Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																																								}
																																							});

																																						}
																																					}
																																				});
																																			}
																																		})
																																	} else {
																																		response.readAsBuffer(function(error, ErrorresponseData) {
																																			if (error) {
																																				// error while reading response or transferring data to Buffer
																																				logger.error("failure reading response from get call api" + JSON.stringify(error));
																																				session.reject("failure reading response from get call api" + JSON.stringify(error));
																																			} else {
																																				hm.response.statusCode = response.statusCode;
																																				logger.error("error response from get call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																																				session.reject("error response from patch call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																																			}
																																		});
																																	}
																																}
																															});
																														}

																													}
																												});
																											}
																											else {
																												response.readAsBuffer(function(error, responseData) {
																													if (error) {
																														logger.error("Failure in reading the message" + JSON.stringify(error));
																														session.reject("Failure in reading the message" + JSON.stringify(error));
																													} else {
																														logger.error("Error received in reading response data " + responseStatusCode + responseData);
																														session.reject("Error received in reading response data " + responseStatusCode + responseData);

																													}
																												})
																											}
																										}
																									});
																								}
																								else {
																									logger.error("Lookup response is not success" + JSON.stringify(responseData))
																									session.reject("Lookup response is not success" + JSON.stringify(responseData));
																								}
																							}
																						});
																					}
																					else {
																						response.readAsBuffer(function(error, responseData) {
																							if (error) {
																								logger.error("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																								session.reject("Failure in reading the message for crewstatuslookupResponse" + JSON.stringify(error));
																							} else {
																								logger.error("Error received in reading lookup response data " + responseStatusCode + responseData);
																								session.reject("Error received in reading lookup response data " + responseStatusCode + responseData);
																							}
																						})
																					}
																				}
																			});
																		}
																	});
																} else {
																	response.readAsBuffer(function(error, ErrorresponseData) {
																		if (error) {
																			// error while reading response or transferring data to Buffer
																			logger.error("failure reading response from CommentApi api" + JSON.stringify(error));
																			session.output.write("failure reading response from CommentApi api");
																		} else {
																			hm.response.statusCode = response.statusCode;
																			logger.error("  Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																			session.reject("Error response code from CommentApi " + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
																		}
																	});

																}
															}
														});
													}
												});
											}
											else {
												response.readAsBuffer(function(error, ErrorresponseData) {
													if (error) {
														// error while reading response or transferring data to Buffer
														logger.error("failure reading response from get call api" + JSON.stringify(error));
														session.reject("failure reading response from get call api" + JSON.stringify(error));
													} else {
														hm.response.statusCode = response.statusCode;
														logger.error("error response from get call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
														session.reject("error response from patch call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
													}
												});
											}
										}
									});
								}
							});
						}
						else {
							response.readAsBuffer(function(error, ErrorresponseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									logger.error("failure reading response from get call api" + JSON.stringify(error));
									session.reject("failure reading response from get call api" + JSON.stringify(error));
								} else {
									hm.response.statusCode = response.statusCode;
									logger.error("error response from get call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
									session.reject("error response from patch call api CHG" + "Response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								}
							});
						}
					}
				});
			}
		}
	} else {
		logger.error("okToProceed is not true in call check response");
		session.reject("okToProceed is not true in call check response");
	}
} else {
	//flow proceeds further
}


function callURL(url, payload) {
	var options = {
		target: url,
		method: "PATCH",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile",
		data: payload
	};
	var patchInfo = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(options.data) + ". ";
	urlopen.open(options, function(error, response) {
		if (error) {
			// an error occurred during reading the file
			var errorinfo = "urlopen connect error with omsAPI  , details are : " + patchInfo + "; error info :" + error;
			ctx.setVariable("exitDescription", errorinfo);
			ctx.setVariable("exitStatus", '500');
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						// error while reading response or transferring data to Buffer
						logger.error("Error in reading the response data " + JSON.stringify(error));
						var errorinfo = "Error in reading the response data , details are : " + patchInfo + "; error info :" + error;
						ctx.setVariable("exitDescription", errorinfo);
						ctx.setVariable("exitStatus", '500');
						session.reject(errorinfo);
					} else {
						logger.info("success url response received");

					}
				});
			} else if (responseStatusCode == 400) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "failure in getting message, details are : " + patchInfo + "; error info :" + JSON.stringify(error)
						ctx.setVariable('exitStatus', responseStatusCode);
						ctx.setVariable('exitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {

					}
				});

			} else if (responseStatusCode == 401) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "failure in getting message, details are : " + patchInfo + "; error info :" + JSON.stringify(error)
						ctx.setVariable('exitStatus', responseStatusCode);
						ctx.setVariable('exitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "response code from patch Call : " + patchInfo + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable('exitStatus', responseStatusCode);
						ctx.setVariable('exitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});

			}
			else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "failure in getting message, details are : " + patchInfo + "; error info :" + JSON.stringify(error)
						ctx.setVariable('exitStatus', responseStatusCode);
						ctx.setVariable('exitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "response code from patch Call : " + patchInfo + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						ctx.setVariable('exitStatus', responseStatusCode);
						ctx.setVariable('exitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			}
		}
	});

}
