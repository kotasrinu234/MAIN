//This Gateway script is a common for all the api calls
var ctx = session.name("Trouble") || session.createContext("Trouble");
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var ctx1 = session.name("current") || session.createContext("current");
var currentUser = ctx1.getVar("user");
var incomingUser = currentUser;
var apiToken;
var incomingUrl = sm.getVar('var://service/routing-url');
if (incomingUser === 'dcas-wismo-esb-dev' || incomingUser === 'dcas-wismo-esb-test' || incomingUser === 'dcas-wismo-esb-prod') {
	apiToken = session.parameters.ppsToken;
} else if (incomingUser === 'dcas-crb-esb-oms-dev' || incomingUser === 'dcas-crb-esb-oms-tst' || incomingUser === 'dcas-crb-esb-oms-prd' || incomingUser === 'tlab-esb-oms-dev' || incomingUser === 'tlab-esb-oms-test') {
/*else if (incomingUser === 'dcas-crb-esb-oms-dev' || incomingUser === 'dcas-crb-esb-oms-tst' || incomingUser === 'dcas-crb-esb-oms-prd') {*/
	apiToken = session.parameters.apiToken;
}
else if (incomingUser === 'atlas-esb-dev' || incomingUser === 'atlas-esb-test') {
	apiToken = session.parameters.atlasToken;
}
else if (incomingUser === 'dcas-oms-esb-ami-dev' || incomingUser === 'dcas-oms-esb-ami-tst' || incomingUser === 'dcas-oms-esb-ami-prd') {
	apiToken = session.parameters.compassToken;
}
else if(incomingUrl.includes('4671')){
	apiToken = session.parameters.FSEToken;
}
if ((apiToken === null || apiToken === undefined || apiToken === '')) { }
else {
	ctx.setVar("apiToken", apiToken);
}
var logger = console.options({
	'category': 'all'
});
function patchURLResponse(url, myctx, omsrequest) {
	var CallPATCHapi = {
		target: url,
		method: "PATCH",
		headers: {
			"osiApiToken": apiToken
		},
		contentType: "application/json",
		sslClientProfile: "trrpt_CheckTroubleOMS_ssl_client_profile",
		data: omsrequest

	};
	urlopen.open(CallPATCHapi, function(error, response) {
		if (error) {
			logger.error("trrpt_ReportTroubleOMS_008 urlopen connect error with patch call api" + JSON.stringify(error));
			session.reject("Error invoking patch call api CHG");
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200 || responseStatusCode == 400) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						// error while reading response or transferring data to Buffer
						logger.error(" trrpt_ReportTroubleOMS_009 failure reading response from patch call api" + JSON.stringify(error));
						session.reject("failure reading response from patch call api");
					} else {
						ctx.setVar(myctx+"response", responseData);
					}
				});
			}
			else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						logger.error("Failure in reading the message" + JSON.stringify(error));
						session.reject("Failure in reading the message" + JSON.stringify(error));
					} else {
						logger.error("Error received in reading response data " + responseStatusCode + responseData);
						session.reject("Error received in reading response data " + responseStatusCode + responseData);

					}
				})
			}
		}
	});
}

module.exports = patchURLResponse;
