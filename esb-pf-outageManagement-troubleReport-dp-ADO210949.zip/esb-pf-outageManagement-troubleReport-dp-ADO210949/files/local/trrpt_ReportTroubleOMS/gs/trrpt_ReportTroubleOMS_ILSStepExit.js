var callCheckctx = session.name('callCheckResponse') || session.createContext("callCheckResponse");
var crossStreetctx = session.name('CrossStreetLookup') || session.createContext("CrossStreetLookup");
var callCheckPayload = callCheckctx.getVar("Response");
var corssStreetPayload = crossStreetctx.getVar("CrossStreetLookupResponse");
if(callCheckPayload){
	session.output.write(callCheckPayload);
}
else if(corssStreetPayload){
	session.output.write(corssStreetPayload);
}
