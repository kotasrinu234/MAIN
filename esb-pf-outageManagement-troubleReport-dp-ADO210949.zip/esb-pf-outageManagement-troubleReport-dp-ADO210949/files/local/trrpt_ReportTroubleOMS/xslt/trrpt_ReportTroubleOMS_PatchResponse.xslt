<xsl:stylesheet
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:dp="http://www.datapower.com/extensions"
xmlns:date="http://exslt.org/dates-and-times"
xmlns:dyn="http://exslt.org/dynamic"
xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
xmlns:dpconfig="http://www.datapower.com/param/config"
extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
<xsl:template match="/">

<xsl:variable name="callQueryResponseData">
<xsl:value-of select="dp:variable('var://context/respdata/callQueryResponseData')"/>
</xsl:variable>
<xsl:variable name="">
<xsl:value-of select="dp:variable('var://context/respdata/')"/>
</xsl:variable>
<xsl:variable name="id">
<xsl:value-of select="dp:variable('var://context/respdata/callQueryResponseData/id')"/>
</xsl:variable>

</xsl:template>
</xsl:stylesheet>

