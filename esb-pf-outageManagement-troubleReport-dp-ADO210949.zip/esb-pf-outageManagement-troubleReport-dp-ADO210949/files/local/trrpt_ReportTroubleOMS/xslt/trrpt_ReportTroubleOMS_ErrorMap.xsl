<xsl:stylesheet version="1.0"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	extension-element-prefixes="dp"
	exclude-result-prefixes="dp soapenv date"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:v11="http://esm.dteco.com/common/v1"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ns3="http://outagemanagement.esm.dteco.com/trouble/v1">
	<xsl:output method="xml" />
	<xsl:template match="/">
		<!--This xslt is used to handle errors -->
		<xsl:if
			test="dp:variable('var://context/ReporteTroubleOMS/omsstatuscode') != ' '">
			<dp:set-variable
				name="'var://service/error-protocol-response'"
				value="dp:variable('var://context/ReporteTroubleOMS/omsstatuscode')" />
			<dp:set-variable
				name="'var://service/error-protocol-reason-phrase'"
				value="dp:variable('var://context/ReporteTroubleOMS/omsresponse')" />
		</xsl:if>
		<xsl:variable name="ReplyCode">
			<xsl:choose>
				<xsl:when
					test="dp:variable('var://context/ReporteTroubleOMS/omsstatuscode') != ''">
					<xsl:value-of
						select="dp:variable('var://context/ReporteTroubleOMS/omsstatuscode')" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="'500'" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="Header">
			<xsl:copy-of
				select="dp:variable('var://context/Input/TroubleRequest')" />
		</xsl:variable>
		<xsl:variable name="error_response">
			<xsl:choose>
				<xsl:when
					test="dp:variable('var://context/ReporteTroubleOMS/omsresponse') != ''">
					<xsl:value-of
						select="dp:variable('var://context/ReporteTroubleOMS/omsresponse')" />
				</xsl:when>
				<!--<xsl:when
					test="dp:variable('var://context/error/customErrorMessage') != ''">
					<xsl:copy-of
						select="dp:variable('var://context/error/customErrorMessage')" />
				</xsl:when>-->
				<xsl:when
					test="dp:variable('var://context/error/error-message') != ''">
					<xsl:copy-of
						select="dp:variable('var://context/error/error-message')" />
				</xsl:when>
				<xsl:when
					test="dp:variable('var://context/error/errorURLMessage') != ''">
					<xsl:copy-of
						select="dp:variable('var://context/error/errorURLMessage')" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of
						select="dp:variable('var://service/error-message')" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<dp:set-variable
			name="'var://context/error/errorResponse'" value="$error_response" />
		<soapenv:Envelope>
			<soapenv:Header />
			<soapenv:Body>
				<ns3:RestorationStatus>
					<v11:Header>
						<v11:Verb>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='Verb']" />
						</v11:Verb>
						<v11:Noun>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='Noun']" />
						</v11:Noun>
						<v11:Revision>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='Revision']" />
						</v11:Revision>
						<v11:Context>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='Context']" />
						</v11:Context>
						<v11:Timestamp>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='Timestamp']" />
						</v11:Timestamp>
						<v11:Source>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='Source']" />
						</v11:Source>
						<v11:AsyncReplyFlag>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='AsyncReplyFlag']" />
						</v11:AsyncReplyFlag>
						<v11:ReplyAddress>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='ReplyAddress']" />
						</v11:ReplyAddress>
						<v11:AckRequired>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='AckRequired']" />
						</v11:AckRequired>
						<v11:User>
							<v11:UserID>
								<xsl:value-of
									select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='UserID']" />
							</v11:UserID>
							<v11:Organization>
								<xsl:value-of
									select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='Organization']" />
							</v11:Organization>
						</v11:User>
						<v11:MessageID>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='MessageID']" />
						</v11:MessageID>
						<v11:CorrelationID>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='CorrelationID']" />
						</v11:CorrelationID>
						<v11:Comment>
							<xsl:value-of
								select="$Header/*[local-name()='Header']/*[local-name()='Comment']" />
						</v11:Comment>
						<v11:Property>
							<v11:Name>
								<xsl:value-of
									select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Name']" />
							</v11:Name>
							<v11:Value>
								<xsl:value-of
									select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Value']" />
							</v11:Value>
						</v11:Property>
					</v11:Header>
					<v11:Reply>
						<v11:ReplyCode>
							<xsl:value-of select="'FAIL'" />
						</v11:ReplyCode>
						<v11:Error>
							<v11:level>FATAL</v11:level>
							<v11:code>
								<xsl:value-of select="$ReplyCode" />
							</v11:code>
							<v11:details>
								<xsl:value-of select="$error_response" />
							</v11:details>
							<v11:context>ERROR</v11:context>
						</v11:Error>
						<v11:ID>
							<xsl:value-of select="$ReplyCode" />
						</v11:ID>
					</v11:Reply>
				</ns3:RestorationStatus>
			</soapenv:Body>
		</soapenv:Envelope>
	</xsl:template>
</xsl:stylesheet>
