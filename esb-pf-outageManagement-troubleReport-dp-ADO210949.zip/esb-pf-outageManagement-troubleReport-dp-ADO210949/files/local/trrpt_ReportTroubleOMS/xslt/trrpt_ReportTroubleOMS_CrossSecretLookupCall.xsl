<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	extension-element-prefixes="dp"
	exclude-result-prefixes="dp da com max sr soapenv">
	<xsl:output method="xml" />
	<!--This xslt is used to make CrossStreetLookup call when PremiseID is not 
		present in incoming data -->
	<xsl:param name="dpconfig:CrossStreetLookupURL" />
	<xsl:template match="/">
		<xsl:variable name="input">
			<xsl:copy-of select="." />
		</xsl:variable>
		<xsl:variable name="troubleCode">
			<xsl:value-of
				select="$input//*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode']" />
		</xsl:variable>
		<xsl:variable name="premiseId">
			<xsl:value-of
				select="$input//*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='premiseId']" />
		</xsl:variable>
		<xsl:variable name="remarks">
			<xsl:value-of
				select="$input//*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='remarks']" />
		</xsl:variable>
		<xsl:variable name="municipality">
			<xsl:value-of
				select="$input//*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='municipality']" />
		</xsl:variable>
		<dp:set-variable
			name="'var://context/Trouble/troubleCode'"
			value="string($troubleCode)" />
		<dp:set-variable
			name="'var://context/Trouble/premiseId'" value="string($premiseId)" />
		<dp:set-variable
			name="'var://context/Trouble/remarks'" value="string($remarks)" />
		<dp:set-variable
			name="'var://context/Trouble/municipality'"
			value="string($municipality)" />
		<xsl:if
			test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']">
			<dp:set-variable
				name="'var://context/input/descriptionVal'" value="'Y'" />
			<xsl:variable name="appId"
				select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']" />
			<xsl:message>
				coming from input---
				<xsl:value-of select="$appId" />
			</xsl:message>
			<xsl:variable name="applicationId"
				select="document('local:///trrpt_ReportTroubleOMS/xml/trrpt_ReportTroubleOMS_applicationId.xml')" />
			<xsl:for-each
				select="$applicationId/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']">
				<xsl:variable name="name"
					select="./*[local-name()='name']" />
				<xsl:message>
					coming from input---
					<xsl:value-of select="./*[local-name()='description']" />
				</xsl:message>
				<xsl:message>
					coming from input---
					<xsl:value-of select="$name" />
				</xsl:message>
				<xsl:message>
					<xsl:value-of select="string($appId)" />
				</xsl:message>
				<xsl:if test="$name = string($appId)">
					<dp:set-variable
						name="'var://context/input/description'"
						value="string(./*[local-name()='description'])" />
					<xsl:message>
						from config file---
						<xsl:value-of select="$description" />
					</xsl:message>
					<dp:set-variable
						name="'var://context/input/Trouble'" value="'ValueIsSet'" />
				</xsl:if>
			</xsl:for-each>
		</xsl:if>
		<xsl:if
			test="not(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId'])">
			<dp:set-variable
				name="'var://context/input/descriptionVal'" value="'N'" />
		</xsl:if>
		<dp:set-variable
			name="'var://context/Input/TroubleRequest'"
			value="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Header']" />
		<xsl:variable name="CrossStreet1">
			<xsl:value-of
				select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet1']" />
		</xsl:variable>
		<xsl:variable name="CrossStreet2">
			<xsl:value-of
				select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet2']" />
		</xsl:variable>
		<xsl:variable name="CrossStreet1Field">
			<xsl:call-template name="tokenize">
				<xsl:with-param name="names" select="$CrossStreet1" />
			</xsl:call-template>
		</xsl:variable>
		<xsl:variable name="CrossStreet2Field">
			<xsl:call-template name="tokenize">
				<xsl:with-param name="names" select="$CrossStreet2" />
			</xsl:call-template>
		</xsl:variable>
		<xsl:variable name="municipalityField">
			<xsl:call-template name="tokenize">
				<xsl:with-param name="names" select="$municipality" />
			</xsl:call-template>
		</xsl:variable>
		<xsl:variable name="CrossStreet">
			<xsl:value-of
				select="concat($CrossStreet1Field, '%20', 'and', '%20', $CrossStreet2Field)" />
		</xsl:variable>
		<xsl:variable name="CrossStreetLookupURL">
			<xsl:value-of
				select="concat($dpconfig:CrossStreetLookupURL,'/findAddressCandidates?f=pjson&amp;outFields=Addr_type&amp;forStorage=false&amp;Address=', $CrossStreet, '&amp;city=', $municipalityField, '&amp;Region=MI', '&amp;sourceCOUNTRY=US&amp;countrycode=US')" />
		</xsl:variable>
		<xsl:variable name="longitude" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']/*[local-name()='longitude']" />
		<xsl:variable name="latitude" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']/*[local-name()='latitude']" />
			<xsl:variable name="premiseId"
				select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='premiseId']" />
			<dp:set-variable
				name="'var://context/Trouble/CrossStreetLookupURL'"
				value="string($CrossStreetLookupURL)" />
			<dp:set-variable
				name="'var://context/Trouble/CrossStreet1'"
				value="string($CrossStreet1)" />
			<dp:set-variable
				name="'var://context/Trouble/CrossStreet2'"
				value="string($CrossStreet2)" />
			<xsl:choose>
				<xsl:when test="(not(string-length($premiseId) &gt; 0)) and not($longitude != '' and $latitude != '')">
					<!--<xsl:if test="not(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet1']) 
						and not(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet2'])"> 
						<xsl:message dp:type="all" dp:priority="error"> <xsl:value-of select="'Any 
						of required fields CrossStreet1 or CrossStreet2 should be there in absence 
						of premiseId'"/> </xsl:message> <dp:set-variable name="'var://context/error/customErrorMessage'" 
						value="'Any of required fields CrossStreet1 or CrossStreet2 should be there 
						in absence of premiseId'"/> <dp:reject/> </xsl:if> -->
					<xsl:choose>
						<xsl:when
							test="($CrossStreet1 !='' and $CrossStreet2 !='')">
							<xsl:choose>
								<xsl:when
									test="(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet1']) and (/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet2'])">
									<dp:set-variable
										name="'var://context/trrpt_ReporteTroubleOMS/flag'" value="1" />
									<xsl:variable name="CrossStreetLookupResponse">
										<dp:url-open target="{$CrossStreetLookupURL}"
											ssl-proxy="client:geocode_ClientProfile"
											response="responsecode-binary" http-method="get" />
									</xsl:variable>
									<xsl:choose>
										<xsl:when
											test="$CrossStreetLookupResponse/result/responsecode = '200'">
											<xsl:variable name="output">
												<xsl:value-of
													select="normalize-space(dp:decode(dp:binary-encode($CrossStreetLookupResponse/result/binary/node()),'base-64'))"
													disable-output-escaping="yes" />
											</xsl:variable>
											<dp:set-variable name="'var://context/CrossStreetLookup/CrossStreetLookupResponse'" value="$output"/>
											<xsl:copy-of select="$output" />
										</xsl:when>
										<xsl:otherwise>
											<xsl:message dp:type="all" dp:priority="error"
												terminate="yes">
												trrpt_ReportTroubleOMS_001:
												<xsl:value-of
													select="$CrossStreetLookupResponse" />
												Error invoking Geo Location
											</xsl:message>
											<!-- <xsl:message dp:type="all" dp:priority="error"> Error invoking 
												Geo Loaction <xsl:copy-of select="$CrossStreetLookupResponse/result/errorstring/text()"/> 
												</xsl:message> -->
											<xsl:variable name="error"
												select="$CrossStreetLookupResponse/result/errorstring/text()" />
											<dp:set-variable
												name="'var://context/error/customErrorMessage'"
												value="$CrossStreetLookupResponse/result/errorstring/text()" />
											<dp:set-variable
												name="'var://service/error-message'"
												value="$CrossStreetLookupResponse/result/errorstring/text()" />
											<dp:reject>
												<xsl:value-of select="$error" />
											</dp:reject>
										</xsl:otherwise>
									</xsl:choose>
								</xsl:when>
							</xsl:choose>
						</xsl:when>
						<xsl:otherwise>
							<xsl:message dp:type="all" dp:priority="error">
								+
							</xsl:message>
							<xsl:copy-of select="'{}'" />
						</xsl:otherwise>
					</xsl:choose>
				</xsl:when>
				<xsl:otherwise>
					<xsl:variable name="bracket">
						<text>"</text>
					</xsl:variable>
					<xsl:variable name="startflower">
						<text>{</text>
					</xsl:variable>
					<xsl:variable name="endflower">
						<text>}</text>
					</xsl:variable>
					<xsl:value-of
						select="concat($startflower,$bracket,'default',$bracket,':',$bracket,'12',$bracket,$endflower)" />
				</xsl:otherwise>
			</xsl:choose>
	</xsl:template>
	<xsl:template name="tokenize">
		<xsl:param name="names" />
		<xsl:choose>
			<xsl:when test="contains($names, ' ')">
				<xsl:value-of select="substring-before($names, ' ')" />
				<xsl:text>%20</xsl:text>
				<!-- recursive call -->
				<xsl:call-template name="tokenize">
					<xsl:with-param name="names"
						select="substring-after($names, ' ')" />
				</xsl:call-template>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$names" />
			</xsl:otherwise>
		</xsl:choose>
		<!-- <dp:set-variable name="'var://context/Trouble/troubleID'" value="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode']" 
			/> -->
	</xsl:template>
</xsl:stylesheet>
