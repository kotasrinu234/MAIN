<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpfunc="http://www.datapower.com/extensions/functions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	extension-element-prefixes="dp"
	exclude-result-prefixes="dp da com max sr soapenv">
	<xsl:include href="store:///utilities.xsl" />
	<xsl:output method="xml" />
	<xsl:include href="store:///utilities.xsl" />
	<xsl:output omit-xml-declaration="yes" />
	<!--This xslt will do the mapping required as per mapping(12,17) sheet -->
	<xsl:template match="/">
		<json:object
			xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
			xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">
			<json:object name="customFieldValues">
				<xsl:variable name="attachments"
					select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='attachments']" />
				<xsl:choose>
					<xsl:when test="string-length($attachments) &gt; 0">
						<dp:set-variable
							name="'var://context/Trouble/attachments'"
							value="$attachments" />
						<json:array name="attachments">
							<xsl:for-each
								select="//*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='attachments']/*[local-name()='id']">
								<json:object>
									<json:string name="id">
										<xsl:value-of select="." />
									</json:string>
								</json:object>
							</xsl:for-each>
						</json:array>
					</xsl:when>
				</xsl:choose>
			</json:object>
		</json:object>
	</xsl:template>
</xsl:stylesheet>
