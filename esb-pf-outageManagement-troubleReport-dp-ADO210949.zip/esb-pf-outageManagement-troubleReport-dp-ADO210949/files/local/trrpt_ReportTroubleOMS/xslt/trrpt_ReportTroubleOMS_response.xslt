<xsl:stylesheet version="1.0"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	extension-element-prefixes="dp"
	exclude-result-prefixes="dp soapenv date"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:v11="http://esm.dteco.com/common/v1"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ns2="http://trouble.outagemanagement.esm.dteco.com/v1/report"
	xmlns:ns3="http://outagemanagement.esm.dteco.com/trouble/v1">
	<xsl:output method="xml" />
	<!--This xslt is used to do the mapping as per mapping(18,19) sheet -->
	<xsl:template match="/">
		<xsl:variable name="Header">
			<xsl:copy-of
				select="dp:variable('var://context/Input/TroubleRequest')" />
		</xsl:variable>
		<xsl:message dp:type="all" dp:priority="debug">
			Header:
			<xsl:value-of select="$Header" />
		</xsl:message>
		<dp:set-http-request-header
			name="'Content-Type'" value="'application/xml'" />
		<soapenv:Envelope>
			<soapenv:Header />
			<soapenv:Body>
				<xsl:variable name="ActionValue">
					<!-- <xsl:value-of select="dp:variable('var://context/Input/TroubleRequest/action')"/> -->
					<xsl:value-of
						select="dp:variable('var://context/Trouble/action')" />
				</xsl:variable>
				<xsl:variable name="ActionValueNoPremiseid">
					<!-- <xsl:value-of select="dp:variable('var://context/Input/TroubleRequest/action')"/> -->
					<xsl:value-of
						select="dp:variable('var://context/callCheckResponse/Response')" />
				</xsl:variable>
				<xsl:variable name="Response">
					<xsl:choose>
						<xsl:when
							test="contains($ActionValueNoPremiseid,'NoPremiseID')">
							<ns3:RestorationStatus>
								<v11:Header>
									<v11:Verb>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Verb']" />
									</v11:Verb>
									<v11:Noun>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Noun']" />
									</v11:Noun>
									<v11:Revision>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Revision']" />
									</v11:Revision>
									<v11:Context>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Context']" />
									</v11:Context>
									<v11:Timestamp>
										<xsl:choose>
											<xsl:when
												test="json:object/json:array[@name='activeHazards']/json:object/json:string[@name ='updatedAt']">
												<xsl:value-of
													select="json:object/json:array[@name='activeHazards']/json:object/json:string[@name ='updatedAt']/text()" />
											</xsl:when>
											<xsl:when
												test="json:object/json:string[@name ='createdAt']">
												<xsl:value-of
													select="json:object/json:string[@name ='createdAt']/text()" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="$Header/*[local-name()='Header']/*[local-name()='Timestamp']" />
											</xsl:otherwise>
										</xsl:choose>
									</v11:Timestamp>
									<v11:Source>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Source']" />
									</v11:Source>
									<v11:AsyncReplyFlag>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='AsyncReplyFlag']" />
									</v11:AsyncReplyFlag>
									<v11:ReplyAddress>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='ReplyAddress']" />
									</v11:ReplyAddress>
									<v11:AckRequired>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='AckRequired']" />
									</v11:AckRequired>
									<v11:User>
										<v11:UserID>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='UserID']" />
										</v11:UserID>
										<v11:Organization>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='Organization']" />
										</v11:Organization>
									</v11:User>
									<v11:MessageID>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='MessageID']" />
									</v11:MessageID>
									<v11:CorrelationID>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='CorrelationID']" />
									</v11:CorrelationID>
									<v11:Comment>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Comment']" />
									</v11:Comment>
									<v11:Property>
										<v11:Name>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Name']" />
										</v11:Name>
										<v11:Value>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Value']" />
										</v11:Value>
									</v11:Property>
								</v11:Header>
								<v11:Reply>
									<xsl:choose>
										<xsl:when
											test="dp:variable('var://service/error-code')='0x00000000'">
											<v11:ReplyCode>
												<xsl:value-of select="'SUCCESS'" />
											</v11:ReplyCode>
										</xsl:when>
										<xsl:otherwise>
											<v11:ReplyCode>
												<xsl:value-of select="'FAIL'" />
											</v11:ReplyCode>
											<v11:Error>
												<v11:level>FATAL</v11:level>
												<v11:code>
													<xsl:value-of select="'500'" />
												</v11:code>
												<v11:details>
													<xsl:value-of
														select="dp:variable('var://service/error-message')" />
												</v11:details>
												<v11:context>ERROR</v11:context>
											</v11:Error>
											<v11:ID>
												<xsl:value-of select="'500'" />
											</v11:ID>
										</xsl:otherwise>
									</xsl:choose>
								</v11:Reply>
								<ns2:RestorationStatus>
									<ns2:applicationId>
										<xsl:value-of
											select="dp:variable('var://context/Input/applicationId')" />
									</ns2:applicationId>
									<!-- <ns2:applicationId><xsl:value-of select="dp:variable('var://context/Input/contactMethod')"/></ns2:applicationId> -->
									<ns2:requestorId>
										<xsl:value-of
											select="dp:variable('var://context/Input/requestorId')" />
									</ns2:requestorId>
									<ns2:troubleId>
										<xsl:value-of
											select="/json:object/json:string[@name ='displayID']" />
									</ns2:troubleId>
									<ns2:insvcJobId>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/CREjobDisplayID')" />
									</ns2:insvcJobId>
									<ns2:id>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/CREJobId')" />
									</ns2:id>
									<ns2:jobStatus />
									<ns2:crewId />
									<ns2:crewStatus />
									<ns2:crewDispatchDate />
									<ns2:xPosition />
									<ns2:yPosition />
									<ns2:troubleCode>
										<xsl:choose>
											<xsl:when
												test="/json:object/json:string[@name ='externalCallCodeID'] != ' '">
												<xsl:value-of
													select="/json:object/json:string[@name ='externalCallCodeID']" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Input/externalCallCodeID')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:troubleCode>
									<ns2:estimatedStartTime />
									<ns2:estimatedEndTime />
									<ns2:estimatedTimeLimit />
									<ns2:estimationType />
									<ns2:estimateSubType />
									<ns2:estimateChanged />
									<!-- <ns2:circuit><xsl:value-of select="/json:object/json:string[@name 
										='networkModelName']"/></ns2:circuit> -->
									<ns2:region />
									<ns2:dispatchGroup />
									<ns2:numberOfCustomersAffected />
									<ns2:numberOfCustomersStillOut />
									<ns2:offDate>
										<xsl:value-of
											select="/json:object/json:string[@name ='startedTime']" />
									</ns2:offDate>
									<ns2:onDate />
									<ns2:remarks>
										<xsl:value-of
											select="/json:object/json:string[@name ='notes']" />
									</ns2:remarks>
									<ns2:causeCode />
									<ns2:stormMode />
									<ns2:actionTaken />
									<ns2:businessException />
									<ns2:outage />
									<xsl:choose>
										<xsl:when
											test="/json:object/json:string[@name ='externalPremiseID'] != ' '">
											<ns2:premiseId>
												<xsl:value-of
													select="/json:object/json:string[@name ='externalPremiseID']" />
											</ns2:premiseId>
										</xsl:when>
										<xsl:when
											test="/json:object/json:string[@name ='externalPremiseID'] = ' '">
											<xsl:if
												test="dp:variable('var://context/Input/premiseId') != ' '">
												<ns2:premiseId>
													<xsl:value-of
														select="dp:variable('var://context/Input/premiseId')" />
												</ns2:premiseId>
											</xsl:if>
										</xsl:when>
										<xsl:otherwise></xsl:otherwise>
									</xsl:choose>
									<ns2:municipality>
										<xsl:choose>
											<xsl:when
												test="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='Municipality'] != ' '">
												<xsl:value-of
													select="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='Municipality']" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Input/Municipality')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:municipality>
									<ns2:address>
										<xsl:value-of
											select="/json:object/json:string[@name ='address']" />
									</ns2:address>
									<ns2:streetAddress>
										<xsl:value-of
											select="/json:object/json:string[@name ='address']" />
									</ns2:streetAddress>
									<ns2:zipcode />
									<ns2:externalReference>
										<xsl:choose>
											<xsl:when test="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='externalReference']">
												<xsl:value-of
													select="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='externalReference']" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Trouble/externalReference')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:externalReference>
								</ns2:RestorationStatus>
							</ns3:RestorationStatus>
						</xsl:when>

						<xsl:when test="contains($ActionValue,'CRE')">
							<ns3:RestorationStatus>
								<v11:Header>
									<v11:Verb>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Verb']" />
									</v11:Verb>
									<v11:Noun>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Noun']" />
									</v11:Noun>
									<v11:Revision>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Revision']" />
									</v11:Revision>
									<v11:Context>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Context']" />
									</v11:Context>
									<v11:Timestamp>
										<xsl:choose>
											<xsl:when
												test="json:object/json:array[@name='activeHazards']/json:object/json:string[@name ='updatedAt']">
												<xsl:value-of
													select="json:object/json:array[@name='activeHazards']/json:object/json:string[@name ='updatedAt']/text()" />
											</xsl:when>
											<xsl:when
												test="json:object/json:string[@name ='createdAt']">
												<xsl:value-of
													select="json:object/json:string[@name ='createdAt']/text()" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="$Header/*[local-name()='Header']/*[local-name()='Timestamp']" />
											</xsl:otherwise>
										</xsl:choose>
									</v11:Timestamp>
									<v11:Source>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Source']" />
									</v11:Source>
									<v11:AsyncReplyFlag>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='AsyncReplyFlag']" />
									</v11:AsyncReplyFlag>
									<v11:ReplyAddress>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='ReplyAddress']" />
									</v11:ReplyAddress>
									<v11:AckRequired>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='AckRequired']" />
									</v11:AckRequired>
									<v11:User>
										<v11:UserID>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='UserID']" />
										</v11:UserID>
										<v11:Organization>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='Organization']" />
										</v11:Organization>
									</v11:User>
									<v11:MessageID>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='MessageID']" />
									</v11:MessageID>
									<v11:CorrelationID>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='CorrelationID']" />
									</v11:CorrelationID>
									<v11:Comment>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Comment']" />
									</v11:Comment>
									<v11:Property>
										<v11:Name>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Name']" />
										</v11:Name>
										<v11:Value>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Value']" />
										</v11:Value>
									</v11:Property>
								</v11:Header>
								<v11:Reply>
									<xsl:choose>
										<xsl:when
											test="dp:variable('var://service/error-code')='0x00000000'">
											<v11:ReplyCode>
												<xsl:value-of select="'SUCCESS'" />
											</v11:ReplyCode>
										</xsl:when>
										<xsl:otherwise>
											<v11:ReplyCode>
												<xsl:value-of select="'FAIL'" />
											</v11:ReplyCode>
											<v11:Error>
												<v11:level>FATAL</v11:level>
												<v11:code>
													<xsl:value-of select="'500'" />
												</v11:code>
												<v11:details>
													<xsl:value-of
														select="dp:variable('var://service/error-message')" />
												</v11:details>
												<v11:context>ERROR</v11:context>
											</v11:Error>
											<v11:ID>
												<xsl:value-of select="'500'" />
											</v11:ID>
										</xsl:otherwise>
									</xsl:choose>
								</v11:Reply>
								<ns2:RestorationStatus>
									<ns2:applicationId>
										<xsl:value-of
											select="dp:variable('var://context/Input/applicationId')" />
									</ns2:applicationId>
									<!-- <ns2:applicationId><xsl:value-of select="dp:variable('var://context/Input/contactMethod')"/></ns2:applicationId> -->
									<ns2:requestorId>
										<xsl:value-of
											select="dp:variable('var://context/Input/requestorId')" />
									</ns2:requestorId>
									<ns2:troubleId>
										<xsl:value-of
											select="/json:object/json:string[@name ='displayID']" />
									</ns2:troubleId>
									<ns2:insvcJobId>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/CREjobDisplayID')" />
									</ns2:insvcJobId>
									<ns2:id>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/CREJobId')" />
									</ns2:id>
									<ns2:jobStatus />
									<ns2:crewId />
									<ns2:crewStatus />
									<ns2:crewDispatchDate />
									<ns2:xPosition />
									<ns2:yPosition />
									<!-- <ns2:troubleCode><xsl:choose><xsl:when test="/json:object/json:string[@name 
										='externalCallCodeID'] != ' '"><xsl:value-of select="/json:object/json:string[@name 
										='externalCallCodeID']"/></xsl:when><xsl:otherwise><xsl:value-of select="dp:variable('var://context/Input/externalCallCodeID')"/></xsl:otherwise></xsl:choose></ns2:troubleCode> -->
									<xsl:variable name="troubleCode">
										<xsl:value-of
											select="dp:variable('var://context/Trouble/callType')" />
									</xsl:variable>
									<ns2:troubleCode>
										<xsl:value-of select="$troubleCode" />
									</ns2:troubleCode>
									<ns2:estimatedStartTime />
									<ns2:estimatedEndTime />
									<ns2:estimatedTimeLimit />
									<ns2:estimationType />
									<ns2:estimateSubType />
									<ns2:estimateChanged />
									<!-- <ns2:circuit><xsl:value-of select="/json:object/json:string[@name 
										='networkModelName']"/></ns2:circuit> -->
									<ns2:region />
									<ns2:dispatchGroup />
									<ns2:numberOfCustomersAffected />
									<ns2:numberOfCustomersStillOut />
									<ns2:offDate>
										<xsl:value-of
											select="/json:object/json:string[@name ='startedTime']" />
									</ns2:offDate>
									<ns2:onDate />
									<ns2:remarks>
										<xsl:value-of
											select="/json:object/json:string[@name ='notes']" />
									</ns2:remarks>
									<ns2:causeCode />
									<ns2:stormMode />
									<ns2:actionTaken />
									<ns2:businessException />
									<ns2:outage />
									<xsl:choose>
										<xsl:when
											test="/json:object/json:string[@name ='externalPremiseID'] != ' '">
											<ns2:premiseId>
												<xsl:value-of
													select="/json:object/json:string[@name ='externalPremiseID']" />
											</ns2:premiseId>
										</xsl:when>
										<xsl:when
											test="/json:object/json:string[@name ='externalPremiseID'] = ' '">
											<xsl:if
												test="dp:variable('var://context/Input/premiseId') != ' '">
												<ns2:premiseId>
													<xsl:value-of
														select="dp:variable('var://context/Input/premiseId')" />
												</ns2:premiseId>
											</xsl:if>
										</xsl:when>
										<xsl:otherwise></xsl:otherwise>
									</xsl:choose>
									<ns2:municipality>
										<xsl:choose>
											<xsl:when
												test="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='Municipality'] != ' '">
												<xsl:value-of
													select="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='Municipality']" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Input/Municipality')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:municipality>
									<ns2:address>
										<xsl:value-of
											select="/json:object/json:string[@name ='address']" />
									</ns2:address>
									<ns2:streetAddress>
										<xsl:value-of
											select="/json:object/json:string[@name ='address']" />
									</ns2:streetAddress>
									<ns2:zipcode />
									<ns2:externalReference>
										<xsl:choose>
											<xsl:when test="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='externalReference']">
												<xsl:value-of
													select="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='externalReference']" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Trouble/externalReference')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:externalReference>
								</ns2:RestorationStatus>
							</ns3:RestorationStatus>
						</xsl:when>

						<xsl:when test="contains($ActionValue,'DUP')">
							<ns3:RestorationStatus>
								<v11:Header>
									<v11:Verb>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Verb']" />
									</v11:Verb>
									<v11:Noun>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Noun']" />
									</v11:Noun>
									<v11:Revision>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Revision']" />
									</v11:Revision>
									<v11:Context>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Context']" />
									</v11:Context>
									<v11:Timestamp>
										<xsl:choose>
											<xsl:when
												test="json:object/json:array[@name='activeHazards']/json:object/json:string[@name ='updatedAt']">
												<xsl:value-of
													select="json:object/json:array[@name='activeHazards']/json:object/json:string[@name ='updatedAt']/text()" />
											</xsl:when>
											<xsl:when
												test="json:object/json:string[@name ='createdAt']">
												<xsl:value-of
													select="json:object/json:string[@name ='createdAt']/text()" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="$Header/*[local-name()='Header']/*[local-name()='Timestamp']" />
											</xsl:otherwise>
										</xsl:choose>
									</v11:Timestamp>
									<v11:Source>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Source']" />
									</v11:Source>
									<v11:AsyncReplyFlag>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='AsyncReplyFlag']" />
									</v11:AsyncReplyFlag>
									<v11:ReplyAddress>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='ReplyAddress']" />
									</v11:ReplyAddress>
									<v11:AckRequired>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='AckRequired']" />
									</v11:AckRequired>
									<v11:User>
										<v11:UserID>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='UserID']" />
										</v11:UserID>
										<v11:Organization>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='Organization']" />
										</v11:Organization>
									</v11:User>
									<v11:MessageID>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='MessageID']" />
									</v11:MessageID>
									<v11:CorrelationID>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='CorrelationID']" />
									</v11:CorrelationID>
									<v11:Comment>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Comment']" />
									</v11:Comment>
									<v11:Property>
										<v11:Name>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Name']" />
										</v11:Name>
										<v11:Value>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Value']" />
										</v11:Value>
									</v11:Property>
								</v11:Header>
								<v11:Reply>
									<xsl:choose>
										<xsl:when
											test="dp:variable('var://service/error-code')='0x00000000'">
											<v11:ReplyCode>
												<xsl:value-of select="'SUCCESS'" />
											</v11:ReplyCode>
										</xsl:when>
										<xsl:otherwise>
											<v11:ReplyCode>
												<xsl:value-of select="'FAIL'" />
											</v11:ReplyCode>
											<v11:Error>
												<v11:level>FATAL</v11:level>
												<v11:code>
													<xsl:value-of select="'500'" />
												</v11:code>
												<v11:details>
													<xsl:value-of
														select="dp:variable('var://service/error-message')" />
												</v11:details>
												<v11:context>ERROR</v11:context>
											</v11:Error>
											<v11:ID>
												<xsl:value-of select="'500'" />
											</v11:ID>
										</xsl:otherwise>
									</xsl:choose>
								</v11:Reply>
								<ns2:RestorationStatus>
									<ns2:applicationId>
										<xsl:value-of
											select="dp:variable('var://context/Input/applicationId')" />
									</ns2:applicationId>
									<!-- <ns2:applicationId><xsl:value-of select="dp:variable('var://context/Input/contactMethod')"/></ns2:applicationId> -->
									<ns2:requestorId>
										<xsl:value-of
											select="dp:variable('var://context/Input/requestorId')" />
									</ns2:requestorId>
									<ns2:troubleId>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/displayID')" />
									</ns2:troubleId>
									<ns2:insvcJobId>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/jobDisplayID')" />
									</ns2:insvcJobId>
									<ns2:id>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/DUPJobId')" />
									</ns2:id>
									<ns2:jobStatus>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/jobStatus')" />
									</ns2:jobStatus>
									<ns2:crewId />
									<ns2:crewStatus />
									<ns2:crewDispatchDate />
									<ns2:xPosition />
									<ns2:yPosition />
									<ns2:troubleCode>
										<xsl:variable name="externalCallCodeIDVal">
											<xsl:value-of
												select="dp:variable('var://context/Trouble/externalCallCodeID')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when test="$externalCallCodeIDVal != ''">
												<xsl:value-of
													select="dp:variable('var://context/Trouble/externalCallCodeID')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Input/troubleCode')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:troubleCode>
									<ns2:estimatedStartTime>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/etrvalue')" />
									</ns2:estimatedStartTime>
									<ns2:estimatedEndTime>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/etrvalue')" />
									</ns2:estimatedEndTime>
									<ns2:estimatedTimeLimit />
									<ns2:estimationType />
									<ns2:estimateSubType />
									<ns2:estimateChanged />
									<xsl:variable name="nominalFeeder">
										<xsl:value-of
											select="dp:variable('var://context/Trouble/nominalFeeder')" />
									</xsl:variable>
									<xsl:if test="string-length($nominalFeeder) &gt; 0">
										<ns2:circuit>
											<xsl:value-of select="$nominalFeeder" />
										</ns2:circuit>
									</xsl:if>
									<!-- <ns2:circuit><xsl:value-of select="/json:object/json:string[@name 
										='networkModelName']"/></ns2:circuit> -->
									<ns2:region>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/regionName')" />
									</ns2:region>
									<ns2:dispatchGroup>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/dispatchGroup')" />
									</ns2:dispatchGroup>
									<ns2:numberOfCustomersAffected>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/totalAffected')" />
									</ns2:numberOfCustomersAffected>
									<ns2:numberOfCustomersStillOut>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/currentAffected')" />
									</ns2:numberOfCustomersStillOut>
									<ns2:offDate>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/offDate')" />
									</ns2:offDate>
									<ns2:onDate />
									<ns2:remarks>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/notes')" />
									</ns2:remarks>
									<ns2:causeCode>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/cause')" />
									</ns2:causeCode>
									<ns2:stormMode>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/stormMode')" />
									</ns2:stormMode>
									<ns2:actionTaken>
										<xsl:value-of
											select="'Trouble already exists.Returning Status'" />
									</ns2:actionTaken>
									<ns2:businessException>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/BusinessException')" />
									</ns2:businessException>
									<ns2:outage>
										<!-- <xsl:value-of select="dp:variable('var://context/Trouble/outage')"/> -->
										<!-- <xsl:if test = "dp:variable('var://context/Trouble/outage') 
											! = 'outage'"> -->
										<xsl:variable name="outage"
											select="dp:variable('var://context/Trouble/outage')" />
										<xsl:message>
											outage values is-------
											<xsl:value-of select="$outage" />
										</xsl:message>
										<xsl:if test="string-length($outage) &gt; 0">
											<xsl:choose>
												<xsl:when
													test="contains($outage,'UNPLANNED_OUTAGE')">
													<xsl:value-of select="'true'" />
												</xsl:when>
												<xsl:otherwise>
													<xsl:value-of select="'false'" />
												</xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</ns2:outage>
									<ns2:premiseId>
										<xsl:variable name="PremiseIDVal">
											<xsl:value-of
												select="dp:variable('var://context/Trouble/externalPremiseID')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when test="$PremiseIDVal != ''">
												<xsl:value-of
													select="dp:variable('var://context/Trouble/externalPremiseID')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Input/premiseId')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:premiseId>
									<ns2:municipality>
										<xsl:variable name="MunicipalityVal">
											<xsl:value-of
												select="dp:variable('var://context/Trouble/Municipality')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when test="$MunicipalityVal != ''">
												<xsl:value-of
													select="dp:variable('var://context/Trouble/Municipality')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Input/municipality')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:municipality>
									<ns2:address>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/address')" />
									</ns2:address>
									<ns2:streetAddress>
										<xsl:value-of
											select="dp:variable('var://context/Trouble/address')" />
									</ns2:streetAddress>
									<ns2:zipcode />
									<ns2:externalReference>
										<xsl:choose>
											<xsl:when test="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='externalReference']">
												<xsl:value-of
													select="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='externalReference']" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Trouble/externalReference')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:externalReference>
								</ns2:RestorationStatus>
							</ns3:RestorationStatus>
						</xsl:when>

						<xsl:when test="contains($ActionValue,'CHG')">
							<ns3:RestorationStatus>
								<v11:Header>
									<v11:Verb>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Verb']" />
									</v11:Verb>
									<v11:Noun>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Noun']" />
									</v11:Noun>
									<v11:Revision>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Revision']" />
									</v11:Revision>
									<v11:Context>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Context']" />
									</v11:Context>
									<v11:Timestamp>
										<xsl:choose>
											<xsl:when
												test="json:object/json:array[@name='activeHazards']/json:object/json:string[@name ='updatedAt']">
												<xsl:value-of
													select="json:object/json:array[@name='activeHazards']/json:object/json:string[@name ='updatedAt']/text()" />
											</xsl:when>
											<xsl:when
												test="json:object/json:string[@name ='createdAt']">
												<xsl:value-of
													select="json:object/json:string[@name ='createdAt']/text()" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="$Header/*[local-name()='Header']/*[local-name()='Timestamp']" />
											</xsl:otherwise>
										</xsl:choose>
									</v11:Timestamp>
									<v11:Source>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Source']" />
									</v11:Source>
									<v11:AsyncReplyFlag>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='AsyncReplyFlag']" />
									</v11:AsyncReplyFlag>
									<v11:ReplyAddress>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='ReplyAddress']" />
									</v11:ReplyAddress>
									<v11:AckRequired>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='AckRequired']" />
									</v11:AckRequired>
									<v11:User>
										<v11:UserID>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='UserID']" />
										</v11:UserID>
										<v11:Organization>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='User']/*[local-name()='Organization']" />
										</v11:Organization>
									</v11:User>
									<v11:MessageID>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='MessageID']" />
									</v11:MessageID>
									<v11:CorrelationID>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='CorrelationID']" />
									</v11:CorrelationID>
									<v11:Comment>
										<xsl:value-of
											select="$Header/*[local-name()='Header']/*[local-name()='Comment']" />
									</v11:Comment>
									<v11:Property>
										<v11:Name>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Name']" />
										</v11:Name>
										<v11:Value>
											<xsl:value-of
												select="$Header/*[local-name()='Header']/*[local-name()='Property']/*[local-name()='Value']" />
										</v11:Value>
									</v11:Property>
								</v11:Header>
								<v11:Reply>
									<xsl:choose>
										<xsl:when
											test="dp:variable('var://service/error-code')='0x00000000'">
											<v11:ReplyCode>
												<xsl:value-of select="'SUCCESS'" />
											</v11:ReplyCode>
										</xsl:when>
										<xsl:otherwise>
											<v11:ReplyCode>
												<xsl:value-of select="'FAIL'" />
											</v11:ReplyCode>
											<v11:Error>
												<v11:level>FATAL</v11:level>
												<v11:code>
													<xsl:value-of select="'500'" />
												</v11:code>
												<v11:details>
													<xsl:value-of
														select="dp:variable('var://service/error-message')" />
												</v11:details>
												<v11:context>ERROR</v11:context>
											</v11:Error>
											<v11:ID>
												<xsl:value-of select="'500'" />
											</v11:ID>
										</xsl:otherwise>
									</xsl:choose>
								</v11:Reply>
								<ns2:RestorationStatus>
									<ns2:applicationId>
										<xsl:value-of
											select="dp:variable('var://context/Input/applicationId')" />
									</ns2:applicationId>
									<!-- <ns2:applicationId><xsl:value-of select="dp:variable('var://context/Input/contactMethod')"/></ns2:applicationId> -->
									<ns2:requestorId>
										<xsl:value-of
											select="dp:variable('var://context/Input/requestorId')" />
									</ns2:requestorId>
									<xsl:variable name="troubleId">
										<xsl:value-of
											select="dp:variable('var://context/patchCallRes/CallPATCHapi_res_displayID')" />
									</xsl:variable>
									<ns2:troubleId>
										<xsl:choose>
											<xsl:when test="$troubleId != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/CallPATCHapi_res_displayID')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Trouble/troubleId')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:troubleId>
									<ns2:insvcJobId>
										<xsl:variable name="jobDisplayID">
											<xsl:value-of
												select="dp:variable('var://context/patchCallRes/jobDisplayID')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when test="$jobDisplayID != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/jobDisplayID')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/patchReslookup/jobDisplayID')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:insvcJobId>
									<ns2:Id>
										<xsl:variable name="patch_JobID">
											<xsl:value-of
												select="dp:variable('var://context/patchCallRes/CallPATCHapi_res_jobID')" />
										</xsl:variable>
										<xsl:variable name="post_JobID">
											<xsl:value-of
												select="dp:variable('var://context/patchReslookup/displayIdqueryAPI_res_jobID')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when test="$patch_JobID != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/CallPATCHapi_res_jobID')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/patchReslookup/displayIdqueryAPI_res_jobID')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:Id>
									<ns2:jobStatus>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/jobStatusLabel')" />
									</ns2:jobStatus>
									<ns2:crewId />
									<ns2:crewStatus />
									<ns2:crewDispatchDate />
									<ns2:xPosition />
									<ns2:yPosition />
									<ns2:troubleCode>
										<xsl:variable name="externalCallCodeIDVal">
											<xsl:value-of
												select="dp:variable('var://context/patchCallRes/externalCallCodeID')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when test="$externalCallCodeIDVal != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/externalCallCodeID')" />
											</xsl:when>
											<xsl:when
												test="dp:variable('var://context/patchReslookup/externalCallCodeID') != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchReslookup/externalCallCodeID')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Trouble/externalCallCodeID')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:troubleCode>
									<ns2:estimatedStartTime>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/etrvalue')" />
									</ns2:estimatedStartTime>
									<ns2:estimatedEndTime>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/etrvalue')" />
									</ns2:estimatedEndTime>
									<ns2:estimatedTimeLimit />
									<ns2:estimationType />
									<ns2:estimateSubType />
									<ns2:estimateChanged />
									<!-- <xsl:variable name="nominalFeeder"><xsl:value-of select="dp:variable('var://context/Trouble/nominalFeeder')"/></xsl:variable><xsl:if 
										test ="string-length($nominalFeeder) &gt; 0"><ns2:circuit><xsl:value-of select="$nominalFeeder" 
										/></ns2:circuit></xsl:if> -->
									<ns2:circuit>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/nominalFeeder')" />
									</ns2:circuit>
									<ns2:region>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/regionName')" />
									</ns2:region>
									<ns2:dispatchGroup>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/aorLabel')" />
									</ns2:dispatchGroup>
									<ns2:numberOfCustomersAffected>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/totalAffected')" />
									</ns2:numberOfCustomersAffected>
									<ns2:numberOfCustomersStillOut>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/currentAffected')" />
									</ns2:numberOfCustomersStillOut>
									<xsl:variable name="startedTime">
										<xsl:value-of
											select="dp:variable('var://context/patchCallRes/startedTime')" />
									</xsl:variable>
									<ns2:offDate>
										<xsl:choose>
											<xsl:when test="$startedTime != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/startedTime')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/patchReslookup/startedTime')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:offDate>
									<ns2:onDate />
									<xsl:variable name="notes">
										<xsl:value-of
											select="dp:variable('var://context/patchCallRes/notes')" />
									</xsl:variable>
									<ns2:remarks>
										<xsl:choose>
											<xsl:when test="$notes != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/notes')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/patchReslookup/notes')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:remarks>
									<ns2:causeCode>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/cause')" />
									</ns2:causeCode>
									<ns2:stormMode>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/stormMode')" />
									</ns2:stormMode>
									<ns2:actionTaken>
									</ns2:actionTaken>
									<ns2:businessException>
										<xsl:value-of
											select="dp:variable('var://context/patchReslookup/BusinessException')" />
									</ns2:businessException>
									<ns2:outage>
										<xsl:variable name="outage"
											select="dp:variable('var://context/patchReslookup/outage')" />
										<xsl:message>
											outage values is-------
											<xsl:value-of select="$outage" />
										</xsl:message>
										<xsl:if test="string-length($outage) &gt; 0">
											<xsl:choose>
												<xsl:when
													test="contains($outage,'UNPLANNED_OUTAGE')">
													<xsl:value-of select="'true'" />
												</xsl:when>
												<xsl:otherwise>
													<xsl:value-of select="'false'" />
												</xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</ns2:outage>
									<ns2:premiseId>
										<xsl:variable name="PremiseIDVal">
											<xsl:value-of
												select="dp:variable('var://context/patchCallRes/externalPremiseID')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when test="$PremiseIDVal != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/externalPremiseID')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/patchReslookup/externalPremiseID')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:premiseId>
									<ns2:municipality>
										<xsl:variable name="MunicipalityVal">
											<xsl:value-of
												select="dp:variable('var://context/patchCallRes/customFieldValuesExtMunicipality')" />
										</xsl:variable>
										<xsl:choose>
											<xsl:when test="$MunicipalityVal != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/customFieldValuesExtMunicipality')" />
											</xsl:when>
											<xsl:when
												test="dp:variable('var://context/patchReslookup/customFieldValuesExtMunicipality') != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/customFieldValuesExtMunicipality')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Trouble/municipality')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:municipality>
									<xsl:variable name="address">
										<xsl:value-of
											select="dp:variable('var://context/patchCallRes/address')" />
									</xsl:variable>
									<ns2:address>
										<xsl:choose>
											<xsl:when test="$addess != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/address')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/patchReslookup/address')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:address>
									<ns2:streetAddress>
										<xsl:choose>
											<xsl:when test="$addess != ''">
												<xsl:value-of
													select="dp:variable('var://context/patchCallRes/address')" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/patchReslookup/address')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:streetAddress>
									<ns2:zipcode />
									<ns2:externalReference>
										<xsl:choose>
											<xsl:when test="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='externalReference']">
												<xsl:value-of
													select="/json:object/json:object[@name = 'customFieldValuesExt']/json:string[@name ='externalReference']" />
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of
													select="dp:variable('var://context/Trouble/externalReference')" />
											</xsl:otherwise>
										</xsl:choose>
									</ns2:externalReference>
								</ns2:RestorationStatus>
							</ns3:RestorationStatus>
						</xsl:when>
					</xsl:choose>
				</xsl:variable>
				<xsl:copy-of select="$Response" />
				<dp:set-variable
					name="'var://context/Trouble/Response'" value="$Response" />
			</soapenv:Body>
		</soapenv:Envelope>
	</xsl:template>
</xsl:stylesheet>
