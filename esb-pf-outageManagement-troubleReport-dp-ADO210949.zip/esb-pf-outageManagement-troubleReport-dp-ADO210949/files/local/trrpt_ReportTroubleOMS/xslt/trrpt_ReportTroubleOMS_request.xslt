<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpfunc="http://www.datapower.com/extensions/functions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	extension-element-prefixes="dp"
	exclude-result-prefixes="dp da com max sr soapenv">
	<xsl:include href="store:///utilities.xsl" />
	<xsl:output method="xml" />
	<xsl:include href="store:///utilities.xsl" />
	<xsl:output omit-xml-declaration="yes" />
	<!--This xslt will do the mapping required as per mapping(12,17) sheet -->
	<xsl:template match="/">
		<xsl:variable name="action"
			select="dp:variable('var://context/Trouble/action')" />
		<xsl:variable name="rightNow"
			select="date:seconds(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='notificationTime'])" />
		<xsl:variable name="convertTime"
			select="dpfunc:zulu-time($rightNow, 'on')" />
		<xsl:variable name="startedAt">
			<xsl:value-of
				select="concat(substring-before($convertTime,'.'),'Z')" />
		</xsl:variable>
		<xsl:if
			test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']">
			<dp:set-variable
				name="'var://context/Input/contactMethod'"
				value="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']" />
		</xsl:if>
		<!-- <xsl:variable name="appId" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']" 
			/> <xsl:message>coming from input<xsl:value-of select="$appId"/></xsl:message> 
			<xsl:variable name="applicationId" select="document('local:///trrpt_ReportTroubleOMS/xml/trrpt_ReportTroubleOMS_applicationId.xml')"/> 
			<xsl:for-each select="$applicationId/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']"> 
			<xsl:variable name="name" select="./*[local-name()='name']"/> <xsl:message>coming 
			from input<xsl:value-of select="./*[local-name()='description']"/></xsl:message> 
			<xsl:message>coming from input<xsl:value-of select="$name"/></xsl:message> 
			<xsl:message>jaswanth<xsl:value-of select="string($appId)"/></xsl:message> 
			<xsl:if test="$name = string($appId)"> <dp:set-variable name="'var://context/description'" 
			value="./*[local-name()='description']" /> <xsl:message>from config file<xsl:value-of 
			select="$description"/></xsl:message> <dp:set-variable name="'var://context/input/Trouble'" 
			value="'ValueIsSet'" /> </xsl:if> </xsl:for-each> -->
		<xsl:if
			test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='requestorId']">
			<dp:set-variable
				name="'var://context/Input/requestorId'"
				value="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='requestorId'])" />
		</xsl:if>
		<xsl:if
			test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']">
			<dp:set-variable
				name="'var://context/Input/applicationId'"
				value="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId'])" />
		</xsl:if>
		<xsl:choose>
			<xsl:when
				test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode']">
				<dp:set-variable
					name="'var://context/Input/externalCallCodeID'"
					value="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode']" />
			</xsl:when>
			<xsl:when
				test="not(*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode'])">
				<dp:set-variable
					name="'var://context/error/customErrorMessage'"
					value="'troubleCode field not present in incoming data'" />
				<dp:reject />
			</xsl:when>
			<xsl:otherwise />
		</xsl:choose>
		<xsl:if
			test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='premiseId']">
			<dp:set-variable
				name="'var://context/Input/premiseId'"
				value="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='premiseId']" />
		</xsl:if>
		<xsl:if
			test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='municipality']">
			<dp:set-variable
				name="'var://context/Input/Municipality'"
				value="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='municipality']" />
		</xsl:if>
		<json:object
			xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
			xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">
			<xsl:choose>
				<xsl:when
					test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPreference'] = 'P'">
					<json:string name="callbackContactMethod">
						<xsl:value-of select="'1'" />
					</json:string>
				</xsl:when>
				<xsl:when
					test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPreference'] = 'S'">
					<json:string name="callbackContactMethod">
						<xsl:value-of select="'3'" />
					</json:string>
				</xsl:when>
				<xsl:when
					test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPreference'] = 'E'">
					<json:string name="callbackContactMethod">
						<xsl:value-of select="'2'" />
					</json:string>
				</xsl:when>
				<xsl:when
					test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPreference'] = 'N'" />
				<xsl:when
					test="not(*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPreference'])">
					<!-- <dp:set-variable name="'var://context/error/customErrorMessage'" 
						value="'contactPreference field not present in incoming data'" /> <dp:reject 
						/> -->
				</xsl:when>
				<xsl:otherwise />
			</xsl:choose>
			<xsl:if
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='remarks']">
				<json:string name="notes">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='remarks']" />
				</json:string>
			</xsl:if>
			<xsl:variable name="premiseId"
				select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='premiseId']" />
			<xsl:if test="string-length($premiseId) &gt; 0">
				<json:string name="externalPremiseID">
					<xsl:value-of
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='premiseId']" />
				</json:string>
			</xsl:if>
			<xsl:if
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='addressOfLocation']">
				<xsl:variable name="address"
					select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='addressOfLocation']" />
				<xsl:if test="string-length($address) &gt; 0">
					<json:string name="address">
						<xsl:value-of select="$address" />
					</json:string>
				</xsl:if>
				<!-- <json:string name="address"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='addressOfLocation']" 
					/> </json:string> -->
			</xsl:if>
			<xsl:if
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode']">
				<xsl:choose>
					<xsl:when test="string-length($premiseId) &gt; 0">
						<xsl:variable name="troubleCode">
							<xsl:value-of
								select="dp:variable('var://context/Trouble/callType')" />
						</xsl:variable>
						<json:string name="externalCallCodeID">
							<xsl:value-of select="$troubleCode" />
						</json:string>
					</xsl:when>
					<xsl:otherwise>
						<json:string name="externalCallCodeID">
							<xsl:value-of
								select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode']" />
						</json:string>
					</xsl:otherwise>
				</xsl:choose>
				<!-- <json:string name="externalCallCodeID"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode']" 
					/> </json:string> -->
			</xsl:if>
			<xsl:variable name="contactMethodlookup"
				select="dp:variable('var://context/contactMethod/contactMethodLookup_invoked')" />
			<xsl:if test="$contactMethodlookup = 'Yes'">
				<json:string name="contactMethod">
					<xsl:value-of
						select="dp:variable('var://context/contactMethod/contactMethodLookup_status')" />
					</json:string>
			</xsl:if>
			<json:string name="startedAt">
				<xsl:value-of select="$startedAt" />
			</json:string>
			<xsl:if
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactInformation']">
				<xsl:variable name="callbackContactInfo"
					select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactInformation']" />
				<xsl:if test="string-length($callbackContactInfo) &gt; 0">
					<json:string name="callbackContactInfo">
						<xsl:value-of select="$callbackContactInfo" />
					</json:string>
				</xsl:if>
				<!-- <json:string name="callbackContactInfo"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactInformation']" 
					/> </json:string> -->
			</xsl:if>
			<xsl:if
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPhone']">
				<xsl:variable name="phoneNumber"
					select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPhone']" />
				<xsl:if test="string-length($phoneNumber) &gt; 0">
					<json:string name="phoneNumber">
						<xsl:value-of select="$phoneNumber" />
					</json:string>
				</xsl:if>
				<!-- <json:string name="phoneNumber"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPhone']" 
					/> </json:string> -->
			</xsl:if>
			<json:object name="customFieldValues">
				<!-- <json:string name="MessageID"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Header']/*[local-name()='MessageID']" 
					/> </json:string> -->
					<xsl:choose>
					<xsl:when test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='outageReason'] = 'SinglePremiseOnTransformer'">
						<json:boolean name="SinglePremiseOnTransformer">
						<xsl:value-of select="'true'" />
					</json:boolean>
					</xsl:when>
					<xsl:otherwise>
						<json:boolean name="SinglePremiseOnTransformer">
						<xsl:value-of select="'false'" />
					</json:boolean>
					</xsl:otherwise>
				</xsl:choose>
				 <xsl:if test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Header']/*[local-name()='Source']">
					<json:string name="source">
						<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Header']/*[local-name()='Source']"/>
					</json:string>
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']">
					<json:string name="ApplicationID">
						<xsl:value-of
							select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId']" />
					</json:string>
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='requestorId']">
					<xsl:variable name="RequestorID"
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='requestorId']" />
					<xsl:if test="string-length($RequestorID) &gt; 0">
						<json:string name="RequestorID">
							<xsl:value-of select="$RequestorID" />
						</json:string>
					</xsl:if>
					<!-- <json:string name="RequestorID"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='requestorId']" 
						/> </json:string> -->
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='paymentStatusCode']">
					<xsl:variable name="paymentStatusCode"
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='paymentStatusCode']" />
					<xsl:if test="string-length($paymentStatusCode) &gt; 0">
						<json:string name="paymentStatusCode">
							<xsl:value-of select="$paymentStatusCode" />
						</json:string>
					</xsl:if>
					<!-- <json:string name="PaymentStatusCode"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='paymentStatusCode']" 
						/> </json:string> -->
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactEmail']">
					<xsl:variable name="ContactEmail"
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactEmail']" />
					<xsl:if test="string-length($ContactEmail) &gt; 0">
						<json:string name="ContactEmail">
							<xsl:value-of select="$ContactEmail" />
						</json:string>
					</xsl:if>
					<!-- <json:string name="ContactEmail"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactEmail']" 
						/> </json:string> -->
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet1']">
					<xsl:variable name="CrossStreet1"
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet1']" />
					<xsl:if test="string-length($CrossStreet1) &gt; 0">
						<json:string name="CrossStreet1">
							<xsl:value-of select="$CrossStreet1" />
						</json:string>
					</xsl:if>
					<!-- <json:string name="CrossStreet1"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet1']" 
						/> </json:string> -->
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet2']">
					<xsl:variable name="CrossStreet2"
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet2']" />
					<xsl:if test="string-length($CrossStreet2) &gt; 0">
						<json:string name="CrossStreet2">
							<xsl:value-of select="$CrossStreet2" />
						</json:string>
					</xsl:if>
					<!-- <json:string name="CrossStreet2"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet2']" 
						/> </json:string> -->
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='municipality']">
					<xsl:variable name="Municipality"
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='municipality']" />
					<xsl:if test="string-length($Municipality) &gt; 0">
						<json:string name="Municipality">
							<xsl:value-of select="$Municipality" />
						</json:string>
					</xsl:if>
					<!-- <json:string name="Municipality"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='municipality']" 
						/> </json:string> -->
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='externalReference']">
					<xsl:variable name="externalReference"
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='externalReference']" />
					<xsl:if test="string-length($externalReference) &gt; 0">
						<json:string name="external_order_number">
							<xsl:value-of select="$externalReference" />
						</json:string>
						<dp:set-variable
							name="'var://context/Trouble/externalReference'"
							value="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='externalReference'])" />
					</xsl:if>
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='attachments']">
					<json:boolean name="Attachment_Available_Flag">
						<xsl:value-of select="'true'" />
					</json:boolean>
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='TBTFlag']">
					<xsl:variable name="TBTFlag"
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='TBTFlag']" />
					<xsl:choose>
						<xsl:when test="string-length($TBTFlag) &gt; 0">
							<json:boolean name="TBT">
								<xsl:value-of
									select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='TBTFlag']" />
							</json:boolean>
						</xsl:when>
						<xsl:otherwise>
							<json:boolean name="TBT">
								<xsl:value-of select="'false'" />
							</json:boolean>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='TBTOriginalCallNumber']">
					<json:string name="TBTOriginalCallNumber">
						<xsl:value-of
							select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='TBTOriginalCallNumber']" />
					</json:string>
				</xsl:if>
			</json:object>
			<xsl:if
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='customerName']">
				<xsl:variable name="name"
					select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='customerName']" />
				<xsl:if test="string-length($name) &gt; 0">
					<json:string name="name">
						<xsl:value-of select="$name" />
					</json:string>
				</xsl:if>
				<!-- <json:string name="name"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='customerName']" 
					/> </json:string> -->
			</xsl:if>
			<!-- <xsl:if test="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='remarks']"> 
				<json:string name="includeRemarks"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='includeRemarks']" 
				/> </json:string> </xsl:if> -->
			<xsl:if
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='observations']">
				<json:array name="observations">
					<xsl:for-each
						select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='observations']/*[local-name()='observation']">
						<xsl:message>
							Inside for observations
						</xsl:message>
						<json:number name='observationNumber'>
							<xsl:value-of select="." />
						</json:number>
					</xsl:for-each>
				</json:array>
				<!-- <xsl:variable name="firstObservation"> <xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='observations']/*[local-name()='observation' 
					and position()=1]" /> </xsl:variable> <xsl:variable name="secondObservation"> 
					<xsl:value-of select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='observations']/*[local-name()='observation' 
					and position()=2]" /> </xsl:variable> <json:array name="observations"> <xsl:if 
					test="$firstObservation!=''"> <json:number> <xsl:value-of select="$firstObservation" 
					/> </json:number> </xsl:if> <xsl:if test="$secondObservation!=''"> <json:number> 
					<xsl:value-of select="$secondObservation" /> </json:number> </xsl:if> </json:array> -->
			</xsl:if>
			<xsl:if
				test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']">
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']/*[local-name() = 'longitude']">
					<xsl:if
						test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']/*[local-name() = 'latitude']">
						<xsl:variable name="longitude">
							<xsl:value-of
								select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']/*[local-name()='longitude']" />
						</xsl:variable>
						<xsl:variable name="latitude">
							<xsl:value-of
								select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']/*[local-name()='latitude']" />
						</xsl:variable>
						<xsl:if
							test="(string-length($longitude) &gt; 0) and (string-length($latitude) &gt; 0)">
							<xsl:for-each
								select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']">
								<json:object name="location">
									<json:array name="coordinates">
										<json:number>
											<xsl:value-of select="$longitude" />
										</json:number>
										<json:number>
											<xsl:value-of select="$latitude" />
										</json:number>
									</json:array>
									<json:string name="type">
										<xsl:value-of select="'POINT'" />
									</json:string>
								</json:object>
							</xsl:for-each>
						</xsl:if>
					</xsl:if>
				</xsl:if>
			</xsl:if>
			<xsl:if
				test="dp:variable('var://context/trrpt_ReporteTroubleOMS/flag') = '1'">
				<xsl:variable name="CrossSecretLookupResponse">
					<xsl:copy-of
						select="dp:variable('var://context/CrossStreetLookUpJSONx_Output')" />
				</xsl:variable>
				<xsl:for-each
					select="$CrossSecretLookupResponse/*[local-name()='object']/*[local-name()='array'][@name = 'candidates']/*[local-name()='object']">
					<xsl:sort
						select="./*[local-name()='number'][@name = 'score']"
						data-type="number" order="descending" />
					<xsl:if test="position() = 1">
						<json:object name="location">
							<json:array name="coordinates">
								<json:number>
									<xsl:value-of
										select="./*[local-name()='object']/*[local-name()='number'][@name = 'x']" />
								</json:number>
								<json:number>
									<xsl:value-of
										select="./*[local-name()='object']/*[local-name()='number'][@name = 'y']" />
								</json:number>
							</json:array>
							<json:string name="type">
								<xsl:value-of select="'POINT'" />
							</json:string>
						</json:object>
					</xsl:if>
				</xsl:for-each>
			</xsl:if>
		</json:object>
	</xsl:template>
</xsl:stylesheet>
