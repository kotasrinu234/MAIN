<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" extension-element-prefixes="dp dpconfig" exclude-result-prefixes="dp da com max sr soapenv dpconfig">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" omit-xml-declaration="no"/>
	<xsl:strip-space elements="*"/>
	<xsl:param name="dpconfig:reportTroubleExitDescription" select="''"/>
	<xsl:template match="/">
		<xsl:variable name="reportTroubleExitDescription" select="$dpconfig:reportTroubleExitDescription"/>
		<dp:set-variable name="'var://context/ilsExit/reportTroubleExitDescription'" value="string($reportTroubleExitDescription)"/>
		<xsl:variable name="TransformedData" select="dp:variable('var://context/Trouble/Response')"/>
		<xsl:variable name="callDisplayID" select="$TransformedData/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='troubleId']/text()"/>
		<xsl:variable name="jobDisplayID" select="$TransformedData/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='insvcJobId']/text()"/>
		<xsl:variable name="jobID">
			<xsl:choose>
				<xsl:when test="$TransformedData/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='id']">
					<xsl:value-of select="$TransformedData/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='id']/text()"/>
				</xsl:when>
				<xsl:when test="$TransformedData/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='Id']">
					<xsl:value-of select="$TransformedData/*[local-name()='RestorationStatus']/*[local-name()='RestorationStatus']/*[local-name()='Id']/text()"/>
				</xsl:when>
			</xsl:choose>
		</xsl:variable>
		<dp:set-variable name="'var://context/ILSExit/callDisplayID'" value="string($callDisplayID)"/>
		<dp:set-variable name="'var://context/ILSExit/jobDisplayID'" value="string($jobDisplayID)"/>
		<dp:set-variable name="'var://context/ILSExit/jobID'" value="string($jobID)"/>
	</xsl:template>
</xsl:stylesheet>
