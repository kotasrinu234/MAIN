<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:dp="http://www.datapower.com/extensions" 
xmlns:dpconfig="http://www.datapower.com/param/config"
extension-element-prefixes="dp dpconfig"
exclude-result-prefixes="dp dpconfig">
	<xsl:param name="dpconfig:ppsAppBindDN" select="''"/>
	<xsl:param name="dpconfig:ppsAppTargetBaseDN" select="''"/>
	<xsl:param name="dpconfig:crmAppBindDN" select="''"/>
	<xsl:param name="dpconfig:crmAppTargetBaseDN" select="''"/>
	<xsl:param name="dpconfig:tlabAppBindDN" select="''"/>
	<xsl:param name="dpconfig:tlabAppTargetBaseDN" select="''"/>
	<xsl:param name="dpconfig:atlasAppBindDN" select="''"/>
	<xsl:param name="dpconfig:atlasAppTargetBaseDN" select="''"/>
	<xsl:param name="dpconfig:compassAppBindDN" select="''"/>
	<xsl:param name="dpconfig:compassAppTargetBaseDN" select="''"/>
	<xsl:variable name="ppsAppBindDN" select="$dpconfig:ppsAppBindDN"/>
	<xsl:variable name="ppsAppTargetBaseDN" select="$dpconfig:ppsAppTargetBaseDN"/>
	<xsl:variable name="crmAppBindDN" select="$dpconfig:crmAppBindDN"/>
	<xsl:variable name="crmAppTargetBaseDN" select="$dpconfig:crmAppTargetBaseDN"/> 
	<xsl:variable name="tlabAppBindDN" select="$dpconfig:tlabAppBindDN"/>
	<xsl:variable name="tlabAppTargetBaseDN" select="$dpconfig:tlabAppTargetBaseDN"/>
	<xsl:variable name="atlasAppBindDN" select="$dpconfig:atlasAppBindDN"/>
	<xsl:variable name="atlasAppTargetBaseDN" select="$dpconfig:atlasAppTargetBaseDN"/>
	<xsl:variable name="compassAppBindDN" select="$dpconfig:compassAppBindDN"/>
	<xsl:variable name="compassAppTargetBaseDN" select="$dpconfig:compassAppTargetBaseDN"/>
	<xsl:template match="/">
		<xsl:variable name="encodedCredential" select="dp:http-request-header('Authorization')"/>
		<xsl:variable name="uname" select="normalize-space(substring-before(dp:decode(substring($encodedCredential,'7'),'base-64'),':'))"/>
		<xsl:variable name="bindPWD" select="normalize-space(substring-after(dp:decode(substring($encodedCredential,'7'),'base-64'),':'))"/>
		<dp:set-variable name="'var://context/current/bindPWD'" value="$bindPWD" />
		<dp:set-variable name="'var://context/current/user'" value="$uname" />
		<xsl:choose>
			<xsl:when test="($uname='dcas-wismo-esb-dev') or ($uname='dcas-wismo-esb-test') or ($uname='dcas-wismo-esb-prod')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$ppsAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$ppsAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='dcas-crb-esb-oms-dev') or ($uname='dcas-crb-esb-oms-tst') or ($uname='dcas-crb-esb-oms-prd')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$crmAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$crmAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='tlab-esb-oms-dev') or ($uname='tlab-esb-oms-test')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$tlabAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$tlabAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='atlas-esb-dev') or ($uname='atlas-esb-test')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$atlasAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$atlasAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:when test="($uname='dcas-oms-esb-ami-dev') or ($uname='dcas-oms-esb-ami-tst') or ($uname='dcas-oms-esb-ami-prd')">
				<dp:set-variable name="'var://context/current/bindDN'" value="$compassAppBindDN" />
				<dp:set-variable name="'var://context/current/targetBaseDN'" value="$compassAppTargetBaseDN" />
				<dp:set-variable name="'var://context/current/validUser'" value="'true'" />
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/current/validUser'" value="'false'" />
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="dp:variable('var://context/current/validUser')='true'">
				<xsl:variable name="serverAddress" select="'corpad.dtenet.com'"/>
				<xsl:variable name="portNumber" select="'636'"/>
				<xsl:variable name="bindDN" select="dp:variable('var://context/current/bindDN')"/>
				<xsl:variable name="bindPassword" select="$bindPWD"/>
				<xsl:variable name="targetBaseDN" select="dp:variable('var://context/current/targetBaseDN')"/>
				<xsl:variable name="attributeName" select="'sAMAccountName,member'"/>
				<xsl:variable name="filter" select="'(|(objectClass=group))'"/>
				<xsl:variable name="sslProxyProfile" select="'client:omsapi_AD_AAA_Client_Profile'"/>
				<xsl:variable name="ldapLBGroup" select="''"/>
				<xsl:variable name="ldapResults" select="dp:ldap-search($serverAddress, $portNumber, $bindDN, $bindPassword, $targetBaseDN, $attributeName, $filter, 'sub', $sslProxyProfile, $ldapLBGroup)"/>
				<dp:set-variable name="'var://context/current/ldapResults'" value="$ldapResults" />
				<!-- <xsl:copy-of select="$ldapResults" /> -->
				<xsl:choose>
					<xsl:when test="$ldapResults/LDAP-search-results/result" >
						<accepted />
					</xsl:when>
					<xsl:otherwise >
						<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Methods'"/>
						<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Headers'"/>
						<dp:set-variable name="'var://context/aaa/customErrorCode'" value="'401'"/>
						<dp:set-variable name="'var://context/aaa/customErrorMessage'" value="'Unauthorized'"/>
						<dp:set-variable name="'var://context/aaa/customReasonMessage'" value="'Unauthorized'"/>
						<dp:reject>Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : <xsl:value-of select="$uname"/> </dp:reject>
				        <dp:set-variable name="'var://context/ReporteTroubleOMS/omsresponse'" value="concat('Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : ', $uname)"/>
						<dp:set-variable name="'var://context/ReporteTroubleOMS/omsstatuscode'" value="'401'"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Methods'"/>
				<dp:set-http-response-header value="'*'" name="'Access-Control-Allow-Headers'"/>
				<dp:set-variable name="'var://context/aaa/customErrorCode'" value="'401'"/>
				<dp:set-variable name="'var://context/aaa/customErrorMessage'" value="'Unauthorized'"/>
				<dp:set-variable name="'var://context/aaa/customReasonMessage'" value="'Unauthorized'"/>
				<dp:reject>Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : <xsl:value-of select="$uname"/> </dp:reject>
				<dp:set-variable name="'var://context/ReporteTroubleOMS/omsresponse'" value="concat(' Error returned is 401 unauthorized with error message as : Rejected by Policy and username is : ', $uname)"/>
				<dp:set-variable name="'var://context/ReporteTroubleOMS/omsstatuscode'" value="'401'"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
