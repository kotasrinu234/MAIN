<xsl:stylesheet version="1.0"
	extension-element-prefixes="dp dpconfig"
	exclude-result-prefixes="dp soapenv"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:dpfunc="http://www.datapower.com/extensions/functions"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<xsl:include href="store:///utilities.xsl" />
	<xsl:output method="xml" omit-xml-declaration="yes" />
	<xsl:param name="dpconfig:CheckTroubleUrl" />
	<xsl:template match="/">
		<xsl:variable name="start-flower-bracket">
			<xsl:text>{</xsl:text>
		</xsl:variable>
		<xsl:variable name="bracket">
			<xsl:text>"</xsl:text>
		</xsl:variable>
		<xsl:variable name="end-flower-bracket">
			<xsl:text>}</xsl:text>
		</xsl:variable>
		<xsl:variable name="colon">
			<xsl:text>:</xsl:text>
		</xsl:variable>
		<xsl:variable name="comma">
			<xsl:text>,</xsl:text>
		</xsl:variable>
		<xsl:variable name="Id">
			<xsl:value-of
				select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Header']/*[local-name()='MessageID']" />
		</xsl:variable>
		<xsl:variable name="premiseId">
			<xsl:value-of
				select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='premiseId']" />
		</xsl:variable>
		<xsl:variable name="callType">
			<xsl:value-of
				select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode']" />
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="($callType != '' and $premiseId != '')">
				<xsl:variable name="callCheckRequest">
					<xsl:value-of select="$start-flower-bracket" />
					<!--forming the 1st string and value structure -->
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="'Id'" />
					<xsl:value-of select="$bracket" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$colon" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="$Id" />
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="$comma" />
					<!--forming the 2nd string and value structure -->
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="'premiseId'" />
					<xsl:value-of select="$bracket" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$colon" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="$premiseId" />
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="$comma" />
					<!--forming the 3rd string and value structure -->
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="'callType'" />
					<xsl:value-of select="$bracket" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$colon" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="$callType" />
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="$end-flower-bracket" />
				</xsl:variable>
				<xsl:message dp:type="all" dp:priority="debug">
					callCheckRequest:
					<xsl:value-of select="$callCheckRequest" />
				</xsl:message>
				<xsl:variable name="CheckTroubleURL">
					<xsl:value-of select="$dpconfig:CheckTroubleUrl" />
				</xsl:variable>
				<xsl:variable name="CheckTroubleResponse">
					<dp:url-open target="{$CheckTroubleURL}"
						response="responsecode-binary" http-method="post"
						content-type="application/json">
						<xsl:copy-of select="$callCheckRequest" />
					</dp:url-open>
				</xsl:variable>
				<dp:set-variable
					name="'var://context/callCheckResponse/CheckTroubleResponse'"
					value="$CheckTroubleResponse" />
				<xsl:choose>
					<xsl:when
						test="$CheckTroubleResponse/result/responsecode = '200'">
						<xsl:variable name="output">
							<xsl:value-of
								select="dp:decode(dp:binary-encode($CheckTroubleResponse/result/binary/node()),'base-64')" />
						</xsl:variable>
						<xsl:message dp:type="all" dp:priority="debug">
							Response Received form callCheckService is
							<xsl:copy-of select="$output" />
						</xsl:message>
						<dp:set-variable
							name="'var://context/callCheckResponse/Response'"
							value="normalize-space($output)" />
						<xsl:variable name="callId">
							<xsl:text>"callId":""</xsl:text>
						</xsl:variable>
						<xsl:choose>
							<xsl:when
								test="contains(dp:variable('var://context/callCheckResponse/Response'), $callId)">
								<dp:set-variable
									name="'var://context/error/customErrorMessage'"
									value="'CallId is null or undefined'" />
								<dp:reject>CallId is null or undefined</dp:reject>
							</xsl:when>
							<xsl:otherwise />
						</xsl:choose>
					</xsl:when>
					<xsl:otherwise>
						<!-- <xsl:message dp:type="all" dp:priority="error">Error invoking 
							call check service <xsl:copy-of select="$CheckTroubleResponse/result/errorstring/text()"/> 
							</xsl:message> -->
						<xsl:variable name="output">
							<xsl:value-of
								select="dp:decode(dp:binary-encode($CheckTroubleResponse/result/binary/node()),'base-64')" />
						</xsl:variable>
						<xsl:variable name="errorMessage"
							select="concat($CheckTroubleResponse/result/errorstatuscode ,$CheckTroubleResponse/result/errorstring, normalize-space($output))" />
						<xsl:variable name="errorURLMessage"
							select="concat($CheckTroubleResponse/result/responsecode ,$CheckTroubleResponse/result/reasonphrase, normalize-space($output))" />
						<xsl:message dp:type="all" dp:priority="error">
							trrpt_ReportTroubleOMS_002:
							<xsl:value-of select="normalize-space($output)" />
						</xsl:message>
						<dp:set-variable
							name="'var://context/error/output'"
							value="normalize-space($output)" />
						<!-- <dp:set-variable name="'var://context/error/customErrorMessage'" 
							value="normalize-space($output)"/> -->
						<dp:set-variable
							name="'var://service/error-message'"
							value="normalize-space($output)" />
						<dp:set-variable
							name="'var://context/error/error-message'"
							value="normalize-space($errorMessage)" />
						<dp:set-variable
							name="'var://context/error/errorURLMessage'"
							value="normalize-space($errorURLMessage)" />
						<dp:reject />
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<xsl:message>
					without premiseId
				</xsl:message>
				<!--<xsl:copy-of select="dp:variable('var://context/Input/TroubleRequest')"/> -->
				<xsl:variable name="callCheck">
					<xsl:value-of select="$start-flower-bracket" />
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="'action'" />
					<xsl:value-of select="$bracket" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$colon" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$bracket" />
					<xsl:text>NoPremiseID</xsl:text>
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="$comma" />
					<!--forming the 2nd string and value structure -->
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="'okToProceed'" />
					<xsl:value-of select="$bracket" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$colon" />
					<xsl:text></xsl:text>
					<xsl:value-of select="$bracket" />
					<xsl:text>true</xsl:text>
					<xsl:value-of select="$bracket" />
					<xsl:value-of select="$end-flower-bracket" />
				</xsl:variable>
				<dp:set-variable
					name="'var://context/callCheckResponse/Response'"
					value="normalize-space($callCheck)" />
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="not(string-length($premiseId) &gt; 0)">
				<xsl:if
					test="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']">
					<xsl:variable name="longitude">
						<xsl:value-of
							select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']/*[local-name()='longitude']" />
					</xsl:variable>
					<xsl:variable name="latitude">
						<xsl:value-of
							select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='location']/*[local-name()='latitude']" />
					</xsl:variable>
					<xsl:if test="($longitude != '' and $latitude != '')">
						<dp:set-variable
							name="'var://context/Trouble/longitude'"
							value="normalize-space($longitude)" />
						<dp:set-variable
							name="'var://context/Trouble/latitude'"
							value="normalize-space($latitude)" />
					</xsl:if>
				</xsl:if>
			</xsl:when>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
