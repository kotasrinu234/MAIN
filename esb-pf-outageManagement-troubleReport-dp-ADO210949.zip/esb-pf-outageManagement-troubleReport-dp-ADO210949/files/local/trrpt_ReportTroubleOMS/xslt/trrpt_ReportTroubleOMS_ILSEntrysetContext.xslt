<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:uuid="java:java.util.UUID" extension-element-prefixes="dp dpconfig" exclude-result-prefixes="dp da com max sr soapenv dpconfig">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" omit-xml-declaration="no"/>
	<xsl:strip-space elements="*"/>
	<xsl:param name="dpconfig:reportTroubleEntryDescription" select="''"/>
	<xsl:template match="/">
		<xsl:variable name="description">
			<xsl:value-of select="$dpconfig:reportTroubleEntryDescription"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/ilsEntry/description'" value="string($description)"/>
		<xsl:variable name="correlationID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Header']/*[local-name()='MessageID'])"/>
		<xsl:variable name="messageType" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Header']/*[local-name()='Verb'])"/>
		<xsl:variable name="channelID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='applicationId'])"/>
		<xsl:variable name="callCode" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleCode'])"/>
		<xsl:variable name="premiseID" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='premiseId'])"/>
		<xsl:variable name="callIDTBTFlag" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='TBTFlag'])"/>
		<xsl:variable name="callIDTBT" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='TBTOriginalCallNumber'])"/>
		<xsl:variable name="sourceEventTimestamp" select="string(/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='notificationTime'])"/>
		<xsl:variable name="crossStreet1" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet1']"/>
		<xsl:variable name="crossStreet2" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='troubleLocation']/*[local-name()='crossStreet2']"/>
		<xsl:variable name="contactPhone" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='contactInfo']/*[local-name()='contactPhone']"/>
		<xsl:variable name="remarks" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='remarks']"/>
		<xsl:variable name="attachments" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReportTrouble']/*[local-name()='Trouble']/*[local-name()='attachments']"/>
		<xsl:variable name="encodedCredential" select="dp:http-request-header('Authorization')"/>
		<xsl:variable name="uname" select="normalize-space(substring-before(dp:decode(substring($encodedCredential,'7'),'base-64'),':'))"/>
		<dp:set-variable name="'var://context/ilsEntry/userID'" value="string($uname)"/>
		<xsl:if test="string-length($attachments) &gt; 0">
			<dp:set-variable name="'var://context/ilsEntry/attachments'" value="string($attachments)"/>
		</xsl:if>
		<dp:set-variable name="'var://context/ilsEntry/remarks'" value="string($remarks)"/>
		<dp:set-variable name="'var://context/ilsEntry/contactPhone'" value="string($contactPhone)"/>
		<dp:set-variable name="'var://context/ilsEntry/crossStreet1'" value="string($crossStreet1)"/>
		<dp:set-variable name="'var://context/ilsEntry/crossStreet2'" value="string($crossStreet2)"/>
		<xsl:choose>
			<xsl:when test="$correlationID">
				<dp:set-variable name="'var://context/ilsEntry/CorrelationID'" value="$correlationID"/>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/ilsEntry/CorrelationID'" value="dp:variable('var://context/ILS/uniqueId')"/>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:if test="$messageType">
			<dp:set-variable name="'var://context/ilsEntry/messageType'" value="string($messageType)"/>
		</xsl:if>
		<xsl:if test="$channelID">
			<dp:set-variable name="'var://context/ilsEntry/channelID'" value="string($channelID)"/>
		</xsl:if>
		<xsl:if test="$callCode">
			<dp:set-variable name="'var://context/ilsEntry/callCode'" value="string($callCode)"/>
		</xsl:if>
		<xsl:if test="$premiseID">
			<dp:set-variable name="'var://context/ilsEntry/premiseID'" value="string($premiseID)"/>
		</xsl:if>
		<xsl:if test="$callIDTBT">
			<dp:set-variable name="'var://context/ilsEntry/callIDTBT'" value="string($callIDTBT)"/>
		</xsl:if>
		<xsl:if test="$callIDTBTFlag">
			<dp:set-variable name="'var://context/ilsEntry/callIDTBTFlag'" value="string($callIDTBTFlag)"/>
		</xsl:if>
		<xsl:if test="$sourceEventTimestamp">
			<dp:set-variable name="'var://context/ilsEntry/sourceEventTimestamp'" value="string($sourceEventTimestamp)"/>
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>
