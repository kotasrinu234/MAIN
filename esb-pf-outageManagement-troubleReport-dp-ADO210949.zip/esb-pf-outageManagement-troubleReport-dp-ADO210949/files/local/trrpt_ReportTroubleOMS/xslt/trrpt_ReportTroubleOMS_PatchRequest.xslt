<xsl:stylesheet
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:dp="http://www.datapower.com/extensions"
xmlns:date="http://exslt.org/dates-and-times"
xmlns:dyn="http://exslt.org/dynamic"
xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
xmlns:dpconfig="http://www.datapower.com/param/config"
extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
<xsl:param name="dpconfig:omsExternalURL"/>
<xsl:param name="dpconfig:osiApiToken"/>
<xsl:template match="/">
<xsl:variable name="Actiondata">
	<xsl:value-of select="dp:variable('var://context/Trouble/action')"/>
</xsl:variable>
<xsl:if test="$Actiondata = 'CHG'">
	<xsl:variable name="id">
		<xsl:value-of select="dp:variable('var://context/callcodectx/callCodeIDdata_Id')"/>
	</xsl:variable>
	<xsl:variable name="callCodeIDdata">
		<xsl:value-of select="dp:variable('var://context/callcodectx/callCodeIDdata')"/>
	</xsl:variable>
	<xsl:variable name="OMSurl">
		<xsl:value-of select="concat($dpconfig:omsExternalURL,'/api/v1/ServiceType/Electric/Call/',$id)" />
	</xsl:variable>
	<xsl:variable name="httpHeaders"> <header name="Authorization"><xsl:copy-of select="concat('Basic ',$dpconfig:osiApiToken)"/></header> </xsl:variable>
		<xsl:message dp:type="all" dp:priority="debug">patchCallRequest: <xsl:value-of select="$callCodeIDdata"/> </xsl:message>
		<xsl:variable name="PatchCallResponse">
			<dp:url-open target="{$OMSurl}" response="responsecode-binary" http-method="patch" content-type="application/json" ssl-proxy="{trrpt_ReportTroubleOMS_ClientProfile}" http-headers="$httpHeaders">
				<xsl:copy-of select="$callCodeIDdata"/>
			</dp:url-open>
		</xsl:variable>

		  <xsl:message dp:type="all" dp:priority="debug">PatchCallResponse: <xsl:value-of select="$PatchCallResponse"/>error in connecting OMS service</xsl:message>
		<xsl:choose>
			<xsl:when test="$PatchCallResponse/result/responsecode = '200'">
				<xsl:variable name="output">
					<xsl:value-of select="dp:decode(dp:binary-encode($PatchCallResponse/result/binary/node()),'base-64')"/>
				</xsl:variable>
				<xsl:message dp:type="all" dp:priority="debug">Response Received form PatchCallService is
					<xsl:copy-of select="$output"/>
				</xsl:message>
					<dp:set-variable name="'var://context/PatchCallResponse/Response'" value="normalize-space($PatchCallResponse)" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">
					<xsl:copy-of select="$PatchCallResponse/result/errorstring/text()"/>
				</xsl:message>
				<dp:set-variable name="'var://context/error/customErrorMessage'" value="$PatchCallResponse/result/errorstring/text()"/>
				<dp:reject/>
			</xsl:otherwise>
		</xsl:choose>
</xsl:if>
</xsl:template>
</xsl:stylesheet>
