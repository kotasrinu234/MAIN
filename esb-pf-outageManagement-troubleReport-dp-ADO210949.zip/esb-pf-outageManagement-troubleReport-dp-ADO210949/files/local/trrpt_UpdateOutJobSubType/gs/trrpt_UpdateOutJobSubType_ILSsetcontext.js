var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
var entryDescription = session.parameters.entryDescription;
var exitSDescription = session.parameters.exitSDescription;
var exitDestination = session.parameters.omsExternalURL;
ctx.setVariable('exitDestination', exitDestination);
var messageType = session.parameters.messageType
ctx.setVariable("messageType", messageType)
ctx.setVariable('entryDescription', entryDescription);
ctx.setVariable('exitDescription', exitSDescription);
function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
var uuid = uuidv4();
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (incomingdata.messageID !== undefined || incomingdata.messageID !== null || incomingdata.messageID !== '') {
			ctx.setVariable("correlationID", incomingdata.messageID);
		}
		else{
			ctx.setVariable("correlationID", uuid);
		}
		if (incomingdata.callIdNew !== undefined || incomingdata.callIdNew !== null || incomingdata.callIdNew !== '') {
			ctx.setVariable("callID", incomingdata.callIdNew);
		}
		if (incomingdata.outageSubtypeID !== undefined || incomingdata.outageSubtypeID !== null || incomingdata.outageSubtypeID !== '') {
			ctx.setVariable("jobSubType", incomingdata.outageSubtypeID)
		}
		if (incomingdata.timestamp !== undefined || incomingdata.timestamp !== null || incomingdata.timestamp !== '') {
			ctx.setVariable("sourceEventTimestamp", incomingdata.timestamp)
		}
	}
});
