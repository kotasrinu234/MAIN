var sm = require('service-metadata');
session.input.readAsBuffer(function(error, buffer) {
	if (error) {
		session.reject("Unexpected error in readAsJSON(): " + error);
		return;
	} else {
		var ilsctx = session.name('ILS') || session.createContext('ILS');
		var errorDescription = ilsctx.getVar("errorDescription");
		if (errorDescription) {
			ilsctx.setVariable('errormessage', errorDescription );
		} else {
			var message = sm.getVar('var://service/error-message')
			ilsctx.setVariable('errormessage', message);
		}
	}

});
