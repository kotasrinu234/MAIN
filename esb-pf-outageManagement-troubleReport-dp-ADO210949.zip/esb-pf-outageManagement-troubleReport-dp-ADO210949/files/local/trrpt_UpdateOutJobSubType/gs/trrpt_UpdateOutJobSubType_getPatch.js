
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var apiToken = session.parameters.apiToken;
var ctx = session.name("UpdateOutJobSubType") || session.createContext("UpdateOutJobSubType");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var exitFDescription = session.parameters.exitFDescription;
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var optionsCall = {
			target: session.parameters.omsExternalURL + '/api/ServiceType/Electric/Call/' + incomingdata.callIdNew + '?includeFields=jobID,jobDisplayID',
			method: "GET",
			headers: {
				"osiApiToken": apiToken
			},
			contentType: "application/json",
			sslClientProfile: "trrpt_ReportTroubleOMS_ClientProfile"
		};
		session.output.write(incomingdata);
		var getCallInfo = " TargetURL :" + optionsCall.target + "; Method :" + optionsCall.method + ". ";
		try {
			urlopen.open(optionsCall, function(error, response) {
				if (error) {
					var errorinfo = "trrpt_UpdateOutJobSubType_001 : urlopen connect error with get call api , details are : " + getCallInfo + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatus", "500");
					logger.error("trrpt_UpdateOutJobSubType_001 : urlopen connect error with get call api " + JSON.stringify(error));
					session.reject("trrpt_UpdateOutJobSubType_001 : urlopen connect error with get call api " + JSON.stringify(error));
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure reading response from get call api , details are : " + getCallInfo + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", "500");
								logger.error("failure reading response from get call api " + JSON.stringify(error));
								session.reject("failure reading response from get call api " + JSON.stringify(error));
							} else {
								var payload = {
									"outageSubtypeID": incomingdata.outageSubtypeID
								}
								if (responseData) {
									if (responseData.jobID) {
										var jobID = responseData.jobID;
										if (jobID === null || jobID === undefined || jobID === '') {
											var errorinfo = "trrpt_UpdateOutJobSubType_003 : JobID not found";
											ilsctx.setVariable("exitDescription", errorinfo);
											ilsctx.setVariable("exitStatus", '500');
											var ErrorTxt = ("trrpt_UpdateOutJobSubType_003 : JobID not found");
											ctx.setVariable("ErrorTxt", ErrorTxt);
											ctx.setVar("retry", "yes");
											logger.error("trrpt_UpdateOutJobSubType_003 : JobID not found");
											ctx.setVariable('exitDescription', exitFDescription);
										}
										else {
											var CallPATCHapi = {
												target: session.parameters.omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + jobID,
												sslClientProfile: 'trrpt_ReportTroubleOMS_ClientProfile',
												method: 'PATCH',
												contentType: 'application/json',
												headers: {
													'osiApiToken': apiToken
												},
												data: payload
											};
											session.output.write(payload);
											var patchCallInfo = " TargetURL :" + CallPATCHapi.target + "; Method :" + CallPATCHapi.method + "; Data :" + JSON.stringify(CallPATCHapi.data) + ". ";
											try {
												urlopen.open(CallPATCHapi, function(error, response) {
													if (error) {
														var errorinfo = "trrpt_UpdateOutJobSubType_002 : urlopen connect error with patch call api , details are : " + patchCallInfo + "; error info :" + error;
														ilsctx.setVariable("errorDescription", errorinfo);
														ilsctx.setVariable("errorStatus", "500");
														logger.error("trrpt_UpdateOutJobSubType_002 : urlopen connect error with patch call api" + JSON.stringify(error));
														session.reject("trrpt_UpdateOutJobSubType_002 : Error invoking patch call api" + JSON.stringify(error));
													} else {
														var responseStatusCode = response.statusCode;
														if (responseStatusCode == 200) {
															response.readAsJSON(function(error, responseData) {
																if (error) {
																	// error while reading response or transferring data to Buffer
																	var errorinfo = " failure reading response from patch call api , details are : " + patchCallInfo + "; error info :" + error;
																	ilsctx.setVariable("errorDescription", errorinfo);
																	ilsctx.setVariable("errorStatus", "500");
																	logger.error(" failure reading response from patch call api " + JSON.stringify(error));
																	session.reject(" failure reading response from patch call api " + JSON.stringify(error));
																} else {
																	logger.info(responseData);
																	ilsctx.setVariable("exitStatus", '0');
																}
															});
														} else if (responseStatusCode == 400) {
															response.readAsBuffer(function(error, responseData) {
																if (responseData == 'No updates') {
																	ilsctx.setVariable("exitStatus", '0');
																}
																else {
																	if (error) {
																		var errorinfo = "Failure in reading the message , details are : " + patchCallInfo + "; error info :" + error;
																		ilsctx.setVariable("errorDescription", errorinfo);
																		ilsctx.setVariable("errorStatus", "500");
																		logger.error("Failure in reading the message" + JSON.stringify(error));
																		session.reject("Failure in reading the message" + JSON.stringify(error));
																	} else {
																		var errorinfo = "trrpt_UpdateOutJobSubType_004 : Error received in reading response data , details are : " + patchCallInfo + "; errorresponseinfo :" + responseData + " responseStatusCode :" + responseStatusCode;
																		ilsctx.setVariable("exitDescription", errorinfo);
																		ilsctx.setVariable("exitStatus", responseStatusCode);
																		var ErrorTxt = ("trrpt_UpdateOutJobSubType_004 : error response from get call api with response code is " + responseStatusCode + " and the reason is " + responseData);
																		ctx.setVariable("ErrorTxt", ErrorTxt);
																		ctx.setVar("retry", "yes");
																		logger.error("Error received in reading response data " + responseStatusCode + responseData);
																		//session.reject("Error received in reading response data " + responseStatusCode + responseData);

																	}
																}
															});

														} else {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "Failure in reading the message , details are : " + patchCallInfo + "; error info :" + error;
																	ilsctx.setVariable("errorDescription", errorinfo);
																	ilsctx.setVariable("errorStatus", "500");
																	logger.error("Failure in reading the message" + JSON.stringify(error));
																	session.reject("Failure in reading the message" + JSON.stringify(error));
																} else {
																	var errorinfo = "trrpt_UpdateOutJobSubType_004 : Error received in reading response data , details are : " + patchCallInfo + "; errorresponseinfo :" + responseData + " responseStatusCode :" + responseStatusCode;
																	ilsctx.setVariable("exitDescription", errorinfo);
																	ilsctx.setVariable("exitStatus", responseStatusCode);
																	var ErrorTxt = ("trrpt_UpdateOutJobSubType_004 : error response from get call api with response code is " + responseStatusCode + " and the reason is " + responseData);
																	ctx.setVariable("ErrorTxt", ErrorTxt);
																	ctx.setVar("retry", "yes");
																	logger.error("Error received in reading response data " + responseStatusCode + responseData);
																	//session.reject("Error received in reading response data " + responseStatusCode + responseData);

																}
															});
														}
													}
												});
											}
											catch (error) {
												var errorinfo = "trrpt_UpdateOutJobSubType_002 : urlopen connect error with patch call api , details are : " + patchCallInfo + "; error info :" + error;
												ilsctx.setVariable("errorDescription", errorinfo);
												ilsctx.setVariable("errorStatus", "500");
												logger.error("trrpt_UpdateOutJobSubType_002 : urlopen connect error with patch call api" + JSON.stringify(error));
												session.reject("trrpt_UpdateOutJobSubType_002 : Error invoking patch call api" + JSON.stringify(error));
											}
										}
									}
									else {
										var errorinfo = "trrpt_UpdateOutJobSubType_003 : JobID not found";
										ilsctx.setVariable("exitDescription", errorinfo);
										ilsctx.setVariable("exitStatus", '500');
										var ErrorTxt = ("trrpt_UpdateOutJobSubType_003 : JobID not found");
										ctx.setVariable("ErrorTxt", ErrorTxt);
										ctx.setVar("retry", "yes");
										logger.error("JobID not found");
										ctx.setVariable('exitDescription', exitFDescription);
									}
								}
							}
						});
					}
					else if (responseStatusCode == 404) {
						response.readAsBuffer(function(error, ErrorresponseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure reading response from get call api , details are : " + getCallInfo + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", "404");
								logger.error("failure reading response from get call api" + JSON.stringify(error));
								session.reject("failure reading response from get call api" + JSON.stringify(error));
							} else {
								hm.response.statusCode = response.statusCode;
								var errorinfo = "trrpt_UpdateOutJobSubType_003 : error response from get call api with response code is " + responseStatusCode + "  , details are : " + getCallInfo + "; error info :" + error;
								ilsctx.setVariable("exitDescription", errorinfo);
								ilsctx.setVariable("exitStatus", responseStatusCode);
								var ErrorTxt = ("trrpt_UpdateOutJobSubType_003 : error response from get call api with response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								ctx.setVariable("ErrorTxt", ErrorTxt);
								ctx.setVar("retry", "yes");
								ctx.setVariable('exitDescription', exitFDescription);
								logger.error("error response from get call api with response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								//session.reject("error response from patch call api with response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
							}
						});
					}
					else {
						response.readAsBuffer(function(error, ErrorresponseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure in reading message  , details are : " + getCallInfo + "; error info :" + error;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", "500");
								logger.error("failure reading response from get call api" + JSON.stringify(error));
								session.reject("failure reading response from get call api" + JSON.stringify(error));
							} else {
								var errorinfo = "trrpt_UpdateOutJobSubType_003 : error response from get call api with response code is " + responseStatusCode + " , details are : " + getCallInfo + "; errorresponseinfo :" + ErrorresponseData;
								ilsctx.setVariable("errorDescription", errorinfo);
								ilsctx.setVariable("errorStatus", responseStatusCode);
								logger.error("trrpt_UpdateOutJobSubType_003 : error response from get call api with response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
								session.reject("trrpt_UpdateOutJobSubType_003 : error response from patch call api with response code is " + responseStatusCode + " and the reason is " + ErrorresponseData);
							}
						});
					}
				}
			});
		}
		catch (error) {
			var errorinfo = "trrpt_UpdateOutJobSubType_001 : urlopen connect error with get call api , details are : " + getCallInfo + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("trrpt_UpdateOutJobSubType_001 : urlopen connect error with get call api " + JSON.stringify(error));
			session.reject("trrpt_UpdateOutJobSubType_001 : urlopen connect error with get call api " + JSON.stringify(error));
		}
	}
});
