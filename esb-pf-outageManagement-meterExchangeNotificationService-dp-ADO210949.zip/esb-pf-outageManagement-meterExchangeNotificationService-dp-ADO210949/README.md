# esb-pf-outageManagement-meterExchangeNotificationService-dp
interface 4b meterExchange
Deployment instructions:

#IIBMQ scripts are uploaded in dteenergy/esb-pf-outageManagement-meterExchangeNotificationService-mq repository.

MQCSP details will be given by DTE ESB team.

Password aliases will be created by DTE ESB team.

Private keys and certs need to be provided by DTE ESB team.

Properties file as per env are in the config folder of this repository.

Jenkins file as per env are also uploaded in this repository.
