<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

		<xsl:variable name="TransactionID">
			<xsl:copy-of
				select="dp:variable('var://service/global-transaction-id')" />

		</xsl:variable>
		
		<xsl:variable name="transerrorcode">
			<xsl:copy-of
				select="dp:variable('var://context/mens/troubleResponseErrorcode')" />

		</xsl:variable>
		<xsl:variable name="transerrormessage">
			<xsl:copy-of
				select="dp:variable('var://context/mens/troubleResponseErrormessage')" />

		</xsl:variable>

		<xsl:if
			test="string-length(normalize-space($transerrorcode))&gt; 0">
			<dp:set-variable
				name="'var://service/error-protocol-response'"
				value="$transerrorcode" />
		</xsl:if>
		<xsl:variable name="customererrorcode">
			<xsl:choose>
				<xsl:when
					test="string-length(normalize-space($transerrorcode))&gt; 0">
					<xsl:value-of select="$transerrorcode"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of
						select="dp:variable('var://service/error-code')" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:if test="string-length(normalize-space($transerrormessage))&gt; 0">
		<dp:set-variable
				name="'var://service/error-message'"
				value="$transerrormessage" />
		</xsl:if>
		<xsl:if test="contains(dp:variable('var://service/error-message'), 'Invalid object syntax') or contains(dp:variable('var://service/error-message'), 'Invalid object syntax
') or contains(dp:variable('var://service/error-message'), 'Invalid JSON syntax')">
		<dp:set-variable
				name="'var://service/error-protocol-response'"
				value="'400'" />
		<xsl:message> <xsl:value-of select="dp:variable('var://service/error-message')"/>  </xsl:message>

<xsl:message dp:type="all" dp:priority="error">mens_CreateTrouble_007 <xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>		
		</xsl:if>		
		
		<dp:set-variable name="'var://context/mens/customererrorcode'" value="$customererrorcode" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
	</xsl:template>
</xsl:stylesheet>
