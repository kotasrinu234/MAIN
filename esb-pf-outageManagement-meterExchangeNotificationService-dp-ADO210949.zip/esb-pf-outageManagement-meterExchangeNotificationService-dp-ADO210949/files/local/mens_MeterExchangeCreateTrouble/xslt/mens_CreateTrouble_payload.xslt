<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:dyn="http://exslt.org/dynamic" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:param name="dpconfig:troubleCode" select="''"/>
	<xsl:param name="dpconfig:applicationId" select="''"/>
	<xsl:variable name="troubleCode" select="$dpconfig:troubleCode"/>
	<xsl:variable name="applicationId" select="$dpconfig:applicationId"/>
	<xsl:template match="/">
		<xsl:variable name="correlationID" select="dp:variable('var://context/mens/correlationID')"/>
		<xsl:variable name="premiseId">
			<xsl:copy-of select="dp:variable('var://context/mens/premiseID')"/>
		</xsl:variable>
		<xsl:variable name="externalId">
			<xsl:value-of select="dp:variable('var://context/mens/externalID')"/>
		</xsl:variable>
		<xsl:variable name="exchange_meter_in">
			<xsl:value-of select="dp:variable('var://context/mens/exchange_meter_in')"/>
		</xsl:variable>
		<xsl:variable name="exchange_meter_out">
			<xsl:value-of select="dp:variable('var://context/mens/exchange_meter_out')"/>
		</xsl:variable>
		<xsl:variable name="Exchange_Meter_Out_Reading">
			<xsl:value-of select="dp:variable('var://context/mens/Exchange_Meter_Out_Reading')"/>
		</xsl:variable>
		<xsl:variable name="Jsonx_Message">
			<!-- <?xml version="1.0" encoding="UTF-8"?> -->
			<soapenv:Envelope xmlns:v11="http://esm.dteco.com/common/v1" xmlns:v1="http://outagemanagement.esm.dteco.com/trouble/v1" xmlns:rep="http://trouble.outagemanagement.esm.dteco.com/v1/report" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dp="http://www.datapower.com/schemas/management" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
				<soapenv:Header/>
				<soapenv:Body>
					<v1:ReportTrouble>
						<v11:Header>
							<v11:Verb>create</v11:Verb>
							<v11:Noun>Trouble</v11:Noun>
							<v11:Source>Field App</v11:Source>
							<v11:Timestamp>
								<xsl:value-of select="date:date-time()"/>
							</v11:Timestamp>
							<v11:MessageID>
								<xsl:value-of select="$correlationID"/>
							</v11:MessageID>
						</v11:Header>
						<rep:Trouble>
							<rep:applicationId>
								<xsl:value-of select="$applicationId"/>
							</rep:applicationId>
							<rep:troubleCode>
								<xsl:value-of select="$troubleCode"/>
							</rep:troubleCode>
							<rep:notificationTime>
								<xsl:value-of select="date:date-time()"/>
							</rep:notificationTime>
							<rep:remarks>
								<xsl:value-of select=" concat('Meter Exchange Initiated by crew ',$externalId,
													' Meter In: ',$exchange_meter_in,
    												' Meter Out: ',$exchange_meter_out,
    												' Meter Reading ',$Exchange_Meter_Out_Reading)"/>
							</rep:remarks>
							<rep:troubleLocation>
								<rep:premiseId>
									<xsl:value-of select="$premiseId"/>
								</rep:premiseId>
							</rep:troubleLocation>
						</rep:Trouble>
					</v1:ReportTrouble>
				</soapenv:Body>
			</soapenv:Envelope>
		</xsl:variable>
		<xsl:copy-of select="$Jsonx_Message"/>
	</xsl:template>
</xsl:stylesheet>