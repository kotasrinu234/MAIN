<!-- XSLT is used to invoke CALL api and do a get the api response -->
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"


	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:template match="/">
	<dp:set-variable name="'var://context/mens/RestorationStatusID'" value="string(//*[local-name()='id'])"/>
	<dp:set-variable name="'var://context/mens/ResponsejobId'" value="string(//*[local-name()='insvcJobId'])"/>	
	<xsl:variable name="code">
	<xsl:value-of select="string(//*[local-name()='code'])"/>
	</xsl:variable>
		<xsl:variable name="errormessage">
	<xsl:value-of select="string(//*[local-name()='details'])"/>
	</xsl:variable>
	<xsl:if test="string-length(normalize-space($code))&gt; 0">
	<dp:set-variable
	name="'var://context/mens/troubleResponseErrorcode'" value="normalize-space($code)" />
	<dp:set-variable	name="'var://context/mens/troubleResponseErrormessage'" value="normalize-space($errormessage)" />
	<dp:reject>error return from trouble report is <xsl:value-of select ="$errormessage"/></dp:reject>
	</xsl:if>
	</xsl:template>
</xsl:stylesheet>
	