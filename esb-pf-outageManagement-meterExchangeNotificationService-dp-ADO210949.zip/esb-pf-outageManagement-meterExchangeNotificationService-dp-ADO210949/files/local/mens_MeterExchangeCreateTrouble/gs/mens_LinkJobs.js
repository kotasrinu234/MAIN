var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	var ctx = session.name("mens") || session.createContext("mens");
	session.output.write(incomingdata);
	var omsExternalURL = session.parameters.omsExternalURL;
	var RestorationStatusID = ctx.getVar("RestorationStatusID");
	var apiToken = session.parameters.osiApiToken;
	var linksExists = '';
	linksExists = ctx.getVariable('linksExists')
	var jobid = ctx.getVar("jobID");
	var linksExists = ctx.getVariable('linksExists')
	if (linksExists !== 'yes') {
		var lookupUrl = session.parameters.lookupUrl
		var LinksLookupPayload = {
			"lookupReq": {
				"type": [
					{
						"name": "linkTypes",
						"label": "DTE - Associated"
					}
				]
			}
		};
		var LinksLookup = {
			target: lookupUrl,
			method: 'POST',
			contentType: 'application/json',
			data: LinksLookupPayload
		};
		var info = " TargetURL: " + LinksLookup.target + "; Method: " + LinksLookup.method + "; Data: " + JSON.stringify(LinksLookup.data) + ". ";
		try {
			urlopen.open(LinksLookup, function(error, response) {
				if (error) {
					var errorinfo = " url connection error 'LinksLookup', details are : " + info + "; error info :" + error
					logger.error(errorinfo);
					ctx.setVariable("troubleResponseErrorcode", '500')
					ctx.setVariable("var://service/error-message", errorinfo)
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'LinksLookup', details are :" + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
								logger.error(errorinfo);
								ctx.setVariable("troubleResponseErrorcode", '500')
								ctx.setVariable("var://service/error-message",  errorinfo)
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = '200 OK';
								logger.debug("response received :" + JSON.stringify(responseData));
								if (responseData.lookupRep.type[0].result == 1) {
									var invalidresp = "Invalid Lookup Request 'LinksLookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									logger.error(invalidresp);
									session.reject(invalidresp)
								} else {
									var LinksPatchURL = omsExternalURL + '/api/ServiceType/Electric/Job/' + jobid + '/LinkJobs'
									var LinksPatchPayload = {
										"addLinks": [{
											"linkedID": RestorationStatusID,
											"linkTypeID": responseData.lookupRep.type[0].id
										}]
									};

									var LinksPatch = {
										target: LinksPatchURL,
										sslClientProfile: 'omsapi_client_profile',
										method: 'PATCH',
										contentType: 'application/json',
										data: LinksPatchPayload,
										headers: {
											'osiApiToken': apiToken
										}
									};
									var info = " TargetURL :" + LinksPatch.target + "; Method :" + LinksPatch.method + "; Data :" + JSON.stringify(LinksPatch.data) + ". ";
									urlopen.open(LinksPatch, function(error, response) {
										if (error) {
											var errorinfo = " url connection error 'LinksPatch', details are : " + info + "; error info :" + error
											logger.error('mens_CreateTrouble_004 '+errorinfo);
											var ErrorTxt = errorinfo;
											ctx.setVariable("ErrorTxt", ErrorTxt);
											ctx.setVariable("troubleResponseErrorcode", '500')
											ctx.setVariable("var://service/error-message", errorinfo)
											session.reject(errorinfo)
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'MeterUpdates', details are : " + info + "; error info :" + error
														logger.error(errorinfo);
														ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
														ctx.setVariable("var://service/error-message", errorinfo)
														session.reject(errorinfo);
													} else {
														var buff = Buffer.from(responseData)
														var ResponseString = buff.toString();
														ctx.setVariable("respo", ResponseString)
														if (responseStatusCode == 200 || (ResponseString === "No updates")) {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response received :" + JSON.stringify(responseData));
														} else {
															var errorinfo = " error response 'JobIdUpdates', details are : " + info + "; response info :" + ResponseString + "; ResponseStatusCode :" + responseStatusCode
															logger.error(errorinfo);
															session.reject(errorinfo)
														}
													}
												})
											} else if (responseStatusCode == 500) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'MeterUpdates', details are : " + info + "; error info :" + error
														logger.error(errorinfo);
														ctx.setVariable("troubleResponseErrorcode", '500')
														ctx.setVariable("var://service/error-message", errorinfo)
														session.reject(errorinfo);
													} else {
														var errorinfo = " error response 'MeterUpdates', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														hm.current.statusCode = responseStatusCode;
														logger.error(errorinfo);
														var ErrorTxt = errorinfo
														ctx.setVariable("ErrorTxt", ErrorTxt);
														session.reject(errorinfo)
													}
												});
											} else {
												var errorinfo = " error response 'JobIdUpdates', details are : " + info + "; ResponseStatusCode :" + responseStatusCode
												logger.error(errorinfo);
												ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
												session.reject(errorinfo)
											}
										}
									})
								}
							}
						})
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure reading the error response 'CauseCodeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
								logger.error(errorinfo);
								ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
								ctx.setVariable("var://service/error-message", errorinfo)
								session.reject(errorinfo);
							} else {
								var errorinfo = "error response 'CauseCodeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
								hm.current.statusCode = responseStatusCode;
								logger.error(errorinfo);
								ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
								session.reject(errorinfo);
							}
						});
					}


				}
			})

		} catch (error) {
			logger.error(error);
			ctx.setVariable("troubleResponseErrorcode", '500')
			ctx.setVariable("var://service/error-message", error)

			session.reject(error);

		}

	}

})
