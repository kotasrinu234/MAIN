var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("mens") || session.createContext("mens");
	session.output.write(incomingdata);
	var omsExternalURL = session.parameters.omsExternalURL;
	var RestorationStatusID = ctx.getVar("RestorationStatusID");
	var apiToken = session.parameters.osiApiToken;
	var linksExists = '';
	linksExists = ctx.getVariable('linksExists')
	var jobid = ctx.getVar("jobID");
	var JobIDGUIDUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + RestorationStatusID + '?includeFields=status,jobTypeID';
	var GetCallResponseData = {
		target: JobIDGUIDUrl,
		sslClientProfile: 'omsapi_client_profile',
		method: 'GET',
		contentType: 'application/json',
		headers: {
			'osiApiToken': apiToken
		}
	};
	var info = " TargetURL :" + GetCallResponseData.target + "; Method :" + GetCallResponseData.method + ". ";
	urlopen.open(GetCallResponseData, function(error, response) {
		if (error) {
			var errorinfo = " url connection error 'JobCompletion Get Call', details are : " + info + "; error info :" + error
			logger.error('mens_CreateTrouble_002 '+errorinfo);
			ctx.setVariable("troubleResponseErrorcode", '500')
			session.reject(errorinfo)
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode === 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response 'JobCompletion', details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
						session.reject(errorinfo);
					} else {
						hm.response.statusCode = '200 OK';
						logger.debug("response received from Get Call Response Data :" + responseData);
						ctx.setVariable("ResponseData", responseData)
						var lookupUrl = session.parameters.lookupUrl;
						var jobTypeID = responseData.jobTypeID;
						var status = responseData.status;
						var outageTypeLookup = {
							"lookupReq": {
								"type": [{
									"name": "jobTypes.workflows",
									"id": jobTypeID,
									"label": "Completed"
								}]
							}
						}
						var outageTypeLookupPost = {
							target: lookupUrl,
							method: 'POST',
							contentType: 'application/json',
							data: outageTypeLookup
						}
						var info = " TargetURL :" + outageTypeLookupPost.target + "; Method :" + outageTypeLookupPost.method + "; Data :" + JSON.stringify(outageTypeLookupPost.data) + ". ";
						urlopen.open(outageTypeLookupPost, function(error, response) {
							if (error) {
								TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
								var errorinfo = " url connection error 'JobCompletion', details are : " + info + "; error info :" + error
								logger.error(errorinfo);
								ctx.setVariable("troubleResponseErrorcode", '500')
								session.reject(errorinfo);
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsJSON(function(error, responseData) {
										if (error) {
											TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
											var errorinfo = "error reading response 'JobCompletion', details are : " + info + "; error info :" + error
											logger.error(errorinfo);
											ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
											session.reject(errorinfo);
										} else {
											hm.response.statusCode = '200 OK';
											logger.debug("response received from outage Type Lookup Post :" + JSON.stringify(responseData));
											ctx.setVariable("Response", responseData)
											if (responseData.lookupRep.type[0].result == 1) {
												TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
												var invalidresp = "Invalid Lookup Request of outageTypeLookupPost 'JobCompletion', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												logger.error(invalidresp)
												session.reject(invalidresp)
											} else {
												var Respstatus = responseData.lookupRep.type[0].status;
												ctx.setVariable("RespStatus", Respstatus)
												if (Respstatus !== status) {
													var RespStatusUrl = omsExternalURL + '/api/v1/ServiceType/Electric/Job/' + RestorationStatusID + '/WorkFlow';

													var RespStatusPayloadPost = {
														target: RespStatusUrl,
														sslClientProfile: 'omsapi_client_profile',
														method: 'POST',
														contentType: 'application/json',
														data: Respstatus,
														headers: {
															'osiApiToken': apiToken
														}
													};
													var info = " TargetURL :" + RespStatusPayloadPost.target + "; Method :" + RespStatusPayloadPost.method + "; Data :" + JSON.stringify(RespStatusPayloadPost.data) + ". ";

													urlopen.open(RespStatusPayloadPost, function(error, response) {
														if (error) {
															var errorinfo = " url connection error 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
															logger.error('mens_CreateTrouble_003 '+errorinfo);
															ctx.setVariable("troubleResponseErrorcode", '500')
															var ErrorTxt = errorinfo;
															ctx.setVariable("ErrorTxt", ErrorTxt);
														} else {
															var responseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																response.readAsJSON(function(error, responseData) {
																	if (error) {
																		TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																		var errorinfo = "error reading response 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		response.readAsJSON(function(error, responseData) {
																			if (error) {
																				var errorinfo = "error reading response 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				hm.response.statusCode = '200 OK';
																				logger.debug("response received from RespStatus Payload Post  :" + JSON.stringify(responseData));
																				ctx.setVariable("JobCompleted", 'yes')
																			}
																		});
																	}
																})
															} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
																response.readAsBuffer(function(error, BusinessResponseData) {
																	if (error) {
																		var errorinfo = "error reading response 'StatusUpdate', details are : " + info + "; error info :" + error
																		logger.error(errorinfo);
																		ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
																		session.reject(errorinfo);
																	} else {
																		//business error change 1
																		var BusinessResponseData = BusinessResponseData;
																		var buff = Buffer.from(BusinessResponseData);
																		var ResponseString = buff.toString();
																		ctx.setVariable("respo", ResponseString)
																		if (!(ResponseString === "No updates")) {
																			var errorinfo = "error response 'JobCompletionStatus BusinessError', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
																			ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
																			logger.error(errorinfo);
																			ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
																			session.reject(errorinfo);
																		}
																	}

																});
															} else {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = " error response 'RespStatusPayloadPost', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		responseData = responseData.toString()
																		if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
																			var ErrorTxt = "TaskUpdate_CrtJob10 : error response 'RespStatusPayloadPost', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
																		} else {
																			var ErrorTxt = errorinfo
																		}
																		hm.current.statusCode = responseStatusCode;
																		ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
																		logger.error(errorinfo);
																		session.reject("Error returned from RespStatus Payload Post  " + ": with statusCode " + responseStatusCode + " " + responseData);
																	}
																});
															}
														}
													})
												}
												ctx.setVariable('JobCompleted', 'yes')
											}
										}
									})
								}
							}
						})
					}
				})
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response 'JobCompletion GetCallResponseData', details are : " + info + "; error info :" + error
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", '500')
						session.reject(errorinfo);
					} else {
						var errorinfo = " error response 'JobCompletion GetCallResponseData', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						responseData = responseData.toString()
						if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
							var ErrorTxt = "TaskUpdate_CrtJob11 : error response 'JobCompletion GetCallResponseData', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
						} else {
							var ErrorTxt = errorinfo
						}
						hm.current.statusCode = responseStatusCode;
						ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
						logger.error(errorinfo);
						session.reject(errorinfo)
					}
				});
			}
		}
	})
})
