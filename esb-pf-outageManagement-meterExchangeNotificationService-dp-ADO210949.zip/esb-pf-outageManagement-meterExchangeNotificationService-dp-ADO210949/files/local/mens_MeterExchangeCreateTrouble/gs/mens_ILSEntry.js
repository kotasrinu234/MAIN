var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("mens") || session.createContext("mens");
var logger = console.options({
	'category': 'all'
});
function uuidv4() { return 'xxaxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
ctx.setVariable("correlationID", uuidv4());
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var jobID = '';
	if (incomingdata.data[0].job.calls[0] !== undefined) {
		if (incomingdata.data[0].job.calls[0].premiseID !== undefined) { } else {
			ctx.setVariable("troubleResponseErrorcode", '400')
			session.reject("premiseID is not present incoming request payload")
		}
	} else {
		ctx.setVariable("troubleResponseErrorcode", '400')
		session.reject("premiseID is not present incoming request payload")
	}
	if (incomingdata.data[0].job !== undefined) {
		if (incomingdata.data[0].job.id !== undefined) {
			jobID = incomingdata.data[0].job.id;
			ctx.setVariable("jobID", jobID);
		} else {
			session.reject("job.id is not present in incoming payload");
			ctx.setVariable("troubleResponseErrorcode", '400')
		}
		if (incomingdata.data[0].job.customFieldValuesExt !== undefined) {
			if (incomingdata.data[0].job.customFieldValuesExt.Exchange_Meter_Out_Reading !== undefined) {
				ctx.setVariable("Exchange_Meter_Out_Reading", incomingdata.data[0].job.customFieldValuesExt.Exchange_Meter_Out_Reading);
			}
		}

	} else {
		session.reject("job block is not present in incoming request payload")
		ctx.setVariable("troubleResponseErrorcode", '400')

	}
	var userID = ' '

	if (incomingdata.data[0].createdByUserName !== undefined) {
		userID = incomingdata.data[0].createdByUserName;
		ctx.setVariable("userID", userID)
	}

	var sourceEventTimestamp = ''
	if (incomingdata.data[0].updatedAt !== undefined) {
		sourceEventTimestamp = incomingdata.data[0].updatedAt;
		ctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
	}
	var messageType =

		ctx.setVariable("TroubleCreated", session.parameters.exitDescription);
	ctx.setVariable("description", session.parameters.entryDescription);
	ctx.setVariable("messageType", session.parameters.messageType);
	var externalID = '';
	if (incomingdata.data[0].crew !== undefined) {
		if (incomingdata.data[0].crew.externalID !== undefined) {
			externalID = incomingdata.data[0].crew.externalID;
			ctx.setVariable("externalID", externalID);
		}
	}
	if (incomingdata.data[0].customFieldValuesExt !== undefined) {
		if (incomingdata.data[0].customFieldValuesExt.exchange_meter_in !== undefined) {
			ctx.setVariable("exchange_meter_in", incomingdata.data[0].customFieldValuesExt.exchange_meter_in);
		}
		var exchange_meter_out = '';
		if (incomingdata.data[0].customFieldValuesExt.exchange_meter_out !== undefined) {
			exchange_meter_out = incomingdata.data[0].customFieldValuesExt.exchange_meter_out
			ctx.setVariable("exchange_meter_out", exchange_meter_out);
		}
	}

})
