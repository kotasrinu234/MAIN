var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsBuffer(function(readAsJSONError, incomingdata) {
	var ctx = session.name("mens") || session.createContext("mens");
	var omsExternalURL = session.parameters.omsExternalURL;
	var apiToken = session.parameters.osiApiToken;
	var RestorationStatusID = ctx.getVar("RestorationStatusID");
	var exchange_meter_in = ctx.getVar("exchange_meter_in");
	var exchange_meter_out = ctx.getVar("exchange_meter_out");
	var Exchange_Meter_Out_Reading = ctx.getVar("Exchange_Meter_Out_Reading");
	///api/ServiceType/Electric/Job/{<RestorationStatus><id>}
	var JobPatchUri = omsExternalURL + '/api/ServiceType/Electric/Job/' + RestorationStatusID;
		session.output.write("{}");

	var RestorationStatusPayload = { "customFieldValues": {} }
	if (exchange_meter_in != undefined) { RestorationStatusPayload.customFieldValues.Exchange_Meter_In = exchange_meter_in }
	if (exchange_meter_out != undefined) { RestorationStatusPayload.customFieldValues.Exchange_Meter_Out = exchange_meter_out }
	if (Exchange_Meter_Out_Reading != undefined) { RestorationStatusPayload.customFieldValues.Exchange_Meter_Out_Reading = Exchange_Meter_Out_Reading }
	var jobApi = {
		target: JobPatchUri,
		method: 'PATCH',
		sslClientProfile: 'OMS_Client_Profile',
		headers: {
			'osiApiToken': apiToken
		},
		contentType: 'application/json',
		data: RestorationStatusPayload
	};
	var info = " TargetURL :" + jobApi.target + "; Method :" + jobApi.method + ". ";
	// Make the patch request
	urlopen.open(jobApi, function(error, response) {
		if (error) {
			var errorinfo = " url open connect error for OMS jobApi request, details are: " + info + JSON.stringify(error)
			logger.error('mens_CreateTrouble_001 '+ errorinfo);
			ctx.setVariable("troubleResponseErrorcode", '500')
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200 || responseStatusCode == 400 || responseStatusCode == 404) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Failure in reading message from OMS jobApi request, details are: " + info + JSON.stringify(error)
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", '500')
						session.reject(errorinfo);
					} else {
						var buff = Buffer.from(responseData)
						var ResponseString = buff.toString();
						ctx.setVariable("respo", ResponseString)
						var jobid = ctx.getVar("jobID");
						if (responseStatusCode == 200 || (ResponseString === "No updates")) {
							var GetLinksDataURL = omsExternalURL + '/api/ServiceType/Electric/Job/' + jobid; +'includeFields=links'
							var GetLinksData = {
								target: GetLinksDataURL,
								sslClientProfile: 'omsapi_client_profile',
								method: 'GET',
								contentType: 'application/json',
								headers: {
									'osiApiToken': apiToken
								}
							};
							var info = " TargetURL :" + GetLinksData.target + "; Method :" + GetLinksData.method + "; Data :" + ". ";

							urlopen.open(GetLinksData, function(error, response) {
								if (error) {
									var errorinfo = " url connection error 'Get Links Data', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									ctx.setVariable("troubleResponseErrorcode", '500')
									session.reject(errorinfo)
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'Get Links Data', details are : " + info + "; error info :" + error
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												ctx.setVariable("GetLinksData", responseData)
												if (responseData.links === null || responseData.links === undefined || responseData.links === '' || responseData.links[0] === undefined) {
													ctx.setVariable("addLinks", 'yes')
												} else {
													for (var i = 0; i < responseData.links.length; i++) {
														if ((responseData.links[i].linkedID === undefined || responseData.links[i].linkedID === null || responseData.links[i].linkedID === '')) {
															ctx.setVariable("addLinks", 'yes')
														} else {
															if (responseData.links[i].linkedID === RestorationStatusID) {
																ctx.setVariable("linksExists", 'yes')
															} else {
																ctx.setVariable("addLinks", 'yes')
															}

														}
													}
												}
											}
										})
									} else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'Get Links Data', details are : " + info + "; error info :" + error
												logger.error(errorinfo);
												ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
												session.reject(errorinfo);
											} else {
												var errorinfo = " error response 'Get Links Data', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												responseData = responseData.toString()
												if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
													var ErrorTxt = " error response 'Get Links Data', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
												} else {
													var ErrorTxt = errorinfo
												}
												hm.current.statusCode = responseStatusCode;
												logger.error(errorinfo);
												ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
												session.reject(errorinfo)
											}
										});
									}
								}
							}
							)
						} else {
							var errorinfo = " error response 'JobIdUpdates', details are : " + info + "; response info :" + ResponseString + "; ResponseStatusCode :" + responseStatusCode
							logger.error(errorinfo);
							ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
							session.reject(errorinfo)
						}
					}
				});
			} else {
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						var errorinfo = "Error reading response from OMS jobApi request, details are: " + info + JSON.stringify(readError);
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response from OMS jobApi request, details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
						session.reject(errorinfo);
					}
				});
			}
		}
	})

})
