var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("mens") || session.createContext("mens");
	session.output.write(incomingdata);
	var omsExternalURL = session.parameters.omsExternalURL;
	var apiToken = session.parameters.osiApiToken;
	var premiseID = incomingdata.data[0].job.calls[0].premiseID;
	var PremiseApiUri = omsExternalURL + '/api/Premise/' + premiseID + '?includeFields=externalID';
	var PremiseApi = {
		target: PremiseApiUri,
		method: 'GET',
		sslClientProfile: 'OMS_Client_Profile',
		headers: {
			'osiApiToken': apiToken
		},
		contentType: 'application/json'
	};
	var info = " TargetURL :" + PremiseApi.target + "; Method :" + PremiseApi.method + ". ";
	// Make the GET request
	urlopen.open(PremiseApi, function(error, response) {
		if (error) {
			var errorinfo = " url open connect error for OMS PremiseApi request, details are: " + info + JSON.stringify(error)
			logger.error('mens_CreateTrouble_005 ' + errorinfo);
			ctx.setVariable("troubleResponseErrorcode", '500')
			session.reject(errorinfo);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "Failure in reading message from OMS PremiseApi request, details are: " + info + JSON.stringify(error)
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", '500')
						session.reject(errorinfo);
					} else {
						// Success: Write the response data (Job details)
						logger.debug("Job details received: " + JSON.stringify(responseData));
						ctx.setVariable("premiseID", responseData.externalID);
					}
				});
			} else if (responseStatusCode == 401) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "Error reading response from OMS PremiseApi request, details are: " + info + JSON.stringify(error);
						logger.error('mens_CreateTrouble_006 ' + errorinfo);
						ctx.setVariable("troubleResponseErrorcode", '401')
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response from OMS PremiseApi request, details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
						ctx.setVariable("troubleResponseErrorcode", '401')
						logger.error('mens_CreateTrouble_006 ' + errorinfo)					
						session.reject(errorinfo);
					}
				});
			} else if (responseStatusCode == 400) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "Error reading response from OMS PremiseApi request, details are: " + info + JSON.stringify(error);
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", '400')
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response from OMS PremiseApi request, details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;

						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				});
			} else {
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						var errorinfo = "Error reading response from OMS PremiseApi request, details are: " + info + JSON.stringify(readError);
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
						session.reject(errorinfo);
					} else {
						var errorinfo = "Error response from OMS PremiseApi request, details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
						logger.error(errorinfo);
						ctx.setVariable("troubleResponseErrorcode", responseStatusCode)
						session.reject(errorinfo);
					}
				});
			}
		}
	})

})
