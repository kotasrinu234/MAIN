var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('ILS') || session.createContext('ILS');
function uuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var myuuid = uuidv4();
		var correlationID = myuuid;
		var entryDescription = session.parameters.EntryDescription;
		var exitDescription = session.parameters.ExitDescription;
		var messageType = session.parameters.messageType;
		var premiseID = incomingdata.data[0].leadCall.externalPremiseID;
		var jobID = incomingdata.data[0].id;
		var userID = incomingdata.data[0].createdByUserName;
		var sourceEventTimestamp = incomingdata.data[0].updatedAt;
		var sourceUrl = sm.getVar('var://service/URL-in');
		var payload = incomingdata;
		payload.messageID = myuuid
		ctx.setVariable('payload', payload)
		session.output.write(payload)
		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ctx.setVariable('correlationID', " ");
		} else {
			ctx.setVariable('correlationID', correlationID);
		}
		if (messageType !== undefined || messageType !== null || messageType !== '') {
			ctx.setVariable("messageType", messageType);
		}
		if (entryDescription !== undefined || entryDescription !== null || entryDescription !== '') {
			ctx.setVariable('entryDescription', entryDescription);
		}
		if (exitDescription !== undefined || exitDescription !== null || exitDescription !== '') {
			ctx.setVariable('exitDescription', exitDescription);
		}
		if (premiseID === null || premiseID === '' || premiseID === undefined) {
			ctx.setVariable("premiseID", '');
		}
		else {
			ctx.setVariable("premiseID", premiseID);
		}
		if (jobID === null || jobID === '' || jobID === undefined) {
			ctx.setVariable("jobID", '');
		}
		else {
			ctx.setVariable("jobID", jobID);
		}
		if (userID === null || userID === '' || userID === undefined) {
			ctx.setVariable("userID", '');
		}
		else {
			ctx.setVariable("userID", userID);
		}
		if (sourceEventTimestamp === null || sourceEventTimestamp === '' || sourceEventTimestamp === undefined) {
			ctx.setVariable("sourceEventTimestamp", '');
		}
		else {
			ctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		if (sourceUrl === null || sourceUrl === '' || sourceUrl === undefined) {
			ctx.setVariable("sourceUrl", '');
		}
		else {
			ctx.setVariable("sourceUrl", sourceUrl);
		}
	}
});
