<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<xsl:output method="xml" encoding="utf-8" indent="yes" />
	<xsl:template match="/">
		                <dp:remove-http-response-header name="MQMD"/>
<dp:set-http-response-header
				name="'Content-Type'" value="'application/json'" />
		
	</xsl:template>
</xsl:stylesheet>