var logger = console.options({ 'category': 'all' });
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('GLN') || session.createContext('GLN');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data as JSON:" + readAsJSONError
		logger.error(errorinfo);
		ILSctx.setVariable("exitStatus", "500")
		ILSctx.setVariable("exitDescription", errorinfo)
		session.reject(errorinfo)
	} else {
		ILSctx.setVariable("correlationID", incomingdata.messageID)
		ILSctx.setVariable("exitDestination", session.parameters.exitDestination)
		ILSctx.setVariable("sourceEventTimestamp", incomingdata.currentTimeStamp)
		var gln = incomingdata.gln;

		// Check if gln is undefined, null, or an empty string
		if (gln === undefined || gln === null || gln === '') {
			var errorinfo = "glnv_001: GLN is not present in input payload ";
			ctx.setVariable("glnNotPresent", true)
			ctx.setVariable("invalidGLNMsg", "GLN is not present in input payload" )
		} else {
			ILSctx.setVariable("GLN", gln)
			if (gln.length < 7) {
				var errorinfo = "Invalid GLN ";
				ctx.setVariable("invalidGLN", true);
				ctx.setVariable("invalidGLNMsg","Invalid GLN ")
			} else {
				ILSctx.setVariable("GLN", gln)
				ILSctx.setVariable("glny", gln.slice(-6))
				ILSctx.setVariable("glnx", gln.slice(0, -6))
				ctx.setVariable("glny", gln.slice(-6));
				ctx.setVariable("glnx", gln.slice(0, -6));
			}
		}

	}
});
