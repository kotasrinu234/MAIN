var hm = require('header-metadata');
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('GLN') || session.createContext('GLN');
var sm = require('service-metadata');
var errorCode = sm.getVar('var://service/error-code');
var errorMessage = sm.getVar('var://service/error-message')
var logger = console.options({
	'category': 'all'
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data as JSON: " + readAsJSONError
		logger.error(errorinfo);
		logger.error("glnv_009 invalid JSON message")
		ILSctx.setVariable("exitStatus", "500")
		ILSctx.setVariable("exitDescription", errorinfo)
		var obj = {};
		obj.errorMessage = errorinfo
		obj.errorCode = 500
		session.output.write(obj);
	} else {
		// block to handle AAA failure
		if (errorMessage === "Rejected by policy.") {
			var WSM = session.name("WSM") || session.createContext("WSM");
			var value = WSM.getVar('identity/username');
			var errorinfo = `glnv_008: AAA failure for GLN with, Username: ${value}, Errorstring: ${errorCode}, errorMessage: ${errorMessage}`;
			ILSctx.setVariable("exitDescription", errorinfo);//errorDescription
			ILSctx.setVariable("exitStatus", 401)

			var obj = {}
			obj.statusCode = '401'
			obj.errorMessage = "Unauthorized"
			session.output.write(obj)
			logger.error(errorinfo);
		}
		else {
			// block to handle 400, 498, and 499
			var LogILSError = ctx.getVariable("logerror")
			if (LogILSError === true) {
				var errorStatus = ctx.getVariable("errorcode")
				var errormsg = ctx.getVariable("errorMsg")
				var errorpayload = ctx.getVariable("errorpayload")
				ILSctx.setVariable("exitDescription", errormsg);
				ILSctx.setVariable("exitStatus", errorStatus)
				session.output.write(errorpayload)
			}
			else {
				var glnNotPresent = ctx.getVariable("glnNotPresent")
				var inValidGln = ctx.getVariable("invalidGLN")
				if (glnNotPresent === true) {
					ILSctx.setVariable("exitStatus", '400');
					ILSctx.setVariable("exitDescription", "GLN is not present in input payload");
					hm.current.statusCode = 400;
					var obj = {};
					obj.errorMessage = ctx.getVariable("invalidGLNMsg")
					obj.errorCode = 400
					session.output.write(obj);
				} else if (inValidGln === true) {
				 ILSctx.setVariable("exitStatus", '400');
					ILSctx.setVariable("exitDescription", "Invalid Gln");
					hm.current.statusCode = 400;
					var obj = {};
					obj.errorMessage = ctx.getVariable("invalidGLNMsg")
					obj.errorCode = 400
					session.output.write(obj);
				} else {
					ILSctx.setVariable("exitDescription", errorMessage);
					ILSctx.setVariable("errorStatus", 500);
					session.output.write(incomingdata);
				}
			}
		}
	}
})
