var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
sm.setVar("var://service/mpgw/skip-backside", true)
var logger = console.options({ 'category': 'all' });
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name('GLN') || session.createContext('GLN');
var description = session.parameters.Exitdescription;
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data as JSON:" + readAsJSONError
		logger.error(errorinfo);
		ILSctx.setVariable("exitStatus", "500")
		ILSctx.setVariable("exitDescription", errorinfo)
		session.reject(errorinfo);
	} else {
		ctx.setVariable("tokenResponse", incomingdata.token);
		var tokenResponse = incomingdata.token;
		var TokenAPIPayload = ctx.getVariable("TokenAPIPayload");
		var gln = TokenAPIPayload.gln;
		var messageID = TokenAPIPayload.messageID;

		var glny = ctx.getVariable("glny");
		var glnx = ctx.getVariable("glnx");

		var Url = session.parameters.POSTCallURL;
		var query_url = Url+
			"where=GLNX+%3D+" + glnx + "+and+GLNY+%3D+" + glny + "+and+ISODIRECTION+is+null&" +
			"text=&objectIds=&time=&geometry=&" +
			"geometryType=esriGeometryEnvelope&inSR=&" +
			"spatialRel=esriSpatialRelIntersects&distance=&" +
			"units=esriSRUnit_Foot&relationParam=&outFields=" +
			"OBJECTID%2C+GLNX%2C+GLNY&returnGeometry=false&returnTrueCurves=false&" +
			"maxAllowableOffset=&geometryPrecision=&outSR=&" +
			"havingClause=&returnIdsOnly=false&returnCountOnly=false&" +
			"orderByFields=&groupByFieldsForStatistics=&outStatistics=&" +
			"returnZ=false&returnM=false&gdbVersion=&historicMoment=&" +
			"returnDistinctValues=false&resultOffset=&resultRecordCount=&" +
			"returnExtentOnly=false&datumTransformation=&parameterValues=&" +
			"rangeValues=&quantizationParameters=&featureEncoding=esriDefault&" +
			"f=json&token=" + tokenResponse

		var validationApi = {
			target: query_url,
			sslClientProfile: 'OMS_Client_Profile',
			method: 'POST',
			contentType: 'application/json',
			data: TokenAPIPayload
		};

		ctx.setVariable("validationApiPayload", validationApi.data);
		var info = " TargetURL :" + validationApi.target + "; Method :" + validationApi.method + "; Data :" + JSON.stringify(validationApi.data) + ". ";


		urlopen.open(validationApi, function(error, response) {
			if (error) {
				var errorinfo = "glnv_005: urlopen connect error while doing validationApi call, details are : " + info + "; error info :" + error
				ILSctx.setVariable('exitDescription', errorinfo);
				ILSctx.setVariable('exitStatus', "500");
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200 || responseStatusCode == 201 || responseStatusCode == 202) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "glnv_006: failure in reading message from validationApi call, details are : " + info + "; error info :" + error
							ILSctx.setVariable('exitDescription', errorinfo);
							ILSctx.setVariable('exitStatus', responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							ILSctx.setVariable('exitStatus', 0);
							ctx.setVariable("responseData", responseData);
							ILSctx.setVariable('exitDescription', session.parameters.Entrydescription);
							if (responseData.error) {
								ctx.setVariable("logerror", true);
								ctx.setVariable("errorcode", responseData.error.code);
								if (responseData.error.code === 499 || responseData.error.code === 498) {
									var errorMsg = responseData.error.message;
									ctx.setVariable("errorMsg", errorMsg);
									logger.error(errorMsg);
									ctx.setVariable("errorpayload", responseData);
									session.reject(errorMsg);
								}
								else if (responseData.error.code === 400) {
									var errorMsg = responseData.error.message;
									ctx.setVariable("errorMsg", errorMsg);
									logger.error(errorMsg);
									ctx.setVariable("errorpayload", responseData);
									session.reject(errorMsg);
								}
							}
							else {
								if (responseData.features && responseData.features.length > 0) {
									logger.debug("GLN is valid");
									var Payload = {
										"messageID": messageID,
										"gln": gln,
										"status": "VALID"
									}
									var status = Payload.status;
									ILSctx.setVariable('exitStatus', status);
									session.output.write(Payload);
									ILSctx.setVariable('exitDescription', description);
								} else {
									logger.debug("GLN is Invalid");
									var Payload = {
										"messageID": messageID,
										"gln": gln,
										"status": "INVALID"
									}

									var status = Payload.status;
									ILSctx.setVariable('exitStatus', status);
									session.output.write(Payload);
									ILSctx.setVariable('exitDescription', description);
								}
							}
						}
					})
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						var responseStatusCode = response.statusCode;
						if (error) {
							var errorinfo = "glnv_007: failure in reading message from validationApi , details are : " + info + "; error info :" + error;
							ILSctx.setVariable('exitDescription', errorinfo);
							ILSctx.setVariable('exitStatus', responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "glnv_007: Error returned from validationApi with statusCode " + responseStatusCode + " , details are : " + info + "; errorresponse :" + responseData;
							ILSctx.setVariable('exitDescription', errorinfo);
							ILSctx.setVariable('exitStatus', responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		})
	}
});
