var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
sm.setVar("var://service/mpgw/skip-backside", true)
var logger = console.options({ 'category': 'all' });
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("GLN") || session.createContext("GLN");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data as JSON:" + readAsJSONError
		logger.error(errorinfo);
		ILSctx.setVariable("exitStatus", "500")
		ILSctx.setVariable("exitDescription", errorinfo)
	} else {
		var invalidGLN = ctx.getVariable("invalidGLN")
		var glnNotPresent = ctx.getVariable("glnNotPresent")
		if (invalidGLN === true || glnNotPresent === true) {
			session.reject("Invalid GLN request ")
		} else {
			var GetUrl = session.parameters.GetTokenUrl;
			var Url = session.parameters.exitDestination 
			var GetTokenUsername= session.parameters.GetTokenUsername
			var GetTokenPassword= session.parameters.GetTokenPassword
			var TokenUrl = GetUrl+'?request=gettoken&username='+GetTokenUsername+'&password='+GetTokenPassword+'&f=pjson&client=requestip&encrypted=false';
			var TokenApi = {
				target: TokenUrl,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'POST',
				contentType: 'application/json',
				data: incomingdata
			};
			ILSctx.setVariable("exitDestination", Url)
			ctx.setVariable("TokenAPIPayload", TokenApi.data);

			var info = " TargetURL :" + Url + "; Method :" + TokenApi.method + "; Data :" + JSON.stringify(TokenApi.data) + ". ";
			urlopen.open(TokenApi, function(error, response) {
				if (error) {
					var errorinfo = "glnv_002: urlopen connect error while doing TokenApi call, details are : " + info
					ILSctx.setVariable('exitDescription', errorinfo);
					ILSctx.setVariable('exitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "glnv_003: failure in reading message from TokenApi call, details are : " + info 
							ILSctx.setVariable('exitDescription', errorinfo);
								ILSctx.setVariable('exitStatus', responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
							else {
								ctx.setVariable("responseData", responseData);
							 if(!(responseData.error== null ||responseData.error== undefined ))
						{
							
							var response ='glnv_004 '+JSON.stringify(responseData)
							if(!(responseData.error.code == undefined)){
							ILSctx.setVariable('exitStatus', responseData.error.code);	
							}
							session.reject(response)
							
						}else{
							ILSctx.setVariable('exitDescription', session.parameters.StepExitdescription);
								ILSctx.setVariable('exitStatus', responseStatusCode);
								session.output.write(responseData)
							}
						}

						})
					}
					else {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "glnv_004: failure in reading message from TokenApi call, details are : " + info 
								ILSctx.setVariable('exitDescription', errorinfo);
								ILSctx.setVariable('exitStatus', responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
							else {
								var errorinfo = "glnv_004: failure in reading message from TokenApi call, details are : " + info
								ILSctx.setVariable('exitDescription', errorinfo);
								ILSctx.setVariable('exitStatus', responseStatusCode);
								session.output.write(responseData)
								logger.error(errorinfo);
								session.reject(responseData);
							}
						})
					}
				}
			})
		}
	}
});
