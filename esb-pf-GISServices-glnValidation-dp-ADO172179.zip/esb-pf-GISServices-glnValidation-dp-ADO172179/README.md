# esb-pf-GISServices-glnValidation-dp
Global Location Number Validation
