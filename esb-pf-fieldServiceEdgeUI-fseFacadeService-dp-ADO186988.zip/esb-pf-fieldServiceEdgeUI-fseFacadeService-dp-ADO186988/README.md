# esb-pf-fieldServiceEdgeUI-fseFacadeService-dp

Interface 60 Deployment Instructions

1) Export the below objects from FieldServiceEdgeUIINT domain.
   MultiProtocolGateway Services
   
   
       a) ffs_ConvertTime
       b) ffs_ReceiveRequest
       c) ffs_SendResponse
    
    TLS client Profile
    
    
        a) ffs_ReceiveRequest_TLS_Client Profile
        b) FSE_Client_Profile
        
 2) Add below two extra lines to the "baseffsDeploymentPolicyRequest.xml" file
 
       <!-- start -->
          <ModifiedConfig>
            <Match>*/*/xml/aaapolicy?Name=ffs_ReceiveRequest_AAA&amp;Property=Authorize/AZLDAPGroup&amp;Value=.*</Match>
            <Type>change</Type>
            <Property/>
            <Value>@ffs_ReceiveRequest_AAA.aaa.auth.LDAP.GroupDN@</Value>
        </ModifiedConfig>	
        <ModifiedConfig>
            <Match>*/*/xml/aaapolicy?Name=ffs_ReceiveRequest_AAA&amp;Property=Authorize/AZLDAPBindDN&amp;Value=.*</Match>
            <Type>change</Type>
            <Property/>
            <Value>@ffs_ReceiveRequest_AAA.aaa.auth.LDAP.BindDN@</Value>
        </ModifiedConfig>
          
          <!--End  -->
   3) Add below two lines to the propertie files for DEV,INT,ST,Load,ACC,Prod. (Values may change according to the environment)
     
           ffs_ReceiveRequest_AAA.aaa.auth.LDAP.BindDN=CN=fse-esb-oms-dev,OU=Service,OU=Restricted Accounts,DC=dtenet,DC=com
           ffs_ReceiveRequest_AAA.aaa.auth.LDAP.Group=CN=FseOms-Users-dev,OU=PF,OU=ESB,OU=DCA,OU=DTE Groups,DC=dtenet,DC=com
           
