<xsl:stylesheet version="1.0" exclude-result-prefixes="dp  get ns0 v1 " extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:ns1="http://www.multispeak.org/Version_4.1_Release" xmlns:mustUnderstand="http://www.w3.org/2003/05/soap-envelope" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="2.0" encoding="UTF-8" indent="yes"/>
	<xsl:strip-space elements="*"/>
	
	<xsl:param name="dpconfig:entryDescription"/>
	<xsl:param name="dpconfig:exitDescription"/>
	<xsl:param name="dpconfig:exitDestination"/>
	<xsl:param name="dpconfig:messageType"/>
	<xsl:template match="/">
		<xsl:variable name="meterID" select="/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'MeterID']]"/>
		<xsl:variable name = "Timestamp" select ="/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'Timestamp']]" />
		
		<xsl:variable name = "TimeModified" select ="/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'TimeModified']]" />
		
		<dp:set-variable name="'var://context/ILS/MeterID'" value="$meterID"/>
		<dp:set-variable name="'var://context/ILS/Timestamp'" value="$Timestamp"/>
		<dp:set-variable name="'var://context/ILS/TimeModified'" value="$TimeModified"/>
		<dp:set-variable name="'var://context/ILS/correlationID'" value="concat('FSE-',$TimeModified)"/>
		<dp:set-variable name="'var://context/ILS/entryDescription'" value="$dpconfig:entryDescription"/>
		<dp:set-variable name="'var://context/ILS/exitDescription'" value="$dpconfig:exitDescription"/>
		<dp:set-variable name="'var://context/ILS/exitDestination'" value="$dpconfig:exitDestination"/>
		<dp:set-variable name="'var://context/ILS/messageType'" value="$dpconfig:messageType"/>
		
		<xsl:choose>
		<xsl:when test ='$TimeModified' >
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$TimeModified"/>
		</xsl:when>
		<xsl:otherwise>
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$Timestamp"/>
		</xsl:otherwise>
	
		</xsl:choose>
		
				
	</xsl:template>
</xsl:stylesheet>