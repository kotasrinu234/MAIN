<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1" extension-element-prefixes="dp" xmlns:dp="http://www.datapower.com/extensions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dpconfig="http://www.datapower.com/param/config">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="no"/>
	<xsl:strip-space elements="*"/>
	<xsl:param name="dpconfig:meterReadMqUrl"/>
	<xsl:template match="/">
		<xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
		<xsl:variable name="dpErrorMessage" select="dp:variable('var://service/error-message')"/>
		<xsl:variable name="errsubcode" select="dp:variable('var://service/error-subcode')"/>
		<dp:set-variable name="'var://context/ILS/errsubcode'" value="$errsubcode"/>
		<xsl:variable name="customErrorCode" select="dp:variable('var://context/error/customErrorCode')"/>
		<xsl:variable name="customErrorMessage" select="dp:variable('var://context/error/customErrorMessage')"/>
		<xsl:choose>
			<xsl:when test="$errsubcode ='0x01d30002'">
				<dp:set-variable name="'var://context/ILS/errorCode'" value="'401'"/>
			</xsl:when>
			<xsl:when test="$errsubcode ='0x00d30003'">
				<dp:set-variable name="'var://context/ILS/errorCode'" value="'500'"/>
			</xsl:when>
			<xsl:otherwise/>
		</xsl:choose>
		<xsl:variable name="errCode" select="dp:variable('var://context/ILS/errorCode')"/>
		<dp:set-variable name="'var://context/ILS/errCode'" value="$errCode"/>
		<xsl:variable name="url">
			<xsl:value-of select="$dpconfig:meterReadMqUrl"/>
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
				<xsl:message dp:type="all" dp:priority="error">fse_SVR_02 AAA failure for user name : <xsl:value-of select="dp:variable('var://context/WSM/identity/username')"/> with Status code 401 unauthorized with ,TransactionID : <xsl:value-of select="dp:variable('var://service/transaction-id')"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
				</xsl:message>
				<dp:set-variable name="'var://context/ILS/errorCode'" value="'401'"/>
				<dp:set-variable name="'var://context/ILS/statusDetail'" value="concat('fse_SVR_02  AAA failure for user name : ', dp:variable('var://context/WSM/identity/username'),' with Status code 401 unauthorized with ,TransactionID :  ', dp:variable('var://service/transaction-id'),'  ErrorMessage : ',dp:variable('var://service/error-message'))"/>
				<dp:set-variable name="'var://service/error-protocol-response'" value="'401'"/>
				<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'"/>
			</xsl:when>
			<xsl:when test="$customErrorCode and $customErrorCode !=''">
				<xsl:message dp:type="all" dp:priority="error">id=fse_SVR_01|ErrorCode:<xsl:value-of select="$customErrorCode"/> ErrorMessage: <xsl:value-of select="concat('transactionID:',$transactionID,',',$customErrorMessage)"/>
				</xsl:message>
				<dp:set-variable name="'var://context/ILS/statusDetail'" value="concat('errorMessage-',' ',$errCode,' ',$customErrorMessage)"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:message dp:type="all" dp:priority="error">id=fse_SVR_01|ErrorCode:<xsl:value-of select="$systemErrorCode"/> ErrorMessage: <xsl:value-of select="concat('transactionID:',$transactionID,',',$dpErrorMessage)"/>
				</xsl:message>
				<dp:set-variable name="'var://context/ILS/statusDetail'" value="concat('id=fse_SVR_01 errorCode - ', $errCode,' errorDescription : ', $dpErrorMessage,' url : ',$url)"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
