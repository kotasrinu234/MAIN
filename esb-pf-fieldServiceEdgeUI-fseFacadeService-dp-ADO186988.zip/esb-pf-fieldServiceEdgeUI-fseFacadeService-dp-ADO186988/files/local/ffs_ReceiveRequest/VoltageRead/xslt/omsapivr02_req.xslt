<xsl:stylesheet version="1.0" exclude-result-prefixes="dp  get ns0 v1 " extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:ns1="http://www.multispeak.org/Version_4.1_Release" xmlns:mustUnderstand="http://www.w3.org/2003/05/soap-envelope" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="2.0" encoding="UTF-8" indent="yes"/>
	<xsl:strip-space elements="*"/>
	<xsl:param name="dpconfig:meterReadMqUrl"/>
	<xsl:param name="dpconfig:meterReadReplyToQ"/>
		<xsl:param name="dpconfig:efoMeterReadReplyToQ"/>

	
	<xsl:template match="/">
		<xsl:variable name="meterID" select="/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'MeterID']]"/>
		<xsl:variable name = "Timestamp" select ="/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'Timestamp']]" />
		
		<xsl:variable name = "TimeModified" select ="/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'TimeModified']]" />
		

		
		
		<!--  <dp:set-http-request-header name="'SOAPAction'"               value="$environmentSpecificProperties/EnvironmentSpecific/OMSSOAPAction/text()"/>
      <dp:remove-http-request-header name="MQMD"/> -->
		<xsl:variable name="Payload">
			<soap:Envelope>
				<soapenv:Header>
					<ns1:MultiSpeakMsgHeader mustUnderstand:mustUnderstand="false" MajorVersion="4" MinorVersion="1" Build="3" BuildString="Release" UserID="" Pwd="" Company="ESB"/>
				</soapenv:Header>
				<soap:Body>
					<ns1:InitiateMeterReadingsByMeterID>
						<ns1:meterIDs>
							<ns1:meterID>
								<xsl:attribute name="meterNo">
									<xsl:value-of select="$meterID"/>
								</xsl:attribute>
								<xsl:attribute name="objectID">
									<xsl:value-of select="$meterID"/>
								</xsl:attribute>
								<xsl:value-of select="$meterID"/>
							</ns1:meterID>
						</ns1:meterIDs>
						<ns1:transactionID>
							<xsl:value-of select="dp:generate-uuid()"/>
						</ns1:transactionID>
					</ns1:InitiateMeterReadingsByMeterID>
				</soap:Body>
			</soap:Envelope>
		</xsl:variable>
		<dp:set-variable name="'var://context/fvr02/svr_payload'" value="$Payload"/>
		<xsl:variable name="url">
			<xsl:value-of select="$dpconfig:meterReadMqUrl"/>
		</xsl:variable>
		<xsl:variable name="MQMDStr">
			<MQMD>
				<ReplyToQ>
				<xsl:choose>
				<xsl:when test ="contains(dp:variable('var://service/URI'),'EFO')">
					<xsl:value-of select="$dpconfig:efoMeterReadReplyToQ"/>
					</xsl:when>
					<xsl:otherwise>
					<xsl:value-of select="$dpconfig:meterReadReplyToQ"/>
					</xsl:otherwise>
					</xsl:choose>
				</ReplyToQ>
			</MQMD>
		</xsl:variable>
		<xsl:variable name="MQMDStr2">
			<dp:serialize select="$MQMDStr" omit-xml-decl="yes"/>
		</xsl:variable>
		<xsl:variable name="headers">
			<header name="MQMD">
				<xsl:copy-of select="$MQMDStr2"/>
			</header>
		</xsl:variable>
		<xsl:message dp:type="all" dp:priority="debug">headers++<xsl:value-of select="$headers"/>
		</xsl:message>
		<xsl:variable name="CallApi">
			<dp:url-open target="{$url}" http-headers="$headers" response="responsecode-binary">
				<xsl:copy-of select="$Payload"/>
			</dp:url-open>
			
		</xsl:variable>
		
		<dp:set-variable name = "'var://context/rc/CallApi'" value = "$CallApi"/>
		<xsl:variable name = "CallApi" select = "dp:variable('var://context/rc/CallApi')"/>
		<xsl:variable name = "info" select = "concat(' TargetURL :',$url,' ; Method:POST','; Data :',$Payload)"/>
		
		<dp:set-variable name="'var://context/rc/CallAPIResponseCode'" value="string($CallApi/result/responsecode)"/>
		<xsl:variable name="responseCode" select="string($CallApi/result/responsecode)"/>
		<xsl:choose>
			<xsl:when test="$responseCode='0'">
				</xsl:when>
			<xsl:otherwise>
				<xsl:variable name="errorstatuscode" select="$CallApi/result/responsecode"/>
				<xsl:variable name="errorstring">
					<xsl:value-of select="$CallApi/result/errorstring"/>
				</xsl:variable>
				<xsl:choose>
					<xsl:when test="string-length(normalize-space($errorstatuscode))&gt; 0">
						<xsl:message dp:type="all" dp:priority="error">omsapivr_01 unable to place message in meter read queue with responseCode as <xsl:value-of select="$errorstatuscode"/>
						</xsl:message>
							<dp:set-variable name="'var://context/error/customErrorCode'" value="string($errorstatuscode)"/>
					<dp:set-variable name="'var://context/error/customErrorMessage'" value="concat('unable to place message in meter read queue ,with responseCode as ', $errorstatuscode,' , details: ', $info)" />
						<dp:reject>unable to place message in meter read queue ,with responseCode as <xsl:value-of select="$errorstatuscode"/>
						</dp:reject>
					</xsl:when>
					<xsl:otherwise>
						<xsl:message dp:type="all" dp:priority="error">omsapivr_01 unable to place message in meter read queue with responseCode as <xsl:value-of select="$responseCode"/>
						</xsl:message>
						<dp:reject>unable to place message in meter read queue ,with responseCode as <xsl:value-of select="$errorstatuscode"/>
						<dp:set-variable name="'var://context/error/customErrorMessage'" value="concat('unable to place message in meter read queue ,with responseCode as ', $errorstatuscode,' , details: ', $info)" />
						</dp:reject>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
		
	</xsl:template>
</xsl:stylesheet>