var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');

function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var correlationID = uuidv4();
		var EntryDescription = session.parameters.ResoureRequestEntryDescription;
		var ExitDescription = session.parameters.ResoureRequestExitDescription;
		var messageType = session.parameters.ResoureRequestmessageType;
		var sourceEventTimestamp = new Date().toISOString();
		var sourceUrl = sm.getVar('var://service/URL-in');
		var jobID = incomingdata.RequestAdditionalHelp.OUGRequestHelp.ExternalRefID;
		var crewDisplayID = incomingdata.RequestAdditionalHelp.OUGRequestHelp.CrewID;
		var workType = incomingdata.RequestAdditionalHelp.OUGRequestHelp.WorkType.Name;
		var crewTypeDisplayID = incomingdata.RequestAdditionalHelp.OUGRequestHelp.CrewType.Name;


		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ILSctx.setVariable('correlationID', ' ');
		} else {
			ILSctx.setVariable('correlationID', correlationID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ILSctx.setVariable('messageType', ' ');
		} else {
			ILSctx.setVariable('messageType', messageType);
		}
		if (EntryDescription === undefined || EntryDescription === null || EntryDescription === '') {
			ILSctx.setVariable('EntryDescription', ' ');
		} else {
			ILSctx.setVariable('EntryDescription', EntryDescription);
		}
		if (ExitDescription === undefined || ExitDescription === null || ExitDescription === '') {
			ILSctx.setVariable('ExitDescription', '');
		} else {
			ILSctx.setVariable('ExitDescription', ExitDescription);
		}
		if (jobID === null || jobID === '' || jobID === undefined) {
			ILSctx.setVariable("jobID", '');
		}
		else {
			ILSctx.setVariable("jobID", jobID);
		}
		if (crewDisplayID === null || crewDisplayID === '' || crewDisplayID === undefined) {
			ILSctx.setVariable("crewDisplayID", '');
		}
		else {
			ILSctx.setVariable("crewDisplayID", crewDisplayID);
		}
		if (workType === null || workType === '' || workType === undefined) {
			ILSctx.setVariable("workType", '');
		}
		else {
			ILSctx.setVariable("workType", workType);
		}
		if (crewTypeDisplayID === null || crewTypeDisplayID === '' || crewTypeDisplayID === undefined) {
			ILSctx.setVariable("crewTypeDisplayID", '');
		}
		else {
			ILSctx.setVariable("crewTypeDisplayID", crewTypeDisplayID);
		}
		if (sourceEventTimestamp === null || sourceEventTimestamp === '' || sourceEventTimestamp === undefined) {
			ILSctx.setVariable("sourceEventTimestamp", '');
		}
		else {
			ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		if (sourceUrl === null || sourceUrl === '' || sourceUrl === undefined) {
			ILSctx.setVariable("sourceUrl", '');
		}
		else {
			ILSctx.setVariable("sourceUrl", sourceUrl);
		}
	}
});
