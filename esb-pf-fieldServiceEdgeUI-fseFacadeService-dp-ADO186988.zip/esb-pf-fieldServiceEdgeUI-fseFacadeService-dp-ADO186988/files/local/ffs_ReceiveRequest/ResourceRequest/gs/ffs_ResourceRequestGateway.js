var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.INPUT.readAsJSON(function(readAsJSONError, json) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		var correlationID = ILSctx.getVariable('correlationID');
		var OUGRequestHelp = json.RequestAdditionalHelp.OUGRequestHelp
		var ExternalRefID = OUGRequestHelp.ExternalRefID;
		var ExternalRefIDSplit = ExternalRefID.split(":");
		var JobIDGUID = ExternalRefIDSplit[0];

		if ((JobIDGUID == undefined) || (JobIDGUID == '') || (JobIDGUID == null)) {
			logger.error("JobIDGUID is null or not present in the incoming data");
			session.reject("JobIDGUID is null or not present in the incoming data");
		}
		else {
			function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
			var ReceiveRequestUrl = session.parameters.ResourceRequestUrl + JobIDGUID + '/CrewAssignment';
			ILSctx.setVariable('ExitDestination', ReceiveRequestUrl);
			var ReceiveRequestPayload = {
				"CallBackData": {
					"messageID": correlationID,
					"Client": "FSE",
					"ServiceName": "CrewRequest",
				},
				"CrewRequest": {}
			};
			if (!(OUGRequestHelp.ExternalRefID == null || OUGRequestHelp.ExternalRefID == undefined || OUGRequestHelp.ExternalRefID == '')) {
				ReceiveRequestPayload.CallBackData.ExternalRefID = OUGRequestHelp.ExternalRefID
			}
			if (!(JobIDGUID == null || JobIDGUID == undefined || JobIDGUID == '')) {
				ReceiveRequestPayload.CrewRequest.JobIDGUID = JobIDGUID
			}
			if (!(OUGRequestHelp.Destination == null || OUGRequestHelp.Destination == undefined || OUGRequestHelp.Destination == '')) {
				ReceiveRequestPayload.CrewRequest.Destination = OUGRequestHelp.Destination
			}
			if (!(OUGRequestHelp.Longitude == null || OUGRequestHelp.Longitude == undefined || OUGRequestHelp.Longitude == '')) {
				ReceiveRequestPayload.CrewRequest.Longitude = OUGRequestHelp.Longitude
			}
			if (!(OUGRequestHelp.Latitude == null || OUGRequestHelp.Latitude == undefined || OUGRequestHelp.Latitude == '')) {
				ReceiveRequestPayload.CrewRequest.Latitude = OUGRequestHelp.Latitude
			}
			if (!(OUGRequestHelp.Notes == null || OUGRequestHelp.Notes == undefined || OUGRequestHelp.Notes == '')) {
				ReceiveRequestPayload.CrewRequest.Notes = OUGRequestHelp.Notes
			}
			if (!(OUGRequestHelp.CrewID == null || OUGRequestHelp.CrewID == undefined || OUGRequestHelp.CrewID == '')) {
				ReceiveRequestPayload.CrewRequest.CrewID = OUGRequestHelp.CrewID
			}
			if (!(OUGRequestHelp.CrewType == null || OUGRequestHelp.CrewType == undefined || OUGRequestHelp.CrewType == '')) {
				if (!(OUGRequestHelp.CrewType.Name == null || OUGRequestHelp.CrewType.Name == undefined || OUGRequestHelp.CrewType.Name == '')) {
					ReceiveRequestPayload.CrewRequest.CrewType = OUGRequestHelp.CrewType.Name
				}
			}
			if (!(OUGRequestHelp.WorkType == null || OUGRequestHelp.WorkType == undefined || OUGRequestHelp.WorkType == '')) {
				if (!(OUGRequestHelp.WorkType.Name == null || OUGRequestHelp.WorkType.Name == undefined || OUGRequestHelp.WorkType.Name == '')) {
					ReceiveRequestPayload.CrewRequest.WorkType = OUGRequestHelp.WorkType.Name
				}
			}

			var ReceiveRequestPayloadPost = {
				target: ReceiveRequestUrl,
				method: 'POST',
				sslClientProfile: 'ffs_ReceiveRequest_TLS_ClientProfile',
				contentType: 'application/json',
				data: ReceiveRequestPayload,
			};

			var info = " TargetURL :" + ReceiveRequestPayloadPost.target + "; Method :" + ReceiveRequestPayloadPost.method + "; Data :" + JSON.stringify(ReceiveRequestPayloadPost.data) + ". ";
			try {
				urlopen.open(ReceiveRequestPayloadPost, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error while opening the CrewAssignment 'ResourceRequestUrl', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting response from  the GetResponseData, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
								} else {
									hm.response.statusCode = '200 OK';
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDestination', ReceiveRequestUrl);
									logger.debug("response received from GetResponseData :" + JSON.stringify(responseData));
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting response from  the GetResponseData, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									var responseinfo = "Error returned from GetResponseData : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', responseinfo);
									logger.error(responseinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "urlopen connect error while opening the CrewAssignment'ResourceRequestUrl', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	}
});
