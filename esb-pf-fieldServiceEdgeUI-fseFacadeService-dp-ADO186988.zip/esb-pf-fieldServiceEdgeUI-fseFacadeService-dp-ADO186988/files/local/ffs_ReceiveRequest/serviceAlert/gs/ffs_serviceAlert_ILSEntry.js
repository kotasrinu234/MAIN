var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');

function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo)
		logger.error("Error in reading incoming data");
	} else {
		var correlationID = uuidv4();
		var EntryDescription = session.parameters.ServiceAlertEntryDescription;
		var ExitDescription = session.parameters.ServiceAlertExitDescription;
		var messageType = session.parameters.ServiceAlertmessageType;
		var sourceUrl = sm.getVar('var://service/URL-in');
		var crewDisplayID = incomingdata.PanicButton.ServiceAlert.RelatedEngineer.OUGCrewID;
		if (sourceUrl.includes("AlertNotification")) {
			ILSctx.setVariable("sourceEventTimestamp", new Date().toISOString());
		} else {
			ILSctx.setVariable("sourceEventTimestamp", incomingdata.RequestVerifyRestore.Task.OUGFieldTime);

		}
		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ILSctx.setVariable('correlationID', ' ');
		} else {
			ILSctx.setVariable('correlationID', correlationID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ILSctx.setVariable('messageType', ' ');
		} else {
			ILSctx.setVariable('messageType', messageType);
		}
		if (EntryDescription === undefined || EntryDescription === null || EntryDescription === '') {
			ILSctx.setVariable('EntryDescription', ' ');
		} else {
			ILSctx.setVariable('EntryDescription', EntryDescription);
		}
		if (ExitDescription === undefined || ExitDescription === null || ExitDescription === '') {
			ILSctx.setVariable('ExitDescription', '');
		} else {
			ILSctx.setVariable('ExitDescription', ExitDescription);
		}
		if (crewDisplayID === null || crewDisplayID === '' || crewDisplayID === undefined) {
			ILSctx.setVariable("crewDisplayID", '');
		}
		else {
			ILSctx.setVariable("crewDisplayID", crewDisplayID);
		}
		if (sourceUrl === null || sourceUrl === '' || sourceUrl === undefined) {
			ILSctx.setVariable("sourceUrl", '');
		}
		else {
			ILSctx.setVariable("sourceUrl", sourceUrl);
		}
	}
});
