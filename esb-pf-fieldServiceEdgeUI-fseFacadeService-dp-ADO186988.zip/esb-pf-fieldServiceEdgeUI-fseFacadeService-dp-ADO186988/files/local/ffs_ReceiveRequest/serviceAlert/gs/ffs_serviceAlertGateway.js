var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		var ExternalRefID = incomingData.PanicButton.ServiceAlert.RelatedEngineer.ExternalRefID;
		var CrewID = incomingData.PanicButton.ServiceAlert.RelatedEngineer.OUGCrewID;
		var Description = incomingData.PanicButton.ServiceAlert.Description;
		var Title = incomingData.PanicButton.ServiceAlert.Title;
		var CreationTime = incomingData.PanicButton.ServiceAlert.CreationTime;

		if ((CrewID == undefined) || (CrewID == '') || (CrewID == null)) {
			logger.error("CrewID is null or not present in the incoming data");
			session.reject("CrewID is null or not present in the incoming data");
		}
		else {
			var correlationID = ILSctx.getVariable('correlationID');
			var serviceAlertUrl = session.parameters.serviceAlertUrl + CrewID;
			var serviceAlertPayload = {
				"CallBackData": {
					"messageID": correlationID,
					"Client": "FSE",
					"ServiceName": "ServiceAlert",
					"ExternalRefID": ExternalRefID
				},
				"ServiceAlert": {
					"CrewID": CrewID,
					"Description": Description,
					"Title": Title,
					"CreationTime": CreationTime
				}
			};

			var serviceAlertPayloadPost = {
				target: serviceAlertUrl,
				method: 'POST',
				sslClientProfile: 'ffs_ReceiveRequest_TLS_ClientProfile',
				contentType: 'application/json',
				data: serviceAlertPayload,
			};
			var info = " TargetURL :" + serviceAlertPayloadPost.target + "; Method :" + serviceAlertPayloadPost.method + "; Data :" + JSON.stringify(serviceAlertPayloadPost.data) + ". ";
			try {
				urlopen.open(serviceAlertPayloadPost, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error while opening the serviceAlertUrl, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting response from  the serviceAlert, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
								} else {
									hm.response.statusCode = '200 OK';
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDestination', serviceAlertUrl);
									logger.debug("response received from serviceAlert :" + JSON.stringify(responseData));
								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading response from serviceAlert, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									var errorinfo = "Error returned from serviceAlert,details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "urlopen connect error while opening the serviceAlertUrl, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	}
});
