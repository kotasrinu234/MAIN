var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("gcc") || session.createContext("gcc");
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		var correlationID = ILSctx.getVariable('correlationID');
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
		var ExternalRefID = incomingData.RequestGetCalls.Task.ExternalRefID;
		var ExternalRefIDSplit = ExternalRefID.split(":");
		var JobIDGUID = ExternalRefIDSplit[0];

		var sourceUrl = sm.getVar('var://service/URL-in');
		var clientValue;
		if (sourceUrl.includes('EFO')) {
			clientValue = 'EFO';
		} else {
			clientValue = 'FSE';
		}

		if ((JobIDGUID == undefined) || (JobIDGUID == '') || (JobIDGUID == null)) {
			logger.error("JobIDGUID is null or not present in the incoming data");
			session.reject("JobIDGUID is null or not present in the incoming data");
		}
		else {
			var ReceiveRequestUrl = session.parameters.getCustomerCallUrl + JobIDGUID + '/Calls';
			ILSctx.setVariable('ExitDestination', ReceiveRequestUrl);
			
			var numvalue ;
			if (sourceUrl.includes('EFO')) {
			numvalue = incomingData.RequestGetCalls.Task.Number;
		} else {
			numvalue = 0;
		}
			
			var ReceiveRequestPayload = {
				"CallBackData": {
					"messageID": correlationID,
					"CallID": incomingData.RequestGetCalls.Task.CallID,
					"Number": numvalue,
					"Client": clientValue,
					"ServiceName": "CallRequest",
					"ExternalRefID": ExternalRefID
				},
				"GetCallsByJobRequest": {
					"JobID": incomingData.RequestGetCalls.Task.OUGJobID,
					"JobIDGUID": incomingData.RequestGetCalls.Task.OUGJobIDGUID

				}
			};

			var ReceiveRequestPayloadPost = {
				target: ReceiveRequestUrl,
				method: 'POST',
				sslClientProfile: 'ffs_ReceiveRequest_TLS_ClientProfile',
				contentType: 'application/json',
				data: ReceiveRequestPayload,
			};
			var info = " TargetURL :" + ReceiveRequestPayloadPost.target + "; Method :" + ReceiveRequestPayloadPost.method + "; Data :" + JSON.stringify(ReceiveRequestPayloadPost.data) + ". ";
			try {
				urlopen.open(ReceiveRequestPayloadPost, function(error, response) {
					if (error) {
						var errorinfo = "urlopen connect error while opening the url, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting response from  the GetResponseData, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
								} else {
									hm.response.statusCode = '200 OK';
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDestination', ReceiveRequestUrl);
									logger.debug("response received from GetResponseData :" + JSON.stringify(responseData));
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Failure in getting response from  the GetResponseData, details are : " + info + "; error info :" + JSON.stringify(error);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
								} else {
									hm.current.statusCode = responseStatusCode;
									var responseinfo = "Error returned from GetResponseData : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', responseinfo);
									logger.error(responseinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var errorinfo = "urlopen connect error while opening the url, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	}
});
