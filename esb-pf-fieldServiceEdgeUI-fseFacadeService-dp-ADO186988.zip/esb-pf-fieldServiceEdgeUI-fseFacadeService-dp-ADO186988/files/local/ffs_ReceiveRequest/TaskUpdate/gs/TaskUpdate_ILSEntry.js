var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({ 'category': 'all' });
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }

		var correlationID = uuidv4();
		var sourceUrl = sm.getVar('var://service/URL-in');
		if (sourceUrl.includes("TaskUpdate")) {
			nullCheck("messageType", session.parameters.TaskUpdatemessageType)
			nullCheck("EntryDescription", session.parameters.TaskUpdateEntryDescription)
			nullCheck("ExitDescription", session.parameters.TaskUpdatetExitDescription)
			nullCheck("sourceEventTimestamp", new Date().toISOString())
			nullCheck("correlationID", correlationID)
			nullCheck("sourceUrl", sourceUrl)

			ILSctx.setVariable("assignmentStatus", "")
			ILSctx.setVariable("crewAssignmentDisplayID", "")
			if (!(incomingdata.TaskUpdate.Task === undefined || incomingdata.TaskUpdate.Task === null || incomingdata.TaskUpdate.Task === "")) {
				if (!(incomingdata.TaskUpdate.Task.Status === undefined || incomingdata.TaskUpdate.Task.Status === null || incomingdata.TaskUpdate.Task.Status === "")) {
					if (!(incomingdata.TaskUpdate.Task.Status.Name === undefined || incomingdata.TaskUpdate.Task.Status.Name === null || incomingdata.TaskUpdate.Task.Status.Name === "")) {
						ILSctx.setVariable("assignmentStatus", incomingdata.TaskUpdate.Task.Status.Name)
					}
				}
				if (!(incomingdata.TaskUpdate.Task.CallID === undefined || incomingdata.TaskUpdate.Task.CallID === null || incomingdata.TaskUpdate.Task.CallID === "")) {
					ILSctx.setVariable("crewAssignmentDisplayID", incomingdata.TaskUpdate.Task.CallID)
				}
			}
		} else {
			nullCheck("sourceEventTimestamp", incomingdata.RequestVerifyRestore.Task.OUGFieldTime)
		}
	}
});
function nullCheck(paramName, paramValue) {
	if (!(paramValue === null || paramValue === undefined || paramValue === "")) {
		ILSctx.setVariable(paramName, paramValue)
	} else {
		ILSctx.setVariable(paramName, "")
	}
}
