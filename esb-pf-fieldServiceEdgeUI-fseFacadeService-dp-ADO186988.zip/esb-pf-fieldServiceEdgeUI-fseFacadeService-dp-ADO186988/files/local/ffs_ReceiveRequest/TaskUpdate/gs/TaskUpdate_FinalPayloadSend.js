var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var attArray = [];
var pubArray = [];
var disArray = [];
var comArray = [];
var ctx = session.name("ffs_ReceiveRequest") || session.createContext("ffs_ReceiveRequest");
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		var id = new String(incomingdata.TaskUpdate.Task.ExternalRefID);
		var JobIDGUID = (id.split(":")[0]);
		var CrewAssignmentIDGUID = (id.split(":")[1]);
		var ConvertedETA = incomingdata.TaskUpdate.Task.OUGETA;
		var ConvertedETR = incomingdata.TaskUpdate.Task.OUGPublishedETR;
		var IncomingConv;
		if (incomingdata.TaskUpdate.Task.OUGETA === undefined || incomingdata.TaskUpdate.Task.OUGETA === null || incomingdata.TaskUpdate.Task.OUGETA === "") {
		} else {
			IncomingConv = ctx.getVariable("IncomingConv")
			if (IncomingConv.includes("OUGETA")) {
				ConvertedETA = ctx.getVariable("ConvertedETA")
			}
		}
		if (incomingdata.TaskUpdate.Task.OUGPublishedETR === undefined || incomingdata.TaskUpdate.Task.OUGPublishedETR === null || incomingdata.TaskUpdate.Task.OUGPublishedETR === "") {
		} else {
			IncomingConv = ctx.getVariable("IncomingConv")
			if (IncomingConv.includes("OUGPublishedETR")) {
				ConvertedETR = ctx.getVariable("ConvertedETR")
			}
		}

		var Attachments = incomingdata.TaskUpdate.Task.Attachments;
		if (incomingdata.TaskUpdate.Task.OUGPropertiesChanged === undefined || incomingdata.TaskUpdate.Task.OUGPropertiesChanged === null || incomingdata.TaskUpdate.Task.OUGPropertiesChanged === "") {
			logger.error('OUGPropertiesChanged is not present in input  payload');
			//session.reject('OUGPropertiesChanged is not present in input  payload');	
		}
		else {
			var pub = incomingdata.TaskUpdate.Task.OUGPropertiesChanged.split(',');
			ctx.setVariable("InitialPC", pub)
			for (var i = 0; i < pub.length; i++) {
				if (pub[i].includes('OUGURD')) {
					var publish = pub[i].substring(6);
				} else if (pub[i].includes('OUGOH')) {
					var publish = pub[i].substring(5);
				} else if (pub[i].includes('OUG')) {
					var publish = pub[i].substring(3);
				}
				else {
					var publish = pub[i];
				}
				pubArray.push(publish);
			}
		}
		ctx.setVariable("pub", pubArray);

		if (incomingdata.TaskUpdate.Task.Status === undefined || incomingdata.TaskUpdate.Task.Status === null || incomingdata.TaskUpdate.Task.Status === "") {
			var Status
		} else {
			var Status = incomingdata.TaskUpdate.Task.Status.Name;
		}

		if (incomingdata.TaskUpdate.Task.OUGCauseCode === undefined || incomingdata.TaskUpdate.Task.OUGCauseCode === null || incomingdata.TaskUpdate.Task.OUGCauseCode === "") {
			var CauseCode
		} else {
			var CauseCode = incomingdata.TaskUpdate.Task.OUGCauseCode.Name;
		}
		if (incomingdata.TaskUpdate.Task.OUGOutageSubtype === undefined || incomingdata.TaskUpdate.Task.OUGOutageSubtype === null || incomingdata.TaskUpdate.Task.OUGOutageSubtype === "") {
			var OutageSubtype
		} else {
			var OutageSubtype = incomingdata.TaskUpdate.Task.OUGOutageSubtype.Name;
		}

		var OpenLoopArray = [];
		var Task = incomingdata.TaskUpdate.Task
		if (pubArray.includes("OpenLoop")) {
			if (Task.OUGOpenLoop === undefined || Task.OUGOpenLoop === null || Task.OUGOpenLoop === " " || Task.OUGOpenLoop === "" || Task.OUGOpenLoop.Key === -1) {
			} else {
				if (Task.OUGOpenLoop.Name === undefined || Task.OUGOpenLoop.Name === null || Task.OUGOpenLoop.Name === " " || Task.OUGOpenLoop.Name === "") {
				} else {
					var OpenLoopConditon = Task.OUGOpenLoop.Name
					if (OpenLoopConditon === "Y" || OpenLoopConditon === "y") {
						if (pubArray.includes("CircuitNumber")) {
							openLoopNullCheck(Task.OUGOHCircuitNumber, "CircuitNumber", OpenLoopArray)
						}
						if (pubArray.includes("MapNumber")) {
							openLoopNullCheck(Task.OUGURDMapNumber, "MapNumber", OpenLoopArray)
						}
						if (pubArray.includes("FeederNumber")) {
							openLoopNullCheck(Task.OUGFeederNumber, "FeederNumber", OpenLoopArray)
						}
						if (pubArray.includes("Reconductor")) {
							if (Task.OUGReconductor === undefined || Task.OUGReconductor === null || Task.OUGReconductor === " " || Task.OUGReconductor === "" || Task.OUGReconductor.Key === -1) {
							} else {
								openLoopNullCheck(Task.OUGReconductor.Name, "Reconductor", OpenLoopArray)
							}
						}
						if (pubArray.includes("JacketedCable")) {
							if (Task.OUGJacketedCable === undefined || Task.OUGJacketedCable === null || Task.OUGJacketedCable === " " || Task.OUGJacketedCable === "" || Task.OUGJacketedCable.Key === -1) {
							} else {
								openLoopNullCheck(Task.OUGJacketedCable.Name, "JacketedCable", OpenLoopArray)
							}
						}
						if (pubArray.includes("CableCart")) {
							if (Task.OUGCableCart === undefined || Task.OUGCableCart === null || Task.OUGCableCart === " " || Task.OUGCableCart === "" || Task.OUGCableCart.Key === -1) {
							} else {
								openLoopNullCheck(Task.OUGCableCart.Name, "CableCart", OpenLoopArray)
							}
						}
						if (pubArray.includes("LiveFront")) {
							if (Task.OUGLiveFront === undefined || Task.OUGLiveFront === null || Task.OUGLiveFront === " " || Task.OUGLiveFront === "" || Task.OUGLiveFront.Key === -1) {
							} else {
								openLoopNullCheck(Task.OUGLiveFront.Name, "LiveFront", OpenLoopArray)
							}
						}
						if (pubArray.includes("LE28Comments")) {
							openLoopNullCheck(Task.OUGLE28Comments, "LE28Comments", OpenLoopArray)
						}
						if (pubArray.includes("BoomTruck")) {
							if (Task.OUGBoomTruck === undefined || Task.OUGBoomTruck === null || Task.OUGBoomTruck === " " || Task.OUGBoomTruck === "" || Task.OUGBoomTruck.Key === -1) {
							} else {
								openLoopNullCheck(Task.OUGBoomTruck.Name, "BoomTruck", OpenLoopArray)
							}
						}
						if (pubArray.includes("BackHoe")) {
							if (Task.OUGBackHoe === undefined || Task.OUGBackHoe === null || Task.OUGBackHoe === " " || Task.OUGBackHoe === "" || Task.OUGBackHoe.Key === -1) {
							} else {
								openLoopNullCheck(Task.OUGBackHoe.Name, "BackHoe", OpenLoopArray)
							}
						}
						if (pubArray.includes("BackyardMachine")) {
							if (Task.OUGBackyardMachine === undefined || Task.OUGBackyardMachine === null || Task.OUGBackyardMachine === " " || Task.OUGBackyardMachine === "" || Task.OUGBackyardMachine.Key === -1) {
							} else {
								openLoopNullCheck(Task.OUGBackyardMachine.Name, "BackyardMachine", OpenLoopArray)
							}
						}
						if (pubArray.includes("IsolatedBetweenLow")) {
							openLoopNullCheck(Task.OUGIsolatedBetweenLow, "IsolatedBetweenLow", OpenLoopArray)
						}
						if (pubArray.includes("IsolatedBetweenHigh")) {
							openLoopNullCheck(Task.OUGIsolatedBetweenHigh, "IsolatedBetweenHigh", OpenLoopArray)
						}

						function openLoopNullCheck(paramValue, paramName, arrayName) {
							if (!(paramValue === undefined || paramValue === null || paramValue === "" || paramValue === " " || paramValue.Key === -1)) {
								var obj = {
									FieldName: paramName,
									Value: paramValue
								}
								arrayName.push(obj)
							}
						};
					}
				}
			}
		};
		//ctx.setVariable("TestArray", OpenLoopArray)
		var correlationID = ILSctx.getVariable('correlationID');

		var payload =
		{
			"CallBackData": {
				"messageID": correlationID,
				"Client": "FSE",
				"ServiceName": "TaskUpdate",
				"Number": 0,
				"ExternalRefID": incomingdata.TaskUpdate.Task.ExternalRefID
			},
			"TaskUpdate": {
				"JobIDGUID": JobIDGUID,
				"CrewAssignmentIDGUID": CrewAssignmentIDGUID,
				"CrewAssignmentStatus": Status,
				"Attachments": incomingdata.TaskUpdate.Task.Attachments,
				"CrewGUID": incomingdata.TaskUpdate.Task.OUGCrewGUID,
				"CrewID": incomingdata.TaskUpdate.Task.OUGCrewID,
				"PremiseID": incomingdata.TaskUpdate.Task.OUGPremiseID,
				"ETA": ConvertedETA,
				//"NeedOperBy": NeedOperBy,
				"OutageSubtype": OutageSubtype,
				"CompletionRemarks": incomingdata.TaskUpdate.Task.OUGCompletionRemarks,
				"PropertiesChanged": pubArray.join(','),
				"PublishedETR": ConvertedETR,
				"CauseCode": CauseCode,
				"CloseCancelRemarks": incomingdata.TaskUpdate.Task.OUGCloseCancelRemarks,
				"ExchangeMeterIn": incomingdata.TaskUpdate.Task.OUGExchangeMeterIn,
				"ExchangeMeterOut": incomingdata.TaskUpdate.Task.OUGExchangeMeterOut,
				"ExchangeMeterOutReading": incomingdata.TaskUpdate.Task.OUGExchangeMeterOutReading,
				"Dispositions": incomingdata.TaskUpdate.Task.OUGDispositions,
				"MaterialsAffected": incomingdata.TaskUpdate.Task.OUGMaterialsAffected,
				"Comments": incomingdata.TaskUpdate.Task.OUGComments
			}
		};
		var OUGNeedOperBy = incomingdata.TaskUpdate.Task.OUGNeedOperBy
		if (!(OUGNeedOperBy === undefined || OUGNeedOperBy === null || OUGNeedOperBy === '')) {
			var DateTime = new Date(OUGNeedOperBy)
			var NeedOperByYear = DateTime.getFullYear()
			if (NeedOperByYear <= '1900') {
				var newArray = pubArray.filter(item => item !== 'NeedOperBy');
				payload.TaskUpdate.PropertiesChanged = newArray.join(',')
			} else {
				payload.TaskUpdate.NeedOperBy = DateTime.toISOString();
			}
		} else {
			var newArray = pubArray.filter(item => item !== 'NeedOperBy');
			payload.TaskUpdate.PropertiesChanged = newArray.join(',')
		};

		if (OpenLoopArray.length !== 0) {
			payload.TaskUpdate.OpenLoop = OpenLoopArray
		};

		if (incomingdata.TaskUpdate.Task.Stamp === null || incomingdata.TaskUpdate.Task.Stamp === undefined || incomingdata.TaskUpdate.Task.Stamp === "") {
		}
		else {
			if (incomingdata.TaskUpdate.Task.Stamp.TimeModified === null || incomingdata.TaskUpdate.Task.Stamp.TimeModified === undefined || incomingdata.TaskUpdate.Task.Stamp.TimeModified === "") {
			} else {
				payload.CallBackData.TimeModified = incomingdata.TaskUpdate.Task.Stamp.TimeModified
			}
		}
		if (incomingdata.TaskUpdate.Task.CallID === null || incomingdata.TaskUpdate.Task.CallID === undefined || incomingdata.TaskUpdate.Task.CallID === "") {
		} else {
			payload.CallBackData.CallID = incomingdata.TaskUpdate.Task.CallID
		}

		if (incomingdata.TaskUpdate.Task.OUGJobClosed === null || incomingdata.TaskUpdate.Task.OUGJobClosed === undefined || incomingdata.TaskUpdate.Task.OUGJobClosed === "") {
		} else {
			payload.TaskUpdate.JobClosed = incomingdata.TaskUpdate.Task.OUGJobClosed
		}
		var TaskUpdateUrl = session.parameters.TaskUpdateURL;
		//ctx.setVariable("payload", payload);

		var checkNullProperties = payload.TaskUpdate.PropertiesChanged.split(',');
		//ctx.setVariable("checkNullProperties", checkNullProperties)
		var PropArray = []

		if (!(incomingdata.TaskUpdate.Task.Status.Name === null || incomingdata.TaskUpdate.Task.Status.Name === undefined || incomingdata.TaskUpdate.Task.Status.Name === "")) {
			if (incomingdata.TaskUpdate.Task.Status.Name === "Completed") {
				if (checkNullProperties.includes("Dispositions")) {
				}
				else {
					checkNullProperties.push("Dispositions")
				}
			}
		}


		checkNullProperties.forEach(property => {
			switch (property) {
				case "ETA":
					nullPropertiesCheck(payload.TaskUpdate.ETA, PropArray, "ETA");
					break;
				case "Status":
					nullPropertiesCheck(payload.TaskUpdate.CrewAssignmentStatus, PropArray, "Status");
					break;
				case "Dispositions":
					if (!(payload.TaskUpdate.Dispositions === null || payload.TaskUpdate.Dispositions === undefined || payload.TaskUpdate.Dispositions === "")) {
						if (!(payload.TaskUpdate.Dispositions.length === 0)) {
							if (!(payload.TaskUpdate.Dispositions[0].Name === undefined || payload.TaskUpdate.Dispositions[0].Name === null || payload.TaskUpdate.Dispositions[0].Name === "") && (payload.TaskUpdate.Dispositions[0].Key != -1)) {
								PropArray.push("Dispositions")
							}
						}
					}
					break;
				case "OutageSubtype":
					nullPropertiesCheck(payload.TaskUpdate.OutageSubtype, PropArray, "OutageSubtype");
					break;
				case "CauseCode":
					nullPropertiesCheck(payload.TaskUpdate.CauseCode, PropArray, "CauseCode");
					break;
				case "MaterialsAffected":
					if (!(payload.TaskUpdate.MaterialsAffected === null || payload.TaskUpdate.MaterialsAffected === undefined || payload.TaskUpdate.MaterialsAffected === "")) {
						if (!(payload.TaskUpdate.MaterialsAffected.length === 0)) {
							if (!(payload.TaskUpdate.MaterialsAffected[0].Name === undefined || payload.TaskUpdate.MaterialsAffected[0].Name === null || payload.TaskUpdate.MaterialsAffected[0].Name === "") && (payload.TaskUpdate.MaterialsAffected[0].Key != -1)) {
								PropArray.push("MaterialsAffected")
							}
						}
					}
					break;
				case "CompletionRemarks":
					nullPropertiesCheck(payload.TaskUpdate.CompletionRemarks, PropArray, "CompletionRemarks");
					break;
				case "NeedOperBy":
					nullPropertiesCheck(payload.TaskUpdate.NeedOperBy, PropArray, "NeedOperBy");
					break;
				case "PublishedETR":
					nullPropertiesCheck(payload.TaskUpdate.PublishedETR, PropArray, "PublishedETR");
					break;
				case "ExchangeMeterIn":
					nullPropertiesCheck(payload.TaskUpdate.ExchangeMeterIn, PropArray, "ExchangeMeterIn");
					break;
				case "ExchangeMeterOut":
					nullPropertiesCheck(payload.TaskUpdate.ExchangeMeterOut, PropArray, "ExchangeMeterOut");
					break;
				case "ExchangeMeterOutReading":
					nullPropertiesCheck(payload.TaskUpdate.ExchangeMeterOutReading, PropArray, "ExchangeMeterOutReading");
					break;
				case "OpenLoop":
					nullPropertiesCheck(payload.TaskUpdate.OpenLoop, PropArray, "OpenLoop");
					break;
				case "JobClosed":
					nullPropertiesCheck(payload.TaskUpdate.JobClosed, PropArray, "JobClosed");
					break;
				case "Comments":
					nullPropertiesCheck(payload.TaskUpdate.Comments, PropArray, "Comments");
					break;
				case "CloseCancelRemarks":
					nullPropertiesCheck(payload.TaskUpdate.CloseCancelRemarks, PropArray, "CloseCancelRemarks");
					break;
				default:
					PropArray.push(property)
					break;

			}
		});
		//ctx.setVariable("PropArray", PropArray)
		function nullPropertiesCheck(parameter, arrayName, propName) {
			if (!(parameter === null || parameter === undefined || parameter === "" || parameter.Key === -1)) {
				arrayName.push(propName)
			}
		}
		payload.TaskUpdate.PropertiesChanged = PropArray.join(',')

		var TaskUpdateCall = {
			target: TaskUpdateUrl,
			sslClientProfile: 'ffs_ReceiveRequest_TLS_ClientProfile',
			method: 'put',
			contentType: 'application/json',
			data: payload
		};

		var info = " TargetURL :" + TaskUpdateCall.target + "; Method :" + TaskUpdateCall.method + "; Data :" + JSON.stringify(TaskUpdateCall.data) + ". ";
		urlopen.open(TaskUpdateCall, function(error, response) {
			if (error) {
				// an error occurred during request sending or response header parsing
				var errorinfo = "urlopen connect error while doing TaskUpdateCall, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							var errorinfo = "failure in reading message from TaskUpdateCall, details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitDescription', errorinfo);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
						else {
							ILSctx.setVariable('ExitStatus', '0');
							ILSctx.setVariable('ExitDestination', TaskUpdateUrl);
							ctx.setVariable("res", responseData);
						}
					})
				} else if (responseStatusCode == 400) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading response from Task Update call, details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitDescription', errorinfo);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.current.statusCode = responseStatusCode;
							var errorinfo = "Bad Request response from Task Update call,details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "failure in reading response from Task Update call, details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitDescription', errorinfo);
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.current.statusCode = responseStatusCode;
							var errorinfo = "Error returned from Task Update call,details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		})
	}
})
