var ctx = session.name("CrewStatus_Update") || session.createContext("CrewStatus_Update");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incommingdata) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		var correlationID = ILSctx.getVariable('correlationID');
		var EngineerID = incommingdata.CrewStatusUpdate.Engineer.ID;
		var CrewStatus = incommingdata.CrewStatusUpdate.Engineer.OUGCrewStatus.Name;
		var CrewID = incommingdata.CrewStatusUpdate.Engineer.OUGCrewID;
		var ExternalRefID = incommingdata.CrewStatusUpdate.Engineer.ExternalRefID;
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }

		var CrewStatusJson = {
			CallBackData: {
				messageID: correlationID,
				Client: "FSE",
				ServiceName: "CrewStatusUpdate",
				ExternalRefID: ExternalRefID
			},
			CrewStatusUpdate: {
				CrewID: CrewID,
				EngineerID: EngineerID,
				CrewStatus: CrewStatus
			}
		}
		var FSEUrl = session.parameters.CrewUpdateURL;
		ctx.setVariable("CrewStatusJson", CrewStatusJson);
		var FSECall = {
			target: FSEUrl,
			sslClientProfile: 'ffs_ReceiveRequest_TLS_ClientProfile',
			method: 'PUT',
			contentType: 'application/json',
			data: CrewStatusJson
		};

				var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";
		try {
			urlopen.open(FSECall, function(error, response) {
				if (error) {
					// an error occurred during request sending or response header parsing
					var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitDescription', errorinfo);
					ILSctx.setVariable('ExitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								// error while reading response or transferring data to Buffer
								var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitDescription', errorinfo);
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
							} else {
								ILSctx.setVariable('ExitStatus', '0');
								ILSctx.setVariable('ExitDestination', FSEUrl);
								ctx.setVariable("responseData", responseData);
							}
						})
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error while doing FSECall, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitDescription', errorinfo);
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.response.statusCode = responseStatusCode;
								var errorinfo = "Error returned from FSECall, details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			})
		} catch (error) {
			var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
			ILSctx.setVariable('ExitDescription', errorinfo);
			ILSctx.setVariable('ExitStatus', '500');
			logger.error(errorinfo);
			session.reject(errorinfo);
		}

	}
});
