var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');

function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		var correlationID = uuidv4();
		var sourceUrl = sm.getVar('var://service/URL-in');

		if (sourceUrl.includes("CrewStatus")) {
			ILSctx.setVariable('messageType', session.parameters.CrewStatusUpdatemessageType)
			ILSctx.setVariable('EntryDescription', session.parameters.CrewStatusUpdateEntryDescription)
			ILSctx.setVariable('ExitDescription', session.parameters.CrewStatusUpdateExitDescription)
			ILSctx.setVariable("sourceEventTimestamp", new Date().toISOString());
		} else {
			ILSctx.setVariable("sourceEventTimestamp", incomingdata.RequestVerifyRestore.Task.OUGFieldTime);

		}

		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ILSctx.setVariable('correlationID', ' ');
		} else {
			ILSctx.setVariable('correlationID', correlationID);
		}
		if (sourceUrl === null || sourceUrl === '' || sourceUrl === undefined) {
			ILSctx.setVariable("sourceUrl", '');
		}
		else {
			ILSctx.setVariable("sourceUrl", sourceUrl);
		}
	}
});
