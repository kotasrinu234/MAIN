var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("ffs_ReceiveRequest") || session.createContext("ffs_ReceiveRequest");
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
		var IncomingConv = [];

		if (incomingData.TaskUpdate.Task.OUGETA === undefined ||
			incomingData.TaskUpdate.Task.OUGETA === null ||
			incomingData.TaskUpdate.Task.OUGETA === "") {
		} else {
			IncomingConv.push("OUGETA")
		}
		if (incomingData.TaskUpdate.Task.OUGPublishedETR === undefined ||
			incomingData.TaskUpdate.Task.OUGPublishedETR === null ||
			incomingData.TaskUpdate.Task.OUGPublishedETR === "") {
		} else {
			IncomingConv.push("OUGPublishedETR")
		}


		if (IncomingConv.includes("OUGETA") ||
			IncomingConv.includes("OUGPublishedETR")) {

			var OUGETA = incomingData.TaskUpdate.Task.OUGETA;
			var OUGPublishedETR = incomingData.TaskUpdate.Task.OUGPublishedETR;
			var TimeConvParameters = [OUGETA, OUGPublishedETR]
			var TimeConversions = ["OUGETA", "OUGPublishedETR"]
			ctx.setVariable("IncomingConv", IncomingConv)


			var TimeConvExists = [];
			for (var i = 0; i < IncomingConv.length; i++) {
				for (var j = 0; j < TimeConversions.length; j++) {
					if (IncomingConv[i] == TimeConversions[j]) {
						TimeConvExists.push(String(IncomingConv[i]))
					}
				}
			}
			ctx.setVariable("TimeConvExists", TimeConvExists)

			var OUGETAExists = TimeConvExists.includes("OUGETA");
			var OUGPublishedETRExists = TimeConvExists.includes("OUGPublishedETR");
			var TimeConvExtistParams = [OUGETAExists, OUGPublishedETRExists]

			var TimeConversionPayload = []
			for (var i = 0; i < TimeConversions.length; i++) {
				if (TimeConvExtistParams[i]) {
					var timeStampPayload = {
						"DateConversion": {
							"action": '2',
							"dateList": [{
								"fieldName": TimeConversions[i].toString(),
								"fromDateTime": TimeConvParameters[i]
							}]
						}
					}
					TimeConversionPayload.push(timeStampPayload)
				}
			}
			ctx.setVariable("TimeConversionPayload", TimeConversionPayload)

			var TimeConvertorurl = session.parameters.ffs_ConvertTimeURL;
			var ConvertedTimes = [];
			for (var i = 0; i < TimeConversionPayload.length; i++) {
				var TimeConvertorcall = {
					target: TimeConvertorurl,
					method: 'POST',
					contentType: 'application/json',
					data: TimeConversionPayload[i]
				};

				var info = " TargetURL :" + TimeConvertorcall.target + "; Method :" + TimeConvertorcall.method + "; Data :" + JSON.stringify(TimeConvertorcall.data) + ". ";
				try {
					urlopen.open(TimeConvertorcall, function(error, response) {
						if (error) {
							var errorinfo = "ffs_001 urlopen connect error with connecting to ffs_ConvertTime from ffs_ReceiveRequest, details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitDescription', errorinfo);
							ILSctx.setVariable('ExitStatus', '500');
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "error message while reading response from ffs_ConvertTime in ffs_ReceiveRequest service, details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitDescription', errorinfo);
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										hm.response.statusCode = responseStatusCode;
										var Response = JSON.parse(responseData);
										ctx.setVariable("responseDataTest", Response)
										if (Response.DateConversion.dateList[0].fieldName == "OUGETA") {
											ctx.setVariable("ConvertedETA", Response.DateConversion.dateList[0].toDateTime)
										}
										if (Response.DateConversion.dateList[0].fieldName == "OUGPublishedETR") {
											ctx.setVariable("ConvertedETR", Response.DateConversion.dateList[0].toDateTime)
										}

										var PushToArray = Response.DateConversion.dateList[0].toDateTime;
										ConvertedTimes.push(PushToArray)

										//ctx.setVariable("Response", Response)
										ctx.setVariable("PushToArray", PushToArray)
										ctx.setVariable("ConvertedTimes", ConvertedTimes)
									}
								});
							}
						}
					});
				} catch (error) {
					var errorinfo = "ffs_001 urlopen connect error with connecting to ffs_ConvertTime from ffs_ReceiveRequest, details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitDescription', errorinfo);
					ILSctx.setVariable('ExitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
				}
			}
		}
	}
});
