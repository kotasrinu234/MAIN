var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');

function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var correlationID = uuidv4();
		var EntryDescription = session.parameters.AdditionalWorkEntryDescription;
		var ExitDescription = session.parameters.AdditionalWorkExitDescription;
		var messageType = session.parameters.AdditionalWorkmessageType;
		var sourceUrl = sm.getVar('var://service/URL-in');
		var externalRefID = incomingdata.RequestAdditionalWork.OUGRequestWork.ExternalRefID;
		var externalRefIDSplit = externalRefID.split(":");
		var jobID = externalRefIDSplit[0];
		var jobType = incomingdata.RequestAdditionalWork.OUGRequestWork.JobType.Name;


		if (sourceUrl.includes("AdditionalWork")) {
			ILSctx.setVariable("sourceEventTimestamp", new Date().toISOString());
		} else {
			ILSctx.setVariable("sourceEventTimestamp", incomingdata.RequestVerifyRestore.Task.OUGFieldTime);
		}

		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ILSctx.setVariable('correlationID', ' ');
		} else {
			ILSctx.setVariable('correlationID', correlationID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ILSctx.setVariable('messageType', ' ');
		} else {
			ILSctx.setVariable('messageType', messageType);
		}
		if (EntryDescription === undefined || EntryDescription === null || EntryDescription === '') {
			ILSctx.setVariable('EntryDescription', ' ');
		} else {
			ILSctx.setVariable('EntryDescription', EntryDescription);
		}
		if (ExitDescription === undefined || ExitDescription === null || ExitDescription === '') {
			ILSctx.setVariable('ExitDescription', '');
		} else {
			ILSctx.setVariable('ExitDescription', ExitDescription);
		}
		if (jobID === null || jobID === '' || jobID === undefined) {
			ILSctx.setVariable("jobID", '');
		}
		else {
			ILSctx.setVariable("jobID", jobID);
		}
		if (jobType === null || jobType === '' || jobType === undefined) {
			ILSctx.setVariable("jobType", '');
		}
		else {
			ILSctx.setVariable("jobType", jobType);
		}
		if (sourceUrl === null || sourceUrl === '' || sourceUrl === undefined) {
			ILSctx.setVariable("sourceUrl", '');
		}
		else {
			ILSctx.setVariable("sourceUrl", sourceUrl);
		}
	}
});
