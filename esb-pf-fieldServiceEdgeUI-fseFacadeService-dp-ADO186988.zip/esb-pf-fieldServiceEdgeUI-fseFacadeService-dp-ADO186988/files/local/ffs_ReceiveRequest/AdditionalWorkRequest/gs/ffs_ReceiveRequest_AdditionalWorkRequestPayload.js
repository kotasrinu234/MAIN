var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		var ILSctx = session.name('ILS') || session.createContext('ILS');
		var ctx = session.name("additionalWorkRequest") || session.createContext("additionalWorkRequest");
		var externalRefID = incomingData.RequestAdditionalWork.OUGRequestWork.ExternalRefID;
		var externalRefIDSplit = externalRefID.split(":");
		var jobIDGUID = externalRefIDSplit[0];
		var jobTypeName = incomingData.RequestAdditionalWork.OUGRequestWork.JobType.Name;
		var linkTypeName = incomingData.RequestAdditionalWork.OUGRequestWork.LinkType.Name;
		var resourceNeededName = incomingData.RequestAdditionalWork.OUGRequestWork.ResourceNeeded.Name;
		var jobAddress = incomingData.RequestAdditionalWork.OUGRequestWork.JobAddress;
		var longitude = incomingData.RequestAdditionalWork.OUGRequestWork.Longitude;
		var latitude = incomingData.RequestAdditionalWork.OUGRequestWork.Latitude;
		var notes = incomingData.RequestAdditionalWork.OUGRequestWork.Notes;
		var deviceId = incomingData.RequestAdditionalWork.OUGRequestWork.OUGDeviceID;
		var additionalWorkRequestUrl = session.parameters.AdditionWorkRequestURL + jobIDGUID + '/CreateJob';
		var correlationID = ILSctx.getVariable('correlationID');
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
		var additionalWorkRequestPayload = {
			"CallBackData": {
				"messageID": correlationID,
				"Client": "FSE",
				"ServiceName": "CreateJobRequest",
				"ExternalRefID": externalRefID
			},
			"CreateJobRequest": {
				"JobIDGUID": jobIDGUID,
				"JobAddress": jobAddress,
				"Longitude": longitude,
				"Latitude": latitude,
				"Notes": notes,
				"JobType": jobTypeName,
				"LinkType": linkTypeName,
				"ResourceNeeded": resourceNeededName,
				"DeviceId": deviceId
			}

		};
		var ctx = session.name("additionalWorkRequest") || session.createContext("additionalWorkRequest");
		ctx.setVariable("AdditionalWorkPayload", additionalWorkRequestPayload);
		var additionalWorkRequestPayloadPost = {
			target: additionalWorkRequestUrl,
			method: 'POST',
			sslClientProfile: 'ffs_ReceiveRequest_TLS_ClientProfile',
			contentType: 'application/json',
			data: additionalWorkRequestPayload,
		};

		var info = " TargetURL :" + additionalWorkRequestPayloadPost.target + "; Method :" + additionalWorkRequestPayloadPost.method + "; Data :" + JSON.stringify(additionalWorkRequestPayloadPost.data) + ". "; 
		try {
			urlopen.open(additionalWorkRequestPayloadPost, function(error, response) {
				if (error) {
					var errorinfo = "urlopen connect error while opening the additionalWorkRequest url, details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitDescription', errorinfo);
					ILSctx.setVariable('ExitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsJSON(function(error, responseData) {
							if (error) {
								var errorinfo = "Failure in getting response from additionalWorkRequest url, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitDescription', errorinfo);
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
							} else {
								hm.response.statusCode = '200 OK';
								ILSctx.setVariable('ExitStatus', '0');
								ILSctx.setVariable('ExitDestination', additionalWorkRequestUrl);
								logger.debug("response received from GetResponseData :" + JSON.stringify(responseData));
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "failure in reading response from AdditionWorkRequestURL, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitDescription', errorinfo);
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								hm.current.statusCode = responseStatusCode;
								var errorinfo = "Error returned from AdditionWorkRequestURL,details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
							}
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "urlopen connect error while opening the additionalWorkRequest url, details are : " + info + "; error info :" + error
			ILSctx.setVariable('ExitDescription', errorinfo);
			ILSctx.setVariable('ExitStatus', '500');
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	}
});
