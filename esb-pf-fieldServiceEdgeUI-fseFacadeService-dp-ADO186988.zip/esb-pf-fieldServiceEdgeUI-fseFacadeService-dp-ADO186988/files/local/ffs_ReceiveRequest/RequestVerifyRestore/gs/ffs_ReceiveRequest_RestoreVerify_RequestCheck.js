//js is used to perform nullcheck for the input request
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var nullCheckRequired = session.parameters.RestoreVerify_NullCheck;
	
	if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
	var ctx = session.name("ffs_ReceiveRequest")|| session.createContext("ffs_ReceiveRequest");
		if(nullCheckRequired == 'REQUIRED'){
			if(incomingdata.RequestVerifyRestore.Task != '' || incomingdata.RequestVerifyRestore.Task != undefined || incomingdata.RequestVerifyRestore.Task != null){
			var ExternalRefID = incomingdata.RequestVerifyRestore.Task.ExternalRefID;
			if (ExternalRefID === null || ExternalRefID === '' || ExternalRefID === undefined) {
				logger.error('ExternalRefID is not present in input  payload');
				ctx.setVariable("schemafailed", 'yes')
				var schemafailedMessage = 'ExternalRefID is not present in input  payload'
				session.reject('ExternalRefID is not present in input payload');
	        }	
	        var OUGFieldTime = incomingdata.RequestVerifyRestore.Task.OUGFieldTime;			
			if (OUGFieldTime === null || OUGFieldTime === '' || OUGFieldTime === undefined) {
				logger.error('OUGFieldTime is not present in input payload');
				ctx.setVariable("schemafailed", 'yes')
				var schemafailedMessage = 'FieldTime is not present in input  payload';
				ctx.setVariable("schemafailedMessage", 'FieldTime is not present in input  payload')
				session.reject('OUGFieldTime is not present in input payload');
	        }


			var OUGVerify = incomingdata.RequestVerifyRestore.Task.OUGVerify;
			if (OUGVerify === null || OUGVerify === '' || OUGVerify === undefined) {
	           logger.debug('OUGVerify is not present in input payload');
				ctx.setVariable("schemafailed", 'yes')
				var schemafailedMessage = 'Verify is not present in input  payload';
				session.reject('OUGVerify is not present in input payload');
	        }	

				var OUGRestore = incomingdata.RequestVerifyRestore.Task.OUGRestore;
					if (OUGRestore === null || OUGRestore === '' || OUGRestore === undefined) {
		           	logger.error('OUGRestore is not present in input payload');
					ctx.setVariable("schemafailed", 'yes')
				  	var schemafailedMessage = 'Restore is not present in input  payload';
				session.reject('OUGRestore is not present in input payload');
		        }

				}
						
}
if(incomingdata.RequestVerifyRestore.Task == undefined || incomingdata.RequestVerifyRestore.Task =='' || incomingdata.RequestVerifyRestore.Task == null){
		logger.debug('OUGVerify and OUGRestore both are not present in input payload ');
		ctx.setVariable("schemafailed", 'yes')
		  var schemafailedMessage = 'Verify and Restore both are not present in input payload';
		  var test = FSENegativeResponse(schemafailedMessage, incomingdata);
}else{	
	
var OUGVerify = incomingdata.RequestVerifyRestore.Task.OUGVerify;
var OUGRestore = incomingdata.RequestVerifyRestore.Task.OUGRestore;
if((OUGVerify == true && OUGRestore == true) || (OUGVerify == false && OUGRestore == false) ){
	 logger.error('Verify and Restore both are '+OUGVerify);
	ctx.setVariable("schemafailed", 'yes')
	  var schemafailedMessage = 'OUGVerify and OUGRestore both are  present in input payload as '+OUGRestore;
	ctx.setVariable("schemafailedMessage", schemafailedMessage)
	session.reject('OUGVerify and OUGRestore both are  present in input payload as '+OUGRestore);
}

}
		}		
	});
