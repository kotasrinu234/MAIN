var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');

function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var correlationID = uuidv4();
		var EntryDescription = session.parameters.RestoreVerifyEntryDescription;
		var ExitDescription = session.parameters.RestoreVerifyExitDescription;
		var messageType = session.parameters.RestoreVerifymessageType;
		//var sourceEventTimestamp = new Date().toISOString();
		var sourceUrl = sm.getVar('var://service/URL-in');
		var ExternalRefID = incomingdata.RequestVerifyRestore.Task.ExternalRefID;
		var jobID = ExternalRefID.split(':').shift();
		var crewAssignmentDisplayID = incomingdata.RequestVerifyRestore.Task.CallID;


		var OUGFieldTime = incomingdata.RequestVerifyRestore.Task.OUGFieldTime
		if (OUGFieldTime !== undefined && OUGFieldTime !== null && OUGFieldTime !== '') {
			ILSctx.setVariable("sourceEventTimestamp", new Date().toISOString());
		} else {
			ILSctx.setVariable("sourceEventTimestamp", OUGFieldTime);
		}

		if (correlationID === undefined || correlationID === null || correlationID === '') {
				ILSctx.setVariable('correlationID', ' ');
			} else {
				ILSctx.setVariable('correlationID', correlationID);
			}
			if (messageType === undefined || messageType === null || messageType === '') {
				ILSctx.setVariable('messageType', ' ');
			} else {
				ILSctx.setVariable('messageType', messageType);
			}
		if (EntryDescription === undefined || EntryDescription === null || EntryDescription === '') {
				ILSctx.setVariable('EntryDescription', ' ');
			} else {
				ILSctx.setVariable('EntryDescription', EntryDescription);
			}
			if (ExitDescription === undefined || ExitDescription === null || ExitDescription === '') {
				ILSctx.setVariable('ExitDescription', '');
			} else {
				ILSctx.setVariable('ExitDescription', ExitDescription);
			}
		if (jobID === null || jobID === '' || jobID === undefined) {
			ILSctx.setVariable("jobID", '');
		}
		else {
			ILSctx.setVariable("jobID", jobID);
		}
		if (crewAssignmentDisplayID === null || crewAssignmentDisplayID === '' || crewAssignmentDisplayID === undefined) {
			ILSctx.setVariable("crewAssignmentDisplayID", '');
		}
		else {
			ILSctx.setVariable("crewAssignmentDisplayID", crewAssignmentDisplayID);
		}
		
		if (sourceUrl === null || sourceUrl === '' || sourceUrl === undefined) {
			ILSctx.setVariable("sourceUrl", '');
		}
		else {
			ILSctx.setVariable("sourceUrl", sourceUrl);
		}
	}
});
