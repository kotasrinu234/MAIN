var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("ffs_ReceiveRequest") || session.createContext("ffs_ReceiveRequest");
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
		var timeStampPayload = {
			"DateConversion": {
				"action": '2',
				"dateList": [{
					"fieldName": "OUGFieldTime",
					"fromDateTime": incomingdata.RequestVerifyRestore.Task.OUGFieldTime
				}]
			}
		}
		var TimeConvertorurl = session.parameters.ffs_ConvertTimeURL;
		var TimeConvertorcall = {
			target: TimeConvertorurl,
			method: 'POST',
			contentType: 'application/json',
			data: timeStampPayload
		};

		var info = " TargetURL :" + TimeConvertorcall.target + "; Method :" + TimeConvertorcall.method + "; Data :" + JSON.stringify(TimeConvertorcall.data) + ". ";
		try {
			urlopen.open(TimeConvertorcall, function(error, response) {
				if (error) {
					var errorinfo = "ffs_001 urlopen connect error with connecting to ffs_ConvertTime from ffs_ReceiveRequest, details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitDescription', errorinfo);
					ILSctx.setVariable('ExitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error message while reading response from ffs_ConvertTime in ffs_ReceiveRequest service, details are : " + info + "; error info :" + JSON.stringify(error);
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
							} else {
								ILSctx.setVariable('ExitStatus', '0');
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;

								var OUGFieldTimeResponse = JSON.parse(responseData);

								var OUGFieldTime = OUGFieldTimeResponse.DateConversion.dateList[0].toDateTime;
								//creating callba
								var Createpayload = {
									"CallBackData": {
										"Client": "FSE",
										"ServiceName": "RestoreVerify"
									},
									"RestoreVerify": {
									}
								}
								if (incomingdata.RequestVerifyRestore.Task != undefined || incomingdata.RequestVerifyRestore.Task != '' || incomingdata.RequestVerifyRestore.Task != null) {
									var CallID = incomingdata.RequestVerifyRestore.Task.CallID;
									if (CallID != undefined) {
										Createpayload.CallBackData.CallID = CallID;
									}
									var number = incomingdata.RequestVerifyRestore.Task.Number;
									if (number != undefined) {
										Createpayload.CallBackData.Number = number;
									}
									//adding uuid in payload as message id;
									function uuidv4() {
										return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
											var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
											return v.toString(16);
										});
									}
									//var uuid = uuidv4();
									var correlationID = ILSctx.getVariable('correlationID');
									Createpayload.CallBackData.messageID = correlationID;

									var ExternalRefID = incomingdata.RequestVerifyRestore.Task.ExternalRefID;
									if (ExternalRefID) {
										Createpayload.CallBackData.ExternalRefID = ExternalRefID;
										var jobId = ExternalRefID.split(':').shift();
										Createpayload.RestoreVerify.JobIDGUID = jobId;
									}
									//var OUGFieldTime = incomingdata.RequestVerifyRestore.Task.OUGFieldTime;
									if (OUGFieldTime != undefined) {
										Createpayload.RestoreVerify.FieldTime = OUGFieldTime;
									}
									var OUGVerify = incomingdata.RequestVerifyRestore.Task.OUGVerify;
									if (OUGVerify != undefined) {
										Createpayload.RestoreVerify.Verify = OUGVerify;
									}
									var OUGRestore = incomingdata.RequestVerifyRestore.Task.OUGRestore;
									if (OUGRestore != undefined) {
										Createpayload.RestoreVerify.Restore = OUGRestore;
									}
									var OUGLastRequestStatus = incomingdata.RequestVerifyRestore.Task.OUGLastRequestStatus;
									if (OUGLastRequestStatus != undefined) {
										Createpayload.RestoreVerify.LastRequestStatus = OUGLastRequestStatus;
									}
								}
								//https://esb{env}.serv.dteco.com:xxxx/OutageManagementAPI /V1/job/{job id}/verifyRequest
								//https://esb{env}.serv.dteco.com:xxxx /OutageManagementAPI/V1/job/{job id}/restorationRequest
								var backendurl = session.parameters.RestoreVerifyBackendurl;
								var RestoreVerifyBackendurl;
								var ExternalRefID = incomingdata.RequestVerifyRestore.Task.ExternalRefID;
								var jobId = ExternalRefID.split(':').shift();
								if (incomingdata.RequestVerifyRestore.Task.OUGVerify == true) {
									RestoreVerifyBackendurl = backendurl + '/OutageManagementAPI/V1/job/' + jobId + '/verifyRequest';
								} else if (incomingdata.RequestVerifyRestore.Task.OUGRestore == true) {
									RestoreVerifyBackendurl = backendurl + '/OutageManagementAPI/V1/job/' + jobId + '/restorationRequest';
								}
								var headers = hm.current;


								var Authen = headers.get('Authorization');


								var RestoreVerifyBackendcall = {
									target: RestoreVerifyBackendurl,
									method: 'POST',
									sslClientProfile: 'ffs_ReceiveRequest_TLS_ClientProfile',
									contentType: 'application/json',
									headers: {
										'Authorization': Authen,
									},
									data: Createpayload
								};
								var info = " TargetURL :" + RestoreVerifyBackendcall.target + "; Method :" + RestoreVerifyBackendcall.method + "; Data :" + JSON.stringify(RestoreVerifyBackendcall.data) + ". ";
								try {
									urlopen.open(RestoreVerifyBackendcall, function(error, response) {
										if (error) {
											var errorinfo = "ffs_002 urlopen connect error with connecting to  RestoreVerifyBackendcall, details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitDescription', errorinfo);
											ILSctx.setVariable('ExitStatus', '500');
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "error message while reading response from RestoreVerifyBackendcall, details are : " + info + "; error info :" + JSON.stringify(error);
														ILSctx.setVariable('ExitStatus', responseStatusCode);
														ILSctx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														hm.response.statusCode = responseStatusCode;
														ILSctx.setVariable('ExitStatus', '0');
														ILSctx.setVariable('ExitDestination', RestoreVerifyBackendurl);
													}
												});
											} else {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "Error returned while doing post for RestoreVerifyBackendcall, details are : " + info + "; error info :" + JSON.stringify(error);
														ILSctx.setVariable('ExitStatus', responseStatusCode);
														ILSctx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														var errorinfo = "Error returned while updating RestoreVerifyBackendcall,details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', responseStatusCode);
														ILSctx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo);
													}
												});
											}
										}
									});
								} catch (error) {
									var errorinfo = "ffs_002 urlopen connect error with connecting to  RestoreVerifyBackendcall, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', '500');
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								//create callbackdata end
							}
						});
					} else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "Error returned while doing post  from ffs_ConvertTime in ffs_ReceiveRequest service, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitDescription', errorinfo);
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "Error returned while updating from ffs_ConvertTime in ffs_ReceiveRequest service,details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							}
						});
					}
				}
			});
		} catch (error) {
			var errorinfo = "ffs_001 urlopen connect error with connecting to ffs_ConvertTime from ffs_ReceiveRequest, details are : " + info + "; error info :" + error
			ILSctx.setVariable('ExitDescription', errorinfo);
			ILSctx.setVariable('ExitStatus', '500');
			logger.error(errorinfo);
			session.reject(errorinfo);
		}
	}
});
