<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:com="http://comesb.pro.com" extension-element-prefixes="dp com" exclude-result-prefixes="dp dpconfig com">
	<xsl:output method="xml"/>
	<xsl:import href="com_UtilityFunctions.xsl"/>
	<xsl:variable name="errorCode" select="dp:variable('var://service/error-code')"/>
	<xsl:variable name="errorSubCode" select="dp:variable('var://service/error-subcode')"/>
	<xsl:variable name="errorMsg" select="dp:variable('var://service/error-message')"/>
	<xsl:variable name="backendURL" select="dp:variable('var://service/routing-url')"/>
	<xsl:variable name="requestIP" select="com:getRequestorIP()"/>
	<xsl:variable name="msgSize" select="dp:variable('var://service/input-size')"/>
	<xsl:variable name="logStage" select="dp:variable('var://context/esb/logstage')"/>
	<xsl:variable name="errorResponse" select="dp:variable('var://context/gcc/errorResponse')"/>
	<xsl:variable name="errorDesc" select="dp:variable('var://context/ILS/ExitDescription')"/>
	<xsl:variable name="serviceName" select="dp:variable('var://context/gcc/serviceName')"/>
	<!-- Initialize parameter for disable logging -->
	<xsl:param name="dpconfig:disableLog" select="''"/>
	<!-- Get the value-of stylesheet parameter -->
	<xsl:variable name="disableLog" select="$dpconfig:disableLog"/>
	<xsl:template match="/">
		<xsl:if test="$disableLog != '1'">
			<xsl:message dp:type="all" dp:priority="debug">***Module: print error details --> Start***</xsl:message>
			<xsl:message dp:type="all" dp:priority="debug">Error code: <xsl:value-of select="$errorCode"/>
			</xsl:message>
			<xsl:message dp:type="all" dp:priority="debug">Error subcode: <xsl:value-of select="$errorSubCode"/>
			</xsl:message>
			<xsl:message dp:type="all" dp:priority="debug">Error message: <xsl:value-of select="$errorMsg"/>
			</xsl:message>
			<dp:set-local-variable name="comErrorMsg" value="$errorMsg"/>
			<xsl:if test="contains($errorResponse, '1215')">
				<dp:set-http-response-header name="'RetryHeaderFlag'" value="'Yes'"/>
			</xsl:if>
		</xsl:if>
		<xsl:choose>
			<xsl:when test="$errorCode = '0x01130006'">
				<xsl:if test="$disableLog != '1'">
					<xsl:message dp:type="all" dp:priority="error">
						<xsl:value-of select="$errorMsg"/> to backend URL: <xsl:value-of select="$backendURL"/>
					</xsl:message>
					<xsl:if test="contains($errResp, '1215')">
						<dp:set-http-response-header name="'RetryHeaderFlag'" value="'Yes'"/>
					</xsl:if>
					<dp:set-local-variable name="comErrorMsg" value="'Error connecting to backend URL'"/>
				</xsl:if>
				<!-- Return SOAP Fault to the user -->
				<env:Envelope xmlns:env='http://schemas.xmlsoap.org/soap/envelope/'>
					<env:Body>
						<env:Fault>
							<faultcode>env:Client</faultcode>
							<faultstring>Error connecting to actual backend service</faultstring>
						</env:Fault>
					</env:Body>
				</env:Envelope>
			</xsl:when>
			<xsl:otherwise>
				<xsl:call-template name="returnGenericException"/>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:variable name="errTime">
			<xsl:value-of select="dp:time-value()"/>
		</xsl:variable>
		<xsl:variable name="comErrorEvent">
			<xsl:choose>
				<!-- If nothing logged so far, log this error event as request in -->
				<xsl:when test="string-length($logStage) = 0">
					<xsl:value-of select="$errTime"/>|0|0|Error|ErrorMsg=<xsl:value-of select="dp:local-variable($comErrorMsg)"/>|<xsl:value-of select="com:getRequestDetails()"/>
				</xsl:when>
				<!-- If request in is logged, log it as request out -->
				<xsl:when test="$logStage = '1'">
					<xsl:value-of select="$errTime"/>|0|1|Error|ErrorMsg=<xsl:value-of select="dp:local-variable($comErrorMsg)"/>|<xsl:value-of select="$msgSize"/>
				</xsl:when>
				<!-- If request out/response in are also logged, log this as response out -->
				<xsl:when test="$logStage = '2'">
					<xsl:value-of select="$errTime"/>|1|1|Error|ErrorMsg=<xsl:value-of select="dp:local-variable($comErrorMsg)"/>|<xsl:value-of select="$msgSize"/>
				</xsl:when>
				<!-- All events have been logged.. dont do anything -->
				<xsl:otherwise/>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="ignore">
			<xsl:value-of select="com:genComEvent($comErrorEvent,$disableLog)"/>
		</xsl:variable>
		<xsl:if test="$disableLog != '1'">
			<xsl:if test="contains($errResp, '1215')">
				<dp:set-http-response-header name="'RetryHeaderFlag'" value="'Yes'"/>
			</xsl:if>
			<xsl:message dp:type="all" dp:priority="debug">***Module: print error details<xsl:value-of select="$comErrorEvent"/> --> End***</xsl:message>
		</xsl:if>
		
		<xsl:choose>
			<xsl:when test="errorDesc">
				<xsl:copy-of select="$errorDesc"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:copy-of select="$errorMsg"/>
			</xsl:otherwise>
		</xsl:choose>
		
	</xsl:template>
	<!-- Template to return the standard service bus internal error -->
	<xsl:template name="returnGenericException">
		<env:Envelope xmlns:env='http://schemas.xmlsoap.org/soap/envelope/'>
			<env:Body>
				<env:Fault>
					<faultcode>env:Client</faultcode>
					<faultstring>
						<xsl:value-of select="$errorMsg"/>
					</faultstring>
				</env:Fault>
			</env:Body>
		</env:Envelope>
	</xsl:template>
</xsl:stylesheet>
