var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var conversionVal,GMTDate, ESTDateVar, ESTDate,localOffset,offset,utc,finalESTDate,dateArray;
var ctx = session.name("omsapijob")|| session.createContext("omsapijob");
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if(readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
		if(incomingdata.DateConversion.action == '2' ){
			var incomingtime = incomingdata.DateConversion.dateList[0].fromDateTime;
			var	GMTDate = new Date(incomingtime);
			var ESTDateVar = GMTDate.getTime();
			var localOffset = GMTDate.getTimezoneOffset() * 60000;
			var datestrng = GMTDate.toString();
			//var offset;
//									if(datestrng.includes(edt)){
//									offset = +4;
//										} else {
//									offset = +5;
//									}
			//var utc = ESTDateVar + (3600000*offset);
			var utc = ESTDateVar
			var ctx = session.name("omsapijob")|| session.createContext("omsapijob");
			ctx.setVariable("utc",utc);
			var ESTDate = new Date(utc).toISOString();
			var finalutcDate = ESTDate;
			var outputpayload ={
				"DateConversion": {
						"action": "2",
						"dateList": [{
						"fieldName": incomingdata.DateConversion.dateList[0].fieldName,
						"fromDateTime": incomingdata.DateConversion.dateList[0].fromDateTime,
						"toDateTime": finalutcDate
					}]
				}
			}
			
			session.output.write(outputpayload);
		}
		else if(incomingdata.DateConversion.action == '1' ) {
			dateArray = incomingdata.DateConversion.dateList;
			var ctx = session.name("gcc_dateTime") || session.createContext("gcc_dateTime");
			ctx.setVariable("dateArray.length",dateArray.length);
			if(incomingdata.DateConversion.action == 1){
				for (let i=0; i < dateArray.length; i++){
					GMTDate = new Date(dateArray[i].fromDateTime);
					ESTDateVar = GMTDate.getTime();
					localOffset = GMTDate.getTimezoneOffset() * 60000;
					var datestrng = GMTDate.toString();
					var edt = "EDT";
					if(datestrng.includes(edt)){
						offset = -4;
					} else {
						offset = -5;
					}
					utc = ESTDateVar + (3600000*offset);
					ctx.setVariable("utc",utc);
					ESTDate = new Date(utc).toISOString();
					finalESTDate = ESTDate.replace('Z', '');
					incomingdata.DateConversion.dateList[i].toDateTime = finalESTDate;
					ctx.setVariable("requestJson",incomingdata);
					ctx.setVariable("finalESTDate",finalESTDate);
					session.output.write(incomingdata);
				}
			}
		}
		
	}
				});

	
