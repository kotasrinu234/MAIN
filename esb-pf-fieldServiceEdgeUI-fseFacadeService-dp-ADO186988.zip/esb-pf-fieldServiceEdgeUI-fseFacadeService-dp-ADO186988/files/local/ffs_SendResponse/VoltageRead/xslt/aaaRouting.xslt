<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:dp="http://www.datapower.com/extensions" 
xmlns:dpconfig="http://www.datapower.com/param/config"
extension-element-prefixes="dp dpconfig"
exclude-result-prefixes="dp dpconfig">

<xsl:template match="/">

<xsl:variable name = "uriIn" select = "dp:variable('var://service/URI')" />
<dp:set-variable name = "'var://context/fseEfo/uriIn'" value = "$uriIn" />


<xsl:variable name="aaaOutput">
<path>

<xsl:choose>
<!-- <xsl:if test ="contains($uriIn,'/FoaGateWay/EFO/VoltageRead')">
 --><xsl:when test ="contains(dp:variable('var://service/URI'),'EFO')">
<efo>EFO</efo>
</xsl:when>

<!-- <xsl:if test ="contains($uriIn, '/FoaGateWay/VoltageRead')" > -->
<!-- <xsl:if test ="contains(dp:variable('var://service/URI'), '/FoaGateWay/VoltageRead')" > -->
<xsl:otherwise>
<fse>FSE</fse>

</xsl:otherwise>
</xsl:choose>
</path>
</xsl:variable>

<dp:set-variable name = "'var://context/fseEfo/pathAaa'" value = "$aaaOutput" />
<xsl:copy-of select ="$aaaOutput" />

</xsl:template>
</xsl:stylesheet>
