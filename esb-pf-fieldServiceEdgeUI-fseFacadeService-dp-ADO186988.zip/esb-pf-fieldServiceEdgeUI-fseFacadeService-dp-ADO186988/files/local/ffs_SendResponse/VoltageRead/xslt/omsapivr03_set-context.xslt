<xsl:stylesheet version="1.0" exclude-result-prefixes="dp  get ns0 v1 " extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:ns1="http://www.multispeak.org/Version_4.1_Release" xmlns:mustUnderstand="http://www.w3.org/2003/05/soap-envelope" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="2.0" encoding="UTF-8" indent="yes"/>
	<xsl:strip-space elements="*"/>
	
	<xsl:param name="dpconfig:entryDescription"/>
	<xsl:param name="dpconfig:exitDescription"/>
	<xsl:param name="dpconfig:exitDestination"/>
	<xsl:param name="dpconfig:messageType"/>
	<xsl:param name="dpconfig:sourceUrl"/>
	<xsl:template match="/">
		<xsl:variable name="meterID" select="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/*[local-name()='meterID']"/>
		<xsl:variable name = "Timestamp" select ="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='changedMeterReads']/*[local-name()='meterReading']/*[local-name()='readingValues']/*[local-name()='readingValue']/*[local-name()='timeStamp']" />
		
		<xsl:variable name = "correlationID" select ="/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='ReadingChangedNotification']/*[local-name()='transactionID']" />
		
		<dp:set-variable name="'var://context/ILS/MeterID'" value="$meterID"/>
		<dp:set-variable name="'var://context/ILS/Timestamp'" value="$Timestamp"/>
		<dp:set-variable name="'var://context/ILS/TimeModified'" value="$TimeModified"/>
		<dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID"/>
		<dp:set-variable name="'var://context/ILS/entryDescription'" value="$dpconfig:entryDescription"/>
		<dp:set-variable name="'var://context/ILS/exitDescription'" value="$dpconfig:exitDescription"/>
		<dp:set-variable name="'var://context/ILS/exitDestination'" value="$dpconfig:exitDestination"/>
		<dp:set-variable name="'var://context/ILS/messageType'" value="$dpconfig:messageType"/>
		<dp:set-variable name="'var://context/ILS/sourceUrl'" value="$dpconfig:sourceUrl"/>
		
		
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$Timestamp"/>
		
		<xsl:choose>
 <xsl:when test ="contains(dp:variable('var://service/URL-in'),'EFO')">
		<dp:set-variable name="'var://context/vr_fse/token'" value="'efotoken'"/>

</xsl:when>
<xsl:otherwise>
		<dp:set-variable name="'var://context/vr_fse/token'" value="'fsetoken'"/>

</xsl:otherwise>
</xsl:choose>
		
		
				
	</xsl:template>
</xsl:stylesheet>