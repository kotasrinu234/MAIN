<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1"
	extension-element-prefixes="dp" xmlns:dp="http://www.datapower.com/extensions" 
	 xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dpconfig="http://www.datapower.com/param/config">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="no" />
	<xsl:strip-space elements="*" />	
	<xsl:param name="dpconfig:exitDestination"/>
	<xsl:template match="/">
		<xsl:variable name="systemErrorCode"
			select="dp:variable('var://service/error-code')" />
		<xsl:variable name="dpErrorMessage"
			select="dp:variable('var://service/error-message')" />

		<xsl:variable name="customErrorCode"
			select="dp:variable('var://context/vr_fse/customErrorCode')" />
		<xsl:variable name="customErrorMessage"
			select="dp:variable('var://context/vr_fse/customErrorMessage')" />
			
			<dp:set-variable name="'var://context/fvr03/retry'" value="string('yes')" />

<xsl:variable name ="url" select = "dp:variable('var://context/ILS/exitDestination')"/>
					<xsl:choose>
						<xsl:when test="$customErrorCode and $customErrorCode !=''">
							<xsl:message dp:type="all" dp:priority="error">id=fse_ReVR_01|ErrorCode:<xsl:value-of select="$customErrorCode" /> ErrorMessage: <xsl:value-of select="$customErrorMessage" />
							</xsl:message>
							<dp:set-variable name = "'var://context/ILS/errorcode'" value ="$customErrorCode" />
							<!-- <dp:set-variable name = "'var://context/ILS/statusDetail'" value ="concat('errorMessage-',$customErrorMessage,' url:',$url)" /> -->
							<dp:set-variable name = "'var://context/ILS/statusDetail'" value ="$customErrorMessage" />
						</xsl:when>
						<xsl:otherwise>
							<xsl:message dp:type="all" dp:priority="error">id=fse_ReVR_01|ErrorCode:<xsl:value-of select="$systemErrorCode" /> ErrorMessage: <xsl:value-of select="$dpErrorMessage" />
								</xsl:message>
								<dp:set-variable name = "'var://context/ILS/errorcode'" value ="$systemErrorCode" />
								<!-- <dp:set-variable name = "'var://context/ILS/statusDetail'" value ="concat('errorMessage-',$dpErrorMessage,' url:',$url)" /> -->
								<dp:set-variable name = "'var://context/ILS/statusDetail'" value ="$dpErrorMessage" />
						</xsl:otherwise>
					</xsl:choose>
		
	</xsl:template>
</xsl:stylesheet>

