var ctx = session.name("vr_fse") || session.createContext("vr_fse");
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var token = ctx.getVariable('token');
var fseToken = session.parameters.FSETOKEN;
var efoToken = session.parameters.EFOTOKEN;
var Auth = '';
if (token == 'fsetoken' ){
	Auth = "Basic " + session.parameters.FSETOKEN;
} else if (token == 'efotoken'){	
	Auth = "Basic " + session.parameters.EFOTOKEN;
}
var ILSctx = session.name('ILS') || session.createContext('ILS');

function callURL(url, method, myctx, payload) {
	var url;
if (token == 'fsetoken' ){
	url = session.parameters.VRFseUrl;
	ILSctx.setVariable('ExitDestination', url)
} else if (token == 'efotoken'){	
	url = session.parameters.EFOExecuteMultipleOperations
	ILSctx.setVariable('ExitDestination', url)
	}
	
	var options = {
		target: url,
		method: method,
		headers: {
			'Authorization': Auth
		},
		contentType: "application/json",
		sslClientProfile: "FSE_Client_Profile"
	};
	if (method == "POST" || method == "PATCH") {
		options.data = payload;
	}

	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(payload) + ". ";

	urlopen.open(options, function(error, response) {
		if (error) {
			var ctx = session.name("vr_fse") || session.createContext("vr_fse");
			// an error occurred during reading the file
			var errorinfo = "urlopen error of 'callURL', details are : " + info + "; error info :" + error
			logger.error(errorinfo);
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', errorinfo)
			ctx.setVariable("customErrorCode", '500');
			ctx.setVariable("customErrorMessage", errorinfo);
			throw error;
		} else {
			var responseStatusCode = response.statusCode;
			var ctx = session.name("vr_fse") || session.createContext("vr_fse");
			ctx.setVariable(myctx + "_responseStatusCode", responseStatusCode);
			ctx.setVariable(myctx + "_response", response);

			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, data) {
					if (error) {
						var errorinfo = "Error in reading 'callURL' response data, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', responseStatusCode);
						ILSctx.setVariable('ExitDescription', responseStatusCode)
						ctx.setVariable("customErrorCode", '500');
						ctx.setVariable("customErrorMessage", errorinfo)
						logger.error(errorinfo);
						logger.error("Error in reading response data");
						throw error;
					} else {
						var ctx = session.name("vr_fse") || session.createContext("vr_fse");
						ctx.setVariable(myctx + '_response', data);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "failure in reading message 'callURL', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						ctx.setVariable("customErrorCode", '500');
						ctx.setVariable("customErrorMessage", errorinfo);
						logger.error(errorinfo);
					} else {
						var ctx = session.name("vr_fse") || session.createContext("vr_fse");
						ctx.setVariable(myctx + '_buffer_response', "" + responseData);
						logger.error("response received with responseStatusCode " + responseStatusCode + " " + responseData);
						var responseDataStr = "" + responseData;
						ctx.setVariable(myctx + '_buffer_response2', responseDataStr);
						if (responseStatusCode == 400 && responseDataStr !== 'No updates') {
							var responseinfo = "Bad Request response received from callURL, details are : " + info + "; response info :" + responseDataStr + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', responseinfo)
							ctx.setVariable("customErrorCode", '400');
							ctx.setVariable("customErrorMessage", responseinfo);
							ctx.setVariable("customReasonMessage", 'Bad Request');
							session.reject("Bad Request");
						}
					}
				});


				if (responseStatusCode == 403) {
					var responseinfo = "ffs_011:Forbidden response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', responseinfo)
					ctx.setVariable("customErrorCode", '403');
					ctx.setVariable("customErrorMessage", responseinfo);
					ctx.setVariable("customReasonMessage", 'Forbidden');
					session.reject("Forbidden");
				} else if (responseStatusCode == 401) {
					var responseinfo = "ffs_012:Unauthorized response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', responseinfo)
					ctx.setVariable("customErrorCode", '401');
					ctx.setVariable("customErrorMessage", responseinfo);
					ctx.setVariable("customReasonMessage", 'Unauthorized');
					session.reject("Unauthorized");
				} else if (responseStatusCode == 404) {
					var responseinfo = "No Records Found response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', responseinfo)
					ctx.setVariable("customErrorCode", '404');
					ctx.setVariable("customErrorMessage", responseinfo);
					ctx.setVariable("customReasonMessage", 'No Records Found');
					session.reject("No Records Found");
				} else if (responseStatusCode == 500) {
					var responseinfo = "Server Error response received from callURL, details are : " + info + "; ResponseStatusCode :" + responseStatusCode
					ILSctx.setVariable('ExitStatus', responseStatusCode);
					ILSctx.setVariable('ExitDescription', responseinfo)
					ctx.setVariable("customErrorCode", '500');
					ctx.setVariable("customErrorMessage", responseinfo);
					ctx.setVariable("customReasonMessage", 'Server Error');
					session.reject("Server Error");
				}
			}
		}
	});
}
module.exports = callURL;
