var sm = require('service-metadata');
var hm = require('header-metadata');
var callURL = require('./VR_callURL.js');
var VRFseUrl = session.parameters.VRFseUrl;

var logger = console.options({
    'category': 'all'
});
var ctx = session.name('vr_fse') || session.createContext('vr_fse');

session.input.readAsJSON(function(error, incomingdata) {
    if (error) {
        logger.error("Error in parsing incoming request " + JSON.stringify(error));
        session.reject("Error in parsing incoming request" + JSON.stringify(error));
        //throw error;
    } else {			
if (ctx.getVariable('flag').toString()=='false'){

	var finalStr ='Instantaneous Voltage a:';
	var ins_vA = ''+ ctx.getVariable('ins_vA');
	var vA = ctx.getVariable('vA');
	var vB = ctx.getVariable('vB');
	var vC = ctx.getVariable('vC');
	
	//if(ins_vA !== undefined && ins_vA !== null) {finalStr = finalStr + ins_vA.slice(0,(ins_vA.indexOf("."))+3)+'V'};
	
	if(ins_vA.indexOf('.') !== -1){
			finalStr = finalStr + ins_vA.slice(0,(ins_vA.indexOf("."))+3)+'V';
		}else{
			finalStr = finalStr + vA +'V';
		}
	
	if(vA !== undefined && vA !== 'NaN,'){
		if(vA.indexOf('.') !== -1){
			finalStr = finalStr + '; V(a):'+ vA.slice(0,(vA.indexOf("."))+3)+'V';
		}else{
		finalStr = finalStr + '; V(a):'+ vA.slice(0,(vA.indexOf(",")))+'V';
		}
	}
	if(vB !== undefined && vB !== 'NaN,'){
		if(vB.indexOf('.') !== -1){
			finalStr = finalStr + '; V(b):'+ vB.slice(0,(vB.indexOf("."))+3)+'V';
		}else{
		finalStr = finalStr + '; V(b):'+ vB.slice(0,(vB.indexOf(",")))+'V';
		}
	}
	if(vC !== undefined && vC !== 'NaN,'){
		if(vC.indexOf('.') !== -1){
			finalStr = finalStr + '; V(c):'+ vC.slice(0,(vC.indexOf("."))+3)+'V';
		}else{
		finalStr = finalStr + '; V(c):'+ vC.slice(0,(vC.indexOf(",")))+'V';
		}
	}
	incomingdata.Operations[0].Object.ReadResults=finalStr;
	
	}
	
	callURL(VRFseUrl,"POST","vrFseReq",incomingdata);
	}
});

