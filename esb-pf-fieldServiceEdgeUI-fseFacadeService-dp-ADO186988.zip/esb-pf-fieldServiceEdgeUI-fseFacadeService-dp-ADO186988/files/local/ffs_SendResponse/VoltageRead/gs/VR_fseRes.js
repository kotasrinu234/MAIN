var sm = require('service-metadata');
var hm = require('header-metadata');
var callURL = require('./VR_callURL.js');
var ctx = session.name('vr_fse') || session.createContext('vr_fse');
var vrFseRes = ctx.getVariable('vrFseReq_response');
var logger = console.options({
    'category': 'all'
});



logger.debug("FSE Response: " + JSON.stringify(vrFseRes));
session.output.write(vrFseRes);



 

 