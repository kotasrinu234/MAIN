var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});


var ctx = session.name("rreq") || session.createContext("rreq");
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		if (incomingdata.CallBackData.ServiceName == 'ServiceAlert') {
			var currentdate = new Date(),
				m = '' + (currentdate.getMonth() + 1),
				d = '' + currentdate.getDate(),
				y = currentdate.getFullYear();

			if (m.length < 2)
				m = '0' + m;
			if (d.length < 2)
				d = '0' + d;

			var req_format = [y, m, d].join('-');
			var finaldate = req_format + "T" + ("0" + currentdate.getHours()).slice(-2) + ":"
				+ ("0" + currentdate.getMinutes()).slice(-2) + ":"
				+ ("0" + currentdate.getSeconds()).slice(-2);
			var FixedErrorLength = parseInt(session.parameters.TaskUpdateErrorLength)

			var Message = JSON.stringify(incomingdata.ErrorMessage)
			var ErrorMessage = finaldate + " " + Message

			//ctx.setVariable("ErrorMessage", ErrorMessage)

			var ErrorMsglength = ErrorMessage.length
			ctx.setVariable("MSGLength", ErrorMsglength)
			if (ErrorMsglength > FixedErrorLength) {
				var TrimmedMsg = ErrorMessage.substring(0, FixedErrorLength);
				ctx.setVariable("TrimmedMsg", TrimmedMsg)
				ctx.setVariable("TrimmedErrorMsglength", TrimmedMsg.length)

			} else {
				var TrimmedMsg = ErrorMessage
				ctx.setVariable("WithoutTrimming", TrimmedMsg)

			}
			var payload =
			{
				"Task": {
					"@objectType": "Task",
					"@createOrUpdate": true,
					"CallID": incomingdata.CallBackData.CallID,
					"Number": incomingdata.CallBackData.Number,
					"ExternalRefID": incomingdata.CallBackData.ExternalRefID,
					"OUGErrorStatus": TrimmedMsg
					/*[
						{
							"DateReported": finaldate,
							"ErrorStatus": TrimmedMsg
						}
					]*/
				},
				"TaskRequestedProperties": [
					"CallID",
					"Number",
					"OUGEnergizationStatus",
					"EngineersOUGVerify",
					"OUGErrorStatus"
				],
				"ErrorOnNonExistingDictionaries": true
			}
			var Auth = "Basic " + session.parameters.FSETOKEN;
			var ErrorUrl = session.parameters.ErrorUrl;
			var FSECall = {
				target: ErrorUrl,
				sslClientProfile: 'FSE_Client_Profile',
				method: 'POST',
				headers: {
					'Authorization': Auth,
				},
				contentType: 'application/json',
				data: payload
			};

			var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";

			try {
				urlopen.open(FSECall, function(error, response) {
					if (error) {
						// an error occurred during request sending or response header parsing
						var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = " failure in reading message from FSECall, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
								}
								else {
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDescription', session.parameters.ExitDescription);
									ILSctx.setVariable('ExitDestination', ErrorUrl);
									logger.debug("FSE call url open is success");
									ctx.setVariable("responseData", responseData);
								}
							})
						}
						else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "ffs_008: Error returned from 'ffs_serviceAlert ErrorUrl FSECall' 'Authentication/Authentication Error', details are : " + info + "; error info :" + error;
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "ffs_008: Error returned from 'ffs_serviceAlert ErrorUrl FSECall' 'Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							})
						}
						else {
							var errorinfo = "Error returned from FSECall : " + info + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							hm.response.statusCode = responseStatusCode;
						}
					}
				})
			} catch (error) {
				var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			}

		}
	}
})
