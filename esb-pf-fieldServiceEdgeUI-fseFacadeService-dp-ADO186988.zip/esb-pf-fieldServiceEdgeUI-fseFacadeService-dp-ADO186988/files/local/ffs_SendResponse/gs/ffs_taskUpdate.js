var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});


var ctx = session.name("taskUpdate") || session.createContext("taskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		if (incomingdata.CallBackData.ServiceName == 'ETRChangeCount') {
			var Number;
			if (incomingdata.CallBackData.Number === undefined ||
				incomingdata.CallBackData.Number === null ||
				incomingdata.CallBackData.Number === "") {
				Number = 0;
			} else {
				Number = incomingdata.CallBackData.Number
			}
			var payload =
			{
				"Task": {
					"@objectType": "Task",
					"@createOrUpdate": true,
					"CallID": incomingdata.CallBackData.CallID,
					"Number": Number,
					"ExternalRefID": incomingdata.CallBackData.ExternalRefID,
					"OUGPublishedETRChangeCount": incomingdata.ETRChangeCount.PublishedETRChangeCount
				}
			};
			ctx.setVariable("ETRResp", incomingdata.ETRChangeCount.PublishedETRChangeCount)
			var Auth = "Basic " + session.parameters.FSETOKEN;
			var FSEUrl = session.parameters.TaskUpdateFSEUrl;
			var FSECall = {
				target: FSEUrl,
				sslClientProfile: 'FSE_Client_Profile',
				method: 'POST',
				headers: {
					'Authorization': Auth,
				},
				contentType: 'application/json',
				data: payload
			};

			var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";

			try {
				urlopen.open(FSECall, function(error, response) {
					if (error) {
						// an error occurred during request sending or response header parsing
						var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + JSON.stringify(error)
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								else {
									ILSctx.setVariable('ExitStatus', '0');
									logger.debug("FSE call url open is success" + responseData);
									ctx.setVariable("responseData", responseData);
								}
							})
						}
						else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "ffs_009: Error returned from 'TaskUpdateFSEUrl FSECall' 'Authentication/Authentication Error', details are : " + info + "; error info :" + error;
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "ffs_009: Error returned from 'TaskUpdateFSEUrl FSECall' 'Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							})
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + JSON.stringify(error)
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								else {
									ctx.setVariable("Respon", responseData.toString())
									hm.response.statusCode = responseStatusCode;
									var errorinfo = "Error returned from FSECall : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				})
			} catch (error) {
				var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}

		if (incomingdata.CallBackData.ServiceName == 'TaskUpdate') {
			//var currentdate = incomingdata.ActivityDateTime;
			var currentdate = new Date(),
				m = '' + (currentdate.getMonth() + 1),
				d = '' + currentdate.getDate(),
				y = currentdate.getFullYear();
			if (m.length < 2)
				m = '0' + m;
			if (d.length < 2)
				d = '0' + d;

			var req_format = [y, m, d].join('-');
			var finaldate = req_format + "T" + ("0" + currentdate.getHours()).slice(-2) + ":"
				+ ("0" + currentdate.getMinutes()).slice(-2) + ":"
				+ ("0" + currentdate.getSeconds()).slice(-2);
			//	ctx.setVariable("Time",finaldate)
			//var response = incomingdata.ErrorMessage;
			//	var ErrorMessage = JSON.parse(response)
			//ctx.setVariable("ParesedError", ErrorMessage)
			var Number;
			if (incomingdata.CallBackData.Number === undefined ||
				incomingdata.CallBackData.Number === null ||
				incomingdata.CallBackData.Number === "") {
				Number = 0;
			} else {
				Number = incomingdata.CallBackData.Number
			}

			var FixedErrorLength = parseInt(session.parameters.TaskUpdateErrorLength)
			//ctx.setVariable("ActualLength", FixedErrorLength);
			var Message = JSON.stringify(incomingdata.ErrorMessage)
			var ErrorMessage = finaldate + " " + Message

			//ctx.setVariable("ErrorMessage", ErrorMessage)

			var ErrorMsglength = ErrorMessage.length
			ctx.setVariable("MSGLength", ErrorMsglength)
			if (ErrorMsglength > FixedErrorLength) {
				var TrimmedMsg = ErrorMessage.substring(0, FixedErrorLength);
				ctx.setVariable("TrimmedMsg", TrimmedMsg)
				ctx.setVariable("TrimmedErrorMsglength", TrimmedMsg.length)

			} else {
				var TrimmedMsg = ErrorMessage
				ctx.setVariable("WithoutTrimming", TrimmedMsg)

			}

			var payload =
			{
				"Task": {
					"@objectType": "Task",
					"@createOrUpdate": true,
					"CallID": incomingdata.CallBackData.CallID,
					"Number": Number,
					"ExternalRefID": incomingdata.CallBackData.ExternalRefID,
					"OUGErrorStatus": TrimmedMsg

					/*[
						{
							"DateReported": finaldate,
							"ErrorStatus": TrimmedMsg
						}
					]*/
				},
				"TaskRequestedProperties": [
					"CallID",
					"Number",
					"OUGEnergizationStatus",
					"EngineersOUGVerify",
					"OUGErrorStatus"
				],
				"ErrorOnNonExistingDictionaries": true
			}
			ctx.setVariable("payload", payload)
			var Auth = "Basic " + session.parameters.FSETOKEN;
			var FSEErrorUrl = session.parameters.ErrorUrl;
			var ErrorCall = {
				target: FSEErrorUrl,
				sslClientProfile: 'FSE_Client_Profile',
				method: 'POST',
				contentType: 'application/json',
				data: payload,
				headers: {
					'Authorization': Auth
				}
			};
			var info = " TargetURL :" + ErrorCall.target + "; Method :" + ErrorCall.method + "; Data :" + JSON.stringify(ErrorCall.data) + ". ";
			try {
				urlopen.open(ErrorCall, function(error, response) {
					if (error) {
						// an error occurred during request sending or response header parsing
						var errorinfo = "urlopen connect error while doing FSE ErrorCall, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									// error while reading response or transferring data to Buffer
									var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + JSON.stringify(error)
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								else {
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDescription', session.parameters.ExitDescription);
									ILSctx.setVariable('ExitDestination',FSEErrorUrl);
									logger.debug("FSE call url open is success" + responseData);
									ctx.setVariable("responseData", responseData);
								}
							})
						}
						else if (responseStatusCode == 401 || responseStatusCode == 403) {
							// Handle business error responses (HTTP 401 or 403)
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									// Handle error in reading response data
									var errorinfo = "ffs_010: Error returned from 'TaskUpdateErrorUrl FSECall' 'Authentication/Authentication Error', details are : " + info + "; error info :" + error;
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "ffs_010: Error returned from 'TaskUpdateErrorUrl FSECall' 'Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
									ILSctx.setVariable('ExitDescription', errorinfo);
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							})
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + JSON.stringify(error)
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
								else {
									hm.response.statusCode = responseStatusCode;
									var errorinfo = "Error returned from FSECall : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				})
			} catch (error) {
				var errorinfo = "urlopen connect error while doing FSE ErrorCall, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	}
})
