var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("ffs") || session.createContext("ffs");
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {

		//before creating task payload check with interface it is from

		if (incomingdata.CallBackData.ServiceName == 'RestoreVerify') {
			var task_payload =
			{
				"Task": {
					"@objectType": "Task",
					"@createOrUpdate": true
				},
				"ErrorOnNonExistingDictionaries": true,
				TaskRequestedProperties: ["CallID"]
			}

			if (incomingdata.CallBackData.CallID != undefined) {
				//task_payload.TaskRequestedProperties.push(incomingdata.CallBackData.CallID);
				task_payload.Task.CallID = incomingdata.CallBackData.CallID;
			}
			if (incomingdata.CallBackData.Number != undefined) {
				task_payload.Task.Number = incomingdata.CallBackData.Number;
			}
			if (incomingdata.CallBackData.ExternalRefID != undefined) {
				task_payload.Task.ExternalRefID = incomingdata.CallBackData.ExternalRefID;
			}
			if (incomingdata.UpdateEngerzationStatus.LastRequestStatus != undefined) {
				task_payload.Task.OUGLastRequestStatus = incomingdata.UpdateEngerzationStatus.LastRequestStatus;
			}
			if (incomingdata.UpdateEngerzationStatus.EnergizationStatus != undefined) {
				task_payload.Task.OUGEnergizationStatus = incomingdata.UpdateEngerzationStatus.EnergizationStatus;
			}

			var ctx = session.name("ffs") || session.createContext("ffs");
			ctx.setVariable('FSEpayload', task_payload);
			var Auth = "Basic " + session.parameters.FSETOKEN;
			var FseRestoreVerifyUrl = session.parameters.FseRestoreVerifyUrl;

			var FSEapicall = {
				target: session.parameters.FseRestoreVerifyUrl,
				sslClientProfile: 'FSE_Client_Profile',
				method: 'POST',
				contentType: 'application/json',
				headers: {
					'Authorization': Auth
				},
				data: task_payload
			};

			var info = " TargetURL :" + FSEapicall.target + "; Method :" + FSEapicall.method + "; Data :" + JSON.stringify(FSEapicall.data) + ". ";
			try {
				urlopen.open(FSEapicall, function(error, response) {
					if (error) {
						var ctx = session.name("foa") || session.createContext("foa");
						ctx.setVariable("retry", 'yes');
						var errorinfo = "urlopen connect error with connecting to  FSEapi call, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						//logger.debug("urlopen connect error with connecting to  FSEapi call  is " + JSON.stringify(error));
						var ErrorTxt = " in service ffs_SendResponse urlopen connect error with connecting to  FSEapi call  is  " + JSON.stringify(error);
						ctx.setVariable("ErrorTxt", ErrorTxt);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error message while reading response ffs_SendResponse from FSE  api call, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									ILSctx.setVariable('ExitStatus', '0');
									ILSctx.setVariable('ExitDestination', FseRestoreVerifyUrl);
									ILSctx.setVariable('ExitDescription', session.parameters.ExitDescription);
								}
							});
						} else if (responseStatusCode == 401 || responseStatusCode == 403) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "ffs_007:error message while reading response from FSE  Api, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "ffs_007:Error returned while doing post for ffs_SendResponse fse api call :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode + " Unauthorized"
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', session.parameters.ErrorDescription);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
						else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "Error returned while doing post ffs_SendResponsefor  fse api call, details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "Error returned  ffs_SendResponse fse api call, details are :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			} catch (error) {
				var ctx = session.name("foa") || session.createContext("foa");
				ctx.setVariable("retry", 'yes');
				var errorinfo = "urlopen connect error with connecting to  FSEapi call, details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitDescription', errorinfo);
				ILSctx.setVariable('ExitStatus', '500');
				logger.error(errorinfo);
				var ErrorTxt = " in service ffs_SendResponse urlopen connect error with connecting to  FSEapi call  is  " + JSON.stringify(error);
				ctx.setVariable("ErrorTxt", ErrorTxt);
			}
		}//RestoreVerify
	}
});
