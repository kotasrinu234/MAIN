var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ms = require('multistep');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});



var ctx = session.name("gcc") || session.createContext("gcc");
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		if (incomingdata.CallBackData.ServiceName == 'CallRequest') {
			if (incomingdata.ErrorMessage === undefined) {
				if (incomingdata.GetCallsByJobResponse[0].CallCode == "404") {
					
					var numValue;
					if (!(incomingdata.CallBackData.Client == "EFO")) {
					numValue = 0	
					}
					else {
						
						numValue = incomingdata.CallBackData.Number
						
					}
					
					var attachobj =
					{
						"Task": {
							"@objectType": "Task",
							"@createOrUpdate": true,
							"Key": -1,
							"CallID": incomingdata.CallBackData.CallID,
							"Number": numValue,
							"OUGGetCalls": false
						},
						"ErrorOnNonExistingDictionaries": true,
						"TaskRequestedProperties": [
							"CallID",
							"Number"
						],
						"AssignmentRequestedProperties": [
							"Task",
							"Start",
							"Finish",
							"Engineers"
						]
					};

                    var FSEAttachCall;
					if (incomingdata.CallBackData.Client === "EFO") {
						var Auth = "Basic " + session.parameters.EFOTOKEN;
						FSEAttachCall = session.parameters.EFOProcessTaskEx;
						}
					else {
						var Auth = "Basic " + session.parameters.FSETOKEN;
						FSEAttachCall = session.parameters.FSEAttachCall;
					}

					
					ILSctx.setVariable('ExitDestination', FSEAttachCall);
					var FSECall = {
						target: FSEAttachCall,
						sslClientProfile: 'FSE_Client_Profile',
						method: 'POST',
						headers: {
							'Authorization': Auth,
						},
						contentType: 'application/json',
						data: attachobj
					};
					ctx.setVariable("ilsGetcustomercallExitpayload", FSECall.data);
					var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";
					try {
						urlopen.open(FSECall, function(error, response) {
							if (error) {
								// an error occurred during request sending or response header parsing
								var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitDescription', errorinfo);
								ILSctx.setVariable('ExitStatus', '500');
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								// read response data
								// get the response status code
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsJSON(function(error, responseData) {
										if (error) {
											// error while reading response or transferring data to Buffer
											var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											logger.error(errorinfo);
											ILSctx.setVariable('ExitDescription', errorinfo);
										}
										else {
											ILSctx.setVariable('ExitStatus', '0');
											ILSctx.setVariable('ExitDescription', session.parameters.GetCustomerNoCallExitDescription);
											ILSctx.setVariable('ExitDestination', FSEAttachCall);
											logger.debug("FSE call url open is success");
											ctx.setVariable("LogILSGetcustomercallExitpayload", "yes");
											ctx.setVariable("responseData", responseData);
										}
									})
								} else if (responseStatusCode == 401 || responseStatusCode == 403) {
									// Handle business error responses (HTTP 401 or 403)
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											// Handle error in reading response data
											var errorinfo = "ffs_002: Error returned from FSEAttachCall 'Authentication/Authentication Error', details are : " + info + "; error info :" + error;
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "ffs_002: Error returned from FSEAttachCall 'Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
											ILSctx.setVariable('ExitDescription', errorinfo);
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});
								}
								else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "failure in reading message from attach call, details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											hm.current.statusCode = responseStatusCode;
											var errorinfo = "Error returned from fse attach call, details are :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									})
								}
							}
						})
					} catch (error) {
						var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					}

				}
				else {

					var ops = ctx.getVariable("ops");
					var payload =
					{
						"Operations": ops,
						"OneTransaction": true,
						"ContinueOnError": true,
						"CreateOrUpdate": true
					};
					ctx.setVariable("payload", payload);
					ctx.setVariable("ilspayload", payload);
					var FSEGetCallsUrl;
					if (incomingdata.CallBackData.Client === "EFO") {
						var Auth = "Basic " + session.parameters.EFOTOKEN;
						FSEGetCallsUrl = session.parameters.EFOExecuteMultipleOperations;
						}
					else {
						var Auth = "Basic " + session.parameters.FSETOKEN;
						FSEGetCallsUrl = session.parameters.FSEGetCallsUrl;
					}

					ILSctx.setVariable('ExitDestination', FSEGetCallsUrl);
					var FSECall = {
						target: FSEGetCallsUrl,
						sslClientProfile: 'FSE_Client_Profile',
						method: 'POST',
						headers: {
							'Authorization': Auth,
						},
						contentType: 'application/json',
						data: payload
					};

					var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";
					try {
						urlopen.open(FSECall, function(error, response) {
							if (error) {
								// an error occurred during request sending or response header parsing
								var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitDescription', errorinfo);
								ILSctx.setVariable('ExitStatus', '500');
								logger.error(errorinfo);
								session.reject(errorinfo);

							} else {
								// read response data
								// get the response status code
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsJSON(function(error, responseData) {
										if (error) {
											// error while reading response or transferring data to Buffer
											var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											logger.error(errorinfo);
											ILSctx.setVariable('ExitDescription', errorinfo);
										}
										else {
											logger.debug("FSE call url open is success");
											ILSctx.setVariable('ExitStatus', '0');
											ILSctx.setVariable('ExitDescription', session.parameters.GetCustomerCreateCallExitDescription);
											ILSctx.setVariable('ExitDestination', FSEGetCallsUrl);
											ctx.setVariable("responseData", responseData);
											session.output.write(payload);
											ctx.setVariable("LogILSpayload", "yes");
											ms.callRule('ffs_SendResponse_Processing_Policy_ILSExitRule', null, null, function(error) {
												if (error) {
													logger.error("Error in ffs_SendResponse_Processing_Policy_ILSExitRule");
												}
											});
											var callsArray = incomingdata.GetCallsByJobResponse;
											var meterArray = [];
											var FSECallLimit = session.parameters.FSECallLimit
											for (var a = 0; a < callsArray.length; a++) {
												if (a >= FSECallLimit) {
													ctx.setVariable("MeterTestBreak", a)
													break;
												} else {
													var meter = {
														"MeterID": incomingdata.GetCallsByJobResponse[a].MeterID
													};
													meterArray.push(meter);
												}
											}
											
											var numValue;
					if (!(incomingdata.CallBackData.Client == "EFO")) {
						numValue = 0

					}
					else {
						numValue = incomingdata.CallBackData.Number
						
					}

											var attachobj =
											{
												"Task": {
													"@objectType": "Task",
													"@createOrUpdate": true,
													"Key": -1,
													"CallID": incomingdata.CallBackData.CallID,
													"Number": numValue,
													"OUGGetCalls": false,
													"OUGCustomerCalls": meterArray
												},
												"ReturnSchedulingError": true,
												"ReturnAssignment": false,
												"TaskRequestedProperties": [
													"CallID",
													"Number"
												],
												"AssignmentRequestedProperties": [
													"Task",
													"Start",
													"Finish",
													"Engineers"
												]
											};
											var FSEAttachCall ;
											if (incomingdata.CallBackData.Client === "EFO") {
												var Auth = "Basic " + session.parameters.EFOTOKEN;
												FSEAttachCall = session.parameters.EFOProcessTaskEx;
												}
											else {
												var Auth = "Basic " + session.parameters.FSETOKEN;
												FSEAttachCall = session.parameters.FSEAttachCall;
											}
											
											ILSctx.setVariable('ExitDestination', FSEAttachCall);
											var FSECall = {
												target: FSEAttachCall,
												sslClientProfile: 'FSE_Client_Profile',
												method: 'POST',
												headers: {
													'Authorization': Auth,
												},
												contentType: 'application/json',
												data: attachobj
											};
											 ctx.setVariable("ilsGetcustomercallExitpayload", FSECall.data);

											var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";
											try {
												urlopen.open(FSECall, function(error, response) {
													if (error) {
														// an error occurred during request sending or response header parsing
														var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
														ILSctx.setVariable('ExitDescription', errorinfo);
														ILSctx.setVariable('ExitStatus', '500');
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														// read response data
														// get the response status code
														var responseStatusCode = response.statusCode;
														if (responseStatusCode == 200) {
															response.readAsJSON(function(error, responseData) {
																if (error) {
																	// error while reading response or transferring data to Buffer
																	var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																	logger.error(errorinfo);
																	ILSctx.setVariable('ExitDescription', errorinfo);

																}
																else {
																	ILSctx.setVariable('ExitStatus', '0');
																	ILSctx.setVariable('ExitDestination', FSEAttachCall);
																	ILSctx.setVariable('ExitDescription', session.parameters.GetCustomerAttachCallExitDescription);
																	logger.debug("FSE call url open is success");
																    ctx.setVariable("LogILSGetcustomercallExitpayload", "yes");
																	ctx.setVariable("responseData", responseData);
																}
															})
														} else if (responseStatusCode == 401 || responseStatusCode == 403) {
															// Handle business error responses (HTTP 401 or 403)
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	// Handle error in reading response data
																	var errorinfo = "ffs_003: Error returned from FSEAttachCall 'Authentication/Authentication Error', details are : " + info + "; error info :" + error;
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "ffs_003: Error returned from FSEAttachCall 'Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
															});
														}
														else {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "failure in reading message from attach call, details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);

																} else {
																	hm.current.statusCode = responseStatusCode;
																	var errorinfo = "Error returned from attach call, details are :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
															})
														}
													}
												})
											} catch (error) {
												var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitDescription', errorinfo);
												ILSctx.setVariable('ExitStatus', '500');
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										}
									})
								} else if (responseStatusCode == 401 || responseStatusCode == 403) {
									// Handle business error responses (HTTP 401 or 403)
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											// Handle error in reading response data
											var errorinfo = "ffs_004: Error returned from FSEGetCallsUrl 'Authentication/Authentication Error', details are : " + info + "; error info :" + error;
											ILSctx.setVariable('ExitDescription', errorinfo);
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "ffs_004: Error returned from FSEGetCallsUrl 'Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
											ILSctx.setVariable('ExitDescription', errorinfo);
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									});
								}
								else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "failure in reading response from fse create call, details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											hm.current.statusCode = responseStatusCode;
											var errorinfo = "Error returned from fse create call, details are :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										}
									})
								}
							}
						})
					} catch (error) {
						var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitDescription', errorinfo);
						ILSctx.setVariable('ExitStatus', '500');
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				}
			}
		}
	}
})
