var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ms = require('multistep');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("gcc") || session.createContext("gcc");
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.reject("error reading input as JSON : " + readAsJSONError)
		session.reject("error reading input as JSON : " + readAsJSONError)
	}
	else {
		ctx.setVariable("inputJson", incomingdata)
		var LogILSpayload = ctx.getVariable("LogILSpayload")
		var ilspayload = ctx.getVariable("ilspayload")
		if (LogILSpayload === "yes") {
			session.output.write(ilspayload)
		}
		else {
			session.output.write(incomingdata);
		}
	}
})
