var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("gcc") || session.createContext("gcc");

var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var logger = console.options({
	'category': 'all'
});
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		ctx.setVariable("incomingdata", incomingdata)
		var payload = JSON.stringify(incomingdata);
		ctx.setVariable("payload", payload)
		var sourceEventTimestamp = new Date().toISOString();
		var sourceUrl = sm.getVar('var://service/URL-in');
		var EntryDescription = session.parameters.EntryDescription;

		if (!(incomingdata.CallBackData.messageID === undefined || incomingdata.CallBackData.messageID === null || incomingdata.CallBackData.messageID === '')) {
			ILSctx.setVariable('correlationID', incomingdata.CallBackData.messageID)
		} else {
			ILSctx.setVariable('correlationID', " ")
		}

		if (!(incomingdata.CallBackData.CallID === undefined || incomingdata.CallBackData.CallID === null || incomingdata.CallBackData.CallID === '')) {
			ILSctx.setVariable('crewAssignmentDisplayID', incomingdata.CallBackData.CallID)
		} else {
			ILSctx.setVariable('crewAssignmentDisplayID', " ")
		}
		if (incomingdata.CallBackData.ServiceName === 'CreateJobRequest') {
			ILSctx.setVariable('messageType', session.parameters.AdditionalWorkResponsemessageType)
		}
		if (incomingdata.CallBackData.ServiceName === 'TaskUpdate') {
			ILSctx.setVariable('messageType', session.parameters.TaskUpdateResponsemessageType)
		}
		if (incomingdata.CallBackData.ServiceName === 'ServiceAlert') {
			ILSctx.setVariable('messageType', session.parameters.ServiceAlertResponsemessageType)
		}

		if (incomingdata.CallBackData.ServiceName === 'CallRequest') {
			ILSctx.setVariable('messageType', session.parameters.GetCustomerCallmessageType)
		}
		if (incomingdata.CallBackData.ServiceName === 'RestoreVerify') {
			ILSctx.setVariable('messageType', session.parameters.RestoreVerifyResponsemessageType)
		}
		if (incomingdata.CallBackData.ServiceName === 'CrewRequest') {
			ILSctx.setVariable('messageType', session.parameters.ResoureRequestmessageType)
		}
		if (sourceEventTimestamp === null || sourceEventTimestamp === '' || sourceEventTimestamp === undefined) {
			ILSctx.setVariable("sourceEventTimestamp", '');
		}
		else {
			ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		if (sourceUrl === null || sourceUrl === '' || sourceUrl === undefined) {
			ILSctx.setVariable("sourceUrl", '');
		}
		else {
			ILSctx.setVariable("sourceUrl", sourceUrl);
		}
		if (EntryDescription !== undefined || EntryDescription !== null || EntryDescription !== '') {
			ILSctx.setVariable('EntryDescription', EntryDescription);
		}
		else {
			ILSctx.setVariable("EntryDescription", EntryDescription);
		}

	}
});
