var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');

var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("gcc") || session.createContext("gcc");
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		if (incomingdata.CallBackData.ServiceName == 'CallRequest') {
			if (incomingdata.ErrorMessage !== undefined) {
				var currentdate = new Date(),
					m = '' + (currentdate.getMonth() + 1),
					d = '' + currentdate.getDate(),
					y = currentdate.getFullYear();

				if (m.length < 2)
					m = '0' + m;
				if (d.length < 2)
					d = '0' + d;

				var req_format = [y, m, d].join('-');
				var finaldate = req_format + "T" + ("0" + currentdate.getHours()).slice(-2) + ":"
					+ ("0" + currentdate.getMinutes()).slice(-2) + ":"
					+ ("0" + currentdate.getSeconds()).slice(-2);

				var FixedErrorLength = parseInt(session.parameters.TaskUpdateErrorLength)
				var Message = JSON.stringify(incomingdata.ErrorMessage)
				var ErrorMessage = finaldate + " " + Message

				//ctx.setVariable("ErrorMessage", ErrorMessage)

				var ErrorMsglength = ErrorMessage.length
				ctx.setVariable("MSGLength", ErrorMsglength)
				if (ErrorMsglength > FixedErrorLength) {
					var TrimmedMsg = ErrorMessage.substring(0, FixedErrorLength);
					ctx.setVariable("TrimmedMsg", TrimmedMsg)
					ctx.setVariable("TrimmedErrorMsglength", TrimmedMsg.length)

				} else {
					var TrimmedMsg = ErrorMessage
					ctx.setVariable("WithoutTrimming", TrimmedMsg)

				}
				var payload =
				{
					"Task": {
						"@objectType": "Task",
						"@createOrUpdate": true,
						"CallID": incomingdata.CallBackData.CallID,
						"Number": incomingdata.CallBackData.Number,
						"ExternalRefID": incomingdata.CallBackData.ExternalRefID,
						"OUGErrorStatus": TrimmedMsg
						/*[
							{
								"DateReported": finaldate,
								"ErrorStatus": TrimmedMsg
							}
						]*/
					},
					"TaskRequestedProperties": [
						"CallID",
						"Number",
						"OUGEnergizationStatus",
						"EngineersOUGVerify",
						"OUGErrorStatus"
					],
					"ErrorOnNonExistingDictionaries": true
				}
				var FSEGetCallsErrorUrl;
				if (incomingdata.CallBackData.Client === "EFO") {
						var Auth = "Basic " + session.parameters.EFOTOKEN;
						FSEGetCallsErrorUrl =session.parameters.EFOProcessTaskEx;
						}
					else {
						var Auth = "Basic " + session.parameters.FSETOKEN;
						FSEGetCallsErrorUrl = session.parameters.ErrorUrl;
					}
				
				ILSctx.setVariable('ExitDestination', FSEGetCallsErrorUrl);
				var FSECall = {
					target: FSEGetCallsErrorUrl,
					sslClientProfile: 'FSE_Client_Profile',
					method: 'POST',
					headers: {
						'Authorization': Auth,
					},
					contentType: 'application/json',
					data: payload
				};
                 ctx.setVariable("ilsGetcustomercallExitpayload", FSECall.data);
					var info = " TargetURL :" + FSECall.target + "; Method :" + FSECall.method + "; Data :" + JSON.stringify(FSECall.data) + ". ";

				try {
					urlopen.open(FSECall, function(error, response) {
						if (error) {
							// an error occurred during request sending or response header parsing
							var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitDescription', errorinfo);
							ILSctx.setVariable('ExitStatus', '500');
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							// read response data
							// get the response status code
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										// error while reading response or transferring data to Buffer
										var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										logger.error(errorinfo);
										ILSctx.setVariable('ExitDescription', errorinfo);
									}
									else {
										//var description = session.parameters.GetCustomerCallErrorDescription;
										ILSctx.setVariable('ExitStatus', '0');
										ILSctx.setVariable('ExitDescription', session.parameters.ErrorDescription);
										ILSctx.setVariable('ExitDestination', FSEGetCallsErrorUrl);
										ctx.setVariable("LogILSGetcustomercallExitpayload", "yes");
										logger.debug("error successfully sent to FSE");
									}
								})
							}
							else if (responseStatusCode == 401 || responseStatusCode == 403) {
								// Handle business error responses (HTTP 401 or 403)
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										// Handle error in reading response data
										var errorinfo = "ffs_005: Error returned from ' ffs_GetCustomerCalls FSEGetCallsErrorUrl' 'Authentication/Authentication Error', details are : " + info + "; error info :" + error;
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var errorinfo = "ffs_005: Error returned from ' ffs_GetCustomerCalls FSEGetCallsErrorUrl' 'Authentication/Authentication Error', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
								})
							}
							else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure in reading message from FSECall, details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										hm.current.statusCode = responseStatusCode;
										var errorinfo = "Error returned from fse call, details are :" + info + "; responseinfo :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
								})
							}
						}
					})
				} catch (error) {
					var errorinfo = "urlopen connect error while doing FSECall, details are : " + info + "; error info :" + error
					ILSctx.setVariable('ExitDescription', errorinfo);
					ILSctx.setVariable('ExitStatus', '500');
					logger.error(errorinfo);
					session.reject(errorinfo);
				}

			}
			else {
				var callsArray = incomingdata.GetCallsByJobResponse;
				if (incomingdata.GetCallsByJobResponse[0].CallCode !== "404") {
					let opsArray = [];
					var timeArray = [];
					var FSECallLimit = session.parameters.FSECallLimit
					for (let a = 0; a < callsArray.length; a++) {
						//	for (let b = 0; b < FSECallLimit; b++) {
						if (a >= FSECallLimit) {
							ctx.setVariable("CallTestBreak", a)
							break;
						} else {
							let ops = {
								"Action": "CreateOrUpdate",
								"Object": {
									"@objectType": "OUGCustomerCall",
									"@createOrUpdate": "true",
									"CallCode": incomingdata.GetCallsByJobResponse[a].CallCode,
									"CustomerAddress": incomingdata.GetCallsByJobResponse[a].CustomerAddress,
									"CustomerName": incomingdata.GetCallsByJobResponse[a].CustomerName,
									"CustomerPhone": incomingdata.GetCallsByJobResponse[a].CustomerPhone,
									"MeterID": incomingdata.GetCallsByJobResponse[a].MeterID,
									//"Observations": incomingdata.GetCallsByJobResponse[a].Observations,
									//"Timestamp": OUGFieldTime
								}
							};
							opsArray.push(ops);
							ctx.setVariable("ops", opsArray);
							ctx.setVariable("TotalAttachCalls", opsArray.length)
						}


						/*	var time = {
								"fieldName": "GetCallsByJobResponse.Timestamp",
								"fromDateTime" : incomingdata.GetCallsByJobResponse[a].Timestamp
							};
							//timeArray.push(time);
							
						
						//ctx.setVariable("timeStamp", timeArray);
						var timePayload = {
							"DateConversion": {
								"action": "1",
								"dateList": [time]
							}
						};
						var TimeConvertorurl = session.parameters.ffs_ConvertTimeURL;
						var TimeConvertorcall = {
							target: TimeConvertorurl,
							method: 'POST',
							contentType: 'application/json',
							data: timePayload
						 };
						urlopen.open(TimeConvertorcall, function(error, response) {
							if (error) {
								logger.error(" urlopen connect error with connecting to ffs_ConvertTime from ffs_ReceiveRequest is api " + JSON.stringify(error));
								session.reject("urlopen connect error with connecting to ffs_ConvertTime from ffs_ReceiveRequest is api " + JSON.stringify(error));
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200 )  {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											logger.error(" error message while reading response from ffs_ConvertTime in ffs_ReceiveRequest service is " + JSON.stringify(error));
											session.reject(" error message while reading response from ffs_ConvertTime in ffs_ReceiveRequest service is " + JSON.stringify(error));
										} else {
											hm.response.statusCode = responseStatusCode;
											var OUGFieldTimeResponse = JSON.parse(responseData);
											var OUGFieldTime = OUGFieldTimeResponse.DateConversion.dateList[0].toDateTime;
											//ops.Timestamp = OUGFieldTime;
							
									
										}
									})
								}
								else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
	
											logger.error("failure in reading response from attach call " + JSON.stringify(error));
											session.reject("failure in reading response from attach call ");
										} else {
	
											hm.current.statusCode = responseStatusCode;
											logger.error("Error returned from fse attach call " + ": with statusCode " + responseStatusCode + " " + responseData);
											session.reject("Error returned from fse attach call " + ": with statusCode " + responseStatusCode + " " + responseData);
										}
									})
								}
							}
					
						})*/
					}

				}

			}
		}
	}
})
