var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var ms = require('multistep');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("gcc") || session.createContext("gcc");
var ILSctx = session.name('ILS') || session.createContext('ILS');

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("error reading input as JSON : " + readAsJSONError)
		session.reject("error reading input as JSON : " + readAsJSONError)
	}
	else {
		var LogILSGetcustomercallExitpayload = ctx.getVariable("LogILSGetcustomercallExitpayload")
		var ilsGetcustomercallExitpayload = ctx.getVariable("ilsGetcustomercallExitpayload")
		if (LogILSGetcustomercallExitpayload === "yes") {
			session.output.write(ilsGetcustomercallExitpayload)
		}
		else {
			session.output.write(incomingdata);
		}
	}
})
