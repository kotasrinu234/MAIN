var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var crewAssignmentID;
		var crewAssignmentDisplayID;
		var jobID;
		var crewDisplayID;
		var assignmentStatus;
		var sourceEventTimestamp;
		var correlationID;
		var messageType;
		var Entrydescription = session.parameters.Entrydescription;
		var urlIn = sm.getVar('var://service/URL-in');
		ILSctx.setVariable("sourceUrl", urlIn);
		if (incomingdata.CallBackData.messageID === undefined || incomingdata.CallBackData.messageID === null || incomingdata.CallBackData.messageID === '') {
			ILSctx.setVariable("correlationID", "")
		} else {
			correlationID = incomingdata.CallBackData.messageID
			ILSctx.setVariable("correlationID", correlationID);
		}
		if (incomingdata.CallBackData.ServiceName === undefined || incomingdata.CallBackData.ServiceName === null || incomingdata.CallBackData.ServiceName === '') {
			ILSctx.setVariable("messageType", "")
		} else {
			messageType = incomingdata.CallBackData.ServiceName + "Event";
			ILSctx.setVariable("messageType", messageType);
		}
		if (incomingdata.TaskUpdate.CrewAssignmentIDGUID === undefined || incomingdata.TaskUpdate.CrewAssignmentIDGUID === null || incomingdata.TaskUpdate.CrewAssignmentIDGUID === '') {
			ILSctx.setVariable("crewAssignmentID", "")
		} else {
			crewAssignmentID = incomingdata.TaskUpdate.CrewAssignmentIDGUID
			ILSctx.setVariable("crewAssignmentID", crewAssignmentID);
		}
		if (incomingdata.CallBackData.CallID === undefined || incomingdata.CallBackData.CallID === null || incomingdata.CallBackData.CallID === '') {
			ILSctx.setVariable("crewAssignmentDisplayID", " ");
		} else {
			crewAssignmentDisplayID = incomingdata.CallBackData.CallID
			ILSctx.setVariable("crewAssignmentDisplayID", crewAssignmentDisplayID);
		}
		if (incomingdata.TaskUpdate.JobIDGUID === undefined || incomingdata.TaskUpdate.JobIDGUID === null || incomingdata.TaskUpdate.JobIDGUID === '') {
			ILSctx.setVariable("jobID", " ");
		} else {
			jobID = incomingdata.TaskUpdate.JobIDGUID
			ILSctx.setVariable("jobID", jobID);
		}
		if (incomingdata.TaskUpdate.CrewGUID === undefined || incomingdata.TaskUpdate.CrewGUID === null || incomingdata.TaskUpdate.CrewGUID === '') {
			ILSctx.setVariable("crewDisplayID", " ");
		} else {
			crewDisplayID = incomingdata.TaskUpdate.CrewGUID
			ILSctx.setVariable("crewDisplayID", crewDisplayID);
		}
		if (incomingdata.TaskUpdate.CrewAssignmentStatus === undefined || incomingdata.TaskUpdate.CrewAssignmentStatus === null || incomingdata.TaskUpdate.CrewAssignmentStatus === '') {
			ILSctx.setVariable("assignmentStatus", " ");
		} else {
			assignmentStatus = incomingdata.TaskUpdate.CrewAssignmentStatus
			ILSctx.setVariable("assignmentStatus", assignmentStatus);
		}
		if (incomingdata.CallBackData.TimeModified === undefined || incomingdata.CallBackData.TimeModified === null || incomingdata.CallBackData.TimeModified === '') {
			ILSctx.setVariable("sourceEventTimestamp", " ");
		} else {
			sourceEventTimestamp = incomingdata.CallBackData.TimeModified
			ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		if (Entrydescription === undefined || Entrydescription === null || Entrydescription === "") {
			ILSctx.setVariable('Entrydescription', " ");
		} else {
			ILSctx.setVariable('Entrydescription', Entrydescription);
		}
	}
});
