var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.INPUT.readAsBuffer(function(readAsBufferError, BufferData) {
	if (readAsBufferError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsBufferError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsBufferError));
	} else {
		var incomingdata = JSON.parse(BufferData);
		var ACEMQUrl = session.parameters.ACEMQUrl
		ILSctx.setVariable("exitDestination", ACEMQUrl);
		var deflatedPayload = ctx.getVariable("deflatedPayload");
		var dateTime = new Date();
		var Exitdescription = session.parameters.Exitdescription;

		var payload = {
			"serviceName": "workOrderFSEUpdate",
			"expiry": session.parameters.Expiry,
			"eventType": "Status",
			"payload": deflatedPayload,
			"sendTimeStamp": dateTime.toISOString(),
			"waitTime": session.parameters.WaitTime,
			"destQueueName": "OMSAPITASK.UPDATE.SEQ"
		};
		if (incomingdata.CallBackData.messageID === undefined || incomingdata.CallBackData.messageID === null || incomingdata.CallBackData.messageID === "") {
		} else {
			payload.messageId = incomingdata.CallBackData.messageID
		}
		if (incomingdata.CallBackData.CallID === undefined || incomingdata.CallBackData.CallID === null || incomingdata.CallBackData.CallID === "") {
		} else {
			payload.eventContext = incomingdata.CallBackData.CallID
		}
		if (incomingdata.CallBackData.TimeModified === undefined || incomingdata.CallBackData.TimeModified === null || incomingdata.CallBackData.TimeModified === "") {
		} else {
			payload.EventTimeStamp = incomingdata.CallBackData.TimeModified + "Z"
		}
		if (incomingdata.TaskUpdate.CrewAssignmentIDGUID === undefined || incomingdata.TaskUpdate.CrewAssignmentIDGUID === null || incomingdata.TaskUpdate.CrewAssignmentIDGUID === "") {
		} else {
			payload.crewAssignmentID = incomingdata.TaskUpdate.CrewAssignmentIDGUID
		}
		if (incomingdata.CallBackData.CallID === undefined || incomingdata.CallBackData.CallID === null || incomingdata.CallBackData.CallID === "") {
		} else {
			payload.crewAssignmentDisplayID = incomingdata.CallBackData.CallID
		}
		if (incomingdata.TaskUpdate.JobIDGUID === undefined || incomingdata.TaskUpdate.JobIDGUID === null || incomingdata.TaskUpdate.JobIDGUID === "") {
		} else {
			payload.jobID = incomingdata.TaskUpdate.JobIDGUID
		}
		if (incomingdata.TaskUpdate.CrewGUID === undefined || incomingdata.TaskUpdate.CrewGUID === null || incomingdata.TaskUpdate.CrewGUID === "") {
		} else {
			payload.crewDisplayID = incomingdata.TaskUpdate.CrewGUID
		}
		if (incomingdata.TaskUpdate.CrewAssignmentStatus === undefined || incomingdata.TaskUpdate.CrewAssignmentStatus === null || incomingdata.TaskUpdate.CrewAssignmentStatus === "") {
		} else {
			payload.assignmentStatus = incomingdata.TaskUpdate.CrewAssignmentStatus
		}
		if (incomingdata.CallBackData.ServiceName === undefined || incomingdata.CallBackData.ServiceName === null || incomingdata.CallBackData.ServiceName === "") {
		} else {
			payload.messageType = incomingdata.CallBackData.ServiceName + 'Event'
		}
		if (incomingdata.CallBackData.CallID === undefined || incomingdata.CallBackData.CallID === null || incomingdata.CallBackData.CallID === "") {
		} else {
			payload.eventKey = incomingdata.CallBackData.CallID
		}
		var PropertiesChanged = incomingdata.TaskUpdate.PropertiesChanged;
		var PropertiesChangedSplit = PropertiesChanged.split(',');



		if (PropertiesChangedSplit.includes("Status")) {
			if (!(incomingdata.TaskUpdate.CrewAssignmentIDGUID === undefined || incomingdata.TaskUpdate.CrewAssignmentIDGUID === null || incomingdata.TaskUpdate.CrewAssignmentIDGUID === "")) {
				var OMSURL = session.parameters.OMSURL
				var GetWorkTypeIDURL = OMSURL + '/api/ServiceType/Electric/CrewAssignment/' + incomingdata.TaskUpdate.CrewAssignmentIDGUID + '?includeFields=workTypeID'
				var GetWorkTypeID = {
					target: GetWorkTypeIDURL,
					sslClientProfile: 'omsapi_client_profile',
					method: 'GET',
					contentType: 'application/json',
					headers: {
						'osiApiToken': session.parameters.Token
					}
				};
				var info = " TargetURL :" + GetWorkTypeID.target + "; Method :" + GetWorkTypeID.method + ". ";
				urlopen.open(GetWorkTypeID, function(error, response) {
					if (error) {
						var errorinfo = "TaskUpdate_Seq01 : url connection error 'StatusUpdate GetWorkTypeID', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('Exitdescription', errorinfo);
						ctx.setVariable("retry", 'yes');
						ctx.setVariable("ErrorTxt", errorinfo);
						logger.error(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'GetWorkTypeID', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('Exitdescription', errorinfo);
									logger.error(errorinfo);
									ctx.setVariable("ErrorTxt", errorinfo);
									ctx.setVariable("retry", 'yes');
								} else {
									hm.response.statusCode = '200 OK';
									var workTypeID = responseData.workTypeID;
									var LabelLookUp = {
										"lookupReq": {
											"type": [
												{
													"name": "workTypes",
													"id": workTypeID,
													"status": 'none'
												}
											]
										}
									};
									var LabelLookUpCall = {
										target: session.parameters.lookupUrl,
										method: 'POST',
										contentType: 'application/json',
										data: LabelLookUp
									};
									var info = " TargetURL :" + LabelLookUpCall.target + "; Method :" + LabelLookUpCall.method + "; Data :" + JSON.stringify(LabelLookUpCall.data) + ". ";
									urlopen.open(LabelLookUpCall, function(error, response) {
										if (error) {
											var errorinfo = "TaskUpdate_Seq02 : url connection error 'Label LookUp', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', '500');
											ILSctx.setVariable('Exitdescription', errorinfo);
											logger.error(errorinfo);
											ctx.setVariable("ErrorTxt", errorinfo);
											ctx.setVariable("retry", 'yes');
										} else {
											var responseStatusCode = response.statusCode;
											if (responseStatusCode == 200) {
												response.readAsJSON(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'Label LookUp', details are : " + info + "; error info :" + error
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('Exitdescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														hm.response.statusCode = '200 OK';
														logger.debug("response received from LookUp of Status :" + responseData);
														//		ctx.setVariable("StatusResponseData", responseData);
														if (responseData.lookupRep.type[0].result == 1) {
															var invalidresp = "Invalid Lookup Request 'Label LookUp', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
															ILSctx.setVariable('ExitStatus', '1');
															ILSctx.setVariable('Exitdescription', invalidresp);
															logger.error(invalidresp);
															session.reject(invalidresp)
														} else {
															if (!(responseData.lookupRep.type[0].label === undefined || responseData.lookupRep.type[0].label === '')) {
																payload.workFlowType = responseData.lookupRep.type[0].label;
																payload.workFlowRequirementEvent = 'N'
																QueueCall(ACEMQUrl, payload)
															} else {
																var invalidresp = "TaskUpdate_Seq03 : Invalid Lookup Request 'Label LookUp', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('Exitdescription', invalidresp);
																logger.error(invalidresp);
																session.reject(invalidresp)
															}
														}
													}
												})
											} else {
												response.readAsBuffer(function(error, responseData) {
													if (error) {
														var errorinfo = "error reading response 'Label LookUp', details are : " + info + "; error info :" + error
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('Exitdescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo);
													} else {
														var errorinfo = "error response 'Label LookUp', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('Exitdescription', errorinfo);
														hm.current.statusCode = responseStatusCode;
														logger.error(errorinfo);
														ctx.setVariable("ErrorTxt", errorinfo);
														ctx.setVariable("retry", 'yes');
													}
												});
											}
										}
									});
								}
							})
						} else if ((responseStatusCode == 400) || (responseStatusCode == 404) || (responseStatusCode == 401)) {
							if (responseStatusCode == 401) {
								var errorinfo = "error response 'GetWorkTypeID', details are : ' Unauthorized '" + "; Response : " + JSON.stringify(response)
								ILSctx.setVariable('ExitStatus', responseStatusCode);
								ILSctx.setVariable('Exitdescription', errorinfo)
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								response.readAsBuffer(function(error, BusinessResponseData) {
									if (error) {
										var errorinfo = "error reading response 'GetWorkTypeID', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('Exitdescription', errorinfo)
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var BusinessResponseData = BusinessResponseData;
										var buff = Buffer.from(BusinessResponseData);
										var ResponseString = buff.toString();
										var errorinfo = "error response 'GetWorkTypeID', details are : " + info + "; response info :" + ResponseString + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('Exitdescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo)
									}
								});
							}
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'GetWorkTypeID', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('Exitdescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "TaskUpdate_Seq05 : error response 'GetWorkTypeID', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									responseData = responseData.toString()
									if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
										var ErrorTxt = "TaskUpdate_Seq05 : error response 'GetWorkTypeID', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
									} else {
										var ErrorTxt = errorinfo
									}
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('Exitdescription', errorinfo);
									hm.current.statusCode = responseStatusCode;
									ctx.setVariable("retry", 'yes');
									ctx.setVariable("ErrorTxt", ErrorTxt);
									logger.error(errorinfo);
								}
							});
						}

					}
				});
			}
		} else {
			payload.waitTimeWorkFlow = 'Y'
			QueueCall(ACEMQUrl, payload)
		}
		ctx.setVariable("payload", payload);

		function QueueCall(url, payload) {
			try {
				var pushingToQueue = {
					target: url,
					data: payload
				};
				var info = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";
				urlopen.open(pushingToQueue, function(error, response) {
					var hm = require('header-metadata');
					if (error) {
						var errorinfo = "TaskUpdate_Seq04 : url connection error 'Sequencing SEQ.REQUEST', details are : " + info + "; error info :" + error
						ILSctx.setVariable("exitStatus", "500")
						ILSctx.setVariable("Exitdescription", errorinfo)
						logger.error(errorinfo);
						ctx.setVariable("retry", 'yes');
						ctx.setVariable("ErrorTxt", errorinfo);
					} else {
						var mqrc = response.statusCode;
						if (mqrc == 0) {
							var replyMQMD = response.get({
								type: 'mq'
							}, 'MQMD');
							var replyMQRFH2 = response.get({
								type: 'mq'
							}, 'MQRFH2');
							response.readAsBuffer(function(readError, responseData) {
								if (readError) {
									var errorinfo = "error reading response 'Sequencing SEQ.REQUEST', details are : " + info + "; error info :" + readError
									ILSctx.setVariable("exitStatus", "500")
									ILSctx.setVariable("Exitdescription", errorinfo)
									hm.response.statusCode = 500
									//session.reject(errorinfo);
								} else {
									logger.debug("MQResponsecode " + mqrc);
									ILSctx.setVariable("exitStatus", "0")
									ILSctx.setVariable('Exitdescription', Exitdescription);
								}
							});
						} else {
							var errorinfo = "error response 'Sequencing SEQ.REQUEST', details are : " + info + "; response info :" + response + "; ResponseStatusCode :" + response.statusCode
							ILSctx.setVariable("exitStatus", "500")
							ILSctx.setVariable("Exitdescription", errorinfo)
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
						}
					}
				})
			} catch (err) {
				var errorinfo = "TaskUpdate_Seq04 : url connection error 'Sequencing SEQ.REQUEST', details are : " + info + "; error info :" + err
				ILSctx.setVariable("exitStatus", "500")
				ILSctx.setVariable("Exitdescription", errorinfo)
				ctx.setVariable("ErrorTxt", errorinfo);
				ctx.setVariable("retry", 'yes');
				logger.error(errorinfo)
			}
		}
	}
})
