var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});

session.INPUT.readAsBuffer(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		
		
var BackoutURL = "dpmq://omsapitask_TaskUpdate_sequence_Qmgr/?RequestQueue=OMSAPITASK.UPDATE.BACKOUT";
var sendBackout = {
	target: BackoutURL,
	data: incomingdata
};
try {
	urlopen.open(sendBackout, function(error, response) {
		var hm = require('header-metadata');
		if (error) {
			logger.error("url open error in sending the msg to the backuout queue");
			session.reject("url open error in sending the msg to the backuout queue");
		} else {
			var mqrc = response.statusCode;
			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						hm.response.statusCode = 403
						logger.error("error");
						session.reject(readError);
					} else {
						//ctx.setVar("response", "send to the queue");
					}
				});
			} else {
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						logger.error("error");
						session.reject("error");
					} else {
						logger.error("error");
						session.reject("error");
					}
				});
			}
		}
	});
} catch (error) {
	logger.error("error");
    session.reject("error");
}
		
		
	}
});