var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var ILSctx = session.name('ILS') || session.createContext('ILS');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var incomingdata = incomingdata;
		var Entrydescription = session.parameters.ReceiveEntrydescription;
		ILSctx.setVariable("Entrydescription", Entrydescription);
		var StandaloneMQurl = session.parameters.MQUrl;
		var CrewStatusQueue = session.parameters.CrewURL;
		var urlIn = sm.getVar('var://service/URL-in');
		ILSctx.setVariable("sourceUrl", urlIn);
		var externalRefId = incomingdata.CallBackData.ExternalRefID;
		if (externalRefId !== undefined) {
			var Ids = externalRefId.split(':');
		}
		var type = incomingdata.CallBackData.ServiceName;

		if (incomingdata.CallBackData.messageID === undefined || incomingdata.CallBackData.messageID === null || incomingdata.CallBackData.messageID === "") {
			ILSctx.setVariable('correlationID', " ")
		} else {
			ILSctx.setVariable('correlationID', incomingdata.CallBackData.messageID)
		}
		if (incomingdata.CallBackData.ServiceName === undefined || incomingdata.CallBackData.ServiceName === null || incomingdata.CallBackData.ServiceName === '') {
			ILSctx.setVariable("messageType", " ")
		} else {
			var messageType = incomingdata.CallBackData.ServiceName + "Event";
			ILSctx.setVariable("messageType", messageType);
		}
		if (type === 'TaskUpdate') {
			var TaskExitdescription = session.parameters.ReceiveTaskExitdescription;
			ILSctx.setVariable("Exitdescription", TaskExitdescription);
			if (incomingdata.TaskUpdate.CrewAssignmentIDGUID === undefined || incomingdata.TaskUpdate.CrewAssignmentIDGUID === null || incomingdata.TaskUpdate.CrewAssignmentIDGUID === '') {
				ILSctx.setVariable("crewAssignmentID", " ")
			} else {
				var crewAssignmentID = incomingdata.TaskUpdate.CrewAssignmentIDGUID
				ILSctx.setVariable("crewAssignmentID", crewAssignmentID);
			}
			if (incomingdata.CallBackData.CallID === undefined || incomingdata.CallBackData.CallID === null || incomingdata.CallBackData.CallID === '') {
				ILSctx.setVariable("crewAssignmentDisplayID", " ");
			} else {
				var crewAssignmentDisplayID = incomingdata.CallBackData.CallID
				ILSctx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID);
			}
			if (incomingdata.TaskUpdate.JobIDGUID === undefined || incomingdata.TaskUpdate.JobIDGUID === null || incomingdata.TaskUpdate.JobIDGUID === '') {
				ILSctx.setVariable("jobID", " ");
			} else {
				var jobID = incomingdata.TaskUpdate.JobIDGUID
				ILSctx.setVariable("jobID", jobID);
			}
			if (incomingdata.TaskUpdate.CrewGUID === undefined || incomingdata.TaskUpdate.CrewGUID === null || incomingdata.TaskUpdate.CrewGUID === "") {
				ILSctx.setVariable('crewDisplayID', " ")
			} else {
				var crewDisplayID = incomingdata.TaskUpdate.CrewGUID
				ILSctx.setVariable('crewDisplayID', crewDisplayID)
			}
			if (incomingdata.TaskUpdate.CrewAssignmentStatus === undefined || incomingdata.TaskUpdate.CrewAssignmentStatus === null || incomingdata.TaskUpdate.CrewAssignmentStatus === '') {
				ILSctx.setVariable("assignmentStatus", " ");
			} else {
				var assignmentStatus = incomingdata.TaskUpdate.CrewAssignmentStatus
				ILSctx.setVariable("assignmentStatus", assignmentStatus);
			}
			if (incomingdata.CallBackData.TimeModified === undefined || incomingdata.CallBackData.TimeModified === null || incomingdata.CallBackData.TimeModified === '') {
				ILSctx.setVariable("sourceEventTimestamp", " ");
			} else {
				var sourceEventTimestamp = incomingdata.CallBackData.TimeModified
				ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
			}
			if (StandaloneMQurl === undefined || StandaloneMQurl === null || StandaloneMQurl === "") {
				ILSctx.setVariable('exitDestination', " ");
			} else {
				ILSctx.setVariable('exitDestination', StandaloneMQurl);
			}
		}
		else if (type === 'CrewStatusUpdate') {
			var CrewExitdescription = session.parameters.ReceiveCrewExitdescription
			ILSctx.setVariable("Exitdescription", CrewExitdescription);
			if (externalRefId === undefined || externalRefId === null || externalRefId === "") {
				ILSctx.setVariable('crewAssignmentID', " ");
				ILSctx.setVariable('jobID', "");
			} else {
				ILSctx.setVariable('crewAssignmentID', Ids[1]);
				ILSctx.setVariable('jobID', Ids[0]);
			}
			if (incomingdata.CrewStatusUpdate.CrewID === undefined || incomingdata.CrewStatusUpdate.CrewID === null || incomingdata.CrewStatusUpdate.CrewID === "") {
				ILSctx.setVariable('crewDisplayID', " ")
			} else {
				ILSctx.setVariable('crewDisplayID', incomingdata.CrewStatusUpdate.CrewID)
			}
			if (CrewStatusQueue === undefined || CrewStatusQueue === null || CrewStatusQueue === "") {
				ILSctx.setVariable('exitDestination', " ");
			} else {
				ILSctx.setVariable('exitDestination', CrewStatusQueue);
			}
			if (incomingdata.CallBackData.TimeModified === undefined || incomingdata.CallBackData.TimeModified === null || incomingdata.CallBackData.TimeModified === '') {
				ILSctx.setVariable("sourceEventTimestamp", " ");
			} else {
				var sourceEventTimestamp = incomingdata.CallBackData.TimeModified
				ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
			}
		}
	}
});