//js is used to push message to standalone queue
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
var urlIn = sm.getVar('var://service/URL-in');
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
	var StandaloneMQurl = session.parameters.MQUrl;
	var CrewStatusQueue = session.parameters.CrewURL;
	if (urlIn.includes('CrewStatus')) {
		sendToQueue(CrewStatusQueue, incomingdata);
	} else {
		sendToQueue(StandaloneMQurl, incomingdata);
	}
});

function sendToQueue(targetQueue, incomingdata) {
	var pushingToQueue = {
		target: targetQueue,
		data: incomingdata
	};
	var info = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";

	try {
		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error 'OMSAPITASK.UPDATE Queue', details are : " + info + "; error info :" + error
				ILSctx.setVariable("exitStatus", "500")
				ILSctx.setVariable("Exitdescription", errorinfo)
				var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "error reading response 'OMSAPITASK.UPDATE Queue', details are : " + info + "; error info :" + readError
							ILSctx.setVariable("exitStatus", "500")
							ILSctx.setVariable("Exitdescription", errorinfo)
							hm.response.statusCode = 500
							session.reject(errorinfo);
						} else {
							logger.debug("MQResponsecode " + mqrc);
							ILSctx.setVariable('exitStatus', '0');
						}
					});
				} else {
					var errorinfo = "error response 'OMSAPITASK.UPDATE Queue', details are : " + info + "; response info :" + JSON.stringify(response)+ "; ResponseStatusCode :" + response.statusCode
					var ctx = session.name("foa") || session.createContext("foa");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					ILSctx.setVariable("exitStatus", "500")
					ILSctx.setVariable("Exitdescription", errorinfo)
					logger.error("TaskUpdate_001 : " + errorinfo);
					session.reject(errorinfo);
				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error 'OMSAPITASK.UPDATE Queue', details are : " + info + "; error info :" + err
		ILSctx.setVariable("exitStatus", "500")
		ILSctx.setVariable("Exitdescription", errorinfo)
		var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
		var mqconnection = 'Forbidden';
		ctx.setVariable("mqconnection", mqconnection);
		logger.error(errorinfo);
		session.reject(errorinfo);
	}
}
