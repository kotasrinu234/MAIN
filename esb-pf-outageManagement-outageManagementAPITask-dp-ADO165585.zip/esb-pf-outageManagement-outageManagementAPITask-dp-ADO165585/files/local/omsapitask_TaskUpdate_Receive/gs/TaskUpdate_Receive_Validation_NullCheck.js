//js is used to perform nullcheck for the input request
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var urlIn = sm.getVar('var://service/URL-in');
session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		if (urlIn.includes('CrewStatus')) {
			ctx.setVariable("incoming", incomingData);
		} else {

			var Attachments = incomingData.TaskUpdate.Attachments;
			var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
			var ExternalRefID = incomingData.CallBackData.ExternalRefID;

			if (ExternalRefID === null || ExternalRefID === '' || ExternalRefID === undefined) {
				logger.error('ExternalRefID is not present in input  payload');
				ctx.setVariable("schemafailed", 'yes')
				session.reject('ExternalRefID is not present in input  payload');
			}

			if (Attachments === null || Attachments === undefined || Attachments === '') {
			} else {
				for (var i = 0; i < Attachments.length; i++) {
					if ((Attachments[i].ExternalKey_SO === null) || (Attachments[i].ExternalKey_SO === '') || (Attachments[i].ExternalKey_SO === undefined)) {
						logger.error('ExternalKey_SO is not present in input  payload');
						ctx.setVariable("schemafailed", 'yes')
						session.reject('ExternalKey_SO is not present in input  payload');
					}
				}
			}
			if (PropertiesChanged === null || PropertiesChanged === '' || PropertiesChanged === undefined) {
				logger.error('PropertiesChanged is not present in input  payload');
				ctx.setVariable("schemafailed", 'yes')
				session.reject('PropertiesChanged is not present in input  payload');
			}
		}
	}
});
