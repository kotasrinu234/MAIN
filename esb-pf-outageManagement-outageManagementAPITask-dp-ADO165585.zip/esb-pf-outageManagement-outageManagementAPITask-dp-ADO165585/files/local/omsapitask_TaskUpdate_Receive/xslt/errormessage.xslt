<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" version="1.0" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
	
	<xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
	<xsl:variable name="systemErrorMessage" select="dp:variable('var://service/error-message')"/>
     
	<xsl:template match="/">
		
		<json:object xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx" xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">
					<json:string name="errorCode">
						<xsl:value-of select="$systemErrorCode"/>
					</json:string>
					<json:string name="errorDescription">
						<xsl:value-of select="$systemErrorMessage"/>
					</json:string>
		</json:object>
		<xsl:variable name="errorMessage" select="dp:variable('var://service/error-message')"/>
		<xsl:choose>
					<xsl:when test="contains(dp:variable('var://context/TaskUpdate/schemafailed'),'yes') and contains(dp:variable('var://service/error-code'),'0x00d30003' )">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'400'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Request'" />
						<dp:set-variable name="'var://context/ILS/exitStatus'" value="'400'"/>
					</xsl:when>
				<!--  	<xsl:when test="contains(dp:variable('var://context/TaskUpdate/mqconnection'),'Forbidden') and contains(dp:variable('var://service/error-code'),'0x00d30003')">
						<dp:set-variable name="'var://service/error-protocol-response'" value="'502'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Bad Gateway'" />
						<dp:set-variable name="'var://context/ILS/exitStatus'" value="'502'"/>
					</xsl:when> -->
					<xsl:otherwise>
						<dp:set-variable name="'var://service/error-protocol-response'" value="'500'" />
						<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Interval Server Error (General Error)'" />
					</xsl:otherwise>
			</xsl:choose>
		<dp:set-http-request-header name="'Content-Type'" value="'application/json'"/>
	</xsl:template>
</xsl:stylesheet>	
