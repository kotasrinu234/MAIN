var ctx = session.name("TaskUpdate_UploadAttachment") || session.createContext("TaskUpdate_UploadAttachment");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var AmazonURL = session.parameters.BackEndUrl;
ILSctx.setVariable("exitDestination", AmazonURL)
session.input.readAsJSON(function(readAsJSONError, requestJson) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		var JobIDGUID = requestJson.TaskUpdate.JobIDGUID;
		var Attachments = requestJson.TaskUpdate.Attachments;
		var messageId = requestJson.CallBackData.messageID;
		var timeModified = requestJson.CallBackData.TimeModified;
		var callID = requestJson.CallBackData.CallID;
		for (let i = 0; i < Attachments.length; i++) {
			var payload = {
				"asyncReplyFlag": true,
				"downloadType": 1,
				"checkForDup": true,
				"messageId": messageId,
				"callID": callID,
				"timeModified": timeModified,
				"id": JobIDGUID,
				"url": Attachments[i].ExternalURL_SO,
				"fileName": Attachments[i].FileName,
				"userId": session.parameters.userId
			}
			var AmazonImageUpload = {
				target: AmazonURL,
				sslClientProfile: 'omsapitask_TaskUpdate_IIB_ClientProfile',
				method: 'POST',
				contentType: 'application/json',
				data: payload
			};
			var info = " TargetURL :" + AmazonImageUpload.target + "; Method :" + AmazonImageUpload.method + "; Data :" + JSON.stringify(AmazonImageUpload.data) + ". ";

			try {
				urlopen.open(AmazonImageUpload, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'UploadAttachment', details are : " + info + "; error info :" + error
						ILSctx.setVariable('exitStatus', '500');
						ILSctx.setVariable("Exitdescription", errorinfo);
						logger.error("TaskUpdate_057 : " + errorinfo);
						session.reject(errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'UploadAttachment', details are : " + info + "; error info :" + error
									ILSctx.setVariable('exitStatus', '500');
									ILSctx.setVariable("Exitdescription", errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									ILSctx.setVariable("exitStatus", "0");
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'UploadAttachment', details are : " + info + "; error info :" + error
									ILSctx.setVariable('exitStatus', '500');
									ILSctx.setVariable("Exitdescription", errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error response 'UploadAttachment', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('exitStatus', '500');
									ILSctx.setVariable("Exitdescription", errorinfo);
									logger.error("TaskUpdate_058 : " + errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				})
			} catch (err) {
				var errorinfo = "url connection error 'UploadAttachment', details are : " + info + "; error info :" + err
				ILSctx.setVariable('exitStatus', '500');
				ILSctx.setVariable("Exitdescription", errorinfo);
				logger.error("TaskUpdate_057 : " + errorinfo);
				session.reject(errorinfo);
			}
		}
	}
});
