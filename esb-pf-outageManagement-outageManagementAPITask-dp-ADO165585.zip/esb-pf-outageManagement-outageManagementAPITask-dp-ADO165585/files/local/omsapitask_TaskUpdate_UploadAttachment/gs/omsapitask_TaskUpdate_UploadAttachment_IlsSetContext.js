var ILSctx = session.name("ILS") || session.createContext("ILS");
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');

var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else {
		var incomingdata = incomingdata;
		var Entrydescription = session.parameters.ILSEntryDescription;
		var Exitdescription = session.parameters.Exitdescription;
		var urlIn = sm.getVar('var://service/URL-in');
		ILSctx.setVariable("sourceUrl", urlIn);
		if (incomingdata.CallBackData.messageID === undefined || incomingdata.CallBackData.messageID === null || incomingdata.CallBackData.messageID === "") {
			ILSctx.setVariable('correlationID', " ")
		} else {
			var correlationID = incomingdata.CallBackData.messageID
			ILSctx.setVariable('correlationID', correlationID)
		}
		if (incomingdata.CallBackData.ServiceName === undefined || incomingdata.CallBackData.ServiceName === null || incomingdata.CallBackData.ServiceName === "") {
			ILSctx.setVariable('messageType', " ")
		} else {
			var messageType = incomingdata.CallBackData.ServiceName + "Event";
			ILSctx.setVariable('messageType', messageType)
		}
		if (incomingdata.CallBackData.CallID === undefined || incomingdata.CallBackData.CallID === null || incomingdata.CallBackData.CallID === "") {
			ILSctx.setVariable('crewAssignmentDisplayID', " ")
		} else {
			var crewAssignmentDisplayID = incomingdata.CallBackData.CallID
			ILSctx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID)
		}
		if (incomingdata.CallBackData.TimeModified === undefined || incomingdata.CallBackData.TimeModified === null || incomingdata.CallBackData.TimeModified === "") {
			ILSctx.setVariable('sourceEventTimestamp', " ")
		} else {
			var sourceEventTimestamp = incomingdata.CallBackData.TimeModified
			ILSctx.setVariable('sourceEventTimestamp', sourceEventTimestamp)
		}
		if (Entrydescription === undefined || Entrydescription === null || Entrydescription === "") {
			ILSctx.setVariable('Entrydescription', " ");
		} else {
			ILSctx.setVariable('Entrydescription', Entrydescription);
		}
		if (Exitdescription === undefined || Exitdescription === null || Exitdescription === "") {
			ILSctx.setVariable('Exitdescription', " ");
		} else {
			ILSctx.setVariable('Exitdescription', Exitdescription);
		}
	}
});

