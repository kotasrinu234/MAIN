var ctx = session.name("TaskUpdate_crewStatus") || session.createContext("TaskUpdate_crewStatus");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var logger = console.options({ 'category': 'all' });
var omsExternalURL = session.parameters.omsExternalURL;
ILSctx.setVariable("exitDestination", omsExternalURL)
var apiToken = session.parameters.OMSToken;
var currentDateTime = new Date().toISOString();  
ctx.setVariable("currentDateTime", currentDateTime);
session.input.readAsJSON(function(readAsJSONError, requestJson) {

	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		var getId = requestJson.CrewStatusUpdate.CrewID;

		if (getId === null || getId === undefined || getId === "") {
			logger.error("Invalid or No CrewID for CrewStatusUpdate");
			session.reject("Invalid or No CrewID for CrewStatusUpdate");
		} else {

			var lookupLabel = requestJson.CrewStatusUpdate.CrewStatus;
			var CrewStatusUpdateAPI = omsExternalURL + '/api/ServiceType/Electric/Crew/' + getId;
			var identifier;

			var getCrewStatusUpdate = {
				target: CrewStatusUpdateAPI,
				sslClientProfile: 'omsapi_client_profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': apiToken
				}
			};
			var info = " TargetURL :" + getCrewStatusUpdate.target + "; Method :" + getCrewStatusUpdate.method + ". ";

			urlopen.open(getCrewStatusUpdate, function(error, response) {
				if (error) {
					var errorinfo = "url connection error 'CrewStatusUpdate GetCall', details are : " + info + "; error info :" + error
					ILSctx.setVariable('exitStatus', '500');
					ILSctx.setVariable("Exitdescription", errorinfo);
					logger.error(errorinfo);
					session.reject("TaskUpdate_059 : " + errorinfo);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						logger.info("CrewStatusUpdateAPI response status code 200 ");
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'CrewStatusUpdate GetCall', details are : " + info + "; error info :" + error
								ILSctx.setVariable('exitStatus', '500');
								ILSctx.setVariable("Exitdescription", errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								ILSctx.setVariable('exitStatus', '0');
								var CrewStatusUpdateAPIRes = JSON.parse(responseData);
								ctx.setVariable("CrewStatusUpdateAPIRes", CrewStatusUpdateAPIRes);
								var lookupmessage = {
									"lookupReq": {
										"type": [
											{
												"name": "crewCustomFields",
												"externalLabel": "crewStatusCustom",
												"label": lookupLabel
											}]
									}
								}
								var lookupCall = {
									target: session.parameters.lookupUrl,
									method: 'POST',
									contentType: 'application/json',
									data: lookupmessage
								};
								var info = " TargetURL :" + lookupCall.target + "; Method :" + lookupCall.method + "; Data :" + JSON.stringify(lookupCall.data) + ". ";

								lookup(lookupCall, function(error, responseData) {
									if (error) {
										var errorinfo = "url connection error 'CrewStatusUpdate LookUp', details are : " + info + "; error info :" + error
										ILSctx.setVariable('exitStatus', '500');
										ILSctx.setVariable("Exitdescription", errorinfo);
										logger.error("TaskUpdate_060 : " + errorinfo);
									} else {
										var lookupResponse = responseData;
										var responseStatusCode = responseData.statusCode;
										if (lookupResponse.lookupRep.type[0].result == 0) {
											if ((lookupResponse.lookupRep.type[0].status != undefined) && (lookupResponse.lookupRep.type[0].status != null) && (lookupResponse.lookupRep.type[0].status != '')) {
												identifier = lookupResponse.lookupRep.type[0].status;
												ctx.setVariable("identifier", identifier);

												var patchMessage =
												{
													"customFieldValues": {
														"crewStatusCustom": identifier
													}
												}
												var patchcrewStatusCustom = {
													target: CrewStatusUpdateAPI,
													sslClientProfile: 'omsapi_client_profile',
													method: 'PATCH',
													contentType: 'application/json',
													headers: {
														'osiApiToken': apiToken
													},
													data: patchMessage
												};
												var info = " TargetURL :" + patchcrewStatusCustom.target + "; Method :" + patchcrewStatusCustom.method + "; Data :" + JSON.stringify(patchcrewStatusCustom.data) + ". ";
												urlopen.open(patchcrewStatusCustom, function(error, response) {
													if (error) {
														var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
														ILSctx.setVariable('exitStatus', '500');
														ILSctx.setVariable("Exitdescription", errorinfo);
														logger.error(errorinfo);
														session.reject("TaskUpdate_061 : " + errorinfo);
													} else {
														var responseStatusCode = response.statusCode;
														if (responseStatusCode == 200) {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('exitStatus', '500');
																	ILSctx.setVariable("Exitdescription", errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	ILSctx.setVariable('exitStatus', '0');
																	var patchcrewStatusAPIRes = JSON.parse(responseData);
																	ctx.setVariable("patchcrewStatusAPIRes", patchcrewStatusAPIRes);
																	if (lookupLabel == "AVAILABLE") {
																		var postOnShift =
																		{
																			"shiftOnTime": currentDateTime // current time stamp in UTC
																		}

																		var postOnShiftTime = {
																			target: CrewStatusUpdateAPI + '/OnShift',
																			sslClientProfile: 'omsapi_client_profile',
																			method: 'POST',
																			contentType: 'application/json',
																			headers: {
																				'osiApiToken': apiToken
																			},
																			data: postOnShift
																		};

																		var info = " TargetURL :" + postOnShiftTime.target + "; Method :" + postOnShiftTime.method + "; Data :" + JSON.stringify(postOnShiftTime.data) + ". ";
																		urlopen.open(postOnShiftTime, function(error, response) {
																			if (error) {
																				var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('exitStatus', '500');
																				ILSctx.setVariable("Exitdescription", errorinfo);
																				logger.error(errorinfo);
																				session.reject("TaskUpdate_066 : " + errorinfo);
																			} else {
																				var responseStatusCode = response.statusCode;
																				if (responseStatusCode == 200) {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('exitStatus', '500');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							ILSctx.setVariable('exitStatus', '0');
																							var postOnShiftTimeRes = JSON.parse(responseData);
																							ctx.setVariable("postOnShiftTimeRes", postOnShiftTimeRes);
																						}
																					});
																				} else if(responseStatusCode == 400){
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('exitStatus', '500');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							var errorinfo = "error response 'CrewStatusUpdate', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																							ILSctx.setVariable('exitStatus', '400');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																						}
																					});
																				}else {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('exitStatus', '500');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							var errorinfo = "error response 'CrewStatusUpdate', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																							ILSctx.setVariable('exitStatus', '500');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																							session.reject("TaskUpdate_067 : " + errorinfo);
																						}
																					});
																				}
																			}
																		})
																	}
																	else if (lookupLabel == "UN-AVAILABLE") {
																		var patchOffShift =
																		{
																			"shiftOffTime": currentDateTime // current time stamp in UTC
																		}

																		var patchOffShiftTime = {
																			target: CrewStatusUpdateAPI + '/OffShift',
																			sslClientProfile: 'omsapi_client_profile',
																			method: 'PATCH',
																			contentType: 'application/json',
																			headers: {
																				'osiApiToken': apiToken
																			},
																			data: patchOffShift
																		};

																		var info = " TargetURL :" + patchOffShiftTime.target + "; Method :" + patchOffShiftTime.method + "; Data :" + JSON.stringify(patchOffShiftTime.data) + ". ";

																		urlopen.open(patchOffShiftTime, function(error, response) {
																			if (error) {
																				var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('exitStatus', '500');
																				ILSctx.setVariable("Exitdescription", errorinfo);
																				logger.error(errorinfo);
																				session.reject("TaskUpdate_068 : " + errorinfo);
																			} else {
																				var responseStatusCode = response.statusCode;
																				if (responseStatusCode == 200) {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('exitStatus', '500');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							ILSctx.setVariable('exitStatus', '0');
																							var patchOffShiftTimeRes = JSON.parse(responseData);
																							ctx.setVariable("patchOffShiftTimeRes", patchOffShiftTimeRes);
																						}
																					});
																				} else if(responseStatusCode == 400){
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('exitStatus', '500');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							var errorinfo = "error response 'CrewStatusUpdate', details are : " + info + "; errorresponse:" + responseData + "; ResponseStatusCode :" + responseStatusCode
																							ILSctx.setVariable('exitStatus', '400');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																						}
																					});
																				}else {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('exitStatus', '500');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							var errorinfo = "error response 'CrewStatusUpdate', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																							ILSctx.setVariable('exitStatus', '500');
																							ILSctx.setVariable("Exitdescription", errorinfo);
																							logger.error(errorinfo);
																							session.reject("TaskUpdate_069 : " + errorinfo);
																						}
																					});
																				}
																			}
																		})
																	}
																	else {
																		//do nothing
																	}


																}
															});
														} else if(responseStatusCode == 400){
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('exitStatus', '500');
																	ILSctx.setVariable("Exitdescription", errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "error response 'CrewStatusUpdate', details are : " + info + "; errorresponse :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	ILSctx.setVariable('exitStatus', '400');
																	ILSctx.setVariable("Exitdescription", errorinfo);
																	logger.error(errorinfo);
																}
															});
														}else {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "error reading response 'CrewStatusUpdate', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('exitStatus', '500');
																	ILSctx.setVariable("Exitdescription", errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "error response 'CrewStatusUpdate', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	ILSctx.setVariable('exitStatus', '500');
																	ILSctx.setVariable("Exitdescription", errorinfo);
																	logger.error(errorinfo);
																	session.reject("TaskUpdate_062 : " + errorinfo);
																}
															});
														}
													}
												})
											} else {
												var info = " TargetURL :" + lookupCall.target + "; Method :" + lookupCall.method + "; Data :" + JSON.stringify(lookupCall.data) + ". ";
												var invalidresp = "Invalid Lookup Request 'CrewStatusUpdate LookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode : 200"
												logger.error(invalidresp);
												identifier = "";
											}
										} else {
											var info = " TargetURL :" + lookupCall.target + "; Method :" + lookupCall.method + "; Data :" + JSON.stringify(lookupCall.data) + ". ";
											var invalidresp = "Invalid Lookup Request 'CrewStatusUpdate LookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode : 200"
											logger.error(invalidresp);
											session.reject("TaskUpdate_063 : " + invalidresp);
											identifier = "";
										}
									}
								})
							}
						})
					} else if(responseStatusCode == 400) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'CrewStatusUpdate GetCall', details are : " + info + "; error info :" + error
								ILSctx.setVariable('exitStatus', '500');
								ILSctx.setVariable("Exitdescription", errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "error response 'CrewStatusUpdate GetCall', details are : " + info + "; errorresponse :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('exitStatus', '400');
								ILSctx.setVariable("Exitdescription", errorinfo);
								logger.error(errorinfo);
							}
						});
					}else {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "error reading response 'CrewStatusUpdate GetCall', details are : " + info + "; error info :" + error
								ILSctx.setVariable('exitStatus', '500');
								ILSctx.setVariable("Exitdescription", errorinfo);
								logger.error(errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "error response 'CrewStatusUpdate GetCall', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
								ILSctx.setVariable('exitStatus', '500');
								ILSctx.setVariable("Exitdescription", errorinfo);
								logger.error(errorinfo);
								session.reject("TaskUpdate_064 : " + errorinfo);
							}
						});
					}
				}
			})
		}
	}
});

function lookup(url, data) {
	var info = " TargetURL :" + url + "; Data :" + JSON.stringify(data) + ". ";
	urlopen.open(url, function(error, response) {
		if (error) {
			var errorinfo = "url connection error 'CrewStatusUpdate LookUp', details are : " + info + "; error info :" + error
			ILSctx.setVariable('exitStatus', '500');
			ILSctx.setVariable("Exitdescription", errorinfo);
			// an error occurred during request sending or response header parsing
			logger.error(errorinfo);
			session.reject("TaskUpdate_065 : " + errorinfo)
		} else {
			// read response data
			// get the response status code
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsJSON(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response 'CrewStatusUpdate LookUp', details are : " + info + "; error info :" + error
						ILSctx.setVariable('exitStatus', '500');
						ILSctx.setVariable("Exitdescription", errorinfo);
						// error while reading response or transferring data to Buffer
						logger.error(errorinfo);
						data(error, null);
					} else {
						ILSctx.setVariable('exitStatus', '0');
						hm.response.statusCode = '200 Message is received';
						logger.debug("response received from Lookup api:" + responseData);
						data(null, responseData);
					}
				})
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						var errorinfo = "error reading response 'CrewStatusUpdate LookUp', details are : " + info + "; error info :" + error
						ILSctx.setVariable('exitStatus', '500');
						ILSctx.setVariable("Exitdescription", errorinfo);
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "error response 'CrewStatusUpdate LookUp', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
						hm.current.statusCode = responseStatusCode;
						ILSctx.setVariable('exitStatus', '500');
						ILSctx.setVariable("Exitdescription", errorinfo);
						logger.error(errorinfo);
						session.reject("TaskUpdate_066 : " + errorinfo);
						data("Error returned from lookup OMS call with statusCode " + responseStatusCode, null);

					}
				});
			}
		}
	});
}
