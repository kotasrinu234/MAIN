<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dp="http://www.datapower.com/extensions"
	extension-element-prefixes="dp" exclude-result-prefixes="dp">
	<xsl:template match="@*|node()">
		<xsl:apply-templates select="@*|node()" />
	</xsl:template>

	<xsl:template match="//json:string[@name='payload']">
		<xsl:variable name="inflated"
			select="dp:inflate(//json:string[@name='payload'])" />
		<xsl:variable name="parsed" select="dp:parse($inflated)" />
		<dp:set-variable name="'var://context/ILS/parsed'"
			value="$parsed" />
		<xsl:variable name="messageID"
			select="$parsed/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'messageID']]" />
		<xsl:variable name="CrewID"
			select="$parsed/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'CrewID']]" />
		<xsl:variable name="ExchangeMeterIn"
			select="$parsed/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'ExchangeMeterIn']]" />
		<xsl:variable name="ExchangeMeterOut"
			select="$parsed/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'ExchangeMeterOut']]" />
		<xsl:variable name="ExchangeMeterOutReading"
			select="$parsed/*[local-name()='object']/*[local-name()='object']/*[local-name()='number' and @*[local-name()='name' and normalize-space(.) = 'ExchangeMeterOutReading']]" />
		<xsl:variable name="PremiseID" select="$parsed/*[local-name()='object']/*[local-name()='object']/*[local-name()='string' and @*[local-name()='name' and normalize-space(.) = 'PremiseID']]" />

		<dp:set-variable name="'var://context/ILS/messageID'" value="string($messageID)" />
		<xsl:variable name="DateTime" select="date:date-time()" />
		<xsl:variable name="Comments">
			<xsl:value-of select="concat('Meter Exchange Initiated by crew ',$CrewID,'  Meter In: ', $ExchangeMeterIn, ' Meter Out: ', $ExchangeMeterOut, ' Meter Reading: ',$ExchangeMeterOutReading)" />
		</xsl:variable>
		<xsl:variable name='MeterInPayload'>
			<soapenv:Envelope
				xmlns:v11="http://esm.dteco.com/common/v1"
				xmlns:v1="http://outagemanagement.esm.dteco.com/trouble/v1"
				xmlns:rep="http://trouble.outagemanagement.esm.dteco.com/v1/report"
				xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
				xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"
				xmlns:dp="http://www.datapower.com/schemas/management"
				xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
				<soapenv:Header />
				<soapenv:Body>
					<v1:ReportTrouble>
						<v11:Header>
							<v11:Verb>create</v11:Verb>
							<v11:Noun>Trouble</v11:Noun>
				                	<v11:Source>Field App</v11:Source> 
							<v11:Timestamp>
								<xsl:value-of select='$DateTime' />
							</v11:Timestamp>
							<v11:AsyncReplyFlag>true</v11:AsyncReplyFlag>
							<v11:MessageID>
								<xsl:value-of select='$messageID' />
							</v11:MessageID>
						</v11:Header>
						<rep:Trouble>
							<rep:applicationId>F</rep:applicationId>
							<rep:troubleCode>METEREX</rep:troubleCode>
							<rep:notificationTime>
								<xsl:value-of select='$DateTime' />
							</rep:notificationTime>
							<rep:remarks>
								<xsl:value-of select='$Comments' />
							</rep:remarks>
							<rep:troubleLocation>
								<rep:premiseId>
									<xsl:value-of select='$PremiseID' />
								</rep:premiseId>
							</rep:troubleLocation>
						</rep:Trouble>
					</v1:ReportTrouble>
				</soapenv:Body>
			</soapenv:Envelope>
		</xsl:variable>
		<dp:set-variable
			name="'var://context/ILS/MeterInPayload'" value="$MeterInPayload" />
		<xsl:copy-of select="$parsed" />
	</xsl:template>

</xsl:stylesheet>
