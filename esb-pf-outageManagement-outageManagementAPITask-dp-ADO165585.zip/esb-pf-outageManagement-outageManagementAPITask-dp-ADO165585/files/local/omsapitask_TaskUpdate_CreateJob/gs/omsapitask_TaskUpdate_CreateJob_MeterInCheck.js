var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var TaskUpdateReq = require('./URLOpenUtil.js');
var ms = require('multistep');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var TaskUpdateQueueURL = session.parameters.TaskUpdateQueueURL
var SeqInputPayload = ctx.getVariable('SeqInputPayload')
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {
		var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
		ctx.setVariable('ParentJob', incomingData.TaskUpdate.JobIDGUID)
		var PropertiesChangedSplit = PropertiesChanged.split(',');
		if (PropertiesChangedSplit.includes("ExchangeMeterIn")) {
			if (!(incomingData.TaskUpdate.PremiseID === undefined || incomingData.TaskUpdate.PremiseID === null || incomingData.TaskUpdate.PremiseID === "")) {
				if (!(incomingData.TaskUpdate.ExchangeMeterIn === undefined || incomingData.TaskUpdate.ExchangeMeterIn === null || incomingData.TaskUpdate.ExchangeMeterIn === "")) {
					var options = {
						target: session.parameters.TroubleReportURL,
						method: 'POST',
						sslClientProfile: 'omsapi_client_profile',
						contentType: 'application/xml',
						data: ILSctx.getVariable('MeterInPayload')
					};
					ILSctx.setVariable('ExitDestination', options.target)
					var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + XML.stringify(options.data) + ". ";
					urlopen.open(options, function(error, response) {
						if (error) {
							var errorinfo = "TaskUpdate_CrtJob12 : url connection error 'TaskUpdate Create MeterExchangeIn', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							var ErrorTxt = errorinfo
							ctx.setVariable("ErrorTxt", ErrorTxt);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
										var errorinfo = "error reading response 'TaskUpdate Create MeterExchangeIn', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', '500');
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var responseDataString = responseData.toString();
										ctx.setVariable("response30", responseDataString)

										var insvcJobIdStart = responseDataString.indexOf("<ns2:insvcJobId>") + 16;
										var insvcJobIdEnd = responseDataString.indexOf("</ns2:insvcJobId>");
										var insvcJobId = responseDataString.substring(insvcJobIdStart, insvcJobIdEnd);

										var troubleIdStart = responseDataString.indexOf("<ns2:troubleId>") + 15;
										var troubleIdEnd = responseDataString.indexOf("</ns2:troubleId>");
										var troubleId = responseDataString.substring(troubleIdStart, troubleIdEnd);

										if (!(insvcJobId === null || insvcJobId === undefined || insvcJobId === '')) {
											ILSctx.setVariable('callJobDisplayID', insvcJobId)
											ILSctx.setVariable('callDisplayID', troubleId)
											ctx.setVariable('CreateJob', 'yes')
											var ns2IdStart = responseDataString.indexOf("<ns2:id>") + 8;
											var ns2IdEnd = responseDataString.indexOf("</ns2:id>");
											var ns2Id = responseDataString.substring(ns2IdStart, ns2IdEnd);
											ctx.setVariable('JobIDfrom30', ns2Id)
											ILSctx.setVariable('ExitDestination', options.target)
											ILSctx.setVariable('ExitDescription', session.parameters.CreateJobExitDescription)
											ILSctx.setVariable('ExitStatus', '0')
											ms.callRule('omsapitask_TaskUpdate_CreateJob_Processing_Policy_StepExit_Rule', null, null, function(error) {
												if (error) {
												}
											});

											var Payload = {
												"customFieldValues":
													{}
											};
											var ExchangeMeterIn = incomingData.TaskUpdate.ExchangeMeterIn;
											var ExchangeMeterOut = incomingData.TaskUpdate.ExchangeMeterOut;
											var ExchangeMeterOutReading = incomingData.TaskUpdate.ExchangeMeterOutReading;
											if (!(ExchangeMeterIn === null || ExchangeMeterIn === undefined || ExchangeMeterIn === '')) {
												Payload.customFieldValues.Exchange_Meter_In = ExchangeMeterIn
											}
											if (!(ExchangeMeterOut === null || ExchangeMeterOut === undefined || ExchangeMeterOut === '')) {
												Payload.customFieldValues.Exchange_Meter_Out = ExchangeMeterOut
											}
											if (!(ExchangeMeterOutReading === null || ExchangeMeterOutReading === undefined || ExchangeMeterOutReading === '')) {
												Payload.customFieldValues.Exchange_Meter_Out_Reading = ExchangeMeterOutReading
											}
											var OMSURL = session.parameters.OMSURL
											var MeterPatchURL = OMSURL + '/api/ServiceType/Electric/Job/' + ns2Id
											var Token = session.parameters.OMSToken

											var MeterPatch = {
												target: MeterPatchURL,
												sslClientProfile: 'omsapi_client_profile',
												method: 'PATCH',
												contentType: 'application/json',
												data: Payload,
												headers: {
													'osiApiToken': Token
												}
											};
											var info = " TargetURL :" + MeterPatch.target + "; Method :" + MeterPatch.method + "; Data :" + JSON.stringify(MeterPatch.data) + ". ";
											urlopen.open(MeterPatch, function(error, response) {
												if (error) {
													var errorinfo = "TaskUpdate_CrtJob13 : url connection error 'MeterUpdates', details are : " + info + "; error info :" + error
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = errorinfo;
													ctx.setVariable("ErrorTxt", ErrorTxt);
												} else {
													var responseStatusCode = response.statusCode
													if (responseStatusCode == 200 || responseStatusCode == 400 || responseStatusCode == 404) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																var errorinfo = "error reading response 'MeterUpdates', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ExitDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var buff = Buffer.from(responseData)
																var ResponseString = buff.toString();
																ctx.setVariable("respo", ResponseString)

																if (responseStatusCode == 200 || (ResponseString === "No updates")) {
																	var GetLinksDataURL = OMSURL + '/api/ServiceType/Electric/Job/' + incomingData.TaskUpdate.JobIDGUID; +'includeFields=links'
																	var GetLinksData = {
																		target: GetLinksDataURL,
																		sslClientProfile: 'omsapi_client_profile',
																		method: 'GET',
																		contentType: 'application/json',
																		headers: {
																			'osiApiToken': Token
																		}
																	};
																	var info = " TargetURL :" + GetLinksData.target + "; Method :" + GetLinksData.method + "; Data :" + ". ";
																	urlopen.open(GetLinksData, function(error, response) {
																		if (error) {
																			var errorinfo = "TaskUpdate_CrtJob14 : url connection error 'Get Links Data', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', '500');
																			ILSctx.setVariable('ExitDescription', errorinfo);
																			logger.error(errorinfo);
																			ctx.setVariable("retry", 'yes');
																			var ErrorTxt = errorinfo;
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsJSON(function(error, responseData) {
																					if (error) {
																						TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																						var errorinfo = "error reading response 'Get Links Data', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', '500');
																						ILSctx.setVariable('ExitDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						ctx.setVariable("GetLinksData", responseData)
																						if (responseData.links === null || responseData.links === undefined || responseData.links === '' || responseData.links[0] === undefined) {
																							ctx.setVariable("addLinks", 'yes')
																						} else {
																							for (var i = 0; i < responseData.links.length; i++) {
																								if ((responseData.links[i].linkedID === undefined || responseData.links[i].linkedID === null || responseData.links[i].linkedID === '')) {
																									ctx.setVariable("addLinks", 'yes')
																								} else {
																									if (responseData.links[i].linkedID === ns2Id) {
																										ctx.setVariable("linksExists", 'yes')
																									} else {
																										ctx.setVariable("addLinks", 'yes')
																									}

																								}
																							}
																						}
																					}
																				})
																			} else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																						var errorinfo = "error reading response 'Get Links Data', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ExitDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "TaskUpdate_CrtJob15 : error response 'Get Links Data', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																						responseData = responseData.toString()
																						if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
																							var ErrorTxt = "TaskUpdate_CrtJob15 : error response 'Get Links Data', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
																						} else {
																							var ErrorTxt = errorinfo
																						}
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ExitDescription', errorinfo);
																						hm.current.statusCode = responseStatusCode;
																						logger.error(errorinfo);
																						ctx.setVariable("retry", 'yes');
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																					}
																				});
																			}
																		}
																	})
																} else {
																	TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																	var errorinfo = "TaskUpdate_CrtJob16 : error response 'JobIdUpdates', details are : " + info + "; response info :" + ResponseString + "; ResponseStatusCode :" + responseStatusCode
																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo)
																}
															}
														})
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																var errorinfo = "error reading response 'MeterUpdates', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', responseStatusCode);
																ILSctx.setVariable('ExitDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var errorinfo = "TaskUpdate_CrtJob17 :error response 'MeterUpdates', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																responseData = responseData.toString()
																if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
																	var ErrorTxt = "TaskUpdate_CrtJob17 : error response 'MeterUpdates', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
																} else {
																	var ErrorTxt = errorinfo
																}
																ILSctx.setVariable('ExitStatus', responseStatusCode);
																ILSctx.setVariable('ExitDescription', errorinfo);
																hm.current.statusCode = responseStatusCode;
																logger.error(errorinfo);
																ctx.setVariable("retry", 'yes');
																ctx.setVariable("ErrorTxt", ErrorTxt);
															}
														});
													}
												}
											})
										} else {
											TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
										}
									}
								})
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
										var errorinfo = "TaskUpdate_CrtJob18 : error reading response 'TaskUpdate Create MeterExchangeIn', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var errorinfo = "TaskUpdate_CrtJob18 : error response 'TaskUpdate Create MeterExchangeIn', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										responseData = responseData.toString()
										if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
											var ErrorTxt = "TaskUpdate_CrtJob18 : error response 'TaskUpdate Create MeterExchangeIn', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
										} else {
											var ErrorTxt = errorinfo
										}
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										hm.current.statusCode = responseStatusCode;
										logger.error(errorinfo);
										ctx.setVariable("retry", 'yes');
										ctx.setVariable("ErrorTxt", ErrorTxt);
									}
								})
							}
						}
					});
				} else {
					TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
				}
			} else {
				TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
			}
		} else {
			TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
		}
	}
});
