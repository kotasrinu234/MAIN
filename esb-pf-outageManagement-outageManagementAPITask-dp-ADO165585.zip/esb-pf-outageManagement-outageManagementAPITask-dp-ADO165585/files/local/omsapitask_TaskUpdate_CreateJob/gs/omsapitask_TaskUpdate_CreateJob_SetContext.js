var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');

var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', 'Error in reading incoming data')
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject(readAsJSONError);
	} else { 
		ctx.setVariable("SeqInputPayload", incomingData)
		ILSctx.setVariable('ServiceName', incomingData.serviceName)
	}
})