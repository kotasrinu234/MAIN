var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var TaskUpdateReq = require('./URLOpenUtil.js');
var TaskUpdateQueueURL = session.parameters.TaskUpdateQueueURL
var SeqInputPayload = ctx.getVariable('SeqInputPayload')
var RetryCheck = ctx.getVariable("retry")
var LastRetry = ctx.getVariable("LastRetry")
var JobCompleted = ctx.getVariable("JobCompleted")

if(RetryCheck === 'yes'){
	if(LastRetry === 'yes'){
		TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
	}
}
if(JobCompleted === 'yes'){
	TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
}
session.output.write(SeqInputPayload)

