//js is used to push message to standalone queue
var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ms = require('multistep');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var TaskUpdateExitDescription = session.parameters.TaskUpdateExitDescription

function QueueCall(StandaloneMQurl, Payload) {
	var pushingToQueue = {
		target: StandaloneMQurl,
		data: Payload
	};
	var info = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";

	try {
		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error 'OMSAPITASK.UPDATE.PROCESSING Queue', details are : " + info + "; error info :" + error
				var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
				var mqconnection = 'Forbidden';
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(errorinfo);
				session.reject(errorinfo)
			} else {
				var mqrc = response.statusCode;

				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "Error reading the response 'OMSAPITASK.UPDATE.PROCESSING', details are : " + info + "; error info :" + readError
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							hm.response.statusCode = 500
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							ILSctx.setVariable('ExitStatus', '0');
							logger.debug("MQResponsecode " + mqrc);
							ILSctx.setVariable('ExitDestination', StandaloneMQurl)
							ILSctx.setVariable('ExitDescription', TaskUpdateExitDescription)
							ILSctx.setVariable('ExitStatus', '0')
						}
					});
				} else {
					var errorinfo = "Error received from the response of Queue 'OMSAPITASK.UPDATE.PROCESSING', details are : " + info + "; response info :" + JSON.stringify(response) + "; ResponseStatusCode :" + response.statusCode
					var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					logger.error(errorinfo);
					session.reject(errorinfo)
				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error 'OMSAPITASK.UPDATE.PROCESSING Queue', details are : " + info + "; error info :" + err
		var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
		var mqconnection = 'Forbidden';
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo)
		ctx.setVariable("mqconnection", mqconnection);
		logger.error(errorinfo);
		session.reject(errorinfo)
	}
}
module.exports = QueueCall;
