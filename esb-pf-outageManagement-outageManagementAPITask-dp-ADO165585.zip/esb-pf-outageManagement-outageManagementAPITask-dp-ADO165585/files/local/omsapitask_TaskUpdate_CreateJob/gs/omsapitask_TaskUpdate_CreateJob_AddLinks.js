var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var TaskUpdateReq = require('./URLOpenUtil.js');
var ms = require('multistep');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var TaskUpdateQueueURL = session.parameters.TaskUpdateQueueURL
var SeqInputPayload = ctx.getVariable('SeqInputPayload')
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var RetryCheck = ctx.getVariable("retry")
var Token = session.parameters.OMSToken
var ILSctx = session.name('ILS') || session.createContext('ILS');
if (RetryCheck !== 'yes') {
	session.input.readAsJSON(function(readAsJSONError, incomingData) {
		if (readAsJSONError) {
			TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
			logger.error("Error in reading incoming data" + JSON.stringify(error));
			session.reject("error in reading incoming data" + JSON.stringify(error));
		} else {
			var OMSURL = session.parameters.OMSURL
			var JobIDfrom30 = ctx.getVariable('JobIDfrom30')
			var CreateJob = ctx.getVariable('CreateJob')
			if (CreateJob === 'yes') {
				var linksExists = ctx.getVariable('linksExists')
				if (linksExists !== 'yes') {
					var lookupUrl = session.parameters.lookupUrl
					var LinksLookupPayload = {
						"lookupReq": {
							"type": [
								{
									"name": "linkTypes",
									"label": "DTE - Associated"
								}
							]
						}
					};
					var LinksLookup = {
						target: lookupUrl,
						method: 'POST',
						contentType: 'application/json',
						data: LinksLookupPayload
					};
					var info = " TargetURL: " + LinksLookup.target + "; Method: " + LinksLookup.method + "; Data: " + JSON.stringify(LinksLookup.data) + ". ";
					urlopen.open(LinksLookup, function(error, response) {
						if (error) {
							TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
							var errorinfo = "TaskUpdate_CrtJob01 : url connection error 'LinksLookup', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
										var errorinfo = "error reading response 'LinksLookup', details are :" + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', '500');
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										hm.response.statusCode = '200 OK';
										logger.debug("response received :" + JSON.stringify(responseData));
										//	ctx.setVariable("CauseCodeResponse", responseData)
										if (responseData.lookupRep.type[0].result == 1) {
											TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
											var invalidresp = "Invalid Lookup Request 'LinksLookup', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', '1');
											ILSctx.setVariable('ExitDescription', invalidresp);
											logger.error(invalidresp);
											session.reject(invalidresp)
										} else {
											var LinksPatchURL = OMSURL + '/api/ServiceType/Electric/Job/' + incomingData.TaskUpdate.JobIDGUID + '/LinkJobs'
											var LinksPatchPayload = {
												"addLinks": [{
													"linkedID": JobIDfrom30,
													"linkTypeID": responseData.lookupRep.type[0].id
												}]
											};

											var LinksPatch = {
												target: LinksPatchURL,
												sslClientProfile: 'omsapi_client_profile',
												method: 'PATCH',
												contentType: 'application/json',
												data: LinksPatchPayload,
												headers: {
													'osiApiToken': Token
												}
											};
											var info = " TargetURL :" + LinksPatch.target + "; Method :" + LinksPatch.method + "; Data :" + JSON.stringify(LinksPatch.data) + ". ";
											urlopen.open(LinksPatch, function(error, response) {
												if (error) {
													var errorinfo = "TaskUpdate_CrtJob02 : url connection error 'LinksPatch', details are : " + info + "; error info :" + error
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													ctx.setVariable("retry", 'yes');
													var ErrorTxt = errorinfo;
													ctx.setVariable("ErrorTxt", ErrorTxt);
												} else {
													if (responseStatusCode == 200) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																var errorinfo = "error reading response 'MeterUpdates', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ExitDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var buff = Buffer.from(responseData)
																var ResponseString = buff.toString();
																ctx.setVariable("respo", ResponseString)
																if (responseStatusCode == 200 || (ResponseString === "No updates")) {

																	hm.response.statusCode = responseStatusCode;
																	logger.debug("response received :" + JSON.stringify(responseData));

																} else if (responseStatusCode == 500) {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																			var errorinfo = "error reading response 'MeterUpdates', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ExitDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var errorinfo = "TaskUpdate_CrtJob03 : error response 'MeterUpdates', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ExitDescription', errorinfo);
																			hm.current.statusCode = responseStatusCode;
																			logger.error(errorinfo);
																			ctx.setVariable("retry", 'yes');
																			var ErrorTxt = errorinfo
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																		}
																	});
																} else {
																	TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																	var errorinfo = "TaskUpdate_CrtJob04 : error response 'JobIdUpdates', details are : " + info + "; response info :" + ResponseString + "; ResponseStatusCode :" + responseStatusCode
																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo)
																}
															}
														})
													} else if (responseStatusCode == 500) {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																var errorinfo = "error reading response 'MeterUpdates', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', responseStatusCode);
																ILSctx.setVariable('ExitDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var errorinfo = "TaskUpdate_CrtJob05 : error response 'MeterUpdates', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																ILSctx.setVariable('ExitStatus', responseStatusCode);
																ILSctx.setVariable('ExitDescription', errorinfo);
																hm.current.statusCode = responseStatusCode;
																logger.error(errorinfo);
																ctx.setVariable("retry", 'yes');
																var ErrorTxt = errorinfo
																ctx.setVariable("ErrorTxt", ErrorTxt);
															}
														});
													} else {
														TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
														var errorinfo = "TaskUpdate_CrtJob06 : error response 'JobIdUpdates', details are : " + info + "; response info :" + ResponseString + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', responseStatusCode);
														ILSctx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.reject(errorinfo)
													}
												}
											})
										}
									}
								})
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
										var errorinfo = "failure reading the error response 'CauseCodeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
										var errorinfo = "error response 'CauseCodeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										hm.current.statusCode = responseStatusCode;
										logger.error(errorinfo);
										session.reject(errorinfo);
									}
								});
							}
						}
					})
				}
			}
		}
	})
}
