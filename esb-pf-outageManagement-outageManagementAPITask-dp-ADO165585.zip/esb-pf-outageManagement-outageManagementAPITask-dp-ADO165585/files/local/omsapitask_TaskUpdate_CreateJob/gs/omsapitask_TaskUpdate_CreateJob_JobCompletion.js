var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var TaskUpdateReq = require('./URLOpenUtil.js');
var urlopen = require('urlopen');
var ms = require('multistep');
var Token = session.parameters.OMSToken
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var TaskUpdateQueueURL = session.parameters.TaskUpdateQueueURL
var SeqInputPayload = ctx.getVariable('SeqInputPayload')
var RetryCheck = ctx.getVariable("retry")

if (RetryCheck !== 'yes') {
	var CreateJob = ctx.getVariable('CreateJob')
	if (CreateJob === 'yes') {
		var JobIDGUID = ctx.getVariable("JobIDfrom30")
		var OMSURL = session.parameters.OMSURL
		var JobIDGUIDUrl = OMSURL + '/api/v1/ServiceType/Electric/Job/' + JobIDGUID + '?includeFields=status,jobTypeID';
		var GetCallResponseData = {
			target: JobIDGUIDUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': Token
			}
		};
		var info = " TargetURL :" + GetCallResponseData.target + "; Method :" + GetCallResponseData.method + ". ";
		urlopen.open(GetCallResponseData, function(error, response) {
			if (error) {
				var errorinfo = "TaskUpdate_CrtJob07 : url connection error 'JobCompletion Get Call', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDestination', JobIDGUIDUrl);
				ILSctx.setVariable('ExitDescription', errorinfo);
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "TaskUpdate_043 : " + errorinfo;
				ctx.setVariable("ErrorTxt", ErrorTxt);
				session.output.write(incomingData)
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode === 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
							var errorinfo = "error reading response 'JobCompletion', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							ILSctx.setVariable('ExitStatus', '0');
							hm.response.statusCode = '200 OK';
							logger.debug("response received from Get Call Response Data :" + responseData);
							ctx.setVariable("ResponseData", responseData)
							// LookUp for finding outage type
							var lookupUrl = session.parameters.lookupUrl;
							var jobTypeID = responseData.jobTypeID;
							var status = responseData.status;
							var outageTypeLookup = {
								"lookupReq": {
									"type": [{
										"name": "jobTypes.workflows",
										"id": jobTypeID,
										"label": "Completed"
									}]
								}
							}
							var outageTypeLookupPost = {
								target: lookupUrl,
								method: 'POST',
								contentType: 'application/json',
								data: outageTypeLookup
							}

							var info = " TargetURL :" + outageTypeLookupPost.target + "; Method :" + outageTypeLookupPost.method + "; Data :" + JSON.stringify(outageTypeLookupPost.data) + ". ";
							urlopen.open(outageTypeLookupPost, function(error, response) {
								if (error) {
									TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
									var errorinfo = "TaskUpdate_CrtJob08 : url connection error 'JobCompletion', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', session.reject);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
												var errorinfo = "error reading response 'JobCompletion', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												hm.response.statusCode = '200 OK';
												logger.debug("response received from outage Type Lookup Post :" + JSON.stringify(responseData));
												ctx.setVariable("Response", responseData)
												if (responseData.lookupRep.type[0].result == 1) {
													TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
													var invalidresp = "Invalid Lookup Request of outageTypeLookupPost 'JobCompletion', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable('ExitStatus', '1');
													ILSctx.setVariable('ExitDescription', invalidresp);
													logger.error(invalidresp)
													session.reject(invalidresp)
												} else {
													ctx.setVariable("WorkFlowIdResp", responseData)
													hm.response.statusCode = '200 OK';
													logger.debug("response received from workFlow Lookup Post :" + JSON.stringify(responseData));
													if (responseData.lookupRep.type[0].result == 1) {
														TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
														var invalidresp = "Invalid Lookup Request 'workFlowLookupPost', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', '1');
														ILSctx.setVariable('ExitDescription', invalidresp);
														logger.error(invalidresp)
														session.reject(invalidresp)
													} else {
														ILSctx.setVariable('ExitStatus', '0');
														ILSctx.setVariable('ExitDestination', lookupUrl);
														var Respstatus = responseData.lookupRep.type[0].status;
														ctx.setVariable("RespStatus", Respstatus)
														if (Respstatus !== status) {
															var RespStatusUrl = OMSURL + '/api/v1/ServiceType/Electric/Job/' + JobIDGUID + '/WorkFlow';

															var RespStatusPayloadPost = {
																target: RespStatusUrl,
																sslClientProfile: 'omsapi_client_profile',
																method: 'POST',
																contentType: 'application/json',
																data: Respstatus,
																headers: {
																	'osiApiToken': Token
																}
															};
															var info = " TargetURL :" + RespStatusPayloadPost.target + "; Method :" + RespStatusPayloadPost.method + "; Data :" + JSON.stringify(RespStatusPayloadPost.data) + ". ";
															urlopen.open(RespStatusPayloadPost, function(error, response) {
																if (error) {
																	var errorinfo = "TaskUpdate_CrtJob09 : url connection error 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus', '500');
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	logger.error(errorinfo);
																	ctx.setVariable("retry", 'yes');
																	var ErrorTxt = errorinfo;
																	ctx.setVariable("ErrorTxt", ErrorTxt);
																} else {
																	var responseStatusCode = response.statusCode;
																	if (responseStatusCode == 200) {
																		response.readAsJSON(function(error, responseData) {
																			if (error) {
																				TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																				var errorinfo = "error reading response 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus', '500');
																				ILSctx.setVariable('ExitDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				ILSctx.setVariable('ExitStatus', '0');
																				hm.response.statusCode = '200 OK';
																				logger.debug("response received from RespStatus Payload Post  :" + JSON.stringify(responseData));
																				ctx.setVariable("JobCompleted", 'yes')
																				ILSctx.setVariable('ExitDestination', RespStatusPayloadPost.target)
																				ILSctx.setVariable('ExitDescription', session.parameters.CompleteJobExitDescription)
																				ILSctx.setVariable('ExitStatus', '0')
																				ms.callRule('omsapitask_TaskUpdate_CreateJob_Processing_Policy_StepExit_Rule', null, null, function(error) {
																					if (error) {
																					}
																				});
																			}
																		});
																	} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
																		response.readAsBuffer(function(error, BusinessResponseData) {
																			if (error) {
																				TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																				var errorinfo = "error reading response 'StatusUpdate', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus', responseStatusCode);
																				ILSctx.setVariable('ExitDescription', errorinfo)
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				//business error change 1
																				var BusinessResponseData = BusinessResponseData;
																				var buff = Buffer.from(BusinessResponseData);
																				var ResponseString = buff.toString();
																				ctx.setVariable("respo", ResponseString)
																				if (!(ResponseString === "No updates")) {
																					TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																					var errorinfo = "error response 'JobCompletionStatus BusinessError', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
																					ILSctx.setVariable('ExitStatus', responseStatusCode);
																					ILSctx.setVariable('ExitDescription', errorinfo);
																					logger.error(errorinfo);
																					session.reject(errorinfo);
																				}
																			}

																		});
																	} else {
																		response.readAsBuffer(function(error, responseData) {
																			if (error) {
																				TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
																				var errorinfo = "error reading response 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus', responseStatusCode);
																				ILSctx.setVariable('ExitDescription', errorinfo);
																				logger.error(errorinfo);
																				session.reject(errorinfo);
																			} else {
																				var errorinfo = "TaskUpdate_CrtJob10 : error response 'RespStatusPayloadPost', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																				responseData = responseData.toString()
																				if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
																					var ErrorTxt = "TaskUpdate_CrtJob10 : error response 'RespStatusPayloadPost', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
																				} else {
																					var ErrorTxt = errorinfo
																				}
																				ILSctx.setVariable('ExitStatus', responseStatusCode);
																				ILSctx.setVariable('ExitDestination', RespStatusUrl);
																				ILSctx.setVariable('ExitDescription', errorinfo);
																				hm.current.statusCode = responseStatusCode;
																				logger.error(errorinfo);
																				ctx.setVariable("retry", 'yes');
																				ctx.setVariable("ErrorTxt", ErrorTxt);
																				//session.reject("Error returned from RespStatus Payload Post  " + ": with statusCode " + responseStatusCode + " " + responseData);
																			}
																		});
																	}
																}
															});
														}
														ctx.setVariable('JobCompleted', 'yes')
													}
												}
											}
										});
									}
								}
							});
						}
					})
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							TaskUpdateReq(TaskUpdateQueueURL, SeqInputPayload)
							var errorinfo = "error reading response 'JobCompletion GetCallResponseData', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "TaskUpdate_CrtJob11 : error response 'JobCompletion GetCallResponseData', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							responseData = responseData.toString()
							if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
								var ErrorTxt = "TaskUpdate_CrtJob11 : error response 'JobCompletion GetCallResponseData', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
							} else {
								var ErrorTxt = errorinfo
							}
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo);
							hm.current.statusCode = responseStatusCode;
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", ErrorTxt);
						}
					});
				}
			}
		})
	}
}
