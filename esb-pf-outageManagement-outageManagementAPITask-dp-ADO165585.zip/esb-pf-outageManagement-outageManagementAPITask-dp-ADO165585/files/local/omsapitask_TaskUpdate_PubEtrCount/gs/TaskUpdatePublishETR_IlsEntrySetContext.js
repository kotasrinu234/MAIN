var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
var messageType = session.parameters.messageType;
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var incomingdata = incomingdata;
		var Entrydescription = session.parameters.PubEtrCountIlsEntrydescription;
		var Exitdescription = session.parameters.PubEtrCountIlsExitdescription;
		var urlIn = sm.getVar('var://service/URL-in');
		ILSctx.setVariable("sourceUrl", urlIn);
		if (incomingdata.CallBackData.messageID != undefined) {
			ILSctx.setVariable('correlationID', incomingdata.CallBackData.messageID)
		}
		if (incomingdata.CallBackData.CallID === undefined || incomingdata.CallBackData.CallID === null || incomingdata.CallBackData.CallID === '') {
			ILSctx.setVariable("crewAssignmentDisplayID", " ");
		} else {
			var crewAssignmentDisplayID = incomingdata.CallBackData.CallID
			ILSctx.setVariable('crewAssignmentDisplayID', crewAssignmentDisplayID);
		}
		if (incomingdata.CallBackData.TimeModified === undefined || incomingdata.CallBackData.TimeModified === null || incomingdata.CallBackData.TimeModified === '') {
			ILSctx.setVariable("sourceEventTimestamp", " ");
		} else {
			var sourceEventTimestamp = incomingdata.CallBackData.TimeModified
			ILSctx.setVariable("sourceEventTimestamp", sourceEventTimestamp);
		}
		if (messageType === undefined || messageType === null || messageType === "") {
			ILSctx.setVariable('messageType', " ");
		} else {
			ILSctx.setVariable('messageType', messageType);
		}
		if (Entrydescription === undefined || Entrydescription === null || Entrydescription === "") {
			ILSctx.setVariable('Entrydescription', " ");
		} else {
			ILSctx.setVariable('Entrydescription', Entrydescription);
		}
		if (Exitdescription === undefined || Exitdescription === null || Exitdescription === "") {
			ILSctx.setVariable('Exitdescription', " ");
		} else {
			ILSctx.setVariable('Exitdescription', Exitdescription);
		}
	}
});