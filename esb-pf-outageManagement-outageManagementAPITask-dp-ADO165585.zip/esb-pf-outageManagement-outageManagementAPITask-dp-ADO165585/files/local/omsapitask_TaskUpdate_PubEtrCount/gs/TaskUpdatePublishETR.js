var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
session.INPUT.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {
		var messageID;
		var TimeModified;
		var PublishedETRChangeCount = incomingData.ETRChangeCount.PublishedETRChangeCount;

		if (incomingData.CallBackData.messageID === undefined || incomingData.CallBackData.messageID === null || incomingData.CallBackData.messageID === "") {
		} else {
			messageID = incomingData.CallBackData.messageID;
		}
		if (incomingData.CallBackData.TimeModified === undefined || incomingData.CallBackData.TimeModified === null || incomingData.CallBackData.TimeModified === "") {
		} else {
			TimeModified = incomingData.CallBackData.TimeModified;
		}

		var Client = incomingData.CallBackData.Client;
		var ServiceName = incomingData.CallBackData.ServiceName;
		var CallID = incomingData.CallBackData.CallID;
		var Number = incomingData.CallBackData.Number;
		var ExternalRefID = incomingData.CallBackData.ExternalRefID;
		//  ilsctx.setVariable('exitStatus', '500');
		var FSEGatewayPayload = {
			"CallBackData": {
				"messageID": messageID,
				"TimeModified": TimeModified,
				"Client": Client,
				"ServiceName": ServiceName,
				"CallID": CallID,
				"Number": Number,
				"ExternalRefID": ExternalRefID
			},
			"ETRChangeCount": {
				"PublishedETRChangeCount": PublishedETRChangeCount

			}
		}
		var FSEGatewayUrl = session.parameters.FSEUrl;
		ILSctx.setVariable('exitDestination', FSEGatewayUrl);
		session.output.write(FSEGatewayPayload);
		var FSEGatewayPayloadSend = {
			target: FSEGatewayUrl,
			sslClientProfile: 'omsapijob_RestoreVerify_UpdateStatus_TLS_ClientProfile',
			method: 'POST',
			contentType: 'application/json',
			data: FSEGatewayPayload
		};
		var info = " TargetURL :" + FSEGatewayPayloadSend.target + "; Method :" + FSEGatewayPayloadSend.method + "; Data :" + JSON.stringify(FSEGatewayPayloadSend.data) + ". ";
		urlopen.open(FSEGatewayPayloadSend, function(error, response) {
			if (error) {
				var errorinfo = "url connection error 'ETRCountUpdate to FSE', details are : " + info + "; error info :" + error
				logger.error(errorinfo);
				var ErrorTxt = "TaskUpdate_055 : " + errorinfo;
				ILSctx.setVariable("Exitdescription", ErrorTxt);
				ILSctx.setVariable('exitStatus', '500');
				session.reject(errorinfo);

			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'ETRCountUpdate to FSE', details are : " + info + "; error info :" + error
							ILSctx.setVariable('exitStatus', '500');
							ILSctx.setVariable("Exitdescription", errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							hm.response.statusCode = '200 OK';
							ILSctx.setVariable('exitStatus', '0');
							logger.debug("response received from ETRCountUpdate to FSE :" + JSON.stringify(responseData));
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'ETRCountUpdate to FSE', details are : " + info + "; error info :" + error
							ILSctx.setVariable('exitStatus', '500');
							ILSctx.setVariable("Exitdescription", errorinfo);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "error response 'ETRCountUpdate to FSE', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							hm.current.statusCode = responseStatusCode;
							ILSctx.setVariable('exitStatus', '500');
							ILSctx.setVariable("Exitdescription", errorinfo);
							logger.error("TaskUpdate_056 : " + errorinfo);
							session.reject(errorinfo);
						}
					});
				}
			}
		});
	}
});