var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ms = require('multistep');
var SeqConfirmExitDescription = session.parameters.SeqConfirmExitDescription
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

function QueueCall(StandaloneMQurl, payload) {
	var pushingToQueue = {
		target: StandaloneMQurl,
		data: payload
	};
	var info = " TargetURL :" + pushingToQueue.target + "; Method :" + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";
	ILSctx.setVariable('ExitStatus', '0');
	ILSctx.setVariable('ExitDestination', StandaloneMQurl);
	ILSctx.setVariable('ExitDescription', SeqConfirmExitDescription);
	ms.callRule('omsapitask_TaskUpdate_Send_Processing_Policy_ILSExit_Rule', null, null, function(error) {
		if (error) {
			throw error;
		}
	});

	try {
		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error 'SequenceConfirmation', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				ILSctx.setVariable('ExitDestination', StandaloneMQurl);
				var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(errorinfo);
				var ErrorTxt = "TaskUpdate_Seq_002 : " + errorinfo;
				ctx.setVariable("ErrorTxt", ErrorTxt);
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "failure in reading response 'SequenceConfirmation', details are : " + info + "; error info :" + readError
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							hm.response.statusCode = 500
							logger.error(errorinfo);
						} else {
							logger.debug("MQResponsecode " + mqrc);
						}
					});
				} else {
					var errorinfo = "error response 'SequenceConfirmation', details are : " + info + "; response  info :" + response
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', errorinfo)
					ILSctx.setVariable('ExitDestination', StandaloneMQurl);
					var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(" Error received from the response of Queue SEQ.CONFIRMATION.REQUEST [MQRC=" + mqrc + "]" + errorinfo);
					var ErrorTxt = "TaskUpdate_Seq_002 : " + errorinfo;
					ctx.setVariable("ErrorTxt", ErrorTxt);
				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error 'SequenceConfirmation', details are : " + info + "; error info :" + err
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', errorinfo)
		ILSctx.setVariable('ExitDestination', StandaloneMQurl);
		logger.error(errorinfo);
		var ErrorTxt = "TaskUpdate_Seq_002 : " + errorinfo;
		ctx.setVariable("ErrorTxt", ErrorTxt);
	}
}

module.exports = QueueCall;
