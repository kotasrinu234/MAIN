var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ms = require('multistep');
var OMSExitDescription = session.parameters.OMSExitDescription
var incomingData = ctx.getVariable("incomingData")
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var FSEGatewayUrl = session.parameters.FSEUrl2
var logger = console.options({
	'category': 'all'
});


function BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, myctx) {
	var BusinessResponseData = BusinessResponseData;
	var ResponseString = ResponseString;
	var responseStatusCode = responseStatusCode;
	var BusinessErrorStatus = responseStatusCode
	if (ResponseString == 'No updates') {
		logger.debug("Response returned from " + myctx + ": with statusCode " + responseStatusCode + " " + BusinessResponseData);
	} else if (ResponseString !== 'No updates') {

		var OMSUrl = session.parameters.OMSUrl;
		var Token = session.parameters.OMSToken;
		var CrewAssignmentIDGUID = incomingData.TaskUpdate.CrewAssignmentIDGUID;

		var CallIDUrl = OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentIDGUID + '?includeFields=displayID';
		var GetCallID = {
			target: CallIDUrl,
			sslClientProfile: 'omsapi_client_profile',
			method: 'GET',
			contentType: 'application/json',
			headers: {
				'osiApiToken': Token
			}
		};
		var info = " TargetURL :" + GetCallID.target + "; Method :" + GetCallID.method + ". ";
		urlopen.open(GetCallID, function(error, response) {
			if (error) {
				var errorinfo = "url connection error '" + myctx + "', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', errorinfo)
				logger.error(errorinfo);
				session.reject("TaskUpdate_067 : " + errorinfo);
			}
			else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response '" + myctx + "', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							ILSctx.setVariable('ExitStatus', '0');
							ILSctx.setVariable('ExitDescription', OMSExitDescription)
							ILSctx.setVariable('ExitDestination', OMSUrl);
							hm.response.statusCode = '200 OK';
							logger.debug("response received from OMS Get calls by job:" + JSON.stringify(responseData));
							ctx.setVariable("omsResponse", responseData);
							ctx.setVariable("displayID", responseData.displayID);
							var CallID = responseData.displayID;

							var FSEGatewayUrl = session.parameters.FSEUrl2
							var Client = incomingData.CallBackData.Client;
							var ExternalRefID = incomingData.CallBackData.ExternalRefID;
							var Number = incomingData.CallBackData.Number;
							var res = BusinessResponseData.toString();
							var messageID = incomingData.CallBackData.messageID

							ctx.setVariable("ResponseConv", res)

							var ErrorMessagePayload = {
								"CallBackData": {
									"CallID": CallID,
									"messageID": messageID,
									"Number": Number,
									"Client": Client,
									"ServiceName": 'TaskUpdate',
									"ExternalRefID": ExternalRefID
								},
								"ErrorMessage": res
							};

							var FSEGatewayPayloadSend = {
								target: FSEGatewayUrl,
								sslClientProfile: 'omsapijob_RestoreVerify_UpdateStatus_TLS_ClientProfile',
								method: 'POST',
								contentType: 'application/json',
								data: ErrorMessagePayload
							};
							var info = " TargetURL :" + FSEGatewayPayloadSend.target + "; Method :" + FSEGatewayPayloadSend.method + "; Data :" + JSON.stringify(FSEGatewayPayloadSend.data) + ". ";
							urlopen.open(FSEGatewayPayloadSend, function(error, response) {
								if (error) {
									var errorinfo = "url connection error '" + myctx + "', details are : " + info + "; error info :" + error
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response '" + myctx + "', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ExitDescription', errorinfo)
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												ILSctx.setVariable('ExitStatus', '0');
												ILSctx.setVariable('ExitDescription', "Business Error Sent to FSE Successfully")
												ILSctx.setVariable('ExitDestination', FSEGatewayUrl);
												hm.response.statusCode = '200 OK';
												logger.debug("response received from Business Error call:" + responseData)
												//logger.error("Terminating the process as the business error is sent : " + " And status code : " + responseStatusCode + " with response  : " + JSON.stringify(responseData))
												session.reject("Terminated the process as the business error is sent to FSE for the Error with StatusCode :" + BusinessErrorStatus + ". And the response : " + res)

											}
										});
									} else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response '" + myctx + "', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo)
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var buff = Buffer.from(responseData)
											    var ResponseString = buff.toString();
												var errorinfo = "error response '" + myctx + "', details are : " + info + "; response info :" + JSON.stringify(ResponseString) + "; ResponseStatusCode :" + responseStatusCode
												hm.current.statusCode = responseStatusCode;
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo)
												logger.error(errorinfo)
												session.reject("TaskUpdate_069 : " + errorinfo)
											}
										});
									}
								}
							});
						}
					})
				}
				else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response '" + myctx + "', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo)
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var responseStatusCode = response.statusCode;
							var errorinfo = "error response '" + myctx + "', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable('ExitStatus', responseStatusCode);
							ILSctx.setVariable('ExitDescription', errorinfo)
							logger.error(errorinfo)
							session.reject("TaskUpdate_070 : " + errorinfo);
						}
					})
				}
			}
		});
	}
	else {
		response.readAsBuffer(function(error, responseData) {
			if (error) {
				var errorinfo = "error reading response '" + myctx + "', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', responseStatusCode);
				ILSctx.setVariable('ExitDescription', errorinfo)
				logger.error(errorinfo);
				session.reject(errorinfo);
			} else {
				var errorinfo = "error response '" + myctx + "', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
				ILSctx.setVariable('ExitStatus', responseStatusCode);
				ILSctx.setVariable('ExitDescription', errorinfo)
				hm.current.statusCode = responseStatusCode;
				logger.error(errorinfo)
				session.reject("TaskUpdate_070 : " + errorinfo)
			}
		});
	}
};

module.exports = BusinessErrorCall;
