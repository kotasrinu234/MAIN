var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var SeqConfirmRequest = require('./TaskUpdateSend_ConfirmAceReq.js');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var FromRetry = ctx.getVariable("FromRetry")
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		ctx.setVariable("SeqIncoming", incomingdata)

		var dateTime = new Date();
		var SeqConfirmURL = session.parameters.SeqConfirmURL
		var SeqConfirmPayload = {
			"sendTimeStamp": dateTime.toISOString(),
			"confirmation" : 'Y'
		}	
		if(!(incomingdata.messageId === undefined || incomingdata.messageId === null || incomingdata.messageId === "")){
			SeqConfirmPayload.messageId = incomingdata.messageId
		}
		if(!(incomingdata.messageType === undefined || incomingdata.messageType === null || incomingdata.messageType === "")){
			SeqConfirmPayload.messageType = incomingdata.messageType
		}
		if(!(incomingdata.eventType === undefined || incomingdata.eventType === null || incomingdata.eventType === "")){
			SeqConfirmPayload.eventType = incomingdata.eventType
		}
		if(!(incomingdata.serviceName === undefined || incomingdata.serviceName === null || incomingdata.serviceName === "")){
			SeqConfirmPayload.serviceName = incomingdata.serviceName
		}
		if(!(incomingdata.EventTimeStamp === undefined || incomingdata.EventTimeStamp === null || incomingdata.EventTimeStamp === "")){
			SeqConfirmPayload.EventTimeStamp = incomingdata.EventTimeStamp
		}
		if(!(incomingdata.eventContext === undefined || incomingdata.eventContext === null || incomingdata.eventContext === "")){
			SeqConfirmPayload.eventContext = incomingdata.eventContext
		}
		if(!(incomingdata.crewAssignmentID === undefined || incomingdata.crewAssignmentID === null || incomingdata.crewAssignmentID === "")){
			SeqConfirmPayload.crewAssignmentID = incomingdata.crewAssignmentID
		}
		if(!(incomingdata.crewAssignmentDisplayID === undefined || incomingdata.crewAssignmentDisplayID === null || incomingdata.crewAssignmentDisplayID === "")){
			SeqConfirmPayload.crewAssignmentDisplayID = incomingdata.crewAssignmentDisplayID
		}
		if(!(incomingdata.jobID === undefined || incomingdata.jobID === null || incomingdata.jobID === "")){
			SeqConfirmPayload.jobID = incomingdata.jobID
		}
		if(!(incomingdata.crewDisplayID === undefined || incomingdata.crewDisplayID === null || incomingdata.crewDisplayID === "")){
			SeqConfirmPayload.crewDisplayID = incomingdata.crewDisplayID
		}
		if(!(incomingdata.assignmentStatus === undefined || incomingdata.assignmentStatus === null || incomingdata.assignmentStatus === "")){
			SeqConfirmPayload.assignmentStatus = incomingdata.assignmentStatus
		}
		if(!(incomingdata.eventKey === undefined || incomingdata.eventKey === null || incomingdata.eventKey === "")){
			SeqConfirmPayload.eventKey = incomingdata.eventKey
		}
		if(!(incomingdata.workFlowType === undefined || incomingdata.workFlowType === null || incomingdata.workFlowType === "")){
			SeqConfirmPayload.workFlowType = incomingdata.workFlowType
		}
		if(!(incomingdata.workFlowRequirementEvent === undefined || incomingdata.workFlowRequirementEvent === null || incomingdata.workFlowRequirementEvent === "")){
			SeqConfirmPayload.workFlowRequirementEvent = incomingdata.workFlowRequirementEvent
		}
		if(!(incomingdata.waitTimeWorkFlow === undefined || incomingdata.waitTimeWorkFlow === null || incomingdata.waitTimeWorkFlow === "")){
			SeqConfirmPayload.waitTimeWorkFlow = incomingdata.waitTimeWorkFlow
		}

        if (!(FromRetry === "yes")) {
			ctx.setVariable("SeqConfirmPayload", SeqConfirmPayload)
		} else {
			var initialSeqConfirmPayload = ctx.getVariable('initialSeqConfirmPayload')
			ctx.setVariable("SeqConfirmPayload", initialSeqConfirmPayload)
		}
		
	}
})
