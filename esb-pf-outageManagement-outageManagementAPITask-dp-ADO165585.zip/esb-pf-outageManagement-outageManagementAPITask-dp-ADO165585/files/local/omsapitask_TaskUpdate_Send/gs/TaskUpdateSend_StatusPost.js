var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var BusinessErrorCall = require('./BusinessErrorUrlOpen.js');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var checkretry = ctx.getVariable("retry");
var flag = ctx.getVariable("flag")
if (checkretry !== 'yes') {
	session.input.readAsJSON(function(readAsJSONError, incomingData) {
		if (readAsJSONError) {
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data')
			session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
		} else {
			session.output.write(incomingData)
			if (flag !== 'yes') {
				var OMSUrl = session.parameters.OMSUrl;
				var OMSExitDescription = session.parameters.OMSExitDescription;
				if ((OMSUrl == undefined) || (OMSUrl == ' ') || (OMSUrl == null)) {
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', 'Error in connection with OMSUrl')
					session.reject("Error in connection with OMSUrl ");
				} else {
					var CrewAssignmentIDGUID = incomingData.TaskUpdate.CrewAssignmentIDGUID;
					var Token = session.parameters.OMSToken;
					var lookupUrl = session.parameters.lookupUrl;
					session.output.write(incomingData)

					var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
					var PropertiesChangedSplit = PropertiesChanged.split(',');
					ctx.setVariable("PropertiesChangedList", PropertiesChangedSplit);

					if (PropertiesChangedSplit.includes("Status")) {
						var StatusLabel = incomingData.TaskUpdate.CrewAssignmentStatus;
						if ((PropertiesChangedSplit.includes("ETA") ||
							PropertiesChangedSplit.includes("Dispositions") ||
							PropertiesChangedSplit.includes("CompletionRemarks"))) {
						} else {
							var CrewAssignmentIDGUIDUrl = OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentIDGUID;
							StatusPost(CrewAssignmentIDGUIDUrl)
						}
					}

					function StatusPost(CrewAssignmentIDGUIDUrl) {
						var GetWorkTypeID = {
							target: CrewAssignmentIDGUIDUrl,
							sslClientProfile: 'omsapi_client_profile',
							method: 'GET',
							contentType: 'application/json',
							headers: {
								'osiApiToken': Token
							}
						};
						var info = " TargetURL :" + GetWorkTypeID.target + "; Method :" + GetWorkTypeID.method + ". ";
						urlopen.open(GetWorkTypeID, function(error, response) {
							if (error) {
								var errorinfo = "url connection error 'StatusUpdate GetWorkTypeID', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', '500');
								ILSctx.setVariable('ExitDestination', CrewAssignmentIDGUIDUrl);
								ILSctx.setVariable('ExitDescription', errorinfo);
								ctx.setVariable("retry", 'yes');
								var ErrorTxt = "TaskUpdate_023 : " + errorinfo;
								ctx.setVariable("ErrorTxt", ErrorTxt);
								session.output.write(incomingData)
								logger.error(errorinfo);
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsJSON(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'StatusUpdate GetWorkTypeID', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', '500');
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											hm.response.statusCode = '200 OK';
											ILSctx.setVariable('ExitStatus', '0');
											ILSctx.setVariable('ExitDescription', OMSExitDescription);
											ILSctx.setVariable('ExitDestination', OMSUrl);
											logger.debug("response received :" + responseData);

											var workTypeID = responseData.workTypeID;
											ctx.setVariable("workTypeId", workTypeID);
											var status = responseData.status;
											ctx.setVariable("status", status);

											var StatusLookUpPayload = {
												"lookupReq": {
													"type": [
														{
															"name": "workType.workflows",
															"id": workTypeID,
															"label": StatusLabel
														}
													]
												}
											};

											var StatusLookUpOpenUrlPost = {
												target: lookupUrl,
												method: 'POST',
												contentType: 'application/json',
												data: StatusLookUpPayload
											};
											var info = " TargetURL :" + StatusLookUpOpenUrlPost.target + "; Method :" + StatusLookUpOpenUrlPost.method + "; Data :" + JSON.stringify(StatusLookUpOpenUrlPost.data) + ". ";
											urlopen.open(StatusLookUpOpenUrlPost, function(error, response) {
												if (error) {
													var errorinfo = "url connection error 'StatusUpdate LookUp', details are : " + info + "; error info :" + error
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													session.reject("TaskUpdate_024 : " + errorinfo);
												} else {
													var responseStatusCode = response.statusCode;
													if (responseStatusCode == 200) {
														response.readAsJSON(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response 'StatusUpdate LookUp', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ExitDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																hm.response.statusCode = '200 OK';
																ILSctx.setVariable('ExitStatus', '0');
																ILSctx.setVariable('ExitDescription', OMSExitDescription);
																ILSctx.setVariable('ExitDestination', lookupUrl);
																logger.debug("response received from LookUp of Status :" + responseData);
																//		ctx.setVariable("StatusResponseData", responseData);
																if (responseData.lookupRep.type[0].result == 1) {
																	var invalidresp = "Invalid Lookup Request 'StatusUpdate LookUp', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	ILSctx.setVariable('ExitStatus', '1');
																	ILSctx.setVariable('ExitDescription', invalidresp);
																	logger.error(invalidresp);
																	session.reject("TaskUpdate_025 : " + invalidresp)
																} else {
																	var LookUpStatus = responseData.lookupRep.type[0].status;
																	ctx.setVariable("StatusIdentifier", LookUpStatus)

																	var CrewAssignmentIDGUID = incomingData.TaskUpdate.CrewAssignmentIDGUID;
																	var Token = session.parameters.OMSToken;

																	if (status != LookUpStatus) {
																		var StatusPatchUrl = OMSUrl + '/api/v1/ServiceType/Electric/CrewAssignment/' + CrewAssignmentIDGUID + '/WorkFlow';
																		var StatusPatchPayload = {
																			"status": LookUpStatus
																		};

																		var StatusPatchPayloadPatch = {
																			target: StatusPatchUrl,
																			sslClientProfile: 'omsapi_client_profile',
																			method: 'POST',
																			contentType: 'application/json',
																			data: StatusPatchPayload,
																			headers: {
																				'osiApiToken': Token
																			}
																		};
																		var info = " TargetURL :" + StatusPatchPayloadPatch.target + "; Method :" + StatusPatchPayloadPatch.method + "; Data :" + JSON.stringify(StatusPatchPayloadPatch.data) + ". ";
																		urlopen.open(StatusPatchPayloadPatch, function(error, response) {
																			if (error) {
																				var errorinfo = "url connection error 'StatusUpdate', details are : " + info + "; error info :" + error
																				ILSctx.setVariable('ExitStatus', '500');
																				ILSctx.setVariable('ExitDestination', OMSUrl);
																				ILSctx.setVariable('ExitDescription', errorinfo);
																				ctx.setVariable("retry", 'yes');
																				var ErrorTxt = "TaskUpdate_026 : " + errorinfo
																				ctx.setVariable("ErrorTxt", ErrorTxt);
																				session.output.write(incomingData)
																				logger.error(errorinfo);
																			} else {
																				var responseStatusCode = response.statusCode;
																				if (responseStatusCode == 200) {
																					response.readAsJSON(function(error, responseData) {
																						if (error) {
																							var errorinfo = "error reading response 'StatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('ExitStatus', '500');
																							ILSctx.setVariable('ExitDescription', errorinfo);
																							logger.error(errorinfo);
																							Session.reject(errorinfo);
																						} else {
																							hm.response.statusCode = '200 OK';
																							ILSctx.setVariable('ExitStatus', '0');
																							ILSctx.setVariable('ExitDescription', OMSExitDescription);
																							ILSctx.setVariable('ExitDestination', OMSUrl);
																							logger.debug("response received from Status Payload Patch :" + responseData);
																							session.output.write(incomingData)
																						}
																					});
																				} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
																					response.readAsBuffer(function(error, BusinessResponseData) {
																						if (error) {
																							var errorinfo = "error reading response 'StatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('ExitStatus', responseStatusCode);
																							ILSctx.setVariable('ExitDescription', errorinfo)
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							//business error change 1
																							var BusinessResponseData = BusinessResponseData;
																							var buff = Buffer.from(BusinessResponseData);
																							var ResponseString = buff.toString();
																							ctx.setVariable("respo", ResponseString)
																							if (!(ResponseString === "No updates")) {
																								var errorinfo = "error response 'StatusUpdate', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
																								ILSctx.setVariable('ExitStatus', responseStatusCode);
																								ILSctx.setVariable('ExitDescription', errorinfo);
																								logger.error("TaskUpdate_027 : " + errorinfo);
																							}
																							BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "StatusUpdate BusinessError");
																						}
																					});
																				}
																				else {
																					response.readAsBuffer(function(error, responseData) {
																						if (error) {
																							var errorinfo = "TaskUpdate_028 : error reading response 'StatusUpdate', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('ExitStatus', responseStatusCode);
																							ILSctx.setVariable('ExitDescription', errorinfo);
																							logger.error(errorinfo);
																							session.reject(errorinfo);
																						} else {
																							var errorinfo = "TaskUpdate_028 : error response 'StatusUpdate', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																							responseData = responseData.toString()
																							if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
																								var ErrorTxt = "error response 'StatusUpdate', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
																							} else {
																								var ErrorTxt = errorinfo
																							}
																							ILSctx.setVariable('ExitStatus', responseStatusCode);
																							ILSctx.setVariable('ExitDestination', StatusPatchUrl);
																							ILSctx.setVariable('ExitDescription', errorinfo);
																							hm.current.statusCode = responseStatusCode;
																							ctx.setVariable("retry", 'yes');
																							ctx.setVariable("ErrorTxt", ErrorTxt);
																							session.output.write(incomingData)
																							logger.error(errorinfo);
																						}
																					});
																				}
																			}
																		});
																	}
																}
															}
														});
													} else {
														response.readAsBuffer(function(error, responseData) {
															if (error) {
																var errorinfo = "error reading response 'StatusUpdate LookUp', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ExitDescription', errorinfo);
																logger.error(errorinfo);
																session.reject(errorinfo);
															} else {
																var errorinfo = "error response 'StatusUpdate LookUp', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ExitDescription', errorinfo);
																hm.current.statusCode = responseStatusCode;
																logger.error(errorinfo);
																session.reject(errorinfo);
															}
														});
													}
												}
											});
										}
									});
								}
								else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
									response.readAsBuffer(function(error, BusinessResponseData) {
										if (error) {
											var errorinfo = "error reading response 'StatusUpdate GetWorkTypeID', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo)
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											//business error change 2
											var BusinessResponseData = BusinessResponseData;
											var buff = Buffer.from(BusinessResponseData);
											var ResponseString = buff.toString();
											ctx.setVariable("respo", ResponseString)
											if (!(ResponseString === "No updates")) {
												var errorinfo = "error response 'StatusUpdate GetWorkTypeID', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error("TaskUpdate_029 : " + errorinfo);
											}
											BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "StatusUpdate Getcall for worktype Id BusinessError");
										}
									});
								} else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'StatusUpdate GetWorkTypeID', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "TaskUpdate_030 : error response 'StatusUpdate GetWorkTypeID', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											responseData = responseData.toString()
											if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
												var ErrorTxt = "TaskUpdate_030 : error response 'StatusUpdate GetWorkTypeID', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
											} else {
												var ErrorTxt = errorinfo
											}
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDestination', CrewAssignmentIDGUIDUrl);
											ILSctx.setVariable('ExitDescription', errorinfo);
											hm.current.statusCode = responseStatusCode;
											ctx.setVariable("retry", 'yes');
											ctx.setVariable("ErrorTxt", ErrorTxt);
											session.output.write(incomingData)
											logger.error(errorinfo);
										}
									});
								}
							}
						});
					}
				}
			}
		}
	});
}