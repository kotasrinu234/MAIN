var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var BusinessErrorCall = require('./BusinessErrorUrlOpen.js');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var OpenLoopComments = ""
var logger = console.options({
	'category': 'all'
});

var checkretry = ctx.getVariable("retry");
var flag = ctx.getVariable("flag")
if (checkretry !== 'yes') {
	session.input.readAsJSON(function(readAsJSONError, incomingData) {
		if (readAsJSONError) {
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data')
			logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
			session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
		} else {
			session.output.write(incomingData)
			if (flag !== 'yes') {
				var OMSUrl = session.parameters.OMSUrl;
				var OMSExitDescription = session.parameters.OMSExitDescription;
				if ((OMSUrl == undefined) || (OMSUrl == ' ') || (OMSUrl == null)) {
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', 'Error in connection with OMSUrl of Comment')
					logger.error("Error in connection with OMSUrl of Comment");
					session.reject("Error in connection with OMSUrl of Comment");
				} else {
					session.output.write(incomingData)
					var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
					var PropertiesChangedSplit = PropertiesChanged.split(',');
					var JobIDGUID = incomingData.TaskUpdate.JobIDGUID;
					var Token = session.parameters.OMSToken;
					var OpenLoopArray = incomingData.TaskUpdate.OpenLoop
					var Delimiter = session.parameters.Delimiter
					// Start of Openloop 

					if (PropertiesChangedSplit.includes("OpenLoop")) {
						if (incomingData.TaskUpdate.OpenLoop === undefined || incomingData.TaskUpdate.OpenLoop === null || incomingData.TaskUpdate.OpenLoop === " ") {
						} else {

							for (var i = 0; i < OpenLoopArray.length; i++) {
								OpenLoopComments = OpenLoopComments + OpenLoopArray[i].FieldName + Delimiter + OpenLoopArray[i].Value + "\n";
								if (i === OpenLoopArray.length - 1) {
									var FinalCrewID
									var CrewGetCall = ctx.getVariable("CrewGetResponse")
									if (CrewGetCall === null || CrewGetCall === undefined || CrewGetCall === "") {
									} else {
										if (CrewGetCall.customFieldValuesExt === null || CrewGetCall.customFieldValuesExt === undefined || CrewGetCall.customFieldValuesExt === " ") {
											if (CrewGetCall.externalID === null || CrewGetCall.externalID === undefined || CrewGetCall.externalID === " ") {
											} else {
												FinalCrewID = CrewGetCall.externalID
											}
										} else {
											if (CrewGetCall.customFieldValuesExt.CrewID === null || CrewGetCall.customFieldValuesExt.CrewID === undefined || CrewGetCall.customFieldValuesExt.CrewID === "") {
												if (CrewGetCall.externalID === null || CrewGetCall.externalID === undefined || CrewGetCall.externalID === " ") {
												} else {
													FinalCrewID = CrewGetCall.externalID
												}
											} else {
												FinalCrewID = CrewGetCall.customFieldValuesExt.CrewID
											}
										}
									}

									if (FinalCrewID === null || FinalCrewID === undefined || FinalCrewID === " ") {
									} else {
										var Crew = "Crew" + Delimiter + FinalCrewID
										OpenLoopComments = OpenLoopComments + Crew
									}
								}
							}

							var OpenLoopPayload = {
								"comment": OpenLoopComments
							}
							var OpenLoopUrl = OMSUrl + '/api/v1/ServiceType/Electric/Job/' + JobIDGUID + '/Comment'
							var OpenLoopPayloadPost = {
								target: OpenLoopUrl,
								sslClientProfile: 'omsapi_client_profile',
								method: 'POST',
								contentType: 'application/json',
								data: OpenLoopPayload,
								headers: {
									'osiApiToken': Token
								}
							};
							var info = " TargetURL :" + OpenLoopPayloadPost.target + "; Method :" + OpenLoopPayloadPost.method + "; Data :" + JSON.stringify(OpenLoopPayloadPost.data) + ". ";
							urlopen.open(OpenLoopPayloadPost, function(error, response) {
								if (error) {
									var errorinfo = "url connection error 'OpenLoop CommentsUpdate', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDestination', OpenLoopUrl);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									ctx.setVariable("retry", 'yes');
									var ErrorTxt = "TaskUpdate_039 : " + errorinfo
									ctx.setVariable("ErrorTxt", ErrorTxt);
									session.output.write(incomingData)
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'OpenLoop CommentsUpdate', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												session.output.write(incomingData)
												hm.response.statusCode = '200 OK';
												ILSctx.setVariable('ExitStatus', '0');
												ILSctx.setVariable('ExitDescription', OMSExitDescription);
												ILSctx.setVariable('ExitDestination', OMSUrl);
												logger.debug("response received from OpenLoop Comment Payload Post :" + JSON.stringify(responseData));
											}
										});
									} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
										response.readAsBuffer(function(error, BusinessResponseData) {
											if (error) {
												var errorinfo = "error reading response 'OpenLoop CommentsUpdate', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo)
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												//business error change
												var BusinessResponseData = BusinessResponseData;
												var buff = Buffer.from(BusinessResponseData);
												var ResponseString = buff.toString();
												ctx.setVariable("respo", ResponseString)
												if (!(ResponseString === "No updates")) {
													var errorinfo = "error response 'OpenLoop CommentsUpdate', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable('ExitStatus', responseStatusCode);
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error("TaskUpdate_040 : " + errorinfo);
												}
												BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "OpenLoop CommentsUpdates BusinessError");
											}
										});
									}
									else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'OpenLoop CommentsUpdate', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "TaskUpdate_041 : error response 'OpenLoop CommentsUpdate', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												responseData = responseData.toString()
												if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
													var ErrorTxt = "TaskUpdate_041 : error response 'OpenLoop CommentsUpdate', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
												} else {
													var ErrorTxt = errorinfo
												}
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDestination', OMSUrl);
												ILSctx.setVariable('ExitDescription', errorinfo);
												hm.current.statusCode = responseStatusCode;
												logger.error(errorinfo);
												ctx.setVariable("retry", 'yes');
												ctx.setVariable("ErrorTxt", ErrorTxt);
												session.output.write(incomingData)
											}
										});
									}
								}
							});
						}
					}
				}
			}
		}
	})
}