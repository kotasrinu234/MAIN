var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ms = require('multistep');
var urlopen = require('urlopen');
var PutToQueueError = ctx.getVariable("PutToQueueError")
var ETRQueueError = ctx.getVariable("ETRQueueError")
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name('ILS') || session.createContext('ILS');
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
		logger.error("Error in reading incoming data" + JSON.stringify(error));
		session.reject("error in reading incoming data" + JSON.stringify(error));
	} else {
		session.output.write(incomingData)
		ctx.setVariable("incomingData", incomingData)

		if ((ETRQueueError === "" || ETRQueueError === undefined || ETRQueueError === null)) {
		} else {
			if (ETRQueueError === 'yes') {
				var flag = 'yes'
				ctx.setVariable("flag", flag)
			}
		}

		if ((PutToQueueError === "" || PutToQueueError === undefined || PutToQueueError === null)) {
		} else {
			if (PutToQueueError === 'yes') {
				var flag = 'yes'
				ctx.setVariable("flag", flag)
			}
		}

		if (incomingData.TaskUpdate === null ||
			incomingData.TaskUpdate === undefined ||
			incomingData.TaskUpdate === '') {
		} else {
			var lookupUrl = session.parameters.lookupUrl;
			var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
			var PropertiesChangedSplit = PropertiesChanged.split(',');
			if (PropertiesChangedSplit.includes("Dispositions")) {
				var Dispositions = incomingData.TaskUpdate.Dispositions;
				var DispositionsNames = []
				for (var i = 0; i < Dispositions.length; i++) {
					var dis =
					{
						"name": "crewAssignmentCustomFields",
						"externalLabel": "Disposition",
						"label": Dispositions[i].Name
					};
					DispositionsNames.push(dis);
				}
				var DispositionsLookUpPayload = {
					"lookupReq": {
						"type": DispositionsNames
					}
				}
				var DispositionsLookUp = {
					target: lookupUrl,
					method: 'POST',
					contentType: 'application/json',
					data: DispositionsLookUpPayload
				};
				var info = " TargetURL: " + DispositionsLookUp.target + "; Method: " + DispositionsLookUp.method + "; Data: " + JSON.stringify(DispositionsLookUp.data) + ". ";
				urlopen.open(DispositionsLookUp, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'DispositionsLookUp', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject("TaskUpdate_002 : " + errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'DispositionsLookUp', details are :" + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("Response received from Dispositions LookUp Payload Post" + JSON.stringify(responseData));
									//	ctx.setVariable("ResponseData2", responseData);
									if (responseData.lookupRep.type[0].result == 1) {
										var invalidresp = "Invalid Lookup Request 'DispositionsLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', '1');
										ILSctx.setVariable('ExitDescription', invalidresp);
										logger.error(invalidresp);
										session.reject("TaskUpdate_003 : " + invalidresp)
									} else {
										ILSctx.setVariable('ExitStatus', '0');
										var DispositionResponse = responseData.lookupRep.type;
										var DispositionStatus = []
										for (var j = 0; j < DispositionResponse.length; j++) {
											var DisStatus = DispositionResponse[j].status;
											var Result = DispositionResponse[j].result
											if (Result == 1) {
												var invalidresp = "Invalid Lookup Request 'DispositionsLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', '1');
												ILSctx.setVariable('ExitDescription', invalidresp);
												logger.error(invalidresp);
												session.reject("TaskUpdate_003 : " + invalidresp)
											} else {
												DispositionStatus.push(DisStatus);
											}
										}
										ctx.setVariable("DispositionStatus", DispositionStatus)
									}
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure reading the error response 'DispositionsLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error response 'DispositionsLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									hm.current.statusCode = responseStatusCode;
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
				ctx.setVariable("DispositionsNames", DispositionsNames);
			}
			if (PropertiesChangedSplit.includes("OutageSubtype")) {
				var OutageSubtype = incomingData.TaskUpdate.OutageSubtype;
				var OUtageSubtypeLookUpPayload = {
					"lookupReq": {
						"type": [

							{

								"name": "outageSubtypes",
								"label": OutageSubtype
							}
						]
					}
				};

				var OUtageSubtypeLookUp = {
					target: lookupUrl,
					method: 'POST',
					contentType: 'application/json',
					data: OUtageSubtypeLookUpPayload
				}
				var info = " TargetURL: " + OUtageSubtypeLookUp.target + "; Method: " + OUtageSubtypeLookUp.method + "; Data: " + JSON.stringify(OUtageSubtypeLookUp.data) + ". ";
				urlopen.open(OUtageSubtypeLookUp, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'OUtageSubtypeLookUp', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject("TaskUpdate_002 : " + errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'OUtageSubtypeLookUp', details are :" + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = '200 OK';
									logger.debug("response received :" + responseData);
									//	ctx.setVariable("ResponseOutage", responseData)
									if (responseData.lookupRep.type[0].result == 1) {
										var invalidresp = "Invalid Lookup Request 'OUtageSubtypeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', '1');
										ILSctx.setVariable('ExitDescription', invalidresp);
										logger.error(invalidresp);
										session.reject("TaskUpdate_004 : " + invalidresp)
									} else {
										ILSctx.setVariable('ExitStatus', '0');
										var InternalId = responseData.lookupRep.type[0].id;
										ctx.setVariable("OutageInternalID", InternalId)
									}
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure reading the error response 'OUtageSubtypeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error response 'OUtageSubtypeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									hm.current.statusCode = responseStatusCode;
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			}
			if (PropertiesChangedSplit.includes("CauseCode")) {
				var CauseCode = incomingData.TaskUpdate.CauseCode;
				var CauseCodeLookUpPayload = {
					"lookupReq": {
						"type": [
							{
								"name": "jobCustomFields.workflows",
								"label": CauseCode
							}
						]
					}
				};
				var CauseCodeLookUp = {
					target: lookupUrl,
					method: 'POST',
					contentType: 'application/json',
					data: CauseCodeLookUpPayload
				};
				var info = " TargetURL: " + CauseCodeLookUp.target + "; Method: " + CauseCodeLookUp.method + "; Data: " + JSON.stringify(CauseCodeLookUp.data) + ". ";
				urlopen.open(CauseCodeLookUp, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'CauseCodeLookUp', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo)
						logger.error(errorinfo);
						session.reject("TaskUpdate_002 :  " + errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'CauseCodeLookUp', details are :" + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = '200 OK';
									logger.debug("response received :" + JSON.stringify(responseData));
									//	ctx.setVariable("CauseCodeResponse", responseData)
									if (responseData.lookupRep.type[0].result == 1) {
										var invalidresp = "Invalid Lookup Request 'CauseCodeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', '1');
										ILSctx.setVariable('ExitDescription', invalidresp);
										logger.error(invalidresp);
										session.reject("TaskUpdate_005 : " + invalidresp)
									} else {
										ILSctx.setVariable('ExitStatus', '0');
										var InternalID = responseData.lookupRep.type[0].status;
										ctx.setVariable("CauseCodeIdentifier", InternalID)
									}
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure reading the error response 'CauseCodeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error response 'CauseCodeLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									hm.current.statusCode = responseStatusCode;
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
			}
			if (PropertiesChangedSplit.includes("MaterialsAffected")) {
				var MaterialsAffected = incomingData.TaskUpdate.MaterialsAffected;
				var MaterialsAffectedNames = []
				for (var i = 0; i < MaterialsAffected.length; i++) {
					var dis =
					{
						"name": "jobCustomFields.materialAffected",
						"label": MaterialsAffected[i].Name
					};
					MaterialsAffectedNames.push(dis);
				}
				var MaterialsAffectedLookUpPayload = {
					"lookupReq": {
						"type": MaterialsAffectedNames
					}
				}
				var MaterialsAffectedLookUp = {
					target: lookupUrl,
					method: 'POST',
					contentType: 'application/json',
					data: MaterialsAffectedLookUpPayload
				};
				var info = " TargetURL: " + MaterialsAffectedLookUp.target + "; Method: " + MaterialsAffectedLookUp.method + "; Data: " + JSON.stringify(MaterialsAffectedLookUp.data) + ". ";
				urlopen.open(MaterialsAffectedLookUp, function(error, response) {
					if (error) {
						var errorinfo = "url connection error 'MaterialsAffectedLookUp', details are : " + info + "; error info :" + error
						ILSctx.setVariable('ExitStatus', '500');
						ILSctx.setVariable('ExitDescription', errorinfo);
						logger.error(errorinfo);
						session.reject("TaskUpdate_002 : " + errorinfo);
					} else {
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {
							response.readAsJSON(function(error, responseData) {
								if (error) {
									var errorinfo = "error reading response 'MaterialsAffectedLookUp', details are :" + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									hm.response.statusCode = responseStatusCode;
									logger.debug("Response received from MaterialsAffected LookUp Payload Post" + JSON.stringify(responseData));
									//	ctx.setVariable("ResponseData2", responseData);
									if (responseData.lookupRep.type[0].result == 1) {
										var invalidresp = "Invalid Lookup Request 'MaterialsAffectedLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
										ILSctx.setVariable('ExitStatus', '1');
										ILSctx.setVariable('ExitDescription', invalidresp);
										logger.error(invalidresp);
										session.reject("TaskUpdate_003 : " + invalidresp)
									} else {
										ILSctx.setVariable('ExitStatus', '0');
										var MaterialsAffectedResponse = responseData.lookupRep.type;
										var MaterialsAffectedStatus = []
										for (var j = 0; j < MaterialsAffectedResponse.length; j++) {
											var DisStatus = MaterialsAffectedResponse[j].status;
											var Result = MaterialsAffectedResponse[j].result

											if (Result == 1) {
												var invalidresp = "Invalid Lookup Request 'MaterialsAffectedLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', '1');
												ILSctx.setVariable('ExitDescription', invalidresp);
												logger.error(invalidresp);
												session.reject("TaskUpdate_003 : " + invalidresp)
											} else {
												MaterialsAffectedStatus.push(DisStatus);
											}
										}
										ctx.setVariable("MaterialsAffectedStatus", MaterialsAffectedStatus)
									}
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {
									var errorinfo = "failure reading the error response 'MaterialsAffectedLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									var errorinfo = "error response 'MaterialsAffectedLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
									ILSctx.setVariable('ExitStatus', responseStatusCode);
									ILSctx.setVariable('ExitDescription', errorinfo);
									hm.current.statusCode = responseStatusCode;
									logger.error(errorinfo);
									session.reject(errorinfo);
								}
							});
						}
					}
				});
				ctx.setVariable("MaterialsAffectedNames", MaterialsAffectedNames);
			}
		}
	}
});
