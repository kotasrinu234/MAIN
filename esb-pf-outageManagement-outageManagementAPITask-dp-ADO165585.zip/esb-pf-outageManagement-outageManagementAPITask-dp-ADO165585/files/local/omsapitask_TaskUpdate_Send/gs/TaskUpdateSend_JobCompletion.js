var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var ms = require('multistep');
var BusinessErrorCall = require('./BusinessErrorUrlOpen.js');
var OMSExitDescription = session.parameters.OMSExitDescription
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var checkretry = ctx.getVariable("retry");
if (checkretry !== 'yes') {
	var flag = ctx.getVariable("flag")
	session.input.readAsJSON(function(readAsJSONError, incomingData) {
		if (readAsJSONError) {
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data')
			logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
			session.reject(readAsJSONError);
		} else {
			session.output.write(incomingData)
			if (flag !== 'yes') {
				var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
				var PropertiesChangedSplit = PropertiesChanged.split(',');
				ctx.setVariable("PropertiesChangedList", PropertiesChangedSplit);
				var CloseCancelRemarks = incomingData.TaskUpdate.CloseCancelRemarks;

				if (PropertiesChangedSplit.includes("JobClosed")) {
					var JobClosed = incomingData.TaskUpdate.JobClosed;
					if (JobClosed === true) {

						if ((CloseCancelRemarks == undefined) || (CloseCancelRemarks == '') || (CloseCancelRemarks == null)) {
							session.output.write(incomingData)
						} else {
							var OMSUrl = session.parameters.OMSUrl;
							if ((OMSUrl == undefined) || (OMSUrl == ' ') || (OMSUrl == null)) {
								ILSctx.setVariable('ExitStatus', '500');
								ILSctx.setVariable('ExitDescription', 'Error in connection with OMSUrl of JobCompletion')
								logger.error("TaskUpdate_042 : Error in connection with OMSUrl of JobCompletion");
								session.reject("Error in connection with OMSUrl of JobCompletion");
							} else {
								session.output.write(incomingData)
								var CrewAssignmentIDGUID = incomingData.TaskUpdate.CrewAssignmentIDGUID;
								var Token = session.parameters.OMSToken;
								var JobIDGUID = incomingData.TaskUpdate.JobIDGUID;
								var JobIDGUIDUrl = OMSUrl + '/api/v1/ServiceType/Electric/Job/' + JobIDGUID + '?includeFields=status,jobTypeID,activeCrewAssignmentCount';
								var GetCallResponseData = {
									target: JobIDGUIDUrl,
									sslClientProfile: 'omsapi_client_profile',
									method: 'GET',
									contentType: 'application/json',
									headers: {
										'osiApiToken': Token
									}
								};
								var info = " TargetURL :" + GetCallResponseData.target + "; Method :" + GetCallResponseData.method + ". ";
								urlopen.open(GetCallResponseData, function(error, response) {
									if (error) {
										var errorinfo = "url connection error 'JobCompletion Get Call', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', '500');
										ILSctx.setVariable('ExitDestination', JobIDGUIDUrl);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										ctx.setVariable("retry", 'yes');
										var ErrorTxt = "TaskUpdate_043 : " + errorinfo;
										ctx.setVariable("ErrorTxt", ErrorTxt);
										session.output.write(incomingData)
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode === 200) {
											response.readAsJSON(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'JobCompletion', details are : " + info + "; error info :" + error
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													ILSctx.setVariable('ExitStatus', '0');
													ILSctx.setVariable('ExitDescription', OMSExitDescription)
													ILSctx.setVariable('ExitDestination', OMSUrl);
													hm.response.statusCode = '200 OK';
													logger.debug("response received from Get Call Response Data :" + responseData);
													ctx.setVariable("ResponseData", responseData)
													// LookUp for finding outage type
													var lookupUrl = session.parameters.lookupUrl;
													var jobTypeID = responseData.jobTypeID;
													var status = responseData.status;
													//var activeCrewAssignmentCount = responseData.activeCrewAssignmentCount
													if (responseData.activeCrewAssignmentCount === 0) {
														var outageTypeLookup = {
															"lookupReq": {
																"type": [{
																	"name": "jobOutageTypes",
																	"id": jobTypeID,
																	"status": status
																}]
															}
														}
														var outageTypeLookupPost = {
															target: lookupUrl,
															method: 'POST',
															contentType: 'application/json',
															data: outageTypeLookup
														}
														var info = " TargetURL :" + outageTypeLookupPost.target + "; Method :" + outageTypeLookupPost.method + "; Data :" + JSON.stringify(outageTypeLookupPost.data) + ". ";
														urlopen.open(outageTypeLookupPost, function(error, response) {
															if (error) {
																var errorinfo = "url connection error 'JobCompletion', details are : " + info + "; error info :" + error
																ILSctx.setVariable('ExitStatus', '500');
																ILSctx.setVariable('ExitDescription', session.reject);
																logger.error(errorinfo);
																session.reject("TaskUpdate_044 : " + errorinfo);
															} else {
																var responseStatusCode = response.statusCode;
																if (responseStatusCode == 200) {
																	response.readAsJSON(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'JobCompletion', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', '500');
																			ILSctx.setVariable('ExitDescription', errorinfo);
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			hm.response.statusCode = '200 OK';
																			logger.debug("response received from outage Type Lookup Post :" + JSON.stringify(responseData));
																			ctx.setVariable("Response", responseData)
																			if (responseData.lookupRep.type[0].result == 1) {
																				var invalidresp = "Invalid Lookup Request of outageTypeLookupPost 'JobCompletion', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																				ILSctx.setVariable('ExitStatus', '1');
																				ILSctx.setVariable('ExitDescription', invalidresp);
																				logger.error(invalidresp)
																				session.reject("TaskUpdate_045 : " + invalidresp)
																			} else {
																				ILSctx.setVariable('ExitStatus', '0');
																				ILSctx.setVariable('ExitDescription', OMSExitDescription)
																				ILSctx.setVariable('ExitDestination', lookupUrl);
																				var outageType = responseData.lookupRep.type[0].label;
																				ctx.setVariable("outageType", outageType);

																				if (outageType == "NON_OUTAGE") {

																					var worlFlowLookup = {
																						"lookupReq": {
																							"type": [{
																								"name": "jobTypes.workflows",
																								"id": jobTypeID,
																								"label": "Completed"
																							}]
																						}
																					};
																					var workFlowLookupPost = {
																						target: lookupUrl,
																						method: 'POST',
																						contentType: 'application/json',
																						data: worlFlowLookup
																					}
																					var info = " TargetURL :" + workFlowLookupPost.target + "; Method :" + workFlowLookupPost.method + "; Data :" + JSON.stringify(workFlowLookupPost.data) + ". ";
																					urlopen.open(workFlowLookupPost, function(error, response) {
																						if (error) {
																							var errorinfo = "url connection error 'JobCompletion', details are : " + info + "; error info :" + error
																							ILSctx.setVariable('ExitStatus', '500');
																							ILSctx.setVariable('ExitDescription', errorinfo);
																							logger.error(errorinfo);
																							session.reject("TaskUpdate_046 : " + errorinfo);
																						} else {
																							var responseStatusCode = response.statusCode;
																							if (responseStatusCode == 200) {
																								response.readAsJSON(function(error, responseData) {
																									if (error) {
																										var errorinfo = "error reading response 'workFlowLookupPost', details are : " + info + "; error info :" + error
																										ILSctx.setVariable('ExitStatus', '500');
																										ILSctx.setVariable('ExitDescription', errorinfo);
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									} else {
																										hm.response.statusCode = '200 OK';
																										logger.debug("response received from workFlow Lookup Post :" + JSON.stringify(responseData));
																										if (responseData.lookupRep.type[0].result == 1) {
																											var invalidresp = "Invalid Lookup Request 'workFlowLookupPost', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																											ILSctx.setVariable('ExitStatus', '1');
																											ILSctx.setVariable('ExitDescription', invalidresp);
																											logger.error(invalidresp)
																											session.reject("TaskUpdate_047: " + invalidresp)
																										} else {
																											ILSctx.setVariable('ExitStatus', '0');
																											ILSctx.setVariable('ExitDescription', OMSExitDescription)
																											ILSctx.setVariable('ExitDestination', lookupUrl);
																											var Respstatus = responseData.lookupRep.type[0].status;
																											ctx.setVariable("RespStatus", Respstatus)
																											var RespStatusUrl = OMSUrl + '/api/v1/ServiceType/Electric/Job/' + JobIDGUID + '/WorkFlow';

																											var RespStatusPayloadPost = {
																												target: RespStatusUrl,
																												sslClientProfile: 'omsapi_client_profile',
																												method: 'POST',
																												contentType: 'application/json',
																												data: Respstatus,
																												headers: {
																													'osiApiToken': Token
																												}
																											};
																											var info = " TargetURL :" + RespStatusPayloadPost.target + "; Method :" + RespStatusPayloadPost.method + "; Data :" + JSON.stringify(RespStatusPayloadPost.data) + ". ";
																											urlopen.open(RespStatusPayloadPost, function(error, response) {
																												if (error) {
																													var errorinfo = "url connection error 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																													ILSctx.setVariable('ExitStatus', '500');
																													ILSctx.setVariable('ExitDestination', OMSUrl);
																													ILSctx.setVariable('ExitDescription', errorinfo);
																													logger.error(errorinfo);
																													ctx.setVariable("retry", 'yes');
																													var ErrorTxt = "TaskUpdate_048 : " + errorinfo;
																													ctx.setVariable("ErrorTxt", ErrorTxt);
																													session.output.write(incomingData)
																													//session.reject("urlopen connect error while opening the RespStatus Payload Post url " + JSON.stringify(error));
																												} else {
																													var responseStatusCode = response.statusCode;
																													if (responseStatusCode == 200) {
																														response.readAsJSON(function(error, responseData) {
																															if (error) {
																																var errorinfo = "error reading response 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																																ILSctx.setVariable('ExitStatus', '500');
																																ILSctx.setVariable('ExitDescription', errorinfo);
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															} else {
																																ILSctx.setVariable('ExitStatus', '0');
																																ILSctx.setVariable('ExitDescription', OMSExitDescription)
																																ILSctx.setVariable('ExitDestination', OMSUrl);
																																hm.response.statusCode = '200 OK';
																																logger.debug("response received from RespStatus Payload Post  :" + JSON.stringify(responseData));
																																session.output.write(incomingData)
																															}
																														});
																													} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
																														response.readAsBuffer(function(error, BusinessResponseData) {
																															if (error) {
																																var errorinfo = "error reading response 'StatusUpdate', details are : " + info + "; error info :" + error
																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ExitDescription', errorinfo)
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															} else {
																																//business error change 1
																																var BusinessResponseData = BusinessResponseData;
																																var buff = Buffer.from(BusinessResponseData);
																																var ResponseString = buff.toString();
																																ctx.setVariable("respo", ResponseString)
																																if (!(ResponseString === "No updates")) {
																																	var errorinfo = "error response 'JobCompletionStatus BusinessError', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
																																	ILSctx.setVariable('ExitStatus', responseStatusCode);
																																	ILSctx.setVariable('ExitDescription', errorinfo);
																																	logger.error("TaskUpdate_049 : " + errorinfo);
																																}
																																BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "JobCompletion for StatusPost");
																															}

																														});
																													} else {
																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																var errorinfo = "error reading response 'RespStatusPayloadPost', details are : " + info + "; error info :" + error
																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ExitDescription', errorinfo);
																																logger.error(errorinfo);
																																session.reject(errorinfo);
																															} else {
																																var errorinfo = "TaskUpdate_050 : error response 'RespStatusPayloadPost', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																																responseData = responseData.toString()
																																if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
																																	var ErrorTxt = "TaskUpdate_050 : error response 'RespStatusPayloadPost', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
																																} else {
																																	var ErrorTxt = errorinfo
																																}
																																ILSctx.setVariable('ExitStatus', responseStatusCode);
																																ILSctx.setVariable('ExitDestination', RespStatusUrl);
																																ILSctx.setVariable('ExitDescription', errorinfo);
																																hm.current.statusCode = responseStatusCode;
																																logger.error(errorinfo);
																																ctx.setVariable("retry", 'yes');
																																ctx.setVariable("ErrorTxt", ErrorTxt);
																																session.output.write(incomingData)
																																//session.reject("Error returned from RespStatus Payload Post  " + ": with statusCode " + responseStatusCode + " " + responseData);
																															}
																														});
																													}
																												}
																											});

																										}
																									}
																								});
																							} else {
																								response.readAsBuffer(function(error, responseData) {
																									if (error) {
																										var errorinfo = "error reading response 'workFlowLookupPost', details are : " + info + "; error info :" + error
																										ILSctx.setVariable('ExitStatus', '500');
																										ILSctx.setVariable('ExitDescription', errorinfo);
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									} else {
																										var errorinfo = "error response 'workFlowLookupPost', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																										ILSctx.setVariable('ExitStatus', '500');
																										ILSctx.setVariable('ExitDescription', errorinfo);
																										hm.current.statusCode = responseStatusCode;
																										logger.error(errorinfo);
																										session.reject(errorinfo);
																									}
																								});
																							}
																						}
																					});
																					//}
																					//}
																				} else {

																					var JobClosureUrl = session.parameters.JobClosureUrl
																					var JobClosureExitDescription = session.parameters.JobClosureExitDescription
																					ILSctx.setVariable('ExitDestination', JobClosureUrl);
																					ILSctx.setVariable('ExitDescription', JobClosureExitDescription);
																					ms.callRule('omsapitask_TaskUpdate_Send_Processing_Policy_ILSExit_Rule', null, null, function(error) {
																						if (error) {
																							throw error;
																						}
																					});
																					var payload = {
																						"serviceName": "Interface47",
																						"jobId": JobIDGUID,
																						"userId": "FSEMobile"
																					}
																					if (incomingData.CallBackData.messageID === undefined || incomingData.CallBackData.messageID === null || incomingData.CallBackData.messageID === "") { } else {
																						payload.msgId = incomingData.CallBackData.messageID
																					}
																					if (incomingData.CallBackData.TimeModified === undefined || incomingData.CallBackData.TimeModified === null || incomingData.CallBackData.TimeModified === "") { } else {
																						payload.timesStamp = incomingData.CallBackData.TimeModified + "Z"
																					}
																					var pushingToQueue = {
																						target: JobClosureUrl,
																						data: payload
																					};
																					var info = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";

																					try {
																						urlopen.open(pushingToQueue, function(error, response) {
																							var hm = require('header-metadata');
																							if (error) {
																								var errorinfo = "url connection error queue OMSAPIJOB.OUTAGE.JOB.CLOSURE.REQUEST 'JobClosure', details are : " + info + "; error info :" + error
																								ILSctx.setVariable('ExitStatus', '500');
																								ILSctx.setVariable('ExitDestination', JobClosureUrl);
																								ILSctx.setVariable('ExitDescription', errorinfo)
																								logger.error(errorinfo);
																								ctx.setVariable("retry", 'yes');
																								var ErrorTxt = "TaskUpdate_067 : " + errorinfo;
																								ctx.setVariable("ErrorTxt", ErrorTxt);
																							} else {
																								var mqrc = response.statusCode;
																								if (mqrc == 0) {
																									var replyMQMD = response.get({
																										type: 'mq'
																									}, 'MQMD');
																									var replyMQRFH2 = response.get({
																										type: 'mq'
																									}, 'MQRFH2');
																									response.readAsBuffer(function(readError, responseData) {
																										if (readError) {
																											var errorinfo = "failure in reading response queue OMSAPIJOB.OUTAGE.JOB.CLOSURE.REQUEST 'JobClosure', details are : " + info + "; error info :" + error
																											ILSctx.setVariable('ExitStatus', '500');
																											ILSctx.setVariable('ExitDescription', errorinfo)
																											hm.response.statusCode = 500
																											logger.error(errorinfo);
																											session.reject(errorinfo);
																										} else {
																											ILSctx.setVariable('ExitStatus', '0');
																											ILSctx.setVariable('ExitDescription', JobClosureExitDescription)
																											ILSctx.setVariable('ExitDestination', JobClosureUrl);
																											logger.debug("MQResponsecode " + mqrc);
																										}
																									});
																								} else {
																									var errorinfo = "urlopen connect error to queue OMSAPIJOB.OUTAGE.JOB.CLOSURE.REQUEST 'JobClosure', details are : " + info + "; response info :" + response + "; ResponseStatusCode :" + response.statusCode
																									ILSctx.setVariable('ExitStatus', '500');
																									ILSctx.setVariable('ExitDestination', JobClosureUrl);
																									ILSctx.setVariable('ExitDescription', errorinfo)
																									logger.error(errorinfo);
																									ctx.setVariable("retry", 'yes');
																									var ErrorTxt = "TaskUpdate_067 : " + errorinfo;
																									ctx.setVariable("ErrorTxt", ErrorTxt);
																								}
																							}
																						})
																					} catch (err) {
																						var errorinfo = "url connection error queue OMSAPIJOB.OUTAGE.JOB.CLOSURE.REQUEST 'JobClosure', details are : " + info + "; error info :" + err
																						ILSctx.setVariable('ExitStatus', '500');
																						ILSctx.setVariable('ExitDestination', JobClosureUrl);
																						ILSctx.setVariable('ExitDescription', errorinfo)
																						logger.error(errorinfo);
																						ctx.setVariable("retry", 'yes');
																						var ErrorTxt = "TaskUpdate_067 : " + errorinfo;
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																					}
																				}
																			}
																		}
																	});
																} else {
																	response.readAsBuffer(function(error, responseData) {
																		if (error) {
																			var errorinfo = "error reading response 'JobCpmpletion GetResponseData', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', '500');
																			ILSctx.setVariable('ExitDescription', errorinfo)
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		} else {
																			var errorinfo = "error response 'JobCompletion GetResponseData', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', '500');
																			ILSctx.setVariable('ExitDescription', errorinfo)
																			hm.current.statusCode = responseStatusCode;
																			logger.error(errorinfo);
																			session.reject(errorinfo);
																		}
																	});
																}
															}
														});
													}
												}
											});
										}
										else if ((responseStatusCode === 400) || (responseStatusCode === 404)) {
											response.readAsBuffer(function(error, BusinessResponseData) {
												if (error) {
													var errorinfo = "error reading response 'JobCompletionStatus', details are : " + info + "; error info :" + error
													ILSctx.setVariable('ExitStatus', responseStatusCode);
													ILSctx.setVariable('ExitDescription', errorinfo)
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var BusinessResponseData = BusinessResponseData;
													var buff = Buffer.from(BusinessResponseData);
													var ResponseString = buff.toString();
													ctx.setVariable("respo", ResponseString)
													if (!(ResponseString === "No updates")) {
														var errorinfo = "error response 'JobCompletion Get Call for Jobtype ID ', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
														ILSctx.setVariable('ExitStatus', responseStatusCode);
														ILSctx.setVariable('ExitDescription', errorinfo);
														logger.error("TaskUpdate_051 : " + errorinfo);
													}
													BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "JobCompletion Get Call for Jobtype ID BusinessError");
												}
											});
										} else {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'JobCompletion GetCallResponseData', details are : " + info + "; error info :" + error
													ILSctx.setVariable('ExitStatus', responseStatusCode);
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "TaskUpdate_052 : error response 'JobCompletion GetCallResponseData', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													responseData = responseData.toString()
													if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
														var ErrorTxt = "TaskUpdate_052 : error response 'JobCompletion GetCallResponseData', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
													} else {
														var ErrorTxt = errorinfo
													}
													ILSctx.setVariable('ExitStatus', responseStatusCode);
													ILSctx.setVariable('ExitDestination', JobIDGUIDUrl);
													ILSctx.setVariable('ExitDescription', errorinfo);
													hm.current.statusCode = responseStatusCode;
													logger.error(errorinfo);
													ctx.setVariable("retry", 'yes');
													ctx.setVariable("ErrorTxt", ErrorTxt);
													session.output.write(incomingData)
												}
											});
										}
									}
								});
							}
						}
					}
				}
			}
		}
	});
}