var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var BusinessErrorCall = require('./BusinessErrorUrlOpen.js');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var OpenLoopComments = ""
var logger = console.options({
	'category': 'all'
});

var checkretry = ctx.getVariable("retry");
var flag = ctx.getVariable("flag")
if (checkretry !== 'yes') {
	session.input.readAsJSON(function(readAsJSONError, incomingData) {
		if (readAsJSONError) {
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data' + JSON.stringify(readAsJSONError))
			logger.error("error in reading incoming data" + JSON.stringify(readAsJSONError));
			session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
		} else {
			session.output.write(incomingData)
			if (flag !== 'yes') {
				var OMSUrl = session.parameters.OMSUrl;
				var OMSExitDescription = session.parameters.OMSExitDescription;
				if ((OMSUrl == undefined) || (OMSUrl == ' ') || (OMSUrl == null)) {
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDescription', "omsurl not defined or null 'CommentsUpdate'")
					logger.error("omsurl not defined or null 'CommentsUpdate'");
					session.reject("omsurl not defined or null 'CommentsUpdate'");
				} else {
					session.output.write(incomingData)
					var CrewAssignmentIDGUID = incomingData.TaskUpdate.CrewAssignmentIDGUID;
					var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
					var PropertiesChangedSplit = PropertiesChanged.split(',');
					var JobIDGUID = incomingData.TaskUpdate.JobIDGUID;
					var Token = session.parameters.OMSToken;

					if (PropertiesChangedSplit.includes("Comments")) {
						var Comments = incomingData.TaskUpdate.Comments;
						var CommentUrl = OMSUrl + '/api/v1/ServiceType/Electric/Job/' + JobIDGUID + '/Comment';

						for (var i = 0; i < Comments.length; i++) {
							var Comment = Comments[i].Comment
							var CommentPayload = {
								"comment": Comment
							};

							var CommentPayloadPost = {
								target: CommentUrl,
								sslClientProfile: 'omsapi_client_profile',
								method: 'POST',
								contentType: 'application/json',
								data: CommentPayload,
								headers: {
									'osiApiToken': Token
								}
							};
							var info = " TargetURL :" + CommentPayloadPost.target + "; Method :" + CommentPayloadPost.method + "; Data :" + JSON.stringify(CommentPayloadPost.data) + ". ";
							urlopen.open(CommentPayloadPost, function(error, response) {
								if (error) {
									var errorinfo = "url connection error 'CommentsUpdate', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo)
									logger.error(errorinfo);
									ctx.setVariable("retry", 'yes');
									var ErrorTxt = "TaskUpdate_031 :" + errorinfo;
									ctx.setVariable("ErrorTxt", ErrorTxt);
									session.output.write(incomingData)
									//session.reject("urlopen connect error while opening the Comments Payload Post url " + JSON.stringify(error));
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'CommentsUpdate', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												session.output.write(incomingData)
												hm.response.statusCode = '200 OK';
												ILSctx.setVariable('ExitStatus', '0');
												ILSctx.setVariable('ExitDescription', OMSExitDescription);
												ILSctx.setVariable('ExitDestination', OMSUrl);
												logger.debug("response received from Comment Payload Post :" + JSON.stringify(responseData));
											}
										});
									} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
										response.readAsBuffer(function(error, BusinessResponseData) {
											if (error) {
												var errorinfo = "failure in reading response 'CommentsUpdate', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo)
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												//business error change
												var BusinessResponseData = BusinessResponseData;
												var buff = Buffer.from(BusinessResponseData);
												var ResponseString = buff.toString();
												ctx.setVariable("respo", ResponseString)
												if (!(ResponseString === "No updates")) {
													var errorinfo = "Error returned from CommentsPost, details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable('ExitStatus', responseStatusCode);
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error("TaskUpdate_032 : " + errorinfo);
												}
												BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "Comment Post");
											}
										});
									}
									else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "failure reading the error response CommentsPost, details are : " + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "TaskUpdate_033 : error response 'CommentPayloadPost', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												responseData = responseData.toString()
												if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
													var ErrorTxt = "TaskUpdate_033 : error response 'CommentPayloadPost', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
												} else {
													var ErrorTxt = errorinfo
												}
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDestination', CommentUrl);
												ILSctx.setVariable('ExitDescription', errorinfo);
												hm.current.statusCode = responseStatusCode;
												logger.error(errorinfo);
												ctx.setVariable("retry", 'yes');
												ctx.setVariable("ErrorTxt", ErrorTxt);
												session.output.write(incomingData)
												//session.reject("Error returned from Comments Payload Post " + ": with statusCode " + responseStatusCode + " " + responseData);
											}
										});
									}
								}
							});
						}
					}
					if (PropertiesChangedSplit.includes("OpenLoop")) {
						if (incomingData.TaskUpdate.OpenLoop === undefined || incomingData.TaskUpdate.OpenLoop === null || incomingData.TaskUpdate.OpenLoop === " ") {
						} else {
							if (incomingData.TaskUpdate.CrewGUID === null || incomingData.TaskUpdate.CrewGUID === undefined || incomingData.TaskUpdate.CrewGUID === " ") {
							} else {
								var CrewID = incomingData.TaskUpdate.CrewGUID
								var CrewIDGetUrl = OMSUrl + "/api/v1/ServiceType/Electric/Crew/" + CrewID + "?includeFields=externalID,customFieldValuesExt";
								var OpenLoopCrewGetCall = {
									target: CrewIDGetUrl,
									sslClientProfile: 'omsapi_client_profile',
									method: 'GET',
									contentType: 'application/json',
									headers: {
										'osiApiToken': Token
									}
								};
								var info = " TargetURL :" + OpenLoopCrewGetCall.target + "; Method :" + OpenLoopCrewGetCall.method + ". ";
								urlopen.open(OpenLoopCrewGetCall, function(error, response) {
									if (error) {
										var errorinfo = "url connection error 'OpenLoopCrewGetCall', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', '500');
										ILSctx.setVariable('ExitDescription', errorinfo)
										logger.error(errorinfo);
										session.output.write(incomingData)
										//session.reject("urlopen connect error " + JSON.stringify(error));
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode == 200) {
											response.readAsJSON(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'OpenLoopCrewGetCall', details are : " + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													//	session.reject("Failure in getting response " + JSON.stringify(error));
												} else {
													hm.response.statusCode = '200 OK';
													ILSctx.setVariable('ExitStatus', '0');
													ILSctx.setVariable('ExitDescription', OMSExitDescription);
													ILSctx.setVariable('ExitDestination', OMSUrl);
													logger.debug("response received :" + JSON.stringify(responseData));
													ctx.setVariable("CrewGetResponse", responseData)
													session.output.write(incomingData)
												}
											});
										} else {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "failure reading the error response 'OpenLoopCrewGetCall', details are : " + info + "; error info :" + error + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ExitDescription', errorinfo);
													logger.error(errorinfo);
													//session.reject("failure in reading response  ");
												} else {
													var errorinfo = "error response 'OpenLoopCrewGetCall', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable('ExitStatus', '500');
													ILSctx.setVariable('ExitDescription', errorinfo);
													session.output.write(incomingData)
													hm.current.statusCode = responseStatusCode;
													logger.error(errorinfo);
												}
											});
										}
									}
								});
							}

							var LookUpUrl = session.parameters.lookupUrl
							var OpenLoopLookUpPayload = {
								"lookupReq": {
									"type": [
										{
											"name": "outageSubtypes",
											"label": "OPEN-LOOP-MAXIMO"
										}
									]
								}
							};
							var OpenLoopOutageLookUp = {
								target: LookUpUrl,
								method: 'POST',
								contentType: 'application/json',
								data: OpenLoopLookUpPayload
							};
							var info = " TargetURL :" + OpenLoopOutageLookUp.target + "; Method :" + OpenLoopOutageLookUp.method + "; Data :" + JSON.stringify(OpenLoopOutageLookUp.data) + ". ";
							urlopen.open(OpenLoopOutageLookUp, function(error, response) {
								if (error) {
									var errorinfo = "url connection error 'OpenLoopOutageLookUp', details are : " + info + "; error info :" + error
									ILSctx.setVariable('ExitStatus', '500');
									ILSctx.setVariable('ExitDescription', errorinfo)
									logger.error(errorinfo);
									session.reject("TaskUpdate_034 : " + errorinfo);
								} else {
									var responseStatusCode = response.statusCode;
									if (responseStatusCode == 200) {
										response.readAsJSON(function(error, responseData) {
											if (error) {
												var errorinfo = "error reading response 'OpenLoopOutageLookUp', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ExitDescription', "error reading response 'OpenLoopOutageLookUp', details are :" + info + "; error info :" + error);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												hm.response.statusCode = responseStatusCode;
												logger.debug("Response received from OpenLoop OutageSybType Post" + responseData);
												//	ctx.setVariable("ResponseData2", responseData);
												if (responseData.lookupRep.type[0].result == 1) {
													var invalidresp = "Invalid Lookup Request 'OpenLoopOutageLookUp', details are :" + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable('ExitStatus', '1');
													ILSctx.setVariable('ExitDescription', invalidresp);
													logger.error(invalidresp)
													session.reject("TaskUpdate_035 : " + invalidresp)
												} else {
													var OutageSubTypeID = responseData.lookupRep.type[0].id;
													var OutageOpenLoopPayload = {
														"outageSubtypeID": OutageSubTypeID
													}
													var OutageUrl = OMSUrl + '/api/v1/ServiceType/Electric/Job/' + JobIDGUID
													var OpenLoopPayloadPost = {
														target: OutageUrl,
														sslClientProfile: 'omsapi_client_profile',
														method: 'PATCH',
														contentType: 'application/json',
														data: OutageOpenLoopPayload,
														headers: {
															'osiApiToken': Token
														}
													};
													var info = " TargetURL :" + OpenLoopPayloadPost.target + "; Method :" + OpenLoopPayloadPost.method + "; Data :" + JSON.stringify(OpenLoopPayloadPost.data) + ". ";
													urlopen.open(OpenLoopPayloadPost, function(error, response) {
														if (error) {
															var errorinfo = "url connection error 'OpenLoopPayloadPost', details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', '500');
															ILSctx.setVariable('ExitDescription', errorinfo)
															ILSctx.setVariable('ExitDestination', OutageUrl);
															logger.error(errorinfo);
															ctx.setVariable("retry", 'yes');
															var ErrorTxt = "TaskUpdate_036 : " + errorinfo;
															ctx.setVariable("ErrorTxt", ErrorTxt);
															session.output.write(incomingData)
															//session.reject("urlopen connect error while opening the Comments Payload Post url " + JSON.stringify(error));
														} else {
															var responseStatusCode = response.statusCode;
															if (responseStatusCode == 200) {
																response.readAsJSON(function(error, responseData) {
																	if (error) {
																		var errorinfo = "error reading response 'OpenLoopPayloadPost', details are : " + info + "; error info :" + error
																		ILSctx.setVariable('ExitStatus', '500');
																		ILSctx.setVariable('ExitDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		session.output.write(incomingData)
																		hm.response.statusCode = '200 OK';
																		ILSctx.setVariable('ExitStatus', '0');
																		ILSctx.setVariable('ExitDescription', OMSExitDescription);
																		ILSctx.setVariable('ExitDestination', OMSUrl);
																		logger.debug("response received from OutageSubType Patch :" + JSON.stringify(responseData));
																	}
																});
															} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
																response.readAsBuffer(function(error, BusinessResponseData) {
																	if (error) {
																		var errorinfo = "failure in reading response 'OpenLoopPayloadPost', details are : " + info + "; error info :" + error
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ExitDescription', errorinfo)
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		//business error change
																		var BusinessResponseData = BusinessResponseData;
																		var buff = Buffer.from(BusinessResponseData);
																		var ResponseString = buff.toString();
																		ctx.setVariable("respo", ResponseString)
																		if (!(ResponseString === "No updates")) {
																			var errorinfo = "Error returned from OutageSubType Patch , details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
																			ILSctx.setVariable('ExitStatus', responseStatusCode);
																			ILSctx.setVariable('ExitDescription', errorinfo);
																			logger.error("TaskUpdate_037 : " + errorinfo);
																		}
																		BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "OpenLoop OutageSubType");
																	}
																});
															}
															else {
																response.readAsBuffer(function(error, responseData) {
																	if (error) {
																		var errorinfo = "failure reading the error response 'OpenLoopPayloadPost', details are : " + info + "; error info :" + error
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ExitDescription', errorinfo);
																		logger.error(errorinfo);
																		session.reject(errorinfo);
																	} else {
																		var errorinfo = "TaskUpdate_038 : error response 'OpenLoopPayloadPost', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																		responseData = responseData.toString()
																		if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
																			var ErrorTxt = "TaskUpdate_038 : error response 'OpenLoopPayloadPost', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
																		} else {
																			var ErrorTxt = errorinfo
																		}
																		ILSctx.setVariable('ExitStatus', responseStatusCode);
																		ILSctx.setVariable('ExitDescription', errorinfo);
																		ILSctx.setVariable('ExitDestination', OutageUrl);
																		hm.current.statusCode = responseStatusCode;
																		logger.error(errorinfo);
																		ctx.setVariable("retry", 'yes');
																		ctx.setVariable("ErrorTxt", ErrorTxt);
																		session.output.write(incomingData)
																		//session.reject("Error returned from Comments Payload Post " + ": with statusCode " + responseStatusCode + " " + responseData);
																	}
																});
															}
														}
													});
												}
											}
										});
									} else {
										response.readAsBuffer(function(error, responseData) {
											if (error) {
												var errorinfo = "failure reading the error response 'OpenLoopOutageLookUp', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject(errorinfo);
											} else {
												var errorinfo = "error response 'OpenLoopOutageLookUp', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												hm.current.statusCode = responseStatusCode;
												logger.error(errorinfo);
												session.reject(errorinfo);
											}
										});
									}
								}
							});
						}
					}
				}
			}
		}
	});
}