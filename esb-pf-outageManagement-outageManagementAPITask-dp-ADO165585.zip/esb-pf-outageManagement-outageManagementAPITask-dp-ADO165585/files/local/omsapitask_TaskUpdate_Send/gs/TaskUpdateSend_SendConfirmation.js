var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var SeqConfirmPayload = ctx.getVariable("SeqConfirmPayload")
var SeqConfirmURL = session.parameters.SeqConfirmURL
var SeqConfirmRequest = require('./TaskUpdateSend_ConfirmAceReq.js');
var checkRetry = ctx.getVariable('retry')
var LastRetryCheck = ctx.getVariable('checkLastRetry')

var sendConfirmationError = ctx.getVariable('sendConfirmationError')
if (sendConfirmationError === 'yes') {
	SeqConfirmRequest(SeqConfirmURL, SeqConfirmPayload)
} else {
	if (checkRetry === 'yes') {
		if (LastRetryCheck === 'yes') {
			SeqConfirmRequest(SeqConfirmURL, SeqConfirmPayload)
		}
	} else {
		SeqConfirmRequest(SeqConfirmURL, SeqConfirmPayload)
	}
}






