//js is used to push message to standalone queue
var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ms = require('multistep');
var SendIlsExitDescription = session.parameters.SendIlsExitDescription
var ETRQueueError = ctx.getVariable("ETRQueueError")
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
ctx.setVariable("FinalFSEDescription", SendIlsExitDescription)

var checkretry = ctx.getVariable("retry");
if (checkretry !== 'yes') {
	session.input.readAsJSON(function(readAsJSONError, incomingData) {
		if (readAsJSONError) {
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data')
			logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
			session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
		} else {
			session.output.write(incomingData);
			var StandaloneMQurl = session.parameters.MQUrl;
			var ETRQueuePayload = ctx.getVariable("ETRQueuePayload")
			if (ETRQueuePayload === null || ETRQueuePayload === undefined || ETRQueuePayload === "") {
				if (ETRQueueError === "yes") {
					QueueCall(StandaloneMQurl, incomingData)
					session.output.write(incomingData);
				}
			} else {
				QueueCall(StandaloneMQurl, ETRQueuePayload)
				session.output.write(incomingData);
			}
		}
	})
}
function QueueCall(StandaloneMQurl, PublishedETRChangeCountPayload) {
	var pushingToQueue = {
		target: StandaloneMQurl,
		data: PublishedETRChangeCountPayload
	};
	var info = " TargetURL :" + pushingToQueue.target + "; Data :" + pushingToQueue.data + ". ";

	try {
		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error 'OMSAPITASK.PUBLISH.ETR.COUNT Queue', details are : " + info + "; error info :" + error
				var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
				var mqconnection = 'Forbidden';
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDestination', StandaloneMQurl);
				ILSctx.setVariable('ExitDescription', errorinfo)
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "TaskUpdate_021 : " + errorinfo;
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("ETRQueueError", "yes");
				session.output.write(PublishedETRChangeCountPayload);
			} else {
				var mqrc = response.statusCode;

				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "Error reading the response , details are : " + info + "; error info :" + readError
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', errorinfo)
							hm.response.statusCode = 500
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
							ILSctx.setVariable('ExitStatus', '0');
							ILSctx.setVariable('ExitDescription', SendIlsExitDescription)
							ILSctx.setVariable('ExitDestination', " ");
							logger.debug("MQResponsecode " + mqrc);
							var inputData = ctx.getVariable('incomingData')
							ctx.setVariable("ETRQueueError", "no");
							ctx.setVariable("retry", 'no');
							session.output.write(inputData);
						}
					});
				} else {
					var errorinfo = "Error received from the response of OMSAPITASK.PUBLISH.ETR.COUNT Queue, details are : " + info + "; response info :" + response + "; ResponseStatusCode :" + response.statusCode
					var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDestination', StandaloneMQurl);
					ILSctx.setVariable('ExitDescription', errorinfo)
					logger.error(errorinfo);
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = "TaskUpdate_022 : " + errorinfo;
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("ETRQueueError", "yes");
					session.output.write(PublishedETRChangeCountPayload);
				}
			}
		});
	} catch (err) {
		var errorinfo = "url connection error 'OMSAPITASK.PUBLISH.ETR.COUNT Queue', details are : " + info + "; error info :" + err
		var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
		var mqconnection = 'Forbidden';
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDestination', StandaloneMQurl);
		ILSctx.setVariable('ExitDescription', errorinfo)
		ctx.setVariable("mqconnection", mqconnection);
		logger.error(errorinfo);
		ctx.setVariable("retry", 'yes');
		var ErrorTxt = "TaskUpdate_021 : " + errorinfo;
		ctx.setVariable("ErrorTxt", ErrorTxt);
		ctx.setVariable("ETRQueueError", "yes");
		session.output.write(PublishedETRChangeCountPayload);
	}
}
