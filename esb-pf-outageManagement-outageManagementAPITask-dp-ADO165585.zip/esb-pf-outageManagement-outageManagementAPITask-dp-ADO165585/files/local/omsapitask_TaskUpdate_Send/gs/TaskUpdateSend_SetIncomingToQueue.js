//js is used to push message to standalone queue
var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ms = require('multistep');
var ImageUploadExitDescription = session.parameters.ImageUploadExitDescription
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var checkretry = ctx.getVariable("retry");
var ETRQueueError = ctx.getVariable("ETRQueueError");
if (checkretry !== 'yes') {
	session.input.readAsJSON(function(readAsJSONError, incomingData) {
		if (readAsJSONError) {
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data')
			logger.error("Error in reading incoming data" + JSON.stringify(error));
			session.reject("error in reading incoming data" + JSON.stringify(error));
		} else {
			session.output.write(incomingData)
			if (ETRQueueError === "yes") {
				session.output.write(incomingData)
			} else {
				if (incomingData.TaskUpdate.Attachments === null ||
					incomingData.TaskUpdate.Attachments === undefined ||
					incomingData.TaskUpdate.Attachments === '' ||
					incomingData.TaskUpdate.Attachments.length === 0) {

				} else {
					//var PutToQueueError = ctx.getVariable("PutToQueueError")
					var StandaloneMQurl = session.parameters.MQUrlQ3;
					ILSctx.setVariable('ExitDestination', StandaloneMQurl);
					ILSctx.setVariable('ExitDescription', ImageUploadExitDescription);
					QueueCall(incomingData, StandaloneMQurl)
					session.output.write(incomingData)
				}
			}
		}
	});
}


function QueueCall(payload, StandaloneMQurl) {
	var pushingToQueue = {
		target: StandaloneMQurl,
		data: payload
	};
	var info = " TargetURL :" + pushingToQueue.target + "; Data :" + JSON.stringify(pushingToQueue.data) + ". ";

	try {

		urlopen.open(pushingToQueue, function(error, response) {
			var hm = require('header-metadata');
			if (error) {
				var errorinfo = "url connection error 'OMSAPITASK.UPLOAD.ATTACHMENT Queue', details are : " + info + "; error info :" + error
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDestination', StandaloneMQurl);
				ILSctx.setVariable('ExitDescription', ImageUploadExitDescription)
				var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
				var AlreadyLogged = ctx.getVariable("PutToQueueError")
				if (AlreadyLogged === "yes") {
				} else {
					ctx.setVariable("SendConfirmation", "yes")
					ms.callRule('omsapitask_TaskUpdate_Send_Processing_Policy_ILSExit_Rule', null, null, function(error) {
						if (error) {
						}
					});
				}
				var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				logger.error(errorinfo);
				ctx.setVariable("retry", 'yes');
				var ErrorTxt = "TaskUpdate_053 : " + errorinfo;
				ctx.setVariable("ErrorTxt", ErrorTxt);
				ctx.setVariable("PutToQueueError", "yes")
				session.output.write(payload)
			} else {
				var mqrc = response.statusCode;
				if (mqrc == 0) {
					var replyMQMD = response.get({
						type: 'mq'
					}, 'MQMD');
					var replyMQRFH2 = response.get({
						type: 'mq'
					}, 'MQRFH2');
					response.readAsBuffer(function(readError, responseData) {
						if (readError) {
							var errorinfo = "error reading response 'OMSAPITASK.UPLOAD.ATTACHMENT Queue', details are : " + info + "; error info :" + readError
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDescription', ImageUploadExitDescription)
							hm.response.statusCode = 500
							logger.error(errorinfo);
							session.reject(errorinfo);
							var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
							var AlreadyLogged = ctx.getVariable("PutToQueueError")
							if (AlreadyLogged === "yes") {
							} else {
								ctx.setVariable("SendConfirmation", "yes")
								ms.callRule('omsapitask_TaskUpdate_Send_Processing_Policy_ILSExit_Rule', null, null, function(error) {
									if (error) {
										throw error;
									}
								});
							}
						} else {
							ILSctx.setVariable('ExitStatus', '0');
							ILSctx.setVariable('ExitDescription', ImageUploadExitDescription)
							ILSctx.setVariable('ExitDestination', StandaloneMQurl);
							var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
							var AlreadyLogged = ctx.getVariable("PutToQueueError")
							ctx.setVariable("SendConfirmation", "yes")
							ms.callRule('omsapitask_TaskUpdate_Send_Processing_Policy_ILSExit_Rule', null, null, function(error) {
								if (error) {
									throw error;
								}
							});
							logger.debug("MQResponsecode " + mqrc);
							session.output.write(payload)
						}
					});
				} else {
					var errorinfo = "error response 'OMSAPITASK.UPLOAD.ATTACHMENT Queue', details are : " + info + "; response info :" + response + "; ResponseStatusCode :" + response.statusCode
					ILSctx.setVariable('ExitStatus', '500');
					ILSctx.setVariable('ExitDestination', StandaloneMQurl);
					ILSctx.setVariable('ExitDescription', ImageUploadExitDescription)
					var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
					var AlreadyLogged = ctx.getVariable("PutToQueueError")
					if (AlreadyLogged === "yes") {
					} else {
						ms.callRule('omsapitask_TaskUpdate_Send_Processing_Policy_ILSExit_Rule', null, null, function(error) {
							if (error) {
								throw error;
							}
						});
					}
					var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
					var mqconnection = 'Forbidden';
					ctx.setVariable("mqconnection", mqconnection);
					logger.error(errorinfo);
					ctx.setVariable("retry", 'yes');
					var ErrorTxt = "TaskUpdate_054 : " + errorinfo;
					ctx.setVariable("ErrorTxt", ErrorTxt);
					ctx.setVariable("PutToQueueError", "Yes")
					session.output.write(payload)
				}
			}
		});

	} catch (err) {
		var errorinfo = "url connection error 'OMSAPITASK.UPLOAD.ATTACHMENT Queue', details are : " + info + "; error info :" + err
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ExitDestination', StandaloneMQurl);
		ILSctx.setVariable('ExitDescription', ImageUploadExitDescription)
		var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
		var AlreadyLogged = ctx.getVariable("PutToQueueError")
		if (AlreadyLogged === "yes") {
		} else {
			ctx.setVariable("SendConfirmation", "yes")
			ms.callRule('omsapitask_TaskUpdate_Send_Processing_Policy_ILSExit_Rule', null, null, function(error) {
				if (error) {
				}
			});
		}
		var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
		var mqconnection = 'Forbidden';
		ctx.setVariable("mqconnection", mqconnection);
		logger.error(errorinfo);
		ctx.setVariable("retry", 'yes');
		var ErrorTxt = "TaskUpdate_053 : " + errorinfo;
		ctx.setVariable("ErrorTxt", ErrorTxt);
		ctx.setVariable("PutToQueueError", "yes")
		session.output.write(payload)
	}
}