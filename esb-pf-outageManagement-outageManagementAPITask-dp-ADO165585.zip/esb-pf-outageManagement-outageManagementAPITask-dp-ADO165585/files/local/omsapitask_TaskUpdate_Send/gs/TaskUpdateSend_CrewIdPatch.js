var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var BusinessErrorCall = require('./BusinessErrorUrlOpen.js');
var ETRQueueError = ctx.getVariable("ETRQueueError")
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var flag = ctx.getVariable("flag")
session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		session.output.write(incomingData)
		if (flag !== 'yes') {
			var OMSUrl = session.parameters.OMSUrl;
			var OMSExitDescription = session.parameters.OMSExitDescription;
			if ((OMSUrl == undefined) || (OMSUrl == ' ') || (OMSUrl == null)) {
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', 'Error in connection with OMSUrl of CrewID Patch Call');
				logger.error("Error in connection with OMSUrl of CrewID Patch");
				session.reject("Error in connection with OMSUrl of CrewID Patch");
			} else {
				session.output.write(incomingData)
				var lookupUrl = session.parameters.lookupUrl;
				ctx.setVariable("IncomingDa", incomingData);
				var CrewAssignmentIDGUID = incomingData.TaskUpdate.CrewAssignmentIDGUID;
				var Token = session.parameters.OMSToken;

				var DispositionStatus = ctx.getVariable("DispositionStatus")
				var ETA = incomingData.TaskUpdate.ETA;
				var CompletionRemarks = incomingData.TaskUpdate.CompletionRemarks;
				var NeedOperBy = incomingData.TaskUpdate.NeedOperBy;
				var CrewIdParameters = ["ETA", "Dispositions", "CompletionRemarks", "NeedOperBy"]

				var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
				var PropertiesChangedSplit = PropertiesChanged.split(',');
				ctx.setVariable("Properties", PropertiesChangedSplit)

				var UpdatesOfCrewID = []
				for (var i = 0; i < PropertiesChangedSplit.length; i++) {
					for (var j = 0; j < CrewIdParameters.length; j++) {
						if (PropertiesChangedSplit[i] == CrewIdParameters[j]) {
							UpdatesOfCrewID.push(String(PropertiesChangedSplit[i]))
						}
					}
				}
				ctx.setVariable("UpdatesOfCrewID", UpdatesOfCrewID)
				var DispositionsExists = UpdatesOfCrewID.includes("Dispositions");
				var ETAExists = UpdatesOfCrewID.includes("ETA");
				var CompletionRemarksExists = UpdatesOfCrewID.includes("CompletionRemarks");
				var NeedOperByExists = UpdatesOfCrewID.includes("NeedOperBy");

				var ETAPayload = {
					"eta": ETA
				}
				var DispositionsPayload = {
					"Disposition": DispositionStatus
				}
				var CompletionRemarksPayload = {
					"CompletionRemarks": CompletionRemarks
				}
				var NeedOperByPayload = {
					"operator_by": NeedOperBy
				}

				var CrewCustomFieldsExists = [DispositionsExists, CompletionRemarksExists, NeedOperByExists]
				var CrewCustomFieldspayloads = [DispositionsPayload, CompletionRemarksPayload, NeedOperByPayload]
				var CrewCustomPayload = {}

				for (var i = 0; i < CrewCustomFieldsExists.length; i++) {
					if (CrewCustomFieldsExists[i]) {
						CrewCustomPayload = { ...CrewCustomPayload, ...CrewCustomFieldspayloads[i] }
					}
				}
				var CrewCustomFieldsPayload = {
					"customFieldValues": CrewCustomPayload
				}

				var CrewIDsExist = [ETAExists]
				var CrewIDAllPayloads1 = [ETAPayload]

				if (PropertiesChangedSplit.includes("Dispositions") ||
					PropertiesChangedSplit.includes("CompletionRemarks") ||
					PropertiesChangedSplit.includes("NeedOperBy")) {
					CrewIDsExist.push(CrewCustomFieldsExists)
					CrewIDAllPayloads1.push(CrewCustomFieldsPayload)
				}
				var CrewIDAllPayloadsPatch = {}

				for (var i = 0; i < CrewIDsExist.length; i++) {
					if (CrewIDsExist[i]) {
						CrewIDAllPayloadsPatch = { ...CrewIDAllPayloadsPatch, ...CrewIDAllPayloads1[i] }
					}
				}

				var CrewIDExistsHasElements = (
					PropertiesChangedSplit.includes("ETA") ||
					PropertiesChangedSplit.includes("Dispositions") ||
					PropertiesChangedSplit.includes("NeedOperBy"))
				ctx.setVariable("CrewIDExistsHasElements", CrewIDExistsHasElements)

				if (PropertiesChangedSplit.includes("Status") &&
					(PropertiesChangedSplit.includes("ETA") ||
						PropertiesChangedSplit.includes("Dispositions") ||
						PropertiesChangedSplit.includes("CompletionRemarks") ||
						PropertiesChangedSplit.includes("NeedOperBy"))) {

					var CrewAssignmentIDGUIDUrl = OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentIDGUID;
					StatusPost(CrewAssignmentIDGUIDUrl)
				} else {
					if (CrewIDExistsHasElements === true) {
						var CrewIDPatchUrl = OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentIDGUID;
						CrewPatchCall(CrewIDPatchUrl, CrewIDAllPayloadsPatch)
					}

				}

				function CrewPatchCall(CrewIDPatchUrl, CrewIDAllPayloadsPatch) {
					var Token = session.parameters.OMSToken;
					var CrewIDPatch = {
						target: CrewIDPatchUrl,
						sslClientProfile: 'omsapi_client_profile',
						method: 'PATCH',
						contentType: 'application/json',
						data: CrewIDAllPayloadsPatch,
						headers: {
							'osiApiToken': Token
						}
					};
					var info = " TargetURL :" + CrewIDPatch.target + "; Method :" + CrewIDPatch.method + "; Data :" + JSON.stringify(CrewIDPatch.data) + ". ";
					urlopen.open(CrewIDPatch, function(error, response) {
						if (error) {
							var errorinfo = "url connection error 'CrewIDPatch', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDestination', CrewIDPatchUrl);
							ILSctx.setVariable('ExitDescription', errorinfo);
							logger.error(errorinfo);
							ctx.setVariable("retry", 'yes');
							var ErrorTxt = "TaskUpdate_006 : " + errorinfo;
							ctx.setVariable("ErrorTxt", ErrorTxt);
							session.output.write(incomingData)
							//session.reject("urlopen connect error while opening the Crew ID Payload Patch url " + JSON.stringify(error));
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'CrewIDPatch', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', '500');
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										hm.response.statusCode = '200 OK';
										ILSctx.setVariable('ExitStatus', '0');
										ILSctx.setVariable('ExitDescription', OMSExitDescription);
										ILSctx.setVariable('ExitDestination', OMSUrl);
										logger.debug("response received from Crew ID Payload Patch :" + JSON.stringify(responseData))
										session.output.write(incomingData)
									}
								});
							} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
								response.readAsBuffer(function(error, BusinessResponseData) {
									if (error) {
										var errorinfo = "Failure in reading response 'CrewIDPatch', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var BusinessResponseData = BusinessResponseData;
										var buff = Buffer.from(BusinessResponseData);
										var ResponseString = buff.toString();
										ctx.setVariable("respo", ResponseString)

										if (!(ResponseString === "No updates")) {
											var errorinfo = "Error returned from 'CrewIDPatch', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error("TaskUpdate_007 : " + errorinfo);
										}
										BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "CrewUpdates BusinessError");
									}
								});
							}
							else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure reading the error response 'CrewIDPatch', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var errorinfo = "TaskUpdate_008 : error response 'CrewIDPatch', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										responseData = responseData.toString()
										if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
											var ErrorTxt = "TaskUpdate_008 : error response 'CrewIDPatch', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
										} else {
											var ErrorTxt = errorinfo
										}
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDestination', CrewIDPatchUrl);
										ILSctx.setVariable('ExitDescription', errorinfo);
										hm.current.statusCode = responseStatusCode;
										logger.error(errorinfo);
										ctx.setVariable("retry", 'yes');
										ctx.setVariable("ErrorTxt", ErrorTxt);
										session.output.write(incomingData)
									}
								});
							}
						}
					});
				}

				function StatusPost(CrewAssignmentIDGUIDUrl) {
					var StatusLabel = incomingData.TaskUpdate.CrewAssignmentStatus;
					var GetWorkTypeID = {
						target: CrewAssignmentIDGUIDUrl,
						sslClientProfile: 'omsapi_client_profile',
						method: 'GET',
						contentType: 'application/json',
						headers: {
							'osiApiToken': Token
						}
					};
					var info = " TargetURL :" + GetWorkTypeID.target + "; Method :" + GetWorkTypeID.method + ". ";
					urlopen.open(GetWorkTypeID, function(error, response) {
						if (error) {
							var errorinfo = "url connection error 'GetWorkTypeID', details are : " + info + "; error info :" + error
							ILSctx.setVariable('ExitStatus', '500');
							ILSctx.setVariable('ExitDestination', CrewAssignmentIDGUIDUrl);
							ILSctx.setVariable('ExitDescription', errorinfo);
							ctx.setVariable("retry", 'yes');
							var ErrorTxt = "TaskUpdate_009 : " + errorinfo;
							ctx.setVariable("ErrorTxt", ErrorTxt);
							session.output.write(incomingData)
							logger.error(errorinfo);
							//session.reject(" urlopen connect error for Status Get Call " + JSON.stringify(error));
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "error reading response 'GetWorkTypeID', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', '500');
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										hm.response.statusCode = '200 OK';
										ILSctx.setVariable('ExitStatus', '0');
										ILSctx.setVariable('ExitDescription', OMSExitDescription);
										ILSctx.setVariable('ExitDestination', OMSUrl);
										logger.debug("response received :" + responseData);

										var workTypeID = responseData.workTypeID;
										ctx.setVariable("workTypeId", workTypeID);
										var status = responseData.status;
										ctx.setVariable("status", status);

										var StatusLookUpPayload = {
											"lookupReq": {
												"type": [
													{
														"name": "workType.workflows",
														"id": workTypeID,
														"label": StatusLabel
													}
												]
											}
										};

										var StatusLookUpOpenUrlPost = {
											target: lookupUrl,
											method: 'POST',
											contentType: 'application/json',
											data: StatusLookUpPayload
										};
										var info = " TargetURL :" + StatusLookUpOpenUrlPost.target + "; Method :" + StatusLookUpOpenUrlPost.method + "; Data :" + JSON.stringify(StatusLookUpOpenUrlPost.data) + ". ";
										urlopen.open(StatusLookUpOpenUrlPost, function(error, response) {
											if (error) {
												var errorinfo = "url connection error 'StatusLookUp', details are : " + info + "; error info :" + error
												ILSctx.setVariable('ExitStatus', '500');
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error(errorinfo);
												session.reject("TaskUpdate_010 : " + errorinfo);
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsJSON(function(error, responseData) {
														var info = " TargetURL :" + StatusLookUpOpenUrlPost.target + "; Method :" + StatusLookUpOpenUrlPost.method + "; Data :" + JSON.stringify(StatusLookUpOpenUrlPost.data) + ". ";
														if (error) {
															var errorinfo = "error reading response 'StatusLookUp', details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', '500');
															ILSctx.setVariable('ExitDescription', errorinfo);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															hm.response.statusCode = '200 OK';
															ILSctx.setVariable('ExitStatus', '0');
															ILSctx.setVariable('ExitDescription', OMSExitDescription);
															ILSctx.setVariable('ExitDestination', lookupUrl);
															logger.debug("response received from LookUp of Status :" + responseData);
															if (responseData.lookupRep.type[0].result == 1) {
																var invalidresp = "Invalid Lookup Request 'StatusLookUp', details are :" + info + "; response info :" + JSON.stringify(responseData) + "; ResponseStatusCode :" + responseStatusCode
																ILSctx.setVariable('ExitStatus', '1');
																ILSctx.setVariable('ExitDescription', invalidresp);
																logger.error(invalidresp)
																session.reject("TaskUpdate_011 : " + invalidresp)
															} else {
																var LookUpStatus = responseData.lookupRep.type[0].status;
																ctx.setVariable("StatusIdentifier", LookUpStatus)
																var CrewAssignmentIDGUID = incomingData.TaskUpdate.CrewAssignmentIDGUID;
																var Token = session.parameters.OMSToken;
																//var status = incomingData.TaskUpdate.CrewAssignmentStatus;

																if (status != LookUpStatus) {
																	var StatusPatchUrl = OMSUrl + '/api/v1/ServiceType/Electric/CrewAssignment/' + CrewAssignmentIDGUID + '/WorkFlow';

																	var StatusPatchPayload = {
																		"status": LookUpStatus
																	};

																	var CrewPayload = {}

																	if ((PropertiesChangedSplit.includes("ETA") ||
																		PropertiesChangedSplit.includes("Dispositions") ||
																		PropertiesChangedSplit.includes("CompletionRemarks"))) {

																		CrewPayload = { ...StatusPatchPayload, ...CrewIDAllPayloadsPatch }

																	} else {
																		var CrewPayload = StatusPatchPayload
																	}

																	var StatusPatchPayloadPatch = {
																		target: StatusPatchUrl,
																		sslClientProfile: 'omsapi_client_profile',
																		method: 'POST',
																		contentType: 'application/json',
																		data: CrewPayload,
																		headers: {
																			'osiApiToken': Token
																		}
																	};
																	var info = " TargetURL :" + StatusPatchPayloadPatch.target + "; Method :" + StatusPatchPayloadPatch.method + "; Data :" + JSON.stringify(StatusPatchPayloadPatch.data) + ". ";
																	urlopen.open(StatusPatchPayloadPatch, function(error, response) {
																		if (error) {
																			var errorinfo = "url connection error 'StatusPatch', details are : " + info + "; error info :" + error
																			ILSctx.setVariable('ExitStatus', '500');
																			ILSctx.setVariable('ExitDestination', StatusPatchUrl);
																			ILSctx.setVariable('ExitDescription', errorinfo);
																			ctx.setVariable("retry", 'yes');
																			var ErrorTxt = "TaskUpdate_012 : " + errorinfo;
																			ctx.setVariable("ErrorTxt", ErrorTxt);
																			session.output.write(incomingData)
																			logger.error(errorinfo);
																			//session.reject("urlopen connect error while opening the Status Payload Patch url " + JSON.stringify(error))
																		} else {
																			var responseStatusCode = response.statusCode;
																			if (responseStatusCode == 200) {
																				response.readAsJSON(function(error, responseData) {
																					if (error) {
																						var errorinfo = "error reading response 'StatusUpdate', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', '500');
																						ILSctx.setVariable('ExitDescription', errorinfo);
																						logger.error(errorinfo);
																						Session.reject(errorinfo);

																					} else {
																						hm.response.statusCode = '200 OK';
																						ILSctx.setVariable('ExitStatus', '0');
																						ILSctx.setVariable('ExitDescription', OMSExitDescription);
																						ILSctx.setVariable('ExitDestination', OMSUrl);
																						logger.debug("response received from Status Payload Patch :" + responseData);
																						session.output.write(incomingData)
																					}
																				});
																			} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
																				response.readAsBuffer(function(error, BusinessResponseData) {
																					if (error) {
																						var errorinfo = "failure in reading response from Status Payload Patch, details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ExitDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var BusinessResponseData = BusinessResponseData;
																						var buff = Buffer.from(BusinessResponseData);
																						var ResponseString = buff.toString();
																						ctx.setVariable("respo", ResponseString)
																						if (!(ResponseString === "No updates")) {
																							var errorinfo = "Error returned from StatusPost with CrewID Payload Patch, details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
																							ILSctx.setVariable('ExitStatus', responseStatusCode);
																							ILSctx.setVariable('ExitDescription', errorinfo);
																							logger.error("TaskUpdate_013 : " + errorinfo);
																						}
																						BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "Status and Crew Updates BusinessError");
																					}
																				});
																			}
																			else {
																				response.readAsBuffer(function(error, responseData) {
																					if (error) {
																						var errorinfo = "TaskUpdate_014 : error reading response 'StatusPayloadPatch', details are : " + info + "; error info :" + error
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ExitDescription', errorinfo);
																						logger.error(errorinfo);
																						session.reject(errorinfo);
																					} else {
																						var errorinfo = "TaskUpdate_014 : error response 'StatusPayloadPatch', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																						responseData = responseData.toString()
																						if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
																							var ErrorTxt = "TaskUpdate_014 : error response 'StatusPayloadPatch', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
																						} else {
																							var ErrorTxt = errorinfo
																						}
																						ILSctx.setVariable('ExitStatus', responseStatusCode);
																						ILSctx.setVariable('ExitDescription', errorinfo);
																						ILSctx.setVariable('ExitDestination', StatusPatchUrl);
																						hm.current.statusCode = responseStatusCode;
																						ctx.setVariable("retry", 'yes');
																						ctx.setVariable("ErrorTxt", ErrorTxt);
																						session.output.write(incomingData)
																						logger.error(errorinfo);
																						//session.reject("Error returned from StatusPatchPayloadPatch call " + ": with statusCode " + responseStatusCode + " " + responseData);
																					}
																				});
																			}
																		}
																	});
																} else if (status == LookUpStatus) {
																	if (CrewIDExistsHasElements === true) {
																		var CrewIDPatchUrl = OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentIDGUID;
																		CrewPatchCall(CrewIDPatchUrl, CrewIDAllPayloadsPatch)
																	}
																}
															}
														}
													});
												} else {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															var errorinfo = "error reading response 'StatusLookUp', details are : " + info + "; error info :" + error
															ILSctx.setVariable('ExitStatus', responseStatusCode);
															ILSctx.setVariable('ExitDescription', errorinfo);
															logger.error(errorinfo);
															session.reject(errorinfo);
														} else {
															var errorinfo = "error response 'StatusLookUp', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
															ILSctx.setVariable('ExitStatus', responseStatusCode);
															ILSctx.setVariable('ExitDescription', errorinfo);
															ILSctx.setVariable('ExitDestination', lookupUrl);
															hm.current.statusCode = responseStatusCode;
															logger.error(errorinfo);
															session.reject(errorinfo);
														}
													});
												}
											}
										});
									}
								});
							}
							else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
								response.readAsBuffer(function(error, BusinessResponseData) {
									if (error) {
										var errorinfo = "error reading response 'GetCall of Status', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var BusinessResponseData = BusinessResponseData;
										var buff = Buffer.from(BusinessResponseData);
										var ResponseString = buff.toString();
										ctx.setVariable("respo", ResponseString)
										if (!(ResponseString === "No updates")) {
											var errorinfo = "Error returned from StatusPost get worktypeID, details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error("TaskUpdate_015 : " + errorinfo);
										}
										BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "StatusPost get worktypeID BusinessError");
									}
								});
							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										var errorinfo = "failure reading the error response 'GetWorkTypeID', details are : " + info + "; error info :" + error
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDescription', errorinfo);
										logger.error(errorinfo);
										session.reject(errorinfo);
									} else {
										var errorinfo = "TaskUpdate_016 : error response 'GetWorkTypeID', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
										responseData = responseData.toString()
										if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
											var ErrorTxt = "TaskUpdate_016 : error response 'GetWorkTypeID', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
										} else {
											var ErrorTxt = errorinfo
										}
										ILSctx.setVariable('ExitStatus', responseStatusCode);
										ILSctx.setVariable('ExitDestination', CrewAssignmentIDGUIDUrl);
										ILSctx.setVariable('ExitDescription', errorinfo);
										hm.current.statusCode = responseStatusCode;
										ctx.setVariable("retry", 'yes');
										ctx.setVariable("ErrorTxt", ErrorTxt);
										session.output.write(incomingData)
										logger.error(errorinfo);
										//session.reject("Error returned  from Status Get Call " + ": with statusCode " + responseStatusCode + " " + responseData);
									}
								});
							}
						}
					});
				}
			}
		}
	}
});
