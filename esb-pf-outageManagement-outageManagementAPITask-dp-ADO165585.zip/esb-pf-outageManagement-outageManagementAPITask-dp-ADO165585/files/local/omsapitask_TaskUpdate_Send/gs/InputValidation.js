var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});

session.input.readAsBuffer(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		var SeqIncoming = ctx.getVariable("SeqIncoming");
		if(SeqIncoming.payload === undefined || SeqIncoming.payload === null || SeqIncoming.payload === ""){
			session.output.write(SeqIncoming)
		} else{
			session.output.write(incomingdata)
		}
	}
})
