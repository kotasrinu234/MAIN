var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var FromRetry = ctx.getVariable("FromRetry")
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var Entrydescription = session.parameters.SendIlsEntrydescription;
		var Exitdescription = session.parameters.OMSExitDescription;
		var urlIn = sm.getVar('var://service/URL-in');
		ILSctx.setVariable("sourceUrl", urlIn);
		var ILSPayload = {};
		var ContextPayload = incomingdata
		ctx.setVariable("IncomingData", incomingdata)
		if (FromRetry === "yes") {
			var Payload = ILSctx.getVariable("RetryILSCtxPayload")
			ContextPayload = JSON.parse(Payload)
		}

		if (ContextPayload.messageId === undefined || ContextPayload.messageId === null || ContextPayload.messageId === "") {
			ILSctx.setVariable('correlationID', " ")
		} else {
			ILSctx.setVariable('correlationID', ContextPayload.messageId)
			ILSPayload.messageId = ContextPayload.messageId
		}
		if (ContextPayload.messageType === undefined || ContextPayload.messageType === null || ContextPayload.messageType === "") {
			ILSctx.setVariable('messageType', " ")
		} else {
			ILSctx.setVariable('messageType', ContextPayload.messageType)
			ILSPayload.messageType = ContextPayload.messageType
		}
		if (ContextPayload.crewAssignmentID === undefined || ContextPayload.crewAssignmentID === null || ContextPayload.crewAssignmentID === "") {
			ILSctx.setVariable('crewAssignmentID', " ");
		} else {
			ILSctx.setVariable('crewAssignmentID', ContextPayload.crewAssignmentID);
			ILSPayload.crewAssignmentID = ContextPayload.crewAssignmentID
		}
		if (ContextPayload.crewAssignmentDisplayID === undefined || ContextPayload.crewAssignmentDisplayID === null || ContextPayload.crewAssignmentDisplayID === "") {
			ILSctx.setVariable('crewAssignmentDisplayID', " ");
		} else {
			ILSctx.setVariable('crewAssignmentDisplayID', ContextPayload.crewAssignmentDisplayID);
			ILSPayload.crewAssignmentDisplayID = ContextPayload.crewAssignmentDisplayID
		}
		if (ContextPayload.jobID === undefined || ContextPayload.jobID === null || ContextPayload.jobID === "") {
			ILSctx.setVariable('jobID', " ");
		} else {
			ILSctx.setVariable('jobID', ContextPayload.jobID);
			ILSPayload.jobID = ContextPayload.jobID
		}
		if (ContextPayload.crewDisplayID === undefined || ContextPayload.crewDisplayID === null || ContextPayload.crewDisplayID === "") {
			ILSctx.setVariable('crewDisplayID', " ");
		} else {
			ILSctx.setVariable('crewDisplayID', ContextPayload.crewDisplayID);
			ILSPayload.crewDisplayID = ContextPayload.crewDisplayID
		}
		if (ContextPayload.assignmentStatus === undefined || ContextPayload.assignmentStatus === null || ContextPayload.assignmentStatus === "") {
			ILSctx.setVariable('assignmentStatus', " ");
		} else {
			ILSctx.setVariable('assignmentStatus', ContextPayload.assignmentStatus);
			ILSPayload.assignmentStatus = ContextPayload.assignmentStatus
		}
		if (ContextPayload.EventTimeStamp === undefined || ContextPayload.EventTimeStamp === null || ContextPayload.EventTimeStamp === "") {
			ILSctx.setVariable('sourceEventTimestamp', " ");
		} else {
			ILSctx.setVariable('sourceEventTimestamp', ContextPayload.EventTimeStamp);
			ILSPayload.EventTimeStamp = ContextPayload.EventTimeStamp
		}
		if (Entrydescription === undefined || Entrydescription === null || Entrydescription === "") {
			ILSctx.setVariable('Entrydescription', " ");
		} else {
			ILSctx.setVariable('Entrydescription', Entrydescription);
		}
		if (Exitdescription === undefined || Exitdescription === null || Exitdescription === "") {
			ILSctx.setVariable('Exitdescription', " ");
		} else {
			ILSctx.setVariable('Exitdescription', Exitdescription);
		}
		ctx.setVariable('ILSContextPayload', ILSPayload)
	}
});