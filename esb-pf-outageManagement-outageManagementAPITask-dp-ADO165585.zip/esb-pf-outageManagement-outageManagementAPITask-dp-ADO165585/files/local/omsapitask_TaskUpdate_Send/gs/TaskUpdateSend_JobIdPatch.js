var ctx = session.name("TaskUpdate") || session.createContext("TaskUpdate");
var ILSctx = session.name('ILS') || session.createContext('ILS');
var ms = require('multistep');
var urlopen = require('urlopen');
var BusinessErrorCall = require('./BusinessErrorUrlOpen.js');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata')
var logger = console.options({
	'category': 'all'
});

var checkretry = ctx.getVariable("retry");
if (checkretry !== 'yes') {
	var flag = ctx.getVariable("flag")
	session.input.readAsJSON(function(readAsJSONError, incomingData) {
		if (readAsJSONError) {
			ILSctx.setVariable('ExitStatus', '500');
			ILSctx.setVariable('ExitDescription', 'Error in reading incoming data');
			logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
			session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
		} else {
			var OMSUrl = session.parameters.OMSUrl;
			var OMSExitDescription = session.parameters.OMSExitDescription;
			var ETRCountExitDescription = session.parameters.ETRCountExitDescription;
			if ((OMSUrl == undefined) || (OMSUrl == '') || (OMSUrl == null)) {
				ILSctx.setVariable('ExitStatus', '500');
				ILSctx.setVariable('ExitDescription', 'Error in connection with OMSUrl of JobID Patch');
				logger.error("Error in connection with OMSUrl of JobID Patch");
				session.reject("Error in connection with OMSUrl of JobID Patch ");
			} else {
				session.output.write(incomingData);
				if (flag !== 'yes') {
					ctx.setVariable("IncomingDa", incomingData);
					session.output.write(incomingData);
					var CrewAssignmentIDGUID = incomingData.TaskUpdate.CrewAssignmentIDGUID;
					var JobIDGUID = incomingData.TaskUpdate.JobIDGUID;
					var Token = session.parameters.OMSToken;
					var PublishedETRChangeCountPayload

					//Variables response from lookups
					var OutageInternalID = ctx.getVariable("OutageInternalID")
					var CauseCodeIdentifier = ctx.getVariable("CauseCodeIdentifier")
					var MaterialsAffectedStatus = ctx.getVariable("MaterialsAffectedStatus")

					var PublishedETR = incomingData.TaskUpdate.PublishedETR;
					var CloseCancelRemarks = incomingData.TaskUpdate.CloseCancelRemarks;
					var ExchangeMeterIn = incomingData.TaskUpdate.ExchangeMeterIn;
					var ExchangeMeterOut = incomingData.TaskUpdate.ExchangeMeterOut;
					var ExchangeMeterOutReading = incomingData.TaskUpdate.ExchangeMeterOutReading;

					var JobIdParameters = ["OutageSubtype", "CauseCode", "PublishedETR", "CloseCancelRemarks", "ExchangeMeterIn", "ExchangeMeterOut", "ExchangeMeterOutReading", "MaterialsAffected"]

					// Start of Properties changed Patch calls

					var PropertiesChanged = incomingData.TaskUpdate.PropertiesChanged;
					var PropertiesChangedSplit = PropertiesChanged.split(',');
					//	ctx.setVariable("Properties", PropertiesChangedSplit)

					var UpdatesOfJobID = []
					for (var i = 0; i < PropertiesChangedSplit.length; i++) {
						for (var j = 0; j < JobIdParameters.length; j++) {
							if (PropertiesChangedSplit[i] == JobIdParameters[j]) {
								UpdatesOfJobID.push(String(PropertiesChangedSplit[i]))
							}
						}
					}
					ctx.setVariable("UpdatesOfJobID", UpdatesOfJobID)

					var OutageSubtypeExists = UpdatesOfJobID.includes("OutageSubtype");
					var MaterialsAffectedExists = UpdatesOfJobID.includes("MaterialsAffected");
					var CauseCodeExists = UpdatesOfJobID.includes("CauseCode");
					var PublishedETRExists = UpdatesOfJobID.includes("PublishedETR");
					var CloseCancelRemarksExits = UpdatesOfJobID.includes("CloseCancelRemarks");
					var ExchangeMeterInExists = UpdatesOfJobID.includes("ExchangeMeterIn");
					var ExchangeMeterOutExists = UpdatesOfJobID.includes("ExchangeMeterOut");
					var ExchangeMeterOutReadingExists = UpdatesOfJobID.includes("ExchangeMeterOutReading");

					//---------------------------------------------------All Payloads-----------------------------------------------------------
					var OutageSubtypePayload = {
						"outageSubtypeID": OutageInternalID
					}
					var CauseCodePayload = {
						"cause": CauseCodeIdentifier
					}
					var PublishedETRPayload = {
						"publishedEtr": {
							"overridden": true,
							"value": PublishedETR
						},
						"etrStatus": "OVERRIDDEN",
						"changeReason": "API Changed Published ETR"
					}
					var CloseCancelRemarksPayload = {
						"Remarks": CloseCancelRemarks
					}
					var MaterialsAffectedPayload = {
						"MaterialAffected": MaterialsAffectedStatus
					}
					var ExchangeMeterPayload1 = {
						"Exchange_Meter_In": ExchangeMeterIn
					}
					var ExchangeMeterPayload2 = {

						"Exchange_Meter_Out": ExchangeMeterOut
					}
					var ExchangeMeterPayload3 = {

						"Exchange_Meter_Out_Reading": ExchangeMeterOutReading

					}

					var JobCustomFieldsExists = [CauseCodeExists, CloseCancelRemarksExits, ExchangeMeterInExists, ExchangeMeterOutExists, ExchangeMeterOutReadingExists, MaterialsAffectedExists]
					var JobCustomfieldsPayloads = [CauseCodePayload, CloseCancelRemarksPayload, ExchangeMeterPayload1, ExchangeMeterPayload2, ExchangeMeterPayload3, MaterialsAffectedPayload]

					ctx.setVariable("CauseCodePayload", CauseCodePayload)
					var JobCustomPayload = {}

					for (var i = 0; i < JobCustomFieldsExists.length; i++) {
						if (JobCustomFieldsExists[i]) {
							JobCustomPayload = { ...JobCustomPayload, ...JobCustomfieldsPayloads[i] }
						}
					}
					var JobCustomFieldsPayload = {
						"customFieldValues": JobCustomPayload
					}

					ctx.setVariable("JobCustomFieldsPayload", JobCustomFieldsPayload);

					var JobIDsExists = [OutageSubtypeExists, PublishedETRExists]
					var JobIDAllPayloads = [OutageSubtypePayload, PublishedETRPayload]
					if (PropertiesChangedSplit.includes("CauseCode") ||
						PropertiesChangedSplit.includes("MaterialsAffected") ||
						PropertiesChangedSplit.includes("CloseCancelRemarks") ||
						PropertiesChangedSplit.includes("ExchangeMeterIn") ||
						PropertiesChangedSplit.includes("ExchangeMeterOut") ||
						PropertiesChangedSplit.includes("ExchangeMeterOutReading")
					) {
						JobIDsExists.push(JobCustomFieldsExists)
						JobIDAllPayloads.push(JobCustomFieldsPayload)
					}

					var JobIDAllPayloadsPatch = {}

					for (var i = 0; i < JobIDsExists.length; i++) {
						if (JobIDsExists[i]) {
							JobIDAllPayloadsPatch = { ...JobIDAllPayloadsPatch, ...JobIDAllPayloads[i] }
						}
					}

					ctx.setVariable("JobIDAllPayloadsPatch", JobIDAllPayloadsPatch)

					var JobIDExistsHasElements = (
						PropertiesChangedSplit.includes("OutageSubtype") ||
						PropertiesChangedSplit.includes("MaterialsAffected") ||
						PropertiesChangedSplit.includes("CauseCode") ||
						PropertiesChangedSplit.includes("CloseCancelRemarks") ||
						PropertiesChangedSplit.includes("PublishedETR") ||
						PropertiesChangedSplit.includes("ExchangeMeterIn") ||
						PropertiesChangedSplit.includes("ExchangeMeterOut") ||
						PropertiesChangedSplit.includes("ExchangeMeterOutReading"))



					if (JobIDExistsHasElements == true) {
						var JobIDGUID = incomingData.TaskUpdate.JobIDGUID;
						var JobIDUrl = OMSUrl + '/api/v1/ServiceType/Electric/Job/' + JobIDGUID;

						var JobIDPatch = {
							target: JobIDUrl,
							sslClientProfile: 'omsapi_client_profile',
							method: 'PATCH',
							contentType: 'application/json',
							data: JobIDAllPayloadsPatch,
							headers: {
								'osiApiToken': Token
							}
						};
						var info = " TargetURL :" + JobIDPatch.target + "; Method :" + JobIDPatch.method + "; Data :" + JSON.stringify(JobIDPatch.data) + ". ";
						urlopen.open(JobIDPatch, function(error, response) {
							if (error) {
								var errorinfo = "url connection error 'JobIdUpdates', details are : " + info + "; error info :" + error
								ILSctx.setVariable('ExitStatus', '500');
								ILSctx.setVariable('ExitDestination', OMSUrl);
								ILSctx.setVariable('ExitDescription', errorinfo);
								logger.error(errorinfo);
								ctx.setVariable("retry", 'yes');
								var ErrorTxt = "TaskUpdate_017 : " + errorinfo;
								ctx.setVariable("ErrorTxt", ErrorTxt);
								session.output.write(incomingData);
							} else {
								var responseStatusCode = response.statusCode;
								if (responseStatusCode == 200) {
									response.readAsJSON(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'JobIdUpdates', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', '500');
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											hm.response.statusCode = '200 OK';
											ILSctx.setVariable('ExitStatus', '0');
											ILSctx.setVariable('ExitDescription', OMSExitDescription);
											ILSctx.setVariable('ExitDestination', OMSUrl);
											session.output.write(incomingData)
											logger.debug("response received from Job ID Payload Patch :" + responseData)

											var PublishedETRChangeCount = responseData.publishedEtrChangeCount;
											//var Test = PropertiesChangedSplit.includes("PublishedETR")
											//ctx.setVariable("Test", Test)
											if (PropertiesChangedSplit.includes("PublishedETR")) {

												var CallIDUrl = OMSUrl + '/api/ServiceType/Electric/CrewAssignment/' + CrewAssignmentIDGUID + '?includeFields=displayID';
												var GetCallID = {
													target: CallIDUrl,
													sslClientProfile: 'omsapi_client_profile',
													method: 'GET',
													contentType: 'application/json',
													headers: {
														'osiApiToken': Token
													}
												};
												var info = " TargetURL :" + GetCallID.target + "; Method :" + GetCallID.method + ". ";
												urlopen.open(GetCallID, function(error, response) {
													if (error) {
														var errorinfo = "url connection error 'PubliahedETR JobIdUpdates', details are : " + info + "; error info :" + error
														ILSctx.setVariable('ExitStatus', '500');
														ILSctx.setVariable('ExitDescription', errorinfo);
														logger.error(errorinfo);
														session.reject("TaskUpdate_018 : " + errorinfo);
													}
													else {
														var rescode = response.statusCode;
														if (rescode == 200) {
															response.readAsJSON(function(error, responseData) {
																if (error) {
																	var errorinfo = "error reading response 'PubliahedETR JobIdUpdates', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus', '500');
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	session.output.write(incomingData)
																	hm.response.statusCode = '200 OK';
																	ILSctx.setVariable('ExitStatus', '0');
																	ILSctx.setVariable('ExitDescription', OMSExitDescription);
																	ILSctx.setVariable('ExitDestination', OMSUrl);
																	logger.debug("response received from OMS Get calls by job:" + JSON.stringify(responseData));
																	ctx.setVariable("omsResponse", responseData);
																	ctx.setVariable("displayID", responseData.displayID);

																	var CallID = responseData.displayID;
																	var messageID = incomingData.CallBackData.messageID;
																	var TimeModified = incomingData.CallBackData.TimeModified;
																	var Client = incomingData.CallBackData.Client;
																	var Number = incomingData.CallBackData.Number;
																	var ExternalRefID = incomingData.CallBackData.ExternalRefID;

																	PublishedETRChangeCountPayload = {
																		"CallBackData": {
																			"Client": Client,
																			"messageID": messageID,
																			"TimeModified": TimeModified,
																			"ServiceName": "ETRChangeCount",
																			"CallID": CallID,
																			"Number": Number,
																			"ExternalRefID": ExternalRefID
																		},
																		"ETRChangeCount": {
																			"PublishedETRChangeCount": PublishedETRChangeCount
																		}
																	}
																	ILSctx.setVariable('ExitDestination', CallIDUrl);
																	ILSctx.setVariable('ExitDescription', ETRCountExitDescription);
																	ms.callRule('omsapitask_TaskUpdate_Send_Processing_Policy_ILSExit_Rule', null, null, function(error) {
																		if (error) {
																			throw error;
																		}
																	});
																	ctx.setVariable("ETRQueuePayload", PublishedETRChangeCountPayload)
																}
															})
														}
														else {
															response.readAsBuffer(function(error, responseData) {
																if (error) {
																	var errorinfo = "failure in reading response 'PubliahedETR JobIdUpdates', details are : " + info + "; error info :" + error
																	ILSctx.setVariable('ExitStatus', '500');
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																} else {
																	var errorinfo = "error response 'PubliahedETR JobIdUpdates', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
																	ILSctx.setVariable('ExitStatus', '500');
																	ILSctx.setVariable('ExitDescription', errorinfo);
																	var responseStatusCode = response.statusCode;
																	logger.error(errorinfo);
																	session.reject(errorinfo);
																}
															})
														}
													}
												});
											}
										}
									});
								} else if ((responseStatusCode == 400) || (responseStatusCode == 404)) {
									response.readAsBuffer(function(error, BusinessResponseData) {
										if (error) {
											var errorinfo = "error reading response 'JobIdUpdates', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var buff = Buffer.from(BusinessResponseData)
											var ResponseString = buff.toString();
											ctx.setVariable("respo", ResponseString)
											if (!(ResponseString === "No updates")) {
												var errorinfo = "error response 'JobIdUpdates', details are : " + info + "; response info :" + BusinessResponseData + "; ResponseStatusCode :" + responseStatusCode
												ILSctx.setVariable('ExitStatus', responseStatusCode);
												ILSctx.setVariable('ExitDescription', errorinfo);
												logger.error("TaskUpdate_019 : " + errorinfo);
											}
											BusinessErrorCall(ResponseString, BusinessResponseData, responseStatusCode, "JobUpdates BusinessError");
										}
									});
								}
								else {
									response.readAsBuffer(function(error, responseData) {
										if (error) {
											var errorinfo = "error reading response 'JobIdUpdates', details are : " + info + "; error info :" + error
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDescription', errorinfo);
											logger.error(errorinfo);
											session.reject(errorinfo);
										} else {
											var errorinfo = "TaskUpdate_020 : error response 'JobIdUpdates', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
											responseData = responseData.toString()
											if (responseData.includes(("<head>") || ("<" && ">") || ("</" && ">"))) {
												var ErrorTxt = "TaskUpdate_020 : error response 'JobIdUpdates', details are : " + info + "; response info :" + "; ResponseStatusCode :" + responseStatusCode
											} else {
												var ErrorTxt = errorinfo
											}
											ILSctx.setVariable('ExitStatus', responseStatusCode);
											ILSctx.setVariable('ExitDestination', JobIDUrl);
											ILSctx.setVariable('ExitDescription', errorinfo);
											hm.current.statusCode = responseStatusCode;
											logger.error(errorinfo);
											ctx.setVariable("retry", 'yes');
											ctx.setVariable("ErrorTxt", ErrorTxt);
											session.output.write(incomingData);
										}
									});
								}
							}
						});
					}
				}
			}
		}
	});
}
