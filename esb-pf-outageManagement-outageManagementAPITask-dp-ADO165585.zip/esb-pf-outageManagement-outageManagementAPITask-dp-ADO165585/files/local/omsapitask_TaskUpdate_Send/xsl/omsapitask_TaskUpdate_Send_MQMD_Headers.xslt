<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	<dp:input-mapping
		href="store:///pkcs7-convert-input.ffd" type="ffd" />
	<xsl:variable name="request">
		<xsl:value-of
			select="normalize-space(dp:decode(dp:binary-encode(//object/message/node()),'base-64'))"
			disable-output-escaping="yes" />
	</xsl:variable>
	<xsl:output method="text" encoding="utf-8" />
	<xsl:template match="/">
		<!-- Fetching the MQMD headers -->
		<xsl:variable name="entriesMQMD"
			select="dp:request-header('MQMD')" />
		<xsl:variable name="entriesMQRFH2"
			select="dp:request-header('MQRFH2')" />

		<!-- Parsing the string MQMD headers to XML format -->
		<xsl:variable name="mqmd-headers"
			select="dp:parse($entriesMQMD)" />
		<dp:set-variable
			name="'var://context/MQMD/MQMDRequestHeaders'" value="$mqmd-headers" />


		<xsl:if test="normalize-space($entriesMQRFH2)!=''">
			<xsl:variable name="mqrfh2-headers"
				select="dp:parse($entriesMQRFH2)" />
			<!-- Placing the MQMD headers in the context variables -->

			<dp:set-variable
				name="'var://context/MQMD/MQRFH2RequestHeaders'"
				value="$mqrfh2-headers" />
			<xsl:value-of select="$request"
				disable-output-escaping="yes" />
			<dp:set-http-request-header
				name="'Content-Type'" value="'application/json'" />
		</xsl:if>

		<xsl:if
			test="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')">
			<xsl:variable name="mqrfh2"
				select="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')" />
			<xsl:variable name="PutToQueueError"
				select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='PutToQueueError'])" />
			<xsl:if test="contains($PutToQueueError,'Yes' )">
				<dp:set-variable
					name="'var://context/TaskUpdate/PutToQueueError'" value="'yes'" />
			</xsl:if>

		</xsl:if>

		<xsl:if
			test="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')">
			<xsl:variable name="mqrfh2"
				select="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')" />
			<xsl:variable name="ETRQueueError"
				select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='ETRQueueError'])" />

			<xsl:if test="contains($ETRQueueError,'yes' )">
				<dp:set-variable
					name="'var://context/TaskUpdate/ETRQueueError'" value="'yes'" />
			</xsl:if>
		</xsl:if>

		<xsl:if
			test="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')">
			<xsl:variable name="mqrfh2"
				select="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')" />
			<xsl:variable name="SeqConfirmPayload"
				select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='SeqConfirmPayload'])" />
			<dp:set-variable
				name="'var://context/TaskUpdate/initialSeqConfirmPayload'" value="$SeqConfirmPayload" />
		</xsl:if>
		
		<xsl:if
			test="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')">
			<xsl:variable name="mqrfh2"
				select="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')" />
			<xsl:variable name="ETRQueuePayload"
				select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='ETRQueuePayload'])" />
			<dp:set-variable
				name="'var://context/TaskUpdate/ETRQueuePayload'" value="$ETRQueuePayload" />
		</xsl:if>
		
		<xsl:if
			test="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')">
			<xsl:variable name="mqrfh2"
				select="dp:variable('var://context/MQMD/MQRFH2RequestHeaders')" />
			<xsl:variable name="checkLastRetry"
				select="string($mqrfh2/*[local-name()='MQRFH2']/*[local-name()='NameValueData']/*[local-name()='NameValue']/*[local-name()='usr']/*[local-name()='LastRetry'])" />
				<xsl:choose>
				<xsl:when test="contains($checkLastRetry,'Y' )">
				<dp:set-variable
					name="'var://context/TaskUpdate/checkLastRetry'" value="'yes'" />
				</xsl:when>
				<xsl:otherwise>
				<dp:set-variable
					name="'var://context/TaskUpdate/checkLastRetry'" value="'no'" />
				</xsl:otherwise>
				</xsl:choose>
		</xsl:if>


	</xsl:template>
</xsl:stylesheet>
