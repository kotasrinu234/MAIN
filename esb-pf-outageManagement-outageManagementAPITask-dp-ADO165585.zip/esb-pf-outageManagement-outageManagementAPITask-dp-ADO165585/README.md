# esb-pf-outageManagement-outageManagementAPITask-dp
Interface 47 - Task Update

# Package from ST Environment.
