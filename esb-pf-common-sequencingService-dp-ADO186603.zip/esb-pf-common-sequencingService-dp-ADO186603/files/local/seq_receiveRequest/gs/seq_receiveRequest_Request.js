var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var MQURL = session.parameters.MQURL;
var ctx = session.name("SEQ") || session.createContext("SEQ");
var ILSctx = session.name("ILS") || session.createContext("ILS");
var ExitDescription = session.parameters.ExitDescription;
session.input.readAsJSON(function(readAsJSONError, json) {
	if (readAsJSONError) {
		ILSctx.setVariable("ExitDescription", "Error in reading input json")
		ILSctx.setVariable("ExitStatus", "500")
		logger.error("Error in reading incoming data" + JSON.stringify(readAsJSONError));
		session.reject("error in reading incoming data" + JSON.stringify(readAsJSONError));
	} else {
		var QueueURL = MQURL + json.destQueueName
		var options = {
			target: QueueURL,
			contentType: 'application/json',
			data: json
		};

		if (json.destQueueName === undefined || json.destQueueName === null || json.destQueueName === '') {
			var errorinfo = " Destination Queue is undefined or has no value; Input json :" + JSON.stringify(json)
			ILSctx.setVariable("ExitDescription", errorinfo)
			ILSctx.setVariable("ExitStatus", "500")
			logger.error(errorinfo);
			session.reject(errorinfo);
		} else {
			try {
				urlopen.open(options, function(error, response) {
					if (error) {
						hm.response.statusCode = 500
						var errorinfo = "SEQ_002: Error encountered while receiving a message from queue named '" + json.destQueueName + "' :: " + error;
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						ILSctx.setVariable("ExitDescription", errorinfo)
						ILSctx.setVariable("ExitStatus", "500")
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var mqrc = response.statusCode;
						if (mqrc == 0) {
							var replyMQMD = response.get({
								type: 'mq'
							}, 'MQMD');
							var replyMQRFH2 = response.get({
								type: 'mq'
							}, 'MQRFH2');
							response.readAsBuffer(function(readError, responseData) {
								if (readError) {
									hm.response.statusCode = 500
									var errorinfo = "Error encountered while reading response from the queue named '" + json.destQueueName + "' :: " + readError;
									ILSctx.setVariable("ExitDescription", errorinfo)
									ILSctx.setVariable("ExitStatus",mqrc)
									logger.error(errorinfo);
									session.reject(errorinfo);
								} else {
									ILSctx.setVariable("ExitStatus", "0")
									ILSctx.setVariable("ExitDestination", QueueURL)
									ILSctx.setVariable("ExitDescription", ExitDescription)
									logger.debug("MQResponseData" + responseData);
								}
							});
						} else {
							hm.response.statusCode = 500
							var mqconnection = 'Forbidden';
							ctx.setVariable("mqconnection", mqconnection);
							var errorinfo = "SEQ_002: Error encountered while receiving a message from queue named '" + json.destQueueName + "' :: " + JSON.stringify(response);
							ILSctx.setVariable("ExitDescription", errorinfo)
							ILSctx.setVariable("ExitStatus",mqrc)
							logger.error(errorinfo);
							session.reject(errorinfo);
						}
					}
				});
			} catch (err) {
				hm.response.statusCode = 500
				var mqconnection = 'Forbidden';
				ctx.setVariable("mqconnection", mqconnection);
				var errorinfo = "SEQ_002: Error encountered while receiving a message from queue named '" + json.destQueueName + "' :: " + err;
				ILSctx.setVariable("ExitDescription", errorinfo)
				ILSctx.setVariable("ExitStatus", "500")
				logger.error(errorinfo);
				session.reject(errorinfo);
			}
		}
	}
});
