var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var urlopen = require('urlopen');
var headers = hm.current;
var logger = console.options({
	'category': 'all'
});
var ctx = session.name('SEQ') || session.createContext('SEQ');
var ILSctx = session.name('ILS') || session.createContext('ILS');
ILSctx.setVariable('ExitStatus', '0');
session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data, details are:"; "error info :" + readAsJSONError
		ILSctx.setVariable('ExitStatus', '500');
		ILSctx.setVariable('ErrorDescription', errorinfo)
		logger.error(errorinfo);
	} else {
		ctx.setVariable('seqPayload', incomingdata)
		var correlationID = incomingdata.messageId;
		var messageType = incomingdata.messageType;
		var crewAssignmentID = incomingdata.crewAssignmentID;
		var crewAssignmentDisplayID = incomingdata.crewAssignmentDisplayID;
		var jobID = incomingdata.jobID;
		var jobDisplayID = incomingdata.jobDisplayID;
		var sourceEventTimestamp = incomingdata.EventTimeStamp;
		//var workFlowType = incomingdata.workFlowType;
	//	var workFlowRequirementEvent = incomingdata.workFlowRequirementEvent;
		//var confirmationMsg = incomingdata.confirmationMsg;
		var description = session.parameters.EntryDescription;
		var sourceUrl = sm.getVar('var://service/URL-in');
		if (correlationID === undefined || correlationID === null || correlationID === '') {
			ILSctx.setVariable('correlationID', '');
		} else {
			ILSctx.setVariable('correlationID', correlationID);
		}
		if (crewAssignmentID === undefined || crewAssignmentID === null || crewAssignmentID === '') {
			ILSctx.setVariable('crewAssignmentID', ' ');
		} else {
			ILSctx.setVariable("crewAssignmentID", crewAssignmentID);
		}
		if (crewAssignmentDisplayID === undefined || crewAssignmentDisplayID === null || crewAssignmentDisplayID === '') {
		} else {
			ILSctx.setVariable('crewAssignmentDisplayID', ' ');
			ILSctx.setVariable("crewAssignmentDisplayID", crewAssignmentDisplayID);
		}
		if (jobID === undefined || jobID === null || jobID === '') {
			ILSctx.setVariable('jobID', ' ');
		} else {
			ILSctx.setVariable('jobID', jobID);
		}
		if (messageType === undefined || messageType === null || messageType === '') {
			ILSctx.setVariable('messageType', ' ');
		} else {
			ILSctx.setVariable('messageType', messageType);
		}
		if (jobDisplayID === undefined || jobDisplayID === null || jobDisplayID === '') {
			ILSctx.setVariable('jobDisplayID', ' ');
		} else {
			ILSctx.setVariable('jobDisplayID', jobDisplayID);
		}
		if (sourceEventTimestamp === undefined || sourceEventTimestamp === null || sourceEventTimestamp === '') {
			ILSctx.setVariable('sourceEventTimestamp', ' ');
		} else {
			ILSctx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
		}
		/*if (workFlowType === undefined || workFlowType === null || workFlowType === '') {
			ILSctx.setVariable('workFlowType', '');
		} else {
			ILSctx.setVariable('workFlowType', workFlowType);
		}
		if (workFlowRequirementEvent === undefined || workFlowRequirementEvent === null || workFlowRequirementEvent === '') {
			ILSctx.setVariable('workFlowRequirementEvent', '');
		} else {
			ILSctx.setVariable('workFlowRequirementEvent', workFlowRequirementEvent);
		}
		if (confirmationMsg === undefined || confirmationMsg === null || confirmationMsg === '') {
			ILSctx.setVariable('confirmationMsg', '');
		} else {
			ILSctx.setVariable('confirmationMsg', confirmationMsg);
		}*/
		if (description === undefined || description === null || description === '') {
			ILSctx.setVariable('description', '');
		} else {
			ILSctx.setVariable('description', description);
		}
		if (sourceUrl === undefined || sourceUrl === null || sourceUrl === '') {
			ILSctx.setVariable('sourceUrl', ' ');
		} else {
			ILSctx.setVariable('sourceUrl', sourceUrl);
		}
	}
});
