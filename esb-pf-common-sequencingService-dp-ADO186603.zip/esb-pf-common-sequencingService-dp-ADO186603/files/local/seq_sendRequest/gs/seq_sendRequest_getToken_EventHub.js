var urlopen = require('urlopen');
var sm = require('service-metadata')
var logger = console.options({ 'category': 'all' });
var ctx = session.name("SEQ") || session.createContext("SEQ");
var ILSctx = session.name("ILS") || session.createContext("ILS");
sm.setVar("var://service/mpgw/skip-backside", true)

session.INPUT.readAsJSON(function(readAsJSONError, json) {
	if (readAsJSONError) {
		var errorinfo = "Error in reading incoming data as JSON : " + readAsJSONError;
		ILSctx.setVariable("exitDescription", errorinfo)
		ILSctx.setVariable("exitStatus", "500")
		logger.error(errorinfo);
		session.reject(errorinfo);
	} else {

		var getTokenUrl = session.parameters.getTokenUrl
		var Options = {
			target: getTokenUrl,
			method: 'GET',
			contentType: 'application/json',
		};

		var info = " TargetURL :" + Options.target + "; Method :" + Options.method + ". ";
		urlopen.open(Options, function(error, response) {
			if (error) {
				var errorinfo = "SEQ_008: url connection error 'Token Call in seq_sendRequest Service', details are :" + info + "; error info :" + error;
				ILSctx.setVariable("exitDescription", errorinfo);
				ILSctx.setVariable("exitStatus", "500");
				ILSctx.setVariable("exitDestination", getTokenUrl);
				logger.error("url connection error 'Token Call in seq_sendRequest Service', details are :" + info + "; error info :" + error);
				ctx.setVariable("retry", 'yes');
				ctx.setVariable("ErrorTxt", errorinfo);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode === 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'Token Call in seq_sendRequest Service', details are : " + info + "; error info :" + error
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", "500");
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var AccessToken = responseData.access_token;
							if (AccessToken === undefined || AccessToken === null || AccessToken === '') {
								var errorinfo = "SEQ_009: Invalid token revieved in seq_sendRequest Service, details are : " + info
								ILSctx.setVariable("exitDescription", errorinfo);
								ILSctx.setVariable("exitStatus", responseStatusCode);
								ILSctx.setVariable("exitDestination", getTokenUrl);
								logger.error("Invalid token revieved in seq_sendRequest Service, details are : " + info);
								ctx.setVariable("retry", 'yes');
								ctx.setVariable("ErrorTxt", errorinfo);
							} else {
								ILSctx.setVariable("exitDestination", getTokenUrl);
								var eventHubURL = "https://" + session.parameters.hubNameSpace + ".servicebus.windows.net/" + session.parameters.eventHub + "/messages"
								var TokenType = responseData.token_type;
								var Token = TokenType + ' ' + AccessToken;
								var Options = {
									target: eventHubURL,
									sslClientProfile: 'seq_sendRequest_tls_client_profile',
									method: 'POST',
									headers: {
										'Authorization': Token,
									},
									contentType: 'application/x-www-form-urlencoded',
									data: json
								}

								var info = " TargetURL :" + Options.target + "; Method :" + Options.method + "; Data :" + JSON.stringify(Options.data) + ". ";
								var errorDescription = session.parameters.errorDescription
								urlopen.open(Options, function(error, response) {
									if (error) {
										var errorinfo = "SEQ_010: " + errorDescription + " : url connection error 'EventHub Call in seq_sendRequest Service', details are :" + info + "; error info :" + error;
										ILSctx.setVariable("exitDescription", errorinfo);
										ILSctx.setVariable("exitStatus", "500");
										ILSctx.setVariable("exitDestination", eventHubURL);
										logger.error(errorDescription + " : url connection error 'EventHub Call in seq_sendRequest Service', details are :" + info + "; error info :" + error);
										ctx.setVariable("retry", 'yes');
										ctx.setVariable("ErrorTxt", errorinfo);
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode === 200 || responseStatusCode === 201) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'EventHub Call in seq_sendRequest Service' , details are : " + eventHubCallInfo + "; error info :" + error;
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", "500");
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													logger.debug("response received :" + responseData);
													ILSctx.setVariable("exitDescription", session.parameters.exitDescription);
													ILSctx.setVariable("exitDestination", eventHubURL);
													ILSctx.setVariable("exitStatus", "0");
												}
											});
										} else {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "error reading response 'EventHub Call in seq_sendRequest Service', details are : " + info + "; error info :" + error
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", "500");
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "SEQ_010: " + errorDescription + " : error response 'EventHub Call in seq_sendRequest Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
													ILSctx.setVariable("exitDescription", errorinfo);
													ILSctx.setVariable("exitStatus", responseStatusCode);
													ILSctx.setVariable("exitDestination", eventHubURL);
													logger.error(errorDescription + " : error response 'EventHub Call in seq_sendRequest Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
													ctx.setVariable("retry", 'yes');
													ctx.setVariable("ErrorTxt", errorinfo);
												}
											});
										}
									}
								});
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "error reading response 'Token Call', details are : " + info + "; error info :" + error
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							logger.error(errorinfo);
							session.reject(errorinfo);
						} else {
							var errorinfo = "SEQ_011: error response 'Token Call in seq_sendRequest Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode
							ILSctx.setVariable("exitDescription", errorinfo);
							ILSctx.setVariable("exitStatus", responseStatusCode);
							ILSctx.setVariable("exitDestination", getTokenUrl);
							logger.error("error response 'Token Call in seq_sendRequest Service', details are : " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode);
							ctx.setVariable("retry", 'yes');
							ctx.setVariable("ErrorTxt", errorinfo);
						}
					});
				}
			}
		});
	}
});
