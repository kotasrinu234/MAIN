<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

<xsl:variable name="TransactionID">
	<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
			
</xsl:variable>


<xsl:message dp:type="all" dp:priority="error">pdss_003 TransactionID:<xsl:value-of select="$TransactionID"/> In pdss_SendCustomerStatusUpdate service message is pushed to Backout queue PDSS.REQUEST.FOR.CUST.STATUS.UPD.BACKOUT with error : <xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>
	
	</xsl:template>
</xsl:stylesheet>