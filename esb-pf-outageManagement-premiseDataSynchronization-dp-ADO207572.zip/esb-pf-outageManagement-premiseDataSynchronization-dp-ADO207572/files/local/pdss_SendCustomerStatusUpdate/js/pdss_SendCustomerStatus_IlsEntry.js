var ctx = session.name("ils") || session.createContext("ils");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
//var urlIn = sm.getVar('var://service/URL-in');

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		if (incomingdata.CustomerStatusUpdate.msgId == undefined || incomingdata.CustomerStatusUpdate.msgId == null || incomingdata.CustomerStatusUpdate.msgId == '') {
                        ctx.setVariable('correlationID', '');
		}else{
			ctx.setVariable('correlationID',incomingdata.CustomerStatusUpdate.msgId);
		}
		if (incomingdata.CustomerStatusUpdate.premiseId == undefined || incomingdata.CustomerStatusUpdate.premiseId == null || incomingdata.CustomerStatusUpdate.premiseId == '') {
			ctx.setVariable('premiseID', '');
		}else{
			ctx.setVariable('premiseID', incomingdata.CustomerStatusUpdate.premiseId);
		}
		if (incomingdata.CustomerStatusUpdate.meterId == undefined || incomingdata.CustomerStatusUpdate.meterId == null || incomingdata.CustomerStatusUpdate.meterId == '') {
			ctx.setVariable('meterID', '');
		}else{
			ctx.setVariable('meterID', incomingdata.CustomerStatusUpdate.meterId);
		}
		if (incomingdata.CustomerStatusUpdate.status == undefined || incomingdata.CustomerStatusUpdate.status == null || incomingdata.CustomerStatusUpdate.status == '') {
			ctx.setVariable('orderStatus', '');
		}else{
			ctx.setVariable('orderStatus', incomingdata.CustomerStatusUpdate.status);
		}
		if (incomingdata.CustomerStatusUpdate.reason == undefined || incomingdata.CustomerStatusUpdate.reason == null || incomingdata.CustomerStatusUpdate.reason == '') {
			ctx.setVariable('orderReason', '');
		}else{
			ctx.setVariable('orderReason', incomingdata.CustomerStatusUpdate.reason);
		}
		if (incomingdata.CustomerStatusUpdate.jobTimeStamp == undefined || incomingdata.CustomerStatusUpdate.jobTimeStamp == null || incomingdata.CustomerStatusUpdate.jobTimeStamp == '') {
			ctx.setVariable('sourceEventTimestamp', '');
		}else{
			ctx.setVariable('sourceEventTimestamp', incomingdata.CustomerStatusUpdate.jobTimeStamp);
		}
		var Entrydescription = session.parameters.EntryDescription
		ctx.setVariable('Entrydescription', Entrydescription);
		ctx.setVariable('sourceUrl', "PDSS.REQUEST.FOR.CUST.STATUS.UPD");
		var messageType = session.parameters.messageType
		ctx.setVariable('messageType', messageType);
		var Exitdescription = session.parameters.Exitdescription
		ctx.setVariable('Exitdescription', Exitdescription);

		var ExitUrl = session.parameters.omsExternalURL
		var Exitdestination = ExitUrl + '/oms/external';
		ctx.setVariable('Exitdestination', Exitdestination);

	}
});
