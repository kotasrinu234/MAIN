var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("pdss") || session.createContext("pdss");
var logger = console.options({
	'category': 'all'
});

	// getting styleheet params
	// getting styleheet params
	var ctx = session.name("pdss") || session.createContext("pdss");
	var retry = ctx.getVar("retry");
	var errormessage = ctx.getVar("errormessage");
	var errorstatus = ctx.getVariable('exitstatus');
	if (retry != 'yes') {
		var Exitdescription = session.parameters.Exitdescription
		ctx.setVariable('Exitdescription', Exitdescription);
		ctx.setVariable('exitstatus', "0");
		
	}else{
		ctx.setVariable('Exitdescription', errormessage);
		ctx.setVariable('exitstatus', errorstatus);
	}
	
	
