//js is used to read stylesheet param and set to context variables 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

var ctx = session.name("pdss")|| session.createContext("pdss");
//set stylesheet parameters to variable

var omsExternalURL = session.parameters.omsExternalURL;
var apiToken = session.parameters.osiApiToken;


var omsExternalURLV1 = omsExternalURL+'/oms/external/api/v1/ServiceType/Electric/';
var omsExternalURL = omsExternalURL+'/oms/external/api/Premise/service/Electric/';
ctx.setVariable("omsExternalURLV1", omsExternalURLV1);
ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("apiToken", apiToken);
}
});
