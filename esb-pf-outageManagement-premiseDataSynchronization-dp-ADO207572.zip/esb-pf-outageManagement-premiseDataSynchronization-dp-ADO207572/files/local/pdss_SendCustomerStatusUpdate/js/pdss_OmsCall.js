//js is used to invoke the oms premise api get and patch call
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	// getting styleheet params
	var ctx = session.name("pdss") || session.createContext("pdss");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
	var apiToken = ctx.getVar("apiToken");
	session.output.write(incomingdata);
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var IncomingpremiseId = incomingdata.CustomerStatusUpdate.premiseId;
		var IncomingMeterId = incomingdata.CustomerStatusUpdate.meterId;

		if (IncomingpremiseId == undefined || IncomingpremiseId == '' || IncomingpremiseId == null) {
			logger.error(" premiseId is not present in request payload");
			var errorinfo = " premiseId is not present in request payload";
			ctx.setVariable("errormessage", errorinfo)
			session.reject(" premiseId is not present in request payload");
		} else {
			var PremiseGetApiUri = omsExternalURLV1 + 'Premise/' + IncomingpremiseId;

			var TokenValue = apiToken;

			var PremiseGetApi = {
				target: PremiseGetApiUri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},

			};
			var info = " TargetURL :" + PremiseGetApiUri + "; Method :" + 'GET';
			urlopen.open(PremiseGetApi, function(error, response) {
				if (error) {
					//var ctx = session.name("pdss") || session.createContext("pdss");
					ctx.setVariable("retry", 'yes');
					logger.error("urlopen connect error with Get PremiseGetApi for premiseId " + IncomingpremiseId + " with error as " + JSON.stringify(error));
					var errorinfo = info + " urlopen connect error with Get PremiseGetApi for premiseId " + IncomingpremiseId + " with error as " + JSON.stringify(error);
					ctx.setVariable("errormessage", errorinfo);
					ctx.setVariable('exitstatus', "500");
					var ErrorTxt = "pdss_004 urlopen connect error with Get PremiseGetApi for premiseId " + IncomingpremiseId + " with error as " + JSON.stringify(error);
					ctx.setVariable("ErrorTxt", ErrorTxt);
				} else {
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("custcsu failure in reading message from PremiseGetApi" + JSON.stringify(error));
								var errorinfo = info + " failure in reading message from PremiseGetApi" + JSON.stringify(error);
								ctx.setVariable("errormessage", errorinfo);
								session.reject(" failure in reading message from PremiseGetApi" + JSON.stringify(error));
							}
							else {
								var responseMeterId = JSON.parse(responseData).premiseServiceType.meterID;
								var ctx = session.name("pdss") || session.createContext("pdss");
								ctx.setVariable("premisepayload", JSON.parse(responseData));


								//premise patch call starts

								var incomingStatus = incomingdata.CustomerStatusUpdate.status;

								if (incomingStatus == 'D') {

									incomingStatus = false;
								} else {
									incomingStatus = true;
								}

								var reason = incomingdata.CustomerStatusUpdate.reason;
								var offedTimeStamp = incomingdata.CustomerStatusUpdate.offedTimeStamp;
								var metertabelcheck = JSON.parse(responseData).premiseServiceType.customTableValuesExt;
								logger.debug("metertabelcheck " + JSON.stringify(metertabelcheck));
								var metertabelcheckmessage = [];
								if (metertabelcheck != undefined || metertabelcheck != '' || metertabelcheck != null) {


									if (metertabelcheck.Meter_Disconnect_Log_Table == undefined || metertabelcheck.Meter_Disconnect_Log_Table == '' || metertabelcheck.Meter_Disconnect_Log_Table == null) {
										logger.debug("Meter_Disconnect_Log_Table " + JSON.stringify(metertabelcheck.Meter_Disconnect_Log_Table));
									} else {

										var incomingdatablocklength = metertabelcheck.Meter_Disconnect_Log_Table.length;

										for (var i = 0; i < incomingdatablocklength; i++) {
											metertabelcheckmessage.push(metertabelcheck.Meter_Disconnect_Log_Table[i]);

										}

									}

								}

								var meterlogincoming = {
									"meter_disconnect_datetime": offedTimeStamp,
									"note": reason
								}

								metertabelcheckmessage.push(meterlogincoming);
								var payload = {
									"connected": incomingStatus,
									"customTableValues": {
										"Meter_Disconnect_Log_Table": metertabelcheckmessage
									}
								}
								var PremisePATCHapiID = incomingdata.CustomerStatusUpdate.premiseId;
								var PremisePATCHapiuri = omsExternalURL + PremisePATCHapiID;
								var PremisePATCHapi = {
									target: PremisePATCHapiuri,
									sslClientProfile: 'OMS_Client_Profile',
									method: 'PATCH',
									contentType: 'application/json',
									headers: {
										'osiApiToken': TokenValue
									},
									data: payload
								};
								session.output.write(payload);
								var einfo = " TargetURL :" + PremisePATCHapiuri + "; Method :" + 'PATCH' + "; Data :" + JSON.stringify(payload) + ". ";
								urlopen.open(PremisePATCHapi, function(error, response) {
									if (error) {
										//var ctx = session.name("pdss") || session.createContext("pdss");
										ctx.setVariable("retry", 'yes');
										logger.error("urlopen connect error with PremisePATCHapi for PremisePATCHapi " + PremisePATCHapiID + " is  " + JSON.stringify(error));
										var errorinfo = einfo + " urlopen connect error with PremisePATCHapi for PremisePATCHapi " + PremisePATCHapiID + " is  " + JSON.stringify(error);
										ctx.setVariable("errormessage", errorinfo);
										ctx.setVariable('exitstatus', "500");
										var ErrorTxt = "pdss_005 urlopen connect error with PremisePATCHapi for PremisePATCHapi " + PremisePATCHapiID + " is  " + JSON.stringify(error);
										ctx.setVariable('ErrorTxt', ErrorTxt);
									} else {
										var responseStatusCode = response.statusCode;
										if (responseStatusCode == 200) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													logger.error("failure in getting message PremisePATCHapi for PremisePATCHapiID:" + PremisePATCHapiID + " " + JSON.stringify(error));
													var errorinfo = einfo + " failure in getting message PremisePATCHapi for PremisePATCHapiID:" + PremisePATCHapiID + " " + JSON.stringify(error);
													ctx.setVariable("errormessage", errorinfo);
													session.reject("failure in getting message PremisePATCHapi for PremisePATCHapiID:" + PremisePATCHapiID + " " + JSON.stringify(error));
												} else {
													hm.response.statusCode = responseStatusCode;
													logger.debug(" PremisePATCHapiID: " + PremisePATCHapiID + "reponse code is  " + responseStatusCode);
												}
											});
										} else if (responseStatusCode == 423) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "pdss_011 failure in getting message PremisePATCHapi for PremisePATCHapiID:" + PremisePATCHapiID + " Details are : " + einfo + " error details , " + JSON.stringify(error);
													logger.error(errorinfo);
													ctx.setVariable('exitstatus', responseStatusCode);
													ctx.setVariable("errormessage", errorinfo);
													session.reject(errorinfo);
												} else {
													ctx.setVariable("retry", 'yes');
													var errorinfo = "pdss_011 PremisePATCHapiID: " + PremisePATCHapiID + "reponse code is  " + responseStatusCode + " " + responseData + " with details :" + einfo;
													logger.error(errorinfo);
													ctx.setVariable('exitstatus', responseStatusCode);
													ctx.setVariable("errormessage", errorinfo)
													var ErrorTxt = "pdss_011 PremisePATCHapiID: " + PremisePATCHapiID + "reponse code is  " + responseStatusCode + " " + responseData;
													ctx.setVariable('ErrorTxt', ErrorTxt);
												}
											});
										} else if (responseStatusCode == 401) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "pdss_009 failure in reading message from PremisePATCHapiID with details are :" + einfo + " error details:" + JSON.stringify(error);
													ctx.setVariable("errormessage", errorinfo);
													ctx.setVariable('exitstatus', responseStatusCode);
													logger.error(errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "pdss_009 PremisePATCHapiID: " + PremisePATCHapiID + "reponse code is  " + responseStatusCode + " " + responseData + " details are :" + einfo;
													logger.error(errorinfo);
													ctx.setVariable('exitstatus', responseStatusCode);
													ctx.setVariable("errormessage", errorinfo)
													session.reject(errorinfo);

												}
											});

										} else if (responseStatusCode == 403) {
											response.readAsBuffer(function(error, responseData) {
												if (error) {
													var errorinfo = "pdss_010 failure in reading message from PremisePATCHapiID details are:" + einfo + " error info: " + JSON.stringify(error);
													logger.error(errorinfo);
													ctx.setVariable('exitstatus', responseStatusCode);
													ctx.setVariable("errormessage", errorinfo);
													session.reject(errorinfo);
												} else {
													var errorinfo = "pdss_010 PremisePATCHapiID: " + PremisePATCHapiID + "reponse code is  " + responseStatusCode + " " + responseData + " details are: " + einfo;
													logger.error(errorinfo);
													ctx.setVariable('exitstatus', responseStatusCode);
													ctx.setVariable("errormessage", errorinfo)
													session.reject(errorinfo);

												}
											});
										} else {

											response.readAsBuffer(function(error, responseData) {
												if (error) {
													logger.error("failure in reading message from PremisePATCHapiID  " + JSON.stringify(error));
													var errorinfo = einfo + " failure in reading message from PremisePATCHapiID:" + JSON.stringify(error);
													ctx.setVariable("errormessage", errorinfo);
													ctx.setVariable('exitstatus', "500");
													session.reject("failure in reading message from PremisePATCHapiID ");
												} else {
													logger.error(" PremisePATCHapiID: " + PremisePATCHapiID + "reponse code is  " + responseStatusCode + " " + responseData);
													var errorinfo = " PremisePATCHapiID: " + PremisePATCHapiID + "reponse code is  " + responseStatusCode + " " + responseData;
													ctx.setVariable("errormessage", errorinfo)
													ctx.setVariable('exitstatus', responseStatusCode);
													session.reject(" PremisePATCHapiID: " + PremisePATCHapiID + "reponse code is  " + responseStatusCode + " " + responseData);

												}
											});

										}
									}
								});


								//premise patch call ends


							}
						});
					} else if (responseStatusCode == 401) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "pdss_007 failure in reading message from GET Premise call with premiseID, details are " + info + " error details :" + JSON.stringify(error);
								logger.error(errorinfo);
								ctx.setVariable('exitstatus', responseStatusCode);
								ctx.setVariable("errormessage", errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "pdss_007 response code from GET Premise call with premiseID: " + IncomingpremiseId + " is " + responseStatusCode + " " + responseData + " details are:" + info;
								logger.error(errorinfo);
								ctx.setVariable('exitstatus', responseStatusCode);
								ctx.setVariable("errormessage", errorinfo);
								session.reject(errorinfo);
							}
						});
					} else if (responseStatusCode == 403) {
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								var errorinfo = "pdss_008 failure in reading message from GET Premise call with premiseID, details are " + info + " error details :" + JSON.stringify(error);
								logger.error(errorinfo);
								ctx.setVariable('exitstatus', responseStatusCode);
								ctx.setVariable("errormessage", errorinfo);
								session.reject(errorinfo);
							} else {
								var errorinfo = "pdss_008 response code from GET Premise call with premiseID: " + IncomingpremiseId + " is " + responseStatusCode + " " + responseData + " details are: " + info;
								logger.error(errorinfo);
								ctx.setVariable('exitstatus', responseStatusCode);
								ctx.setVariable("errormessage", errorinfo);
								session.reject(errorinfo);
							}
						});
					} else {

						response.readAsBuffer(function(error, responseData) {
							if (error) {
								logger.error("failure in reading message from GET Premise call with premiseID " + JSON.stringify(error));
								var errorinfo = "failure in reading message from GET Premise call with premiseID " + JSON.stringify(error);
								ctx.setVariable("errormessage", errorinfo);
								ctx.setVariable('exitstatus', "500");
								session.reject("failure in reading message from GET Premise call with premiseID ");
							} else {
								logger.error(" response code from GET Premise call with premiseID: " + IncomingpremiseId + " is " + responseStatusCode + " " + responseData);
								var errorinfo = "response code from GET Premise call with premiseID: " + IncomingpremiseId + " is " + responseStatusCode + " " + responseData;
								ctx.setVariable("errormessage", errorinfo);
								ctx.setVariable('exitstatus', responseStatusCode);
								session.reject("response code from GET Premise call with premiseID: " + IncomingpremiseId + " is " + responseStatusCode + " " + responseData);
							}
						});


					}
				}
			});
		}

	}

});
