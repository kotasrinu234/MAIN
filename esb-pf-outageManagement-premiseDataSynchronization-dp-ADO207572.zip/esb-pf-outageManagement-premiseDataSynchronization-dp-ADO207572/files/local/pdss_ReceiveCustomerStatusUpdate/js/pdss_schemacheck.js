var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var nullcheck= session.parameters.nullcheck;
	if(nullcheck == 'yes'){
		if(incomingdata.CustomerStatusUpdate == null || incomingdata.CustomerStatusUpdate == '' || incomingdata.CustomerStatusUpdate == undefined){
			logger.error('pdss_001 CustomerStatusUpdate  is not present in request payload');
			var ctx = session.name("pdss")|| session.createContext("pdss");
			var schemacheck = 'schema failed';
			ctx.setVariable("schemacheck", schemacheck);
			ctx.setVariable('errormessage', "CustomerStatusUpdate  is not present in input payload");
	        session.reject('CustomerStatusUpdate  is not present in input payload');
		}else{
			
	var premiseId = incomingdata.CustomerStatusUpdate.premiseId;
	
	if (premiseId == null || premiseId == '' || premiseId == undefined) {
		logger.error('pdss_001 premiseId is not present in input payload');
		var ctx = session.name("pdss")|| session.createContext("pdss");
		var schemacheck = 'schema failed';
		ctx.setVariable("schemacheck", schemacheck);
		ctx.setVariable('errormessage', "premiseId is not present in input payload");
        session.reject('premiseId is not present in input payload');
    }
	
	var status = incomingdata.CustomerStatusUpdate.status;
	if (status == null || status == '' || status == undefined) {
		logger.error('pdss_001 status is not present in input payload');
		var ctx = session.name("pdss")|| session.createContext("pdss");
		var schemacheck = 'schema failed';
		ctx.setVariable("schemacheck", schemacheck);
		ctx.setVariable('errormessage', "status is not present in input payload");
        session.reject('status is not present in input payload');
    }
	
	var reason = incomingdata.CustomerStatusUpdate.reason;
	if (reason == null || reason == '' || reason == undefined) {
		logger.error('pdss_001 reason is not present in input payload');
		var ctx = session.name("pdss")|| session.createContext("pdss");
		var schemacheck = 'schema failed';
		ctx.setVariable("schemacheck", schemacheck);
		ctx.setVariable('errormessage', "reason is not present in input payload");
        session.reject('reason is not present in input payload');
    }
	var offedTimeStamp = incomingdata.CustomerStatusUpdate.offedTimeStamp;
	
	if (offedTimeStamp == null || offedTimeStamp == '' || offedTimeStamp == undefined) {
		logger.error('pdss_001 offedTimeStamp is not present in input payload');
		var ctx = session.name("pdss")|| session.createContext("pdss");
		var schemacheck = 'schema failed';
		ctx.setVariable("schemacheck", schemacheck);
		ctx.setVariable('errormessage', "offedTimeStamp is not present in input payload");
        session.reject('offedTimeStamp is not present in input payload');
    }
		}
	}
	
});
