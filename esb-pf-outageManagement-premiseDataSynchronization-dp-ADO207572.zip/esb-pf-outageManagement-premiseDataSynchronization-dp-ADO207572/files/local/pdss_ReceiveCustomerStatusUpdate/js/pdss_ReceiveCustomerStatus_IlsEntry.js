var ctx = session.name("ils") || session.createContext("ils");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
//var urlIn = sm.getVar('var://service/URL-in');
function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        hm.response.statusCode = 500;
        session.output.write(readAsJSONError);
    } else {
        if (incomingdata.CustomerStatusUpdate.msgId == undefined || incomingdata.CustomerStatusUpdate.msgId == null || incomingdata.CustomerStatusUpdate.msgId == '') {
            var correlationID = uuidv4();
            ctx.setVariable('ID', correlationID.toString());

        } else {
            ctx.setVariable('ID', incomingdata.CustomerStatusUpdate.msgId);
        }
        if (incomingdata.CustomerStatusUpdate.premiseId == undefined || incomingdata.CustomerStatusUpdate.premiseId == null || incomingdata.CustomerStatusUpdate.premiseId == '') {
            ctx.setVariable('premiseID', '');
        } else {
            ctx.setVariable('premiseID', incomingdata.CustomerStatusUpdate.premiseId);
        }
        if (incomingdata.CustomerStatusUpdate.meterId == undefined || incomingdata.CustomerStatusUpdate.meterId == null || incomingdata.CustomerStatusUpdate.meterId == '') {
            ctx.setVariable('meterID', '');
        } else {
            ctx.setVariable('meterID', incomingdata.CustomerStatusUpdate.meterId);
        }
        if (incomingdata.CustomerStatusUpdate.status == undefined || incomingdata.CustomerStatusUpdate.status == null || incomingdata.CustomerStatusUpdate.status == '') {
            ctx.setVariable('orderStatus', '');
        } else {
            ctx.setVariable('orderStatus', incomingdata.CustomerStatusUpdate.status);
        }
        if (incomingdata.CustomerStatusUpdate.reason == undefined || incomingdata.CustomerStatusUpdate.reason == null || incomingdata.CustomerStatusUpdate.reason == '') {
            ctx.setVariable('orderReason', '');
        } else {
            ctx.setVariable('orderReason', incomingdata.CustomerStatusUpdate.reason);
        }
        if (incomingdata.CustomerStatusUpdate.jobTimeStamp == undefined || incomingdata.CustomerStatusUpdate.jobTimeStamp == null || incomingdata.CustomerStatusUpdate.jobTimeStamp == '') {
            ctx.setVariable('sourceEventTimestamp', '');
        } else {
            ctx.setVariable('sourceEventTimestamp', incomingdata.CustomerStatusUpdate.jobTimeStamp);
        }
        var Entrydescription = session.parameters.EntryDescription
        ctx.setVariable('Entrydescription', Entrydescription);
        ctx.setVariable('sourceUrl', "https://esb.serv.dteco.com:1404/OutageManagement/v1/Premise");
        var messageType = session.parameters.messageType
        ctx.setVariable('messageType', messageType);
        var Exitdescription = session.parameters.Exitdescription
        ctx.setVariable('Exitdescription', Exitdescription);
        ctx.setVariable('Exitdestination', "CRM/Customer/Update");

    }
});
