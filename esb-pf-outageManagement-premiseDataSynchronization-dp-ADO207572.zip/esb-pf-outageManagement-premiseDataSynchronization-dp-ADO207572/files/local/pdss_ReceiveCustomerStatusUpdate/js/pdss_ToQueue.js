//js is used to push message to standalone queue 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	var ilsctx = session.name("ils") || session.createContext("ils");

    var ctx = session.name("pdss") || session.createContext("pdss");
    var StandaloneMQurl = session.parameters.StandaloneMQurl;
    var msgID = ilsctx.getVariable('ID');
    var payload = incomingdata;
    payload.CustomerStatusUpdate.msgId = msgID;

    var Streamapi = {
        target: StandaloneMQurl,
        data: payload
    };
    var info = " TargetURL :" + StandaloneMQurl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
    try {
        urlopen.open(Streamapi, function(error, response) {
            var hm = require('header-metadata');
            if (error) {
                var ctx = session.name("pdss") || session.createContext("pdss");
                var mqconnection = 'Forbidden';
                ctx.setVariable("mqconnection", mqconnection);
                logger.error("pdss_002 error while keeping message to queue is " + error);
                var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + error
                ctx.setVariable("errormessage", errorinfo);
                session.reject(" error while keeping message to queue is " + error);
            } else {
                var mqrc = response.statusCode;

                if (mqrc == 0) {
                    var replyMQMD = response.get({
                        type: 'mq'
                    }, 'MQMD');
                    var replyMQRFH2 = response.get({
                        type: 'mq'
                    }, 'MQRFH2');
                    response.readAsBuffer(function(readError, responseData) {
                        if (readError) {
                            hm.response.statusCode = 500
                            var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + readError
                            ctx.setVariable("errormessage", errorinfo);
                            session.reject("error while keeping message to queue is " + error);
                        } else {
                            logger.debug("MQResponsecode " + mqrc);
                        }
                    });
                } else {
                    var ctx = session.name("pdss") || session.createContext("pdss");
                    var mqconnection = 'Forbidden';
                    ctx.setVariable("mqconnection", mqconnection);
                    logger.error(" pdss_002 response code is urlopen.open error [MQRC=" + mqrc + "]");
                    var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + mqrc
                    ctx.setVariable("errormessage", errorinfo);
                    session.reject(" response code is urlopen.open error [MQRC=" + mqrc + "]");

                }
            }
        });
    }
    catch (err) {
        var ctx = session.name("pdss") || session.createContext("pdss");
        var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + err
        ctx.setVariable("errormessage", errorinfo);
        ctx.setVariable("errorset", 'yes');
        session.reject('** Mqurlopen.open error [MQRC=' + err + ']');
    }
});
