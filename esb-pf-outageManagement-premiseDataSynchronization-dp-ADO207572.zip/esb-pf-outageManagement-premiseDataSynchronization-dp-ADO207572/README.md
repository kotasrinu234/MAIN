# esb-pf-outageManagement-premiseDataSynchronization-dp
Interface 37Premise Data Synchronization Service
Deployment instructions:

Standlaone MQ  scripts are uploaded in dteenergy/esb-pf-outageManagement-premiseDataSynchronization-mq repository.
IIBMQ retry scripts are uploaded in dteenergy/esb-pf-common-retry-iib repository

MQCSP details will be given by DTE ESB team.

Password aliases will be created by DTE ESB team.

Private keys and certs need to be provided by DTE ESB team.


Properties file as per env are in the config folder of this repository.

Jenkins file as per env are also uploaded in this repository.
