<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	extension-element-prefixes="dp dpconfig" exclude-result-prefixes="dp dpconfig">

	<!-- Template to stop and halt xslt execution/flow and will set error code 
		in context -->

	<xsl:template name="reject">
		<xsl:param name="errorCode" />
		<xsl:param name="errorMessage" />
		<dp:set-variable name="'var://context/error/customErrorCode'"
			value="$errorCode" />
		<dp:set-variable name="'var://context/error/customErrorMessage'"
			value="$errorMessage" />
		<xsl:choose>
			<xsl:when test="string-length(normalize-space($errorMessage)) &gt; 0">
				<dp:reject>
					<xsl:value-of select="$errorMessage" />
				</dp:reject>
			</xsl:when>
			<xsl:otherwise>
				<dp:reject />
			</xsl:otherwise>
		</xsl:choose>

	</xsl:template>

</xsl:stylesheet>
