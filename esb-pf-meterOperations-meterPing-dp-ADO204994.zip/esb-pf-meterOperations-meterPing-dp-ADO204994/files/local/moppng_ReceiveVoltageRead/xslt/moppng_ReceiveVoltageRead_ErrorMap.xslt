<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver exslt v1"
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
xmlns:NS1="http://esm.dteco.com/common/v1"
xmlns:NS2="http://esm.dteco.com/common/v1"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1"
	xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request"
	xmlns:exslt="http://exslt.org/common"  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">

	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="no" />
	<xsl:strip-space elements="*" />


	<xsl:variable name="context" select="dp:variable('var://context/receiveVoltageRead/context')" />
	<xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')" />
	<xsl:variable name="dpErrorMessage"	select="dp:variable('var://service/error-message')" />

	<xsl:variable name="customErrorCode" select="dp:variable('var://context/error/customErrorCode')" />
	<xsl:variable name="customErrorMessage"	select="dp:variable('var://context/error/customErrorMessage')" />

	<xsl:template match="/">
		<soapenv:Envelope>
			<soapenv:Body>
				<NS1:AcknowledgementMessage>
					<NS2:Header>
						<xsl:copy-of select="$context/*[local-name()='Header']/child::*"/>
					</NS2:Header>
					<NS1:Reply>
						<NS1:ReplyCode>FAILURE</NS1:ReplyCode>
						<NS1:Error>
							<NS1:level>FATAL</NS1:level>
							<xsl:choose>
								<xsl:when test="$customErrorCode and $customErrorCode !=''">
									<NS1:code>
										<xsl:value-of select="$customErrorCode" />
									</NS1:code>
									<NS1:details>
										<xsl:value-of select="$customErrorMessage" />
									</NS1:details>
								</xsl:when>
								<xsl:otherwise>
									<NS1:code>
										<xsl:value-of select="$systemErrorCode" />
									</NS1:code>
									<NS1:details>
										<xsl:value-of select="$dpErrorMessage" />
									</NS1:details>
								</xsl:otherwise>
							</xsl:choose>
						</NS1:Error>
					</NS1:Reply>
				</NS1:AcknowledgementMessage>
			</soapenv:Body>
		</soapenv:Envelope>
		<xsl:choose>
								<xsl:when test="$customErrorCode and $customErrorCode !=''">
									<xsl:message dp:type="all" dp:priority="error">id=mpng_rvr01|errorString:<xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage)"/>
										</xsl:message>
								</xsl:when>
								<xsl:otherwise>
								<xsl:message dp:type="all" dp:priority="error">id=mpng_rvr01|errorString:<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage)"/>
										</xsl:message>
										</xsl:otherwise>
										</xsl:choose>
		
	</xsl:template>

</xsl:stylesheet>
