<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver v1"
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1"
	xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request"
	xmlns:exslt="http://exslt.org/common" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">

	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
	<xsl:strip-space elements="*" />

	<xsl:template match="/">
		<xsl:variable name="queueManager" select="dp:variable('var://context/receiveVoltageRead/queueManager')" />
		<xsl:variable name="destQueue" select="dp:variable('var://context/receiveVoltageRead/destQueue')" />
		<xsl:variable name="target-url" select="concat('dpmq://', $queueManager,'/?RequestQueue=',$destQueue)"/>

		<dp:url-open target="{$target-url}" response="responsecode-ignore" >
			<xsl:copy-of select="dp:variable('var://context/INPUT')" />
		</dp:url-open>
	</xsl:template>

</xsl:stylesheet>
