<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release"
xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1" 
xmlns:NS2="http://esm.dteco.com/common/v1"
	xmlns:date="http://exslt.org/dates-and-times"
	extension-element-prefixes="dp soap dpconfig ver"
	exclude-result-prefixes="dpconfig v1 NS2 date soapenv">

	<xsl:include href="local://util/error-util.xslt"/>
	<xsl:variable name="config" select="document('local://moppng_ReceiveVoltageRead/xml/moppng_ReceiveVoltageRead_readmeter_config.xml')" />
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes" />
	<xsl:variable name="queueManager" select="$config/config/ReadMeter/queueManager" />
	<xsl:variable name="destQueue" select="$config/config/ReadMeter/destQueue" />

	<xsl:template match="/">
		<xsl:apply-templates select="soapenv:Envelope" />
	</xsl:template>

	<xsl:template match="soapenv:Envelope">
		<xsl:apply-templates select="soapenv:Body" />
	</xsl:template>

	<xsl:template match="soapenv:Body">

		<xsl:variable name="inVerb" select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='Verb']" />
		<xsl:variable name="inNoun" select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='Noun']"  />
		<dp:set-variable name="'var://context/mycontext/Inverb'" value="$inVerb" />


		<xsl:if test="$inVerb= ''">
			<dp:set-variable name="'var://context/mycontext/errorMessage'" value="'Verb Missing'"/>
		</xsl:if>
		<xsl:if test="$inNoun= ''">
			<dp:set-variable name="'var://context/mycontext/errorMessage'" value="'Noun Missing'"/>
		</xsl:if>

		<xsl:if test="$inVerb=''">
			<xsl:call-template name="reject">
				<xsl:with-param name="errorCode" select="'0x00d30003'"/>
				<xsl:with-param name="errorMessage" select="dp:variable('var://context/mycontext/errorMessage')"/>
			</xsl:call-template>
		</xsl:if>

		<xsl:if test="$inNoun=''">
			<xsl:call-template name="reject">
				<xsl:with-param name="errorCode" select="'0x00d30003'"/>
				<xsl:with-param name="errorMessage" select="dp:variable('var://context/mycontext/errorMessage')"/>
			</xsl:call-template>
		</xsl:if>

		<xsl:variable name="context">
			<NS2:Header>
				<NS2:Verb>
					<xsl:value-of select="$config/config/Header/Verb"/>
				</NS2:Verb>
				<NS2:Noun>
					<xsl:value-of select="$config/config/Header/Noun"/>
				</NS2:Noun>
				<NS2:Timestamp>
					<xsl:variable name="timestamp" select="date:date-time()" />
					<xsl:variable name="ZuluTime" select="date:add($timestamp,'PT0H')" />
					<xsl:variable name="ms" select="substring(dp:time-value(),11,3)" />
					<xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')" />
				</NS2:Timestamp>
				<NS2:Source>
					<xsl:value-of select="$config/config/Header/Source"/>
				</NS2:Source>
				<NS2:ReplyAddress>
					<xsl:value-of select="$config/config/Header/ReplyAddress"/>
				</NS2:ReplyAddress>
				<NS2:MessageID>
					<xsl:value-of select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='MessageID']" />
				</NS2:MessageID>
				<NS2:CorrelationID>
					<xsl:value-of select="*[local-name()='replyReadMeter']/*[local-name()='Header']/*[local-name()='CorrelationID']" />
				</NS2:CorrelationID>
			</NS2:Header>
		</xsl:variable>

		<dp:set-variable name="'var://context/receiveVoltageRead/context'" value="$context" />
		<dp:set-variable name="'var://context/receiveVoltageRead/queueManager'" value="$queueManager" />
		<dp:set-variable name="'var://context/receiveVoltageRead/destQueue'" value="$destQueue" />

	</xsl:template>

</xsl:stylesheet>