<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver v1"
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
xmlns:NS1="http://esm.dteco.com/common/v1"
xmlns:NS2="http://esm.dteco.com/common/v1"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1"
	xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request"
	xmlns:exslt="http://exslt.org/common"  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">

	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
	<xsl:strip-space elements="*" />
	<xsl:variable name="context" select="dp:variable('var://context/receiveVoltageRead/context')" />

	<xsl:template match="/">
		<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
			<soapenv:Body>
				<NS1:AcknowledgementMessage>
					<NS2:Header>
						<xsl:copy-of select="$context/*[local-name()='Header']/child::*"/>
					</NS2:Header>
					<NS1:Reply>
						<NS1:ReplyCode>SUCCESS</NS1:ReplyCode>
					</NS1:Reply>
				</NS1:AcknowledgementMessage>
			</soapenv:Body>
		</soapenv:Envelope>
	</xsl:template>

</xsl:stylesheet>
