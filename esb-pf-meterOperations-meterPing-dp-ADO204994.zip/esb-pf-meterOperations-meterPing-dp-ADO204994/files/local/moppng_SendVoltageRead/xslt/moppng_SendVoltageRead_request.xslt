<xsl:stylesheet version="1.0" exclude-result-prefixes="dp ver date"
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://esm.dteco.com/common/v1"
	xmlns:get="http://iec.ch/TC57/2009/GetMeterReadings#" xmlns:req="http://interrogatebyendpoints.esm.dteco.com/v1/request"
	xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
	<xsl:strip-space elements="*" />

	<xsl:variable name="ami_Header"
		select="document('local:///moppng_SendVoltageRead/xml/moppng_SendVoltageRead_header_configuration.xml')" />
	<xsl:variable name="context"
		select="dp:variable('var://context/moppng_SendVoltageRead/context')" />

	<xsl:template match="/">
		<dp:set-http-request-header name="'SOAPAction'" value="$ami_Header/config/soapAction"/>
		<!-- <dp:set-http-request-header name="'Authorization'" value="dp:variable('var://context/moppng_SendVoltageRead/authorization')"/> -->
		<dp:remove-http-request-header name="MQMD" />
		<dp:remove-http-request-header name="MQRFH2" />	
		<soapenv:Envelope>
			<soapenv:Body>
				<xsl:apply-templates select="soap:Envelope/soap:Body/ver:InitiateOutageDetectionEventRequest" />
			</soapenv:Body>
		</soapenv:Envelope>
	</xsl:template>

	<xsl:template match="ver:InitiateOutageDetectionEventRequest">
		<req:InterrogateByEndpointsRequest>
			<v1:Header>
				<v1:Verb>
					<xsl:value-of select="$ami_Header/config/Header/Verb" />
				</v1:Verb>
				<v1:Noun>
					<xsl:value-of select="$ami_Header/config/Header/Noun" />
				</v1:Noun>
				<v1:Timestamp>
					<xsl:variable name="timestamp" select="date:date-time()" />
					<xsl:variable name="ZuluTime" select="date:add($timestamp,'PT0H')" />
					<xsl:variable name="ms" select="substring(dp:time-value(),11,3)" />
					<xsl:value-of select="concat(substring($ZuluTime,1,19),'.',$ms,'Z')" />
				</v1:Timestamp>
				<v1:Source>
					<xsl:value-of select="$ami_Header/config/Header/Source" />
				</v1:Source>
				<v1:ReplyAddress>
					<xsl:value-of select="$ami_Header/config/Header/ReplyAddress" />
				</v1:ReplyAddress>
				<v1:AckRequired>
					<xsl:value-of select="$ami_Header/config/Header/AckRequired" />
				</v1:AckRequired>

				<v1:MessageID>
					<xsl:choose>
						<xsl:when test="ver:transactionID =''">
							<xsl:value-of select="substring-after($context/context/transactionID,'moppng-')" />
						</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="dp:generate-uuid()" />
						</xsl:otherwise>
					</xsl:choose>
				</v1:MessageID>

				<v1:CorrelationID>
					<xsl:value-of select="$context/context/transactionID" />
				</v1:CorrelationID>


			</v1:Header>

			<req:Payload>
				<xsl:apply-templates select="ver:meterIDs/ver:meterID" />
			</req:Payload>

		</req:InterrogateByEndpointsRequest>

	</xsl:template>

	<xsl:template match="ver:meterID">
		<get:EndDeviceAsset>
			<get:mRID>
				<xsl:value-of select="./@meterNo" />
			</get:mRID>
		</get:EndDeviceAsset>
	</xsl:template>

</xsl:stylesheet>