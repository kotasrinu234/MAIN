<xsl:stylesheet version="1.0" extension-element-prefixes="dp soap dpconfig ver" exclude-result-prefixes="dp date" xmlns:date="http://exslt.org/dates-and-times" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ver="http://www.multispeak.org/Version_4.1_Release">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" omit-xml-declaration="no"/>

<xsl:param name="dpconfig:messageType" select="''"/>
	<xsl:param name="dpconfig:interfaceName" select="''"/>
	<xsl:param name="dpconfig:exitDescription" select="''"/>
	<xsl:param name="dpconfig:entryDescription" select="''"/>
	<xsl:param name="dpconfig:sourceUrl" select="''"/>
	<!-- <xsl:param name="dpconfig:exitDestination" select="''"/> -->




	<xsl:template match="/">
	
	<xsl:variable name="messageType" select="$dpconfig:messageType"/>
		<xsl:variable name="interfaceName" select="$dpconfig:interfaceName"/>
		<xsl:variable name="exitDescription" select="$dpconfig:exitDescription"/>
		<xsl:variable name="entryDescription" select="$dpconfig:entryDescription"/>
		<xsl:variable name="sourceUrl" select="$dpconfig:sourceUrl"/>
		<!-- <xsl:variable name="exitDestination" select="$dpconfig:exitDestination"/> -->
		<xsl:variable name="correlationID" select="dp:generate-uuid ()"/>
		<xsl:variable name="sourceEventTimestamp" select="date:date-time()"/>
	
	
	
	
<dp:set-variable name="'var://context/ILS/meterIds'" value="''" />

<dp:set-variable name="'var://context/ILS/messageType'" value="$messageType"/>
		<dp:set-variable name="'var://context/ILS/interfaceName'" value="$interfaceName"/>
		<dp:set-variable name="'var://context/ILS/exitDescription'" value="$exitDescription"/>
		<dp:set-variable name="'var://context/ILS/entryDescription'" value="$entryDescription"/>
		<dp:set-variable name="'var://context/ILS/sourceUrl'" value="$sourceUrl"/>
		<dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'"/>
		<dp:set-variable name="'var://context/ILS/exitDestination'" value="dp:variable('var://service/routing-url')"/>
		<dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID"/>
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$sourceEventTimestamp"/>

		<dp:set-variable name="'var://context/moppng_SendVoltageRead/originalRequest'" value="." />
		<xsl:variable name="request" select="." />			
		<dp:set-variable name="'var://context/store/InMsg'" value="$request"/>
		
		<xsl:variable name="config_creds"
		select="document('local:///moppng_SendVoltageRead/xml/moppng_SendVoltageRead_header_configuration.xml')" />

		<!--<xsl:variable name="username" select="string(/*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='MultiSpeakMsgHeader']/@*[local-name()='UserID'])"/>
		<xsl:variable name="password" select="string(/*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='MultiSpeakMsgHeader']/@*[local-name()='Pwd'])" />-->	
		
		<xsl:variable name="username" select="$config_creds/config/backend_Credentials/userID"/>
		<xsl:variable name="password" select="$config_creds/config/backend_Credentials/password" />	
		<xsl:variable name="userpass" select="concat($username,':',$password)" />	
		<xsl:variable name="encodedUserpass" select="dp:encode($userpass,'base-64')"/>
		<xsl:variable name="Authorization" select="concat('Basic ',$encodedUserpass)" />
		<dp:set-variable name="'var://context/moppng_SendVoltageRead/authorization'" value="normalize-space($Authorization)" />
		<dp:set-variable name="'var://context/moppng_SendVoltageRead/userpass'" value="$userpass" />

		<!--Fetching the MQMD headers-->
		
		<xsl:variable name="entriesMQMD" select="dp:request-header('MQMD')"/>
		<xsl:variable name="entriesMQRFH2" select="dp:request-header('MQRFH2')"/>

		<!--Parsing the string MQMD headers to XML format-->
		<xsl:if test="($entriesMQMD !='' and $entriesMQMD !=null)">
		<xsl:variable name="mqmd-headers" select="dp:parse($entriesMQMD)"/>
		</xsl:if>
		<xsl:if test="($entriesMQRFH2 !='' and $entriesMQRFH2 !=null)">
		<xsl:variable name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)"/>
        </xsl:if>
		<xsl:message dp:priority="debug">
			<xsl:value-of select="concat('The Request MQMD : ', $entriesMQMD)"/>
		</xsl:message>
		<xsl:message dp:priority="debug">
			<xsl:value-of select="concat('The Request MQRFH2 : ', $entriesMQRFH2)"/>
		</xsl:message>

		<!--Placing the MQMD headers in the context variables-->
		<dp:set-variable name="'var://context/MQMD/MQMDRequestHeaders'" value="$mqmd-headers"/>
		<dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value="$mqrfh2-headers"/>
		<!--Creating context variables for future references -->
		<xsl:apply-templates select="soap:Envelope"/>

	</xsl:template>
	<xsl:template match="soap:Envelope">
		<xsl:apply-templates select="soap:Header"/>
		<xsl:apply-templates select="soap:Body"/>
		<!--<dp:set-variable name="'var://context/moppng_SendVoltageRead/context'" value="$context" 
			/>-->
	</xsl:template>
	<xsl:template match="soap:Header">
		<xsl:variable name="header">
			<xsl:copy-of select="."/>
		</xsl:variable>
		<dp:set-variable name="'var://context/moppng_SendVoltageRead/header'" value="$header"/>
	</xsl:template>
	<xsl:template match="soap:Body">
		<xsl:apply-templates select="ver:InitiateOutageDetectionEventRequest"/>
	</xsl:template>
	<!--Set necessary details in the context variable for further ussages-->
	<xsl:template match="ver:InitiateOutageDetectionEventRequest">
		 <xsl:variable name="context">
			<context>
			 <transactionID>
					<xsl:choose>
						<!--Generate unique correlation id if it is not passed as part of request 
							and set to context variable-->
						<xsl:when test="ver:transactionID !=''">
							<xsl:value-of select="ver:transactionID"/>
							<dp:set-variable name="'var://context/ILS/transactionID'" value="string(ver:transactionID)" />
						</xsl:when>
						<!--Set correlation id to context variable-->
						<xsl:otherwise>
						<xsl:variable name = 'transId' select = "concat('moppng-',dp:generate-uuid())"/>
							<!-- <xsl:value-of select="concat('moppng-',dp:generate-uuid())"/> -->
							<xsl:value-of select="$transId"/>
							<dp:set-variable name="'var://context/ILS/transactionID'" value="string($transId)" />
						</xsl:otherwise>
					</xsl:choose>
				</transactionID>
				<objectIDs>
					<xsl:apply-templates select="ver:meterIDs/ver:meterID"/>
				</objectIDs>
			</context>
		</xsl:variable>
		<dp:set-variable name="'var://context/moppng_SendVoltageRead/context'" value="$context"/>
		
		
		
		
		
	</xsl:template>
	<xsl:template match="ver:meterID">
	<dp:set-variable name="'var://context/ILS/meterIds'" value="substring-before(concat(dp:variable('var://context/ILS/meterIds'),@objectID,','),',')" />
		<objectId>
			<xsl:value-of select="@objectID"/>
		</objectId>
	</xsl:template>
</xsl:stylesheet>