<xsl:stylesheet version="1.0" exclude-result-prefixes="dp req get ver v1"
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
	xmlns:NS1="http://esm.dteco.com/common/v1"
	xmlns:soap="http://www.w3.org/2003/05/soap-envelope/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
	<xsl:strip-space elements="*" />
	<xsl:template match="/">
		<soap:Envelope>
			<soap:Body>
				<NS1:AcknowledgementMessage xmlns:NS1="http://esm.dteco.com/common/v1">
					<xsl:copy-of select="dp:variable('var://context/moppng_SendVoltageRequest/Header')"/> 
					<NS1:Reply>
						<NS1:ReplyCode>SUCCESS</NS1:ReplyCode> 
					</NS1:Reply>
				</NS1:AcknowledgementMessage>
			</soap:Body>
		</soap:Envelope>
	</xsl:template>
</xsl:stylesheet>