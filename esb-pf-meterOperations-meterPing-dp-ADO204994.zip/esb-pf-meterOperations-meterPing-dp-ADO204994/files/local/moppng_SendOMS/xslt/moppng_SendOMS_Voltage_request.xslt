<xsl:stylesheet version="1.0" exclude-result-prefixes="dp  get v1 soapenv" extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ns0="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1" xmlns:v11="http://esm.dteco.com/common/v1" xmlns:met="http://iec.ch/TC57/2009/MeterReadings#" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
	<xsl:strip-space elements="*"/>
	<!--<xsl:include href="local://util/error-util.xslt" />
	
	<xsl:variable name="events" select="document('local:///moppng_SendOMS/xml/moppng_SendOMS_Config.xml')"/>
	<xsl:variable name="context" select="dp:variable('var://context/moppng_SendOMS/context')"/>
	<xsl:variable name="notificationResult" select="dp:variable('var://context/moppng_SendOMS/notificationResult')"/>
	<xsl:variable name="originalRequest" select="dp:variable('var://context/moppng_SendOMS/originalRequest')"/>
	-->
	<xsl:template match="/">
	<!--
		<xsl:variable name="request">
			<xsl:apply-templates select="$originalRequest" mode="original"/>
		</xsl:variable>
		<xsl:variable name="soapFaultCode" select="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/faultcode" />
		<xsl:variable name="soapFaultMessage" select="*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/faultstring" />
		<dp:set-variable name = "'var://context/mycontext/fault'" value="$soapFaultCode"/>	
		<xsl:variable name="headers">
			<header name="SOAPAction">
				<xsl:value-of select="'http://www.multispeak.org/Version_4.1_Release/ReadingChangedNotification'"/>
			</header>
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="not($notificationResult/*[local-name() ='errorObject']) and not($soapFaultCode)">
				<xsl:variable name="omsResponse">
					<dp:url-open target="http://omsapidev.dteco.com:8080/axis2/services/OMS_MultiSpeak_v41" content-Type="application/soap" response="responsecode" http-headers="$headers">
						<xsl:copy-of select="$request"/>
					</dp:url-open>
				</xsl:variable>
				<xsl:choose>
					<xsl:when test="$omsResponse/url-open/responsecode ='200'">
						<xsl:copy-of select="$omsResponse/url-open/response/child::*"/>
					</xsl:when>
					<xsl:otherwise>
						<dp:set-variable name="'var://context/moppng_SendOMS/errmsg'" value="$omsResponse/url-open/response/child::*" />
						<xsl:call-template name="reject">
							<xsl:with-param name="errorMessage" select="concat('Error:',$omsResponse/url-open/response/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/*[local-name()='Code']/*[local-name()='Value'],':',$omsResponse/url-open/response/*[local-name()='Envelope']/*[local-name()='Body']/*[local-name()='Fault']/*[local-name()='Reason']/*[local-name()='Text'])" />
						</xsl:call-template>
				    </xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<xsl:choose>
					<xsl:when test="$notificationResult/*[local-name() ='errorObject']">
						<xsl:call-template name="reject">
							<xsl:with-param name="errorMessage" select="concat('Error:',$notificationResult/*[local-name() ='errorObject']/@objectID,' , ',$notificationResult/*[local-name() ='errorObject']/@errorString)" />
						</xsl:call-template>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name="reject">
						  <xsl:with-param name="errorCode" select="$soapFaultCode" />
						  <xsl:with-param name="errorMessage" select="$soapFaultMessage" />
						</xsl:call-template>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>

	</xsl:template>
	<xsl:template match="*[local-name()='Envelope']" mode="original">
		<soap:Envelope>
			<soap:Header>
				<xsl:copy-of select="dp:variable('var://context/moppng_SendOMS/header')"/>
			</soap:Header>
			<soap:Body>
				<xsl:apply-templates select="*[local-name()='Body']/*[local-name()='replyReadMeter']"/>
			</soap:Body>
		</soap:Envelope>
	</xsl:template>
	<xsl:template match="*[local-name()='replyReadMeter']">
		<ns0:ReadingChangedNotification>
			<ns0:changedMeterReads>
				<ns0:meterReading>
					<xsl:attribute name="verb">
						<xsl:value-of select="$events/config/ReadingChangedNotification/Verb"/>
					</xsl:attribute>
					<ns0:meterID>
						<xsl:value-of select="$context/context/meterID"/>
					</ns0:meterID>
					<ns0:readingValues>
						<xsl:variable name="intervalBlocks" select="met:MeterReadings/met:MeterReading/met:IntervalBlocks[met:ReadingType/@ref='Vh(a)']"/>
						<xsl:apply-templates select="$intervalBlocks[1]/met:IntervalReadings[1]"/>
					</ns0:readingValues>
				</ns0:meterReading>
			</ns0:changedMeterReads>
			<ns0:transactionID>
			<xsl:value-of select ="$context/context/transactionID"/>			
			</ns0:transactionID>
		</ns0:ReadingChangedNotification>
	</xsl:template>
	<xsl:template match="met:IntervalReadings">
		<ns0:readingValue>
			<ns0:units>
				<xsl:value-of select="$events/config/ReadingChangedNotification/Units"/>
			</ns0:units>
			<ns0:value>
				<xsl:value-of select="$context/context/intervalBlocksValue"/>
			</ns0:value>
			<ns0:fieldName>
				<xsl:value-of select="$events/config/ReadingChangedNotification/FieldName"/>
			</ns0:fieldName>
			<ns0:timeStamp>
				<xsl:value-of select="$context/context/intervalBlocksTime"/>
			</ns0:timeStamp>
		</ns0:readingValue>
		-->
	</xsl:template>
</xsl:stylesheet>