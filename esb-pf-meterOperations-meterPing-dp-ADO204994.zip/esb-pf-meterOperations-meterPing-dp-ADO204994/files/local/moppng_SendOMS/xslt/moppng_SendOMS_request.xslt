<xsl:stylesheet version="1.0" exclude-result-prefixes="dp"
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
	xmlns:ns0="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1"
	xmlns:v11="http://esm.dteco.com/common/v1" xmlns:met="http://iec.ch/TC57/2009/MeterReadings#"
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
	<xsl:strip-space elements="*" />

	<xsl:variable name="config"
		select="document('local:///moppng_SendOMS/xml/moppng_SendOMS_Config.xml')" />
	<xsl:variable name="context"
		select="dp:variable('var://context/moppng_SendOMS/context')" />

	<xsl:template match="/">
		<dp:set-http-request-header name="'SOAPAction'" value="$config/config/soapAction"/>
		<dp:remove-http-request-header name="MQMD" />
		<!-- <dp:remove-http-request-header name="MQRFH2" />-->
		<soap:Envelope>
			<soap:Header>
				<xsl:copy-of select="dp:variable('var://context/moppng_SendOMS/header')" />
			</soap:Header>
			<soap:Body>
				<xsl:apply-templates
					select="soapenv:Envelope/soapenv:Body/v1:replyReadMeter" />
			</soap:Body>
		</soap:Envelope>
	</xsl:template>

	<xsl:template match="v1:replyReadMeter">
		<ns0:ODEventNotification>
			<ns0:ODEvents>
				<ns0:outageDetectionEvent>
					<xsl:attribute name='verb'>
						<xsl:value-of	select="$config/config/OutageDetectionEvent/Verb" />
					</xsl:attribute>
					<xsl:if test="$context/context/replyCode !='SUCCESS'">
					<xsl:attribute name='errorString'>
						<xsl:value-of	select="$context/context/errorString" />
					</xsl:attribute>
					<xsl:attribute name='replaceID'>
						<xsl:value-of	select="$config/config/OutageDetectionEvent/ReplaceID" />
					</xsl:attribute>
					<xsl:attribute name='utility'>
						<xsl:value-of	select="$config/config/OutageDetectionEvent/Utility" />
					</xsl:attribute>
					</xsl:if>

					<ns0:eventTime>
						<xsl:value-of select="$context/context/timestamp" />
					</ns0:eventTime>			


					<ns0:outageEventType>
						<xsl:choose>
							<xsl:when test="$context/context/replyCode='SUCCESS'">
								<xsl:value-of select="$config/config/OutageDetectionEvent/OutageEventType" />
								<dp:set-variable name="'var://context/ILS/exitDescription'" value="'Meter ping was successful and reply sent'"/>
							</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="$config/config/OutageDetectionEvent/OutageEventTypeFailure" />
								<dp:set-variable name="'var://context/ILS/exitDescription'" value="'Meter ping was un-successful and reply sent'"/>
							</xsl:otherwise>
						</xsl:choose>						
					</ns0:outageEventType>


					<ns0:outageDetectionDeviceType>
						<xsl:value-of	select="$config/config/OutageDetectionEvent/OutageDetectionDeviceType" />
					</ns0:outageDetectionDeviceType>
					<ns0:outageLocation>
						<xsl:attribute name="verb">
							<xsl:value-of	select="$config/config/OutageDetectionEvent/OutageLocationVerb" />
						</xsl:attribute>							
						<ns0:meterID>
							<xsl:attribute name='meterNo'>
								<xsl:value-of	select="$context/context/meterID" />
							</xsl:attribute>
						</ns0:meterID>
					</ns0:outageLocation>
					<ns0:messageList>
						<ns0:message>
							<xsl:attribute name="verb">
								<xsl:value-of
								select="$config/config/OutageDetectionEvent/MessageVerb" />
							</xsl:attribute>

							<ns0:comments>
								<xsl:choose>
									<xsl:when test="$context/context/replyCode='SUCCESS'">
										<xsl:value-of select="$config/config/OutageDetectionEvent/Comments" />
									</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$context/context/replyCode"/>
									</xsl:otherwise>
								</xsl:choose>		
							</ns0:comments>
						</ns0:message>
					</ns0:messageList>

				<!-- 	<xsl:if test="$context/context/replyCode='SUCCESS'">					
						<ns0:problemCode>
							<xsl:value-of select="$config/config/OutageDetectionEvent/ProblemCode" />
						</ns0:problemCode>
					</xsl:if>
					 -->
					<ns0:problemCode>
								<xsl:choose>
									<xsl:when test="$context/context/replyCode='SUCCESS'">
										<xsl:value-of select="$config/config/OutageDetectionEvent/ProblemCode" />
									</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$context/context/errorString"/>
									</xsl:otherwise>
								</xsl:choose>		
							</ns0:problemCode>

				</ns0:outageDetectionEvent>
			</ns0:ODEvents>
			<ns0:transactionID>
			<xsl:value-of select ="$context/context/transactionID"/>			
			
			</ns0:transactionID>

		</ns0:ODEventNotification>
	</xsl:template>

</xsl:stylesheet>