<xsl:stylesheet version="1.0" exclude-result-prefixes="dp dpconfig" extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times" xmlns:ns0="http://www.multispeak.org/Version_4.1_Release" xmlns:v1="http://readmeter.esm.dteco.com/callbacks/v1" xmlns:v11="http://esm.dteco.com/common/v1" xmlns:met="http://iec.ch/TC57/2009/MeterReadings#" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dpconfig="http://www.datapower.com/param/config">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" omit-xml-declaration="no"/>
	
	<xsl:param name="dpconfig:messageType" select="''"/>
	<xsl:param name="dpconfig:interfaceName" select="''"/>
	<!-- <xsl:param name="dpconfig:exitDescription" select="''"/> -->
	<xsl:param name="dpconfig:entryDescription" select="''"/>
	<xsl:param name="dpconfig:sourceUrl" select="''"/>
	<!-- <xsl:param name="dpconfig:exitDestination" select="''"/> -->

	
	<xsl:variable name="configurationProperties">
		<xsl:copy-of select="document('local:///OMS_ConfigurationProperties/XML/Configuration.xml')"/>
	</xsl:variable>
	<xsl:variable name="passwordProperties">
		<xsl:copy-of select="document('local:///OMS_ConfigurationProperties/XML/Password.xml')"/>
	</xsl:variable>
	<xsl:variable name="company" select="$configurationProperties/Configuration/System/Interface/Company"/>
	<xsl:variable name="algorithm" select="$configurationProperties/Configuration/System/Interface/Algorithm"/>
	<xsl:variable name="key" select="$configurationProperties/Configuration/System/Interface/Key"/>
	<xsl:variable name="userId" select="$configurationProperties/Configuration/System/Interface/UserID"/>
	<xsl:variable name="buildString" select="$configurationProperties/Configuration/System/Interface/BuildString"/>
	<xsl:variable name="build" select="$configurationProperties/Configuration/System/Interface/Build"/>
	<xsl:variable name="minorVersion" select="$configurationProperties/Configuration/System/Interface/MinorVersion"/>
	<xsl:variable name="majorVersion" select="$configurationProperties/Configuration/System/Interface/MajorVersion"/>
	<xsl:variable name="encryptedPassword" select="$passwordProperties/Password/System/Interface/EncryptedPwd"/>
	
	<xsl:template match="/">
	
	
	
	<xsl:variable name="messageType" select="$dpconfig:messageType"/>
		<xsl:variable name="interfaceName" select="$dpconfig:interfaceName"/>
		<!-- <xsl:variable name="exitDescription" select="$dpconfig:exitDescription"/> -->
		<xsl:variable name="entryDescription" select="$dpconfig:entryDescription"/>
		<xsl:variable name="sourceUrl" select="$dpconfig:sourceUrl"/>
	<!-- 	<xsl:variable name="exitDestination" select="$dpconfig:exitDestination"/> -->
		<xsl:variable name="correlationID" select="dp:generate-uuid ()"/>
		<xsl:variable name="sourceEventTimestamp" select="date:date-time()"/>
		
		<dp:set-variable name="'var://context/moppng_SendOMS/originalRequest'"	value="." />
		<xsl:variable name="request" select="dp:variable('var://context/moppng_SendOMS/originalRequest')" />			
		<dp:set-variable name="'var://context/mycontext/key'" value="$key"/>
		<dp:set-variable name="'var://context/mycontext/algorithm'" value="$algorithm"/>
		<dp:set-variable name="'var://context/mycontext/encryptedPassword'" value="$encryptedPassword"/>
		
		
		<dp:set-variable name="'var://context/ILS/meterIds'" value="''" />

	<dp:set-variable name="'var://context/ILS/messageType'" value="$messageType"/>
			<dp:set-variable name="'var://context/ILS/interfaceName'" value="$interfaceName"/>
			<!-- <dp:set-variable name="'var://context/ILS/exitDescription'" value="$exitDescription"/> -->
			<dp:set-variable name="'var://context/ILS/entryDescription'" value="$entryDescription"/>
			<dp:set-variable name="'var://context/ILS/sourceUrl'" value="$sourceUrl"/>
			<dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'"/>
			<dp:set-variable name="'var://context/ILS/exitDestination'" value="dp:variable('var://service/routing-url')"/>
			<dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID"/>
			<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$sourceEventTimestamp"/>
	


		<dp:set-variable name="'var://context/store/InMsg'" value="$request"/>
		<!--Fetching the MQMD headers-->
		<xsl:variable name="entriesMQMD" select="dp:request-header('MQMD')"/>
		<xsl:variable name="entriesMQRFH2" select="dp:request-header('MQRFH2')"/>
		
		
		<xsl:if test="($entriesMQMD !='' and $entriesMQMD !=null)">
		
		<!--Parsing the string MQMD headers to XML format-->
		<xsl:variable name="mqmd-headers" select="dp:parse($entriesMQMD)"/>
		</xsl:if>
		<xsl:if test="($entriesMQRFH2 !='' and $entriesMQRFH2 !=null)">
		<xsl:variable name="mqrfh2-headers" select="dp:parse($entriesMQRFH2)"/>
		</xsl:if>
		
		<xsl:message dp:priority="debug">
			<xsl:value-of select="concat('The Request MQMD : ', $entriesMQMD)"/>
		</xsl:message>
		<xsl:message dp:priority="debug">
			<xsl:value-of select="concat('The Request MQRFH2 : ', $entriesMQRFH2)"/>
		</xsl:message>
		<!--Placing the MQMD headers in the context variables-->
		<dp:set-variable name="'var://context/MQMD/MQMDRequestHeaders'" value="$mqmd-headers"/>
		<dp:set-variable name="'var://context/MQMD/MQRFH2RequestHeaders'" value="$mqrfh2-headers"/>
		<xsl:copy-of select="."/>
		<xsl:variable name="omsHeader">
			<ns0:MultiSpeakMsgHeader>
				<xsl:attribute name="Company">
					<xsl:value-of select="$company"/>
				</xsl:attribute>
				<xsl:attribute name="Pwd">
					<xsl:value-of select="dp:decrypt-data($algorithm,$key,$encryptedPassword)"/>
				</xsl:attribute>
				<xsl:attribute name="UserID">
					<xsl:value-of select="$userId"/>
				</xsl:attribute>
				<xsl:attribute name="BuildString">
					<xsl:value-of select="$buildString"/>
				</xsl:attribute>
				<xsl:attribute name="Build">
					<xsl:value-of select="$build"/>
				</xsl:attribute>
				<xsl:attribute name="MinorVersion">
					<xsl:value-of select="$minorVersion"/>
				</xsl:attribute>
				<xsl:attribute name="MajorVersion">
					<xsl:value-of select="$majorVersion"/>
				</xsl:attribute>
			</ns0:MultiSpeakMsgHeader>
		</xsl:variable>
		<dp:set-variable name="'var://context/moppng_SendOMS/header'" value="$omsHeader"/>
		<xsl:apply-templates select="soapenv:Envelope"/>
	</xsl:template>
	<xsl:template match="soapenv:Envelope">
		<xsl:apply-templates select="soapenv:Body"/>
	</xsl:template>
	<xsl:template match="soapenv:Body">
		<xsl:apply-templates select="v1:replyReadMeter"/>
	</xsl:template>
	<!--Set necessary details in the context variable for further ussages-->
	<xsl:template match="v1:replyReadMeter">
	<xsl:variable name="transactionid" select="//*[local-name()='CorrelationID']"/>
	
	
	<xsl:variable name="messageid" select="//*[local-name()='MessageID']"/>
	<xsl:variable name="level" select="v11:Reply/v11:Error/v11:level"/>
	<xsl:variable name="code" select="v11:Reply/v11:Error/v11:code"/>
	<xsl:variable name="details" select="v11:Reply/v11:Error/v11:details"/>
		<xsl:variable name="context">
			<context>
				<transactionID>
					<xsl:choose>
						<xsl:when test="contains($transactionid,'moppng-')">
							<xsl:value-of select="''"/>
							<dp:set-variable name="'var://context/ILS/transactionID'" value="''" />
						</xsl:when>
						<xsl:otherwise>
							<xsl:value-of select="$transactionid"/>
							<dp:set-variable name="'var://context/ILS/transactionID'" value="string($transactionid)" />
						</xsl:otherwise>			
					</xsl:choose>
				</transactionID>
				<meterID>
					<xsl:value-of select="met:MeterReadings/met:MeterReading/met:MeterAsset/met:mRID"/>
					<dp:set-variable name="'var://context/ILS/meterIds'" value="string(met:MeterReadings/met:MeterReading/met:MeterAsset/met:mRID)" />
				</meterID>
				<replyCode>
					<xsl:value-of select="v11:Reply/v11:ReplyCode"/>
				</replyCode>
				<errorString>
					<xsl:value-of select="concat($level,':',$code,':',$details)"/>
				</errorString>
				<intervalBlocksValue>
					<xsl:value-of select="met:MeterReadings/met:MeterReading/met:IntervalBlocks/met:IntervalReadings/met:value"/>
				</intervalBlocksValue>
				<intervalBlocksTime>
					<xsl:value-of select="met:MeterReadings/met:MeterReading/met:IntervalBlocks/met:IntervalReadings/met:timeStamp"/>
				</intervalBlocksTime>
				<timestamp>
					<xsl:value-of select="concat(substring-before(*[local-name()='Header']/*[local-name()='Timestamp'],'Z'),'.000Z')" />
				</timestamp>
			</context>
		</xsl:variable>
		<dp:set-variable name="'var://context/moppng_SendOMS/context'" value="$context"/>
		
	</xsl:template>
</xsl:stylesheet>