<xsl:stylesheet version="1.0" exclude-result-prefixes="soapenv" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
<xsl:template match="/">
<!--This xslt is used to extract the username and password from payload-->
<username><xsl:value-of select="*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='MultiSpeakMsgHeader']/@UserID"/></username>
<password><xsl:value-of select="*[local-name()='Envelope']/*[local-name()='Header']/*[local-name()='MultiSpeakMsgHeader']/@Pwd"/></password>
</xsl:template>
</xsl:stylesheet>