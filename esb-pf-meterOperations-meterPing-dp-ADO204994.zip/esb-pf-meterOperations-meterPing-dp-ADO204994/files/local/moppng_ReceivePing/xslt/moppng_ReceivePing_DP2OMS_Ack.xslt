<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1"
	extension-element-prefixes="dp date" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release" 
	xmlns:exslt="http://exslt.org/common" xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">

	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
	<xsl:strip-space elements="*" />
	<xsl:variable name="context"
		select="dp:variable('var://context/moppng_ReceivePing/context')" />


	<xsl:template match="/">
		<soap:Envelope>
			<xsl:copy-of select="dp:variable('var://context/moppng_ReceivePing/header')"/> 
			<soap:Body>
				<ver:InitiateOutageDetectionEventRequestResponse>
					<!--Optional:-->
					<ver:InitiateOutageDetectionEventRequestResult />
				</ver:InitiateOutageDetectionEventRequestResponse>
			</soap:Body>
		</soap:Envelope>

	</xsl:template>

</xsl:stylesheet>