<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1" extension-element-prefixes="dp" xmlns:dp="http://www.datapower.com/extensions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="no"/>
	<xsl:strip-space elements="*"/>
	<xsl:template match="/">
		<xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
		<xsl:variable name="dpErrorMessage" select="dp:variable('var://service/error-message')"/>
		<xsl:variable name="customErrorCode" select="dp:variable('var://context/error/customErrorCode')"/>
		<xsl:variable name="customErrorMessage" select="dp:variable('var://context/error/customErrorMessage')"/>
		<xsl:variable name="urlOut" select="dp:variable('var://service/URL-out')"/>
		<xsl:variable name="context" select="dp:variable('var://context/moppng_ReceivePing/context')/context" />
		<xsl:variable name="objectIDs" select="$context/objectIDs"/>
		<xsl:variable name = "target-url" select = "dp:variable('var://context/meterPing/target-url')"/>

		
		<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ver="http://www.multispeak.org/Version_4.1_Release">
			<soap:Header>
				<xsl:copy-of select="dp:variable('var://context/moppng_ReceivePing/header')"/>
			</soap:Header>
			<soap:Body>
				<ver:InitiateOutageDetectionEventRequestResponse>
					<ver:InitiateOutageDetectionEventRequestResult>
						<!--Optional:-->
						<ver:errorObject>
							<xsl:choose>
								<xsl:when test="$customErrorMessage!=''">
									<xsl:attribute name="objectID">
										<xsl:value-of select="$objectIDs/objectId"/>
									</xsl:attribute>
									<xsl:attribute name="errorString">
										<xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage)"/>
										
									</xsl:attribute>
								</xsl:when>
								<xsl:otherwise>
									<xsl:attribute name="objectID">
										<xsl:value-of select="$objectIDs/objectId"/>
									</xsl:attribute>
									<xsl:attribute name="errorString">
										<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage)"/>
									</xsl:attribute>
								</xsl:otherwise>
							</xsl:choose>
						</ver:errorObject>
					</ver:InitiateOutageDetectionEventRequestResult>
				</ver:InitiateOutageDetectionEventRequestResponse>
			</soap:Body>
		</soap:Envelope>
		<xsl:choose>
								<xsl:when test="$customErrorMessage!=''">
									<xsl:message dp:type="all" dp:priority="error">id=mpng_rp01|errorString:<xsl:value-of select="concat('ErrorCode =', $customErrorCode,',', 'Error Message = ', $customErrorMessage,' url=',$target-url)"/>
										</xsl:message>
										<dp:set-variable name= "'var://context/ILS/statusDetail'" value = "concat('Error Message = ', $customErrorMessage,'. url=',$target-url)"/>
								</xsl:when>
								<xsl:otherwise>
								<xsl:message dp:type="all" dp:priority="error">id=mpng_rp01|errorString:<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage,' url=',$target-url)"/>
								<dp:set-variable name= "'var://context/ILS/statusDetail'" value = "concat('Error Message = ', $dpErrorMessage,'. url=',$target-url)"/>
										</xsl:message>
										</xsl:otherwise>
										</xsl:choose>
		
	</xsl:template>
</xsl:stylesheet>