<?xml version="1.0" encoding="utf-8"?>
<!-- This XSLT is used to set the headers in the request to IIB
Date:26th September 2019
Author: Sushma Yarlagadda -->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:dp="http://www.datapower.com/extensions" xmlns:date="http://exslt.org/dates-and-times"  xmlns:dyn="http://exslt.org/dynamic" extension-element-prefixes="dp date" exclude-result-prefixes="dp date msxsl dyn">
	<xsl:output method="xml" encoding="utf-8" indent="yes"/>


	<xsl:template match="/">
		<xsl:variable name="queueManager" select="dp:variable('var://context/moppng_ReceivePing/queueManager')" />
		<xsl:variable name="destQueue" select="dp:variable('var://context/moppng_ReceivePing/destQueue')" />
		<xsl:variable name="target-url" select="concat('dpmq://', $queueManager,'/?RequestQueue=',$destQueue,';Sync=true')"/>
		<dp:set-variable name = "'var://context/meterPing/target-url'" value = "$target-url"/>
<dp:set-variable name="'var://context/ILS/exitDestination'" value="$target-url"/>
		<xsl:variable name="mqmd-headers" select="dp:variable('var://context/MQMD/MQMDRequestHeaders')"/>

		<xsl:variable name="CorrelId-RQ" select="dp:variable('var://context/store/msgId')"/>
		<xsl:variable name="MsgId-RQ" select="dp:variable('var://context/store/msgId')"/>

		<xsl:message dp:priority="debug">
			<xsl:value-of select="concat('The Request MQMD : ', $CorrelId-RQ)"/>
		</xsl:message>

		<xsl:variable name="current-headers" select="$mqmd-headers"/>

		<xsl:variable name="MQMDStr">
			<MQMD>
				<Format>
					<xsl:value-of select="'MQHRF2'" />
				</Format>
			</MQMD>
		</xsl:variable>

		<xsl:variable name="MQRFH2Request">
			<MQRFH2>
				<StrucId>RFH</StrucId>
				<Version>2</Version>
				<Format>MQSTR</Format>
				<CodedCharSetId>819</CodedCharSetId>
				<Flags>0</Flags>
				<NameValueCCSID>1208</NameValueCCSID>
				<NameValueData>
					<NameValue>
						<usr>
							<Authorization>
								<xsl:value-of select="dp:http-request-header('Authorization')" />
							</Authorization>
						</usr>
					</NameValue>
				</NameValueData>
			</MQRFH2>
		</xsl:variable>

		<xsl:variable name="serializedMQRFH2Request">
			<dp:serialize select="$MQRFH2Request" omit-xml-decl="yes"/>
		</xsl:variable>

		<xsl:variable name="MQMDStr2">
			<dp:serialize select="$MQMDStr" omit-xml-decl="yes"/>
		</xsl:variable>

		<xsl:variable name="headers">
			<header name="MQMD">
				<xsl:copy-of select="$MQMDStr2"/>
			</header>
			<header name="MQRFH2">
				<xsl:copy-of select="$serializedMQRFH2Request"/>
			</header>
		</xsl:variable>




		<xsl:variable name="result">
			<dp:url-open http-headers="$headers" response="responsecode-ignore" target="{$target-url}">
				<xsl:copy-of select="dp:variable('var://context/INPUT')" />
			</dp:url-open>
		</xsl:variable>

		<xsl:message dp:priority="debug">
                       url-open():::::<xsl:copy-of select="$result"/>
		</xsl:message>
		<dp:set-variable name="'var://context/RTQ/MQRFH2Headers'" value="$headers"/>
		<dp:set-variable name="'var://context/RTQ/RetryQueueResult'" value="$result"/>


		<dp:set-request-header name="'MQMD'" value="$MQMDStr2"/>
		<dp:set-request-header name="'MQRFH2'" value="$serializedMQRFH2Request"/>

		<xsl:copy-of select="$result"/>

	</xsl:template>
</xsl:stylesheet>
