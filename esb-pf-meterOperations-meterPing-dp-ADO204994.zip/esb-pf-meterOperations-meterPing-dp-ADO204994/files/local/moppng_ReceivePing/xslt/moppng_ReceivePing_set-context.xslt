<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release"
	extension-element-prefixes="dp soap dpconfig ver"
	exclude-result-prefixes="dp dpconfig date">
	

	<xsl:output method="xml" indent="yes" omit-xml-declaration="no" />
	
	
	<xsl:param name="dpconfig:messageType" select="''"/>
	<xsl:param name="dpconfig:interfaceName" select="''"/>
	<xsl:param name="dpconfig:exitDescription" select="''"/>
	<xsl:param name="dpconfig:entryDescription" select="''"/>
	<!-- <xsl:param name="dpconfig:sourceUrl" select="''"/> -->
	<!-- <xsl:param name="dpconfig:exitDestination" select="''"/> -->
	
	
	
	
	
	<xsl:variable name="config" select="document('local://moppng_ReceivePing/xml/moppng_ReceivePing_config.xml')" />
	<xsl:variable name="queueManager" select="$config/config/ReceivePing/queueManager" />
	<xsl:variable name="destQueue" select="$config/config/ReceivePing/destQueue" />
	
	
	
	


	<xsl:template match="/">
	
		<xsl:variable name="messageType" select="$dpconfig:messageType"/>
		<xsl:variable name="interfaceName" select="$dpconfig:interfaceName"/>
		<xsl:variable name="exitDescription" select="$dpconfig:exitDescription"/>
		<xsl:variable name="entryDescription" select="$dpconfig:entryDescription"/>
		<!-- <xsl:variable name="sourceUrl" select="$dpconfig:sourceUrl"/> -->
		<!-- <xsl:variable name="exitDestination" select="$dpconfig:exitDestination"/> -->
		<xsl:variable name="correlationID" select="dp:generate-uuid ()"/>
		<xsl:variable name="sourceEventTimestamp" select="date:date-time()"/>
	<dp:set-variable name="'var://context/ILS/meterIds'" value="''" />
	
	<dp:set-variable name="'var://context/ILS/messageType'" value="$messageType"/>
		<dp:set-variable name="'var://context/ILS/interfaceName'" value="$interfaceName"/>
		<dp:set-variable name="'var://context/ILS/exitDescription'" value="$exitDescription"/>
		<dp:set-variable name="'var://context/ILS/entryDescription'" value="$entryDescription"/>
		<dp:set-variable name="'var://context/ILS/sourceUrl'" value="dp:variable('var://service/URL-in')"/>
		<dp:set-variable name="'var://context/ILS/exitStatus'" value="'0'"/>
		
		<dp:set-variable name="'var://context/ILS/correlationID'" value="$correlationID"/>
		<dp:set-variable name="'var://context/ILS/sourceEventTimestamp'" value="$sourceEventTimestamp"/>
		<xsl:apply-templates select="soap:Envelope" />
	</xsl:template>

	<xsl:template match="soap:Envelope">
		<xsl:apply-templates select="soap:Header" />
		<xsl:apply-templates select="soap:Body" />
	</xsl:template>

	<xsl:template match="soap:Header">
		<xsl:variable name="header">
			<xsl:copy-of select="." />
		</xsl:variable>

		<dp:set-variable name="'var://context/moppng_ReceivePing/header'" value="$header" />
	</xsl:template>

	<xsl:template match="soap:Body">
		<xsl:apply-templates select="ver:InitiateOutageDetectionEventRequest" />
	</xsl:template>

	<xsl:template match="ver:InitiateOutageDetectionEventRequest">
		<xsl:variable name="context">
			<context>
			
			 <transactionID>
					<xsl:choose>
						<!--Generate unique correlation id if it is not passed as part of request 
							and set to context variable-->
						<xsl:when test="ver:transactionID !=''">
							<xsl:value-of select="ver:transactionID"/>
							<dp:set-variable name="'var://context/ILS/transactionID'" value="string(ver:transactionID)" />
						</xsl:when>
						<!--Set correlation id to context variable-->
						<xsl:otherwise>
						<xsl:variable name = "transId" select = "concat('moppng-',dp:generate-uuid())"/>
							<!-- <xsl:value-of select="concat('moppng-',dp:generate-uuid())"/> -->
							
							
							<dp:set-variable name="'var://context/ILS/transactionID'" value="string($transId)" />
						</xsl:otherwise>
					</xsl:choose>
				</transactionID>
				
				<objectIDs>
					<xsl:apply-templates select="ver:meterIDs/ver:meterID" />
				</objectIDs>
			</context>
		</xsl:variable>
		<dp:set-variable name="'var://context/moppng_ReceivePing/context'"
			value="$context" />



		
	</xsl:template>



	<!-- Set necessary details in the context variable for further ussages -->
	<xsl:template match="ver:meterID">
	<dp:set-variable name="'var://context/ILS/meterIds'" value="substring-before(concat(dp:variable('var://context/ILS/meterIds'),@objectID,','),',')" />
		<objectId>
			<xsl:value-of select="@objectID" />
		</objectId>
		<dp:set-variable name="'var://context/moppng_ReceivePing/queueManager'" value="$queueManager" />
		<dp:set-variable name="'var://context/moppng_ReceivePing/destQueue'" value="$destQueue" />
	</xsl:template>		

</xsl:stylesheet>
