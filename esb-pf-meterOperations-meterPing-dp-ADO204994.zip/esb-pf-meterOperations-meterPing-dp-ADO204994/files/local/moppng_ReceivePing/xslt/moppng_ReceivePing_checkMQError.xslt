<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1"
	extension-element-prefixes="dp date" xmlns:dp="http://www.datapower.com/extensions"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:date="http://exslt.org/dates-and-times"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="no" />
	<xsl:strip-space elements="*" />
	<xsl:include href="local://util/error-util.xslt" />

	<xsl:template match="/">
		<xsl:variable name="errorCode" select="url-open/statuscode" />
		<xsl:variable name="errorMessage" select="url-open/errorstring" />

		<xsl:if test="url-open/statuscode !=0">
			<xsl:call-template name="reject">
				<xsl:with-param name="errorCode" select="$errorCode" />
				<xsl:with-param name="errorMessage" select="$errorMessage" />
			</xsl:call-template>
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>
