<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:dp="http://www.datapower.com/extensions"
    xmlns:dpconfig="http://www.datapower.com/param/config"

    extension-element-prefixes="dp dpconfig"
    exclude-result-prefixes="dp dpconfig ">
	<xsl:output method="xml"/>
	<xsl:param name="dpconfig:portPing" select="''"/>
	<xsl:param name="dpconfig:portRead" select="''"/>

	<xsl:variable name="portPing" select="$dpconfig:portPing"/>
	<xsl:variable name="portRead" select="$dpconfig:portRead"/> 

	<xsl:variable name="config" select="document('local://mop_MultiSpeakGateway/xml/mop_MultiSpeakGateway_config.xml')"/>

	<xsl:template match="/">

		<xsl:variable name="opName" select="local-name(/*[local-name()='Envelope']/*[local-name()='Body']/*[1])"/>

		<xsl:choose>
			<xsl:when test="$opName='InitiateOutageDetectionEventRequest'" >
				<dp:set-variable name="'var://context/mycontext/port'" value="$portPing" />

			</xsl:when>
			<xsl:when test="$opName='InitiateMeterReadingsByMeterID'" >
				<dp:set-variable name="'var://context/mycontext/port'" value="$portRead" />

			</xsl:when>
		</xsl:choose>
		<xsl:variable name="port" select ="dp:variable('var://context/mycontext/port')"/>

		<!-- <xsl:variable name="port" select="$config/config/Operation[Name=$opName]/Port" /> -->
		<xsl:variable name="host" select="$config/config/Operation[Name=$opName]/Host" />
		<xsl:variable name="uri" select="$config/config/Operation[Name=$opName]/URI" />

		<xsl:variable name="routingUrl" select="concat('http://',$host,':',$port,'/',$uri)"/>
		<dp:set-variable name = "'var://context/mycontext/rURL'"  value="$routingUrl"/>
		<dp:set-variable name="'var://service/routing-url'"  value="$routingUrl" />
		<xsl:copy-of select="." />

	</xsl:template>	
</xsl:stylesheet>