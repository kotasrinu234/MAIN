<xsl:stylesheet version="1.0" exclude-result-prefixes="dp v1" extension-element-prefixes="dp" xmlns:dp="http://www.datapower.com/extensions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="no"/>
	<xsl:strip-space elements="*"/>
	<xsl:template match="/">
	<xsl:variable name="opName" select="local-name(/*[local-name()='Envelope']/*[local-name()='Body']/*[1])" />
		<dp:set-variable name="'var://context/mop_MultiSpeakGateway/operationName'" value="$opName"/>
		
		<xsl:variable name="systemErrorCode" select="dp:variable('var://service/error-code')"/>
		<xsl:variable name="dpErrorMessage" select="dp:variable('var://service/error-message')"/>
		<xsl:variable name="context" select="dp:variable('var://context/mop_MultiSpeakGateway/context')/context" />
		<xsl:variable name="objectIDs" select="dp:variable('var://context/mop_MultiSpeakGateway/context')/context/objectIDs" />
		
		<xsl:variable name="operationName" select="dp:variable('var://context/mop_MultiSpeakGateway/operationName')"/>
		
		<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ver="http://www.multispeak.org/Version_4.1_Release">
			<soap:Header>
				<xsl:copy-of select="dp:variable('var://context/mop_MultiSpeakGateway/header')"/>
			</soap:Header>
			<soap:Body>
			
			<xsl:choose>
			<xsl:when test="$operationName='InitiateOutageDetectionEventRequest' or $opName='InitiateOutageDetectionEventRequest'" >
			<ver:InitiateOutageDetectionEventRequestResponse>
					<ver:InitiateOutageDetectionEventRequestResult>
						<!--Optional:-->
						<ver:errorObject>
						            <xsl:attribute name="objectID">
										<xsl:choose>
											<xsl:when test="$objectIDs">
												<xsl:value-of select="$objectIDs/objectId"/>
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="string(*[local-name()='Envelope']/*[local-name()='Body']/*/*[local-name()='meterIDs']/*[local-name()='meterID']/@*[local-name()='objectID'])"/>
											</xsl:otherwise>
										</xsl:choose>
									</xsl:attribute>

									<xsl:attribute name="errorString">
										<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage)"/>
									</xsl:attribute>
							</ver:errorObject>
					</ver:InitiateOutageDetectionEventRequestResult>
				</ver:InitiateOutageDetectionEventRequestResponse>
			
			</xsl:when>
			<xsl:when test="$operationName='InitiateMeterReadingsByMeterID' or $opName='InitiateMeterReadingsByMeterID'">
			<ver:InitiateMeterReadingsByMeterIDResponse>
					<ver:InitiateMeterReadingsByMeterIDResult>
						<!--Optional:-->
						<ver:errorObject>
									<xsl:attribute name="objectID">
										<xsl:choose>
											<xsl:when test="$objectIDs">
												<xsl:value-of select="$objectIDs/objectId"/>
											</xsl:when>
											<xsl:otherwise>
												<xsl:value-of select="string(*[local-name()='Envelope']/*[local-name()='Body']/*/*[local-name()='meterIDs']/*[local-name()='meterID']/@*[local-name()='objectID'])"/>
											</xsl:otherwise>
										</xsl:choose>
									</xsl:attribute>
									<xsl:attribute name="errorString">
										<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage)"/>
									</xsl:attribute>
							</ver:errorObject>
					</ver:InitiateMeterReadingsByMeterIDResult>
				</ver:InitiateMeterReadingsByMeterIDResponse>
			</xsl:when>
			<xsl:otherwise />
			</xsl:choose>
			
			</soap:Body>
		</soap:Envelope>
		<xsl:message dp:type="all" dp:priority="error">id=mpng_msg01|errorString:<xsl:value-of select="concat('ErrorCode =', $systemErrorCode,',', 'Error Message = ', $dpErrorMessage)"/>
				</xsl:message>
	</xsl:template>
</xsl:stylesheet>