<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpconfig="http://www.datapower.com/param/config" xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
	xmlns:ver="http://www.multispeak.org/Version_4.1_Release"
	extension-element-prefixes="dp soap dpconfig ver"
	exclude-result-prefixes="dp dpconfig">

	<xsl:output method="xml" indent="yes" omit-xml-declaration="no" />

	<xsl:template match="/">
		<xsl:variable name="opName" select="local-name(/*[local-name()='Envelope']/*[local-name()='Body']/*[1])" />
		<dp:set-variable name="'var://context/mop_MultiSpeakGateway/operationName'" value="$opName"/>
		<xsl:apply-templates select="*[local-name()='Envelope']" />
	</xsl:template>

	<xsl:template match="*[local-name()='Envelope']">
		<xsl:apply-templates select="*[local-name()='Header']" />
		<xsl:apply-templates select="*[local-name()='Body']" />
	</xsl:template>

	<xsl:template match="*[local-name()='Header']">
		<xsl:variable name="header">
			<xsl:copy-of select="." />
		</xsl:variable>
		<dp:set-variable name="'var://context/mop_MultiSpeakGateway/header'" value="$header" />
	</xsl:template>

	<xsl:template match="*[local-name()='Body']">
		<xsl:apply-templates select="*[1]" />
	</xsl:template>

	<xsl:template match="*[local-name()='InitiateOutageDetectionEventRequest']|*[local-name()='InitiateMeterReadingsByMeterID'] ">
		<xsl:variable name="context">
			<context>
				<objectIDs>
					<xsl:apply-templates select="*[local-name()='meterIDs']/*[local-name()='meterID']" />
				</objectIDs>
			</context>
		</xsl:variable>
		<xsl:if test= "not(*[local-name()='meterIDs']/*[local-name()='meterID']/@meterNo) or (*[local-name()='meterIDs']/*[local-name()='meterID']/@meterNo='')">
		<dp:reject >meterNo missing</dp:reject>
		</xsl:if>
		

		<dp:set-variable name="'var://context/mop_MultiSpeakGateway/context'" value="$context" />
	</xsl:template>

	<!-- Set necessary details in the context variable for further ussages -->
	<xsl:template match="*[local-name()='meterID']">
		<objectId>
			<xsl:value-of select="@objectID" />
		</objectId>
	</xsl:template>

</xsl:stylesheet>
