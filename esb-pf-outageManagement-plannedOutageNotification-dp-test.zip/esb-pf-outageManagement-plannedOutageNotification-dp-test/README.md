# esb-pf-outageManagement-plannedOutageNotification-dp
PlannedOutage
Interface 43 planned outage Deployment instructions:

Standlaone MQ scripts are uploaded in dteenergy/esb-pf-outageManagement-plannedOutageNotification-mq repository. 

MQCSP details will be given by DTE ESB team.

Password aliases will be created by DTE ESB team.

Private keys and certs need to be provided by DTE ESB team.

Properties file as per env are in the config folder of this repository.

Jenkins file as per env are also uploaded in this repository.
