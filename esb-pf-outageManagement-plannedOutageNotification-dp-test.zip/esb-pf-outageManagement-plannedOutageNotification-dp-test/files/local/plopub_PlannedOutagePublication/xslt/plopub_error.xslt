<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"

	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

	extension-element-prefixes="dp" exclude-result-prefixes="dp">

	<xsl:template match="/">

<xsl:variable name="TransactionID">
	<xsl:copy-of
		select="dp:variable('var://service/global-transaction-id')" />
			
</xsl:variable>


<xsl:choose>
<xsl:when test="contains(dp:variable('var://service/error-code'),'0x00230001' )">

<dp:set-variable name="'var://service/error-protocol-response'" value="'404'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
</xsl:when>

<xsl:when test="contains(dp:variable('var://service/error-subcode'),'0x00c30025' )">
<dp:set-variable name="'var://service/error-protocol-response'" value="'404'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
</xsl:when>

<xsl:when test="contains(dp:variable('var://context/plopub/schemacheck'),'schema failed' )">

<dp:set-variable name="'var://service/error-protocol-response'" value="'404'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
</xsl:when>
<xsl:when test="contains(dp:variable('var://service/error-message'),'Invalid object syntax' )">

<dp:set-variable name="'var://service/error-protocol-response'" value="'404'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
</xsl:when>
<xsl:when test="contains(dp:variable('var://service/error-message'),'Invalid JSON syntax' )">

<dp:set-variable name="'var://service/error-protocol-response'" value="'404'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
</xsl:when>


<xsl:when test="contains(dp:variable('var://service/error-message'),'Invalid string syntax' )">

<dp:set-variable name="'var://service/error-protocol-response'" value="'404'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="dp:variable('var://service/error-message')" />
</xsl:when>




<xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
<xsl:message dp:type="all" dp:priority="error">TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
</xsl:message>

<dp:set-variable name="'var://service/error-protocol-response'" value="'401'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'" />
</xsl:when>



<xsl:otherwise>

<xsl:message dp:type="all" dp:priority="error">TransactionID:<xsl:value-of select="$TransactionID"/> ErrorCode:<xsl:value-of select="dp:variable('var://service/error-headers')"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/></xsl:message>
<dp:set-variable name="'var://service/error-protocol-response'" value="'500'" />
<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Interval Server Error (General Error)'" />

</xsl:otherwise>
</xsl:choose>		
	</xsl:template>
</xsl:stylesheet>
