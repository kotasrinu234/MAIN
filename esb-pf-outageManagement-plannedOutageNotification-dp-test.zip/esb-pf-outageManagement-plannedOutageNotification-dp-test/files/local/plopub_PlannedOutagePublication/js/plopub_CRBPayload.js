//purposeof js is to develop a crb payload and publish it
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var headers = hm.current;
var sm = require('service-metadata')
var logger = console.options({
    'category': 'all'
});

var TokenValue = session.parameters.TokenValue;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {

    	    
    		var outage = [];
        	//start for lookup to reach the premise id and push it to an array
        	var outagePlansblocklength = incomingdata.data[0].outagePlans.length;
        	var premisearraycallleng= outagePlansblocklength ;
        	for(var i = 0; i < outagePlansblocklength; i++){
        		
        		var createdByUserName;
        		
        		if(incomingdata.data[0].outagePlans[i].customFieldValuesExt.createdByUserName ==undefined || incomingdata.data[0].outagePlans[i].customFieldValuesExt.createdByUserName =='' || incomingdata.data[0].outagePlans[i].customFieldValuesExt.createdByUserName == null){
        			createdByUserName = incomingdata.data[0].outagePlans[i].createdByUserName;
        		}else{
        			createdByUserName = incomingdata.data[0].outagePlans[i].customFieldValuesExt.createdByUserName;
        		}
        		
        		
        		//
            	var ctx = session.name("plopub")|| session.createContext("plopub");
            	var id = incomingdata.data[0].outagePlans[i].id;
            	var premisearray = ctx.getVar("premisecallarray_"+id);

        		//
            	var ctx = session.name("plopub")|| session.createContext("plopub");
            	var lookupJobstatus_label = ctx.getVar("lookupJobstatus_label");
            	var cancelmessage  = ctx.getVar("cancelmessage");
            	var script;
            	if (lookupJobstatus_label == "Canceled"){
            		script  = cancelmessage;
            	}else{
            		script = incomingdata.data[0].outagePlans[i].customFieldValuesExt.Outage_Plan_Script;
            	}
            	
      		  
        		
        		var outagepayload = {
        		        "department": "SOC",
        		        "script": script,
        		        "outageDate": incomingdata.data[0].outagePlans[i].plannedOutageTime,
        		        "outageStartTime": incomingdata.data[0].outagePlans[i].plannedOutageTime,
        		        "outageEndTime": incomingdata.data[0].outagePlans[i].plannedRestorationTime,
        		        "submittedBy": "ADMS Createdby:"+createdByUserName,
        		        "premiseNumber": premisearray
        		        
        		      }  
        		premisearray = [];
        		
        		outage.push(outagepayload);
        		
        		premisearraycallleng = premisearraycallleng+1;
        	}
            
        
        var payload = {
        		"outage" : outage
        }         
       
       
        var ctx = session.name("plopub")|| session.createContext("plopub");
        ctx.setVariable("CRB_payload", payload);
        
        
        sm.setVar('var://service/mpgw/skip-backside', true);
        var urlopen = require('urlopen');
        
        var  publishurl= ctx.getVar("publishurl");
        var options = {
            target: publishurl,
            data: payload,
        };
        urlopen.open(options, function(error, response) {
            var hm = require('header-metadata');
            if (error) {
                hm.response.statusCode = 500;
                logger.error("plopub_002 Failed in published the message "+ error);
                session.reject("Failed in published the message "+ error);
            } else {
                var mqrc = response.statusCode;
                if (mqrc == 0) {
                    
                    response.readAsBuffer(function(readError, responseData) {
                        if (readError) {
                            hm.response.statusCode = 500;
                        } else {
							console.log("MQResponseData" + responseData);
                        }
                    });
                } else {
                    logger.error('** urlopen.open error [MQRC=' + mqrc + ']');
                    hm.response.statusCode = 500;
                    logger.error("plopub_002 Failed in published the message "+ mqrc);
                    session.reject('** urlopen.open error [MQRC=' + mqrc + ']');
                 
                }
            }
        });
        

    }
    
    });
