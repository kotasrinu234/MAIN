//js will invoke oms job api
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("plopub")|| session.createContext("plopub");
var omsExternalURL = ctx.getVar("omsExternalURL");
var apiToken= ctx.getVar("apiToken");
var lookupURL = session.parameters.lookupURL;

var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	var ctx = session.name("plopub")|| session.createContext("plopub");
	var jobid = incomingdata.data[0].id;
	var jobtypeID = incomingdata.data[0].jobTypeID;
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		
		// lookup for checking job is in pending or not
		var jobtypeID = incomingdata.data[0].jobTypeID;
		var status = incomingdata.data[0].status;
	var lookupMessagepending= 	{
			  "lookupReq": {
				    "type": [
				    	{
				      "name": "jobTypes.workflows",
				        "id": jobtypeID,
				        "status" :status
				      }      
				      		]
			  			  }
						}
	
	var url = lookupURL;
	var LookupServiceResponsepending = {
								target: url,
								method: 'POST',
								contentType: 'application/json',
								data:lookupMessagepending
								};
	urlopen.open(LookupServiceResponsepending, function(error, response) {
		if (error) {
			logger.error(" urlopen connect error from plopub for jobtypeID LookupServiceResponsepending " + JSON.stringify(error));
			session.reject(" urlopen connect error from plopub for jobtypeID LookupServiceResponsepending " + JSON.stringify(error));
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200 )  {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						logger.error("failure in reading message for jobtypeID   LookupServiceResponsepending " + JSON.stringify(error));
						session.reject(" failure in reading message for jobtypeID   LookupServiceResponsepending " + JSON.stringify(error));
					} else {
						hm.response.statusCode = responseStatusCode;
						logger.debug("response received from LookupServiceResponsepending LookupServiceResponse "+ responseData);			
						var lookupResponse = JSON.parse(responseData);
						var lookupJobstatus_label;
						
						if(lookupResponse.lookupRep.type[0].result==0){
							lookupJobstatus_label= lookupResponse.lookupRep.type[0].label;
							 logger.debug("lookupJobstatus_label is "+lookupJobstatus_label);
							ctx.setVariable("lookupJobstatus_label",lookupJobstatus_label);			
					}else{
						logger.error("lookup response for plopub jobtypeid result is not 0 " );
						session.reject("lookup response for plopub jobtypeid result is not 0 " );
					}
					}
				});
			}else {
				
					logger.error(" lookup service responsecode plopub for jobtypeID  is "+responseStatusCode);
					session.reject (" lookup service responsecode plopub for jobtypeID  is "+responseStatusCode);
			}
				
			}
	
	});
	}
});
