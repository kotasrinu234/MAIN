//js is used to invoke oms premise api and get the premise id
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("plopub") || session.createContext("plopub");
var logger = console.options({
	'category': 'all'
});
var p = 0;
var TokenValue = session.parameters.TokenValue;

session.INPUT.readAsJSON(function(readAsJSONError, incomingdata) {

	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

		var incomingdatablocklength = incomingdata.data[0].outagePlans.length;
		var ctx = session.name("plopub") || session.createContext("plopub");
		var omsExternalURL = ctx.getVar("omsExternalURL");
		var osiApiToken = ctx.getVar("osiApiToken");
		for (var i = 0; i < incomingdatablocklength; i++) {
			var premiseIDS = incomingdata.data[0].outagePlans[i].premiseIDs;
			var id = incomingdata.data[0].outagePlans[i].id;
			var totallen = premiseIDS.length;
			var arraybuldforcalling = [];
			var length = parseInt(session.parameters.lengthvalue);
			var sessionlength = parseInt(session.parameters.lengthvalue);
			var premisecallarray = [];
			var reducelength = session.parameters.lengthvalue - 1;

			for (var j = 0; j <= totallen; j++) {
				var InternalPremiseIDS = premiseIDS.slice(j, length);
				length = length + sessionlength;

				arraybuldforcalling = InternalPremiseIDS;
				//start calling premise api
				var Callapiuri = omsExternalURL + '/Premise/Bulk?isInternalIDs=TRUE&includeFields=externalID';
				var test = OMSpremiseresponse(Callapiuri, arraybuldforcalling, id, premisecallarray);
				//end calling premise api 
				j = j + reducelength;


			}

		}

	}
});

function OMSpremiseresponse(url, arraybuldforcalling, id, premisecallarray) {
	var ctx = session.name("plopub") || session.createContext("plopub");
	var osiApiToken = ctx.getVar("osiApiToken");
	var TokenValue = osiApiToken;
	var Callapi = {
		target: url,
		sslClientProfile: 'OMS_Client_Profile',
		method: 'POST',
		contentType: 'application/json',
		headers: {
			'osiApiToken': TokenValue
		},
		data: arraybuldforcalling
	};
	urlopen.open(Callapi, function(error, response) {
		if (error) {
			logger.error("urlopen connect error with Callapi" + JSON.stringify(error));
			throw error;
		} else {
			// read response data
			// get the response status code
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						logger.error("failure in reading message from premiseapi" + JSON.stringify(error));
						session.reject("failure in reading message from premiseapi" + JSON.stringify(error));
					} else {
						//store status code with response body in context variable
						hm.response.statusCode = responseStatusCode;
						hm.response.statusCode = responseStatusCode;
						logger.debug("response received from premiseapi call is" + responseStatusCode);
						var ctx = session.name("plopub") || session.createContext("plopub");
						var responseelements = JSON.parse(responseData);
						var responseelementslength = responseelements.length;

						for (var n = 0; n < responseelementslength; n++) {

							premisecallarray.push(responseelements[n].externalID);

						}
						var ctx = session.name("plopub") || session.createContext("plopub");
						ctx.setVariable("premisecallarray_" + id, premisecallarray);

					}
				});
			} else if (responseStatusCode == 401 || responseStatusCode == 403) {
				// Handle business error responses (HTTP 401 or 403)
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						// Handle error in reading response data
						var errorinfo = "plopub_002: Unauthorized Error returned from URL details are: " + info + "; error info :" + error;
						ctx.setVariable('ExitDescription', errorinfo);
						ctx.setVariable('exitStatus', responseStatusCode);
						logger.error(errorinfo);
						session.reject(errorinfo);
					} else {
						var errorinfo = "plopub_002: Unauthorized Error returned from URL details are: " + info + "; response info :" + responseData + "; ResponseStatusCode :" + responseStatusCode;
						ctx.setVariable('ExitDescription', errorinfo);
						ctx.setVariable('exitStatus', responseStatusCode);
						logger.error(errorinfo);
						session.reject(errorinfo);
					}
				})
			}
			else {

				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						logger.error("failure in reading message from premiseapi call is " + JSON.stringify(error));
						session.reject("failure in reading message from premiseapi call ");
					} else {
						logger.error("responsecode recieved from premiseapi call is " + responseStatusCode + " " + responseData);
						session.reject("responsecode recieved from premiseapi call is " + responseStatusCode + " " + responseData);
					}
				});
			}
		}
	});



}
