//js is used to perform nullcheck for the input request
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("plopub")|| session.createContext("plopub");
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	
	// getting styleheet params
	var ctx = session.name("plopub")|| session.createContext("plopub");
	var nullCheckRequired = ctx.getVar("nullCheckRequired");
	
	if(readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		
		if(nullCheckRequired == 'yes'){
			var outagePlanslength = incomingdata.data[0].outagePlans.length;
			for(var i = 0 ; i<outagePlanslength ; i++){
				
				var Outage_Plan_Script = incomingdata.data[0].outagePlans[i].customFieldValuesExt;
				if (Outage_Plan_Script == null || Outage_Plan_Script == '' || Outage_Plan_Script == undefined) {
					logger.error('plopub_001 Outage_Plan_Script is not present in input payload');
					var schemacheck = 'schema failed';
					ctx.setVariable("schemacheck", schemacheck);
			        
		            session.reject('Outage_Plan_Script is not present in input payload');
		        }else{
		        	if(Outage_Plan_Script.Outage_Plan_Script == null || Outage_Plan_Script.Outage_Plan_Script == '' ||Outage_Plan_Script.Outage_Plan_Script == undefined){
						logger.error('plopub_001 Outage_Plan_Script is not present in input payload');
						var schemacheck = 'schema failed';
						ctx.setVariable("schemacheck", schemacheck);
				        
			            session.reject('Outage_Plan_Script is not present in input payload');
					}
		        }	
				
				
				
				var plannedOutageTime = incomingdata.data[0].outagePlans[i].plannedOutageTime;
				if (plannedOutageTime == null || plannedOutageTime == '' || plannedOutageTime == undefined) {
					logger.error('plopub_001 plannedOutageTime is not present in input payload');
					var schemacheck = 'schema failed';
					ctx.setVariable("schemacheck", schemacheck);
		            session.reject('plannedOutageTime is not present in input payload');
		        }
				
				var plannedRestorationTime = incomingdata.data[0].outagePlans[i].plannedRestorationTime;
				if (plannedRestorationTime == null || plannedRestorationTime == '' || plannedRestorationTime == undefined) {
					logger.error('plopub_001 plannedRestorationTime is not present in input payload');
					var schemacheck = 'schema failed';
					ctx.setVariable("schemacheck", schemacheck);
		            session.reject('plannedRestorationTime is not present in input payload');
		        }
				
				var createdByUserName = incomingdata.data[0].outagePlans[i].createdByUserName;
				if (createdByUserName == null || createdByUserName == '' || createdByUserName == undefined) {
					logger.error('plopub_001 createdByUserName is not present in input payload');
					var schemacheck = 'schema failed';
					ctx.setVariable("schemacheck", schemacheck);
		            session.reject('createdByUserName is not present in input payload');
		        }
				
				var premiseIDs = incomingdata.data[0].outagePlans[i].premiseIDs;
				if (premiseIDs == null || premiseIDs == '' || premiseIDs == undefined) {
					logger.error('plopub_001 premiseIDs is not present in input payload');
					var schemacheck = 'schema failed';
					ctx.setVariable("schemacheck", schemacheck);
		            session.reject('premiseIDs is not present in input payload');
		        }
			}
		}
	}
	});
