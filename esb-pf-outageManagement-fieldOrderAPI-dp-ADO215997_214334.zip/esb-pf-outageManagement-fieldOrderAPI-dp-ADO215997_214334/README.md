# esb-pf-outageManagement-fieldOrderAPI-dp

Deployment instructions:

Domain: OutageManagement01
pipeline PROD :  esb-pf-outageManagement-fieldOrderAPI-dp-prod
Services: 1.omsfoa


Tokens to be updated after Prod Deployment: omsfoa --osiApiToken (stylesheet parameter name)

NOTE: Please validate if all objects are up. Password alias for MQ, ssl certs should be added.
