var ctx = session.name("omsfoa") || session.createContext("omsfoa");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var headers = hm.current;
var logger = console.options({ 'category': 'all' });
var urlIn = sm.getVar('var://service/URL-in');

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
		var corid = uuidv4();
		ctx.setVariable('correlationID', corid);
		ctx.setVariable("messageType", 'updateEvent');

		if (incomingdata.FSM_EFO_Acknowledgement && incomingdata.FSM_EFO_Acknowledgement.ExternalRefID) {
			var payloaddata = incomingdata.FSM_EFO_Acknowledgement.ExternalRefID;
			var externalrefid_parts = payloaddata.split('_');
		}
		if (!(externalrefid_parts[1] == undefined || externalrefid_parts[1] == null || externalrefid_parts[1] == '')) {
			ctx.setVariable("ilscrewassignmentid", externalrefid_parts[1]);
		}
		if (!(externalrefid_parts[2] == undefined || externalrefid_parts[2] == null || externalrefid_parts[2] == '')) {
			ctx.setVariable("jobID", externalrefid_parts[2]);
		}
		if (incomingdata.FSM_EFO_Acknowledgement.Acknowledgement != undefined || incomingdata.FSM_EFO_Acknowledgement.Acknowledgement != null || incomingdata.FSM_EFO_Acknowledgement.Acknowledgement != '') {
			ctx.setVariable("acknowledgement", incomingdata.FSM_EFO_Acknowledgement.Acknowledgement);
		}
		ctx.setVariable('sourceUrl', urlIn);
		var entrydescription = session.parameters.ResEntryDescription;
		ctx.setVariable('description', entrydescription);
		var sourceEventTimestamp = new Date().toISOString();
		ctx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
		var ack = incomingdata.FSM_EFO_Acknowledgement.Acknowledgement;
		if (ack == 'NegativeAcknowledge') {
			ctx.setVariable('ExitDescription', session.parameters.NACKExitDescription);
		} else {
			ctx.setVariable('ExitDescription', session.parameters.ACKExitDescription);
		}
		var exitdestination = session.parameters.omsExternalURL;
		ctx.setVariable("exitdestination", exitdestination);
		var json_mqrfh2 = headers.get({
			type: 'mq'
		}, 'MQRFH2');
		if (
			json_mqrfh2 &&
			json_mqrfh2.MQRFH2 &&
			json_mqrfh2.MQRFH2.NameValueData &&
			json_mqrfh2.MQRFH2.NameValueData.NameValue &&
			json_mqrfh2.MQRFH2.NameValueData.NameValue.usr &&
			json_mqrfh2.MQRFH2.NameValueData.NameValue.usr.retryCount
		) {

		}
		else {
			headers.remove('MQRFH2')

		}
	}
});
