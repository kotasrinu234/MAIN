var ctx = session.name("omsfoa") || session.createContext("omsfoa");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
var urlIn = sm.getVar('var://service/URL-in');

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		hm.response.statusCode = 500;
		session.output.write(readAsJSONError);
	} else {
		function uuidv4() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16); }); }
		var corid = uuidv4();
		incomingdata.messageId = corid
		ctx.setVariable('correlationID', corid);
		var interfaceName = session.parameters.interfaceName;
		ctx.setVariable('interfaceName', interfaceName);

		if (urlIn.includes("Create") || urlIn.includes("Cancel")) {
			ctx.setVariable('messageType', 'crewAssignmentEvent');
			if (!(incomingdata.data[0].id == undefined || incomingdata.data[0].id == null || incomingdata.data[0].id == '')) {
				ctx.setVariable('ilscrewAssignmentID', incomingdata.data[0].id);
			}
			if (!(incomingdata.data[0].displayID == undefined || incomingdata.data[0].displayID == null || incomingdata.data[0].displayID == '')) {
				ctx.setVariable('crewAssignmentDisplayID', incomingdata.data[0].displayID);
			}

			if (!(incomingdata.data[0].job == undefined || incomingdata.data[0].job == null || incomingdata.data[0].job == '')) {
				if (!(incomingdata.data[0].job.id == undefined || incomingdata.data[0].job.id == null || incomingdata.data[0].job.id == '')) {
					ctx.setVariable('jobID', incomingdata.data[0].job.id);
				}
				if (!(incomingdata.data[0].job.displayID == undefined || incomingdata.data[0].job.displayID == null || incomingdata.data[0].job.displayID == '')) {
					ctx.setVariable('jobDisplayID', incomingdata.data[0].job.displayID);
				}
			}

			var Createdescription = session.parameters.Createdescription;
			ctx.setVariable('description', Createdescription)
			ctx.setVariable('ExitDescription', session.parameters.CREWExitDescription);
		}

		if (urlIn.includes("Update")) {
			ctx.setVariable('messageType', 'jobEvent');
			if (!(incomingdata.data[0].id == undefined || incomingdata.data[0].id == null || incomingdata.data[0].id == '')) {
				ctx.setVariable('jobID', incomingdata.data[0].id);
			}
			if (!(incomingdata.data[0].displayID == undefined || incomingdata.data[0].displayID == null || incomingdata.data[0].displayID == '')) {
				ctx.setVariable('jobDisplayID', incomingdata.data[0].displayID);
			}
			var Updatedescription = session.parameters.Updatedescription;
			ctx.setVariable('description', Updatedescription)
			ctx.setVariable('ExitDescription', session.parameters.JOBExitDescription);
		}


		if (urlIn.includes("Cancel")) {

			var Canceldescription = session.parameters.Canceldescription;
			ctx.setVariable('description', Canceldescription)
		}

		if (!(incomingdata.data[0].crew == undefined)) {
			if (!(incomingdata.data[0].crew.customFieldValuesExt == undefined)) {
				if (!(incomingdata.data[0].crew.customFieldValuesExt.employeeid == undefined)) {
					ctx.setVariable('crewDisplayID', incomingdata.data[0].crew.customFieldValuesExt.employeeid);
				}
			}
		}
		if (incomingdata.status === undefined || incomingdata.status === null || incomingdata.status === '') {
			ctx.setVariable("assignmentStatus", '');
		} else {
			var assignmentStatus = incomingdata.status;
			ctx.setVariable("assignmentStatus", assignmentStatus);
		}
		if (!(incomingdata.data[0].updatedAt == undefined)) {
			ctx.setVariable('sourceEventTimestamp', incomingdata.data[0].updatedAt)
		} else {
			var sourceEventTimestamp = incomingdata.data[0].createdAt;
			ctx.setVariable('sourceEventTimestamp', sourceEventTimestamp);
		}
		ctx.setVariable('sourceUrl', urlIn);
		
				if (urlIn.includes("Create") || urlIn.includes("Cancel")) {
					
			
					if((!( incomingdata.data[0].status == undefined)) && (!(incomingdata.data[0].workTypeID == undefined ))){
					var lookupmessage=
					{"lookupReq":{"type":[{"name":"workTypes.workflows",
					"status":incomingdata.data[0].status,
					"id":incomingdata.data[0].workTypeID}]}}
					
					var lookupService = {
				target: session.parameters.lookUpURL,
				method: 'POST',
				contentType: 'application/json',
				data: lookupmessage  
				};
				urlopen.open(lookupService, function(error, response) {
						if (error) {
							logger.error(" urlopen connect error with LookupServiceResponse  " + JSON.stringify(error));
							//session.reject(" urlopen connect error with LookupServiceResponse" + JSON.stringify(error));
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200 )  {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										logger.error(" error message from with LookupServiceResponse for " + JSON.stringify(error));
										//session.reject("error message from with LookupServiceResponse for " + JSON.stringify(error));
									} else {
										hm.response.statusCode = responseStatusCode;
										logger.debug("response received from LookupServiceResponse "+ responseStatusCode);			
										var lookupResponse = JSON.parse(responseData)
					
				//	logger.error("response"+LookupServiceResponse);		
					 var ctx = session.name("omsfoa")|| session.createContext("omsfoa");						
					if(lookupResponse.lookupRep.type[0].result==0){
						var label= lookupResponse.lookupRep.type[0].label;
						ctx.setVariable("assignmentStatus",label);
					}else{
						
					var	label="";
					ctx.setVariable("assignmentStatus",label);	
					}
				}
				});
				}
				}
				});
				
				
				
				
						
					}					}
					
					
	}
});
