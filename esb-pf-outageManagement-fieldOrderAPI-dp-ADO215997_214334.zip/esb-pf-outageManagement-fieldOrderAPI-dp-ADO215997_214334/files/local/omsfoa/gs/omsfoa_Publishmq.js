var ctx = session.name("omsfoa") || session.createContext("omsfoa");
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({'category': 'all'});
var urlIn = sm.getVar('var://service/URL-in');
var PublishMQURL = session.parameters.PublishMQURL;
session.input.readAsJSON(function(readAsJSONError, incommingdata){
	if (readAsJSONError){
		hm.response.statusCode = 500 ;
		session.output.write(readAsJSONError);
	} else {
			sentToQueue(PublishMQURL,incommingdata);
			session.output.write(incommingdata);
	}
});

function sentToQueue(targetQueue, incommingdata){
	var ctx = session.name("omsfoa") || session.createContext("omsfoa");
	var payload = incommingdata
	var correlationID = ctx.getVariable("correlationID");
	payload.messageID = correlationID;
	var options = {
			target : targetQueue,
			data : payload
	};
var info = " TargetURL :" + targetQueue + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";	
try {
	urlopen.open(options, function(error, response){
		var hm = require('header-metadata');
		if(error){
		//	logger.error(' Mqurlopen.open error');
			var ctx = session.name("omsfoa") || session.createContext("omsfoa");
			var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + error
			 ctx.setVariable("errormessage",errorinfo);
		ctx.setVariable("errorset", 'yes');
			session.reject('** Mqurlopen.open error');
			hm.response.statusCode = 500;
		} else {
			var mqrc = response.statusCode;
			if(mqrc == 0){
				response.readAsBuffer(function(readError, responseData){
					if(readError){
						hm.response.statusCode = 500
						var ctx = session.name("omsfoa") || session.createContext("omsfoa");
			var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + readError
			 ctx.setVariable("errormessage",errorinfo);
		ctx.setVariable("errorset", 'yes');
					//	logger.error(': Mqurlopen.open error')
					} else {
						console.log("MQResponseData "+ responseData);
					}
				});
			} else {
			//	logger.error(': ** Mqurlopen.open error [MQRC=' + mqrc + ']');
			var ctx = session.name("omsfoa") || session.createContext("omsfoa");
			var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + mqrc
			 ctx.setVariable("errormessage",errorinfo);
		     ctx.setVariable("errorset", 'yes');
				session.reject('** Mqurlopen.open error [MQRC=' + mqrc + ']');
				hm.response.statusCode = 500
			}
		}
	});
							}catch (err) {
							var ctx = session.name("omsfoa") || session.createContext("omsfoa");
							var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + err
							ctx.setVariable("errormessage", errorinfo);
							ctx.setVariable("errorset", 'yes');
							session.reject('** Mqurlopen.open error [MQRC=' + err + ']');

						}
}
