// js is used to perform oms call 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {
		
			
	// getting styleheet params
	var ctx = session.name("omsfoa")|| session.createContext("omsfoa");
	var omsExternalURL = session.parameters.omsExternalURL;
	var apiToken= session.parameters.osiApiToken;
var ctx = session.name("extPremise")|| session.createContext("extPremise");
ctx.setVariable("Incoming_Json_Payload", incomingdata);
var externalPremiseid = ctx.getVar("externalPremiseid");
		var externalPremiseID = externalPremiseid;
			if(externalPremiseid != '' || externalPremiseid != null || externalPremiseid != undefined ){
				if(externalPremiseid.length>0){
	var externalPremiseIDuri = omsExternalURL + '/api/v1/ServiceType/Electric/Premise/'+externalPremiseid;
			var TokenValue = apiToken;

			var externalPremiseIDapi = {
				target: externalPremiseIDuri,
				sslClientProfile: 'OMS_Client_Profile',
				method: 'GET',
				contentType: 'application/json',
				headers: {
					'osiApiToken': TokenValue
				},
				
			};


			urlopen.open(externalPremiseIDapi, function(error, response) {
				if (error) {
					logger.error(" urlopen connect error with GET externalPremiseIDapi with id as "+externalPremiseID+" " + JSON.stringify(error));
					session.reject("urlopen connect error with GET externalPremiseIDapi with id as "+externalPremiseID+" " + JSON.stringify(error));
				} else {
					// read response data
					// get the response status code
					var responseStatusCode = response.statusCode;
					if (responseStatusCode == 200 ){
						
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								logger.error(" error message while reading response from externalPremiseIDapi" + JSON.stringify(error));
								session.reject(" error message while reading response from externalPremiseIDapi" + JSON.stringify(error));
							} else {
								//store status code with response body in context variable
								hm.response.statusCode = responseStatusCode;
								hm.response.statusCode = responseStatusCode;
								logger.debug("response received from Callapi for externalPremiseIDapi:"+externalPremiseID+ "is :"+ responseStatusCode);			
								 var ctx = session.name("omsfoa")|| session.createContext("omsfoa");
								var externalPremiseIDapi_Response = JSON.parse(responseData);
							 ctx.setVariable("externalPremiseIDapi_Response", externalPremiseIDapi_Response);
					if(externalPremiseIDapi_Response.premiseServiceType != undefined){
						if(externalPremiseIDapi_Response.premiseServiceType.customFieldValuesExt != undefined){
							if(externalPremiseIDapi_Response.premiseServiceType.customFieldValuesExt.Service_Type != undefined){
								var Service_Type = JSON.parse(responseData).premiseServiceType.customFieldValuesExt.Service_Type;
								 ctx.setVariable("Service_Type", Service_Type);
							}}
							}
							}
						});
					
					
					}else if(responseStatusCode == 404 ){
						
						
					}else{
						response.readAsBuffer(function(error, responseData) {
							if (error) {
								//dp:reject stop the transaction and go error rule with error code and description
								logger.error("omsfoa_002 failure in reading message from  externalPremiseIDapi "+externalPremiseID+" is  " + JSON.stringify(error));
							  session.reject("failure in reading message from externalPremiseIDapi "+externalPremiseID+" is  "  + JSON.stringify(error));
							} else {
								
								logger.error(" Error returned from  externalPremiseIDapi "+externalPremiseID+" statusCode " + responseStatusCode+" "+ responseData);
								session.reject("Error returned from  externalPremiseIDapi "+externalPremiseID+" statusCode " + responseStatusCode+" "+ responseData);
				
					}
						});
						
					}
				}
			});	
			}else{
				logger.debug(" externalPremiseID is not present in payload");				
			}
			}else{
				logger.debug(" externalPremiseID is not present in payload");

				
			}
		 	
		
	}
	
});
