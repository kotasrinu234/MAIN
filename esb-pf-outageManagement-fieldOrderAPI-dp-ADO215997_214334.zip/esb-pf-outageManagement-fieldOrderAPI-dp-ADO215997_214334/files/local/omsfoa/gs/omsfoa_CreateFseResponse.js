// js is used to perform oms call 
var ctx = session.name("omsfoa") || session.createContext("omsfoa");
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingData) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject("Error in reading incoming data");
	} else {

		var urltype = sm.URLIn;
		var ExternalRefID;
		if (urltype.includes('/Create')) {
			if (incomingData.data[0].crew != undefined) {
				if (!(incomingData.data[0].crew.customFieldValuesExt == undefined || incomingData.data[0].crew.customFieldValuesExt == '' || incomingData.data[0].crew.customFieldValuesExt == null)) {
					if ((incomingData.data[0].crew.customFieldValuesExt.PSIsAssignedToOMS == undefined) || (incomingData.data[0].crew.customFieldValuesExt.PSIsAssignedToOMS == false)) {

						ExternalRefID = "OMS_" + incomingData.data[0].id + "_" + incomingData.data[0].job.id + '_'
						if (!(incomingData.data[0].job.leadCallID == undefined)) {
							ExternalRefID = ExternalRefID + incomingData.data[0].job.leadCallID
						}
						var crewID = '';

						if (!(incomingData.data[0].crew.customFieldValuesExt.employeeid == undefined)) {
							crewID = incomingData.data[0].crew.customFieldValuesExt.employeeid
						}


						var payload = {
							"FSM_EFO_Acknowledgement": {
								"ExternalRefID": ExternalRefID,
								"Action": "A",
								"Acknowledgement": "NegativeAcknowledge",
								"FSMObjectType": "Trouble",
								"ErrorDescription": "Failed to dispatch " + crewID + " since they are not assigned to OMS"
							}
						}

						session.output.write(payload);
						var PusingToQueue = {
							target: session.parameters.CreateCrewMQUrl,
							data: payload
						};
						var info = " TargetURL :" + session.parameters.CreateCrewMQUrl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
						try {
							urlopen.open(PusingToQueue, function(error, response) {
								var hm = require('header-metadata');
								if (error) {
									var mqconnection = 'Forbidden';
									ctx.setVariable("mqconnection", mqconnection);
									logger.error("  error while keeping payload  message to queue is " + error);
								var ctx = session.name("omsfoa") || session.createContext("omsfoa");
									var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + error
									ctx.setVariable("errormessage", errorinfo);
									ctx.setVariable("errorset", 'yes');
									session.reject(" error while keeping  message to queue is " + error);
								} else {
									var mqrc = response.statusCode;


									if (mqrc == 0) {
										var replyMQMD = response.get({
											type: 'mq'
										}, 'MQMD');
										var replyMQRFH2 = response.get({
											type: 'mq'
										}, 'MQRFH2');
										response.readAsBuffer(function(readError, responseData) {
											if (readError) {
												hm.response.statusCode = 500
											var ctx = session.name("omsfoa") || session.createContext("omsfoa");
												var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + readError
												ctx.setVariable("errormessage", errorinfo);
												ctx.setVariable("errorset", 'yes');
												session.reject(" error while keeping message    to queue is " + error);
											} else {
												logger.debug("MQResponsecode " + mqrc);
											}
										});
									} else {
										var ctx = session.name("omsfoa") || session.createContext("omsfoa");
										logger.error("  response code   urlopen.open error [MQRC=" + mqrc + "]");
										var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + mqrc
										ctx.setVariable("errormessage", errorinfo);
										ctx.setVariable("errorset", 'yes');
										session.reject(" response code  is urlopen.open error [MQRC=" + mqrc + "]");

									}
								}
							});
						}
						catch (err) {
							var ctx = session.name("omsfoa") || session.createContext("omsfoa");
							var errorinfo = "Mqurlopen connection error , details are : " + info + "; error info :" + "Error returned mq call " + err
							ctx.setVariable("errormessage", errorinfo);
							ctx.setVariable("errorset", 'yes');
                                                       session.reject(" response code  is urlopen.open error ");
						}
						//session.output.write(payload)
					}
				}
			}
		}
	}
});
