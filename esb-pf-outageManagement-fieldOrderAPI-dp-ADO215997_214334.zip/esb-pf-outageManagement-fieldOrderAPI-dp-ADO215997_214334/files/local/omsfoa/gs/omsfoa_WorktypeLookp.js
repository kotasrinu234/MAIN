var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
var ctx = session.name("omsfoa")|| session.createContext("omsfoa");
var action = sm.getVar('var://service/URI');
if(action.includes('/Update')){
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if(readAsJSONError) {
		logger.error("Error in reading incoming json data");
		session.reject(readAsJSONError);
	} else {
if(incomingdata.data[0].crewAssignments != undefined ){
	var crewAssignmentsfalse = []
	var crewAssignmentsblock={}
	var crewAssignments = incomingdata.data[0].crewAssignments;
	for(var i=0 ; i<crewAssignments.length;i++){
		  crewAssignmentsblock ={}
		if(crewAssignments[i].resolved == false){
			crewAssignmentsblock.workTypeID=crewAssignments[i].workTypeID
		}
		if(crewAssignmentsblock.workTypeID != undefined){
		crewAssignmentsfalse.push(crewAssignmentsblock);
			}
	}
	
var jsonObject = crewAssignmentsfalse.map(JSON.stringify);
            var uniqueSet = new Set(jsonObject);
            var uniqueArray = Array.from(uniqueSet).map(JSON.parse);
var arrayvalue =[]	
if(uniqueArray.length >0 )  {
		ctx.setVariable("IsResolved", 'false');
		for (var k=0;k< uniqueArray.length ; k++){
			var message ={
				"name": 'workTypes',
				"id": uniqueArray[k].workTypeID,
				"status":"none"
				}
							arrayvalue.push(message)		
				}
										var lookupMessage =	{"lookupReq": {"type": arrayvalue}}
var workTypesLookupServiceResponse = {
														target: session.parameters.lookUpURL,
														method: 'POST',
														contentType: 'application/json',
														data: lookupMessage
														};	

urlopen.open(workTypesLookupServiceResponse, function(error, response) {
			if (error) {
				logger.error(" urlopen connect error with Outage LookupServiceResponse" + JSON.stringify(error));
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							logger.error("failure in putting message to  workTypesLookupServiceResponse" + JSON.stringify(error));
						} else {
							hm.response.statusCode = responseStatusCode;
							logger.debug("response received from workTypesLookupServiceResponse " + JSON.stringify(responseData));
				var crewAssignments = incomingdata.data[0].crewAssignments;
				var responseDatapayload =responseData
							ctx.setVariable('workTypesLookupServiceResponse', responseDatapayload);
							var typeslength =responseDatapayload.lookupRep.type.length;
							var ohugFlag;
							var worktypeidEFO;
								for (var j=0;j<typeslength ; j++){
									if(responseData.lookupRep.type[j].label =='EFO'){
									worktypeidEFO = responseData.lookupRep.type[j].id	
} }
var worktypeidEFOCheck ;
	 for(var i=0 ; i<crewAssignments.length;i++){
		if((crewAssignments[i].resolved == false ) && (crewAssignments[i].workTypeID == worktypeidEFO)){
			worktypeidEFOCheck= 'yes'
			 var displayID = crewAssignments[i].displayID;
										ctx.setVariable("crewAssignmentsdisplayID", displayID);
										var crewAssignmentID = crewAssignments[i].id
										ctx.setVariable("crewAssignmentID", crewAssignmentID);
										break
		}				
			}
			if(worktypeidEFOCheck != 'yes')	{
												ctx.setVariable("IsResolved", 'true');
								sm.setVar('var://service/mpgw/skip-backside', true);
			}			
							}
							});
							}else{
								logger.error("lookup response code for worktypeid is "+responseStatusCode);
								session.reject("lookup response code for worktypeid is "+responseStatusCode);
							}
							}
							})
							}else{
								ctx.setVariable("IsResolved", 'true');
								sm.setVar('var://service/mpgw/skip-backside', true);
							}
}else{
								ctx.setVariable("IsResolved", 'true');
								sm.setVar('var://service/mpgw/skip-backside', true);
							}
	}
	});
	}