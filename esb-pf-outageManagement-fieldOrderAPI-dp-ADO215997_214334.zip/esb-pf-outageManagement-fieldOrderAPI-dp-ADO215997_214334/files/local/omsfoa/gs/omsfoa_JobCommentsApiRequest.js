//js recieve payload from fsm and update the oms api based on nack and ack 
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {

	// getting styleheet params
	var ctx = session.name("omsfoa") || session.createContext("omsfoa");
	var lookupURL = ctx.getVar("lookupURL");
	var omsExternalURL = ctx.getVar("omsExternalURL");
	var apiToken = ctx.getVar("apiToken");
	var ExternalRefIDCrewAssignmentID = ctx.getVar("ExternalRefIDCrewAssignmentID");
	var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
	var ExternalRefIDCallid = ctx.getVar("ExternalRefIDCallid");
	var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
	if (readAsJSONError) {
		logger.debug("omsfoa_059 Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {
		var action = incomingdata.FSM_EFO_Acknowledgement.Action;
		var action = action.toUpperCase();
		var now = new Date();
		var year = now.getFullYear();
		var month = now.getMonth() + 1;
		var month1 = month.toString();
		var strmonthlength = month1.length;
		var todaymonth;
		if (strmonthlength == 1) {
			todaymonth = '0' + month;
		} else {
			todaymonth = month;
		}

		var day = now.getDate();
		var day1 = day.toString();
		var strdaylength = day1.length;
		var todaydate;
		if (strdaylength == 1) {
			todaydate = '0' + day;
		} else {
			todaydate = day;
		}

		var hour = now.getHours();
		var todayhour = hour.toString();
		var strhourlength = todayhour.length;
		var todayhour;
		if (strhourlength == 1) {
			todayhour = '0' + hour;
		} else {
			todayhour = hour;
		}

		var minute = now.getMinutes();
		var todayminute = minute.toString();
		var strminutelength = todayminute.length;
		var todayminute;
		if (strminutelength == 1) {
			todayminute = '0' + minute;
		} else {
			todayminute = minute;
		}

		var second = now.getSeconds();
		var todaysecond = second.toString();
		var strsecondlength = todaysecond.length;
		var todaysecond;
		if (strsecondlength == 1) {
			todaysecond = '0' + todaysecond;
		} else {
			todaysecond = todaysecond;
		}

		var nowdate = year + '-' + todaymonth + '-' + todaydate;
		var nowtime = todayhour + ':' + todayminute + ':' + todaysecond;
		session.output.write(incomingdata)

		if (incomingdata.FSM_EFO_Acknowledgement.Acknowledgement == 'PositiveAcknowledge') {


			if (action == 'A') {
				// action A starts
				if (ExternalRefIDCrewAssignmentID != undefined || ExternalRefIDCrewAssignmentID != '' || ExternalRefIDCrewAssignmentID != null) {
					//Call GET/api/ServiceType/Electric/CrewAssignment/{id}
					var ExternalRefIDCrewAssignmentID = ctx.getVar("ExternalRefIDCrewAssignmentID");
					var CrewAssignmenturi = omsExternalURL + 'CrewAssignment/' + ExternalRefIDCrewAssignmentID;
					var TokenValue = apiToken;
					var CrewAssignmentapi = {
						target: CrewAssignmenturi,
						sslClientProfile: 'OMS_Client_Profile',
						method: 'GET',
						contentType: 'application/json',
						headers: {
							'osiApiToken': TokenValue
						},

					};
					var info = " TargetURL :" + CrewAssignmenturi + "; Method :" + 'GET';

					urlopen.open(CrewAssignmentapi, function(error, response) {
						if (error) {
							logger.error("omsfoa_007 urlopen connect error with CrewAssignmentapi get call for PositiveAcknowledge " + JSON.stringify(error));
							var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + "urlopen connect error with CrewAssignmentapi get call for PositiveAcknowledge " + JSON.stringify(error)
							ctx.setVariable("errormessage", errorinfo);
							ctx.setVariable("errorset", 'yes')
							session.reject(" urlopen connect error with CrewAssignmentapi get call for PositiveAcknowledge " + JSON.stringify(error));
						} else {
							// read response data
							// get the response status code
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {

								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										logger.error("omsfoa_022 failure in reading message from CrewAssignmentapi" + JSON.stringify(error));
										session.reject("failure in reading message from CrewAssignmentapi" + JSON.stringify(error));
									} else {
										//store status code with response body in context variable
										hm.response.statusCode = responseStatusCode;
										hm.response.statusCode = responseStatusCode;
										logger.debug("response received from CrewAssignmentapi for ExternalRefIDCrewAssignmentID:" + ExternalRefIDCrewAssignmentID + "is :" + responseStatusCode);
										var ctx = session.name("omsfoa") || session.createContext("omsfoa");
										var CrewAssignmentPayload = JSON.parse(responseData);
										var CrewAssignmentworkTypeId = JSON.parse(responseData).workTypeID;
										var CrewAssignmentStatus = JSON.parse(responseData).status;
										ctx.setVariable("CrewAssignmentPayload", responseData);
										ctx.setVariable("CrewAssignmentStatus", CrewAssignmentStatus);
										//lookup start
										var lookupMessage = {
											"lookupReq": {
												"type": [
													{
														"name": "workTypes.workflows",
														"status": CrewAssignmentStatus,
														"id": CrewAssignmentworkTypeId
													}
												]
											}
										}
										var ctx = session.name("omsfoa") || session.createContext("omsfoa");
										var lookupURL = ctx.getVar("lookupURL");
										var url = lookupURL;
										var LookupServiceResponse = {
											target: url,
											method: 'POST',
											contentType: 'application/json',
											data: lookupMessage
										};
										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												logger.error("omsfoa_013 urlopen connect error with CrewAssignmentworkTypeId lookup service for positive ack with action as A " + JSON.stringify(error));
												session.reject("urlopen connect error with CrewAssignmentworkTypeId lookup service for positive ack with action as A" + JSON.stringify(error));
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															logger.error("omsfoa_024 failure in getting message from  CrewAssignmentworkTypeId lookup service for positive ack with action as A " + JSON.stringify(error));
															session.reject("failure in getting message from  CrewAssignmentworkTypeId lookup service for positive ack with action as A " + JSON.stringify(error));
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response received from  LookupServiceResponse " + responseData);
															var lookupResponse = JSON.parse(responseData)
															if (lookupResponse.lookupRep.type[0].result == 0) {

																var crewTypeLabel = lookupResponse.lookupRep.type[0].label;
																var ctx = session.name("omsfoa") || session.createContext("omsfoa");
																ctx.setVariable("crewTypeLabel", crewTypeLabel);
																var LabelName;

																if (crewTypeLabel == 'Dispatched') {
																	LabelName = 'Dispatch Successful';
																} else {
																	LabelName = 'Request Successful';
																}
																// doing inner lookup start
																var InnerlookupMessage = {
																	"lookupReq": {
																		"type": [
																			{
																				"name": "workTypes.workflows",
																				"label": LabelName,
																				"id": CrewAssignmentworkTypeId
																			}
																		]
																	}
																}
																var test = InnerlookupMessage.lookupReq.type[0].label;
																ctx.setVariable('assignmentStatus', test)
																var ctx = session.name("omsfoa") || session.createContext("omsfoa");
																var lookupURL = ctx.getVar("lookupURL");
																var url = lookupURL;
																var InnerLookupServiceResponse = {
																	target: url,
																	method: 'POST',
																	contentType: 'application/json',
																	data: InnerlookupMessage
																};
																urlopen.open(InnerLookupServiceResponse, function(error, response) {
																	if (error) {
																		logger.error("omsfoa_015 urlopen connect error with CrewAssignmentworkTypeId labelname for postive ack with action as A is " + JSON.stringify(error));
																		session.reject("urlopen connect error with CrewAssignmentworkTypeId labelname for postive ack with action as A is " + JSON.stringify(error));
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					logger.error("omsfoa_025 failure in getting message from  CrewAssignmentworkTypeId labelname for postive ack with action as A is " + JSON.stringify(error));
																					session.reject(" failure in getting message from  CrewAssignmentworkTypeId labelname for postive ack with action as A is " + JSON.stringify(error));
																				} else {
																					hm.response.statusCode = responseStatusCode;
																					logger.debug("response received from  InnerLookupServiceResponse " + responseData);
																					var lookupResponse = JSON.parse(responseData)
																					if (lookupResponse.lookupRep.type[0].result == 0) {
																						var crewTypestatus = lookupResponse.lookupRep.type[0].status;
																						// api/v1/ServiceType/{sid}/CrewAssignment/{id}/WorkFlow
																						//start
																						var ctx = session.name("omsfoa") || session.createContext("omsfoa");
																						var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
																						var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
																						var ExternalRefIDCrewAssignmentID = ctx.getVar("ExternalRefIDCrewAssignmentID");
																						var joburl = omsExternalURLV1 + 'CrewAssignment/' + ExternalRefIDCrewAssignmentID + '/WorkFlow';
																						var TokenValue = apiToken;

																						var payload = {
																							"status": crewTypestatus
																						}

																						var CrewAssignmentWorkFlowapi = {
																							target: joburl,
																							sslClientProfile: 'OMS_Client_Profile',
																							method: 'POST',
																							contentType: 'application/json',
																							headers: {
																								'osiApiToken': TokenValue
																							},
																							data: payload
																						};
																						var info = " TargetURL :" + joburl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
																						urlopen.open(CrewAssignmentWorkFlowapi, function(error, response) {
																							if (error) {
																								logger.error("omsfoa_008 urlopen connect error with CrewAssignment workflow api for PositiveAcknowledge is " + JSON.stringify(error));
																								var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + "urlopen connect error with CrewAssignment workflow api for PositiveAcknowledge is " + JSON.stringify(error)
																								ctx.setVariable("errormessage", errorinfo);
																								ctx.setVariable("errorset", 'yes')
																								session.reject(" urlopen connect error with CrewAssignment workflow api for PositiveAcknowledge is " + JSON.stringify(error));
																							} else {
																								// read response data
																								// get the response status code
																								var responseStatusCode = response.statusCode;
																								if (responseStatusCode == 200) {

																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											//dp:reject stop the transaction and go error rule with error code and description
																											logger.error("omsfoa_026 failure in getting message to CrewAssignmentWorkFlowapi for PositiveAcknowledge " + JSON.stringify(error));
																											session.reject(" failure in getting message to CrewAssignmentWorkFlowapi for PositiveAcknowledge " + JSON.stringify(error));
																										} else {
																											//store status code with response body in context variable
																											hm.response.statusCode = responseStatusCode;
																											hm.response.statusCode = responseStatusCode;
																											logger.debug("response received from CrewAssignmentWorkFlowapi" + responseStatusCode);

																											//comments start 19th-june-2020

																											//POST /api/ServiceType/{sid}/Job/{id}/Comment

																											var ctx = session.name("omsfoa") || session.createContext("omsfoa");
																											var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
																											var omsExternalURL = ctx.getVar("omsExternalURL");
																											var RECEIVEON = ctx.getVar("RECEIVEON");
																											var joburl = omsExternalURL + 'Job/' + ExternalRefIDJobid + '/Comment';
																											var TokenValue = apiToken;
																											var errormessage = incomingdata.FSM_EFO_Acknowledgement.ErrorDescription;

																											//Comment Format: RECEIVED ON YYYY-MM-DD  AT HH:MM:SS
																											var payload = {
																												"comment": RECEIVEON + ' ' + nowdate + ' AT ' + nowtime
																											}

																											var JobCommentsapi = {
																												target: joburl,
																												sslClientProfile: 'OMS_Client_Profile',
																												method: 'POST',
																												contentType: 'application/text',
																												headers: {
																													'osiApiToken': TokenValue
																												},
																												data: payload
																											};
																											session.output.write(payload)
																											var info = " TargetURL :" + joburl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
																											urlopen.open(JobCommentsapi, function(error, response) {
																												if (error) {
																													logger.error("omsfoa_009 urlopen connect error with JobCommentsapi for PositiveAcknowledge  " + JSON.stringify(error));
																													var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + "urlopen connect error with JobCommentsapi for PositiveAcknowledge " + JSON.stringify(error)
																													ctx.setVariable("errormessage", errorinfo);
																													ctx.setVariable("errorset", 'yes')
																													session.reject(" urlopen connect error with JobCommentsapi for PositiveAcknowledge " + JSON.stringify(error));
																												} else {
																													// read response data
																													// get the response status code
																													var responseStatusCode = response.statusCode;
																													if (responseStatusCode == 200) {

																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																//dp:reject stop the transaction and go error rule with error code and description
																																logger.error("omsfoa_027 failure in reading message from JobCommentsapi for PositiveAcknowledge " + JSON.stringify(error));
																																session.reject(" failure in reading message from JobCommentsapi for PositiveAcknowledge " + JSON.stringify(error));
																															} else {
																																//store status code with response body in context variable
																																hm.response.statusCode = responseStatusCode;
																																hm.response.statusCode = responseStatusCode;
																																logger.debug("response received from JobCommentsapi" + responseStatusCode);
																															}
																														});
																													} else {
																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																logger.error("failure in reading message from Jobcommentsapi for positive ack " + JSON.stringify(error));
																																session.reject("failure in reading message from Jobcommentsapi for positive ack ");
																															} else {
																																logger.error("omsfoa_028 response received from Jobcommentsapi for positive ack " + responseStatusCode + " " + responseData);
																																var errorinfo = "urlopen response , details are : " + info + "; error info :" + "response received from Jobcommentsapi for positive ack " + responseStatusCode + " " + responseData
																																ctx.setVariable("errormessage", errorinfo);
																																ctx.setVariable("errorset", 'yes')
																																session.reject("response received from Jobcommentsapi for positive ack " + responseStatusCode + " " + responseData);


																															}
																														});
																													}
																												}

																											});
																											//end


																											//comments end
																										}
																									});
																								} else {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											//dp:reject stop the transaction and go error rule with error code and description
																											logger.error("failure in getting message from CrewAssignmentWorkFlowapi" + JSON.stringify(error));
																											session.reject("failure in getting message from CrewAssignmentWorkFlowapi for positive ack");
																										} else {
																											logger.error("omsfoa_029 response received from CrewAssignmentWorkFlowapi for positive ack " + responseStatusCode + " " + responseData);
																											var errorinfo = "urlopen response , details are : " + info + "; error info :" + "response received from CrewAssignmentWorkFlowapi for positive ack " + responseStatusCode + " " + responseData
																											ctx.setVariable("errormessage", errorinfo);
																											ctx.setVariable("errorset", 'yes')
																											session.reject(" response received from CrewAssignmentWorkFlowapi for positive ack " + responseStatusCode + " " + responseData);
																										}
																									});

																								}
																							}

																						});

																						//end


																					} else {

																						logger.error("omsfoa_16 CrewAssignmentworkTypeId labelname for postive ack with action as A is Result response is not 0");
																						session.reject(" CrewAssignmentworkTypeId labelname for postive ack with action as A is Result response is not 0");
																					}
																				}
																			});
																		}
																	}
																});
															} else {

																logger.error("omsfoa_14 from with CrewAssignmentworkTypeId lookup service for positive ack with action as A Result response is not 0");
																session.reject(" CrewAssignmentworkTypeId lookup service for positive ack with action as A Result response is not 0");
															}// lookup end;

														}
													});

												} else {

													logger.error("omsfoa_030 lookup service responsecode for positive ack " + responseStatusCode);
													session.reject("lookup service responsecode for positive ack  " + responseStatusCode);
												}
											}
										});
										//lookup end														
									}
								});


							} else {
								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										logger.error("failure in reading message CrewAssignmentapi" + JSON.stringify(error));
										session.reject("failure in reading message CrewAssignmentapi");
									} else {
										logger.error("omsfoa_031 Error returned from Callapi with for CrewAssignmentapi for positive ack " + ExternalRefIDCrewAssignmentID + " statusCode " + responseStatusCode + " " + responseData);
										var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + " Error returned from Callapi with for CrewAssignmentapi for positive ack  " + responseStatusCode + " " + responseData
										ctx.setVariable("errormessage", errorinfo);
										ctx.setVariable("errorset", 'yes')
										session.reject("Error returned from Callapi with for CrewAssignmentapi for positive ack  " + responseStatusCode + " " + responseData);
									}
								});
							}
						}
					});


				} else {
					logger.error("omsfoa_032 CrewAssignmentID is not present in ExternalRefenceID filed in positive ack");
					session.reject("CrewAssignmentID is not present in ExternalRefenceID filed in positive ack");
				}

				//action A ends
			} else if (action == 'C') {



				var ctx = session.name("omsfoa") || session.createContext("omsfoa");
				var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
				var omsExternalURL = ctx.getVar("omsExternalURL");
				var DELETEDFROM = ctx.getVar("DELETEDFROM");
				var joburl = omsExternalURL + 'Job/' + ExternalRefIDJobid + '/Comment';
				var TokenValue = apiToken;
				var errormessage = incomingdata.FSM_EFO_Acknowledgement.ErrorDescription;
				//Comment Format: RECEIVED ON YYYY-MM-DD  AT HH:MM:SS
				var payload = {
					"comment": DELETEDFROM + ' ' + nowdate + ' AT ' + nowtime
				}

				var JobCommentsapi = {
					target: joburl,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'POST',
					contentType: 'application/text',
					headers: {
						'osiApiToken': TokenValue
					},
					data: payload
				};
				session.output.write(payload)
				var info = " TargetURL :" + joburl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
				urlopen.open(JobCommentsapi, function(error, response) {
					if (error) {
						logger.error("omsfoa_009 urlopen connect error with JobCommentsapi for action C for PositiveAcknowledge  " + JSON.stringify(error));
						var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + "urlopen connect error with JobCommentsapi for action C for PositiveAcknowledge  " + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						ctx.setVariable("errorset", 'yes')
						session.reject(" urlopen connect error with JobCommentsapi for action C for PositiveAcknowledge  " + JSON.stringify(error));
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {

							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									logger.error("omsfoa_033 failure in reading message from JobCommentsapifor positive ack " + JSON.stringify(error));
									session.reject(" failure in reading message from JobCommentsapifor positive ack " + JSON.stringify(error));
								} else {
									//store status code with response body in context variable
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from JobCommentsapi " + responseStatusCode);
								}
							});
						} else {

							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									logger.error("failure in reading message from Jobcommentsapi for positive ack " + JSON.stringify(error));
									session.reject("failure in reading message from Jobcommentsapi for positive ack ");
								} else {
									logger.error("omsfoa_034 response received from Jobcommentsapi for positive ack " + responseStatusCode + " " + responseData);
									var errorinfo = "urlopen response , details are : " + info + "; error info :" + "response received from Jobcommentsapi for positive ack " + responseStatusCode + " " + responseData
									ctx.setVariable("errormessage", errorinfo);
									ctx.setVariable("errorset", 'yes')
									session.reject(" response received from Jobcommentsapi for positive ack " + responseStatusCode + " " + responseData);
								}
							});
						}
					}

				});
				//end


				//comments end


			} else {
				logger.debug('omsfoa_035 ACK received for action ' + action + ' from CLICK ON ' + nowdate + ' AT ' + nowtime);

			}

		} else if (incomingdata.FSM_EFO_Acknowledgement.Acknowledgement == 'NegativeAcknowledge') {
			//NegativeAcknowledge
			if (action == 'A') {
				if (ExternalRefIDCrewAssignmentID != undefined || ExternalRefIDCrewAssignmentID != '' || ExternalRefIDCrewAssignmentID != null) {
					//Call GET/api/ServiceType/Electric/CrewAssignment/{id}

					var CrewAssignmenturi = omsExternalURL + 'CrewAssignment/' + ExternalRefIDCrewAssignmentID;
					var TokenValue = apiToken;
					var CrewAssignmentapi = {
						target: CrewAssignmenturi,
						sslClientProfile: 'OMS_Client_Profile',
						method: 'GET',
						contentType: 'application/json',
						headers: {
							'osiApiToken': TokenValue
						},

					};

					var info = " TargetURL :" + CrewAssignmenturi + "; Method :" + 'GET';
					urlopen.open(CrewAssignmentapi, function(error, response) {
						if (error) {
							logger.error("omsfoa_010 urlopen connect error with CrewAssignmentapi for NegatveAck " + JSON.stringify(error));
							var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + "urlopen connect error with CrewAssignmentapi for NegatveAck " + JSON.stringify(error)
							ctx.setVariable("errormessage", errorinfo);
							ctx.setVariable("errorset", 'yes')
							session.reject(" urlopen connect error with CrewAssignmentapi for NegatveAck " + JSON.stringify(error));
						} else {
							// read response data
							// get the response status code
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200) {

								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										logger.error("omsfoa_036 failure in getting message from CrewAssignmentapi for NegatveAck " + JSON.stringify(error));
										session.reject(" failure in getting message from CrewAssignmentapi for NegatveAck " + JSON.stringify(error));
									} else {
										//store status code with response body in context variable
										hm.response.statusCode = responseStatusCode;
										hm.response.statusCode = responseStatusCode;
										logger.debug("response received from CrewAssignmentapi for ExternalRefIDCrewAssignmentID:" + ExternalRefIDCrewAssignmentID + "is :" + responseStatusCode);
										var ctx = session.name("omsfoa") || session.createContext("omsfoa");
										var CrewAssignmentPayload = JSON.parse(responseData);
										var CrewAssignmentworkTypeId = JSON.parse(responseData).workTypeID;
										var CrewAssignmentStatus = JSON.parse(responseData).status;
										ctx.setVariable("CrewAssignmentPayload", responseData);
										ctx.setVariable("CrewAssignmentworkTypeId", CrewAssignmentworkTypeId);
										ctx.setVariable("CrewAssignmentStatus", CrewAssignmentStatus);
										//{"lookupReq":{"type":[{"name":"workTypes.workflows","id":"5b6f07d5e45861646c06d95d","label":"Request Failed"}]}}
										logger.debug("crewapi repsonse negative is " + responseData);
										//lookup start
										var lookupMessage = {
											"lookupReq": {
												"type": [
													{
														"name": "workTypes.workflows",
														"status": CrewAssignmentStatus,
														"id": CrewAssignmentworkTypeId
													}
												]
											}
										}
										var ctx = session.name("omsfoa") || session.createContext("omsfoa");
										var lookupURL = ctx.getVar("lookupURL");
										var url = lookupURL;
										var LookupServiceResponse = {
											target: url,
											method: 'POST',
											contentType: 'application/json',
											data: lookupMessage
										};
										urlopen.open(LookupServiceResponse, function(error, response) {
											if (error) {
												logger.error("omsfoa_017 urlopen connect error with CrewAssignmentworkTypeId lookup status for negative ack with action A is " + JSON.stringify(error));
												session.reject("urlopen connect error with CrewAssignmentworkTypeId lookup status for negative ack with action A is " + JSON.stringify(error));
											} else {
												var responseStatusCode = response.statusCode;
												if (responseStatusCode == 200) {
													response.readAsBuffer(function(error, responseData) {
														if (error) {
															logger.error("omsfoa_037 failure in reading message to  LookupServiceResponse for negative ack" + JSON.stringify(error));
															session.reject(" failure in reading message to  LookupServiceResponse for negative ack" + JSON.stringify(error));
														} else {
															hm.response.statusCode = responseStatusCode;
															logger.debug("response received from  LookupServiceResponse " + responseData);
															var lookupResponse = JSON.parse(responseData)
															if (lookupResponse.lookupRep.type[0].result == 0) {

																var crewTypeLabel = lookupResponse.lookupRep.type[0].label;
																var ctx = session.name("omsfoa") || session.createContext("omsfoa");
																ctx.setVariable("crewTypeLabel", crewTypeLabel);

																var LabelName;

																if (crewTypeLabel == 'Dispatched') {
																	LabelName = 'Dispatch Failed';
																} else {
																	LabelName = 'Request Failed';
																}
																// doing inner lookup start
																var InnerlookupMessage = {
																	"lookupReq": {
																		"type": [
																			{
																				"name": "workTypes.workflows",
																				"label": LabelName,
																				"id": CrewAssignmentworkTypeId
																			}
																		]
																	}
																}
																var test = InnerlookupMessage.lookupReq.type[0].label;
																ctx.setVariable('assignmentStatus', test)
																var ctx = session.name("omsfoa") || session.createContext("omsfoa");
																var lookupURL = ctx.getVar("lookupURL");
																var url = lookupURL;
																var InnerLookupServiceResponse = {
																	target: url,
																	method: 'POST',
																	contentType: 'application/json',
																	data: InnerlookupMessage
																};
																urlopen.open(InnerLookupServiceResponse, function(error, response) {
																	if (error) {
																		logger.error("omsfoa_019 urlopen connect error with with CrewAssignmentworkTypeId labelname for negative ack with action as A is " + JSON.stringify(error));
																		session.reject("urlopen connect error with with CrewAssignmentworkTypeId labelname for negative ack with action as A is " + JSON.stringify(error));
																	} else {
																		var responseStatusCode = response.statusCode;
																		if (responseStatusCode == 200) {
																			response.readAsBuffer(function(error, responseData) {
																				if (error) {
																					logger.error("omsfoa_038 failure in putting message to  CrewAssignmentworkTypeId labelname for negative ack lookup " + JSON.stringify(error));
																					session.reject(" failure in putting message to  CrewAssignmentworkTypeId labelname for negative ack lookup " + JSON.stringify(error));
																				} else {
																					hm.response.statusCode = responseStatusCode;
																					logger.debug("response received from  InnerLookupServiceResponse " + responseData);
																					var lookupResponse = JSON.parse(responseData)
																					if (lookupResponse.lookupRep.type[0].result == 0) {
																						var crewTypestatus = lookupResponse.lookupRep.type[0].status;
																						// api/v1/ServiceType/{sid}/CrewAssignment/{id}/WorkFlow
																						//start
																						var ctx = session.name("omsfoa") || session.createContext("omsfoa");
																						var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
																						var omsExternalURLV1 = ctx.getVar("omsExternalURLV1");
																						var ExternalRefIDCrewAssignmentID = ctx.getVar("ExternalRefIDCrewAssignmentID");
																						var joburl = omsExternalURLV1 + 'CrewAssignment/' + ExternalRefIDCrewAssignmentID + '/WorkFlow';
																						var TokenValue = apiToken;
																						var payload = {
																							"status": crewTypestatus
																						}
																						var CrewAssignmentWorkFlowapi = {
																							target: joburl,
																							sslClientProfile: 'OMS_Client_Profile',
																							method: 'POST',
																							contentType: 'application/json',
																							headers: {
																								'osiApiToken': TokenValue
																							},
																							data: payload
																						};
																						var info = " TargetURL :" + joburl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
																						urlopen.open(CrewAssignmentWorkFlowapi, function(error, response) {
																							if (error) {
																								logger.error("omsfoa_011 urlopen connect error with CrewAssignment workflow api for NegativeACK " + JSON.stringify(error));
																								var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + " urlopen connect error with CrewAssignment workflow api for NegativeACK " + JSON.stringify(error)
																								ctx.setVariable("errormessage", errorinfo);
																								ctx.setVariable("errorset", 'yes')
																								session.reject(" urlopen connect error with CrewAssignment workflow api for NegativeACK " + JSON.stringify(error));
																							} else {
																								// read response data
																								// get the response status code
																								var responseStatusCode = response.statusCode;
																								if (responseStatusCode == 200) {

																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											//dp:reject stop the transaction and go error rule with error code and description
																											logger.error("omsfoa_039 failure in reading message to CrewAssignmentWorkFlowapi for negative ack " + JSON.stringify(error));
																											session.reject(" failure in reading message to CrewAssignmentWorkFlowapi for negative ack " + JSON.stringify(error));
																										} else {
																											//store status code with response body in context variable
																											hm.response.statusCode = responseStatusCode;
																											hm.response.statusCode = responseStatusCode;
																											logger.debug("response received from CrewAssignmentWorkFlowapi" + responseStatusCode);

																											//start
																											//POST /api/ServiceType/{sid}/Job/{id}/Comments

																											var ctx = session.name("omsfoa") || session.createContext("omsfoa");
																											var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
																											var omsExternalURL = ctx.getVar("omsExternalURL");
																											var joburl = omsExternalURL + 'Job/' + ExternalRefIDJobid + '/Comment';
																											var TokenValue = apiToken;

																											// NAK from Click on  <date YYYY-MM-DD> AT <time HH24:MM:SS> <ErrorDescription."Error Description from the payload">
																											var errormessage = incomingdata.FSM_EFO_Acknowledgement.ErrorDescription;
																											var errorcode = incomingdata.FSM_EFO_Acknowledgement.ErrorCode;
																											var NAKON = ctx.getVar("NAKON");
																											var commentmessage;

																											//*** NAK from Click on  YYYY-MM-DD AT time HH:MM:SS (Code:ErrorDescription.Error.$1)   ErrorDescription.Error.$2
																											commentmessage = NAKON + ' ' + nowdate + ' AT ' + nowtime;

																											if (errormessage != undefined) {

																												commentmessage = NAKON + ' ' + nowdate + ' AT ' + nowtime + ' ErrorDescription.Error.' + errormessage;
																											}

																											if (errorcode != undefined) {
																												commentmessage = NAKON + ' ' + nowdate + ' AT ' + nowtime + ' (Code:ErrorDescription.Error.' + errorcode + ')';

																											}

																											if (errormessage != undefined && errorcode != undefined) {

																												commentmessage = NAKON + ' ' + nowdate + ' AT ' + nowtime + ' (Code:ErrorDescription.Error.' + errorcode + ') ErrorDescription.Error.' + errormessage;
																											}
																											logger.debug("commentmessage is " + commentmessage);
																											var payload = {
																												"comment": commentmessage
																											}

																											var JobCommentsapi = {
																												target: joburl,
																												sslClientProfile: 'OMS_Client_Profile',
																												method: 'POST',
																												contentType: 'application/text',
																												headers: {
																													'osiApiToken': TokenValue
																												},
																												data: payload
																											};
																											session.output.write(payload)
																											var info = " TargetURL :" + joburl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
																											urlopen.open(JobCommentsapi, function(error, response) {
																												if (error) {
																													logger.error("omsfoa_012 urlopen connect error with JobCommentsapi for negativeACK with action A" + JSON.stringify(error));
																													var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + " urlopen connect error with JobCommentsapi for negativeACK with action A" + JSON.stringify(error)
																													ctx.setVariable("errormessage", errorinfo);
																													ctx.setVariable("errorset", 'yes')
																													session.reject(" urlopen connect error with JobCommentsapi for negativeACK with action A" + JSON.stringify(error));
																												} else {
																													// read response data
																													// get the response status code
																													var responseStatusCode = response.statusCode;
																													if (responseStatusCode == 200) {

																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																//dp:reject stop the transaction and go error rule with error code and description
																																logger.error("omsfoa_040 failure in getting message to JobCommentsapi for negative ack" + JSON.stringify(error));
																																session.reject("failure in getting message to JobCommentsapi for negative ack " + JSON.stringify(error));
																															} else {
																																//store status code with response body in context variable
																																hm.response.statusCode = responseStatusCode;
																																hm.response.statusCode = responseStatusCode;
																																logger.debug("response received from JobCommentsapi" + responseStatusCode);
																															}
																														});
																													} else {
																														response.readAsBuffer(function(error, responseData) {
																															if (error) {
																																//dp:reject stop the transaction and go error rule with error code and description
																																logger.error("failure in reading message from Jobcommentsapi for negative ack" + JSON.stringify(error));
																																session.reject("failure in reading message from Jobcommentsapi for negative ack");
																															} else {
																																logger.error("omsfoa_041 response received from Jobcommentsapi for negative ack " + responseStatusCode + " " + responseData);
																																var errorinfo = "urlopen repsonse , details are : " + info + "; error info :" + " response received from Jobcommentsapi for negative ack " + responseStatusCode + " " + responseData
																																ctx.setVariable("errormessage", errorinfo);
																																ctx.setVariable("errorset", 'yes')
																																session.reject("response received from Jobcommentsapi for negative ack " + responseStatusCode + " " + responseData);

																															}
																														});
																													}
																												}

																											});
																											//end											

																										}
																									});
																								} else {
																									response.readAsBuffer(function(error, responseData) {
																										if (error) {
																											//dp:reject stop the transaction and go error rule with error code and description
																											logger.error("failure in reading message from CrewAssignmentWorkFlowapi for negative ack" + JSON.stringify(error));
																											session.reject("failure in reading message from CrewAssignmentWorkFlowapi for negative ack");
																										} else {
																											logger.error("omsfoa_042 response received from CrewAssignmentWorkFlowapi for negative ack " + responseStatusCode + " " + responseData);
																											var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + " response received from CrewAssignmentWorkFlowapi for negative ack " + responseStatusCode + " " + responseData
																											ctx.setVariable("errormessage", errorinfo);
																											ctx.setVariable("errorset", 'yes')
																											session.reject(" response received from CrewAssignmentWorkFlowapi for negative ack " + responseStatusCode + " " + responseData);

																										}
																									});
																								}
																							}

																						});



																					} else {

																						logger.error("omsfoa_20 CrewAssignmentworkTypeId  for negative ack with action as A is Result response is not 0");
																						session.reject(" CrewAssignmentworkTypeId  for negative ack with action as A is Result response is not 0");
																					}
																				}
																			});
																		}
																	}
																});
																//doing inner lookup ends
																//end
															} else {

																logger.error("omsfoa_018 CrewAssignmentworkTypeId lookup status for negative ack with action A  Result from lookup  response is not 0");
																session.reject("CrewAssignmentworkTypeId lookup status for negative ack with action A Result from lookup  response is not 0");
															}// lookup end;

														}
													});

												} else {

													logger.error("omsfoa_043 lookup service responsecode for negative ack " + responseStatusCode);
													session.reject(" lookup service responsecode for negative ack " + responseStatusCode);
												}
											}
										});





										//lookup end




									}
								});


							} else {

								response.readAsBuffer(function(error, responseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										logger.error("failure in reading message from Callapi with for CrewAssignmentapi" + JSON.stringify(error));
										session.reject("failure in reading message from Callapi with for CrewAssignmentapi");
									} else {
										logger.error("omsfoa_044 Error returned from Callapi with for CrewAssignmentapi " + ExternalRefIDCrewAssignmentID + " for negative ack statusCode " + responseStatusCode + " " + responseData);
										var errorinfo = "urlopen response , details are : " + info + "; error info :" + "Error returned from Callapi with for CrewAssignmentapi" + responseStatusCode + " " + responseData
										ctx.setVariable("errormessage", errorinfo);
										ctx.setVariable("errorset", 'yes')
										session.reject("Error returned from Callapi with for CrewAssignmentapi" + responseStatusCode + " " + responseData);

									}
								});
							}
						}
					});


				} else {
					logger.error("omsfoa_045 CrewAssignmentID is not present in ExternalRefenceID filed for negative ack");
					session.reject("CrewAssignmentID is not present in ExternalRefenceID filed for negative ack");
				}


				//
			} else if (action == 'C') {



				var ctx = session.name("omsfoa") || session.createContext("omsfoa");
				var ExternalRefIDJobid = ctx.getVar("ExternalRefIDJobid");
				var omsExternalURL = ctx.getVar("omsExternalURL");
				var NAkFAILEDTO = ctx.getVar("NAkFAILEDTO");
				var joburl = omsExternalURL + 'Job/' + ExternalRefIDJobid + '/Comment';
				var TokenValue = apiToken;



				var payload = {
					"comment": NAkFAILEDTO + ' ' + nowdate + ' AT ' + nowtime
				}

				var JobCommentsapi = {
					target: joburl,
					sslClientProfile: 'OMS_Client_Profile',
					method: 'POST',
					contentType: 'application/text',
					headers: {
						'osiApiToken': TokenValue
					},
					data: payload
				};
				session.output.write(payload)
				var info = " TargetURL :" + joburl + "; Method :" + 'POST' + "; Data :" + JSON.stringify(payload) + ". ";
				urlopen.open(JobCommentsapi, function(error, response) {
					if (error) {
						logger.error("omsfoa_012 urlopen connect error with JobCommentsapi for negativeACK for action C" + JSON.stringify(error));
						var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + " urlopen connect error with JobCommentsapi for negativeACK for action C" + JSON.stringify(error)
						ctx.setVariable("errormessage", errorinfo);
						ctx.setVariable("errorset", 'yes')
						session.reject(" urlopen connect error with JobCommentsapi for negativeACK for action C" + JSON.stringify(error));
					} else {
						// read response data
						// get the response status code
						var responseStatusCode = response.statusCode;
						if (responseStatusCode == 200) {

							response.readAsBuffer(function(error, responseData) {
								if (error) {
									//dp:reject stop the transaction and go error rule with error code and description
									logger.error("omsfoa_046 failure in reading message to JobCommentsapi for negative ack " + JSON.stringify(error));
									session.reject(" failure in reading message to JobCommentsapi for negative ack " + JSON.stringify(error));
								} else {
									//store status code with response body in context variable
									hm.response.statusCode = responseStatusCode;
									hm.response.statusCode = responseStatusCode;
									logger.debug("response received from JobCommentsapi" + responseStatusCode);
								}
							});
						} else {
							response.readAsBuffer(function(error, responseData) {
								if (error) {

									//dp:reject stop the transaction and go error rule with error code and description
									logger.error("failure in reading message from Jobcommentsapi for negative ack " + JSON.stringify(error));
									session.reject("failure in reading message from Jobcommentsapi for negative ack ");
								} else {
									logger.error("omsfoa_047 response received from Jobcommentsapi for negative ack " + responseStatusCode + " " + responseData);
									var errorinfo = "urlopen connection error , details are : " + info + "; error info :" + " response received from Jobcommentsapi for negative ack " + responseStatusCode + " " + responseData
									ctx.setVariable("errormessage", errorinfo);
									ctx.setVariable("errorset", 'yes')
									session.reject("response received from Jobcommentsapi for negative ack " + responseStatusCode + " " + responseData);
								}
							});
						}
					}

				});
				//end											


			} else {
				logger.debug("omsfoa_048 NACK received for action " + action + " from CLICK ON " + nowdate + ' AT ' + nowtime);
			}
		}



	}
});
