// js is used to read the stylesheet param and set the context variables
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	} else {

var ctx = session.name("omsfoa")|| session.createContext("omsfoa");
//set stylesheet parameters to variable
var lookupURL = session.parameters.lookUpURL;
var omsExternalURL = session.parameters.omsExternalURL;

var apiToken = session.parameters.osiApiToken;
var ILSServerUrl = session.parameters.ILSServerUrl;
var ILSServerlogging = session.parameters.ILSServerlogging;
var DELETEDFROM = session.parameters.DELETEDFROM;
var RECEIVEON = session.parameters.RECEIVEON;
var NAKON = session.parameters.NAKON;
var NAkFAILEDTO = session.parameters.NAkFAILEDTO;

var omsExternalURLV1 = omsExternalURL+"/api/v1/ServiceType/Electric/";
var omsExternalURL= omsExternalURL+"/api/ServiceType/Electric/";
//var streamuri =session.parameters.streamuri;
//set the retrieved stylesheet parameters to context variables to use it within the urlopenUtil.js
ctx.setVariable("lookupURL", lookupURL);
ctx.setVariable("omsExternalURL", omsExternalURL);
ctx.setVariable("omsExternalURLV1", omsExternalURLV1);
ctx.setVariable("apiToken", apiToken);
ctx.setVariable("ILSServerUrl", ILSServerUrl);
ctx.setVariable("ILSServerlogging", ILSServerlogging);
ctx.setVariable("RECEIVEON", RECEIVEON);
ctx.setVariable("DELETEDFROM", DELETEDFROM);
ctx.setVariable("NAKON", NAKON);
ctx.setVariable("NAkFAILEDTO", NAkFAILEDTO);
//ctx.setVariable("streamuri",streamuri);
}
});
