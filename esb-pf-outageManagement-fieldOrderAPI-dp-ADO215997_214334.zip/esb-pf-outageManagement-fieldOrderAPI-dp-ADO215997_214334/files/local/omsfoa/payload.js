var sm = require('service-metadata');
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});
session.input.readAsBuffer(function(error, buffer) {
	if (error) {
		session.reject("Unexpected error in readAsJSON(): " + error);
		return;
	}else{
	var ctx1 = session.name('omsfoa') || session.createContext('omsfoa');
	var ctx = session.name('myContext') || session.createContext('myContext');
	ctx.setVar("inputData", buffer.toString());
	var errorDescription = ctx1.getVariable('errormessage');
		var errorset = ctx1.getVariable('errorset');
		if(errorset == 'yes'){
			ctx1.setVariable('errorDescription', errorDescription);
		}else{
			var message = sm.getVar('var://service/error-message')
			ctx1.setVariable('errorDescription', message);
		}
}
   	
});
