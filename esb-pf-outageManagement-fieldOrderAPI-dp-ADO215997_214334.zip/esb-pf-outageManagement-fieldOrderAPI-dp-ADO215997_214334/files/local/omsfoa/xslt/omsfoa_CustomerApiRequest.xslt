<!-- Xslt is used to perform a GET operation on oms customer api  -->
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"

	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">

		<xsl:param name="dpconfig:osiApiToken"/>	
		<xsl:param name="dpconfig:omsExternalURL"/>
		
	<xsl:template match="/">
	
	<xsl:variable name="TransactoinID">
	<xsl:copy-of
					select="dp:variable('var://service/global-transaction-id')" />
	</xsl:variable>
	

		<xsl:variable name="CallApiRequest">
			<xsl:copy-of
				select="dp:variable('var://context/CallApiResponseJsonX')" />
		</xsl:variable>
		<xsl:variable name="Input">
				<xsl:copy-of
					select="dp:variable('var://context/DP_Var1')" />
			</xsl:variable>
			

		<xsl:variable name="CustomerID">
		<xsl:choose>
			<xsl:when test="string-length(normalize-space($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='customerID']/text()))&gt; 0">
		<xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='customerID']/text()"/>
	</xsl:when>
	<xsl:otherwise>
			<xsl:value-of
				select="$CallApiRequest/*[local-name()='object']/*[local-name()='string'][@name='customerID']/text()" />
		</xsl:otherwise>
		</xsl:choose>
		</xsl:variable>

				<xsl:variable name="headerValues">

			  <header name="Content-Type">application/json</header>
            <header name="osiApiToken"><xsl:value-of select="$dpconfig:osiApiToken"/></header> 
       
		</xsl:variable>

		<!-- api/Customer/{id} -->
		<xsl:variable name="url">
			<xsl:value-of
				select="concat($dpconfig:omsExternalURL,'/api/Customer/',$CustomerID)" />
		</xsl:variable>

<xsl:choose>
<xsl:when test="string-length(normalize-space($CustomerID))>0">
		<xsl:variable name="CustomerApi">
			<dp:url-open target="{$url}"
				ssl-proxy="client:OMS_Client_Profile" http-headers="$headerValues"
				http-method="get" response="responsecode-binary">
			</dp:url-open>
		</xsl:variable>
		<xsl:variable name="responseCode">
			<xsl:value-of select="$CustomerApi/result/responsecode" />
		</xsl:variable>
			<dp:set-variable name="'var://context/CustomerAPIResponseCode'" value="$responseCode" />
	
		<xsl:choose>
			<xsl:when test="$responseCode='200'">
				<xsl:variable name="CustomerApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($CustomerApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:copy-of select="$CustomerApiResponse" />
				 <xsl:message dp:type="all" dp:priority="info">-------customerapiResponse
				<xsl:value-of select="$CustomerApiResponse"/> </xsl:message>
			</xsl:when>
			
			<xsl:when test="$responseCode='404'">
				<xsl:variable name="CustomerApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($CustomerApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:copy-of select="'{}'" />
				 <xsl:message dp:type="all" dp:priority="info">-------customerapiResponse
				<xsl:copy-of select="$CustomerApiResponse"/> </xsl:message>
			</xsl:when>
			<xsl:otherwise>
			
				<xsl:choose>
				<xsl:when test="string-length(normalize-space($responseCode))&gt; 0">
				<xsl:variable name="CustomerApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($CustomerApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				
				<xsl:message dp:type="all" dp:priority="error">omsfoa_055 TransactionID:<xsl:value-of select="$TransactoinID"/> Customer API Call Response code:<xsl:value-of select="$responseCode"/> for customerID:<xsl:value-of select="$CustomerID"/> and reason is <xsl:value-of select="$CustomerApiResponse" /></xsl:message>
		        <dp:reject>TransactionID:<xsl:value-of select="$TransactoinID"/> Customer API Call Response code:<xsl:value-of select="$responseCode"/> for customerID:<xsl:value-of select="$CustomerID"/> and reason is <xsl:value-of select="$CustomerApiResponse" /></dp:reject>
				</xsl:when>
				<xsl:otherwise>
				<xsl:variable name="errorstatuscode">
			<xsl:value-of select="$CustomerApi/result/errorstatuscode" />
		</xsl:variable>
		<xsl:variable name="errorstring">
			<xsl:value-of select="$CustomerApi/result/errorstring" />
		</xsl:variable>
		
		<xsl:message dp:type="all" dp:priority="error">omsfoa_004 TransactionID:<xsl:value-of select="$TransactoinID"/> Customer API Call Response for customerID:<xsl:value-of select="$CustomerID"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></xsl:message>
		        <dp:reject>TransactionID:<xsl:value-of select="$TransactoinID"/> Customer API Call Response for customerID:<xsl:value-of select="$CustomerID"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></dp:reject>
				</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>	
		</xsl:when>		
	<xsl:otherwise>
	
		<xsl:message dp:type="all" dp:priority="debug">omsfoa_056 TransactionID:<xsl:value-of select="$TransactoinID"/> Customer API is not Invoked(No CustomerID present in OMS request or CallAPI response)</xsl:message>
		
		<dp:set-variable name="'var://context/CustomerAPIResponseCode'" value="'404'" />
	<xsl:copy-of select="'{}'" />
	</xsl:otherwise>
</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
