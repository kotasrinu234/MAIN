<!-- Xslt is used to perform a GET operation on oms comment api and get list of comments -->
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
		xmlns:dpconfig="http://www.datapower.com/param/config"

	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	
			<xsl:param name="dpconfig:osiApiToken"/>	
		<xsl:param name="dpconfig:omsExternalURL"/>

	<xsl:template match="/">
	
	<xsl:variable name="TransactoinID">
	<xsl:copy-of
					select="dp:variable('var://service/global-transaction-id')" />
	</xsl:variable>
	

		<xsl:variable name="InPutMessage">
			<xsl:copy-of
				select="dp:variable('var://context/DP_Var1')" />
		</xsl:variable>

			<xsl:variable name="actions">
						<xsl:copy-of select="dp:variable('var://service/URI')" />
		</xsl:variable>
		
		<xsl:variable name="JobID">
				<xsl:choose>
	
		<xsl:when test="contains($actions,'/Update/' )">
		<xsl:value-of
				select="$InPutMessage/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='id']/text()" />
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of
				select="$InPutMessage/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='id']/text()" />
	
		</xsl:otherwise>
		</xsl:choose>
			</xsl:variable>
		<xsl:variable name="headerValues">

			  <header name="Content-Type">application/json</header>
            <header name="osiApiToken"><xsl:value-of select="$dpconfig:osiApiToken"/></header> 
       
		</xsl:variable>

		<!-- /api/ServiceType/{sid}/Job/{id}/Comment -->
		<xsl:variable name="url">
			<xsl:value-of
				select="concat($dpconfig:omsExternalURL,'/api/ServiceType/Electric/Job/',$JobID,'/Comment?includeFields=comment,updatedAt,createdByUserID,createdByUserName,updatedByUserName')" />
		</xsl:variable>

<xsl:choose>
<xsl:when test="string-length(normalize-space($JobID))>0">
		<xsl:variable name="JobCommentApi">
			<dp:url-open target="{$url}"
				ssl-proxy="client:OMS_Client_Profile" http-headers="$headerValues"
				http-method="get" response="responsecode-binary">
			</dp:url-open>
		</xsl:variable>
		<xsl:variable name="responseCode">
			<xsl:value-of select="$JobCommentApi/result/responsecode" />
		</xsl:variable>
		<dp:set-variable name="'var://context/CommentsAPIResponseCode'" value="$responseCode" />
		
		<xsl:choose>
					<xsl:when test="$responseCode='200'">
				<xsl:variable name="JobCommentApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($JobCommentApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:copy-of select="$JobCommentApiResponse" />
				<xsl:message dp:type="all" dp:priority="info">-------CommentsResponse
				<xsl:value-of select="$JobCommentApiResponse"/> </xsl:message>	
			</xsl:when>
			
			<xsl:when test="$responseCode='404'">
				<xsl:variable name="JobCommentApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($JobCommentApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:copy-of select="'{}'" />
				<xsl:message dp:type="all" dp:priority="info">-------CommentsResponse
				<xsl:copy-of select="$JobCommentApiResponse"/> </xsl:message>	
			</xsl:when>
			<xsl:otherwise>
			<xsl:choose>
				<xsl:when test="string-length(normalize-space($responseCode))&gt; 0">
				
				<xsl:variable name="JobCommentApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($JobCommentApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
			<xsl:message dp:type="all" dp:priority="error">omsfoa_053 TransactionID :<xsl:value-of select="$TransactoinID"/>JobComments API  Call Response code:<xsl:value-of select="$responseCode"/> for JobId :<xsl:value-of select="$JobID"/>  and reason is <xsl:value-of select="$JobCommentApiResponse" /> </xsl:message>
			<dp:reject>TransactionID :<xsl:value-of select="$TransactoinID"/>Job comments Call Response code:<xsl:value-of select="$responseCode"/> for JobId :<xsl:value-of select="$JobID"/>  and reason is <xsl:value-of select="$JobCommentApiResponse" /></dp:reject>	
				</xsl:when>
				<xsl:otherwise>
				<xsl:variable name="errorstatuscode">
			<xsl:value-of select="$JobCommentApi/result/errorstatuscode" />
		</xsl:variable>
		<xsl:variable name="errorstring">
			<xsl:value-of select="$JobCommentApi/result/errorstring" />
		</xsl:variable>
		
			<xsl:message dp:type="all" dp:priority="error">omsfoa_005 TransactionID :<xsl:value-of select="$TransactoinID"/>Job API comments Call Response for JobId :<xsl:value-of select="$JobID"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></xsl:message>
			<dp:reject>TransactionID :<xsl:value-of select="$TransactoinID"/>Job comments Call Response for JobId :<xsl:value-of select="$JobID"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></dp:reject>	
				</xsl:otherwise>
				</xsl:choose>
			

			</xsl:otherwise>
		</xsl:choose>
		</xsl:when>
		<xsl:otherwise>
		<xsl:message dp:type="all" dp:priority="debug">omsfoa_054 TransactionID :<xsl:value-of select="$TransactoinID"/>JobComments API is not invoked(JobId is not present in OMS Input request) </xsl:message>
		
		<dp:set-variable name="'var://context/CommentsAPIResponseCode'" value="'404'" />
		<xsl:copy-of select="'{}'" />
		</xsl:otherwise>
</xsl:choose>
		
	</xsl:template>
</xsl:stylesheet>
