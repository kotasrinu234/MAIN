<!-- xslt is used to invoke the GET operation for Premise api call and get the response -->
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
		xmlns:dpconfig="http://www.datapower.com/param/config"
	

	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
		<xsl:param name="dpconfig:omsExternalURL"/>
		<xsl:param name="dpconfig:osiApiToken"/>
		<xsl:output method="xml" indent="yes" omit-xml-declaration="yes" />
	<xsl:template match="/">

<xsl:variable name="TransactionID">
	<xsl:copy-of
		 select="dp:variable('var://service/global-transaction-id')" />
	</xsl:variable>
	
		<xsl:variable name="CallApiJsonX">
			<xsl:copy-of
				select="dp:variable('var://context/CallApiResponseJsonX')" />
		</xsl:variable>
		
		<xsl:variable name="Input">
			<xsl:copy-of
				select="dp:variable('var://context/DP_Var1')" />
		</xsl:variable>

<xsl:variable name="id">
					<xsl:value-of
						select="$CallApiJsonX/*[local-name()='object']/*[local-name()='string'][@name='displayID']/text()" />
</xsl:variable>
<dp:set-variable name="'var://context/CallId'" value="$id" />

<xsl:variable name="TimeStamp">
<xsl:value-of select="date:date-time()"/>
</xsl:variable>		
		


		<xsl:variable name="externalPremiseid">
					<xsl:value-of
				select="$CallApiJsonX/*[local-name()='object']/*[local-name()='string'][@name='externalPremiseID']/text()" />
		</xsl:variable>
		
		
		<dp:set-variable name="'var://context/extPremise/externalPremiseid'" value="string($externalPremiseid)" />
		<xsl:variable name="headerValues">
			<header name="Content-Type">application/json</header>
			<header name="osiApiToken">
				<xsl:value-of
					select="$dpconfig:osiApiToken"/>
			</header>
		</xsl:variable>

		<!-- api/Premise/{id} -->
		<xsl:variable name="url">
			<xsl:value-of
				select="concat($dpconfig:omsExternalURL,'/api/Premise/',$externalPremiseid)" />
		</xsl:variable>
<xsl:choose>
<xsl:when test="string-length(normalize-space($externalPremiseid))>0">
		<xsl:variable name="PremiseApi">
			<dp:url-open target="{$url}"
				ssl-proxy="client:OMS_Client_Profile" http-headers="$headerValues"
				http-method="get" response="responsecode-binary">
			</dp:url-open>
		</xsl:variable>
		<xsl:variable name="responseCode">
			<xsl:value-of select="$PremiseApi/result/responsecode" />
		</xsl:variable>

		<dp:set-variable
			name="'var://context/PremiseCallResponseCode'" value="$responseCode" />

		<xsl:choose>
			<xsl:when test="$responseCode='200'">
				<xsl:variable name="PremiseApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($PremiseApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:copy-of select="$PremiseApiResponse" />

			</xsl:when>
			<xsl:when test="$responseCode='404'">
				<xsl:variable name="PremiseApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($PremiseApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:copy-of select="'{}'" />
				<xsl:message dp:type="all" dp:priority="info">
					-------callpremiseResponse
					<xsl:value-of select="$PremiseApiResponse" />
				</xsl:message>

			</xsl:when>
			<xsl:otherwise>
					<xsl:choose>
				<xsl:when test="string-length(normalize-space($responseCode))&gt; 0">
				
				<xsl:variable name="PremiseApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($PremiseApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:message dp:type="all" dp:priority="error">omsfoa_051 TransactionID :<xsl:value-of select="$TransactionID"/> Premise Call Response code: <xsl:value-of select="$responseCode"/> for ExternalPrimseid: <xsl:value-of select="$externalPremiseid"/> and reason is <xsl:value-of select="$PremiseApiResponse" /></xsl:message>
			<dp:reject>TransactionID :<xsl:value-of select="$TransactionID"/> Premise Call Response code: <xsl:value-of select="$responseCode"/> for ExternalPrimseid: <xsl:value-of select="$externalPremiseid"/> and reason is <xsl:value-of select="$PremiseApiResponse" />
				</dp:reject>
				</xsl:when>
				<xsl:otherwise>
				<xsl:variable name="errorstatuscode">
			<xsl:value-of select="$PremiseApi/result/errorstatuscode" />
		</xsl:variable>
		<xsl:variable name="errorstring">
			<xsl:value-of select="$PremiseApi/result/errorstring" />
		</xsl:variable>
				
		<xsl:message dp:type="all" dp:priority="error">omsfoa_002 TransactionID :<xsl:value-of select="$TransactionID"/> Premise Call Response for ExternalPrimseid: <xsl:value-of select="$externalPremiseid"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></xsl:message>
			<dp:reject>TransactionID :<xsl:value-of select="$TransactionID"/> Premise Call Response code for ExternalPrimseid: <xsl:value-of select="$externalPremiseid"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></dp:reject>
				</xsl:otherwise>
				</xsl:choose>
				</xsl:otherwise>
		</xsl:choose>
		</xsl:when>
		<xsl:otherwise>
<xsl:message dp:type="all" dp:priority="debug">omsfoa_052 TransactionID :<xsl:value-of select="$TransactionID"/> PremiseCAll API is not Invoked(ExternalPremiseID is not present in Call API response)</xsl:message>	
			
		<xsl:copy-of select="'{}'" />
		<dp:set-variable
			name="'var://context/PremiseCallResponseCode'" value="404" />
		
		</xsl:otherwise>
</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
