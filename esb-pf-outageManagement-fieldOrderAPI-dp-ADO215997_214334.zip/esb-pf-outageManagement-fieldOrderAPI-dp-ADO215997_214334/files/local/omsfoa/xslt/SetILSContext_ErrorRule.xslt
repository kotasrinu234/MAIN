<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpquery="http://www.datapower.com/param/query"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:regexp="http://exslt.org/regular-expressions"
	extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ser="http://dteco.com/DeviceManagement/ServiceOrder"
	version="1.0">
	<xsl:variable name="Delimiter" select="'_'" />
	<xsl:template
		match="/">


		<xsl:variable name="Input">
			<xsl:copy-of
				select="dp:variable('var://context/DP_Var1')" />
		</xsl:variable>

		<xsl:variable name="actions">
			<xsl:copy-of select="dp:variable('var://service/URI')" />
		</xsl:variable>
		<xsl:variable name="ACTION">
			<xsl:choose>
				<xsl:when test="contains($actions, '/Create/')">
					<xsl:value-of select="'A'" />
				</xsl:when>

				<xsl:when test="contains($actions, '/Update/')">
					<xsl:value-of select="'U'" />
				</xsl:when>

				<xsl:when test="contains($actions, '/Cancel/')">
					<xsl:value-of select="'C'" />
				</xsl:when>

				<xsl:when test="contains($actions, '/Preempt/')">
					<xsl:value-of select="'P'" />
				</xsl:when>
			</xsl:choose>
		</xsl:variable>

		<xsl:variable name="JobDisplayID">
			<xsl:value-of
				select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='jobDisplayID']/text()" />
		</xsl:variable>

		<xsl:variable name="CrewAssignmentDisplayId">
			<xsl:value-of
				select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='displayID']/text()" />
		</xsl:variable>
	<xsl:variable name="CallID">		
	<xsl:choose>
		<xsl:when
 			test="string-length(normalize-space($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='leadCallDisplayID']/text()))&gt; 0">
			<xsl:value-of
				select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='leadCallDisplayID']/text()" />	
		</xsl:when>
		<xsl:otherwise>	
			<xsl:value-of
				select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='array'][@name='calls']/*[local-name()='object']/*[local-name()='string'][@name='displayID']/text()" />
		</xsl:otherwise>
		</xsl:choose>
				</xsl:variable>	
		<xsl:variable name="TimeStamp">
			<xsl:value-of select="date:date-time()"/>
		</xsl:variable>

		<xsl:call-template name="set_ILS_Context">
			<xsl:with-param name="ACTION" select="$ACTION" />
			<xsl:with-param name="JobDisplayID" select="$JobDisplayID" />
			<xsl:with-param name="CrewAssignmentDisplayId" select="$CrewAssignmentDisplayId" />
			<xsl:with-param name="CallID" select="$CallID" />
			<xsl:with-param name="TimeStamp" select="$TimeStamp" />
			</xsl:call-template>
	</xsl:template>

	<xsl:template name="set_ILS_Context">
		<xsl:param name="ACTION" />
		<xsl:param name="JobDisplayID" />
		<xsl:param name="CrewAssignmentDisplayId" />
        <xsl:param name="CallID" />
		<xsl:param name="TimeStamp" />

		<dp:set-variable name="'var://context/ServiceLog/MessageId'" value="dp:generate-uuid()"/>
		<dp:set-variable name="'var://context/TimeStamp'" value="$TimeStamp" />
		<dp:set-variable name="'var://context/ServiceLog/Type'" value="'RECEIVED'"/>
		<dp:set-variable name="'var://context/ServiceLog/Application'" value="'OMS'"/>
		<dp:set-variable name="'var://context/ServiceLog/ServiceName'" value="dp:variable('var://service/processor-name')"/>
		<dp:set-variable name="'var://context/ServiceLog/System'" value="concat('DataPower','_',substring(dp:variable('var://service/domain-name'),(string-length(dp:variable('var://service/domain-name'))-3)+1,3))"/>
		<dp:set-variable name="'var://context/ServiceLog/User'" value="' '"/>
		
		
		<dp:set-variable name="'var://context/ServiceLog/ContextElement1'" value="string($ACTION)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement2'" value="string($JobDisplayID)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement3'" value="string($CrewAssignmentDisplayId)"/>
		<dp:set-variable name="'var://context/ServiceLog/ContextElement4'" value="string($CallID)"/>
		
		<xsl:variable name="RawInput">
		<xsl:copy-of select="string(dp:variable('var://context/INPUT'))"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/ServiceLog/RawData'" value="dp:variable('var://context/myContext/inputData')"/>
	<!-- 	<dp:set-variable name="'var://context/ServiceLog/ContextElement5'" value="concat('TransactionId:',string(dp:variable('var://service/global-transaction-id')))"/> -->
		
		
	</xsl:template>
</xsl:stylesheet>
