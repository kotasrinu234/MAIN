<!-- xslt is used to capture the fsm formed payload into a queue -->
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"


	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">

				<xsl:param name="dpconfig:MQurlOut"/>
		        <xsl:param name="dpconfig:MqCall"/>

	<xsl:template match="/">

<xsl:variable name="MQurl_out">
<xsl:value-of select="$dpconfig:MQurlOut"/>
</xsl:variable>
<xsl:choose>
		
			<xsl:when test="contains($dpconfig:MqCall,'yes')">
								<dp:url-open target="{$MQurl_out}" response="ignore">
					<xsl:copy-of select="."/>
					
				</dp:url-open>
			</xsl:when>
		</xsl:choose>		</xsl:template>
		</xsl:stylesheet>
