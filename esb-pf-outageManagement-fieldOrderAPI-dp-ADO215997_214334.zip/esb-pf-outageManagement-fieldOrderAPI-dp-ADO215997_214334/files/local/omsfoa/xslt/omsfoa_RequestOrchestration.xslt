<!-- xslt is used to orchestrate response of all api invoked in this interface and generate a jsonx fsm payload . which will be converted to json in next action -->
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">

	
	<xsl:variable name="Config"
		select="document('local:///omsfoa/xml/Config.xml')" />
<xsl:param name="dpconfig:excludeComments" />
	<xsl:template match="/">
	
	<xsl:variable select="substring-after(dp:variable('var://service/system/ident')/identification/current-time,' ')" name="tempVAR"/>
		<dp:set-variable name="'var://context/dateTime/tempVAR'" value="string($tempVAR)"/>
		
		<xsl:variable name="Jsonx_Message">
			<xsl:variable name="CallApi">
				<xsl:copy-of
					select="dp:variable('var://context/CallApiResponseJsonX')" />
			</xsl:variable>
			<xsl:variable name="PremiseApi">
				<xsl:copy-of
					select="dp:variable('var://context/CallPremiseResponseJsonX')" />
			</xsl:variable>
			<xsl:variable name="JobApi">
				<xsl:copy-of
					select="dp:variable('var://context/JobApiResponseJsonX')" />
			</xsl:variable>
			<xsl:variable name="CustomerApi">
				<xsl:copy-of
					select="dp:variable('var://context/CustomerApiResponseJsonx')" />
			</xsl:variable>
			<xsl:variable name="CommentsApi">
				<xsl:copy-of
					select="dp:variable('var://context/CommentsApiResponseJsonX')" />
			</xsl:variable>
			<xsl:variable name="PremiseResponseCode">
				<xsl:copy-of
					select="dp:variable('var://context/PremiseCallResponseCode')" />
			</xsl:variable>
			<xsl:variable name="Service_Type">
				<xsl:copy-of
					select="dp:variable('var://context/omsfoa/Service_Type')" />
				</xsl:variable>
			<xsl:variable name="Input">
				<xsl:copy-of
					select="dp:variable('var://context/DP_Var1')" />
			</xsl:variable>
						<xsl:variable name="actions">
						<xsl:copy-of select="dp:variable('var://service/URI')" />
		</xsl:variable>
		<xsl:choose>
		<xsl:when test="contains($actions,'/Update/' )">
		
				<xsl:variable name="IsResolved">
				<xsl:copy-of
					select="dp:variable('var://context/omsfoa/IsResolved')" />
					</xsl:variable>
		<xsl:if test="contains($IsResolved, 'false')">
					<json:object
				xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
				xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
				xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">

				<json:array name="locations">
					<json:object>
						<json:string name="addressType">
							<xsl:value-of select="'job'" />
						</json:string>
						<xsl:choose>
							<xsl:when
								test="string-length(normalize-space($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='destination']/text()))&gt; 0">
								<json:string name="address">
									<xsl:value-of
										select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='destination']/text()" />
								</json:string>

							<json:string name='longitude'>
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='leadLocation']/*[local-name()='object'][@name='gpsLocation']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][1]/text()" />
							</json:string>

							<json:string name='latitude'>
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='leadLocation']/*[local-name()='object'][@name='gpsLocation']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][2]/text()" />
							</json:string>
							
							</xsl:when>
							<xsl:otherwise>
							
<xsl:choose>
  <xsl:when test="string-length(normalize-space($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='leadLocation']/*[local-name()='string'][@name='label']/text()))&gt; 0">
                                   <json:string name="address">
                                    <xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='leadLocation']/*[local-name()='string'][@name='label']/text()" />
                                 </json:string>
                               </xsl:when>
                               <xsl:otherwise>
                               
                                 <json:string name="address">
                                    <xsl:value-of select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='address']/text()" />
                                 </json:string>
                               </xsl:otherwise>
                               </xsl:choose>							


							
							<json:string name='longitude'>
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='leadLocation']/*[local-name()='object'][@name='gpsLocation']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][1]/text()" />
							</json:string>

							<json:string name='latitude'>
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='leadLocation']/*[local-name()='object'][@name='gpsLocation']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][2]/text()" />
							</json:string>
						
							</xsl:otherwise>
						</xsl:choose>
						
						<json:string name="crossStreet1">
									<xsl:value-of
										select="$CallApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='CrossStreet1']/text()" />
								</json:string>

								<json:string name="crossStreet2">
									<xsl:value-of
										select="$CallApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='CrossStreet2']/text()" />
								</json:string>
						</json:object>
						
								<xsl:if test="contains($PremiseResponseCode, '200')">
						<json:object>
							<json:string name="addressType">
								<xsl:value-of select="'premise'" />
							</json:string>
							<json:string name="address">
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='string'][@name='address']/text()" />
							</json:string>
							<json:string name='Municipality'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Muncipality']/text()" />
							</json:string>

							<json:string name='streetNumber'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Number']/text()" />
							</json:string>
							<json:string name='preDirection'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Pre_Direction']/text()" />
							</json:string>
							<json:string name='streetName'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Name']/text()" />
							</json:string>

							<json:string name='streetSuffix'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Suffix']/text()" />
							</json:string>

							<json:string name='postDirection'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Post_Direction']/text()" />
							</json:string>
							<json:string name='city'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_City']/text()" />
							</json:string>

							<json:string name='state'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_State']/text()" />
							</json:string>
							<json:string name='zipCode'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Zip_Code']/text()" />
							</json:string>

							<json:string name='County'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_County']/text()" />
							</json:string>

							<json:string name='townShip'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Township']/text()" />
							</json:string>
							
							<json:string name='siteSecondaryValue'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Secondary_Value']/text()" />
							</json:string>
							
							<json:string name='siteSecondaryCode'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Secondary_Code']/text()" />
							</json:string>

							<json:string name='siteID'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='siteID']/text()" />
							</json:string>

							<json:string name='longitude'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='location']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][1]/text()" />
							</json:string>

							<json:string name='latitude'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='location']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][2]/text()" />
							</json:string>

						</json:object>
					</xsl:if>
				</json:array>
				
					<json:string name="jobType">
					<xsl:choose>
				<xsl:when test="string-length(normalize-space($CallApi/*[local-name()='object']/*[local-name()='string'][@name='externalCallCodeID']/text()))&gt; 0">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='externalCallCodeID']/text()" />
				</xsl:when>
				<xsl:otherwise>
						<xsl:for-each
						select="//*[local-name()='lookupRep']/*[local-name()='type']">
						
						<xsl:if
							test="(normalize-space(./name)='jobTypes') and (normalize-space(./result)='0')">
							<xsl:value-of select="./label" />
						</xsl:if>
					</xsl:for-each>
					
				</xsl:otherwise>
				</xsl:choose>

				</json:string>
				
					<json:string name="comments">
						<xsl:for-each	
						 select="$CommentsApi/*[local-name()='array']/*[local-name()='object']">
							 <xsl:variable name="updatedBy">
								<xsl:value-of
									select="./*[ local-name()='string'][@name='updatedByUserName']/text()" />
							</xsl:variable>
								<xsl:variable name="excludeComments">
									<xsl:value-of select="$dpconfig:excludeComments"/>
								</xsl:variable>				
					
								<xsl:variable name="date">
									<xsl:value-of
										select="./*[ local-name()='string'][@name='updatedAt']/text()" />
									</xsl:variable>
									<dp:set-variable name="'var://context/Date'" value="$date" />
									
									<xsl:variable name="convertedDate">
									<xsl:choose>
										<xsl:when test="$tempVAR='EDT'">
											<xsl:call-template name="add-hours-to-dateTimeED">
												<xsl:with-param name="dateTime" select="substring($date,1,19)" />
											</xsl:call-template>
										</xsl:when>
										<xsl:when test="$tempVAR='EST'">
											<xsl:call-template name="add-hours-to-dateTimeES">
												<xsl:with-param name="dateTime" select="substring($date,1,19)" />
											</xsl:call-template>
										</xsl:when>
									</xsl:choose>
									</xsl:variable>
									<xsl:variable name="Comment">
										<xsl:value-of
											select="./*[ local-name()='string'][@name='comment']/text()" />
									</xsl:variable>
			
									<xsl:variable name="createdBy">
									<xsl:value-of
										select="./*[ local-name()='string'][@name='createdByUserName']/text()" />
									</xsl:variable>
									<xsl:if test="not(contains($updatedBy, $dpconfig:excludeComments))">
										<xsl:value-of select="concat($convertedDate, ' ',$createdBy,':',$Comment,'\n')" />
									</xsl:if>
			
						</xsl:for-each>
					</json:string>
				
				
								<json:string name="workNature">
							<xsl:for-each
						select="//*[local-name()='lookupRep']/*[local-name()='type']">
						<xsl:variable name="outageSubtypeID">
							<xsl:value-of
								select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='outageSubtypeID']/text()" />
						</xsl:variable>
						<xsl:if
							test="(normalize-space(./name)='outageSubtypes') and (normalize-space(./id)=$outageSubtypeID) and (normalize-space(./result)='0')">
							<xsl:value-of select="./label" />
						</xsl:if>
					</xsl:for-each>
				</json:string>
						<xsl:variable name="crewAssignmentsdisplayID">
				<xsl:copy-of
					select="dp:variable('var://context/omsfoa/crewAssignmentsdisplayID')" />
				</xsl:variable>
				<json:string name="omsJobId">
					<xsl:value-of
						select="concat($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[ local-name()='string'][@name='displayID'],'_',$crewAssignmentsdisplayID)" />
				</json:string>
								<json:string name="serviceType">
								<xsl:value-of select="$Service_Type"/>
								</json:string>
				<json:string name="cause">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='cause']/text()" />
				</json:string>
		<json:string name="action">
		<xsl:value-of select="'U'"/>
		</json:string>	
						<json:string name="etr">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='object'][@name='publishedEtr']/*[local-name()='string'][@name='value']/text()" />
				</json:string>	
				
				<json:string name="energizationStatus">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='energizationStatus']/text()" />
				</json:string>
				
				<json:string name="currentAffected">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='number'][@name='currentAffected']/text()" />
				</json:string>
				
				<xsl:variable name="dataid_omsid">
				<xsl:value-of
						select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='id']/text()" />			
				</xsl:variable>
				<xsl:variable name="leadcallId">
				<xsl:value-of
						select="$Input/*[local-name()='object']/*[local-name()='array']/*[ local-name()='object']/*[local-name()='string'][@name='leadCallID']/text()" />
				</xsl:variable>
				
					<xsl:variable name="crewAssignmentID">
				<xsl:copy-of
					select="dp:variable('var://context/omsfoa/crewAssignmentID')" />
				</xsl:variable>
				<json:string name='omsId'>
				<xsl:value-of
					   select="concat('OMS_',$crewAssignmentID,'_',$dataid_omsid,'_',$leadcallId )"/>
				
				</json:string>
	</json:object>
	</xsl:if>	
		
		</xsl:when>
	
		<xsl:otherwise>
			<json:object
				xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
				xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
				xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd">

				<json:array name="locations">
					<json:object>
						<json:string name="addressType">
							<xsl:value-of select="'job'" />
						</json:string>
						<xsl:choose>
							<xsl:when
								test="string-length(normalize-space($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='destination']/text()))&gt; 0">
								<json:string name="address">
									<xsl:value-of
										select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='destination']/text()" />
								</json:string>
								
							<json:string name='longitude'>
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[ local-name()='object'][@name='job']/*[local-name()='object'][@name='leadLocation']/*[local-name()='object'][@name='gpsLocation']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][1]/text()" />
							</json:string>

							<json:string name='latitude'>
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[ local-name()='object'][@name='job']/*[local-name()='object'][@name='leadLocation']/*[local-name()='object'][@name='gpsLocation']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][2]/text()" />
							</json:string>
							</xsl:when>
							<xsl:otherwise>
							
							<xsl:choose>
                              <xsl:when test="string-length(normalize-space($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[ local-name()='object'][@name='job']/*[local-name()='object'][@name='leadLocation']/*[local-name()='string'][@name='label']/text()))&gt; 0">
                             <json:string name="address">
                                    <xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[ local-name()='object'][@name='job']/*[local-name()='object'][@name='leadLocation']/*[local-name()='string'][@name='label']/text()" />
                                 </json:string>
                              </xsl:when>
                              <xsl:otherwise>
                                 <json:string name="address">
                                    <xsl:value-of select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='address']/text()" />
                                 </json:string>
                              </xsl:otherwise>
                              </xsl:choose>
								
							<json:string name='longitude'>
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[ local-name()='object'][@name='job']/*[local-name()='object'][@name='leadLocation']/*[local-name()='object'][@name='gpsLocation']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][1]/text()" />
							</json:string>

							<json:string name='latitude'>
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[ local-name()='object'][@name='job']/*[local-name()='object'][@name='leadLocation']/*[local-name()='object'][@name='gpsLocation']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][2]/text()" />
							</json:string>
	
							</xsl:otherwise>
						</xsl:choose>
						
							<json:string name="crossStreet1">
									<xsl:value-of
										select="$CallApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='CrossStreet1']/text()" />
								</json:string>

								<json:string name="crossStreet2">
									<xsl:value-of
										select="$CallApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='CrossStreet2']/text()" />
								</json:string>

					</json:object>
					<xsl:if test="contains($PremiseResponseCode, '200')">
						<json:object>
							<json:string name="addressType">
								<xsl:value-of select="'premise'" />
							</json:string>
							<json:string name="address">
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='string'][@name='address']/text()" />
							</json:string>
							<json:string name='Municipality'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Muncipality']/text()" />
							</json:string>

							<json:string name='streetNumber'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Number']/text()" />
							</json:string>
							<json:string name='preDirection'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Pre_Direction']/text()" />
							</json:string>
							<json:string name='streetName'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Name']/text()" />
							</json:string>

							<json:string name='streetSuffix'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Street_Suffix']/text()" />
							</json:string>

							<json:string name='postDirection'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Post_Direction']/text()" />
							</json:string>
							<json:string name='city'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_City']/text()" />
							</json:string>

							<json:string name='state'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_State']/text()" />
							</json:string>
							<json:string name='zipCode'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Zip_Code']/text()" />
							</json:string>

							<json:string name='County'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_County']/text()" />
							</json:string>

							<json:string name='townShip'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Township']/text()" />
							</json:string>
							
							<json:string name='siteSecondaryValue'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Secondary_Value']/text()" />
							</json:string>
							
							<json:string name='siteSecondaryCode'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Site_Secondary_Code']/text()" />
							</json:string>

							<json:string name='siteID'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='siteID']/text()" />
							</json:string>

							<json:string name='longitude'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='location']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][1]/text()" />
							</json:string>

							<json:string name='latitude'>
								<xsl:value-of
									select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='location']/*[local-name()='array'][@name='coordinates']/*[local-name()='number'][2]/text()" />
							</json:string>

						</json:object>
					</xsl:if>
				</json:array>

				
				<json:string name="jobType">
					<xsl:choose>
				<xsl:when test="string-length(normalize-space($CallApi/*[local-name()='object']/*[local-name()='string'][@name='externalCallCodeID']/text()))&gt; 0">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='externalCallCodeID']/text()" />
				</xsl:when>
				<xsl:otherwise>
						<xsl:for-each
						select="//*[local-name()='lookupRep']/*[local-name()='type']">
						<xsl:if
							test="(normalize-space(./name)='jobTypes') and (normalize-space(./result)='0')">
							<xsl:value-of select="./label" />
						</xsl:if>
					</xsl:for-each>
					
				</xsl:otherwise>
				</xsl:choose>
				</json:string>
				
				<json:string name="circuit">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='networkModelName']/text()" />
				</json:string>

				<json:string name="stationMapArea">
					<xsl:value-of
						select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Station_Map_Area']/text()" />
				</json:string>

				<json:string name="workNature">
							<xsl:for-each
						select="//*[local-name()='lookupRep']/*[local-name()='type']">
						<xsl:variable name="outageSubtypeID">
							<xsl:value-of
								select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='outageSubtypeID']/text()" />
						</xsl:variable>
						<xsl:if
							test="(normalize-space(./name)='outageSubtypes') and (normalize-space(./id)=$outageSubtypeID) and (normalize-space(./result)='0')">
							<xsl:value-of select="./label" />
						</xsl:if>
					</xsl:for-each>
				</json:string>

				<json:string name="premise">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='externalPremiseID']/text()" />
				</json:string>
				<json:string name="customerName">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='name']/text()" />
				</json:string>
				<json:string name="customerPhoneNumber">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='phoneNumber']/text()" />
				</json:string>
				<json:string name="customerCallBackInformation">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='callbackContactInfo']/text()" />
				</json:string>

				<json:string name="customerProfile">
					<xsl:value-of
						select="$CustomerApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Customer_Profile']/text()" />
				</json:string>

				<json:string name="customerProfileType">
					<xsl:value-of
						select="$CustomerApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Customer_Profile_Type']/text()" />
				</json:string>

				<json:string name="customerType">
					<xsl:value-of
						select="$CustomerApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Customer_Type']/text()" />
				</json:string>
				<json:string name="creationDate">
					<xsl:value-of
					
						select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='createdAt']/text()" />
				</json:string>
				
				      <xsl:variable name="workStartDate">
                        <xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='createdAt']/text()" />
                     </xsl:variable>
				<json:string name="workStartDate">
					<xsl:value-of
						select="$workStartDate" />
				</json:string>
<!-- 				<json:string name="workEndDate"> -->
<!-- 					<xsl:value-of -->
<!-- 						select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='createdAt']/text()" /> -->
<!-- 				</json:string> -->
                     <!-- workEndDate start-->

                     <json:string name="workEndDate">
                        <xsl:call-template name="UTC-Plus-FourHrs">
                           <xsl:with-param name="dateTime" select="$workStartDate" />
                        </xsl:call-template>
                     </json:string>
                     <!-- workEndDate end-->
					 
					<json:string name="comments">
						<xsl:for-each	
						 select="$CommentsApi/*[local-name()='array']/*[local-name()='object']">
							 <xsl:variable name="updatedBy">
								<xsl:value-of
									select="./*[ local-name()='string'][@name='updatedByUserName']/text()" />
							</xsl:variable>
								<xsl:variable name="excludeComments">
									<xsl:value-of select="$dpconfig:excludeComments"/>
								</xsl:variable>				
					
								<xsl:variable name="date">
									<xsl:value-of
										select="./*[ local-name()='string'][@name='updatedAt']/text()" />
									</xsl:variable>
									<dp:set-variable name="'var://context/Date'" value="$date" />
									
									<xsl:variable name="convertedDate">
									<xsl:choose>
										<xsl:when test="$tempVAR='EDT'">
											<xsl:call-template name="add-hours-to-dateTimeED">
												<xsl:with-param name="dateTime" select="substring($date,1,19)" />
											</xsl:call-template>
										</xsl:when>
										<xsl:when test="$tempVAR='EST'">
											<xsl:call-template name="add-hours-to-dateTimeES">
												<xsl:with-param name="dateTime" select="substring($date,1,19)" />
											</xsl:call-template>
										</xsl:when>
									</xsl:choose>
									</xsl:variable>
									<xsl:variable name="Comment">
										<xsl:value-of
											select="./*[ local-name()='string'][@name='comment']/text()" />
									</xsl:variable>
			
									<xsl:variable name="createdBy">
									<xsl:value-of
										select="./*[ local-name()='string'][@name='createdByUserName']/text()" />
									</xsl:variable>
									<xsl:if test="not(contains($updatedBy, $dpconfig:excludeComments))">
										<xsl:value-of select="concat($convertedDate, ' ',$createdBy,':',$Comment,'\n')" />
									</xsl:if>
			
						</xsl:for-each>
					</json:string>
								<xsl:variable name="actions">
				<xsl:copy-of select="dp:variable('var://service/URI')" />
		</xsl:variable>
				<xsl:variable name="Dispatchgrp">
					<xsl:for-each
						select="//*[local-name()='lookupRep']/*[local-name()='type']">
						<xsl:variable name="aorsId">
						
							<xsl:choose>
	<xsl:when test="contains($actions,'/Update/')">
<xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='array'][@name='geographicAorIDs']/*[local-name()='string']/text()"/>
</xsl:when>
<xsl:otherwise>
<xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='array'][@name='geographicAorIDs']/*[local-name()='string']/text()"/>
</xsl:otherwise>

</xsl:choose>				
						
						
						</xsl:variable>
						<xsl:if
							test="(normalize-space(./name)='aors') and (normalize-space(./id)=$aorsId) and (normalize-space(./status)='none')">
							<xsl:value-of select="./label" />
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
					 <xsl:choose>
					 <xsl:when test="$Dispatchgrp !=''">
				<json:string name="dispatchGroup">
					<xsl:value-of select="$Dispatchgrp" />
				</json:string>
<!-- update code for Service center name 18-may-2020 -->
				<xsl:variable name="serviceCentername">
					<xsl:value-of select="substring($Dispatchgrp, 1,3)" />
				</xsl:variable>
<xsl:for-each select="$Config/*[local-name()='Backend']/*[local-name()='serviceCenterDetails']/*[local-name()='serviceCenter']">

<xsl:if test="contains(./*[local-name()='name'],$serviceCentername)">
<json:string name="serviceCenter">
<xsl:value-of select="./*[local-name()='value']"/>
</json:string>
</xsl:if>
</xsl:for-each>				
	 </xsl:when>
					 <xsl:otherwise>
					    <json:string name="dispatchGroup"/> 
					    <json:string name="serviceCenter"/>                          
					 </xsl:otherwise>
					 </xsl:choose>					 				

				<json:string name="station">
					<xsl:value-of
						select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Station']/text()" />
				</json:string>

				<json:string name="meterId">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='meterID']/text()" />
				</json:string>
				
				<json:string name="accountNo">
					<xsl:value-of
						select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Contract_Account_Number']/text()" />
				</json:string>

				<json:string name="omsJobId">
					<xsl:value-of
						select="concat($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='jobDisplayID']/text(),'_',$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='displayID']/text())" />
				</json:string>

				<json:string name="callId">
					<xsl:value-of
						select="$CallApi/*[local-name()='object']/*[local-name()='string'][@name='displayID']/text()" />
				</json:string>

				<!-- 3-april-2020 adding omsid -->
				<xsl:variable name="jobid_omsid">
				<xsl:value-of
						select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='id']/text()" />			
				</xsl:variable>
				
				<xsl:variable name="crewAssignmentId_omsid">
				<xsl:value-of
						select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='id']/text()" />
				</xsl:variable>
				
				<xsl:variable name="Callid_omsid">
					<xsl:value-of
						select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='leadCallID']/text()" />
				</xsl:variable>
				
				<json:string name='omsId'>
				<xsl:value-of
					   select="concat('OMS_',$crewAssignmentId_omsid,'_',$jobid_omsid,'_',$Callid_omsid )"/>
				
				</json:string>
				
				<!-- 3-april-2020 adding omsid end-->

				<xsl:if
					test="string-length($Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='crew']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='employeeid'])&gt; 0">
					<json:string name="externalCrewId">
						<xsl:value-of
							select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='crew']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='employeeid']/text()" />

					</json:string>
				</xsl:if>
				<json:string name="crewAssignmentId">
					<xsl:value-of
						select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='id']/text()" />

				</json:string>
				<json:string name="nominalVoltage">
					<xsl:value-of
						select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='Nominal_Voltage']/text()" />

				</json:string>
				<json:string name="nominalFeederName">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='nominalFeeder']/text()" />
				</json:string>
				<json:string name="feederName">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='feederName']/text()" />
				</json:string>

				<json:string name="workType">
					<xsl:for-each
						select="//*[local-name()='lookupRep']/*[local-name()='type']">
						<xsl:variable name="workTypeId">
							<xsl:value-of
								select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='workTypeID']/text()" />
						</xsl:variable>
						<xsl:if
							test="(normalize-space(./name)='workTypes') and (normalize-space(./id)=$workTypeId) and (normalize-space(./status)='none')">
							<xsl:value-of select="./label" />
						</xsl:if>
					</xsl:for-each>
				</json:string>
				<xsl:if
					test="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='object'][@name='crew']">

					<json:string name="crewType">
						<xsl:for-each
							select="//*[local-name()='lookupRep']/*[local-name()='type']">
							<xsl:variable name="typeId">
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='crew']/*[local-name()='string'][@name='id']/text()" />
							</xsl:variable>
							

							<xsl:variable name="CrewStatus">
								<xsl:value-of
									select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='crew']/*[local-name()='number'][@name='type']/text()" />
							</xsl:variable>
							
							<xsl:if
								test="(normalize-space(./name)='crewTypes')  and (normalize-space(./status)=$CrewStatus)">
								<xsl:value-of select="./label" />
							</xsl:if>
						</xsl:for-each>

					</json:string>
				</xsl:if>
				<json:string name="serviceType">
								<xsl:value-of select="$Service_Type"/>
				</json:string>
				<json:string name="cause">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='cause']/text()" />
				</json:string>

				<json:string name="gridNumber">
					<xsl:value-of
						select="$PremiseApi/*[local-name()='object']/*[local-name()='object'][@name='customFieldValuesExt']/*[local-name()='string'][@name='GridNumber']/text()" />
				</json:string>

				<json:string name="action">
					<xsl:variable name="actions">
						<xsl:copy-of select="dp:variable('var://service/URI')" />
					</xsl:variable>

					<xsl:choose>
						<xsl:when test="contains($actions, '/Create/')">
							<xsl:value-of select="'A'" />
						</xsl:when>

						<xsl:when test="contains($actions, '/Update/')">
							<xsl:value-of select="'U'" />
						</xsl:when>

						<xsl:when test="contains($actions, '/Cancel/')">
							<xsl:value-of select="'C'" />
						</xsl:when>

						<xsl:when test="contains($actions, '/Preempt/')">
							<xsl:value-of select="'P'" />
						</xsl:when>

					</xsl:choose>
				</json:string>
				<json:string name="eta">
					<xsl:value-of
						select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='eta']/text()" />
						</json:string>
				
				<json:string name="etr">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='object'][@name='publishedEtr']/*[local-name()='string'][@name='value']/text()" />
				</json:string>

				<json:string name="region">
					<xsl:value-of
						select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='regionName']/text()" />
				</json:string>
					<json:string name="energizationStatus">
					<xsl:choose>
						<xsl:when test="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='energizationStatus']/text()">
					<xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='energizationStatus']/text()"/>
					</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='energizationStatus']/text()"/>
				</xsl:otherwise>
					</xsl:choose>	
					</json:string>
				<json:string name="currentAffected">
				<xsl:choose>
					<xsl:when test="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='number'][@name='currentAffected']/text()">
				<xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='number'][@name='currentAffected']/text()"/>
					</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="$Input/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='number'][@name='currentAffected']/text()"/>
				</xsl:otherwise>
					</xsl:choose>	
				</json:string>	
			</json:object>
		</xsl:otherwise>
		</xsl:choose>
			<dp:set-http-request-header
				name="'Content-Type'" value="'application/json'" />
				
		</xsl:variable>
		<xsl:copy-of select="$Jsonx_Message" />
	</xsl:template>
	  <xsl:template name="UTC-Plus-FourHrs">
      <xsl:param name="dateTime" />
      <xsl:variable name="date" select="substring-before($dateTime, 'T')" />
      <xsl:variable name="time" select="substring-before(substring-after($dateTime, 'T'), 'Z')" />
      <xsl:variable name="year" select="substring($date, 1, 4)" />
      <xsl:variable name="month" select="substring($date, 6, 2)" />
      <xsl:variable name="day" select="substring($date, 9, 2)" />
      <xsl:variable name="hour" select="substring($time, 1, 2)" />
      <xsl:variable name="minute" select="substring($time, 4, 2)" />
      <xsl:variable name="second" select="substring($time, 7)" />
      <xsl:variable name="a" select="floor((14 - $month) div 12)" />
      <xsl:variable name="y" select="$year + 4800 - $a" />
      <xsl:variable name="m" select="$month + 12*$a - 3" />
      <xsl:variable name="jd" select="$day + floor((153*$m + 2) div 5) + 365*$y + floor($y div 4) - floor($y div 100) + floor($y div 400) - 32045" />
      <xsl:variable name="total-seconds" select="86400*$jd + 3600*$hour + 60*$minute + $second + 3600" />
      <xsl:variable name="new-jd" select="floor($total-seconds div 86400)" />
      <xsl:variable name="new-hour" select="floor($total-seconds mod 86400 div 3600)" />
      <xsl:variable name="new-minute" select="floor($total-seconds mod 3600 div 60)" />
      <xsl:variable name="new-second" select="$total-seconds mod 60" />
      <xsl:variable name="f" select="$new-jd + 1401 + floor((floor((4 * $new-jd + 274277) div 146097) * 3) div 4) - 38" />
      <xsl:variable name="e" select="4*$f + 3" />
      <xsl:variable name="g" select="floor(($e mod 1461) div 4)" />
      <xsl:variable name="h" select="5*$g + 2" />
      <xsl:variable name="D" select="floor(($h mod 153) div 5 ) + 1" />
      <xsl:variable name="M" select="(floor($h div 153) + 2) mod 12 + 1" />
      <xsl:variable name="Y" select="floor($e div 1461) - 4716 + floor((14 - $M) div 12)" />
      <xsl:value-of select="concat($Y, format-number($M, '-00'), format-number($D, '-00'))" />
      <xsl:text>T</xsl:text>
      <xsl:value-of select="concat(format-number($new-hour, '00'), format-number($new-minute, ':00'), format-number($new-second, ':00.###'))" />
      <xsl:text>Z</xsl:text>
   </xsl:template>
   
   <xsl:template name="add-hours-to-dateTimeED">
		<xsl:param name="dateTime" />
		<xsl:param name="hours" select="4" />
		<xsl:variable name="dateTime-in-seconds">
			<xsl:call-template name="dateTime-to-seconds">
				<xsl:with-param name="dateTime" select="$dateTime" />
			</xsl:call-template>
		</xsl:variable>
		<xsl:variable name="total-seconds" select="$dateTime-in-seconds - 3600 * $hours" />
		<!-- new date -->
		<xsl:variable name="new-date">
			<xsl:call-template name="JDN-to-Gregorian">
				<xsl:with-param name="JDN" select="floor($total-seconds div 86400)" />
			</xsl:call-template>
		</xsl:variable>
		<!-- new time -->
		<xsl:variable name="t" select="$total-seconds mod 86400" />
		<xsl:variable name="h" select="floor($t div 3600)" />
		<xsl:variable name="r" select="$t mod 3600" />
		<xsl:variable name="m" select="floor($r div 60)" />
		<xsl:variable name="s" select="$r mod 60" />
		<!-- output -->
		<xsl:value-of select="$new-date" />
		<xsl:text>T</xsl:text>
		<xsl:value-of select="format-number($h, '00')" />
		<xsl:value-of select="format-number($m, ':00')" />
		<xsl:value-of select="format-number($s, ':00.###')" />
	</xsl:template>
	
   	<xsl:template name="add-hours-to-dateTimeES">
		<xsl:param name="dateTime" />
		<xsl:param name="hours" select="5" />
		<xsl:variable name="dateTime-in-seconds">
			<xsl:call-template name="dateTime-to-seconds">
				<xsl:with-param name="dateTime" select="$dateTime" />
			</xsl:call-template>
		</xsl:variable>
		<xsl:variable name="total-seconds" select="$dateTime-in-seconds - 3600 * $hours" />
		<!-- new date -->
		<xsl:variable name="new-date">
			<xsl:call-template name="JDN-to-Gregorian">
				<xsl:with-param name="JDN" select="floor($total-seconds div 86400)" />
			</xsl:call-template>
		</xsl:variable>
		<!-- new time -->
		<xsl:variable name="t" select="$total-seconds mod 86400" />
		<xsl:variable name="h" select="floor($t div 3600)" />
		<xsl:variable name="r" select="$t mod 3600" />
		<xsl:variable name="m" select="floor($r div 60)" />
		<xsl:variable name="s" select="$r mod 60" />
		<!-- output -->
		<xsl:value-of select="$new-date" />
		<xsl:text>T</xsl:text>
		<xsl:value-of select="format-number($h, '00')" />
		<xsl:value-of select="format-number($m, ':00')" />
		<xsl:value-of select="format-number($s, ':00.###')" />
	</xsl:template>
	
	<xsl:template name="dateTime-to-seconds">
		<xsl:param name="dateTime" />
		<xsl:variable name="date" select="substring-before($dateTime, 'T')" />
		<xsl:variable name="time" select="substring-after($dateTime, 'T')" />
		<xsl:variable name="year" select="substring($date, 1, 4)" />
		<xsl:variable name="month" select="substring($date, 6, 2)" />
		<xsl:variable name="day" select="substring($date, 9, 2)" />
		<xsl:variable name="hour" select="substring($time, 1, 2)" />
		<xsl:variable name="minute" select="substring($time, 4, 2)" />
		<xsl:variable name="second" select="substring($time, 7)" />
		<xsl:variable name="a" select="floor((14 - $month) div 12)" />
		<xsl:variable name="y" select="$year + 4800 - $a" />
		<xsl:variable name="m" select="$month + 12*$a - 3" />
		<xsl:variable name="jd" select="$day + floor((153*$m + 2) div 5) + 365*$y + floor($y div 4) - floor($y div 100) + floor($y div 400) - 32045" />
		<xsl:value-of select="86400*$jd + 3600*$hour + 60*$minute + $second" />
	</xsl:template>
		<xsl:template name="JDN-to-Gregorian">
		<xsl:param name="JDN" />
		<xsl:variable name="f" select="$JDN + 1401 + floor((floor((4 *$JDN + 274277) div 146097) *3) div 4) - 38" />
		<xsl:variable name="e" select="4*$f + 3" />
		<xsl:variable name="g" select="floor(($e mod 1461) div 4)" />
		<xsl:variable name="h" select="5*$g + 2" />
		<xsl:variable name="D" select="floor(($h mod 153) div 5 ) + 1" />
		<xsl:variable name="M" select="(floor($h div 153) + 2) mod 12 + 1" />
		<xsl:variable name="Y" select="floor($e div 1461) - 4716 + floor((14 - $M) div 12)" />
		<xsl:value-of select="$Y" />
		<xsl:value-of select="format-number($M, '-00')" />
		<xsl:value-of select="format-number($D, '-00')" />
	</xsl:template>
</xsl:stylesheet>
