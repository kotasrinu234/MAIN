<!--  XSLT is used to invoke CALL api and do a get the api response -->
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
	xmlns:dpconfig="http://www.datapower.com/param/config"


	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">

		<xsl:param name="dpconfig:omsExternalURL"/>
		<xsl:param name="dpconfig:NullCheckRequired"/>
		<xsl:param name="dpconfig:MqCall"/>
		<xsl:param name="dpconfig:MQurlInput"/>	
		<xsl:param name="dpconfig:osiApiToken"/>	
		  	
		 
		  	<xsl:template match="/">
	<xsl:variable name="TransactoinID">
	<xsl:copy-of
	  select="dp:variable('var://service/global-transaction-id')" />
	</xsl:variable>
			<xsl:variable name="actions">
						<xsl:copy-of select="dp:variable('var://service/URI')" />
		</xsl:variable>
		<!-- null check start -->
		
		<xsl:if test = "contains( $dpconfig:NullCheckRequired,'true')" >

	<xsl:choose>
	<xsl:when test="contains( $actions,'/Update/')" > 	
	</xsl:when>
	<xsl:otherwise>
	<xsl:choose>
	<xsl:when test="string-length(normalize-space(/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='workTypeID']/text()))&gt; 0">
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error">TransactionID :<xsl:value-of select="$TransactoinID"/> workTypeID is missing in oms request</xsl:message>				
	<dp:set-variable name="'var://context/input/nullCheck'" value="'yes'" />
	<dp:reject> workTypeID missing in oms request</dp:reject>
	</xsl:otherwise>
	</xsl:choose>
	</xsl:otherwise>
	
	</xsl:choose>

	<xsl:choose>
	<xsl:when test="contains( $actions,'/Update/')" > 	
	</xsl:when>
	<xsl:otherwise>
		<xsl:choose>
	<xsl:when test="string-length(normalize-space(/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='jobAorID']/text()))&gt; 0">
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error">TransactionID :<xsl:value-of select="$TransactoinID"/> JobAorID is missing in oms request</xsl:message>				
	<dp:set-variable name="'var://context/input/nullCheck'" value="'yes'" />
	<dp:reject> JobAorID missing in oms request</dp:reject>
	</xsl:otherwise>
	</xsl:choose>
	</xsl:otherwise>
	</xsl:choose>
	
	<xsl:choose>
	<xsl:when test="string-length(normalize-space(/*[local-name()='object']/*[local-name()='array'][@name='data']/*[ local-name()='object']/*[local-name()='string'][@name='createdAt']/text()))&gt; 0">
	</xsl:when>
	<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="error">TransactionID :<xsl:value-of select="$TransactoinID"/> createdAt is missing in oms request</xsl:message>				
	<dp:set-variable name="'var://context/input/nullCheck'" value="'yes'" />
	<dp:reject> createdAt missing in oms request</dp:reject>
	</xsl:otherwise>
	</xsl:choose>
		</xsl:if>
	 <!-- null check end -->	
	
<!-- Sending input json to mq based on config.xml file value starts dpmq://omsfoa_FSM_QM/?RequestQueue=OMSFOA_INPUT-->
<xsl:variable name="MQurlINput">
<xsl:value-of select="$dpconfig:MQurlInput"/>
</xsl:variable>
<xsl:choose>	
			<xsl:when test="contains($dpconfig:MqCall,'yes')">
								<dp:url-open target="{$MQurlINput}" response="ignore">
					<xsl:copy-of select="dp:variable('var://context/INPUT')"/>
					
				</dp:url-open>
			</xsl:when>
		</xsl:choose>
		<!-- Sending input json to mq ends -->
		

	
		
		<xsl:variable name="id">
		<xsl:choose>
	
		<xsl:when test="contains($actions,'/Update/' )">
			<xsl:choose>
				<xsl:when
					test="string-length(normalize-space(/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='leadCallID']/text()))&gt; 0">
			<xsl:value-of
						select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='leadCallID']/text()" />
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of
						select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='array'][@name='calls']/*[local-name()='object']/*[local-name()='string'][@name='id']/text()" />
			</xsl:otherwise>
			</xsl:choose>	
		</xsl:when>
		<xsl:otherwise>
			<xsl:choose>
				<xsl:when
					test="string-length(normalize-space(/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='leadCallID']/text()))&gt; 0">
					<xsl:value-of
						select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='leadCallID']/text()" />
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of
						select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='array'][@name='calls']/*[local-name()='object']/*[local-name()='string'][@name='id']/text()" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:otherwise>
		</xsl:choose>
		
		</xsl:variable>
	
	
		<xsl:variable name="headerValues">
			<header name="Content-Type">application/json</header>
			<header name="osiApiToken">
				<xsl:value-of
					select="$dpconfig:osiApiToken" />
			</header>
		</xsl:variable>

		<!-- /api/ServiceType/{sid}/Call/{id} -->
		<xsl:variable name="url">
			<xsl:value-of
				select="concat($dpconfig:omsExternalURL,'/api/ServiceType/Electric/Call/',$id)" />
		</xsl:variable>
		<xsl:choose>
		<xsl:when test="string-length(normalize-space($id))>0">
		<xsl:variable name="CallApi">
			<dp:url-open target="{$url}"
				ssl-proxy="client:OMS_Client_Profile" http-headers="$headerValues"
				http-method="get" response="responsecode-binary">
			</dp:url-open>
		</xsl:variable>
		<xsl:variable name="responseCode">
			<xsl:value-of select="$CallApi/result/responsecode" />
		</xsl:variable>
		<dp:set-variable name="'var://context/CallAPIResponseCode'" value="$responseCode" />
		
		<xsl:choose>
			<xsl:when test="$responseCode='200'">
				<xsl:variable name="CallApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($CallApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:copy-of select="$CallApiResponse" />
				<xsl:message dp:type="all" dp:priority="info">
					-------callapiResponse
					<xsl:value-of select="$CallApiResponse" />
				</xsl:message>
			</xsl:when>
			<xsl:when test="$responseCode='404'">
				<xsl:variable name="CallApiResponse">
					<xsl:copy-of
						select="(dp:decode(dp:binary-encode($CallApi/result/binary/node()),'base-64'))"
						disable-output-escaping="yes" />
				</xsl:variable>
				<xsl:copy-of select="'{}'" />
				<xsl:message dp:type="all" dp:priority="info">
					-------callApiResponse
					<xsl:copy-of select="$CallApiResponse" />
				</xsl:message>
			</xsl:when>
			
			<xsl:otherwise>	
			<xsl:variable name="IDLable">
				<xsl:choose>
				<xsl:when
					test="string-length(normalize-space(/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='string'][@name='leadCallID']/text()))&gt; 0">
					<xsl:value-of select="'leadCallID'"/>			
				</xsl:when>
				<xsl:otherwise>		 
						<xsl:value-of select="'CallID'"/>									
				</xsl:otherwise>				
			</xsl:choose>
			</xsl:variable>		
			<xsl:choose>
				<xsl:when test="string-length(normalize-space($responseCode))&gt; 0">
				
				<xsl:variable name="CallApiResponse">
<xsl:copy-of select="(dp:decode(dp:binary-encode($CallApi/result/binary/node()),'base-64'))" disable-output-escaping="yes" />
</xsl:variable>
				
		<xsl:message dp:type="all" dp:priority="error">omsfoa_049 TransactionID :<xsl:value-of select="$TransactoinID"/> Call API Response code for <xsl:copy-of select="$IDLable"/>: <xsl:value-of select="$id"/> is <xsl:value-of select="$responseCode" /> and reason is <xsl:value-of select="$CallApiResponse" /> </xsl:message>
				
			<dp:reject>omsfoa_049 Call API Response code for <xsl:copy-of select="$IDLable"/>: <xsl:value-of select="$id"/> is <xsl:value-of select="$responseCode" /> and reason is <xsl:value-of select="$CallApiResponse" />
				</dp:reject>			
				</xsl:when>
			<xsl:otherwise>
			
					<xsl:variable name="errorstatuscode">
			<xsl:value-of select="$CallApi/result/errorstatuscode" />
		</xsl:variable>
							<xsl:variable name="errorstring">
			<xsl:value-of select="$CallApi/result/errorstring" />
		</xsl:variable>
		
			<xsl:message dp:type="all" dp:priority="error">omsfoa_001 TransactionID :<xsl:value-of select="$TransactoinID"/> Call API Response failed for <xsl:copy-of select="$IDLable"/>: <xsl:value-of select="$id"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></xsl:message>
				
			<dp:reject> Call API Response code for <xsl:copy-of select="$IDLable"/>: <xsl:value-of select="$id"/> with error code <xsl:value-of select="$errorstatuscode"/> and with error string as <xsl:value-of select="$errorstring"/></dp:reject>
			</xsl:otherwise>
				</xsl:choose>
				
				
			</xsl:otherwise>
			
		</xsl:choose>	
		</xsl:when>
		<xsl:otherwise>
	<xsl:message dp:type="all" dp:priority="debug">omsfoa_050 TransactionID :<xsl:value-of select="$TransactoinID"/> Call API is not Invoked(LeadcallID or CallId is not present input request)</xsl:message>	
		<xsl:copy-of select="'{}'" />
		</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
