<!--  xslt is used to perform a lookup activity -->
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:dyn="http://exslt.org/dynamic"
	xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"

	extension-element-prefixes="dp date" exclude-result-prefixes="dp date">
	
	<xsl:template match="/">
	
				<xsl:variable name="JobApi">
				<xsl:copy-of
					select="dp:variable('var://context/JobApiResponseJsonX')" />
			</xsl:variable>
			<xsl:variable name="CallApi">
				<xsl:copy-of
					select="dp:variable('var://context/CallApiResponseJsonX')" />
			</xsl:variable>
			<xsl:variable name="actions">
				<xsl:copy-of select="dp:variable('var://service/URI')" />
		</xsl:variable>
	
	<lookupReq>
	<type>
		<name>aors</name>
		<id>
		<xsl:choose>
	<xsl:when test="contains($actions,'/Update/')">
<xsl:value-of select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='array'][@name='geographicAorIDs']/*[local-name()='string']/text()"/>
</xsl:when>
<xsl:otherwise>
<xsl:value-of select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='job']/*[local-name()='array'][@name='geographicAorIDs']/*[local-name()='string']/text()"/>
</xsl:otherwise>

</xsl:choose>				
		</id>
		<status>none</status>
	</type>
	<type>
		<name>workTypes</name>
		<id>
		<xsl:value-of select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='workTypeID']/text()"/>			
		</id>
		<status>none</status>
	</type>
	
	<type>
		<name>crewTypes</name>
		
		<status>
		<xsl:value-of select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='object'][@name='crew']/*[local-name()='number'][@name='type']/text()"/>				
		</status>
		
	</type>
	
	<type>
		<name>outageSubtypes</name>
		<id>
		<xsl:value-of select="$JobApi/*[local-name()='object']/*[local-name()='string'][@name='outageSubtypeID']/text()"/>				
		</id>
	</type>
	
	<xsl:choose>
				<xsl:when test="string-length(normalize-space($CallApi/*[local-name()='object']/*[local-name()='string'][@name='externalCallCodeID']/text()))&gt; 0">
				</xsl:when>
				<xsl:otherwise>
				
					<type>
						<name>jobTypes</name>
						<id>
						<xsl:value-of select="/*[local-name()='object']/*[local-name()='array'][@name='data']/*[local-name()='object']/*[local-name()='string'][@name='jobTypeID']/text()"/>				
						</id>
					</type>
				</xsl:otherwise>
				</xsl:choose>
				
	</lookupReq>
	
				
	</xsl:template>
	
	
	</xsl:stylesheet>
