<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
	xmlns:dp="http://www.datapower.com/extensions"
	xmlns:dpquery="http://www.datapower.com/param/query"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dpconfig="http://www.datapower.com/param/config"
	xmlns:regexp="http://exslt.org/regular-expressions"
	extension-element-prefixes="dp regexp dyn" exclude-result-prefixes="dp"
	xmlns:date="http://exslt.org/dates-and-times"
	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:ser="http://dteco.com/DeviceManagement/ServiceOrder"
	version="1.0">
	
	<xsl:template match="/">

	
	<xsl:variable name="ExternalRefID">
	<xsl:value-of select="/*[local-name()='object']/*[local-name()='object'][@name='FSM_EFO_Acknowledgement']/*[local-name()='string'][@name='ExternalRefID']"/>
	</xsl:variable>
	<!-- //OMS_ crewassignmentid _ jobid _ leadcallid -->
	<xsl:message dp:type="all" dp:priority="debug">value is ++<xsl:value-of select="$ExternalRefID"/>
	</xsl:message>
	<xsl:variable name="crewassignmentidAfter">
	<xsl:value-of select="substring-after($ExternalRefID ,'OMS_')"/>
	</xsl:variable>
		<xsl:variable name="crewassignmentid">
		<xsl:value-of select="substring-before($crewassignmentidAfter,'_' )"/>
		</xsl:variable>
		<xsl:variable name="JobidAfter">
		<xsl:value-of select="substring-after($crewassignmentidAfter,'_' )"/>
		</xsl:variable>
		<xsl:variable name="Jobid">
		<xsl:value-of select="substring-before($JobidAfter,'_' )"/>
		</xsl:variable>
		<xsl:variable name="leadcallid">
		<xsl:value-of select="substring-after($JobidAfter,'_' )"/>
		</xsl:variable>

<dp:set-variable name="'var://context/omsfoa/ExternalRefIDCrewAssignmentID'" value="string($crewassignmentid)"/>
<dp:set-variable name="'var://context/omsfoa/ExternalRefIDCallid'" value="string($leadcallid)"/>
<dp:set-variable name="'var://context/omsfoa/ExternalRefIDJobid'" value="string($Jobid)"/>
	</xsl:template>
</xsl:stylesheet>
