var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("QSMS_Location") || session.createContext("QSMS_Location");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var ctx1 = session.name("QSMS") || session.createContext("QSMS");
var searchSessionId = ctx1.getVar("searchSessionId");
var logger = console.options({
	'category': 'all'
});
session.input.readAsBuffer(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		if (ctx.getVar("location")) {
			var location = ctx.getVar("location");
			if (location !== null || location !== '' || location !== undefined) {
				var payload = {
					"modules": [
						"DTE-PIS"
					],
					"returnFields": [
						"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
					],
					"query": {
						"condition": "equals",
						"field": "Name",
						"type": "strict",
						"term": [
							location
						]
					},
					"sort": "_LastUpdatedOn desc",
					"excludeIncludeAlways": true,
					"includeUnreadCount": false,
					"size": 1,
					"page": 0
				}
				var Url = session.parameters.searchSessionUrl;
				var locUrl = Url + '/v1/search';
				var locUrlPayload = {
					target: locUrl,
					sslClientProfile: 'qsms_ClientProfile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'DWAYSessionId': searchSessionId,
						'subscriber': session.parameters.key
					},
					data: payload
				};
				var info = " TargetURL :" + locUrlPayload.target + "; Method :" + locUrlPayload.method + "; Data :" + JSON.stringify(locUrlPayload.data) + ". ";
				try {
					urlopen.open(locUrlPayload, function(error, response) {
						if (error) {
							var errorinfo = "qsms_Location_005:url connection error with 'locUrlPayload' , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", '500');
							logger.error("qsms_Location_005:url connection error with 'locUrlPayload'" + error);
							session.reject("qsms_Location_005:url connection error with 'locUrlPayload'" + error);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200 || responseStatusCode == 201) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "qsms_Location_006:error reading response 'locUrlPayload' , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", '500');
										logger.error("qsms_Location_006:error reading response 'locUrlPayload'" + error);
										session.reject("qsms_Location_006:error reading response 'locUrlPayload'" + error);
									} else {
										hm.response.statusCode = responseStatusCode;
										var totalResultFound = responseData.totalResultFound;
										ctx.setVar("locResponse", responseData);
										ctx.setVar("totalResultFound", totalResultFound);
										if (totalResultFound > 0) {
											ctx.setVar("Identifier", responseData.results[0].Identifier);
										}
									}
								});
							} else {
								response.readAsBuffer(function(error, errorresponseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										var errorinfo = "qsms_Location_007:error in reading error response received from locUrlPayload , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", '500');
										logger.error("qsms_Location_007:error in reading error response received from locUrlPayload : " + error);
										session.reject("qsms_Location_007:error in reading error response received from locUrlPayload : " + error);
									} else {
										hm.response.statusCode = responseStatusCode;
										var errorinfo = "qsms_Location_008:error response received from locUrlPayload " + responseStatusCode + " , details are : " + info + "; errorresponseinfo :" + errorresponseData;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", responseStatusCode);
										logger.error("qsms_Location_008:error response received from locUrlPayload : " + responseStatusCode + " " + errorresponseData);
										session.reject("qsms_Location_008:error response received from locUrlPayload : " + responseStatusCode + " " + errorresponseData);
									}
								});
							}
						}
					});
				}
				catch (error) {
					var errorinfo = "qsms_Location_005:url connection error with 'locUrlPayload' , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatus", '500');
					logger.error("qsms_Location_005:url connection error with 'locUrlPayload'" + error);
					session.reject("qsms_Location_005:url connection error with 'locUrlPayload'" + error);
				}
			}
		}
		else {
			var errorinfo = "Location is missing in the payload";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", '500');
			logger.error("Location is missing in the payload");
			session.reject("Location is missing in the payload");
		}
	}
});
