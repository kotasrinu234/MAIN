var ctx = session.name("QSMS_WorkOrder_seq") || session.createContext("QSMS_WorkOrder_seq");
var urlopen = require('urlopen');
var ctx1 = session.name("QSMS") || session.createContext("QSMS");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var Id = ctx1.getVar("searchSessionId");
var key = session.parameters.key
var logger = console.options({ 'category': 'all' });
function callURL(url, method, myctx, payload) {
	var searchUrl = url + '/v1/search';
	var options = {
		target: searchUrl,
		method: method,
		headers: {
			"DWAYSessionId": Id,
			"subscriber": key
		},
		contentType: "application/json",
		sslClientProfile: "qsms_ClientProfile"
	};
	if (method == "POST" || method == "PUT") {
		options.data = payload;
	}
	var info = " TargetURL :" + options.target + "; Method :" + options.method + "; Data :" + JSON.stringify(payload) + ". ";
	try {
		urlopen.open(options, function(error, response) {
			if (error) {
				// an error occurred during reading the file
				var errorinfo = "qsms_workDetails_001:Url connection error , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatus", "500");
				logger.error("qsms_workDetails_001:Url connection error" + error);
				session.reject("qsms_workDetails_001:Url connection error" + error);
			} else {
				var responseStatusCode = response.statusCode;
				ctx.setVariable(myctx + "_responseStatusCode", responseStatusCode);
				ctx.setVariable(myctx + "_response", response);
				if (responseStatusCode == 200) {
					response.readAsJSON(function(error, data) {
						if (error) {
							var errorinfo = "qsms_workDetail_002:Error in reading response data , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", "500");
							logger.error("qsms_workDetail_002:Error in reading response data");
							session.reject("qsms_workDetail_002:Error in reading response data");
						} else {
							ctx.setVariable(myctx + '_response', data);
							var totalResultFound = data.totalResultFound
							if(totalResultFound === 0){
								
							}else{
								ctx.setVariable(myctx, data.results[0].Identifier);
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "qsms_workDetail_003:failure in reading message , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", "500");
							logger.error("qsms_workDetail_003:failure in reading message" + JSON.stringify(error));
							session.reject("qsms_workDetail_003:failure in reading message" + JSON.stringify(error));
						} else {
							var errorinfo = "qsms_workDetail_004:error response received with responseStatusCode " + responseStatusCode + " , details are : " + info + "; errorresponseinfo :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", responseStatusCode);
							ctx.setVariable(myctx + '_buffer_response', "" + responseData);
							logger.error("qsms_workDetail_004:error response received with responseStatusCode " + responseStatusCode + " " + responseData);
							session.reject("qsms_workDetail_004:error response received with responseStatusCode " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "qsms_workDetails_001:Url connection error , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		ilsctx.setVariable("errorStatus", "500");
		logger.error("qsms_workDetails_001:Url connection error" + error);
		session.reject("qsms_workDetails_001:Url connection error" + error);
	}
}
module.exports = callURL;
