var ctx = session.name("QSMS_WorkOrder_seq") || session.createContext("QSMS_WorkOrder_seq");
var urlopen = require('urlopen');
var planImpact = ctx.getVar("DTE_PLANTIMPACT");
var unitCenter = ctx.getVar("DTE_UNIT_CENTER");
var personGroup = ctx.getVar("PERSONGROUP");
var subType = ctx.getVar("DTE_SUBTYPE");
var workType = ctx.getVar("WORKTYPE");
var jobType = ctx.getVar("DTE_JOBTYPE");
var priority = ctx.getVar("WOPRIORITY");
var uniqueCRID = ctx.getVar("DTE_UNIQUECRID");
var url = session.parameters.searchSessionUrl;
var callURL = require('./qsms_WordOrder_callUrl.js');
var queries = [];
var logger = console.options({
	'category': 'all'
});
var payload = {
	"modules": [
		session.parameters.moduleRF
	],
	"returnFields": [
		"_Identifier",
		"Identifier",
		"_LastUpdatedOn",
		"_CreatedOn",
		"Name"
	],
	"query": {
		"condition": "equals",
		"field": "Name",
		"type": "strict",
		"term": [
			"WO Exists"
		]
	},
	"sort": "_LastUpdatedOn desc",
	"excludeIncludeAlways": true,
	"includeUnreadCount": false,
	"size": 1,
	"page": 0
}
callURL(url, "POST", "OSCDisposition_Identifier", payload);
if (planImpact) {
	if (planImpact == '' || planImpact == null || planImpact == undefined) { }
	else {
		var payload = {
			"modules": [
				session.parameters.moduleRF
			],
			"returnFields": [
				"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
			],
			"query": {
				"condition": "equals",
				"field": "Name",
				"type": "strict",
				"term": [
					planImpact
				]
			},
			"sort": "_LastUpdatedOn desc",
			"excludeIncludeAlways": true,
			"includeUnreadCount": false,
			"size": 1,
			"page": 0
		}
		callURL(url, "POST", "planImpactIdentifier", payload);
	}
}
if (unitCenter) {
	if (unitCenter == '' || unitCenter == null || unitCenter == undefined) { }
	else {
		var payload = {
			"modules": [
				session.parameters.moduleRF
			],
			"returnFields": [
				"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
			],
			"query": {
				"condition": "equals",
				"field": "Name",
				"type": "strict",
				"term": [
					unitCenter
				]
			},
			"sort": "_LastUpdatedOn desc",
			"excludeIncludeAlways": true,
			"includeUnreadCount": false,
			"size": 1,
			"page": 0
		}
		callURL(url, "POST", "unitCenterIdentifier", payload);
	}
}
if (personGroup) {
	if (personGroup == '' || personGroup == null || personGroup == undefined) { }
	else {
		var payload = {
			"modules": [
				session.parameters.moduleRF
			],
			"returnFields": [
				"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
			],
			"query": {
				"condition": "equals",
				"field": "Name",
				"type": "strict",
				"term": [
					personGroup
				]
			},
			"sort": "_LastUpdatedOn desc",
			"excludeIncludeAlways": true,
			"includeUnreadCount": false,
			"size": 1,
			"page": 0
		}
		callURL(url, "POST", "personGroupIdentifier", payload);
	}
}
if (subType) {
	if (subType == '' || subType == null || subType == undefined) { }
	else {
		var payload = {
			"modules": [
				session.parameters.moduleWOSUB
			],
			"returnFields": [
				"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
			],
			"query": {
				"condition": "equals",
				"field": "Name",
				"type": "strict",
				"term": [
					subType
				]
			},
			"sort": "_LastUpdatedOn desc",
			"excludeIncludeAlways": true,
			"includeUnreadCount": false,
			"size": 1,
			"page": 0
		}
		callURL(url, "POST", "subTypeIdentifier", payload);
	}
}
if (workType) {
	if (workType == '' || workType == null || workType == undefined) { }
	else {
		var payload = {
			"modules": [
				session.parameters.moduleWOTYP
			],
			"returnFields": [
				"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
			],
			"query": {
				"condition": "equals",
				"field": "Name",
				"type": "strict",
				"term": [
					workType
				]
			},
			"sort": "_LastUpdatedOn desc",
			"excludeIncludeAlways": true,
			"includeUnreadCount": false,
			"size": 1,
			"page": 0
		}
		callURL(url, "POST", "workTypeIdentifier", payload);
	}
}
if (jobType) {
	if (jobType == '' || jobType == null || jobType == undefined) { }
	else {
		var payload = {
			"modules": [
				session.parameters.moduleRF
			],
			"returnFields": [
				"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
			],
			"query": {
				"condition": "equals",
				"field": "Name",
				"type": "strict",
				"term": [
					jobType
				]
			},
			"sort": "_LastUpdatedOn desc",
			"excludeIncludeAlways": true,
			"includeUnreadCount": false,
			"size": 1,
			"page": 0
		}
		callURL(url, "POST", "jobTypeIdentifier", payload);
	}
}

if (priority) {
	if (priority == '' || priority == null || priority == undefined) { }
	else {
		var payload = {
			"modules": [
				session.parameters.moduleRF
			],
			"returnFields": [
				"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
			],
			"query": {
				"condition": "equals",
				"field": "Name",
				"type": "strict",
				"term": [
					priority
				]
			},
			"sort": "_LastUpdatedOn desc",
			"excludeIncludeAlways": true,
			"includeUnreadCount": false,
			"size": 1,
			"page": 0
		}
		callURL(url, "POST", "priorityIdentifier", payload);
	}
}
if (uniqueCRID) {
	if (uniqueCRID == '' || uniqueCRID == null || uniqueCRID == undefined) { }
	else {
		var payload = {
			"modules": [
				session.parameters.moduleCR
			],
			"returnFields": [
				"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
			],
			"query": {
				"condition": "equals",
				"field": "Identifier",
				"type": "strict",
				"term": [
					uniqueCRID
				]
			},
			"sort": "_LastUpdatedOn desc",
			"excludeIncludeAlways": true,
			"includeUnreadCount": false,
			"size": 1,
			"page": 0
		}
		callURL(url, "POST", "uniqueCRIDIdentifier", payload);
	}
}
