var ctx = session.name("QSMS_WorkOrder_seq") || session.createContext("QSMS_WorkOrder_seq");
var desc = ctx.getVar("DESCRIPTION");
var planImpactIdentifier = ctx.getVar("planImpactIdentifier");
var unitCenterIdentifier = ctx.getVar("unitCenterIdentifier");
var status = ctx.getVar("STATUS");
var personGroupIdentifier = ctx.getVar("personGroupIdentifier");
var OSCDisposition_Identifier = ctx.getVar("OSCDisposition_Identifier");
var subTypeIdentifier = ctx.getVar("subTypeIdentifier");
var workTypeIdentifier = ctx.getVar("workTypeIdentifier");
var jobTypeIdentifier = ctx.getVar("jobTypeIdentifier");
var location = ctx.getVar("LOCATION");
var woNum = ctx.getVar("WONUM");
var priorityIdentifier = ctx.getVar("priorityIdentifier");
var uniqueCRIDIdentifier = ctx.getVar("uniqueCRIDIdentifier");
var system = ctx.getVar("DTE_SYSTEM");
var finalPayload = {};
var logger = console.options({
	'category': 'all'
});
var moduleRF = session.parameters.moduleRF;
var moduleCR = session.parameters.moduleCR;
var commonPayload = {
	"Description": desc,
	"WorkOrderStatus": status,
	"Location": location,
	"ReportingAuthority": session.parameters.RAuth,
	"WorkOrderNumber": woNum,
	"Status": "Active",
	"SystemTie": system
}
finalPayload = {
	...finalPayload,
	...commonPayload
}
if (OSCDisposition_Identifier) {
	if (!(OSCDisposition_Identifier === null && OSCDisposition_Identifier === undefined && OSCDisposition_Identifier === '')) {
		var OSCDispositionPayload = {
			"OSCDisposition": {
				"Identifier": OSCDisposition_Identifier,
				"ModuleCode": moduleRF
			}
		}
		finalPayload = {
			...finalPayload,
			...OSCDispositionPayload
		};
	}
}
if (planImpactIdentifier) {
	if (!(planImpactIdentifier === null && planImpactIdentifier === undefined && planImpactIdentifier === '')) {
		var planImpactPayload = {
			"PlantImpact": {
				"Identifier": planImpactIdentifier,
				"ModuleCode": moduleRF
			}
		}
		finalPayload = {
			...finalPayload,
			...planImpactPayload
		};
	}
}
if (unitCenterIdentifier) {
	if (!(unitCenterIdentifier === null && unitCenterIdentifier === undefined && unitCenterIdentifier === '')) {
		var unitCenterPayload = {
			"Unit": {
				"Identifier": unitCenterIdentifier,
				"ModuleCode": moduleRF
			}
		}
		finalPayload = {
			...finalPayload,
			...unitCenterPayload
		};
	}
}

if (personGroupIdentifier) {
	if ((personGroupIdentifier === null) || (personGroupIdentifier === undefined) || (personGroupIdentifier === '')) {}
	else{
		var personGroupPayload = {
			"WorkGroup2": {
				"Identifier": personGroupIdentifier,
				"ModuleCode": moduleRF
			}
		}
		finalPayload = {
			...finalPayload,
			...personGroupPayload
		};
	}
}

if (subTypeIdentifier) {
	if (!(subTypeIdentifier === null && subTypeIdentifier === undefined && subTypeIdentifier === '')) {
		var moduleWOSUB = session.parameters.moduleWOSUB;
		var subTypePayload = {
			"SubType": {
				"Identifier": subTypeIdentifier,
				"ModuleCode": moduleWOSUB
			}
		}
		finalPayload = {
			...finalPayload,
			...subTypePayload
		};
	}
}
if (workTypeIdentifier) {
	if (!(workTypeIdentifier === null && workTypeIdentifier === undefined && workTypeIdentifier === '')) {
		var moduleWOTYP = session.parameters.moduleWOTYP;
		var workTypePayload = {
			"WorkType": {
				"Identifier": workTypeIdentifier,
				"ModuleCode": moduleWOTYP
			}
		}
		finalPayload = {
			...finalPayload,
			...workTypePayload
		};
	}
}
if (jobTypeIdentifier) {
	if (!(jobTypeIdentifier === null && jobTypeIdentifier === undefined && jobTypeIdentifier === '')) {
		var jobTypePayload = {
			"JobType2": {
				"Identifier": jobTypeIdentifier,
				"ModuleCode": moduleRF
			}
		}
		finalPayload = {
			...finalPayload,
			...jobTypePayload
		};
	}
}
if (priorityIdentifier) {
	if (!(priorityIdentifier === null && priorityIdentifier === undefined && priorityIdentifier === '')) {
		var priorityPayload = {
			"WorkOrderPriority": {
				"Identifier": priorityIdentifier,
				"ModuleCode": moduleRF
			}
		};
		finalPayload = {...finalPayload, ...priorityPayload};
	}
}
if (uniqueCRIDIdentifier) {
	if (!(uniqueCRIDIdentifier === null && uniqueCRIDIdentifier === undefined && uniqueCRIDIdentifier === '')) {
		var uniqueCRIDPayload = {
			"ConditionReport2": {
				"Identifier": uniqueCRIDIdentifier,
				"ModuleCode": moduleCR
			}
		};
		finalPayload = {...finalPayload, ...uniqueCRIDPayload};
	}
}

session.output.write(finalPayload);
ctx.setVar("finalPayload", finalPayload);
