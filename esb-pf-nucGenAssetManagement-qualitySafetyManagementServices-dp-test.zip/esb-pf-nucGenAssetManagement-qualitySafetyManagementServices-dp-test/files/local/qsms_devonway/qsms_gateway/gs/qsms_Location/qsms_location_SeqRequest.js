var ctx = session.name("QSMS_Location_seq") || session.createContext("QSMS_Location_seq");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
var dateTime = new Date();
var currentTime = dateTime.toISOString();
var EventTimeStamp = ctx.getVariable("EventTimeStamp");
var eventContext = ctx.getVariable("eventContext");
var ESTTimeStamp = DateConversion(EventTimeStamp);
var deflatedPayload = ctx.getVariable("deflatedPayload");
var seqPayload =
{
	"messageId": ctx.getVariable("messageId"),
	"serviceName": "QualitySafetyManagementSystem",
	"expiry": session.parameters.expiry,
	"eventType": "locationEvent",
	"eventContext": eventContext,
	"payload": deflatedPayload,
	"EventTimeStamp": ESTTimeStamp,
	"sendTimeStamp": currentTime,
	"waitTime": session.parameters.waitTime,
	"messageType": "locationEvent",
	"destQueueName": 'QSMS.LOCATION.RECEIVE.SEQ'
}
var StandaloneMQurl = session.parameters.SequenceUrl;
ilsctx.setVar("exitDestination", StandaloneMQurl)
session.output.write(seqPayload)
var publishuri = {
	target: StandaloneMQurl,
	data: seqPayload
};
var info = " TargetURL :" + publishuri.target + "; Data :" + JSON.stringify(publishuri.data) + ". ";
try {
	urlopen.open(publishuri, function(error, response) {
		var hm = require('header-metadata');
		if (error) {
			var mqconnection = 'Forbidden';
			ctx.setVariable("mqconnection", mqconnection);
			var errorinfo = "qsms_Location_001: url connection error 'Sequence Request' , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("qsms_Location_001: url connection error 'Sequence Request'" + error);
			session.reject("qsms_Location_001: url connection error 'Sequence Request'" + error);
		} else {
			var mqrc = response.statusCode;
			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						var errorinfo = "qsms_Location_002 : error reading in response from 'Sequence Request' , details are : " + info + "; error info :" + readError;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", "500");
						logger.error("qsms_Location_002 : error reading in response from 'Sequence Request'" + readError);
						session.reject("qsms_Location_002 : error reading in response from 'Sequence Request'" + readError);

					} else {
						logger.debug("MQResponsecode " + mqrc);
						ctx.setVar("response", responseData);
					}
				});
			} else {
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						var errorinfo = "qsms_Location_003:error in reading error response 'Sequence Request' , details are : " + info + "; error info :" + readError;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", "500");
						logger.error("qsms_Location_003:error in reading error response 'Sequence Request'" + readError);
						session.reject("qsms_Location_003:error in reading error response 'Sequence Request'" + readError);
					} else {
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						var errorinfo = "qsms_Location_004:error response received from 'Sequence Request'" + mqrc + " , details are : " + info + "; errorresponse :" + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", mqrc);
						logger.error("qsms_Location_004:error response received from 'Sequence Request'" + readError);
						session.reject("qsms_Location_004:error response received from 'Sequence Request'" + readError);
					}
				});
			}
		}
		//pushing to queue end
	});
}
catch (error) {
	var mqconnection = 'Forbidden';
	ctx.setVariable("mqconnection", mqconnection);
	var errorinfo = "qsms_Location_001: url connection error 'Sequence Request' , details are : " + info + "; error info :" + error;
	ilsctx.setVariable("errorDescription", errorinfo);
	ilsctx.setVariable("errorStatus", "500");
	logger.error("qsms_Location_001: url connection error 'Sequence Request'" + error);
	session.reject("qsms_Location_001: url connection error 'Sequence Request'" + error);
}
function DateConversion(incomingDateTime) {
	var finalutcDate;
	var ctx = session.name("QSMS_Location_seq") || session.createContext("QSMS_Location_seq");
	var ESTDate = new Date(incomingDateTime).toISOString();
	ctx.setVariable("ESTDate", ESTDate);
	var finalutcDate = ESTDate;
	return finalutcDate;
}