<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
	<xsl:template match="/">
		<xsl:variable name="payload">
			<dp:serialize select="." omit-xml-decl="yes"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/deflatedPayload'" value="string(dp:deflate($payload))"/>
	</xsl:template>
</xsl:stylesheet>