<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
	<xsl:param name="dpconfig:workDetailEntryDescription"
		select="''" />
		<xsl:param name="dpconfig:exitDescription"
		select="''" />
		<xsl:param name="dpconfig:workDetailMessageType"
		select="''" />
	<xsl:template match="/">
	<xsl:variable name="entryDescription">
			<xsl:value-of
				select="$dpconfig:workDetailEntryDescription" />
		</xsl:variable>
		<xsl:variable name="exitDescription">
			<xsl:value-of
				select="$dpconfig:exitDescription" />
		</xsl:variable>
		<xsl:variable name="messageType">
			<xsl:value-of
				select="$dpconfig:workDetailMessageType" />
		</xsl:variable>
		<dp:set-variable name="'var://context/ILS/entryDescription'" value="string($entryDescription)"/>
		<dp:set-variable name="'var://context/ILS/exitDescription'" value="string($exitDescription)"/>
		<dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)"/>
		<xsl:variable name="IncomingPayload">
			<xsl:copy-of select="."/>
		</xsl:variable>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/@*[local-name()='messageID']) &gt; 0">
			<xsl:variable name="messageId" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/@*[local-name()='messageID']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/messageId'" value="string($messageId)"/>
			<dp:set-variable name="'var://context/ILS/messageId'" value="string($messageId)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM']) &gt; 0">
			<xsl:variable name="eventContext" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/eventContext'" value="string($eventContext)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/@*[local-name()='creationDateTime']) &gt; 0">
			<xsl:variable name="EventTimeStamp" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/@*[local-name()='creationDateTime']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/EventTimeStamp'" value="string($EventTimeStamp)"/>
			<dp:set-variable name="'var://context/ILS/EventTimeStamp'" value="string($EventTimeStamp)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DESCRIPTION']) &gt; 0">
			<xsl:variable name="DESCRIPTION" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DESCRIPTION']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/DESCRIPTION'" value="string($DESCRIPTION)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_PLANTIMPACT']) &gt; 0">
			<xsl:variable name="DTE_PLANTIMPACT" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_PLANTIMPACT']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/DTE_PLANTIMPACT'" value="string($DTE_PLANTIMPACT)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_UNIT_CENTER']) &gt; 0">
			<xsl:variable name="DTE_UNIT_CENTER" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_UNIT_CENTER']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/DTE_UNIT_CENTER'" value="string($DTE_UNIT_CENTER)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='STATUS']) &gt; 0">
			<xsl:variable name="STATUS" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='STATUS']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/STATUS'" value="string($STATUS)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='PERSONGROUP']) &gt; 0">
			<xsl:variable name="PERSONGROUP" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='PERSONGROUP']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/PERSONGROUP'" value="string($PERSONGROUP)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='MAXINTERRORMSG']) &gt; 0">
			<xsl:variable name="MAXINTERRORMSG" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='MAXINTERRORMSG']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/MAXINTERRORMSG'" value="string($MAXINTERRORMSG)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_SUBTYPE']) &gt; 0">
			<xsl:variable name="DTE_SUBTYPE" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_SUBTYPE']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/DTE_SUBTYPE'" value="string($DTE_SUBTYPE)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='WORKTYPE']) &gt; 0">
			<xsl:variable name="WORKTYPE" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='WORKTYPE']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/WORKTYPE'" value="string($WORKTYPE)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_JOBTYPE']) &gt; 0">
			<xsl:variable name="DTE_JOBTYPE" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_JOBTYPE']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/DTE_JOBTYPE'" value="string($DTE_JOBTYPE)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='LOCATION']) &gt; 0">
			<xsl:variable name="LOCATION" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='LOCATION']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/LOCATION'" value="string($LOCATION)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='SITEID']) &gt; 0">
			<xsl:variable name="SITEID" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='SITEID']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/SITEID'" value="string($SITEID)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM']) &gt; 0">
			<xsl:variable name="WONUM" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='WONUM']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/WONUM'" value="string($WONUM)"/>
			<dp:set-variable name="'var://context/ILS/WONUM'" value="string($WONUM)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='WOPRIORITY']) &gt; 0">
			<xsl:variable name="WOPRIORITY" select="/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='WOPRIORITY']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/WOPRIORITY'" value="string($WOPRIORITY)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='LOCATIONS']/*[local-name()='DTE_SYSTEM']) &gt; 0">
			<xsl:variable name="DTE_SYSTEM" select="/*[local-name(
		)='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='LOCATIONS']/*[local-name()='DTE_SYSTEM']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/DTE_SYSTEM'" value="string($DTE_SYSTEM)"/>
		</xsl:if>
		<xsl:if test="string-length(/*[local-name()='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_CR']/*[local-name()='DTE_UNIQUECRID']) &gt; 0">
			<xsl:variable name="DTE_UNIQUECRID" select="/*[local-name(
		)='PublishDTEFERMIDVNWYWO']/*[local-name()='DTEFERMIDVNWYWOSet']/*[local-name()='WORKORDER']/*[local-name()='DTE_CR']/*[local-name()='DTE_UNIQUECRID']"/>
			<dp:set-variable name="'var://context/QSMS_WorkOrder_seq/DTE_UNIQUECRID'" value="string($DTE_UNIQUECRID)"/>
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>
