<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
	<xsl:param name="dpconfig:locationEntryDescription"
		select="''" />
		<xsl:param name="dpconfig:exitDescription"
		select="''" />
		<xsl:param name="dpconfig:locMessageType"
		select="''" />
	<xsl:template match="/">
		<xsl:variable name="IncomingPayload">
			<xsl:copy-of select="."/>
		</xsl:variable>
		<xsl:variable name="entryDescription">
			<xsl:value-of
				select="$dpconfig:locationEntryDescription" />
		</xsl:variable>
		<xsl:variable name="exitDescription">
			<xsl:value-of
				select="$dpconfig:exitDescription" />
		</xsl:variable>
		<xsl:variable name="messageType">
			<xsl:value-of
				select="$dpconfig:locMessageType" />
		</xsl:variable>
		<xsl:variable name="messageId" select="/*[local-name()='PublishDTEFERMILOCDVW']/@*[local-name()='messageID']"/>
		<xsl:variable name="eventContext" select="/*[local-name()='PublishDTEFERMILOCDVW']/*[local-name()='DTEFERMILOCDVWSet']/*[local-name()='LOCATIONS']/*[local-name()='LOCATION']"/>
		<xsl:variable name="EventTimeStamp" select="/*[local-name()='PublishDTEFERMILOCDVW']/@*[local-name()='creationDateTime']"/>
		<dp:set-variable name="'var://context/QSMS_Location_seq/messageId'" value="string($messageId)"/>
		<dp:set-variable name="'var://context/QSMS_Location_seq/eventContext'" value="string($eventContext)"/>
		<dp:set-variable name="'var://context/QSMS_Location_seq/EventTimeStamp'" value="string($EventTimeStamp)"/>
		<dp:set-variable name="'var://context/ILS/messageId'" value="string($messageId)"/>
		<dp:set-variable name="'var://context/ILS/eventContext'" value="string($eventContext)"/>
		<dp:set-variable name="'var://context/ILS/EventTimeStamp'" value="string($EventTimeStamp)"/>
		<dp:set-variable name="'var://context/ILS/entryDescription'" value="string($entryDescription)"/>
		<dp:set-variable name="'var://context/ILS/exitDescription'" value="string($exitDescription)"/>
		<dp:set-variable name="'var://context/ILS/messageType'" value="string($messageType)"/>
		<xsl:variable name="payload">
			<dp:serialize select="." omit-xml-decl="yes"/>
		</xsl:variable>
		<dp:set-variable name="'var://context/QSMS_Location_seq/deflatedPayload'" value="dp:deflate($payload)"/>
	</xsl:template>
</xsl:stylesheet>