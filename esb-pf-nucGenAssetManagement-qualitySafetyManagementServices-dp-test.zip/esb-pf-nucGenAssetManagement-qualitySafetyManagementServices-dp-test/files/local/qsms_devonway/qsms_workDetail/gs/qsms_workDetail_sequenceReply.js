var ctx = session.name("QSMS_workDetail") || session.createContext("QSMS_workDetail");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({ 'category': 'all' });
var dateTime = new Date();
var currentTime = dateTime.toISOString();
var eventContext = ctx.getVariable("eventContext");
var seqConfPayload =
{
	"messageId": ctx.getVariable("messageId"),
	"eventType": ctx.getVariable("eventType"),
	"eventContext": eventContext,
	"serviceName": ctx.getVariable("serviceName"),
	"EventTimeStamp": ctx.getVariable("EventTimeStamp"),
	"sendTimeStamp": currentTime,
	"messageType": ctx.getVariable("messageType"),
	"confirmation": 'Y'
}
var StandaloneMQurl = session.parameters.QSMS_workDetail_SeqConfUrl;
var publishuri = {
	target: StandaloneMQurl,
	data: seqConfPayload
};
var info = " TargetURL :" + publishuri.target + "; Data :" + JSON.stringify(publishuri.data) + ". ";
try {
	urlopen.open(publishuri, function(error, response) {
		var hm = require('header-metadata');
		if (error) {
			var mqconnection = 'Forbidden';
			ctx.setVariable("mqconnection", mqconnection);
			var errorinfo = "qsms_workDetail_017:url connection error 'Sequence Request' , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("qsms_workDetail_017:url connection error 'Sequence Request'" + error);
			session.reject("qsms_workDetail_017:url connection error 'Sequence Request'" + error);
		} else {
			var mqrc = response.statusCode;
			if (mqrc == 0) {
				var replyMQMD = response.get({
					type: 'mq'
				}, 'MQMD');
				var replyMQRFH2 = response.get({
					type: 'mq'
				}, 'MQRFH2');
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						var errorinfo = "qsms_workDetail_018:error reading in response from 'Sequence Request' , details are : " + info + "; error info :" + readError;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", "500");
						logger.error("qsms_workDetail_018:error reading in response from 'Sequence Request'" + readError);
						session.reject("qsms_workDetail_018:error reading in response from 'Sequence Request'" + readError);

					} else {
						logger.debug("MQResponsecode " + mqrc);
						ctx.setVar("response", responseData);
					}
				});
			} else {
				response.readAsBuffer(function(readError, responseData) {
					if (readError) {
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						var errorinfo = "qsms_workDetail_019:error in reading error response 'Sequence Request' , details are : " + info + "; error info :" + readError;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", "500");
						logger.error("qsms_workDetail_019:error in reading error response 'Sequence Request'" + readError);
						session.reject("qsms_workDetail_019:error in reading error response 'Sequence Request'" + readError);
					} else {
						var mqconnection = 'Forbidden';
						ctx.setVariable("mqconnection", mqconnection);
						var errorinfo = "qsms_workDetail_020:error response received from 'Sequence Request' " + mqrc + " , details are : " + info + "; errorresponseinfo :" + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", mqrc);
						logger.error("qsms_workDetail_020:error response received from 'Sequence Request'" + responseData);
						session.reject("qsms_workDetail_020:error response received from 'Sequence Request'" + responseData);
					}
				});
			}
		}
		//pushing to queue end
	});
}
catch (error) {
	var mqconnection = 'Forbidden';
	ctx.setVariable("mqconnection", mqconnection);
	var errorinfo = "qsms_workDetail_017:url connection error 'Sequence Request' , details are : " + info + "; error info :" + error;
	ilsctx.setVariable("errorDescription", errorinfo);
	ilsctx.setVariable("errorStatus", "500");
	logger.error("qsms_workDetail_017:url connection error 'Sequence Request'" + error);
	session.reject("qsms_workDetail_017:url connection error 'Sequence Request'" + error);
}
