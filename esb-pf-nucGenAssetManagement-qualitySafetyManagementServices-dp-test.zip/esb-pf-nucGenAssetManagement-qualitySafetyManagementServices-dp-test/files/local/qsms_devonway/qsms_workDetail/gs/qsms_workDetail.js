var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("QSMS_workDetail") || session.createContext("QSMS_workDetail");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var ctx1 = session.name("QSMS") || session.createContext("QSMS");
var searchSessionId = ctx1.getVar("searchSessionId");
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		if (incomingdata.WorkOrderNumber) {
			var workOrderNum = incomingdata.WorkOrderNumber;
			if (workOrderNum !== null || workOrderNum !== '' || workOrderNum !== undefined) {
				var payload = {
					"modules": [
						"DTE-WO"
					],
					"returnFields": [
						"_Identifier", "Identifier", "_LastUpdatedOn", "_CreatedOn", "Name"
					],
					"query": {
						"condition": "equals",
						"field": "WorkOrderNumber",
						"type": "strict",
						"term": [
							workOrderNum
						]
					},
					"sort": "_LastUpdatedOn desc",
					"excludeIncludeAlways": true,
					"includeUnreadCount": false,
					"size": 1,
					"page": 0
				}
				var Url = session.parameters.searchSessionUrl;
				var workUrl = Url + '/v1/search';
				var workUrlPayload = {
					target: workUrl,
					sslClientProfile: 'qsms_ClientProfile',
					method: 'POST',
					contentType: 'application/json',
					headers: {
						'DWAYSessionId': searchSessionId,
						'subscriber': session.parameters.key
					},
					data: payload
				};
				var info = " TargetURL :" + workUrlPayload.target + "; Method :" + workUrlPayload.method + "; Data :" + JSON.stringify(workUrlPayload.data) + ". ";
				try {
					urlopen.open(workUrlPayload, function(error, response) {
						if (error) {
							var errorinfo = "qsms_workDetail_009:url connection error with 'workUrlPayload' , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", "500");
							logger.error("qsms_workDetail_009:url connection error with 'workUrlPayload'" + error);
							session.reject("qsms_workDetail_009:url connection error with 'workUrlPayload'" + error);
						} else {
							var responseStatusCode = response.statusCode;
							if (responseStatusCode == 200 || responseStatusCode == 201) {
								response.readAsJSON(function(error, responseData) {
									if (error) {
										var errorinfo = "qsms_workDetail_010:error reading response 'workUrlPayload' , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "500");
										logger.error("qsms_workDetail_010:error reading response 'workUrlPayload'" + error);
										session.reject("qsms_workDetail_010:error reading response 'workUrlPayload'" + error);
									} else {
										hm.response.statusCode = responseStatusCode;
										if (responseData == '' || responseData == null || responseData == undefined) { }
										else {
											ctx.setVar("workResponse", responseData);
											if (!(responseData.totalResultFound == '' && responseData.totalResultFound == null && responseData.totalResultFound == undefined)) {
												ctx.setVar("totalResultFound", responseData.totalResultFound);
												if (responseData.totalResultFound == 0) { }
												else {
													ctx.setVar("Identifier", responseData.results[0].Identifier);
												}
											}
										}
									}
								});
							} else {
								response.readAsBuffer(function(error, errorresponseData) {
									if (error) {
										//dp:reject stop the transaction and go error rule with error code and description
										var errorinfo = "qsms_workDetail_011:error in reading error response received from workUrlPayload , details are : " + info + "; error info :" + error;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "500");
										logger.error("qsms_workDetail_011:error in reading error response received from workUrlPayload : " + error);
										session.reject("qsms_workDetail_011:error in reading error response received from workUrlPayload : " + error);
									} else {
										hm.response.statusCode = responseStatusCode;
										var errorinfo = "qsms_workDetail_012:error response received from workUrlPayload " + responseStatusCode + " , details are : " + info + "; errorresponseinfo :" + errorresponseData;
										ilsctx.setVariable("errorDescription", errorinfo);
										ilsctx.setVariable("errorStatus", "500");
										logger.error("qsms_workDetail_012:error response received from workUrlPayload : " + responseStatusCode + " " + errorresponseData);
										session.reject("qsms_workDetail_012:error response received from workUrlPayload : " + responseStatusCode + " " + errorresponseData);
									}
								});
							}
						}
					});
				}
				catch (error) {
					var errorinfo = "qsms_workDetail_009:url connection error with 'workUrlPayload' , details are : " + info + "; error info :" + error;
					ilsctx.setVariable("errorDescription", errorinfo);
					ilsctx.setVariable("errorStatus", "500");
					logger.error("qsms_workDetail_009:url connection error with 'workUrlPayload'" + error);
					session.reject("qsms_workDetail_009:url connection error with 'workUrlPayload'" + error);
				}
			}
		}
		else {
			var errorinfo = "workOrderNumber is missing from the input payload ";
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("workOrderNumber is missing from the input payload");
			session.reject("workOrderNumber is missing from the input payload");
		}
	}
});
