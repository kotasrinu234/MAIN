var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("QSMS_workDetail") || session.createContext("QSMS_workDetail");
var ctx1 = session.name("QSMS") || session.createContext("QSMS");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var Id = ctx1.getVar("Id");
var totalResultFound = ctx.getVar("totalResultFound");
var Identifier = ctx.getVar("Identifier");
var devUrl;
var devUrlPayload = {};
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		var key = session.parameters.key;
		var url = session.parameters.devonwayUrl;
		if (totalResultFound !== 0) {
			var modifiedIdentifier = Identifier.replace(/ (\d{4})/g, "%20$1");
			devUrl = url + key + '/modules/DTE-WO/' + modifiedIdentifier;
			ilsctx.setVar("exitDestination", devUrl);
			ilsctx.setVar("exitDescription", session.parameters.exitDescriptionUpdate);
			devUrlCall(devUrl, incomingdata, 'put')
		}
		else {
			devUrl = url + key + '/modules/DTE-WO';
			ilsctx.setVar("exitDestination", devUrl);
			ilsctx.setVar("exitDescription", session.parameters.exitDescriptionCreate);
			devUrlCall(devUrl, incomingdata, 'post')
		}
	}
});
function devUrlCall(url, payload, method) {
	devUrlPayload = {
		target: url,
		sslClientProfile: 'qsms_ClientProfile',
		method: method,
		contentType: 'application/json',
		headers: {
			'DWAYSessionId': Id
		},
		data: payload
	};
	session.output.write(payload)
	var info = " TargetURL :" + devUrlPayload.target + "; Method :" + devUrlPayload.method + "; Data :" + JSON.stringify(devUrlPayload.data) + ". ";
	try {
		urlopen.open(devUrlPayload, function(error, response) {
			if (error) {
				var errorinfo = "qsms_workDetail_013:url connection error with 'devUrlPayload' , details are : " + info + "; error info :" + error;
				ilsctx.setVariable("errorDescription", errorinfo);
				ilsctx.setVariable("errorStatus", '500');
				logger.error("qsms_workDetail_013:url connection error with 'devUrlPayload'" + error);
				session.reject("qsms_workDetail_013:url connection error with 'devUrlPayload'" + error);
			} else {
				var responseStatusCode = response.statusCode;
				if (responseStatusCode == 200 || responseStatusCode == 201) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							var errorinfo = "qsms_workDetail_014:error reading response 'devUrlPayload' , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", '500');
							logger.error("qsms_workDetail_014:error reading response 'devUrlPayload'" + error);
							session.reject("qsms_workDetail_014:error reading response 'devUrlPayload'" + error);
						} else {
							hm.response.statusCode = responseStatusCode;
							if (!(responseData == '' || responseData == null || responseData == undefined)) {
								ctx.setVar("devResponse", responseData);
							}
							else {
							}
							if (!(totalResultFound == '' || totalResultFound == null || totalResultFound == undefined)) {
								if (totalResultFound == 0) {
									var errorDescriptionCreate = session.parameters.errorDescriptionCreate
									if (errorDescriptionCreate == '' || errorDescriptionCreate == null || errorDescriptionCreate == undefined) {

									}
									else {
										ctx.setVar("errorDescription", session.parameters.errorDescriptionCreate);
									}

								}
								else {
									var errorDescriptionUpdate = session.parameters.errorDescriptionUpdate
									if (errorDescriptionUpdate == '' || errorDescriptionUpdate == null || errorDescriptionUpdate == undefined) {

									}
									else {
										ctx.setVar("errorDescription", session.parameters.errorDescriptionUpdate);
									}
								}
							}
						}
					});
				} else {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							//dp:reject stop the transaction and go error rule with error code and description
							var errorinfo = "qsms_workDetail_015:error in reading error response received from devUrlPayload , details are : " + info + "; error info :" + error;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", '500');
							logger.error("qsms_workDetail_015:error in reading error response received from devUrlPayload : " + error);
							session.reject("qsms_workDetail_015:error in reading error response received from devUrlPayload : " + error);
						} else {
							hm.response.statusCode = responseStatusCode;
							var errorinfo = "qsms_workDetail_016:error response received from devUrlPayload " + responseStatusCode + " , details are : " + info + "; errorresponseinfo :" + responseData;
							ilsctx.setVariable("errorDescription", errorinfo);
							ilsctx.setVariable("errorStatus", responseStatusCode);
							logger.error("qsms_workDetail_016:error response received from devUrlPayload : " + responseStatusCode + " " + responseData);
							session.reject("qsms_workDetail_016:error response received from devUrlPayload : " + responseStatusCode + " " + responseData);
						}
					});
				}
			}
		});
	}
	catch (error) {
		var errorinfo = "qsms_workDetail_013:url connection error with 'devUrlPayload' , details are : " + info + "; error info :" + error;
		ilsctx.setVariable("errorDescription", errorinfo);
		ilsctx.setVariable("errorStatus", '500');
		logger.error("qsms_workDetail_013:url connection error with 'devUrlPayload'" + error);
		session.reject("qsms_workDetail_013:url connection error with 'devUrlPayload'" + error);
	}
}
