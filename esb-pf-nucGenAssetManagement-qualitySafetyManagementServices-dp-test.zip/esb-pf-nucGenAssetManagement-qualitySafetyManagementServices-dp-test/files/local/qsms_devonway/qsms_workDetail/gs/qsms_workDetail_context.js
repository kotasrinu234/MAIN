var ctx = session.name("QSMS_workDetail") || session.createContext("QSMS_workDetail");
var entryDescription = session.parameters.entryDescription;
var exitDescription = session.parameters.exitDescription;
var logger = console.options({
	'category': 'all'
});
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		logger.error("Error in reading incoming data");
		session.reject(readAsJSONError);
	}
	else {
		if(incomingdata.WorkOrderNumber == '' || incomingdata.WorkOrderNumber == null || incomingdata.WorkOrderNumber == undefined){}
		else{
			ctx.setVar("woNum", incomingdata.WorkOrderNumber);
		}
		if(entryDescription == '' || entryDescription == null || entryDescription == undefined){}
		else{
			ctx.setVar("entryDescription", entryDescription);
		}
		if(exitDescription == '' || exitDescription == null || exitDescription == undefined){}
		else{
			ctx.setVar("exitDescription", exitDescription);
		}
	}
});