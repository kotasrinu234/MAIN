<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" xmlns:dpconfig="http://www.datapower.com/param/config" extension-element-prefixes="dp" exclude-result-prefixes="dp dpconfig">
	<xsl:output method="xml" indent="yes" omit-xml-declaration="yes"/>
	<xsl:template match="/">
		<xsl:variable name="payload">
			<dp:serialize select="." omit-xml-decl="yes"/>
		</xsl:variable>
		<xsl:variable name="errorStatus" select="dp:variable('var://context/ILS/errorStatus')"/>
		<xsl:variable name="errorDescription" select="dp:variable('var://context/ILS/errorDescription')"/>
		<xsl:variable name="errorPhrase" select="dp:variable('var://context/ILS/reasonPhrase')"/>
		<xsl:choose>
			<xsl:when test="$errorDescription">
				<dp:set-variable name="'var://context/ILS/errorDescription'" value="$errorDescription"/>
				<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="$errorPhrase"/>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/ILS/errorDescription'" value="dp:variable('var://service/error-message')"/>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="$errorStatus">
				<dp:set-variable name="'var://context/ILS/errorStatus'" value="$errorStatus"/>
				<dp:set-variable name="'var://service/error-protocol-response'" value="$errorStatus"/>
			</xsl:when>
			<xsl:otherwise>
				<dp:set-variable name="'var://context/ILS/errorStatus'" value="'500'"/>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:choose>
			<xsl:when test="contains(dp:variable('var://service/error-message'),'Rejected by policy')">
				<xsl:message dp:type="all" dp:priority="error">qsms_009 AAA failure for Maximo username : <xsl:value-of select="dp:variable('var://context/WSM/identity/username')"/> with Statuscode 401 unauthorized with ,TransactionID:<xsl:value-of select="$TransactionID"/> ErrorMessage:<xsl:value-of select="dp:variable('var://service/error-message')"/>
				</xsl:message>
				<dp:set-variable name="'var://context/ILS/errorDescription'" value="concat('qsms_009 : AAA failure for Maximo username : ', dp:variable('var://context/WSM/identity/username'), ' with Statuscode 401 unauthorized , TransactionID : ', dp:variable('var://service/global-transaction-id'), ', ErrorMessage: ', dp:variable('var://service/error-message'))"/>
				<dp:set-variable name="'var://context/ILS/errorStatus'" value="'401'"/>
				<dp:set-variable name="'var://service/error-protocol-response'" value="'401'"/>
				<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Unauthorized'"/>
			</xsl:when>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
