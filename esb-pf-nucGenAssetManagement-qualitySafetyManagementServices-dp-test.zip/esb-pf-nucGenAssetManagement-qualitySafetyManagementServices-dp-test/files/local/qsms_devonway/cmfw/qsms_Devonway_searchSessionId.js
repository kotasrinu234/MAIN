var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("QSMS") || session.createContext("QSMS");
var ilsctx = session.name('ILS') || session.createContext('ILS');
var logger = console.options({
	'category': 'all'
});
var url = session.parameters.searchSessionUrl;
var key = session.parameters.key;
var searchsessionIdUri = url + '/auth?subscriber=' + key;
var searchSessionId = {
	target: searchsessionIdUri,
	sslClientProfile: 'qsms_ClientProfile',
	method: 'POST',
	contentType: 'application/json'
};
var info = " TargetURL :" + searchSessionId.target + "; Method :" + searchSessionId.method + ". ";
try {
	urlopen.open(searchSessionId, function(error, response) {
		if (error) {
			var errorinfo = "qsms_001:urlopen connect error with searchSessionId , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("qsms_001:urlopen connect error with searchSessionId" + error);
			session.reject("qsms_001:urlopen connect error with searchSessionId" + error);
		} else {
			var responseStatusCode = response.statusCode;
			var responsePhrase = response.reasonPhrase;
			if (responseStatusCode === 200) {
				var Id = response.headers.DWAYSessionId;
				ctx.setVar("searchSessionId", Id);
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "qsms_002:failure in reading response from searchSessionId , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", "500");
						logger.error("qsms_002:failure in reading response from searchSessionId" + error);
						session.reject("qsms_002:failure in reading response from searchSessionId" + error);
					} else {
						hm.response.statusCode = responseStatusCode;
						ctx.setVar("response", responseData);
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "qsms_003:failure in reading message from searchSessionId for negative ack , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", responseStatusCode);
						ilsctx.setVariable("reasonPhrase", responsePhrase);
						logger.error("qsms_003:failure in reading message from searchSessionId for negative ack " + JSON.stringify(error));
						session.reject("qsms_003:failure in reading message from searchSessionId for negative ack " + error);
					} else {
						var errorinfo = "qsms_004:response received from searchSessionId for negative ack " + responseStatusCode + " , details are : " + info + "; errorresponseinfo :" + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", responseStatusCode);
						ilsctx.setVariable("reasonPhrase", responsePhrase);
						logger.error("qsms_004:response received from searchSessionId for negative ack " + " " + responseStatusCode + responseData);
						session.reject("qsms_004:response received from searchSessionId for negative ack " + " " + responseStatusCode + responseData);
					}
				});
			}
		}
	});
}
catch (error) {
	var errorinfo = "qsms_001:urlopen connect error with searchSessionId , details are : " + info + "; error info :" + error;
	ilsctx.setVariable("errorDescription", errorinfo);
	ilsctx.setVariable("errorStatus", "500");
	logger.error("qsms_001:urlopen connect error with searchSessionId" + error);
	session.reject("qsms_001:urlopen connect error with searchSessionId" + error);
}
