var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("QSMS") || session.createContext("QSMS");
var ilsctx = session.name("ILS") || session.createContext("ILS");
var logger = console.options({
	'category': 'all'
});
var key = session.parameters.key;
var sessionIdUri = 'https://rest-config.devonway.com/RESTConnect/rest/v2/subscribers/' + key;
var getSessionId = {
	target: sessionIdUri,
	sslClientProfile: 'qsms_ClientProfile',
	method: 'GET',
	contentType: 'application/json'
};
var info = " TargetURL :" + getSessionId.target + "; Method :" + getSessionId.method + ". ";
try {
	urlopen.open(getSessionId, function(error, response) {
		if (error) {
			var errorinfo = "qsms_005:urlopen connect error with getSessionId , details are : " + info + "; error info :" + error;
			ilsctx.setVariable("errorDescription", errorinfo);
			ilsctx.setVariable("errorStatus", "500");
			logger.error("qsms_005:urlopen connect error with getSessionId" + error);
			session.reject("qsms_005:urlopen connect error with getSessionId" + error);
		} else {
			var responseStatusCode = response.statusCode;
			if (responseStatusCode == 200) {
				var Id = response.headers.DWAYSessionId;
				ctx.setVar("Id", Id);
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "failure in reading message from CrewGetApi , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", "500");
						logger.error("qsms_006:failure in reading response from getSessionId" + error);
						session.reject("qsms_006:failure in reading response from getSessionId" + error);
					} else {
						hm.response.statusCode = responseStatusCode;
					}
				});
			} else {
				response.readAsBuffer(function(error, responseData) {
					if (error) {
						//dp:reject stop the transaction and go error rule with error code and description
						var errorinfo = "qsms_007:failure in reading message from getSessionId for negative ack , details are : " + info + "; error info :" + error;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", "500");
						logger.error("qsms_007:failure in reading message from getSessionId for negative ack " + JSON.stringify(error));
						session.reject("qsms_007:failure in reading message from getSessionId for negative ack " + error);
					} else {
						var errorinfo = "qsms_008:response received from getSessionId for negative ack " + responseStatusCode + " , details are : " + info + "; errorresponseinfo :" + responseData;
						ilsctx.setVariable("errorDescription", errorinfo);
						ilsctx.setVariable("errorStatus", responseStatusCode);
						logger.error("qsms_008:response received from getSessionId for negative ack " + " " + responseStatusCode + responseData);
						session.reject("qsms_008:response received from getSessionId for negative ack " + " " + responseStatusCode + responseData);
					}
				});
			}
		}
	});
}
catch (error) {
	var errorinfo = "qsms_005:urlopen connect error with getSessionId , details are : " + info + "; error info :" + error;
	ilsctx.setVariable("errorDescription", errorinfo);
	ilsctx.setVariable("errorStatus", "500");
	logger.error("qsms_005:urlopen connect error with getSessionId" + error);
	session.reject("qsms_005:urlopen connect error with getSessionId" + error);
}
