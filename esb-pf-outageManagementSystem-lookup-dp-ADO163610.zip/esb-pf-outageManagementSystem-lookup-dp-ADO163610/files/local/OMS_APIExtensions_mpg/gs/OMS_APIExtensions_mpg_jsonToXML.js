session.input.readAsBuffer(function(error,buffer){
    if (error) {
        session.output.write(error);
    } else {
/* var parsedInput = JSON.parse(json); */

var str = buffer.toString('utf8');
    var i = str.indexOf("<?xml ");
    if (i !== -1) {
      var j = str.substr(i).indexOf(">");
      str = str.substr(0, i) + str.substr(i+j+1);
    }
    var i = str.indexOf("&lt;?xml ");
    if (i !== -1) {
      var j = str.substr(i).indexOf("?&gt;");
      str = str.substr(0, i) + str.substr(i+j+5);
    }
var xmlRbuffer = str.trim();
console.log("jsonBuffer"+xmlRbuffer)
var parsedInput = JSON.parse(xmlRbuffer);
session.output.write('<' + 'Root' + '>'+OBJtoXML(parsedInput)+'</' + 'Root' + '>')
 var hm = require('header-metadata');
hm.current.set('content-type', 'application/xml');
function OBJtoXML(obj) {
    var xml = '';
    for (var prop in obj) {
        if (obj[prop] instanceof Array) {
            for (var array in obj[prop]) {
                xml += '<' + prop + '>';
                xml += OBJtoXML(new Object(obj[prop][array]));
                xml += '</' + prop + '>';
            }
        } else {
            xml += '<' + prop + '>';
            typeof obj[prop] == 'object' ? xml += OBJtoXML(new Object(obj[prop])) : xml += obj[prop];
            xml += '</' + prop + '>';
        }
    }
    var xml = xml.replace(/<\/?[0-9]{1,}>/g, '');
    return xml;
}}})