//This gatewayscript is used to trigger the OMS backend with GET request and the response is sent to the next action
//Date: 12th March 2020
//Author: Bhagya Lakshmi C D
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
sm.setVar('var://service/mpgw/skip-backside', true);

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		session.output.write(readAsJSONError);
	} else {
		var request = session.createContext('InputRequest');
		request.setVar('InputRequest', incomingdata);
		/* var options = {
			 target: session.parameters.target,
			 sslClientProfile: session.parameters.sslClientProfile,
			 method: 'get',
			 headers: {
				 'osiApiToken': session.parameters.osiApiToken
			 },
 
			 contentType: 'application/json',
		 };*/

		var options = {
			target: session.parameters.jsonDataTarget,
			method: 'get',
			contentType: 'application/json',
		};

		// open connection to target and send data over
		urlopen.open(options, function(error, response) {
			if (error) {
				logger.error("error while calling internal service for modified oms response " + JSON.stringify(error))
				session.reject("error while calling internal service for modified oms response " + JSON.stringify(error))
			} else {
				// read response data
				// get the response status code
				var responseStatusCode = response.statusCode;
				var responseReasonPhrase = response.reasonPhrase;
				if (responseStatusCode == 200) {
					response.readAsBuffer(function(error, responseData) {
						if (error) {
							// error while reading response or transferring data to Buffer
							console.log("Error from OMS: " + JSON.stringify(error));
							session.output.write(error);
						} else {
							hm.current.set('content-type', 'application/json');
							session.output.write(responseData);
							console.log(responseData);
						}
					});
				} else {
					hm.response.statusCode = responseStatusCode;
					var response = session.createContext('ExternalAPIOMS');
					response.setVar('omsstatuscode', responseStatusCode);
					response.setVar('omsresponse', responseReasonPhrase);
					sm.setVar('var://service/error-protocol-reason-phrase', responseReasonPhrase);
					console.log("Response returned from internal service for modified oms response: " + responseReasonPhrase + "  with sta code : " + responseStatusCode);
					session.reject("Response returned from internal service for modified oms response: " + responseReasonPhrase + "  with sta code : " + responseStatusCode)
				}
			}
		}); // end of urlopen.open()
	}
});
