var urlopen = require('urlopen');
var hm = require('header-metadata');
var sm = require('service-metadata');
sm.setVar('var://service/mpgw/skip-backside', true);
var logger = console.options({ "category": "all" })
var ctx = session.name("Lookup") || session.createContext("Lookup");
var options = {
	target: session.parameters.target,
	sslClientProfile: session.parameters.sslClientProfile,
	method: 'get',
	contentType: 'application/json',
	headers: {
		'osiApiToken': session.parameters.osiApiToken
	}
};

urlopen.open(options, function(error, response) {
	if (error) {
		logger.error("error while calling OMS " + JSON.stringify(error));
		hm.response.statusCode = responseStatusCode;
		session.output.write(error);
	} else {
		var responseStatusCode = response.statusCode;
		var responseReasonPhrase = response.reasonPhrase;
		if (responseStatusCode == 200) {
			response.readAsJSON(function(error, responseData) {
				if (error) {
					logger.error("Error reading response from OMS: " + JSON.stringify(error));
					session.output.write(error);
				} else {
					hm.current.set('content-type', 'application/json');
					var responseJson = {}
					/*responseJson.serviceTypes = responseData.serviceTypes
					responseJson.linkTypes = responseData.linkTypes
					responseJson.workFlows = responseData.workFlows
					responseJson.operationModes = responseData.operationModes
					responseJson.systemConfiguration = responseData.systemConfiguration
					responseJson.workRequestTemplates = responseData.workRequestTemplates
					responseJson.jobTemplates = responseData.jobTemplates
					responseJson.systemFieldDefinitions = responseData.systemFieldDefinitions
					responseJson.aors = responseData.aors*/
					//	ctx.setVar("responseData", responseData);
					var serviceTypes = responseData.serviceTypes.map(serviceType => {
						return {
							id: serviceType.id,
							deprecated: serviceType.deprecated,
							jobCustomFields: processCustomFields(serviceType.jobCustomFields),
							callCustomFields: processCustomFields(serviceType.callCustomFields),
							crewCustomFields: processCustomFields(serviceType.crewCustomFields),
							crewAssignmentCustomFields: processCustomFields(serviceType.crewAssignmentCustomFields),
							feederCustomFields: processCustomFields(serviceType.feederCustomFields),
							deviceCustomFields: processCustomFields(serviceType.deviceCustomFields),
							contactMethods: processCustomFields(serviceType.contactMethods),
							callCodes: processCustomFields(serviceType.callCodes),
							crewTypes: processCustomFields(serviceType.crewTypes),
							etrExpirationStatuses: processCustomFields(serviceType.etrExpirationStatuses),
							networkModelTypeLabels: processCustomFields(serviceType.networkModelTypeLabels),
							observations: processCustomFields(serviceType.observations),
							workTypes: processCustomFields(serviceType.workTypes),
							outageSubtypes: processCustomFields(serviceType.outageSubtypes),
							jobTypes: processJobTypes(serviceType.jobTypes)
						};
					});

					//  linkType
					var filteredLinkTypes = {};
					for (var key in responseData.linkTypes) {
						var linkType = responseData.linkTypes[key];
						filteredLinkTypes[key] = {
							id: linkType.id,
							label: linkType.label,
							deprecated: linkType.deprecated
						};
					}
					// Assign the filtered linkTypes to the response JSON
					responseJson.linkTypes = filteredLinkTypes;
					//handle aors
					responseJson.aors = {};
					responseJson.aors.Electric = [];

					for (var i = 0; i < responseData.aors.Electric.length; i++) {
						var aor = responseData.aors.Electric[i];
						var aorObj = {};
						aorObj.id = aor.id;
						aorObj.label = aor.label;
						if (aor.externalID) {
							aorObj.externalID = aor.externalID; //if present
						}
						aorObj.deprecated = aor.deprecated;
						responseJson.aors.Electric.push(aorObj);
					}
					//
					//handle job templates

					responseJson.jobTemplates = {};
					responseJson.jobTemplates.Electric = [];

					for (var i = 0; i < responseData.jobTemplates.Electric.length; i++) {
						var job = responseData.jobTemplates.Electric[i];
						var jobObj = {};
						jobObj.id = job.id;
						jobObj.externalID = job.externalID;
						jobObj.label = job.label;
						jobObj.description = job.description;
						jobObj.jobTypeIDs = job.jobTypeIDs;
						jobObj.deprecated = job.deprecated;

						responseJson.jobTemplates.Electric.push(jobObj);
					}
					//
					// handle operationMode

					responseJson.operationModes = {};
					responseJson.operationModes.Electric = [];

					for (var i = 0; i < responseData.operationModes.Electric.length; i++) {
						var mode = responseData.operationModes.Electric[i];
						var modeObj = {};
						modeObj.id = mode.id;
						modeObj.label = mode.label;
						modeObj.deprecated = mode.deprecated;

						responseJson.operationModes.Electric.push(modeObj);
					}
					//

					var workflows = responseData.workFlows;
					var keys = Object.keys(workflows);
					//var workflowArray = [];
					var workflowObj = {};
					for (var i = 0; i < keys.length; i++) {
						var key = keys[i];
						var workflow = workflows[key];
						// If it's the last workflow, construct the required structure
						workflowObj[key] = {
							id: workflow.id,
							states: workflow.states.map(state => ({
								id: state.id,
								toStates: state.toStates.map(toStates => ({
									actionLabel: toStates.actionLabel,
									toState: toStates.toState
								})),
								label: state.label,
								identifier: state.identifier,
								deprecated: state.deprecated
							}))
						};
					}
					responseJson.workFlows = workflowObj
						// Get the incoming request content(input)
					var sysconfgdata = responseData.systemConfiguration;
					var systemConfiguration = {};
					// Create the output object with only necessary fields
					var systemConfigurationOutput = {
						systemConfiguration: {
							// Retain only the 'id' field from systemConfiguration
							id: sysconfgdata.id,
							// Filter the 'changeReasons' array, keeping only the required fields
							changeReasons: sysconfgdata.changeReasons.map(reason => ({
								id: reason.id,
								identifier: reason.identifier,
								label: reason.label,
								deprecated: reason.deprecated
							})),
							// Filter the 'callbackContactMethodTypes' array, keeping only the required fields
							callbackContactMethodTypes: sysconfgdata.callbackContactMethodTypes.map(type => ({
								id: type.id,
								identifier: type.identifier,
								label: type.label,
								deprecated: type.deprecated
							}))
						}
					};
					// Set the systemConfiguration in responseJson
					responseJson.systemConfiguration = systemConfigurationOutput.systemConfiguration;
					//	var workflows = processWorkflows(responseData.workflows);
					responseJson.serviceTypes = serviceTypes;
					//	responseJson.workflows = workflows;
					session.output.write(responseJson)
				}
			});
		} else {
			hm.response.statusCode = responseStatusCode;
			var response = session.createContext('ExternalAPIOMS');
			response.setVar('omsstatuscode', responseStatusCode);
			response.setVar('omsresponse', responseReasonPhrase);
			sm.setVar('var://service/error-protocol-reason-phrase', responseReasonPhrase);
			logger.error("Error response returned from OMS is : " + responseReasonPhrase + "  with sta code : " + responseStatusCode);
			session.reject("Error response from OMS is : " + responseReasonPhrase + "  with sta code : " + responseStatusCode)
		}
	}
});

function processCustomFields(customFields) {
	return customFields.map(field => {
		var fieldObj = {
			id: field.id,
			externalLabel: field.externalLabel,
			externalID: field.externalID,
			workflowID: field.workflowID,
			identifier: field.identifier,
			label: field.label,
			deprecated: field.deprecated,
			archived: field.archived,
			jobTypeID: field.jobTypeID
		};

		// Add values if they exist
		if (field.values && field.values.length > 0) {
			fieldObj.values = field.values.map(value => {
				return {
					id: value.id,
					archived: value.archived,
					identifier: value.identifier,
					label: value.label,
					deprecated: value.deprecated,
					excluded: value.excluded
				};
			});
		}
		return fieldObj;
	});
}
function processJobTypes(jobTypes) {
	return jobTypes.map(jobType => {
		return {
			id: jobType.id, externalID: jobType.externalID, archived: jobType.archived, label: jobType.label, deprecated: jobType.deprecated, outageType: jobType.outageType, jobWorkflowID: jobType.jobWorkflowID, workTypeIDs: jobType.workTypeIDs, defaultWorkTypeID: jobType.defaultWorkTypeID, etrMode: jobType.etrMode

		};
		
		// Add values if they exist
		if (jobType.workTypeIDs && jobType.workTypeIDs.length > 0) {
			jobType.workTypeIDs = jobType.workTypeIDs.map(value => {
				return {
					workTypeIDs
				};
			});
		}
		
		
	});
}
function processWorkflows(workflows) {
	return workflows.map(workflow => {
		return {
			id: workflow.id, label: workflow.label, deprecated: workflow.deprecated, states: workflow.states.map(state => {
				return {
					id: state.id, label: state.label, deprecated: state.deprecated, toStates: state.toStates.map(toState => {
						return {
							actionLabel: toState.actionLabel, toState: toState.toState

						};
					})
				};
			})
		};
	});
}
