//This gatewayscript is used to frame the error response when any error has occured
//Date: 12th March 2020
//Author: Bhagya Lakshmi C D
var hm = require('header-metadata');
var sm = require('service-metadata');
hm.current.statusCode = '500';
var obj = {};
obj.errorMessage = sm.getVar('var://service/error-message');
obj.errorCode = sm.getVar('var://service/error-code');
obj.formattedErrorMessage = sm.getVar('var://service/formatted-error-message');
obj.errorHeaders = sm.getVar('var://service/error-headers');
session.output.write(obj);