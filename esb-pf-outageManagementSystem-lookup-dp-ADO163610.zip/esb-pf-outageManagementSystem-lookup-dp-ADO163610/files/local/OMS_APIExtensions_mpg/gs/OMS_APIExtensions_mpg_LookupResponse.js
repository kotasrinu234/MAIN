//This gatewayscript is used to frame the lookup response from the OMS backend response data by using the lookupconfig file path detailings
//Date: 12th March 2020
//Author: Bhagya Lakshmi C D
//Author:Sushma Yarlagadda
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
    'category': 'all'
});
//reading data returned from API call
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        session.output.write(readAsJSONError);
    } else {
        //reading lookup config
        fs.readAsJSON('local:///OMS_APIExtensions_mpg/gs/OMS_APIExtensions_mpg_LookupConfig.json', function(error, LookupConfig) {
            if (error) {
                session.output.write(error);
            } else {
                var obj = {};
                //reading input data
                var IncomingRequest = session.name('InputRequest').getVar('InputRequest');
                var obj1 = [];
                //no of objects in the array
                var lookupArraylength = IncomingRequest.lookupReq.type.length;

                //looping over incoming request
                for (var i = 0; i < IncomingRequest.lookupReq.type.length; i++) {
                    //Declaration of temp variables for checking if the search is successful or not
                    var tempid = '';
                    var templabel = '';
                    var ID_tempid = '';
					var ID_tempidValue = '';
                    var tempDeprecated = '';
                    var tempPush = {};
                    //looping over config file
                    for (var j = 0; j < LookupConfig.LookUpConfig.Type.length; j++) {
                        //matching incoming name with config file name
                        if (IncomingRequest.lookupReq.type[i].name == LookupConfig.LookUpConfig.Type[j].name) {
                            //Declaration of temp variables for checking if the incoming request name exists in the config file
                            var temp = i;

                            //traverse to the path in the corresponding name in config file
                            var pathArray = index(incomingdata, LookupConfig.LookUpConfig.Type[j].path)

                            // pulling the name from the lookup config file
                            var lookupName = LookupConfig.LookUpConfig.Type[j].name;

                            var lookupNameSplit = lookupName.split('.');
                            //finding out if single or multiple name there in lookup config file
                            var lookupNameLength = lookupNameSplit.length;

                            //when single name is there in lookup file and id is not there and the length of the name in the config file is not more than length one(i.e, one search level in the config file)
                            if (IncomingRequest.lookupReq.type[i].id == null && (lookupNameLength <= 1)) {

                                if (Array.isArray(pathArray)) {
                                  //  console.log("in array");
                                    //looping over the path in the config filee which corresponds to the matching name	
                                    for (var l = 0; l < pathArray.length; l++) {
                                        //index() function is used to fetch the requested field from the json structure dynamically which is defined in the same js at the bottom.
                                        //It has two arguments, first argument is the json structure where the search has to occur and the second argument is the search string i.e, what has to be searched	
                                        var idstatus = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].status);
                                        //checking if the status from the incoming request is null and label is not null.This block frames the search which matches the label from the request to the label from OMS response and the deprcated value is false
                                        if (IncomingRequest.lookupReq.type[i].status == null && IncomingRequest.lookupReq.type[i].label != null) {
											// single label match
											if(IncomingRequest.lookupReq.type[i].externalLabel == null) {
                                            var labelSearch = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].label);
                                            if (labelSearch !== undefined) {
                                                var incomingLabel = IncomingRequest.lookupReq.type[i].label;
                                                var aLabelSearch = labelSearch;
                                                if (incomingLabel === aLabelSearch) {
                                                    //The variable "ID_tempid" is assigned with the value "exists" when the if block condition is met
                                                    var obj5 = {};
                                                    obj5.name = IncomingRequest.lookupReq.type[i].name;
                                                    obj5.id = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].id);
                                                    obj5.label = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].label);
                                                    obj5.status = idstatus;
                                                    if (obj5.label === null) {
                                                        obj5.result = 1;
                                                    } else {
                                                        obj5.result = 0;
                                                        if (obj5.status == null) {
                                                            obj5.status = 'none';
                                                        }
                                                    }
                                                    if (index(pathArray[l], 'deprecated') == false){ // && (tempDeprecated == true || tempDeprecated === '')) || (index(pathArray[l], 'deprecated') == true && tempDeprecated === '')) {
                                                    	ID_tempid = 'exists';
                                                    	tempDeprecated = index(pathArray[l], 'deprecated');
                                                        tempPush = obj5;
                                                    } else {
                                                    	ID_tempid = '';
                                                    }
                                                }
                                                if (l == pathArray.length - 1 && Object.keys(tempPush).length != 0) {
                                                    obj1.push(tempPush);
                                                }
                                            }
											}
											//multiple level label match
											else if(IncomingRequest.lookupReq.type[i].externalLabel != null) {
											var labelSearch = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].label);
                                            if (labelSearch !== undefined) {
												ID_tempid = 'exists';
                                                var incomingLabel = IncomingRequest.lookupReq.type[i].externalLabel;
                                                var aLabelSearch = labelSearch.toUpperCase();	
                                                
                                                if (incomingLabel.toUpperCase() == aLabelSearch && pathArray[l].deprecated == false) {
												    var valuesPath = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].customdata);
													var obj2 = {};
													for (var alpha = 0; alpha < valuesPath.length; alpha++) {
                                                            var valueLabelSearch = valuesPath[alpha].label;
                                                            if (valueLabelSearch !== undefined) {
                                                                var valueIncomingLabel = IncomingRequest.lookupReq.type[i].label;
                                                                var cLabelSearch = valueLabelSearch;
                                                                //This block is executed when the label in the OMS response search equals the label from the incoming request.Also, if the deprecated value is false in the OMS response
                                                                if (cLabelSearch == valueIncomingLabel) {
																	obj2.id = valuesPath[alpha].id;
                                                                    obj2.label = valuesPath[alpha].label;
                                                                    obj2.name = IncomingRequest.lookupReq.type[i].name;
                                                                    obj2.status = index(valuesPath[alpha], LookupConfig.LookUpConfig.Type[j].status);

                                                                    //The result field in the response os set to "0" if the serach is not empty and set to "1" if not found
                                                                    if (obj2.id != null) {
                                                                        obj2.result = 0;
                                                                    } else {
                                                                        obj2.result = 1;
                                                                        obj2.label = IncomingRequest.lookupReq.type[i].label;
                                                                    }
                                                                    if (valuesPath[alpha].deprecated == false){ //&& (tempDeprecated == true || tempDeprecated === '')) || (valuesPath[alpha].deprecated == true && tempDeprecated === '')) {
                                                                    	ID_tempidValue = 'exists';
                                                                    	tempDeprecated = valuesPath[alpha].deprecated;
                                                                        tempPush = obj2;
                                                                    }
                                                                }
                                                                if (alpha == valuesPath.length - 1 && Object.keys(tempPush).length != 0) {
                                                                    obj1.push(tempPush);
                                                                }
												
                                                            }

                                                        }
															if (ID_tempidValue != 'exists') {
															var obj4 = {};
															obj4.name = IncomingRequest.lookupReq.type[i].name;
															if (IncomingRequest.lookupReq.type[i].id == null) {
																obj4.id = "undefined";
															} else {
																obj4.id = IncomingRequest.lookupReq.type[i].id;
															}
															if (IncomingRequest.lookupReq.type[i].status == null) {
																obj4.status = 'none';
															} else {
																obj4.status = IncomingRequest.lookupReq.type[i].status;
															}
															obj4.result = 1;
															obj1.push(obj4);
														}

                                            }
											}												
											
                                        }
										}
                                        //checking if the status value from config file for the requested name is "none".This block frames all the ids withtout matching the status field									

                                        //framing the search response or all the ids matching the incoming status/label
                                        //checking if the status value from config file for the requested name is "identifier" and also if the incoming status equals the search in the OMS response
                                        else if ((LookupConfig.LookUpConfig.Type[j].status == 'identifier' && IncomingRequest.lookupReq.type[i].status == idstatus) || ((LookupConfig.LookUpConfig.Type[j].status == 'identifier') && (IncomingRequest.lookupReq.type[i].status == null && IncomingRequest.lookupReq.type[i].label == null))) {
                                            //The variable "ID_tempid" is assigned with the value "exists" when the if block condition is met
                                            ID_tempid = 'exists';
                                            var obj5 = {};
                                            obj5.name = IncomingRequest.lookupReq.type[i].name;
                                            obj5.id = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].id);
                                            obj5.label = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].label);
                                            obj5.status = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].status);
                                            obj5.result = 0;
                                            obj1.push(obj5);
                                        } else if (LookupConfig.LookUpConfig.Type[j].status == 'none') {
                                            //The variable "ID_tempid" is assigned with the value "exists" when the if block condition is met
                                            ID_tempid = 'exists';
                                            var obj5 = {};
                                            obj5.name = IncomingRequest.lookupReq.type[i].name;
                                            obj5.id = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].id);
                                            obj5.status = 'none';
                                            obj5.label = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].label);;
                                            obj5.result = 0;
                                            obj1.push(obj5);
                                        } else {}
                                    }

                                    //This block is used to build the response(if id is empty from incoming request and single level search) if the search is unsuccessful or not found based on the variable "ID_tempid" because it will be set to "exists" if the search if found else the initial empty declartion will be assigned
                                    if (ID_tempid != 'exists' && IncomingRequest.lookupReq.type[i].externalLabel == null) {
                                        var obj4 = {};
                                        obj4.name = IncomingRequest.lookupReq.type[i].name;
                                        if (IncomingRequest.lookupReq.type[i].id == null) {
                                            obj4.id = "undefined";
                                        } else {
                                            obj4.id = IncomingRequest.lookupReq.type[i].id;
                                        }
                                        if (IncomingRequest.lookupReq.type[i].status == null) {
                                            obj4.status = 'none';
                                        } else {
                                            obj4.status = IncomingRequest.lookupReq.type[i].status;
                                        }
                                        obj4.result = 1;
                                        obj1.push(obj4);
                                    }																		

                                }
								
								
                                //In object
                                else {
                                    console.log("in object");
                                    var PropertyObject;
                                    var count = Object.keys(pathArray).length;
                                    var countPro = 0;
                                    for (var property in pathArray) {
                                        countPro++
                                        PropertyObject = index(pathArray, property)
                                        var idstatus = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].status);
                                        //checking if the status from the incoming request is null and label is not null.This block frames the search which matches the label from the request to the label from OMS response and the deprcated value is false
                                        if (IncomingRequest.lookupReq.type[i].status == null && IncomingRequest.lookupReq.type[i].label != null) {
                                            var objectLabelSearch = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].label);
                                            if (objectLabelSearch !== undefined) {
                                                var objectIncomingLabel = IncomingRequest.lookupReq.type[i].label;
                                                var bLabelSearch = objectLabelSearch.toUpperCase();
                                                if (objectIncomingLabel.toUpperCase() == bLabelSearch) {

                                                    //The variable "ID_tempid" is assigned with the value "exists" when the if block condition is met
                                                    ID_tempid = 'exists';

                                                    var obj5 = {};
                                                    obj5.name = IncomingRequest.lookupReq.type[i].name;
                                                    obj5.id = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].id);
                                                    obj5.label = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].label);
                                                    obj5.status = idstatus;
                                                    if (obj5.label == null) {
                                                        obj5.result = 1;
                                                    } else {
                                                        obj5.result = 0;
                                                        if (obj5.status == null) {
                                                            obj5.status = 'none';
                                                        }
                                                    }

                                                    if ((index(PropertyObject, 'deprecated') == false && (tempDeprecated == true || tempDeprecated === '')) || (index(PropertyObject, 'deprecated') == true && tempDeprecated === '')) {
                                                        tempDeprecated = index(PropertyObject, 'deprecated');
                                                        tempPush = obj5;
                                                    }
                                                }
                                                if (countPro == count - 1 && Object.keys(tempPush).length != 0) {
                                                    obj1.push(tempPush);
                                                }
                                            }

                                        } //framing the search response or all the ids matching the incoming status/label
                                        //checking if the status value from config file for the requested name is "identifier" and also if the incoming status equals the search in the OMS response
                                        else if ((LookupConfig.LookUpConfig.Type[j].status == 'identifier' && IncomingRequest.lookupReq.type[i].status == idstatus) || ((LookupConfig.LookUpConfig.Type[j].status == 'identifier') && (IncomingRequest.lookupReq.type[i].status == null && IncomingRequest.lookupReq.type[i].label == null))) {

                                            //The variable "ID_tempid" is assigned with the value "exists" when the if block condition is met
                                            ID_tempid = 'exists';
                                            var obj5 = {};
                                            obj5.name = IncomingRequest.lookupReq.type[i].name;
                                            obj5.id = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].id);
                                            obj5.label = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].label);
                                            obj5.status = idstatus;
                                            obj5.result = 0;
                                            obj1.push(obj5);
                                        }
                                        //checking if the status value from config file for the requested name is "none".This block frames all the ids withtout matching the status field									
                                        else if (LookupConfig.LookUpConfig.Type[j].status == 'none') {

                                            //The variable "ID_tempid" is assigned with the value "exists" when the if block condition is met
                                            ID_tempid = 'exists';
                                            var obj5 = {};
                                            obj5.name = IncomingRequest.lookupReq.type[i].name;
                                            obj5.id = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].id);
                                            obj5.status = 'none';
                                            obj5.label = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].label);;
                                            obj5.result = 0;
                                            obj1.push(obj5);
                                        } else {}

                                    }

                                    if (ID_tempid != 'exists') {
                                        var obj4 = {};
                                        obj4.name = IncomingRequest.lookupReq.type[i].name;
                                        if (IncomingRequest.lookupReq.type[i].id == null) {
                                            obj4.id = "undefined";
                                        } else {
                                            obj4.id = IncomingRequest.lookupReq.type[i].id;
                                        }
                                        if (IncomingRequest.lookupReq.type[i].status == null) {
                                            obj4.status = 'none';
                                        } else {
                                            obj4.status = IncomingRequest.lookupReq.type[i].status;
                                        }
                                        obj4.result = 1;
                                        obj1.push(obj4);
                                    }

                                }
                            }

                            //this block will be executed when the id value exists in the inccoming request or the length of the name in the config file is more than one/one search levels
                            else {
                                if (Array.isArray(pathArray)) {
                                    //looping over the path in the config filee which corresponds to the matching name	
                                    for (var k = 0; k < pathArray.length; k++) {

                                        //Fetching the id value from the OMS response with the index function
                                        var idHolder = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].id)
										

                                        //This block will be executed when the incoming id values equals to the id in the OMS response or if the incoming id is null
                                        if (IncomingRequest.lookupReq.type[i].id == idHolder || IncomingRequest.lookupReq.type[i].id == null) {
                                        	
                                            var lookupName = LookupConfig.LookUpConfig.Type[j].name;
                                            var lookupNameSplit = lookupName.split('.');
                                            var lookupNameLength = lookupNameSplit.length;

                                            //This block is executed when the length of the name in the config file after its separtion from '.' is greater than one
                                            if (lookupNameLength > 1) {
                                            
                                                //Retrieves the id in the multiple search level of config file from the OMS Response using index function
                                                var levelIdHolder = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].level.id)
                                                var obj2 = {};

                                                var levelPath = LookupConfig.LookUpConfig.Type[j].level.path;
                                                var levelPathArray = levelPath.split('.');

                                                //fetch the path in the multiple search level of config file from the OMS Response using index function in the "incomingdata" json
                                                var levelPathObject = index(incomingdata, levelPathArray[0])

                                                //This block is executed when the length of the level/path strings are not more than 1
                                                if (levelPathArray.length <= 1) {
                                                    var obj2 = {};

                                                    //Retrieves the id in the multiple search level of config file from the OMS Response using index function
                                                    var IdSubHolder = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].level.id);

                                                    var levelSubHolder = LookupConfig.LookUpConfig.Type[j].level.label;
													

                                                    //This block is executed when the IdSubHolder search in the OMS response equals the id value in the level object of the config file
                                                    if (IdSubHolder == levelSubHolder) {

                                                        //Fetching the value of the path in level object in congif file from the OMS response
                                                        var valuesPath = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].level.path);

                                                        //Looping over the array of the values derived from the path of the level in config file
                                                        for (var alpha = 0; alpha < valuesPath.length; alpha++) {
                                                            var valueLabelSearch = valuesPath[alpha].label;
                                                            if (valueLabelSearch !== undefined) {
                                                                var valueIncomingLabel = IncomingRequest.lookupReq.type[i].label;
                                                                var cLabelSearch = valueLabelSearch;
                                                                //This block is executed when the label in the OMS response search equals the label from the incoming request.Also, if the deprecated value is false in the OMS response
                                                                if (cLabelSearch == valueIncomingLabel) {

                                                                    
                                                                    obj2.id = valuesPath[alpha].id;
                                                                    obj2.label = valuesPath[alpha].label;
                                                                    obj2.name = IncomingRequest.lookupReq.type[i].name;
                                                                    obj2.status = index(valuesPath[alpha], LookupConfig.LookUpConfig.Type[j].level.status);

                                                                    //The result field in the response os set to "0" if the serach is not empty and set to "1" if not found
                                                                    if (obj2.status != null) {
                                                                        obj2.result = 0;
                                                                    } else {
                                                                        obj2.result = 1;
                                                                        obj2.label = IncomingRequest.lookupReq.type[i].label;
                                                                    }
                                                                    if (valuesPath[alpha].deprecated == false) { //&& (tempDeprecated == true || tempDeprecated === '')) || (valuesPath[alpha].deprecated == true && tempDeprecated === '')) {
                                                                    	tempid = 'exists';
                                                                    	tempDeprecated = valuesPath[alpha].deprecated;
                                                                        tempPush = obj2;
                                                                    }
                                                                }
                                                                if (alpha == valuesPath.length - 1 && Object.keys(tempPush).length != 0) {
                                                                    obj1.push(tempPush);
                                                                }
                                                            }

                                                        }
                                                    }
                                                }
                                                //This block is executed when the length of the level/path strings is more than 1
                                                else {
                                                    if (Array.isArray(levelPathObject)) {
                                                        //For arrays
                                                    } else {

                                                        //For accessing objects which have field names    
                                                        //console.error('inside else levelPathObject');
                                                        //looping over objects
                                                        for (var property in levelPathObject) {

                                                            //This block is executed when the object name equals the id in the level search
                                                            if (property == levelIdHolder) {
                                                                tempid = 'exists';
                                                                console.log("inside property" + tempid);
                                                                var levelPath = LookupConfig.LookUpConfig.Type[j].level.path;
                                                                var levelPathArray = levelPath.split('.');
                                                                var levelPathObject = index(incomingdata, levelPathArray[0])
                                                                var PropertyObject = index(levelPathObject, property);
                                                                var StatesObject = index(PropertyObject, levelPathArray[1]);

                                                                //This block is executed when the incoming status is null
                                                                if (IncomingRequest.lookupReq.type[i].status == null) {

                                                                    //If the label from the incoming request is null
                                                                    if (IncomingRequest.lookupReq.type[i].status == null && (IncomingRequest.lookupReq.type[i].label == null)) {
                                                                        for (var x = 0; x < StatesObject.length; x++) {
                                                                            var obj2 = {};
                                                                            obj2.name = LookupConfig.LookUpConfig.Type[j].name;
                                                                            if (IncomingRequest.lookupReq.type[i].id != null) {
                                                                                obj2.id = IncomingRequest.lookupReq.type[i].id;

                                                                            } else {
                                                                                obj2.id = property;
                                                                            }
                                                                            obj2.label = index(StatesObject[x], LookupConfig.LookUpConfig.Type[j].level.label);
                                                                            obj2.status = index(StatesObject[x], LookupConfig.LookUpConfig.Type[j].level.status);
                                                                            obj2.result = 0;
                                                                            obj1.push(obj2);
                                                                        }
                                                                    }
                                                                    //If the label from the incoming request is not null
                                                                    var tempLabel, tempStatus;
                                                                    if (IncomingRequest.lookupReq.type[i].label != null && IncomingRequest.lookupReq.type[i].status == null) {
                                                                        var obj2 = {};
                                                                        obj2.name = LookupConfig.LookUpConfig.Type[j].name;
                                                                        obj2.id = IncomingRequest.lookupReq.type[i].id;
                                                                        //Looping over the array of the level path
                                                                        for (var x = 0; x < StatesObject.length; x++) {
                                                                            var statesObjectLabelSearch = index(StatesObject[x], LookupConfig.LookUpConfig.Type[j].level.label);
                                                                            if (statesObjectLabelSearch !== undefined) {
                                                                                var statesObjectIncomingLabel = IncomingRequest.lookupReq.type[i].label;
                                                                                var dLabelSearch = statesObjectLabelSearch.toUpperCase();
                                                                                //This block is executed when the label from the incoming request equals the label in the OMS search
                                                                                if (statesObjectIncomingLabel.toUpperCase() == dLabelSearch) {
                                                                                    if ((index(StatesObject[x], 'deprecated') == false && (tempDeprecated == true || tempDeprecated === '')) || (index(StatesObject[x], 'deprecated') == true && tempDeprecated === '')) {
                                                                                        tempDeprecated = index(StatesObject[x], 'deprecated');
                                                                                        tempLabel = index(StatesObject[x], LookupConfig.LookUpConfig.Type[j].level.label);
                                                                                        tempStatus = index(StatesObject[x], LookupConfig.LookUpConfig.Type[j].level.status);
                                                                                    }

                                                                                }
                                                                                if (x == StatesObject.length - 1) {
                                                                                    obj2.label = tempLabel;
                                                                                    obj2.status = tempStatus;
                                                                                }
                                                                            }
                                                                        }
                                                                        //The result field in the response os set to "0" if the serach is not empty and set to "1" if not found
                                                                        if (obj2.status != null) {
                                                                            obj2.result = 0;
                                                                        } else {
                                                                            obj2.result = 1;
                                                                            obj2.label = "none";
                                                                        }


                                                                        obj1.push(obj2);
                                                                    }

                                                                }
                                                                //This block is executed when the status from the incoming request is not null
                                                                else {
                                                                    var obj2 = {};
                                                                    obj2.name = LookupConfig.LookUpConfig.Type[j].name;
                                                                    obj2.id = IncomingRequest.lookupReq.type[i].id;
                                                                    //Looping over the array of the level path
                                                                    for (var x = 0; x < StatesObject.length; x++) {
                                                                        //This block is executed when the status from the incoming request equals the status in the OMS search
                                                                        if (IncomingRequest.lookupReq.type[i].status == index(StatesObject[x], LookupConfig.LookUpConfig.Type[j].level.status)) {
                                                                            obj2.label = index(StatesObject[x], LookupConfig.LookUpConfig.Type[j].level.label);
                                                                            obj2.status = index(StatesObject[x], LookupConfig.LookUpConfig.Type[j].level.status);
                                                                        }
                                                                    }
                                                                    //The result field in the response os set to "0" if the serach is not empty and set to "1" if not found
                                                                    if (obj2.status != null) {
                                                                        obj2.result = 0;
                                                                    } else {
                                                                        obj2.result = 1;
                                                                        obj2.status = "none";
                                                                    }
                                                                    obj1.push(obj2);
                                                                }

                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            //This block is executed when the length of the name in the config file after its separtion from '.' is less than one
                                            else {
                                                //The variable "tempid" is assigned with the value "exists" 
                                                tempid = 'exists';
                                                var obj2 = {};
                                                obj2.name = LookupConfig.LookUpConfig.Type[j].name;
                                                obj2.id = pathArray[k].id;
                                                //This block is executed when the status from the incoming request is null
                                                if (IncomingRequest.lookupReq.type[i].status == null) {

                                                    //This block is executed when the label from the incoming request is not null
                                                    if (IncomingRequest.lookupReq.type[i].label != null) {
                                                        //Retrieving the status from the OMS response using index function
                                                        obj2.status = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].status);
                                                    } else {
                                                        //obj2.status = 'none'; changed on 18thAug
                                                        obj2.status = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].status);
                                                        obj2.label = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].label);
                                                    }
                                                }
                                                //This block is executed when status from the incoming request equals the status in the OMS search
                                                else if (IncomingRequest.lookupReq.type[i].status == pathArray[k].status || IncomingRequest.lookupReq.type[i].status == pathArray[k].identifier) {
                                                    obj2.status = IncomingRequest.lookupReq.type[i].status;

                                                } else {}
                                                
                                                //This block is executed when the label from the incoming request is not equal to null
                                                if (IncomingRequest.lookupReq.type[i].label != null) {

                                                    //This block is executed when the label from the incoming request equals the label from the search in the OMS response
                                                    if (IncomingRequest.lookupReq.type[i].label == index(pathArray[k], LookupConfig.LookUpConfig.Type[j].label)) {
                                                        obj2.label = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].label);

                                                    }
                                                } else {
                                                    var labelHolder = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].label)
                                                    obj2.label = labelHolder;
                                                }
                                                //The result field in the response os set to "0" if the serach is not empty and set to "1" if not found
                                                if (obj2.label == null) {
                                                    obj2.result = 1;
                                                } else {
                                                    obj2.result = 0;
                                                    if (obj2.status == null) {
                                                        obj2.status = 'none';
                                                    }
                                                }
                                                if ((index(pathArray[k], 'deprecated') == false && (tempDeprecated == true || tempDeprecated === '')) || (index(pathArray[k], 'deprecated') == true && tempDeprecated === '')) {
                                                    tempDeprecated = index(pathArray[k], 'deprecated');
                                                    obj1.push(obj2);
                                                }
                                                //if (k == pathArray.length-1){obj1.push(tempPush)};
                                            }

                                        }

                                    }
                                } else {
                                    var PropertyObject;
                                   
                                    var count = Object.keys(pathArray).length;
                                    var countPro = 0;
                                    for (var property in pathArray) {
                                        PropertyObject = index(pathArray, property);
                                        count++;
                                        var idHolder = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].id)
                                        if (idHolder == IncomingRequest.lookupReq.type[i].id) {
                                            //The variable "tempid" is assigned with the value "exists" 
                                            tempid = 'exists';
                                            var obj2 = {};
                                            obj2.name = LookupConfig.LookUpConfig.Type[j].name;
                                            obj2.id = PropertyObject.id;

                                            //This block is executed when the status from the incoming request is null
                                            if (IncomingRequest.lookupReq.type[i].status == null) {

                                                //This block is executed when the label from the incoming request is not null
                                                if (IncomingRequest.lookupReq.type[i].label != null) {
                                                    //Retrieving the status from the OMS response using index function
                                                    obj2.status = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].status)
                                                } else {
                                                    //obj2.status = 'none'; changed on Aug 18th
                                                    obj2.status = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].status);
                                                    obj2.label = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].label);
                                                }
                                            }
                                            //This block is executed when status from the incoming request equals the status in the OMS search
                                            else if (IncomingRequest.lookupReq.type[i].status == PropertyObject.status || IncomingRequest.lookupReq.type[i].status == PropertyObject.identifier) {
                                                obj2.status = IncomingRequest.lookupReq.type[i].status;

                                            } else {}

                                            //This block is executed when the label from the incoming request is not equal to null
                                            if (IncomingRequest.lookupReq.type[i].label != null) {

                                                //This block is executed when the label from the incoming request equals the label from the search in the OMS response
                                                if (IncomingRequest.lookupReq.type[i].label == index(PropertyObject, LookupConfig.LookUpConfig.Type[j].label)) {
                                                    obj2.label = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].label);

                                                }
                                            } else {
                                                var labelHolder = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].label)
                                                obj2.label = labelHolder;
                                            }
                                            //The result field in the response os set to "0" if the serach is not empty and set to "1" if not found
                                            if (obj2.label == null) {
                                                obj2.result = 1;
                                            } else {
                                                obj2.result = 0;
                                                if (obj2.status == null) {
                                                    obj2.status = 'none';
                                                }
                                            }
                                            if ((index(PropertyObject, 'deprecated') == false && (tempDeprecated != true || tempDeprecated === '')) || (index(PropertyObject, 'deprecated') == true && tempDeprecated === '')) {
                                                tempDeprecated = index(PropertyObject, 'deprecated');
                                                tempPush = obj2;
                                            }
                                        }
                                        if (countPro = countPro - 1 && Object.keys(tempPush).length != 0) {
                                            obj1.push(tempPush);
                                        }

                                    }
                                } //This block is used to build the response(for multi level search/if the id exists) if the search is unsuccessful or not found based on the variable "tempid" because it will be set to "exists" if the search if found else the initial empty declartion will be assigned
                                if (tempid != 'exists') {
                                    var obj4 = {};
                                    obj4.name = IncomingRequest.lookupReq.type[i].name;
                                    if (IncomingRequest.lookupReq.type[i].id == null) {
                                        obj4.id = "undefined";
                                    } else {
                                        obj4.id = IncomingRequest.lookupReq.type[i].id;
                                    }
                                    if (IncomingRequest.lookupReq.type[i].status == null) {
                                        obj4.status = 'none';
                                    } else {
                                        obj4.status = IncomingRequest.lookupReq.type[i].status;
                                    }
                                    obj4.result = 1;
                                    obj1.push(obj4);
                                }
                            }
                        }
                    }
                    //This block is used to build the response(if the name doesnot exist in the config file) if the search is unsuccessful or not found based on the variable "temp" because it will be set to "exists" if the search if found else the initial empty declartion will be assigned
                    if (i != temp) {

                        var obj3 = {};
                        obj3.name = IncomingRequest.lookupReq.type[i].name;
                        if (IncomingRequest.lookupReq.type[i].id == null) {
                            obj3.id = "undefined";
                        } else {
                            obj3.id = IncomingRequest.lookupReq.type[i].id;
                        }

                        if (IncomingRequest.lookupReq.type[i].status == null) {
                            obj3.status = 'none';
                        } else {
                            obj3.status = IncomingRequest.lookupReq.type[i].status;
                        }
                        obj3.result = 1;
                        obj1.push(obj3);
                    }

                }
                // Framing the entire response into a sinle object after mutiple object searches and printing to output
                obj.type = obj1;
                var lookupRep = {};
                lookupRep.lookupRep = obj;
                session.output.write(lookupRep);
            }
        })
    }

    //index() function is used to fetch the requested field from the json structure dynamically which can be called at the above js.
    //It has two arguments, first argument is the json structure where the search has to occur and the second argument is the search string i.e, what has to be searched
    function index(obj, is, value) {
        if (typeof is == 'string')
            return index(obj, is.split('.'), value);
        else if (is.length == 1 && value !== undefined)
            return obj[is[0]] = value;
        else if (is.length == 0)
            return obj;
        else
            return index(obj[is[0]], is.slice(1), value);
    }
});
