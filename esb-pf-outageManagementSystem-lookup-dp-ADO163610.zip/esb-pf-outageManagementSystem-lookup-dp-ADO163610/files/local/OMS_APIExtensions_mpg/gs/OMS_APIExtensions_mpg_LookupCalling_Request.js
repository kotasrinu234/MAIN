var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var logger = console.options({
    'category': 'all'
});

session.input.readAsJSON(function(readAsJSONError, incomingdata) {

    if (readAsJSONError) {
        logger.error("Error in reading incoming data");
        session.reject(readAsJSONError);
    } else {

        var nslookupservice = session.parameters.lookUpURL;

        var options = {
            target: nslookupservice,
            method: 'post',
            contentType: 'application/json',
            data: incomingdata
        };


        // open connection to target and send data over
        urlopen.open(options, function(error, response) {
            if (error) {
                // an error occurred during request sending or response header parsing
                logger.error("error while calling lookup service " + JSON.stringify(error));
                hm.response.statusCode = responseStatusCode;
            } else {
                // read response data
                // get the response status code
                var responseStatusCode = response.statusCode;
                var responseReasonPhrase = response.reasonPhrase;
                if (responseStatusCode == 200) {
                    response.readAsBuffer(function(error, responseData) {
                        if (error) {
                            // error while reading response or transferring data to Buffer
                            logger.error("Error from lookup service: " + JSON.stringify(error));
                        } else {

                            session.output.write(responseData);
                            logger.debug(responseData);
                        }
                    });
                } else {
                    hm.response.statusCode = responseStatusCode;
                    logger.error("Response returned from Lookupservice is : " + responseReasonPhrase + "  with status code : " + responseStatusCode);
                }
            }
        });
    }
});
