//This gatewayscript is used to frame the lookup response from the SOM backend response data by using the lookupconfig file path detailings
//Date: Jan 2022
//Author: Manoj Kumar S
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var logger = console.options({
	'category': 'all'
});

var ctx = session.name("lookup") || session.createContext("lookup")
//reading data returned from API call
session.input.readAsJSON(function(readAsJSONError, incomingdata) {
	if (readAsJSONError) {
		session.output.write(readAsJSONError);
	} else {
		//reading lookup config
		fs.readAsJSON('local:///SOM_APIExtensions_mpg/gs/SOM_APIExtensions_mpg_LookupConfig.json', function(error, LookupConfig) {
			if (error) {
				session.output.write(error);
			} else {
				var obj = {};
				//reading input data
				var IncomingRequest = session.name('InputRequest').getVar('InputRequest');
				var obj1 = [];
				//no of objects in the array
				var lookupArraylength = IncomingRequest.lookupReq.type.length;

				//looping over incoming request
				for (var i = 0; i < IncomingRequest.lookupReq.type.length; i++) {
					//Declaration of temp variables for checking if the search is successful or not
					var tempid = '';
					var templabel = '';
					var ID_tempid = '';
					var ID_tempidValue = '';
					var tempDeprecated = '';
					var tempPush = {};
					var tempvar = '';
					//looping over config file
					for (var j = 0; j < LookupConfig.LookUpConfig.Type.length; j++) {
						//matching incoming name with config file name
						if (IncomingRequest.lookupReq.type[i].name == LookupConfig.LookUpConfig.Type[j].name) {
							//Declaration of temp variables for checking if the incoming request name exists in the config file
							var temp = i;
							//traverse to the path in the corresponding name in config file
							var pathArray = index(incomingdata, LookupConfig.LookUpConfig.Type[j].path)
							ctx.setVariable('pathArray',pathArray);
							// pulling the name from the lookup config file
							var lookupName = LookupConfig.LookUpConfig.Type[j].name;
							var lookupNameSplit = lookupName.split('.');
							//finding out if single or multiple name there in lookup config file
							var lookupNameLength = lookupNameSplit.length;
							//when single name is there in lookup file and id is not there and the length of the name in the config file is not more than length one(i.e, one search level in the config file)
							if (IncomingRequest.lookupReq.type[i].id == null && (lookupNameLength <= 1)) {
								if (Array.isArray(pathArray)) {
									//  console.log("in array");
									//looping over the path in the config filee which corresponds to the matching name	
									for (var l = 0; l < pathArray.length; l++) {
										//index() function is used to fetch the requested field from the json structure dynamically which is defined in the same js at the bottom.
										//It has two arguments, first argument is the json structure where the search has to occur and the second argument is the search string i.e, what has to be searched	
										var idstatus = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].status);
										//checking if the status from the incoming request is null and label is not null.This block frames the search which matches the label from the request to the label from SOM response and the deprcated value is false
										if (IncomingRequest.lookupReq.type[i].status == null && IncomingRequest.lookupReq.type[i].label != null) {
											// single label match
											if(IncomingRequest.lookupReq.type[i].externalLabel == null) {
												var labelSearch = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].label);
												if (labelSearch !== undefined) {
													tempid = 'exists';
													var incomingLabel = IncomingRequest.lookupReq.type[i].label;
													var aLabelSearch = labelSearch.toUpperCase();
													// Lookup for crewTypes
													if (incomingLabel.toUpperCase() == aLabelSearch) {
														//The variable "ID_tempid" is assigned with the value "exists" when the if block condition is met
														//Lookup for switchOrderinternalId & switchOrderTypes
														ID_tempid = 'exists';
														var obj5 = {};
														obj5.name = IncomingRequest.lookupReq.type[i].name;
														obj5.id = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].id);
														obj5.label = index(pathArray[l], LookupConfig.LookUpConfig.Type[j].label);
														obj5.status = idstatus;
														if (obj5.label == null) {
															obj5.result = 1;
														} else {
															obj5.result = 0;
															if (obj5.status == null) {
																obj5.status = 'none';
															}
														}
														if ((index(pathArray[l], 'deprecated') == false && (tempDeprecated == true || tempDeprecated === '')) || (index(pathArray[l], 'deprecated') == true && tempDeprecated === '')) {
															tempDeprecated = index(pathArray[l], 'deprecated');
															tempPush = obj5;
														}
													}
													if (l == pathArray.length - 1 && Object.keys(tempPush).length != 0) {
														//LookupResult for switchOrderinternalId & switchOrderTypes
														obj1.push(tempPush);
													}
												}
											}
										}
									}
									//This block is used to build the response(if id is empty from incoming request and single level search) if the search is unsuccessful or not found based on the variable "ID_tempid" because it will be set to "exists" if the search if found else the initial empty declartion will be assigned
									if (ID_tempid != 'exists' && IncomingRequest.lookupReq.type[i].externalLabel == null) {
										var obj4 = {};
										obj4.name = IncomingRequest.lookupReq.type[i].name;
										for (let x= 0; x < pathArray.length; x++){
											if(pathArray[x].values !== undefined && pathArray[x].values.length >= 1){
												var pathValues = pathArray[x].values;
												ctx.setVariable('pathArray[x].values.length',pathArray[x].values.length);
												for (let y= 0; y < pathValues.length; y++){
													var incomminglabel = IncomingRequest.lookupReq.type[i].label;
													var valuelabel = pathValues[y].label;
													// Lookup for switchOrderDescription
													if (valuelabel === incomminglabel){
														tempvar = 'exists';
														obj4.id = pathArray[x].id;
														obj4.label = valuelabel;
														obj4.status = pathValues[y].identifier;
														obj4.result = 0;
														obj1.push(obj4);
													}
												}
											}
										}	
									}
									if (ID_tempid != 'exists' && tempvar !== 'exists') {
										// Lookup Failure for switchOrderDescription & switchOrderTypes & switchOrderinternalId & crewTypes
										var obj4 = {};
										obj4.name = IncomingRequest.lookupReq.type[i].name;
										if (IncomingRequest.lookupReq.type[i].id == null) {
											obj4.id = "undefined";
										} else {
											obj4.id = IncomingRequest.lookupReq.type[i].id;
										}
										if (IncomingRequest.lookupReq.type[i].status == null) {
											obj4.status = 'none';
										} else {
											obj4.status = IncomingRequest.lookupReq.type[i].status;
										}
										obj4.result = 1;
										obj1.push(obj4);
									}
								} else{
									var obj4 = {};
									obj4.name = IncomingRequest.lookupReq.type[i].name;
									var incommingLabel = IncomingRequest.lookupReq.type[i].label;
									ctx.setVariable('name151','151');
									//Lookup for aorsId
									tempid = 'exists';
									for(let x in pathArray){
										if (pathArray[x].label == incommingLabel){
											obj4.id = pathArray[x].id
											obj4.label = pathArray[x].label;
											obj4.result = 0;
											obj1.push(obj4);
										} else {
											obj4.id = pathArray[x].id
											obj4.label = pathArray[x].label;
											obj4.result = 0;
											obj1.push(obj4);
										}
									}
								}
								if (tempid != 'exists') {
									//Lookup failure for aorsId
									var obj4 = {};

									obj4.name = IncomingRequest.lookupReq.type[i].name;
									if (IncomingRequest.lookupReq.type[i].id == null) {
										obj4.id = "undefined";
									} else {
										obj4.id = IncomingRequest.lookupReq.type[i].id;
									}
									if (IncomingRequest.lookupReq.type[i].status == null) {
										obj4.status = 'none';
									} else {
										obj4.status = IncomingRequest.lookupReq.type[i].status;
									}
									obj4.result = 1;
									obj1.push(obj4);
									ctx.setVariable("obj4", obj4);
								}
							}
							//this block will be executed when the id value exists in the inccoming request or the length of the name in the config file is more than one/one search levels
							else {
								if (Array.isArray(pathArray)) {
									//looping over the path in the config filee which corresponds to the matching name	
									for (var k = 0; k < pathArray.length; k++) {
										//Fetching the id value from the SOM response with the index function
										var idHolder = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].id)
										ctx.setVariable("idHolder", idHolder);
										//This block will be executed when the incoming id values equals to the id in the SOM response or if the incoming id is null
										if (IncomingRequest.lookupReq.type[i].id == idHolder || IncomingRequest.lookupReq.type[i].id == null) {
											var lookupName = LookupConfig.LookUpConfig.Type[j].name;
											var lookupNameSplit = lookupName.split('.');
											var lookupNameLength = lookupNameSplit.length;
											//The variable "tempid" is assigned with the value "exists" 
											// Lookup for switchOrderTypeObjectID
											tempid = 'exists';
											var obj2 = {};
											obj2.name = LookupConfig.LookUpConfig.Type[j].name;
											obj2.id = pathArray[k].id;
											//This block is executed when the status from the incoming request is null
											if (IncomingRequest.lookupReq.type[i].status == null) {
												//This block is executed when the label from the incoming request is not null
												if (IncomingRequest.lookupReq.type[i].label != null) {
													//Retrieving the status from the SOM response using index function
													obj2.status = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].status);
												} else {
													obj2.status = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].status);
													obj2.switchOrderWorkFlowID = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].switchOrderWorkFlowID);
													obj2.label = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].label);
												}
											}
											//This block is executed when status from the incoming request equals the status in the SOM search
											else if (IncomingRequest.lookupReq.type[i].status == pathArray[k].status || IncomingRequest.lookupReq.type[i].status == pathArray[k].identifier) {
												obj2.status = IncomingRequest.lookupReq.type[i].status;
											} else {}

											//This block is executed when the label from the incoming request is not equal to null
											if (IncomingRequest.lookupReq.type[i].label != null) {
												//This block is executed when the label from the incoming request equals the label from the search in the SOM response
												if (IncomingRequest.lookupReq.type[i].label == index(pathArray[k], LookupConfig.LookUpConfig.Type[j].label)) {
													obj2.label = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].label);
												}
											} else {
												var labelHolder = index(pathArray[k], LookupConfig.LookUpConfig.Type[j].label)
												obj2.label = labelHolder;
											}
											//The result field in the response os set to "0" if the serach is not empty and set to "1" if not found
											if (obj2.label == null) {
												obj2.result = 1;
											} else {
												obj2.result = 0;
												if (obj2.status == null) {
													obj2.status = 'none';
												}
											}
											if ((index(pathArray[k], 'deprecated') == false && (tempDeprecated == true || tempDeprecated === '')) || (index(pathArray[k], 'deprecated') == true && tempDeprecated === '')) {
												tempDeprecated = index(pathArray[k], 'deprecated');
												obj1.push(obj2);
												// Lookup Result for switchOrderTypeObjectID
											}	
										}
									}
								} 
								else {
									if (index(pathArray, IncomingRequest.lookupReq.type[i].id) !== undefined){
										var PropertyObject = index(pathArray, IncomingRequest.lookupReq.type[i].id);
										var idHolder = index(PropertyObject, LookupConfig.LookUpConfig.Type[j].id)
										if (idHolder == IncomingRequest.lookupReq.type[i].id) {
											var obj2 = {};
											obj2.name = LookupConfig.LookUpConfig.Type[j].name;
											var workflowStates = PropertyObject.states;
											if(IncomingRequest.lookupReq.type[i].id == PropertyObject.id){
												for( let z = 0; z < PropertyObject.states.length; z++){
													if (IncomingRequest.lookupReq.type[i].label == PropertyObject.states[z].value.title && PropertyObject.states[z].value.startPoint == false && PropertyObject.states[z].value.fieldValues.deprecated == false){
														tempid = 'exists';
														//Lookup for switchOrder.WorkFlow
														obj2.id = PropertyObject.states[z].id;
														obj2.label = PropertyObject.states[z].value.title;
														obj2.status= PropertyObject.states[z].identifier;
														if (obj2.label == null) {
															obj2.result = 1;
														} else {
															obj2.result = 0;
															if (obj2.status == null) {
																obj2.status = 'none';
															}
														}
														obj1.push(obj2);
														ctx.setVariable("obj2", obj2);
													}
												}
											}
										} else {
											tempid = 'notexists';
										}
									} else {
										// Lookup for switchOrder.WorkFlowStatus
										var incomingReqId = IncomingRequest.lookupReq.type[i].id;
										var obj2 = {};
										obj2.name = IncomingRequest.lookupReq.type[i].name;
										for(var s in pathArray){
											for( var z = 0; z < pathArray[s].states.length; z++){
												if (incomingReqId == pathArray[s].states[z].id) {
													tempid = 'exists';
													obj2.id = pathArray[s].states[z].id;
													obj2.label = pathArray[s].states[z].value.title;
													obj2.status= pathArray[s].states[z].identifier;
													if (obj2.label == null) {
														obj2.result = 1;
													} else {
														obj2.result = 0;
														if (obj2.status == null) {
															obj2.status = 'none';
														}
													}
													obj1.push(obj2);
													ctx.setVariable("obj2", obj2);
												}
											}
										}
									}
								}
								if (tempid != 'exists') {
									// Lookup Failure for switchOrderTypeObjectID & switchOrder.WorkFlow & switchOrder.WorkFlowStatus
									var obj4 = {};
									obj4.name = IncomingRequest.lookupReq.type[i].name;
									if (IncomingRequest.lookupReq.type[i].id == null) {
										obj4.id = "undefined";
									} else {
										obj4.id = IncomingRequest.lookupReq.type[i].id;
									}
									if (IncomingRequest.lookupReq.type[i].status == null) {
										obj4.status = 'none';
									} else {
										obj4.status = IncomingRequest.lookupReq.type[i].status;
									}
									obj4.result = 1;
									obj1.push(obj4);

								}
							}
						}
					}
					//This block is used to build the response(if the name doesnot exist in the config file) if the search is unsuccessful or not found based on the variable "temp" because it will be set to "exists" if the search if found else the initial empty declartion will be assigned
					if (i != temp) {
						var obj3 = {};
						obj3.name = IncomingRequest.lookupReq.type[i].name;
						if (IncomingRequest.lookupReq.type[i].id == null) {
							obj3.id = "undefined";
						} else {
							obj3.id = IncomingRequest.lookupReq.type[i].id;
						}
						if (IncomingRequest.lookupReq.type[i].status == null) {
							obj3.status = 'none';
						} else {
							obj3.status = IncomingRequest.lookupReq.type[i].status;
						}
						obj3.result = 1;
						obj1.push(obj3);
					}
				}
				// Framing the entire response into a sinle object after mutiple object searches and printing to output
				obj.type = obj1;
				var lookupRep = {};
				lookupRep.lookupRep = obj;
				session.output.write(lookupRep);
			}
		})
	}

	//index() function is used to fetch the requested field from the json structure dynamically which can be called at the above js.
	//It has two arguments, first argument is the json structure where the search has to occur and the second argument is the search string i.e, what has to be searched
	function index(obj, is, value) {
		if (typeof is == 'string')
			return index(obj, is.split('.'), value);
		else if (is.length == 1 && value !== undefined)
			return obj[is[0]] = value;
		else if (is.length == 0)
			return obj;
		else
			return index(obj[is[0]], is.slice(1), value);
	}
});
