//This gatewayscript is used to trigger the SOM backend with GET request and the response is sent to the next action
//Date: Jan 2022
//Author: Manoj Kumar S
var urlopen = require('urlopen');
var fs = require('fs');
var hm = require('header-metadata');
var sm = require('service-metadata');
var ctx = session.name("lookup") || session.createContext("lookup");
sm.setVar('var://service/mpgw/skip-backside', true);

session.input.readAsJSON(function(readAsJSONError, incomingdata) {
    if (readAsJSONError) {
        session.output.write(readAsJSONError);
    } else {
        var request = session.createContext('InputRequest');
        request.setVar('InputRequest', incomingdata);
        var options = {
            target: session.parameters.target,
            sslClientProfile: session.parameters.sslClientProfile,
            method: 'get',
            headers: {
                'osiApiToken': session.parameters.osiApiToken
            },

            contentType: 'application/json',
        };
        // open connection to target and send data over
        urlopen.open(options, function(error, response) {
            if (error) {
                // an error occurred during request sending or response header parsing
                console.log("error while calling SOM" + JSON.stringify(error));
                hm.response.statusCode = responseStatusCode;
                session.output.write(error);
            } else {
                // read response data
                // get the response status code
                var responseStatusCode = response.statusCode;
                var responseReasonPhrase = response.reasonPhrase;
                if (responseStatusCode == 200) {
                    response.readAsBuffer(function(error, responseData) {
                        if (error) {
                            // error while reading response or transferring data to Buffer
                            console.log("Error from SOM: " + JSON.stringify(error));
                            session.output.write(error);
                        } else {
                            hm.current.set('content-type', 'application/json');
ctx.setVariable("responseData", responseData);
                            session.output.write(responseData);
                            console.log(responseData);
                        }
                    });
                } else {
                    hm.response.statusCode = responseStatusCode;
                    var response = session.createContext('ExternalAPISOM');
                    response.setVar('somstatuscode', responseStatusCode);
                    response.setVar('somresponse', responseReasonPhrase);
                    sm.setVar('var://service/error-protocol-reason-phrase', responseReasonPhrase);
                    console.log("Response returned from SOM is : " + responseReasonPhrase + "  with status code : " + responseStatusCode);
                }
            }
        }); // end of urlopen.open()
    }
});